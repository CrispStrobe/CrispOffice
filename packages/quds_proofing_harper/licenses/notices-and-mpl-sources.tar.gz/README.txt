Quds optional Harper distribution: original third-party notices and MPL source

The manifest selects permissive licenses or MPL-2.0 from each SPDX expression.
For MPL components, the exact unmodified source .crate archives are in sources/.
These archives correspond to the checksummed Cargo.lock inputs used for the build.
Keep this bundle and manifest with every redistributed native or Wasm binary.
No GPL/AGPL/LGPL-only dependency is permitted by this audited selection.
