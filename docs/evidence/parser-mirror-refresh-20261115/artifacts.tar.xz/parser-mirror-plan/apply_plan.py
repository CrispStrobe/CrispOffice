#!/usr/bin/env python3
"""Check by default; apply this exact saved mirror plan only with --apply.

The parent must wait until canonical qualification releases its source freeze.
No dependency resolution, testing, or checkout changes are performed here.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apply', action='store_true')
parser.add_argument('--stage', action='store_true')
parser.add_argument('--verify-after', action='store_true')
args = parser.parse_args()
if args.stage and not args.apply:
    parser.error('--stage requires --apply')
plan = json.loads((OUT / 'plan.json').read_text())
repo = Path(plan['quds_repository'])
upstream = Path(plan['parser_repository'])
prefix = Path(plan['mirror_prefix'])
mirror = repo / prefix
before = json.loads((OUT / 'before-manifest.json').read_text())
after = json.loads((OUT / 'after-manifest.json').read_text())

def git(where, *command):
    return subprocess.check_output(['git', '-C', str(where), *command])

def identity(path):
    if path.is_symlink():
        content = os.fsencode(os.readlink(path))
        mode = '120000'
    elif path.is_file():
        content = path.read_bytes()
        mode = '100755' if path.stat().st_mode & stat.S_IXUSR else '100644'
    else:
        return None
    return {'mode': mode, 'type': 'blob',
            'git_blob_sha': hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()}

def validate_files(manifest):
    differences = [path for path, row in manifest.items() if identity(mirror / path) != row]
    if differences:
        raise SystemExit('Working-tree contents or modes differ from required manifest: ' + repr(differences))

assert git(upstream, 'rev-parse', plan['parser_source']).decode().strip() == plan['parser_source']
assert git(upstream, 'rev-parse', plan['parser_source'] + '^{tree}').decode().strip() == plan['parser_source_tree']
if args.verify_after:
    validate_files(after)
    print(json.dumps({'verified': True, 'desired_files': len(after), 'repository_mutated': False}))
    raise SystemExit(0)

current_tree = git(repo, 'rev-parse', 'HEAD:' + str(prefix)).decode().strip()
if current_tree != plan['quds_anchor_subtree']:
    raise SystemExit('Canonical mirror changed since the audited anchor; re-audit before applying.')
staged = git(repo, 'diff', '--cached', '--name-only', '--', str(prefix)).decode().splitlines()
untracked = git(repo, 'ls-files', '--others', '--exclude-standard', '--', str(prefix)).decode().splitlines()
if staged or untracked:
    raise SystemExit('Mirror has staged or untracked source to review before applying: ' + repr({'staged': staged, 'untracked': untracked}))
validate_files(before)
payloads = {}
for operation in plan['operations']:
    relative = Path(operation['path'])
    if relative.is_absolute() or '..' in relative.parts:
        raise SystemExit('Invalid plan path')
    target = mirror / relative
    if not target.parent.resolve().is_relative_to(mirror.resolve()):
        raise SystemExit('Target parent escapes mirror')
    if operation['operation'] == 'add' and (target.exists() or target.is_symlink()):
        raise SystemExit('An untracked or ignored file occupies a proposed addition: ' + str(target))
    if operation['operation'] == 'delete':
        continue
    payload = operation['payload']
    if payload['kind'] == 'plan_file':
        content = (OUT / payload['path']).read_bytes()
    else:
        actual = git(upstream, 'rev-parse', payload['commit'] + ':' + payload['path']).decode().strip()
        assert actual == payload['git_blob_sha']
        content = git(upstream, 'cat-file', 'blob', actual)
    assert hashlib.sha256(content).hexdigest() == operation['sha256_after']
    assert len(content) == operation['size_after']
    payloads[operation['path']] = content

if not args.apply:
    print(json.dumps({'ready': True, 'repository_mutated': False, 'counts': plan['counts'],
                      'note': 'Read-only checks passed. Wait for qualification to finish before --apply.'}, indent=2))
    raise SystemExit(0)

for operation in plan['operations']:
    target = mirror / operation['path']
    if operation['operation'] == 'delete':
        target.unlink()
        continue
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_symlink():
        target.unlink()
    content = payloads[operation['path']]
    mode = operation['after']['mode']
    if mode == '120000':
        if target.exists():
            target.unlink()
        os.symlink(os.fsdecode(content), target)
    elif mode in {'100644', '100755'}:
        target.write_bytes(content)
        target.chmod(0o755 if mode == '100755' else 0o644)
    else:
        raise SystemExit('Unsupported Git mode: ' + mode)
validate_files(after)
if args.stage:
    subprocess.run(['git', '-C', str(repo), 'add', '--force', '--',
                    *[operation['destination'] for operation in plan['operations']]], check=True)
print(json.dumps({'applied': True, 'staged': args.stage, 'verified_files': len(after),
                  'counts': plan['counts']}, indent=2))
