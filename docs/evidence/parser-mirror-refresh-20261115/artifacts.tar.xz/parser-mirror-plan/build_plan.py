#!/usr/bin/env python3
"""Read immutable Git objects and write a parser mirror plan in this directory."""
import collections
import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
QUDS = BASE / 'quds_office_suite'
PARSER = BASE / 'legacy-doc-parser'
PREFIX = 'packages/legacy_doc_parser'

def git(repo, *args, data=None):
    return subprocess.check_output(['git', '-C', str(repo), *args], input=data)

def revision(repo, ref):
    return git(repo, 'rev-parse', ref).decode().strip()

def tree(repo, ref):
    result = {}
    for record in git(repo, 'ls-tree', '-rz', ref).split(b'\0'):
        if not record:
            continue
        attrs, path = record.split(b'\t', 1)
        mode, kind, sha = attrs.decode().split()
        result[path.decode()] = {'mode': mode, 'type': kind, 'git_blob_sha': sha}
    return result

def blob(repo, sha):
    return git(repo, 'cat-file', 'blob', sha)

def identity(data, mode='100644'):
    return {'mode': mode, 'type': 'blob',
            'git_blob_sha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

def compare(before, after):
    return {'added': sorted(after.keys() - before.keys()),
            'deleted': sorted(before.keys() - after.keys()),
            'changed': [p for p in sorted(before.keys() & after.keys()) if before[p] != after[p]]}

quds_ref = revision(QUDS, 'dc613179')
parser_ref = revision(PARSER, '08296edb')
mirror = tree(QUDS, quds_ref + ':' + PREFIX)
source = tree(PARSER, parser_ref)
upstream = json.loads(blob(QUDS, mirror['UPSTREAM.json']['git_blob_sha']))
old_ref = upstream['commit']
previous = tree(PARSER, old_ref)
local_differences = compare(previous, mirror)

def adapt_pubspec(data):
    assert data.count(b'  lints: ^3.0.0\n') == 1
    assert data.count(b'  xml: ^6.6.1\n') == 1
    assert b'resolution:' not in data
    return data.replace(b'  lints: ^3.0.0\n', b'  lints: ^6.0.0\n').replace(
        b'  xml: ^6.6.1\n', b'  xml: ^7.0.1\n').rstrip(b'\n') + b'\n\nresolution: workspace\n'

adapted_pubspec = adapt_pubspec(blob(PARSER, source['pubspec.yaml']['git_blob_sha']))
assert adapted_pubspec == blob(QUDS, mirror['pubspec.yaml']['git_blob_sha'])
assert adapt_pubspec(blob(PARSER, previous['pubspec.yaml']['git_blob_sha'])) == adapted_pubspec
assert local_differences['added'] == ['UPSTREAM.json']
assert local_differences['changed'] == ['pubspec.yaml']
assert all(p.startswith('doc/evidence/') and p.endswith('.log') for p in local_differences['deleted'])

upstream['commit'] = parser_ref
upstream_bytes = (json.dumps(upstream, indent=2) + '\n').encode()
(OUT / 'payloads').mkdir(exist_ok=True)
(OUT / 'payloads/pubspec.yaml').write_bytes(adapted_pubspec)
(OUT / 'payloads/UPSTREAM.json').write_bytes(upstream_bytes)

desired = {p: dict(row) for p, row in source.items()}
desired['pubspec.yaml'] = identity(adapted_pubspec, mirror['pubspec.yaml']['mode'])
desired['UPSTREAM.json'] = identity(upstream_bytes, mirror['UPSTREAM.json']['mode'])
delta = compare(mirror, desired)
operations = []
for operation, paths in [('add', delta['added']), ('modify', delta['changed']), ('delete', delta['deleted'])]:
    for path in paths:
        data = None
        payload = None
        if operation != 'delete':
            if path in {'pubspec.yaml', 'UPSTREAM.json'}:
                payload = {'kind': 'plan_file', 'path': 'payloads/' + path}
                data = (OUT / payload['path']).read_bytes()
            else:
                payload = {'kind': 'upstream_git_blob', 'commit': parser_ref, 'path': path,
                           'git_blob_sha': source[path]['git_blob_sha']}
                data = blob(PARSER, source[path]['git_blob_sha'])
        operations.append({'operation': operation, 'path': path,
                           'destination': PREFIX + '/' + path,
                           'before': mirror.get(path), 'after': desired.get(path),
                           'payload': payload,
                           'size_after': None if data is None else len(data),
                           'sha256_after': None if data is None else hashlib.sha256(data).hexdigest()})

plan = {
    'schema': 1,
    'mode': 'Read-only plan; repository writes require explicitly running apply_plan.py --apply later.',
    'quds_repository': str(QUDS), 'quds_anchor': quds_ref,
    'quds_anchor_subtree': revision(QUDS, quds_ref + ':' + PREFIX),
    'mirror_prefix': PREFIX,
    'parser_repository': str(PARSER), 'parser_source': parser_ref,
    'parser_source_tree': revision(PARSER, parser_ref + '^{tree}'),
    'previous_declared_parser_source': old_ref,
    'counts': {'mirror_before': len(mirror), 'upstream_target': len(source),
               'mirror_after': len(desired), **{k: len(v) for k, v in delta.items()}},
    'existing_customization_audit': {
        'undeclared_modified_files': [],
        'undeclared_product_source_changes': [],
        'mode_changes_relative_to_declared_upstream': [],
        'documented_pubspec_adaptations_verified_exactly': True,
        'additional_local_metadata': ['UPSTREAM.json'],
        'previously_omitted_tracked_evidence_logs_to_restore': local_differences['deleted'],
        'difference_from_declared_upstream': local_differences,
    },
    'preserved_adaptations': ['resolution: workspace', 'lints: ^6.0.0', 'xml: ^7.0.1'],
    'pubspec_bytes_unchanged': True,
    'upstream_metadata_preservation': 'Preserve all existing fields and patches text; change only commit.',
    'source_file_mode_counts': dict(collections.Counter(x['mode'] for x in source.values())),
    'operation_after_mode_counts': dict(collections.Counter(x['after']['mode'] for x in operations if x['after'])),
    'operation_source_bytes': sum(x['size_after'] or 0 for x in operations),
    'before_manifest_sha256': hashlib.sha256(encode(mirror)).hexdigest(),
    'after_manifest_sha256': hashlib.sha256(encode(desired)).hexdigest(),
    'operations': operations,
}
(OUT / 'before-manifest.json').write_bytes(encode(mirror))
(OUT / 'after-manifest.json').write_bytes(encode(desired))
(OUT / 'upstream-manifest.json').write_bytes(encode(source))
(OUT / 'plan.json').write_bytes(encode(plan))
(OUT / 'inventory.tsv').write_text('operation\tpath\tbefore_mode\tafter_mode\tbefore_blob\tafter_blob\tsize_after\tsha256_after\n' + ''.join(
    '\t'.join([x['operation'], x['path'], (x['before'] or {}).get('mode', '-'),
               (x['after'] or {}).get('mode', '-'), (x['before'] or {}).get('git_blob_sha', '-'),
               (x['after'] or {}).get('git_blob_sha', '-'), str(x['size_after'] or 0), x['sha256_after'] or '-']) + '\n'
    for x in operations))
print(json.dumps({key: plan[key] for key in ['quds_anchor', 'parser_source', 'counts',
                                           'source_file_mode_counts', 'operation_after_mode_counts',
                                           'operation_source_bytes']}, indent=2))
