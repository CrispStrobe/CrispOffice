#!/usr/bin/env python3
"""Run the fixed-source comments cohort and external roundtrips without mutation."""
import argparse
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--head', required=True)
args = parser.parse_args()
base = Path('/workspace/scratch/0b93849cdeb9')
receipt = base / 'comments-qualification-20261115'
repo = base / 'quds_office_suite'
sdk = base / 'toolchains/flutter/bin/cache/dart-sdk/bin'
tools = [base/'toolchains/env.sh', sdk/'dart', sdk/'dartvm', sdk/'dartaotruntime',
         sdk/'snapshots/dartdev_aot.dart.snapshot', sdk/'snapshots/kernel-service.dart.snapshot']
suites = (receipt/'related-suites.txt').read_text().splitlines()
tests = [str(Path(s).relative_to('packages/quds_office_engine')) for s in suites if s]
files = (receipt/'analysis-files.txt').read_text().splitlines()
xlsx = receipt/'decoy-corrected-xlsx'
commands = [
 ('decoy-corrected-related-tests', 'packages/quds_office_engine', receipt/'related-suites.txt',
  [str(sdk/'dart'), 'test', '--reporter=json', '--concurrency=2', *tests]),
 ('decoy-corrected-strict-analysis', '.', None,
  [str(sdk/'dart'), 'analyze', '--fatal-infos', '--fatal-warnings', *files]),
 ('decoy-corrected-fixture-generation', 'packages/quds_office_engine', None,
  [str(sdk/'dart'), 'run', 'tool/fidelity/comment_schema_fixture.dart', str(xlsx)]),
 ('decoy-corrected-independent-oracle', '.', None,
  ['python3', str(receipt/'verify_comments.py'), '--input-dir', str(xlsx), '--report', str(receipt/'decoy-corrected-independent-report.json')])
]
for name, cwd, manifest, argv in commands:
    cmd = ['python3', str(receipt/'record_gate-cwd.py'), '--repo', str(repo),
           '--output', str(receipt/name), '--head', args.head, '--cwd', cwd]
    if manifest: cmd += ['--suites', str(manifest)]
    for tool in tools: cmd += ['--tool', str(tool)]
    if name.endswith('independent-oracle'): cmd += ['--tool', str(receipt/'verify_comments.py')]
    cmd += ['--', *argv]
    result = subprocess.run(cmd, check=False)
    if result.returncode: raise SystemExit(result.returncode)
