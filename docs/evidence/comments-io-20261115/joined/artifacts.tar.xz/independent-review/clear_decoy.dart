import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';

void main() {
  final sheet = SmlWorksheet(name: 'Notes', sheetId: 1);
  sheet.cellA1('A1').value = 'source cell';
  sheet.comments.add(SmlComment(
    ref: SmlCellRef.parse('A1'), text: 'unrelated decoy', author: 'Decoy'));
  final package = SheetSerializer().write(SmlWorkbook(sheets: [sheet]));
  final decoyBefore = package.getPart('/xl/comments1.xml')!.readText();
  const actualUri = '/xl/annotations/note42.xml';
  package.createPart(actualUri, OfficeContentTypes.sheetComments, utf8.encode(
    '<comments xmlns="${OfficeNamespaces.x}">'
    '<authors><author>Original</author></authors>'
    '<commentList><comment ref="A1" authorId="0">'
    '<text><t>authored note</t></text>'
    '</comment></commentList></comments>'));
  final links = package.relationshipsFor('/xl/worksheets/sheet1.xml');
  final oldLink = links.firstByType(RelationshipTypes.comments)!;
  links.removeById(oldLink.id);
  links.add(id: oldLink.id, type: RelationshipTypes.comments,
      target: '../annotations/note42.xml');
  final imported = SheetDeserializer().readBytes(package.save());
  final importedText = imported.firstSheet.comments.map((c) => c.text).toList();
  imported.firstSheet.comments.clear();
  final saved = OpcPackage.openBytes(SheetSerializer().write(imported).save());
  final reopened = SheetDeserializer().read(saved);
  final after = reopened.firstSheet.comments.map((c) => c.text).toList();
  print(jsonEncode({
    'source': 'fd14d8a68477165e7ca3317b647f403f2308e353',
    'before_clear': importedText,
    'after_clear_save_reopen': after,
    'authored_part_removed': saved.getPart(actualUri) == null,
    'comments_relationship_removed': saved.relationshipsFor(
      '/xl/worksheets/sheet1.xml').firstByType(RelationshipTypes.comments) == null,
    'unrelated_decoy_bytes_preserved':
      saved.getPart('/xl/comments1.xml')!.readText() == decoyBefore,
    'expected_comments_after_clear': 0,
    'success': after.isEmpty,
  }));
  if (after.isNotEmpty) {
    throw StateError('Cleared authored comments resurrected unrelated fallback text');
  }
}
