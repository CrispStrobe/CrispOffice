import 'dart:convert';
import 'dart:typed_data';
import 'package:quds_office_engine/quds_office_engine.dart';

Uint8List ods(String rows) => (ZipWriter()..addFile('content.xml', utf8.encode('''
<o:document-content xmlns:o="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
 xmlns:t="urn:oasis:names:tc:opendocument:xmlns:table:1.0"
 xmlns:x="urn:oasis:names:tc:opendocument:xmlns:text:1.0">
<o:body><o:spreadsheet><t:table t:name="Data">$rows</t:table></o:spreadsheet></o:body>
</o:document-content>'''))).close();

Future<void> main() async {
  final rows = <Map<String, Object?>>[];
  for (final name in ['Semi;Colon', 'COM.MICROSOFT.Data', 'Dash-Name', 'Quote"Name']) {
    final formula = "of:=SUM(['$name'.A1];1)";
    final attribute = formula.replaceAll('&', '&amp;').replaceAll('"', '&quot;');
    final book = OdsSheetReader.readBytes(ods('<t:table-row><t:table-cell t:formula="$attribute" o:value-type="float" o:value="1"/></t:table-row>'));
    final reopened = SheetDeserializer().readBytes(await OfficeIsolateSave.workbook(book, recalculate: false));
    rows.add({'input':formula,'expected':"SUM('$name'!A1,1)",'imported':book.firstSheet.cellA1('A1').formula,'reopened':reopened.firstSheet.cellA1('A1').formula});
  }
  final malformed = OdsSheetReader.readBytes(ods('<t:table-row><t:table-cell t:number-columns-spanned="2" o:value-type="string"><x:p>Wide</x:p></t:table-cell><t:table-cell o:value-type="float" o:value="7"/></t:table-row>'));
  print(jsonEncode({'quoted_references':rows,'missing_covered_placeholder':{'merges':malformed.firstSheet.merges.map((m)=>m.a1).toList(),'B1':malformed.firstSheet.cellOrNull(const SmlCellRef(1,0))?.value,'C1':malformed.firstSheet.cellOrNull(const SmlCellRef(2,0))?.value}}));
}
