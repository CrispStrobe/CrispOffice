import pathlib,shlex,subprocess,sys,yaml
root=pathlib.Path(__file__).resolve().parent
repo=root/'quds_office_suite'
workflow=yaml.safe_load((repo/'.github/workflows/office-macros.yml').read_text())
step=next(x for x in workflow['jobs']['macros']['steps'] if x.get('name')=='Macro and existing command regressions')
files=[x for x in shlex.split(step['run']) if x.startswith('test/') and x.endswith('.dart')]
if len(files)!=29: raise SystemExit(f'Unexpected selection: {len(files)}')
command=[sys.executable,str(root/'run_validation.py'),'macro-final',str(repo/'packages/quds_office_engine'),'dart','--packages='+str(repo/'.dart_tool/package_config.json'),str(root/'runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),*files,'--concurrency','2','--timeout','4x','--reporter','json']
raise SystemExit(subprocess.run(command).returncode)
