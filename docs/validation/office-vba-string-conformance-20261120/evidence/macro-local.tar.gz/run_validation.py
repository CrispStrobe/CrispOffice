#!/usr/bin/env python3
"""Capture local qualification commands, raw output and source identities."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'quds_office_suite'
OUT = ROOT / 'qualification'
OUT.mkdir(exist_ok=True)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()

def inputs():
    paths = set(git('ls-files').splitlines())
    paths.update(git('ls-files', '--others', '--exclude-standard').splitlines())
    selected = {}
    for name in sorted(paths):
        path = REPO / name
        if not path.is_file():
            continue
        selected_test = not selected_tests or '/test/' not in name or name in selected_tests or '/test/support/' in name or '/test/compile/' in name
        if ((path.suffix == '.dart' and selected_test) or path.name in {'pubspec.yaml', 'pubspec.lock', '.fvmrc', 'analysis_options.yaml'}
                or '/example/macros/' in name or name.startswith('packages/quds_office_engine/test/fixtures/')
                or name == '.github/workflows/office-macros.yml'):
            selected[name] = sha(path.read_bytes())
    return selected

name, cwd, *command = sys.argv[1:]
if not name.replace('-', '').replace('_', '').isalnum() or not command:
    raise SystemExit('usage: run_validation.py NAME CWD COMMAND [ARGS...]')
selected_tests = set()
for argument in command:
    if argument.startswith('test/') and argument.endswith('.dart'):
        selected_tests.add(str((Path(cwd).resolve() / argument).relative_to(REPO)))
log = OUT / (name + '.log')
receipt = OUT / (name + '.json')
if log.exists() or receipt.exists():
    raise SystemExit('Use a new attempt name; existing evidence is retained.')
before = inputs()
manifest_data = (json.dumps(before, sort_keys=True, indent=2) + '\n').encode()
manifest_sha = sha(manifest_data)
manifest = OUT / ('inputs-' + manifest_sha + '.json')
manifest.write_bytes(manifest_data)
record = dict(name=name, startedAt=datetime.now(timezone.utc).isoformat(), command=command,
              cwd=str(Path(cwd).resolve()), gitHead=git('rev-parse', 'HEAD'),
              gitTree=git('rev-parse', 'HEAD^{tree}'), inputs=manifest.name,
              inputsSha256=manifest_sha, inputCount=len(before), selectedTests=sorted(selected_tests), log=log.name)
receipt.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'started': name, 'command': command}), flush=True)
start = time.monotonic()
with log.open('wb') as stream:
    process = subprocess.run(command, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT)
after = inputs()
record.update(finishedAt=datetime.now(timezone.utc).isoformat(), seconds=round(time.monotonic()-start, 3),
              exitCode=process.returncode, logSha256=sha(log.read_bytes()),
              inputsUnchanged=before == after,
              changedInputs=[p for p in sorted(set(before) | set(after)) if before.get(p) != after.get(p)])
tests = {}
done = []
for line in log.read_text(errors='replace').splitlines():
    try:
        value = json.loads(line)
    except (ValueError, TypeError):
        continue
    if isinstance(value, dict):
        if value.get('type') == 'testStart':
            tests[value['test']['id']] = value['test']
        if value.get('type') == 'testDone':
            done.append(value)
if done:
    record['testResults'] = {key: sum(1 for x in done if x.get('result') == key and not x.get('hidden', False))
                             for key in ('success', 'failure', 'error')}
    record['skipped'] = sum(1 for x in done if x.get('skipped') and not x.get('hidden', False))
    record['failedTests'] = [dict(test=tests.get(x['testID']), result=x) for x in done
                             if x.get('result') != 'success' and not x.get('hidden', False)]
receipt.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items()
                  if key in {'name','exitCode','seconds','inputsUnchanged','changedInputs','testResults','skipped'}}), flush=True)
if process.returncode:
    print(log.read_text(errors='replace')[-16000:], flush=True)
raise SystemExit(process.returncode)
