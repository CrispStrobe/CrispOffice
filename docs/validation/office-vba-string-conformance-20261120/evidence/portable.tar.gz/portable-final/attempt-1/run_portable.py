#!/usr/bin/env python3
"""Final sequential VM/JavaScript macro gate with explicit source guards."""
import base64
import datetime
import hashlib
import json
import pathlib
import shutil
import stat
import subprocess
import sys
import time

repo = pathlib.Path("/workspace/scratch/f0aea33f35d2/quds_office_suite")
engine = repo / "packages/quds_office_engine"
out = pathlib.Path("/workspace/scratch/f0aea33f35d2/portable-final")
logs = out / "logs"
artifacts = out / "artifacts"
logs.mkdir(parents=True, exist_ok=True)
artifacts.mkdir(parents=True, exist_ok=True)
smokes = [
    "web_smoke.dart",
    "web_vba_smoke.dart",
    "web_vba_procedures_smoke.dart",
    "web_vba_control_flow_smoke.dart",
    "web_vba_arrays_smoke.dart",
    "web_vba_dynamic_arrays_smoke.dart",
]
runner = "tool/macros/web_vba_string_conformance.dart"
fixture = engine / "test/fixtures/vba_conformance/string_intrinsics_v1.json"
package_config = repo / ".dart_tool/package_config.json"
explicit_inputs = {
    str((engine / "tool/macros" / name).relative_to(repo)) for name in smokes
} | {
    str((engine / runner).relative_to(repo)),
    str(fixture.relative_to(repo)),
    "packages/quds_office_engine/test/support/vba_conformance.dart",
    ".dart_tool/package_config.json",
}
config_names = {
    ".fvmrc", "pubspec.yaml", "pubspec.lock", "pubspec_overrides.yaml",
    "analysis_options.yaml", "build.yaml", "melos.yaml", "l10n.yaml",
    "package.json", "package-lock.json", "tsconfig.json",
}
def timestamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2) + "\n")
def git(*args):
    return subprocess.run(["git", *args], cwd=repo, check=True, stdout=subprocess.PIPE).stdout
def input_paths():
    names = set(git("ls-files", "--cached", "--others", "--exclude-standard", "-z").decode().split("\0"))
    selected = set(explicit_inputs)
    for name in names:
        if not name:
            continue
        p = pathlib.PurePosixPath(name)
        if any(part in {"docs", "test", "tests", "fixtures", "build", ".dart_tool"} for part in p.parts):
            continue
        if "lib" in p.parts and p.suffix in {".dart", ".json", ".yaml", ".yml", ".arb"}:
            selected.add(name)
        if p.name in config_names or p.suffix in {".yaml", ".yml"}:
            selected.add(name)
    return sorted(selected)
def manifest():
    result = {}
    for name in input_paths():
        p = repo / name
        data = p.read_bytes()
        result[name] = {
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data),
            "mode": oct(stat.S_IMODE(p.stat().st_mode)),
        }
    return result
before = manifest()
write_json(out / "inputs-before.json", before)
package_data = json.loads(package_config.read_text())
engine_binding = next(p for p in package_data["packages"] if p["name"] == "quds_office_engine")
assert (package_config.parent / engine_binding["rootUri"]).resolve() == engine.resolve()
commands = []
guards = []
summary = {
    "startedAt": timestamp(),
    "repository": str(repo),
    "workingDirectory": str(engine),
    "startingHead": git("rev-parse", "HEAD").decode().strip(),
    "inputPolicy": "All repository production lib Dart/JSON/YAML/ARB files; repository YAML and known dependency/analysis/SDK/node config files outside docs/test/fixtures/build; explicit package config and executed macro tools, shared conformance support, canonical fixture. Slide test additions are intentionally outside this boundary.",
    "inputCount": len(before),
    "packageConfig": str(package_config),
    "enginePackageBinding": engine_binding,
    "commands": commands,
    "sourceGuards": guards,
    "githubActionsQueriedOrAwaited": False,
}
write_json(out / "qualification.json", summary)

def guard(label):
    current = manifest()
    changes = {
        name: {"before": before.get(name), "after": current.get(name)}
        for name in sorted(set(before) | set(current))
        if before.get(name) != current.get(name)
    }
    guards.append({"label": label, "time": timestamp(), "unchanged": not changes})
    if changes:
        write_json(out / "source-changes.json", changes)
        write_json(out / "inputs-after.json", current)
        raise RuntimeError("Production/configuration/tool inputs changed: " + ", ".join(changes))
    return current

def run(label, argv, timeout=180):
    guard("before " + label)
    start = time.monotonic()
    started = timestamp()
    stdout_path = logs / (label + ".stdout")
    stderr_path = logs / (label + ".stderr")
    with stdout_path.open("wb") as stdout, stderr_path.open("wb") as stderr:
        try:
            result = subprocess.run(argv, cwd=engine, stdout=stdout, stderr=stderr, timeout=timeout)
            exit_code = result.returncode
            timed_out = False
        except subprocess.TimeoutExpired:
            exit_code = None
            timed_out = True
    receipt = {
        "label": label,
        "argv": argv,
        "cwd": str(engine),
        "startedAt": started,
        "finishedAt": timestamp(),
        "elapsedSeconds": round(time.monotonic() - start, 3),
        "exitCode": exit_code,
        "timedOut": timed_out,
        "stdout": str(stdout_path.relative_to(out)),
        "stderr": str(stderr_path.relative_to(out)),
    }
    commands.append(receipt)
    write_json(out / "qualification.json", summary)
    guard("after " + label)
    print(json.dumps({k: receipt[k] for k in ("label", "exitCode", "timedOut", "elapsedSeconds")}), flush=True)
    if timed_out or exit_code != 0:
        raise RuntimeError("Gate failed: " + label)
    return stdout_path.read_bytes()

try:
    dart_version = run("dart-version", ["dart", "--version"]).decode().strip()
    node_version = run("node-version", ["node", "--version"]).decode().strip()
    # Dart can print its version to stderr on some builds.
    if not dart_version:
        dart_version = (logs / "dart-version.stderr").read_text().strip()
    summary["toolchain"] = {
        "dartVersion": dart_version,
        "nodeVersion": node_version,
        "dartPath": str(pathlib.Path(shutil.which("dart")).resolve()),
        "nodePath": str(pathlib.Path(shutil.which("node")).resolve()),
    }
    package_arg = "--packages=" + str(package_config)
    receipts = {}
    for filename in smokes:
        stem = pathlib.Path(filename).stem
        target = artifacts / (stem + ".js")
        run(stem + "-compile", ["dart", "compile", "js", package_arg, "-O1", "-o", str(target), "tool/macros/" + filename])
        raw = run(stem + "-node", ["node", "-e", "globalThis.self = globalThis; require(process.argv[1]);", str(target)])
        parsed = json.loads(raw)
        if not isinstance(parsed, dict) or not parsed:
            raise RuntimeError("Smoke program did not emit its expected JSON receipt: " + filename)
        receipts[filename] = parsed
    data = fixture.read_bytes()
    define = "-DVBA_CONFORMANCE_BASE64=" + base64.b64encode(data).decode("ascii")
    vm = run("strings-vm", ["dart", package_arg, define, runner])
    target = artifacts / "web_vba_string_conformance.js"
    run("strings-compile", ["dart", "compile", "js", package_arg, "-O1", define, "-o", str(target), runner])
    javascript = run("strings-node", ["node", "-e", "globalThis.self = globalThis; require(process.argv[1]);", str(target)])
    if vm != javascript:
        raise RuntimeError("String conformance VM and JavaScript receipt bytes differ")
    string_result = json.loads(vm)
    if string_result["caseCount"] != 69:
        raise RuntimeError("Canonical string suite changed its expected case count")
    summary["stringConformance"] = {
        "caseCount": string_result["caseCount"],
        "fixtureSha256": hashlib.sha256(data).hexdigest(),
        "vmReceiptSha256": hashlib.sha256(vm).hexdigest(),
        "javascriptReceiptSha256": hashlib.sha256(javascript).hexdigest(),
        "byteIdentical": True,
    }
    summary["smokeReceipts"] = receipts
    after = guard("final")
    write_json(out / "inputs-after.json", after)
    summary["sourceInputsUnchanged"] = before == after
    summary["endingHead"] = git("rev-parse", "HEAD").decode().strip()
    summary["compiledArtifacts"] = [
        {"path": str(p.relative_to(out)), "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in sorted(artifacts.iterdir()) if p.is_file()
    ]
    write_json(out / "artifact-hashes.json", summary["compiledArtifacts"])
    summary["passed"] = True
    summary["finishedAt"] = timestamp()
    write_json(out / "qualification.json", summary)
    print(json.dumps({
        "passed": True,
        "smokePrograms": len(receipts),
        "stringCases": string_result["caseCount"],
        "matchingStringReceipts": True,
        "guardedInputs": len(before),
        "sourceInputsUnchanged": summary["sourceInputsUnchanged"],
        "startingHead": summary["startingHead"],
        "endingHead": summary["endingHead"],
    }), flush=True)
except Exception as error:
    summary["passed"] = False
    summary["error"] = str(error)
    summary["finishedAt"] = timestamp()
    try:
        write_json(out / "inputs-after.json", manifest())
    except Exception as manifest_error:
        summary["finalManifestError"] = str(manifest_error)
    write_json(out / "qualification.json", summary)
    print(json.dumps({"passed": False, "error": str(error)}), flush=True)
    sys.exit(1)
