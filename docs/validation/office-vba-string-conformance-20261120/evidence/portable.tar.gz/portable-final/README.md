# Final portable macro qualification

Use `final-source/qualification.json` as the authoritative result. At source
`6b94e195ec4871d47c4ee0ffb81bcfe6ab8d7c74`, all six existing JavaScript smoke
programs passed, and all 69 canonical string cases passed on both VM and
JavaScript with byte-identical receipts. All 945 guarded production library,
configuration, tool, support and fixture inputs remained unchanged. All 17
recorded commands exited successfully, with no timeouts.

`final-source/logs/` retains raw output, `inputs-before.json` and
`inputs-after.json` bind the source boundary, and `artifact-hashes.json` records
compiled JavaScript and related output identities. `dependency-graphs/` retains
small compiler-produced dependency lists. Compiled files remain in `artifacts/`
for local inspection; they need not be committed with the evidence.

The files at this directory's root describe an earlier, superseded attempt.
Its first whole-production guard stopped after an announced Studio UI change;
`attempt-1/` preserves that exact stop. A continuation reused successful
engine outputs after classifying that UI file outside the dependency graphs,
but then stopped on a newly reconciled Word revision guard inside every
compiler dependency graph. These source changes are preserved in the original
manifests and flags. They were not runtime assertion failures. The final-source
run restarted all requested checks on the new engine bytes and needs no source
exception. Do not combine attempt counts into an enlarged test total.

`supersession.json` identifies the authoritative run. `dependency-audit.json`
records exact before/after hashes and graph membership for the two observed
source changes. No repository source was edited and no GitHub Actions result
was queried or awaited for this gate.
