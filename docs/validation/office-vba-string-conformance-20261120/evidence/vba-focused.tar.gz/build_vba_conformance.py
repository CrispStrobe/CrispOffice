import json,pathlib
root=pathlib.Path('/workspace/scratch/f0aea33f35d2/quds_office_suite/packages/quds_office_engine')
urls={name:'https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/'+name+'-function' for name in ('len','left','right','mid')}
contract='https://github.com/CrispStrobe/quds_office_suite/blob/main/docs/VBA_MACROS.md'
utf16='https://learn.microsoft.com/en-us/openspecs/microsoft_general_purpose_programming_languages/ms-vbal/c86480b2-aef2-4488-b177-f55e13cc51f2'
cases=[]
def module(body): return 'Sub Main()\n'+body+'\nEnd Sub\n'
def op(value,cell='A1'): return {'tool':'xlsx.cellValue','arguments':{'sheet':0,'cell':cell,'value':value}}
def provenance(kind,refs,note): return {'kind':kind,'references':refs,'note':note}
def positive(id,feature,source,values,kind='spec-derived',refs=None,note='Expected values derived from the published function contract; no Office host was executed.'):
    steps=values if values and isinstance(values[0],dict) else [op(x,'A'+str(i+1)) for i,x in enumerate(values)]
    cases.append({'id':id,'feature':feature,'source':source,'expected':{'steps':steps},'provenance':provenance(kind,refs or [urls[feature.lower().rstrip('$')]],note)})
def expressions(id,feature,pairs,**kwargs):
    source=module('\n'.join('  Worksheets(1).Range("A'+str(i+1)+'").Value2 = '+e for i,(e,v) in enumerate(pairs)))
    positive(id,feature,source,[v for e,v in pairs],**kwargs)
def negative(id,feature,expression,token,code='vba_type_error',source=None,line=None,occurrence=0):
    source=source or module('  Dim result As Variant\n  result = '+expression)
    lines=source.splitlines()
    if line is None:
        line=next(i+1 for i,s in enumerate(lines) if ('  result = ' in s))
    s=lines[line-1]
    start=0
    for n in range(occurrence+1):
        offset=s.index(token,start);start=offset+len(token)
    column=len(s[:offset].encode('utf-16-le'))//2+1
    cases.append({'id':id,'feature':feature,'source':source,'expected':{'diagnostic':{'code':code,'line':line,'column':column}},'provenance':provenance('dialect-contract',[contract], 'Deliberate bounded dialect rule or diagnostic location, not a claim of complete VBA coercion or Office-host parity.')})
expressions('len-basic','Len',[('Len("")',0),('Len("Office")',6),('Len("a""b")',3)])
expressions('left-clamped-counts','Left$',[('Left$("abc",0)',''),('Left$("abc",1)','a'),('Left$("abc",3)','abc'),('Left$("abc",2147483647)','abc'),('Left$("",2147483647)','')])
expressions('right-clamped-counts','Right$',[('Right$("abc",0)',''),('Right$("abc",1)','c'),('Right$("abc",3)','abc'),('Right$("abc",2147483647)','abc'),('Right$("",2147483647)','')])
expressions('mid-one-based-optional','Mid$',[('Mid$("abc",1)','abc'),('Mid$("abc",2)','bc'),('Mid$("abc",3)','c'),('Mid$("abc",4)',''),('Mid$("abc",2147483647)',''),('Mid$("abc",2,0)',''),('Mid$("abc",2,1)','b'),('Mid$("abc",2,2147483647)','bc'),('Mid$("",1)','')])
expressions('utf16-code-units','Len',[
    ('Len("A😀B")',4),('Len("é")',2),('Mid$("A😀B",2,2)','😀'),('Left$("A😀B",3)','A😀'),('Right$("A😀B",3)','😀B'),('Len(Left$("😀",1))',1),('Len(Right$("😀",1))',1),('Len(Mid$("😀",1,1))',1),('Left$("😀",1) & Right$("😀",1)','😀')],kind='dialect-contract',refs=[contract,utf16],note='The Quds dialect explicitly indexes UTF-16 code units. This aligns with the nominal VBA String representation; it is not an Office-host observation or a claim about every implementation-defined string character set.')
expressions('utf16-lone-surrogate-native-values','Left$', [('Left$("😀",1)','\ud83d'),('Right$("😀",1)','\ude00'),('Mid$("A😀B",2,1)','\ud83d'),('Mid$("A😀B",3,1)','\ude00')],kind='dialect-contract',refs=[contract,utf16],note='UTF-16 slicing can emit individual surrogate code units. The conformance runner verifies native plan JSON round trips without treating this as workbook or Office-host qualification.')
expressions('case-insensitive-names','Left$',[('lEn(lEfT$("abcdef",3))',3),('rIgHt$(mId$("abcdef",2,4),2)','de')],kind='dialect-contract',refs=[contract])
positive('variant-and-integral-double','Left$',module('''  Dim text As Variant, count As Variant, start As Double
  text = "abcdef"
  count = 3.0
  start = 2.0
  Worksheets(1).Range("A1").Value2 = Len(text)
  Worksheets(1).Range("A2").Value2 = Left$(text,count)
  Worksheets(1).Range("A3").Value2 = Right$(text,count)
  Worksheets(1).Range("A4").Value2 = Mid$(text,start,count)'''),[6,'abc','def','bcd'],kind='dialect-contract',refs=[contract])
positive('arrays-control-flow-and-calls','Mid$', '''Option Explicit
Sub Main()
  Dim texts() As String, text As Variant, row As Long
  ReDim texts(1 To 2)
  texts(1) = "  alpha"
  texts(2) = "  beta"
  row = 1
  For Each text In texts
    If Len(text) > 2 Then
      Worksheets(1).Cells(row,1).Value2 = Tail(text)
    End If
    row = row + 1
  Next text
End Sub
Function Tail(ByVal text As String) As String
  Tail = Mid$(text,3)
End Function
''',['alpha','beta'],kind='dialect-contract',refs=[contract])
positive('argument-evaluation-once-in-order','Mid$', '''Sub Main()
  Worksheets(1).Range("A1").Value2 = Mid$(MakeText(),StartAt(),TakeCount())
End Sub
Function MakeText() As String
  Worksheets(1).Range("Z1").Value2 = "text"
  MakeText = "abcdef"
End Function
Function StartAt() As Long
  Worksheets(1).Range("Z2").Value2 = "start"
  StartAt = 2
End Function
Function TakeCount() As Long
  Worksheets(1).Range("Z3").Value2 = "length"
  TakeCount = 3
End Function
''',[op('text','Z1'),op('start','Z2'),op('length','Z3'),op('bcd')],kind='dialect-contract',refs=[contract])
positive('arguments-run-even-for-empty-result','Mid$', '''Sub Main()
  Worksheets(1).Range("A1").Value2 = Mid$("abc",2147483647,TakeCount())
End Sub
Function TakeCount() As Long
  Worksheets(1).Range("Z1").Value2 = "length evaluated"
  TakeCount = 2
End Function
''',[op('length evaluated','Z1'),op('')],kind='dialect-contract',refs=[contract])
positive('nested-argument-evaluation','Right$', '''Sub Main()
  Worksheets(1).Range("A1").Value2 = Right$(Left$(MakeText(),FirstCount()),SecondCount())
End Sub
Function MakeText() As String
  Worksheets(1).Range("Z1").Value2 = "text"
  MakeText = "abcdef"
End Function
Function FirstCount() As Long
  Worksheets(1).Range("Z2").Value2 = "first"
  FirstCount = 4
End Function
Function SecondCount() As Long
  Worksheets(1).Range("Z3").Value2 = "second"
  SecondCount = 2
End Function
''',[op('text','Z1'),op('first','Z2'),op('second','Z3'),op('cd')],kind='dialect-contract',refs=[contract])
copy_source=module('  Dim value As String, index As Long\n  value = "x"\n  For index = 1 To 14\n    value = value & value & "x"\n  Next index\n  value = Left$(value,2147483647)\n  value = Right$(value,2147483647)\n  value = Mid$(value,1)\n  Worksheets(1).Range("A1").Value2 = Len(value)')
positive('clamped-copy-budget-accepts-three-max-strings','Len',copy_source,[32767],kind='dialect-contract',refs=[contract],note='Three 32767-code-unit copies share the work budget. Requested counts are clamped before charging; Len does not copy its operand.')
negative('copy-budget-shared-across-intrinsics','Left$','', 'Left$', 'vba_limit_exceeded',source=copy_source.replace('  Worksheets(1).Range("A1").Value2 = Len(value)','  value = Left$(value,2147483647)'),line=10)
for id,feature,expr,token in [
 ('len-refuses-number','Len','Len(42)','42'),
 ('len-refuses-boolean','Len','Len(True)','True'),
 ('left-refuses-numeric-text','Left$','Left$(42,1)','42'),
 ('right-refuses-boolean-text','Right$','Right$(True,1)','True'),
 ('mid-refuses-numeric-text','Mid$','Mid$(42,1)','42'),
 ('left-refuses-string-count','Left$','Left$("abc","2")','"2"'),
 ('right-refuses-boolean-count','Right$','Right$("abc",True)','True'),
 ('left-refuses-fractional-count','Left$','Left$("abc",1.5)','1.5'),
 ('right-refuses-fractional-count','Right$','Right$("abc",0.5)','0.5'),
 ('left-refuses-negative-count','Left$','Left$("abc",-1)','-'),
 ('right-refuses-negative-count','Right$','Right$("abc",-2147483648)','-'),
 ('left-refuses-long-overflow','Left$','Left$("abc",2147483648)','2147483648'),
 ('right-refuses-long-overflow','Right$','Right$("abc",2147483648)','2147483648'),
 ('mid-refuses-zero-start','Mid$','Mid$("abc",0)','0'),
 ('mid-refuses-negative-start','Mid$','Mid$("abc",-1)','-'),
 ('mid-refuses-fractional-start','Mid$','Mid$("abc",1.5)','1.5'),
 ('mid-refuses-start-overflow','Mid$','Mid$("abc",2147483648)','2147483648'),
 ('mid-refuses-string-start','Mid$','Mid$("abc","2")','"2"'),
 ('mid-refuses-boolean-start','Mid$','Mid$("abc",True)','True'),
 ('mid-refuses-negative-length','Mid$','Mid$("abc",1,-1)','-'),
 ('mid-refuses-fractional-length','Mid$','Mid$("abc",1,0.5)','0.5'),
 ('mid-refuses-length-overflow','Mid$','Mid$("abc",1,2147483648)','2147483648'),
 ('mid-refuses-string-length','Mid$','Mid$("abc",1,"2")','"2"'),
 ('mid-refuses-boolean-length','Mid$','Mid$("abc",1,False)','False'),
 ('mid-validates-length-past-end','Mid$','Mid$("abc",2147483647,-1)','-'),
 ('utf16-diagnostic-column','Left$','Left$("😀",-1)','-'),
 ('len-requires-argument','Len','Len()','Len'),
 ('len-refuses-extra-argument','Len','Len("abc",1)','Len'),
 ('left-requires-count','Left$','Left$("abc")','Left$'),
 ('left-refuses-third-argument','Left$','Left$("abc",1,2)','Left$'),
 ('right-requires-count','Right$','Right$("abc")','Right$'),
 ('right-refuses-third-argument','Right$','Right$("abc",1,2)','Right$'),
 ('mid-requires-start','Mid$','Mid$("abc")','Mid$'),
 ('mid-refuses-fourth-argument','Mid$','Mid$("abc",1,2,3)','Mid$'),
]: negative(id,feature,expr,token)
for name in ('Left','Right','Mid'):
    negative('refuses-unsuffixed-'+name.lower(),name+'$',name+'("abc",1)',name,'vba_unsupported')
for name in ('Len','Other'):
    negative('refuses-unapproved-suffix-'+name.lower(),name,name+'$("abc")','$','vba_unsupported')
negative('rejects-wrong-type-in-inactive-branch','Len','', '42', source=module('  If False Then\n    result = Len(42)\n  End If'),line=3)
negative('refuses-variant-number-as-text','Len','Len(value)','value', source=module('  Dim result As Variant, value As Variant\n  value = 42\n  result = Len(value)'),line=4)
negative('refuses-variant-string-as-count','Left$','Left$("abc",value)','value',source=module('  Dim result As Variant, value As Variant\n  value = "2"\n  result = Left$("abc",value)'),line=4)
negative('refuses-uninitialized-variant','Len','Len(value)','value','vba_unsupported',source=module('  Dim result As Variant, value As Variant\n  result = Len(value)'),line=3)
negative('refuses-intrinsic-in-const','Len','', 'Len','vba_unsupported',source=module('  Const size As Long = Len("abc")'),line=2)
negative('refuses-null-state','Left$','Left$(Null,1)','Null','vba_unsupported')
negative('refuses-empty-state','Len','Len(Empty)','Empty','vba_unsupported')
corpus={'schemaVersion':1,'suite':'vba-string-intrinsics','dialect':'vba-excel','cases':cases}
out=root/'test/fixtures/vba_conformance/string_intrinsics_v1.json'
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(corpus,ensure_ascii=True,indent=2)+'\n')
print(json.dumps({'cases':len(cases),'bytes':out.stat().st_size,'positive':sum('steps' in x['expected'] for x in cases),'negative':sum('diagnostic' in x['expected'] for x in cases)}))
