import 'dart:convert';
import 'package:quds_office_engine/quds_office_automation.dart';
import 'package:quds_office_engine/quds_office_engine.dart';
Future<void> main() async {
  final plan = OfficeMacroLanguages().compile(OfficeMacroSource(language:'vba-excel',format:OfficeMacroFormat.xlsx,source:r'''Sub Main()
  Worksheets(1).Range("A1").Value2 = Left$("😀", 1)
End Sub'''));
  final b = XlsxWorkbookBuilder(); b.addSheet('Summary');
  final s = OfficeMacroSession(b.build(), format:OfficeMacroFormat.xlsx);
  try {
    await s.run(plan);
    final actual = SheetDeserializer().readBytes(s.bytes).sheets.single.cellA1('A1').value as String;
    print(jsonEncode({'plan':(plan.steps.single.arguments['value'] as String).codeUnits,'workbook':actual.codeUnits}));
  } catch (e) { print('failure: $e'); }
}
