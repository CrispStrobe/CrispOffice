# Independent VBA compiler review

20 November 2026. Result: **no unresolved correctness defect found in the
reviewed string-intrinsic increment or its UTF-16 emission boundary**.

Reviewed the complete compiler delta from starting main
`a452efdadc9000c51a8e5e9ba2f16405d4979e2e`, and independently inspected the
Unicode-boundary delta after checkpoint
`ee5d0da58e898dbb00ff49398f91dd8284fc6799`.

Reviewed file: `packages/quds_office_engine/lib/src/automation/office_vba_language.dart`

- Git blob: `961aefdb604e8f5db36deb69aa7b731e7b947710`.
- SHA-256: `a220206dd7fe42e60a0b0f0be6a4e8adfc19571e095f7bd75b11c8683056a914`.

## Findings

1. **Names, types and scope.** The lexer admits a dollar suffix only on the
   three implemented string-returning intrinsic names. The checker reserves
   all four intrinsic identifiers against declaration/shadowing. It checks
   arity before indexing arguments, checks every argument's static kind, and
   visits inactive source through the existing checker. Variant payloads
   receive the same strict runtime String/numeric checks. This does not add
   scalar coercions, general type suffixes, constant-expression calls, or
   implicit support for the unsuffixed built-ins.

2. **Evaluation and bounds.** Argument expressions are evaluated once in source
   order before the intrinsic implementation validates their resulting values.
   An explicit Mid length is validated even when the start is beyond the input.
   Numeric indices must be finite exact integers in the allowed signed-Long
   domain; Boolean and numeric-string coercions are refused. The computed
   offsets and clamped counts remain exact on VM and JavaScript, including
   maximum-Long requests. Zero-length results avoid substring allocation.

3. **Work accounting.** Each actual copied UTF-16 unit is charged before
   substring creation, including full-input and nested slices. Large requested
   lengths are clamped before charging. Empty-result calls still consume the
   evaluator's ordinary visit budget; they cannot reset it. Len requires no
   linear copy. Existing source, string, call, operation and encoded-plan bounds
   remain in place.

4. **Publication boundary.** Every `steps.add` path in this compiler passes
   through `_emitRange`. Its guard checks the worksheet selector and every
   String-valued operation field once before range expansion. It rejects lone
   low surrogates, trailing highs, and highs followed by non-lows; it skips
   valid pairs correctly and does not normalize text. This covers values,
   formulas, formatting and ClearContents selectors. Internal halves remain
   usable for length calculations and recombination. Guard scanning is bounded
   by the existing per-string and encoded-output limits; it is not repeated per
   expanded cell. A failure prevents the compiler from returning its native
   plan, including when earlier source statements had accumulated steps.

5. **Error locations and order.** Property writes retain their member token.
   ClearContents retains its existing statement-start token. Existing range
   limits and property-specific checks remain before the emission guard; this
   preserves their error ordering. Corpus expectations record the ClearContents
   exception explicitly.

## Independent evidence

The revised canonical corpus passed 69 cases on both the Dart VM and compiled
JavaScript, with byte-identical JSON receipts. Its native suite passed 113
tests, including malformed-fixture validation. Strict scoped analysis passed.
Every successful case verifies the entire native-plan encode/parse round trip.

- Corpus SHA-256: `a1f82c1931e78212fe9beddb47e5fcca098ffa09c133e91ab8d3819d268f9151`.
- Matching receipt SHA-256: `a873a66a08bd5632adaea09491476b48ae1dc71a7274c57101af71a6153357c4`.
- Evidence prefix: `vba-conformance-utf16-boundary-` in the scratch workspace.

The earlier 62-case candidate is retained separately. It verified native JSON
preservation but did not establish lossless workbook publication. Its emitted
surrogate-success case has been superseded by positioned refusal cases. This
review does not claim actual Microsoft Office execution or replace the parent's
separate XLSX transaction/publication integration checks.
