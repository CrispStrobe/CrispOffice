# Main refresh review: guarded empty Word formatting revisions

Reviewed 20 November 2026 at 04:27 UTC. Scope: `33370cbfc290389cc663913a9efcfa5f71e112b0..b5b32d247cd9ba9803b35175db8d60c8deeeac47`. This was read-only source and ancestry review; no tests or GitHub CI endpoints were queried by this reviewer.

## Result

**No source-review blocker. The incoming change is additive and has been preserved exactly in merge `0c0d6ff72e90c9de7fe5c565b7ad8e7f5195a94a`.** Its first parent is the qualified connector checkpoint `478f3966139f20c0d1cc20a4c2835a4759c726e0`; its second parent is incoming main `b5b32d24`. Incoming paths do not overlap the first parent's work since `33370cbf`. Every one of the seven incoming paths has the identical Git blob in the merge and incoming main.

The incoming range contains:

- `930074b87b2b26d2430eaad13a015ba52ae8f726`: guard and one focused regression.
- `b5b32d247cd9ba9803b35175db8d60c8deeeac47`: final qualification records.

Only `packages/quds_office_engine/lib/src/word/model/word_revision.dart` changes production behavior. `test/word_extended_revision_test.dart` gains one case; five paths under `docs/validation/docx-review-extension-20261120` update or preserve qualification evidence. There are no dependency, workflow, native macro runtime, operation-catalog or VBA compiler changes in this incoming range.

## Guard behavior and preservation

For a zero-width pending run-format revision, `WordRevisions.validateRevision` now requires exactly one empty `WmlRun` at the recorded text offset. Zero matching runs means the target was removed; multiple matching runs means attribution is ambiguous. The offset scan sums the same `WmlRun.text` strings as `WmlParagraph.text`, so non-text inline objects do not introduce a mismatched coordinate system.

The overlap check also refuses two zero-width run-format revisions at the same offset. Existing checks restrict this comparison to the same target paragraph and the same formatting revision kind. Nonempty formatting, paragraph formatting, text revisions and moves keep their existing validation path.

The new checks execute before range normalization or resolution mutation. `WordSerializer.write` calls `WordRevisions.validate` before writing native package parts. Valid single empty formatting runs remain supported by the existing adjacent regression. The new test verifies that an ambiguous duplicate cannot save and that removing the only target does not silently discard revision history.

This intentionally refuses an ambiguous save instead of guessing which empty run owns the history. It does not change the source package, strip the revisions, or resolve them automatically.

## Exact focused local qualification after the merge

Run from `packages/quds_office_engine` after sourcing the established runtime environment. The repository's direct test executable is `test-1.31.1`:

```sh
source /workspace/scratch/f0aea33f35d2/runtime/env.sh

dart --packages=../../.dart_tool/package_config.json \
  /workspace/scratch/f0aea33f35d2/runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart \
  test/word_extended_revision_test.dart test/word_revision_validation_test.dart \
  --reporter expanded

dart --packages=../../.dart_tool/package_config.json \
  /workspace/scratch/f0aea33f35d2/runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart \
  test/office_macro_runtime_test.dart \
  --plain-name 'asset callback failure rolls back preceding document edits' \
  --reporter expanded

dart --packages=../../.dart_tool/package_config.json \
  /workspace/scratch/f0aea33f35d2/runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart \
  test/office_operations_test.dart \
  --plain-name 'model protections and tracked changes deny macro editing' \
  --reporter expanded

dart analyze --fatal-infos --fatal-warnings \
  lib/src/word/model/word_revision.dart test/word_extended_revision_test.dart
```

`word_extended_revision_test.dart` contains 23 cases after the merge, including valid/invalid empty runs, native roundtrips, direct/isolate saves, move atomicity and formatting/text interactions. `word_revision_validation_test.dart` checks shared validator atomicity, stale-range refusal before direct/isolate package mutation and batch preflight. The selected native macro case is a real DOCX transaction rollback; the operation-catalog case keeps the existing protected/change-tracked document admission boundary covered.

### One useful new save-time native macro boundary case

The existing DOCX rollback case fails during an operation, whereas this new guard fails at final serialization. No existing `OfficeMacroSession` test directly contains `rPrChange` or a pending formatting revision. Add or run a tiny focused probe with this contract:

1. Build raw DOCX package bytes containing a paragraph with two empty runs, each with `w:rPrChange`, plus a second ordinary paragraph. Use `OpcPackage.save` for the source so the intentionally ambiguous original is not rejected during fixture construction. Do not enable `w:trackRevisions`; this tests pending imported history, not the unrelated tracking-enabled admission refusal.
2. Open `OfficeMacroSession(format: docx)`, start recording, and apply `docx.heading` to the second paragraph. The detached edit can execute, but final save must return `OfficeMacroException(code: document_error)`.
3. Assert byte-for-byte original session bytes, unchanged session revision and an empty recording. Check `validate` against the same plan also refuses without publication. A whole-plan `run` refusal may be checked in the same probe.
4. Use a companion source with exactly one empty formatting run; the unrelated heading edit should publish normally and preserve that formatting revision on reopen.

This is the direct integration check for the new failure path. The runtime code already supports it: `OfficeMacroSession._execute` saves the detached model before assigning output bytes, advancing the session revision or appending a recorded step, and wraps a save-time exception as `document_error`.

No full macro-suite replay or CLI process matrix is needed solely for this two-predicate Word guard once the focused boundary is checked.

## VBA byte binding

The incoming compiler blob is unchanged between `33370cbf` and `b5b32d24`: `c42ffec4d0f67aecb576a30a5680c7f30117880c`. The new implementation stays at Git blob `961aefdb604e8f5db36deb69aa7b731e7b947710` in both earlier integration `403fec5f` and the merged head `0c0d6ff7`. Its working file equals that committed blob and has SHA-256 `a220206dd7fe42e60a0b0f0be6a4e8adfc19571e095f7bd75b11c8683056a914`.

The preserved incoming documentation describes its own Word/macOS qualification. Those historical host runs were not repeated in this review and should remain attributed to their existing evidence. Draft mail PR #221 and other active feature heads are outside this refresh scope and were not audited or merged by this reviewer.

## Completed focused qualification — 20 November 2026, 04:32 UTC

The requested new test is implemented in `packages/quds_office_engine/test/office_macro_word_revision_guard_test.dart`. It exercises the actual save-time refusal through `OfficeMacroSession.run`, `.validate` and recorded `.callTool`, plus successful detached validation and publication with a single valid empty formatting run. Its SHA-256 is `ca6e36618c597818637f9d1d852387361abff9a6659326424a3089350ec19af8`.

The final focused run passed **34 cases with no failures or skips**: 32 across the new test and both Word revision files, plus the two exact existing native boundary cases named above. Strict scoped analysis and formatting passed. All 6,225 captured inputs remained identical throughout. Exact commands, raw outputs, complete case names and input hashes are in `word-final/` beside this report, bound to source `6b94e195ec4871d47c4ee0ffb81bcfe6ab8d7c74`.

The initial minimal OPC fixture lacked a settings part. Revision import left its model tracking flag enabled, so the earlier admission protection fired instead of the intended save guard; 30 existing cases passed and the two new fixture assumptions failed. That attempt is preserved unchanged under `word-final/attempt-01-unreachable-save-guard/`. The corrected fixture starts from the application's ordinary `DocxDocumentBuilder` native package and replaces only document XML. Its normal authored settings make the intended guard reachable without any model-flag override or protection change. The single valid empty-run companion also succeeds through the same unchanged admission path.

No production source or existing selected macro test was edited for this qualification. The new test file is frozen for root's workflow addition, whole-engine analysis and remote checkpoint.
