# Word main-refresh and native macro qualification

Completed 20 November 2026 on source head `6b94e195ec4871d47c4ee0ffb81bcfe6ab8d7c74`, which preserves incoming main's empty-formatting-run guard. Only the new repository test `test/office_macro_word_revision_guard_test.dart` was added by this reviewer; no production source or existing selected test was changed.

## Accepted results

| Selection | Passed | Failed | Skipped |
| --- | ---: | ---: | ---: |
| New macro guard test, extended Word revisions, shared revision validation | 32 | 0 | 0 |
| Existing DOCX asset-failure rollback case | 1 | 0 | 0 |
| Existing model-protection and tracked-document admission case | 1 | 0 | 0 |
| Total for this focused final qualification | **34** | **0** | **0** |

Strict analysis of the new test, changed Word validator and the two selected Word revision files passed. Formatting the new test in check-only mode found no changes. All **6,225 captured inputs** are unchanged between the start and end of the accepted qualification. These selected tests overlap other task gates; this count must not be added to their totals without deduplication.

The new test source is frozen at SHA-256 `ca6e36618c597818637f9d1d852387361abff9a6659326424a3089350ec19af8`; its exact accepted contents are also preserved in `accepted-test-source.dart.txt`.

## What the new tests establish

The fixture starts from an ordinary `DocxDocumentBuilder` package, including its native settings part, and replaces only the document XML with synthetic revision content. It does not modify a protection setting or override the model's tracking flag. A source with two empty formatting revisions is admitted with its authored tracking-disabled setting, but fails at final serialization with the exact ambiguity diagnostic. The test exercises `run`, `validate`, and recorded `callTool`; each returns `document_error` with no active step/tool and leaves the original bytes, session revision and recording intact.

The companion source contains exactly one empty formatting revision. Detached validation preserves the session, a recorded heading edit succeeds, and reimport retains the empty run's pending history and current formatting. The recording contains exactly the one successful tool call.

## Preserved initial fixture correction

`attempt-01-unreachable-save-guard/` contains the original attempt, raw outputs and original test source. That minimal OPC fixture omitted the native settings part. Importing revision records consequently left `trackRevisions=true`, and existing macro admission blocked the test before serialization. The 30 existing revision cases passed; the two new fixture assumptions failed. Source inspection identified the omitted normal package structure, and the fixture was corrected using the application's standard builder. No protection was bypassed. The accepted 34-case run above completed cleanly on the corrected, frozen test source.

## Evidence and exact execution

- `commands.json`: exact argument arrays, working directory, source-head binding and Dart runtime version.
- `run_qualification.py`: reproducible runner; it refuses to overwrite an existing attempt.
- `*.stdout.log` / `*.stderr.log`: original JSON test events, analyzer output and formatter output.
- `inputs-before.json` / `inputs-after.json`: SHA-256 input inventories covering every configured package's `lib`/`bin` Dart source and manifest, selected tests, Word XML fixtures, package configuration, root/engine manifests, Dart executable, runtime environment and runner.
- `summary.json`: all individual accepted test names, outcomes, durations and the empty changed-input list.

The outer invocation was:

```sh
source /workspace/scratch/f0aea33f35d2/runtime/env.sh
python3 /workspace/scratch/f0aea33f35d2/word-final/run_qualification.py
```

No GitHub CI endpoints were queried or awaited, and no Git or remote mutation was performed by this reviewer.
