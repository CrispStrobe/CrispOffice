# Preserved initial boundary-probe attempt

The two new tests initially used `OpcPackage.create` with no native settings part and assumed that pending imported formatting history would leave `trackRevisions` false. Actual import records revisions and sets that model flag true when no settings part subsequently supplies its authored state. Existing macro admission therefore refused both minimal fixtures before serialization: the 30 existing Word revision cases passed and the two new fixture assumptions failed.

Further source inspection established that the application's ordinary DOCX package includes a settings part. The final fixture starts with `DocxDocumentBuilder` output and replaces only the document XML with synthetic pending-history paragraphs; it never overrides a protection setting or model flag. That legitimate native source reaches the save-time guard, and the valid-single-run companion also succeeds.

No production code changed and no protection was bypassed. All original commands, raw logs, 6,225 input hashes before/after, and the initial test source remain unchanged here. The final qualification and corrected test input are in the parent directory.
