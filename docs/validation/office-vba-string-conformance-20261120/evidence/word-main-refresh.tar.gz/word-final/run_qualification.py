import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from urllib.parse import unquote, urljoin, urlparse

OUT = Path(__file__).resolve().parent
REPO = OUT.parent / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
CONFIG = REPO / '.dart_tool/package_config.json'
DART = str(Path(shutil.which('dart')).resolve())
TEST = OUT.parent / 'runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
SELECTED = [
    ENGINE / 'test/office_macro_word_revision_guard_test.dart',
    ENGINE / 'test/word_extended_revision_test.dart',
    ENGINE / 'test/word_revision_validation_test.dart',
    ENGINE / 'test/office_macro_runtime_test.dart',
    ENGINE / 'test/office_operations_test.dart',
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs():
    paths = {CONFIG, Path(DART), TEST, *SELECTED}
    paths.add(OUT.parent / 'runtime/env.sh')
    paths.add(Path(__file__).resolve())
    for filename in ['pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml']:
        for parent in [REPO, ENGINE]:
            p = parent / filename
            if p.is_file():
                paths.add(p)
    paths.update((ENGINE / 'test/fixtures/word_reviews').glob('*.xml'))
    config = json.loads(CONFIG.read_text())
    roots = []
    for package in config['packages']:
        uri = urljoin(CONFIG.as_uri(), package['rootUri'])
        parsed = urlparse(uri)
        if parsed.scheme != 'file':
            raise RuntimeError(f'Unexpected package source URI scheme: {parsed.scheme}')
        root = Path(unquote(parsed.path))
        roots.append({'name': package['name'], 'root': str(root)})
        for subdir in ['lib', 'bin']:
            tree = root / subdir
            if tree.is_dir():
                paths.update(p for p in tree.rglob('*.dart') if p.is_file())
        manifest = root / 'pubspec.yaml'
        if manifest.is_file():
            paths.add(manifest)
    return {
        'capturedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'sourceScope': 'Every package_config package lib/bin Dart source and pubspec; selected tests; Word review XML fixtures; package config; root/engine manifests and analyzer options; Dart executable; runtime env; runner.',
        'packageRoots': roots,
        'sha256': {str(p.resolve()): digest(p) for p in sorted(paths)},
    }


base = [DART, '--packages=' + str(CONFIG), str(TEST)]
commands = [
    ('revision-and-macro-guard', base + [str(p.relative_to(ENGINE)) for p in SELECTED[:3]] + ['--reporter', 'json']),
    ('docx-macro-rollback', base + ['test/office_macro_runtime_test.dart', '--plain-name', 'asset callback failure rolls back preceding document edits', '--reporter', 'json']),
    ('native-model-protection', base + ['test/office_operations_test.dart', '--plain-name', 'model protections and tracked changes deny macro editing', '--reporter', 'json']),
    ('analysis', [DART, 'analyze', '--fatal-infos', '--fatal-warnings', 'lib/src/word/model/word_revision.dart', 'test/word_extended_revision_test.dart', 'test/word_revision_validation_test.dart', 'test/office_macro_word_revision_guard_test.dart']),
    ('format', [DART, 'format', '--output=none', '--set-exit-if-changed', 'test/office_macro_word_revision_guard_test.dart']),
]
if (OUT / 'summary.json').exists() or (OUT / 'inputs-before.json').exists():
    raise RuntimeError('Refusing to overwrite an existing qualification attempt.')
before = inputs()
(OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
binding = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    'runtime': subprocess.check_output([DART, '--version'], cwd=ENGINE, text=True, stderr=subprocess.STDOUT).strip(),
    'cwd': str(ENGINE),
    'githubActionsQueriedOrAwaited': False,
}
(OUT / 'commands.json').write_text(json.dumps({'binding': binding, 'commands': [{'id': name, 'argv': argv} for name, argv in commands]}, indent=2) + '\n')
results = []
for name, argv in commands:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    watch = time.monotonic()
    with (OUT / (name + '.stdout.log')).open('wb') as stdout, (OUT / (name + '.stderr.log')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=ENGINE, stdout=stdout, stderr=stderr)
    row = {'id': name, 'startedAt': started, 'durationSeconds': time.monotonic() - watch, 'exitCode': result.returncode}
    if '--reporter' in argv:
        events = [json.loads(line) for line in (OUT / (name + '.stdout.log')).read_text().splitlines() if line.startswith('{')]
        tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
        done = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden', False)]
        row['cases'] = [{'name': tests[e['testID']]['name'], 'result': e['result'], 'skipped': e['skipped']} for e in done]
        row['passed'] = sum(e['result'] == 'success' and not e['skipped'] for e in done)
        row['failed'] = sum(e['result'] != 'success' for e in done)
        row['skipped'] = sum(e['skipped'] for e in done)
    results.append(row)
    print(json.dumps({k: v for k, v in row.items() if k != 'cases'}), flush=True)
    if result.returncode:
        break
after = inputs()
(OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
changed = sorted(p for p in set(before['sha256']) | set(after['sha256']) if before['sha256'].get(p) != after['sha256'].get(p))
summary = {'binding': binding, 'results': results, 'inputCount': len(before['sha256']), 'changedInputs': changed, 'allCommandsRun': len(results) == len(commands), 'accepted': len(results) == len(commands) and not changed and all(r['exitCode'] == 0 for r in results)}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'accepted': summary['accepted'], 'changedInputs': changed, 'inputCount': summary['inputCount']}), flush=True)
sys.exit(0 if summary['accepted'] else 1)
