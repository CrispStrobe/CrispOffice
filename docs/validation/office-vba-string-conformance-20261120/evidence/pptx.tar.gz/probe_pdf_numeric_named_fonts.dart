import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import '/workspace/scratch/f0aea33f35d2/quds_office_suite/packages/quds_office_engine/test/support/pdf_alias_fixture.dart';

void main() {
  final sans = aliasTestFont('LiberationSans-Regular');
  final mono = aliasTestFont('LiberationMono-Regular');
  final fonts = OfficeFontSet(
    defaultFamily: 'Liberation Sans',
    faces: [
      OfficeFontFace(font: sans, family: 'Liberation Sans'),
      OfficeFontFace(font: mono, family: 'Liberation Mono'),
    ],
  );
  const source = '12 34 56 78 90 12';
  var accepted = 0;
  for (final (family, font, expectedLines) in [
    ('Liberation Sans', sans, ['12 34 56', '78 90 12']),
    ('Liberation Mono', mono, ['12 34', '56 78', '90 12']),
  ]) {
    for (final align in [PmlTextAlign.center, PmlTextAlign.right]) {
      final shape = PmlShape(
        id: 2,
        name: 'numeric named-face probe',
        text: source,
        fillColor: '',
        fontSizePt: 20,
        rightToLeft: false,
        textAnchor: PmlTextAnchor.center,
        transform: const PmlTransform(
          x: 20 * 12700,
          y: 30 * 12700,
          cx: 100 * 12700,
          cy: 150 * 12700,
        ),
        richText: [
          PmlTextParagraph(
            rightToLeft: false,
            align: align,
            runs: [PmlTextRun(text: source, fontSizePt: 20, fontFamily: family)],
          ),
        ],
      );
      final file = PdfFile.open(OfficePdfExport.presentation(
        PmlPresentation(slides: [PmlSlide(id: 256, shapes: [shape])]),
        fonts: fonts,
      ));
      final lines = <double, List<PdfDrawText>>{};
      for (final op in file.displayList(0).ops.whereType<PdfDrawText>()) {
        lines.putIfAbsent(op.y, () => []).add(op);
      }
      final painted = lines.values
          .map((line) => line.map((op) => op.text).join())
          .toList();
      final extracted = PdfExtract.pageText(file, 0);
      if (jsonEncode(painted) != jsonEncode(expectedLines)) {
        throw StateError('$family $align painted $painted, expected $expectedLines');
      }
      if (extracted.replaceAll('\n', '') != source ||
          extracted.contains('\u202d')) {
        throw StateError('$family $align bad extraction ${jsonEncode(extracted)}');
      }
      var lineIndex = 0;
      for (final line in lines.values) {
        final text = expectedLines[lineIndex];
        final measured = text.runes.fold<double>(
          0,
          (sum, cp) => sum + font.advanceWidth(font.glyphIdFor(cp)) / font.unitsPerEm * 20,
        );
        final slack = 100 - 14.4 - measured;
        final expectedX = 20 + 7.2 + (align == PmlTextAlign.center ? slack / 2 : slack);
        final expectedY = 30 + (150 - expectedLines.length * 25) / 2 + lineIndex * 25;
        if ((line.first.x - expectedX).abs() > 0.02 ||
            (line.first.y - expectedY).abs() > 0.02) {
          throw StateError('$family $align line $lineIndex position '
              '${line.first.x},${line.first.y}; expected $expectedX,$expectedY');
        }
        lineIndex++;
      }
      print(jsonEncode({
        'family': family,
        'alignment': align.name,
        'source': source,
        'painted': painted,
        'positions': lines.values.map((line) => [line.first.x, line.first.y]).toList(),
        'extracted': extracted,
        'generatedOverrideAbsent': !extracted.contains('\u202d'),
        'accepted': true,
      }));
      accepted++;
    }
  }
  print(jsonEncode({'acceptedCases': accepted}));
}
