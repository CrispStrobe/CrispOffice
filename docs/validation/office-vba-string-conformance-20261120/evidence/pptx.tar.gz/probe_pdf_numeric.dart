import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import '/workspace/scratch/f0aea33f35d2/quds_office_suite/packages/quds_office_engine/test/support/pdf_alias_fixture.dart';
void main() {
  for (final (text, width) in <(String, double)>[
    ('12-34/56\n78-90/12', 300),
    ('12 34\n56 78', 300),
    ('12/34 56/78 90/12', 90),
  ]) {
    final shape = PmlShape(id: 2, name: 'probe', text: text, fillColor: '', fontSizePt: 20, rightToLeft: false,
      transform: PmlTransform(x:20*12700,y:30*12700,cx:(width*12700).round(),cy:100*12700),
      richText: [PmlTextParagraph(rightToLeft:false,runs:[PmlTextRun(text:text,fontSizePt:20)])]);
    final file = PdfFile.open(OfficePdfExport.presentation(PmlPresentation(slides:[PmlSlide(id:256, shapes:[shape])]),font:aliasTestFont()));
    final lines=<double,String>{};
    for(final op in file.displayList(0).ops.whereType<PdfDrawText>()) { lines[op.y]=(lines[op.y]??'')+op.text; }
    print(jsonEncode({'source':text,'width':width,'painted':lines.values.toList()}));
  }
}
