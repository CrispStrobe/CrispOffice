# Incoming PPTX source review — 20 November 2026

Reviewed read-only against remote main `a452efdadc9000c51a8e5e9ba2f16405d4979e2e` and incoming head `f007b245` (`integrate/recent-pptx`). Four commits after already-integrated `a5ae56c8` add master/layout decorations, DejaVu fallback, block-arrow geometry/heading fitting, and numeric-only authored LTR rendering. No GitHub Actions/check/status endpoints were queried. This is source review, not test execution.

## Acceptance decision

Preserve all four commits in ancestry, but fix the concrete regressions below before accepting the combined source. Existing main corrections to rich-text font defaults, scalar edits, explicit/inherited/secondary-master backgrounds, and dark-slide color behavior must survive reconciliation. Do not replace conflicting files wholesale from the incoming branch.

## Findings requiring fixes

1. **Arrow outlines disappear in PDF.** The new cases in `OfficePdfExport._strokePreset` all `break` without constructing/stroking the arrow path. An unfilled arrow with a visible stroke vanishes; a filled arrow loses its outline. Reuse the arrow path for stroke as for fill. Test all four presets with empty fill and a colored nonzero stroke, checking actual PDF path/stroke operators rather than only enum parsing.

2. **Unstyled mixed runs are scaled twice.** `_drawSlideRichText` computes paragraph `size` with `fitScale`, passes that size as `_paintStyledParagraph`'s fallback, and `_paintStyledParagraph` then computes `(run.fontSizePt > 0 ? run.fontSizePt : fallbackSize) * sizeScale`. Explicit-size runs scale once; fallback runs scale twice. Preserve an unscaled inherited size or only scale explicit run sizes in the callee. Test a short, narrow single-paragraph shape with mixed explicit/default-size runs and colors, asserting consistent resulting font sizes. Main's paragraph-default and scalar-edit fixes must remain effective.

3. **Numeric multiline content loses line breaks and wrapping.** The new numeric-only predicate accepts any non-RTL string containing no Unicode letters, including `12\n34`. `drawPlainLtr` skips all code points below 32, so the line break disappears; it also does not wrap at `maxWidth`, yet vertical premeasurement still may count wrapped lines. Either use the shortcut only for a single line whose measured width fits, or implement line-aware wrapping with consistent height/alignment. Test explicit breaks, narrow wrapping, single-line order, and RTL numeric paragraphs separately.

4. **Decoration IDs collide with slide animation IDs.** The background paint loop applies `samples?[shape.id]` and `skipIds.contains(shape.id)` to master/layout objects. IDs are scoped to their source parts and routinely overlap foreground IDs. A foreground entrance/exit animation or morph can therefore hide, translate, rotate, or skip unrelated decorations. Paint decorations independently of slide-local samples and skip IDs. Add a widget regression using a decoration and foreground shape with the same ID, with an invisible/translated foreground sample.

5. **Decoration rotation is omitted.** The new background loop calls `_paintShapeInRect`, which does not rotate. Foreground painting calls `_rotateCanvas` before drawing; morph also rotates before `_paintShapeInRect`. Add the same rotation handling to decorations and test a non-square rotated rectangle/picture against its expected raster bounds.

6. **Dark-mode backing inference ignores decorations.** `_solidTextBackground` traverses only `target.shapes`. With newly painted white or mixed background decorations, it still assumes dark slide paper and may brighten black text on a white decoration into unreadable light ink. Traverse background decorations followed by earlier foreground shapes, without applying foreground animation IDs to decoration objects. Treat nonrectangular, rotated, image, and mixed backing conservatively. Keep all original `office_dark_slide_test.dart` assertions unchanged and add a white-decoration case.

7. **Authored master-shape suppression is ignored.** Import unconditionally copies master/layout decorations. `p:sld/@showMasterSp="0"` and `p:sldLayout/@showMasterSp="0"` should suppress the corresponding master decoration inheritance instead of newly showing content that Office hides. No current importer handles this attribute. Add minimal import fixtures with each false/zero attribute and the default/true case, preserving editable slide shapes and appropriate layout decorations. Confirm exact OOXML semantics when implementing.

## Focused existing gates

- Engine: `test/slide_import_fidelity_test.dart`, `test/slide_render_fidelity_test.dart`, `test/office_pdf_export_test.dart`, `test/slide_text_fidelity_test.dart`, `test/slide_rich_text_explicit_style_test.dart`, `test/slide_test.dart`.
- Editor: `test/office_dark_slide_test.dart`, `test/slide_render_fidelity_test.dart`; selected presentation animation/morph tests for ID isolation.
- Strict analysis of affected engine/editor libraries, formatting, and whitespace checks.
- Engine/native macro presentation boundaries if model construction/copy/serialization changes.

No additional exhaustive-switch sites requiring new enum cases were found outside the edited DrawingML/PDF/editor shape paths. `PmlSlide.copy()` must retain deep copies of `backgroundShapes` together with current main's background ownership metadata. Original package master/layout parts remain the serialization source for imported decorations; do not duplicate them into slide-owned editable content.
