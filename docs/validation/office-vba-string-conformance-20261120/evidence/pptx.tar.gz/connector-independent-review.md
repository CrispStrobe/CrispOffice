# Independent review of connector preservation

Reviewed on 20 November 2026 against integration base `403fec5f8b73752890a36579264ab010e6b12bc1`, including the working-tree changes in the eight assigned production files. The audit also searched production Dart constructors and equality checks across `packages`, including the Studio example application. Exact source hashes and observation time are in `connector-independent-review-sources.json` beside this report.

This was a read-only review. No production files were edited, no tests were repeated, and no GitHub CI endpoints were queried. The implementation owner is running the relevant regression gates separately.

## Initial finding: two Studio paths still lose connector state

### 1. Studio alignment drops the flip flags

`packages/quds_office_editor/example/lib/suite_workspace.dart`, `_alignSelectedShape`, constructs `PmlTransform(x: nextX, y: nextY, cx: t.cx, cy: t.cy, rot: t.rot)` without copying `t.flipH` or `t.flipV`. The default values are false, so Center and slide-edge alignment change the slope of a connector that has exactly one flip. The library controller cannot recover this information because the caller supplies the replacement transform.

Carry both flip flags from the source transform. Root and the implementation owner were notified immediately.

### 2. Studio Duplicate slide drops the connector stroke

The same file's `_duplicateSlide` manually reconstructs every `PmlShape` without `strokeColor` or `strokeWidth`. A connector imported with empty fill and an authored stroke therefore becomes invisible when its slide is duplicated. The transform reference preserves the flags, but the only paint is lost. The manual `PmlSlide` construction also omits `showMasterShapes` and the resolved decoration list.

Use the existing `src.copy(id: _nextSlideId())` model method. Its shape copies preserve strokes and the immutable transform, its slide copy preserves decorations and the master-shape flag, and its new-ID path clears the source-part URI. This avoids another manually maintained field list. Root and the implementation owner were notified.

## Eight-file source review

| Area | Assessment |
| --- | --- |
| DrawingML import and write | `flipH`/`flipV` accept trimmed XML `1` and `true`; absent, `0` and `false` remain false. Offset/extent reconstruction carries both values. Shape XML writes true values as `1`, while false uses the normal omitted/default representation. |
| Engine arrangement | All six alignment branches and distribution retain the original flags alongside rotation and dimensions. |
| Native `shapeGeometry` | Replacement geometry preserves both flags while changing requested position, size and rotation. Detached native save uses the corrected serializer. |
| Model copy | `PmlShape.copy` retains the immutable `PmlTransform` and the stroke. Sharing that immutable transform is safe. `PmlSlide.copy` recursively uses these copies. |
| Morph | Equal flips remain constant. Different flips switch at the same midpoint convention as other discrete properties. The sampled frame transform is now passed into the connector renderer, rather than reading the target shape's flags throughout the transition. |
| Editor geometry and equality | Drag/resize, single/group rotation, nudge and grouped-controller edits retain both flags. Transform equality and arrangement-change detection include them. Existing undo commands retain complete before/after transform objects. |
| Clipboard | The clone carries the flags, offset geometry, stroke color and stroke width. |
| Editor paint | A connector chooses authored stroke color if present, otherwise its legacy fill fallback. Endpoints apply independent horizontal and vertical flips within the authored rectangle. The fallback width remains 1.6 pt. The connector branch returns after drawing once. |
| PDF paint | A connector with an authored stroke skips the fill path, preventing the former wider underlay. A fill-only connector takes the fallback path once. Both paths use the same independent-axis endpoint mapping. |
| Translation and rotation | Coordinates and rotation interpolation remain unchanged. Local flipped endpoints are drawn inside the existing rotation around the frame center in both editor and PDF. The reviewed changes introduce no second canvas flip or duplicate rotation. |

The production-wide constructor search found no other reconstruction of an existing transform that drops these flags. Remaining constructors create new shapes or fixtures. The Studio duplication method above is the additional live shape-copy loss found outside the assigned files.

## Regression coverage reviewed, not rerun

The added engine tests cover all four flip combinations through copy, PPTX serialization and actual PDF endpoint inspection; XML `true`/`1`/`false`/`0` on each individual axis; a single authored stroke; the fill-only fallback; every alignment/distribution branch; native geometry serialization; and morph state. Editor tests inspect raster pixels for single-axis slopes, fill fallback and sampled morph direction, and exercise clipboard and grouped nudge/edit/undo behavior.

These tests address the original gap in the incoming branch's both-axes-only import assertion. The two Studio findings require their own correction and focused verification before the entire user path can be called complete.

## Scope

This is connector preservation for the existing native PPTX/editor/PDF paths. It does not claim full PowerPoint connector semantics, endpoint bindings, or general shape-flip rendering across every export format. The ODP writer's pre-existing generic-frame connector fallback was not changed by this work.

## Closure — 20 November 2026, 04:24 UTC

**Both Studio findings are resolved in the reviewed source. No connector-preservation blocker remains in this scope.** The eight originally reviewed production files are unchanged since the initial review; only `suite_workspace.dart` changed to close the two findings. The closure hashes and exact observation time are recorded in `connector-independent-review-sources.json`.

`_alignSelectedShape` now copies `t.flipH` and `t.flipV` along with position, dimensions and rotation. Its position calculations, existing controller call and refresh remain unchanged. `_duplicateSlide` now calls `src.copy(id: _nextSlideId())` and retains the original append-and-select behavior. Inspection of `PmlSlide.copy` confirms that a new ID clears `sourcePartUri`, while copying the source's decorations, master-shape visibility, background provenance, notes, transition, animations and full shape state, including connector stroke and flips. Independent copied lists and shapes preserve the existing model-copy contract.

The corrected Studio source SHA-256 is `a497b7474cda4712a880327f116e227bdc33830b6cca2b8654199b841f9039de`. This closure is based on source inspection; the implementation owner retains responsibility for the focused regression gates. No production edit or additional test run was performed by this reviewer.
