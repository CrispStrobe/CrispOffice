# Independent review of incoming PPTX corrections

Reviewed on 20 November 2026 against checkpoint `6167f475`; current code was subsequently preserved by root at `ee5d0da58e898dbb00ff49398f91dd8284fc6799`. Scope: the eight files listed in `pptx-validation/summary.json`, the seven findings in `pptx-review.md`, and the macro detached-open/save/copy path. No source files were edited, no broad test run was repeated, and no GitHub CI endpoints were queried.

## Acceptance: one remaining blocker

**Numeric multiline fallback reverses space-separated number groups.**

In `OfficePdfExport._paintRichText`, the new single-line/width guard sends multiline numeric text through `_PageSink.drawText` and the normal bidi line breaker. That path does not preserve the incoming feature's authored LTR order for adjacent numeric groups separated by spaces.

A targeted actual-PDF probe using the repository's `aliasTestFont`, `rightToLeft: false`, 20-point text, and a 300-point box produces:

| Source | Painted text by baseline |
| --- | --- |
| `12 34\n56 78` | `34 12`, then `78 56` |
| `12-34/56\n78-90/12` | `12-34/56`, then `78-90/12` |

The existing regression uses `12\n34`, which has only one group per line and therefore misses this. A narrow wrapping test may also miss it if every line contains only one numeric group. Preserve explicit breaks and wrapping while retaining authored order on each numeric line. Add checks where each line contains at least two space-separated groups. Root and the PPTX owner were notified before final qualification.

Probe: `/workspace/scratch/f0aea33f35d2/probe_pdf_numeric.dart`. Run from `packages/quds_office_engine` with the repository package configuration. The initial attempt from repository root failed to locate the test font; the same probe from the correct package cwd produced the results above.

## Other reviewed corrections

- Arrow stroke cases now reconstruct the same closed path used for fills before stroking. Four-direction tests inspect actual PDF stroke paths and PPTX roundtrips. Geometry matches the editor's preset paths.
- Inherited font sizes no longer receive `fitScale` twice; explicit run sizes retain one scale application. The focused mixed-style test exercises that difference.
- Decorations ignore foreground animation samples and morph skip IDs, preventing part-local ID collisions. Rotation is applied around the authored bounds before painting. Widget tests cover hidden foreground IDs, morph ID reuse, and a rotated non-square rectangle.
- Foreground text backing traversal now visits decoration layers before prior foreground shapes, uses identity samples for decorations, and treats overlapping curved, rotated, media, and text backings conservatively. The original dark-slide tests are reported byte-identical in the validation manifest.
- `showMasterSp` suppresses master decorations while retaining layout decorations and editable slide content; the authored slide flag survives `PmlSlide.copy()` and `slideToXml`, with false/zero and true/default import tests. This interpretation is consistent with Microsoft's descriptions for slide and layout `showMasterSp` attributes.

## Macro transaction trace

`OfficeMacroSession._execute` opens a detached copy of the session bytes through `OfficeOperationDocument.open`; PPTX opening uses `SlideDeserializer`. The newly parsed flag is therefore present in the detached model. Saving passes the complete `PmlPresentation` through `OfficeIsolateSave.presentation` to `SlideSerializer`, with no manually enumerated intermediary representation that could drop the new Boolean. `PmlSlide.copy()` also explicitly preserves the flag and deep-copies decorations. No missing macro transaction field was found.

## Limits and references

This review does not establish actual PowerPoint-host parity. Imported decoration lists remain resolved snapshots, as the implementation record states.

- https://learn.microsoft.com/en-us/office/open-xml/presentation/working-with-slide-layouts
- https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.presentation.slide?view=openxml-3.0.1

## Resolution — 20 November 2026, 04:21 UTC

**The numeric multiline blocker above is closed.** I independently reran the original actual-PDF probe after fix commit `fd733f28aa14aad5e9556669caf434f051cd8e15`, on integration head `403fec5f8b73752890a36579264ab010e6b12bc1`. The original finding and its failing output remain above as the development record.

| Source | Box width | Painted text by baseline after the fix |
| --- | --- | --- |
| `12 34\n56 78` | 300 pt | `12 34`, then `56 78` |
| `12-34/56\n78-90/12` | 300 pt | `12-34/56`, then `78-90/12` |
| `12/34 56/78 90/12` | 90 pt | `12/34`, then `56/78`, then `90/12` |

The source review covered the replacement of the single-line shortcut by `_PageSink._layoutLines`, its drawing/counting/measuring callers, and the existing line breaker's source offset and formatting-control handling. The temporary U+202D override is used only for explicitly LTR, letter-free text. `LineBreaker._logicalGlyphs` removes that invisible formatting character before painting. The wrapper subtracts its one UTF-16 code unit from every glyph index and line start/end before `_brokenLineActualText` sees the original source; glyph source lengths and advances are preserved. RTL and letter-containing text do not enter the new override path. The core bidi implementation was not changed.

I also ran a focused independent named-font probe to check the newly shared font-family measurements. With a 100-point-wide, vertically centered text box and source `12 34 56 78 90 12`, Liberation Sans correctly wraps into two lines, while Liberation Mono wraps into three. Both center and right alignment match independently calculated font advance widths to 0.02 pt. Their first painted font-box tops center according to the corresponding two- or three-line count, with 25-point spacing. All four cases extract the exact original source, including spaces, and contain no generated U+202D character. This checks a concrete failure mode that would occur if line counting used the default face while drawing used the named face.

Commands were run from `packages/quds_office_engine`, after sourcing `/workspace/scratch/f0aea33f35d2/runtime/env.sh`:

```sh
dart --packages=../../.dart_tool/package_config.json /workspace/scratch/f0aea33f35d2/probe_pdf_numeric.dart
dart --packages=../../.dart_tool/package_config.json /workspace/scratch/f0aea33f35d2/probe_pdf_numeric_named_fonts.dart
```

Raw results are in `pptx-numeric-independent-probe.log` and `pptx-numeric-independent-named-fonts.log` beside this report. The latter reports four accepted cases and records painted lines, positions, and extracted text. The numeric layout helper/line-count source range reviewed has SHA-256 `ced07ac31b6ed466e24b6650267cc937d939eb51a38a14c308aba6d42be3e94b`.

No additional numeric alignment, wrapping, logical-extraction or named-family blocker was found. No production source was modified and no broad test suite or GitHub CI endpoint was queried during this independent closure. This resolution concerns the numeric blocker only; the separately incoming connector preservation work remains under its own review.
