import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

root = Path('/workspace/scratch/f0aea33f35d2/quds_office_suite')
out = Path('/workspace/scratch/f0aea33f35d2/pptx-validation')
paths = [
    'packages/quds_office_editor/lib/src/editor_slide/render_slide_stage.dart',
    'packages/quds_office_editor/lib/src/editor_word/paint_run_text.dart',
    'packages/quds_office_engine/lib/src/pdf/office_pdf_export.dart',
    'packages/quds_office_engine/lib/src/slide/model/pml_presentation.dart',
    'packages/quds_office_engine/lib/src/slide/serial/slide_serial.dart',
    'packages/quds_office_engine/lib/src/slide/shapes/drawingml.dart',
    'packages/quds_office_engine/test/slide_import_fidelity_test.dart',
    'packages/quds_office_engine/test/slide_incoming_pptx_regression_test.dart',
    'packages/quds_office_engine/test/slide_render_fidelity_test.dart',
    'packages/quds_office_engine/test/office_pdf_export_test.dart',
    'packages/quds_office_engine/test/slide_text_fidelity_test.dart',
    'packages/quds_office_engine/test/slide_rich_text_explicit_style_test.dart',
    'packages/quds_office_engine/test/slide_test.dart',
    'packages/quds_office_editor/test/slide_incoming_pptx_regression_test.dart',
    'packages/quds_office_editor/test/office_dark_slide_test.dart',
    'packages/quds_office_editor/test/slide_render_fidelity_test.dart',
    'packages/quds_office_engine/lib/src/slide/anim/pml_morph.dart',
    'packages/quds_office_engine/lib/src/slide/model/pml_arrange.dart',
    'packages/quds_office_engine/lib/src/automation/operations/slide_steps.dart',
    'packages/quds_office_editor/lib/src/embed/office_clipboard.dart',
    'packages/quds_office_editor/lib/src/embed/office_controller.dart',
    'packages/quds_office_engine/test/slide_arrange_fidelity_test.dart',
    'packages/quds_office_editor/test/slide_arrange_history_test.dart',
    'packages/quds_office_editor/example/lib/suite_workspace.dart',
    'packages/quds_office_editor/example/test/studio_slide_sheet_menus_test.dart',
    'pubspec.lock',
    'pubspec.yaml',
    '.fvmrc',
]

def manifest():
    return {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in paths}

def now():
    return datetime.now(timezone.utc).isoformat()

name, cwd, *command = sys.argv[1:]
receipt = {
    'name': name,
    'started_at': now(),
    'command': command,
    'cwd': str(root / cwd),
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'source_sha256_before': manifest(),
    'log': name + '.log',
}
with (out / (name + '.log')).open('w') as log:
    result = subprocess.run(command, cwd=root / cwd, stdout=log, stderr=subprocess.STDOUT, env=os.environ)
receipt['finished_at'] = now()
receipt['exit_code'] = result.returncode
receipt['source_sha256_after'] = manifest()
receipt['source_unchanged'] = receipt['source_sha256_before'] == receipt['source_sha256_after']
receipt['log_sha256'] = hashlib.sha256((out / (name + '.log')).read_bytes()).hexdigest()
(out / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ('name', 'exit_code', 'source_unchanged', 'log')}, indent=2))
print('\n'.join((out / (name + '.log')).read_text().splitlines()[-18:]))
sys.exit(result.returncode if receipt['source_unchanged'] else 91)
