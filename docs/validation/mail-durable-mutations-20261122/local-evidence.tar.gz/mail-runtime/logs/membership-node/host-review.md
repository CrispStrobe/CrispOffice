# Connected membership host review

Read-only source review by mutation_transport after the bounded Move/Delete integration. This review does not claim runtime, browser persistence, or live-service acceptance. Root owns host runtime verification.

## Outcome

No remaining concrete stale-selection, owner-lifetime, automatic-replay, or mutation-evidence defect found in the reviewed source snapshot. Exact reviewed file hashes are recorded in `host-review-source-hashes.json`.

One optional-adapter mismatch was reported: native membership controls required the membership and observed-record ports, but dispatch also unconditionally required the legacy flag-action port. Root corrected this. The final reviewed dispatch condition requires the legacy flag-action port only for flag operations; membership-only adapters can reach their dedicated port.

## Checks

- Native picker/confirmation captures the connected client, loader, session generation, mailbox generation, source mailbox path, UIDVALIDITY, selected message object, and observed remote identity. These are checked after capability lookup and again after dialog completion.
- EWS/Graph move popup captures selected object and mailbox generation. Dispatch checks the selected remote identity and validates the destination against the current observed mailbox set; equal-source destinations are refused. Cloud UI delegates to the same guarded EWS host.
- Delete requires its dedicated confirmation path. Generic bulk callbacks cannot authorize membership actions: native requires membershipConfirmed; EWS/cloud requires singleMessage. Both default false.
- Frozen plans carry exact source identity and destination. Coordinator checks source scope before each attempt; host checks scope before projecting replies. A stale callback cannot substitute a fresh current message.
- Both hosts retire cached mailbox subscriptions and invalidate saved observation windows before membership dispatch. Native retirement preserves observed metadata, and confirmed Deleted projection preserves unknown read/flag state. Destination membership and destination identities are never fabricated.
- Journal prepare and beginAttempt require the current source scope and current store owner. Result and finish recording intentionally remain possible for the original repository owner after scope retirement, preserving late provider evidence without granting further dispatch authority.
- Store closure waits pending membership receipt work before closing the serialized repository owner. Reconnect and store restoration await prior owner closure. Disposal cancels later dispatches, and stale UI callbacks reject publication.
- Returned provider acknowledgements and mutationMayHaveOccurred evidence are retained by the native loader even after disposal; the transport owns bounded completion. UI scope retirement is separate from evidence persistence.
- Confirmed membership changes require refresh; uncertain membership receipts remain unresolved and are not offered flag-only reconciliation or automatic replay. Cache rows remain explicitly last-saved observations pending refresh/synchronization.

## Evidence boundary

The accompanying Node qualification executed the complete portable core suite and selected portable store fixtures. VM-only membership database/reopen tests were deliberately excluded from Node. Browser entry and worker checks are compilation only; no Chromium or live mail accounts were used here.
