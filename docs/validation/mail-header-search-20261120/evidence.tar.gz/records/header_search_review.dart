import 'dart:convert';
import 'dart:io';
import 'dart:math';

import '../quds_office_suite/packages/quds_mail_core/lib/src/search/header_search.dart';

void check(bool value, String name) {
  if (!value) throw StateError(name);
}

void main(List<String> arguments) {
  final expectedDay = arguments.single;
  final header = MailHeaderSearchDocument(
    subject: 'Alpha planning',
    sender: 'Alice Example <alice@example.test>',
    date: DateTime.utc(2026, 11, 19, 23, 30),
  );
  check(MailHeaderSearchQuery.parse('on:$expectedDay').matches(header),
      'fixed instant must match expected local calendar day');
  check(!MailHeaderSearchQuery.parse('before:$expectedDay').matches(header),
      'before excludes the complete named day');
  check(!MailHeaderSearchQuery.parse('after:$expectedDay').matches(header),
      'after excludes the complete named day');
  for (final field in ['read', 'unread', 'flagged', 'unflagged']) {
    check(!MailHeaderSearchQuery.parse('is:$field').matches(header),
        'unknown flag must not match $field');
  }
  final random = Random(20261120);
  const alphabet = 'abcde ABCDEF0123456789:-"\\[]()|&*?\t\n\r\x00\x7f\u00a0😀';
  var accepted = 0;
  var refused = 0;
  for (var attempt = 0; attempt < 10000; attempt++) {
    final length = random.nextInt(80);
    final query = String.fromCharCodes([
      for (var unit = 0; unit < length; unit++)
        alphabet.codeUnitAt(random.nextInt(alphabet.length)),
    ]);
    try {
      final parsed = MailHeaderSearchQuery.parse(query);
      check(parsed.termCount <= MailHeaderSearchQuery.maxTerms,
          'accepted term count exceeds budget');
      parsed.matches(header);
      accepted++;
    } on MailHeaderSearchException catch (error) {
      check(error.offset >= 0 && error.offset <= query.length,
          'error offset outside original query');
      refused++;
    }
  }
  print(jsonEncode({
    'timezone': Platform.environment['TZ'],
    'fixedInstant': header.date!.toIso8601String(),
    'expectedLocalDay': expectedDay,
    'dateAndUnknownFlagChecks': 'PASS',
    'fuzzInputs': accepted + refused,
    'accepted': accepted,
    'typedRefusals': refused,
    'unexpectedExceptions': 0,
  }));
}
