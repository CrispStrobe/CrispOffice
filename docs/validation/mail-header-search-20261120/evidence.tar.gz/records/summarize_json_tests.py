"""Summarize actual Dart/Flutter JSON events without counting hidden loaders."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import sys


def summarize(path):
    path = Path(path)
    events = []
    non_json_lines = []
    for line in path.read_text().splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            if line.strip():
                non_json_lines.append(line)
    suites = {e['suite']['id']: e['suite']['path'] for e in events if e.get('type') == 'suite'}
    tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    results = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden', False)]
    counts = Counter(e['result'] for e in results)
    skipped = sum(bool(e.get('skipped')) for e in results)
    by_suite = Counter(suites.get(tests.get(e['testID'], {}).get('suiteID'), 'unknown')
                       for e in results)
    done = [e for e in events if e.get('type') == 'done']
    return {
        'log': path.name,
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'complete': bool(done),
        'success': bool(done and done[-1].get('success')),
        'tests': len(results),
        'passed': sum(e['result'] == 'success' and not e.get('skipped') for e in results),
        'skipped': skipped,
        'result_counts': dict(counts),
        'elapsed_ms': done[-1].get('time') if done else None,
        'suites': dict(by_suite),
        'errors': [e for e in events if e.get('type') == 'error'],
        'non_json_lines': non_json_lines,
    }


if __name__ == '__main__':
    for argument in sys.argv[1:]:
        print(json.dumps(summarize(argument), ensure_ascii=False, indent=2))
