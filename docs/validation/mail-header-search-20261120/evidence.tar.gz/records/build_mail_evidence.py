"""Package observed local acceptance; fail closed on incomplete test output."""

from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

from summarize_json_tests import summarize

runtime = Path(__file__).resolve().parent
repo = runtime.parent / 'quds_office_suite'
out = repo / 'docs/validation/mail-header-search-20261120'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(name):
    return json.loads((runtime / name).read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()

def verify_sources(values):
    mismatches = []
    for path, value in values.items():
        expected = value['sha256'] if isinstance(value, dict) else value
        if sha(repo / path) != expected:
            mismatches.append(path)
    assert not mismatches, mismatches
    return {'checked_files': len(values), 'mismatches': []}

accepted = {}
for label, name in {
    'mail_ui': 'mail-ui-tests.jsonl',
    'mail_visuals': 'mail-visual-tests.jsonl',
    'studio_hosts_and_settings': 'mail-host-accepted.jsonl',
    'word_and_layout': 'incoming-engine-acceptance-tests.jsonl',
    'editor_zotero_rerun': 'editor-zotero-accepted.jsonl',
}.items():
    result = summarize(runtime / name)
    assert result['complete'] and result['success'] and not result['errors'], (label, result)
    assert not result['skipped'], (label, result)
    accepted[label] = result

# A mixed run remains a failed run. Preserve the independently completed,
# unchanged four suites and replace only the corrected Zotero suite's result.
mixed = summarize(runtime / 'editor-five-tests.jsonl')
assert mixed['complete'] and mixed['passed'] == 203 and mixed['skipped'] == 8
events = [json.loads(line) for line in (runtime / 'editor-five-tests.jsonl').read_text().splitlines()]
suites = {e['suite']['id']: e['suite']['path'] for e in events if e.get('type') == 'suite'}
tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
zotero = 'word_zotero_navigation_test.dart'
per_suite = {}
skips = []
for event in events:
    if event.get('type') not in ('testDone', 'error'):
        continue
    test = tests.get(event.get('testID'), {})
    suite = Path(suites.get(test.get('suiteID'), '')).name
    if event['type'] == 'error':
        assert suite == zotero, event
        continue
    if event.get('hidden') or suite == zotero:
        continue
    assert event['result'] == 'success', event
    item = per_suite.setdefault(suite, Counter())
    item['skipped' if event.get('skipped') else 'passed'] += 1
    if event.get('skipped'):
        skips.append({'suite': suite, 'name': test.get('name'), 'reason': test.get('metadata', {}).get('skipReason')})
assert len(per_suite) == 4
prior_editor = read('editor-five-source-before.json')['files']
editor_unchanged = {p: h for p, h in prior_editor.items() if not p.endswith('/' + zotero)}
verify_sources(editor_unchanged)
editor = {
    'kind': 'Composed coverage, not a single successful five-suite run',
    'original_mixed_run': mixed,
    'accepted_unchanged_suites': {p: dict(v) for p, v in per_suite.items()},
    'corrected_suite': accepted['editor_zotero_rerun'],
    'passed': sum(c['passed'] for c in per_suite.values()) + accepted['editor_zotero_rerun']['passed'],
    'skipped': len(skips), 'skipped_cases': skips,
    'source_recheck': verify_sources(editor_unchanged),
    'receipt': 'editor-validation-summary.json',
}
assert editor['passed'] == 204 and editor['skipped'] == 8, editor
assert (runtime / editor['receipt']).is_file()
editor_exit = read('editor-analysis-final-exit.json')
assert editor_exit['observed_exit_code'] == 0
assert sha(repo / editor_exit['source_file']) == editor_exit['source_sha256']
assert sha(runtime / editor_exit['log']) == editor_exit['log_sha256']

core = read('core-validation-receipt.json')
for check in core['checks']:
    assert check['exit_code'] == 0
    assert sha(runtime / check['log']) == check['log_sha256']
studio = read('studio-final-analysis.json')
formatting = read('final-format.json')
assert studio['exit_code'] == 0 and formatting['exit_code'] == 0
source_checks = {
    'core': verify_sources(core['source_files']),
    'mail_ui': verify_sources(read('mail-ui-validation-receipt.json')['source_files']),
    'studio_analysis': verify_sources(studio['source_files']),
    'formatting': verify_sources(formatting['source_files']),
    'engine': verify_sources(read('incoming-engine-acceptance-input.json')['sha256']),
}
host_inputs = read('mail-host-input.json')['source_files']
host_domain = {p: h for p, h in host_inputs.items()
               if p.startswith(('packages/quds_mail_core/', 'packages/quds_mail_ui/',
                                'packages/quds_office_editor/example/'))
               and not p.endswith('/test/app_store_screenshots_gate.dart')}
source_checks['mail_and_settings_hosts'] = verify_sources(host_domain)
source_checks['later_host_manifest_changes'] = {
    p: 'Covered by final engine/editor validation or screenshot-gate analysis; mail/settings source is unchanged.'
    for p, h in host_inputs.items() if sha(repo / p) != h
}

intake = json.loads((out / 'intake.json').read_text())
assert intake['status'] == 'PASS' and not intake['uncovered']
assert subprocess.run(['git', 'merge-base', '--is-ancestor', intake['target_commit'], 'HEAD'], cwd=repo).returncode == 0

accepted_names = [
    'core-validation-receipt.json', 'core-tests-direct.log', 'core-header-search-node.log',
    'core-analyze.log', 'core-format.log', 'core-whitespace.log',
    'mail-ui-validation-receipt.json', 'mail-ui-summary.json', 'mail-ui-tests.jsonl',
    'mail-ui-tests.stderr', 'mail-ui-analyze-lib.log', 'mail-ui-analyze-test.log',
    'mail-visual-summary.json', 'mail-visual-tests.jsonl', 'mail-visual-tests.stderr',
    'mail_visual_probe_test.dart', 'mail-host-input.json', 'mail-host-summary.json',
    'mail-host-accepted.jsonl', 'mail-host-accepted.stderr',
    'incoming-engine-acceptance-input.json', 'incoming-engine-acceptance-summary.json',
    'incoming-engine-acceptance-tests.jsonl', 'incoming-engine-acceptance-tests.stderr',
    'incoming-engine-acceptance-analysis.jsonl', 'editor-five-source-before.json',
    'editor-five-tests.jsonl', 'editor-five-tests.stderr', 'editor-zotero-accepted.jsonl',
    'editor-zotero-accepted.stderr', 'editor-validation-summary.json',
    'studio-final-analysis.json', 'studio-final-analysis.log', 'final-format.json',
    'final-format.log', 'final-commit-whitespace.log', 'macos-minimum-version-tests.log',
    'runtime-integrity-final.json', 'source-applicability-final.json',
    'pub-cache-bootstrap-manifest.json', 'bootstrap_pub_cache.py', 'env.sh',
    'flutter-tools-pub-offline-fixed.log', 'workspace-pub-offline-fixed.log',
    'header-search-review-observations.json', 'header_search_review.dart',
    'screenshot-integration-review.json', 'screenshot-gate-validation.json',
    'screenshot-gate-analyze.log', 'screenshot-gate-format-check.log',
    'word-active-style-receipt.json', 'word-active-style-acceptance.jsonl',
    'note-layout-invalidation-fixed.jsonl',
    'incoming-word-tests-input.json', 'incoming-word-tests-summary.json',
    'incoming-word-tests.jsonl', 'summarize_json_tests.py', 'run_studio_analysis.py',
    'build_mail_evidence.py', 'write_mail_validation_readme.py',
    'macos-guard-receipt.json',
]
accepted_names.extend(f'editor-five-analyze-{n}.log' for n in range(1, 7))
accepted_names.append('editor-five-analyze-2-final.log')
# Include the editor agent's command/hash and analyzer receipts without its
# aborted pre-fix attempt. All are provenance, not additional test counts.
for path in sorted(runtime.glob('editor-*.json*')):
    if any(part in path.name for part in ('aborted', 'before-note-fix', 'bookmark')):
        continue
    if path.name not in accepted_names:
        accepted_names.append(path.name)
diagnostic_names = [
    'diagnostic-history.json', 'mail-host-before-compact-fix.jsonl', 'mail-host-final.jsonl',
    'mail-host-tests.jsonl', 'mail-host-tests.stderr', 'mail-visual-contended.jsonl',
    'incoming-word-timeout-diagnostic.jsonl', 'incoming-word-timeout-diagnostic-summary.json',
    'incoming-final-engine-tests.jsonl', 'studio-initial-screenshot-errors.log',
    'word-active-style-repro.jsonl', 'word-active-style-reason.jsonl',
    'word-active-style-fixed.jsonl', 'word-active-style-final.jsonl',
    'note-layout-invalidation-repro.jsonl',
]
members = []
for folder, names in [('records', accepted_names), ('diagnostics', diagnostic_names)]:
    for name in names:
        path = runtime / name
        assert path.is_file(), path
        members.append((folder + '/' + name, path.read_bytes()))
for name in ['intake.json', 'intake.md', 'verify_intake.py']:
    members.append(('source-intake/' + name, (out / name).read_bytes()))

archive = out / 'evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0, compresslevel=9) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(members):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
inventory = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
             for name, data in sorted(members)}
(out / 'evidence-members.json').write_text(json.dumps(inventory, indent=2) + '\n')
visuals = out / 'visuals'
visuals.mkdir(exist_ok=True)
for source, target in [('comparison-help.png', 'help-locales.png'),
                       ('comparison-compact.png', 'compact-locales.png')]:
    shutil.copyfile(runtime / 'mail-visual' / source, visuals / target)

receipt = {
    'schema': 'quds-mail-local-validation/v1', 'status': 'PASS_WITH_DOCUMENTED_SKIPS',
    'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'qualified_source_commit': git('rev-parse', 'HEAD'),
    'qualified_source_tree': git('rev-parse', 'HEAD^{tree}'),
    'core': {'native_tests': 94, 'node_tests': 27, 'receipt': 'records/core-validation-receipt.json'},
    'accepted_test_runs': accepted, 'editor_composed_coverage': editor,
    'source_applicability': source_checks,
    'strict_analysis': {'mail_core': 'clean', 'mail_ui_lib_and_test': 'clean',
                        'studio_changed_files': 19, 'engine_changed_files': 17,
                        'editor_changed_files': 6,
                        'editor_exit_metadata_followup': 'records/editor-analysis-final-exit.json'},
    'formatting': {'files': 22, 'changed': 0}, 'macos_guard_python_tests': 5,
    'intake': {'target': intake['target_commit'], 'counts': intake['counts'],
               'historical_proofs': len(intake['recomputed_equivalence']), 'uncovered': 0},
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive),
                'member_count': len(members), 'manifest': 'evidence-members.json'},
    'visuals': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(visuals.glob('*.png'))},
    'github_actions': 'Neither queried nor awaited',
    'publication': 'Source is saved on work/mail-parity-20261120. PR #270 records the eventual observed merge transaction.',
    'limits': [
        'Loaded header search; no account-wide/body/Bcc search.',
        'Fake-provider/widget tests do not qualify live accounts or real sends.',
        'No installed-platform build, App Store screenshot workflow, or native Arabic/WASM/browser parity run.',
        'Node checks portable query JavaScript, not browser UI.',
        'Eight image-only editor fixtures had no paragraphs to edit and were skipped.',
        'Editor coverage combines four unchanged suites from a mixed run and a clean corrected Zotero rerun.',
        'Test cohorts overlap; no distinct-test grand total is claimed.',
    ],
}
(out / 'validation.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive),
                  'members': len(members), 'editor_passed': editor['passed'],
                  'editor_skipped': editor['skipped'], 'qualified_source': receipt['qualified_source_commit']}))
