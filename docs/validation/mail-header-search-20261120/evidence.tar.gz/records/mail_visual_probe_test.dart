// Reproducible visual evidence. Run from packages/quds_mail_ui with Flutter test.
// Uses only fictional .test addresses and the actual Studio localized labels.
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_mail_ui/quds_mail_ui.dart';
import 'package:quds_office_studio/studio_mail_workspace_strings.dart';
import 'package:quds_office_studio/studio_strings.dart';

const _root = '/workspace/scratch/f31e183d600e';
const _repo = '$_root/quds_office_suite';
const _output = '$_root/runtime/mail-visual';

Future<void> _loadFont(String family, String path) async {
  final loader = FontLoader(family);
  loader.addFont(File(path).readAsBytes().then(ByteData.sublistView));
  await loader.load();
}

Future<void> _capture(WidgetTester tester, GlobalKey key, String filename) async {
  await tester.pumpAndSettle();
  expect(tester.takeException(), isNull);
  final boundary = key.currentContext!.findRenderObject()! as RenderRepaintBoundary;
  await tester.runAsync(() async {
    final image = await boundary.toImage(pixelRatio: 1.5);
    final png = await image.toByteData(format: ui.ImageByteFormat.png);
    await File('$_output/$filename.png').writeAsBytes(png!.buffer.asUint8List());
    image.dispose();
  });
}

String _text(StudioLanguage language, String en, String de, String ar) => switch (language) {
  StudioLanguage.en => en,
  StudioLanguage.de => de,
  StudioLanguage.ar => ar,
};

List<MailMessageListItem> _rows(StudioLanguage language) => [
  MailMessageListItem(
    id: 'one',
    subject: _text(language, 'Quarterly planning review', 'Besprechung der Quartalsplanung', 'مراجعة خطة الربع القادم'),
    sender: 'Nadia Hassan <nadia@example.test>',
    to: 'Project Team <team@example.test>',
    cc: 'review@example.test',
    date: DateTime(2026, 11, 20, 10, 24),
    dateLabel: _text(language, 'Today, 10:24', 'Heute, 10:24', 'اليوم، 10:24'),
    isRead: false,
    isFlagged: true,
  ),
  MailMessageListItem(
    id: 'two',
    subject: _text(language, 'Design notes and next steps', 'Designnotizen und nächste Schritte', 'ملاحظات التصميم والخطوات التالية'),
    sender: 'Jonas Weber <jonas@example.test>',
    to: 'team@example.test',
    date: DateTime(2026, 11, 19, 15, 40),
    dateLabel: _text(language, 'Yesterday, 15:40', 'Gestern, 15:40', 'أمس، 15:40'),
    isRead: true,
    isFlagged: false,
  ),
  MailMessageListItem(
    id: 'three',
    subject: _text(language, 'Updated release checklist', 'Aktualisierte Veröffentlichungsliste', 'قائمة التحقق المحدّثة للإصدار'),
    sender: 'Amal Saleh <amal@example.test>',
    to: 'team@example.test',
    date: DateTime(2026, 11, 18, 8, 10),
    dateLabel: _text(language, '18 November, 08:10', '18. November, 08:10', '18 نوفمبر، 08:10'),
    isRead: false,
    isFlagged: false,
  ),
  MailMessageListItem(
    id: 'four',
    subject: _text(language, 'Imported message with no observed date', 'Importierte Nachricht ohne bekanntes Datum', 'رسالة مستوردة دون تاريخ معروف'),
    sender: 'Archive <archive@example.test>',
  ),
];

Widget _app(StudioLanguage language, GlobalKey capture, {bool compact = false}) => RepaintBoundary(
  key: capture,
  child: MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff256356)),
      fontFamily: language == StudioLanguage.ar ? 'QaArabic' : 'QaLatin',
      fontFamilyFallback: const ['QaArabic', 'QaLatin'],
    ),
    builder: (context, child) => MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: const TextScaler.linear(1.4)),
      child: Directionality(
        textDirection: language == StudioLanguage.ar ? TextDirection.rtl : TextDirection.ltr,
        child: child!,
      ),
    ),
    home: Scaffold(
      appBar: compact ? null : AppBar(title: Text(_text(language, 'Mail · Inbox', 'E-Mail · Posteingang', 'البريد · الوارد'))),
      body: MailMessageList(
        items: _rows(language),
        strings: StudioStrings(language).mailMessageListStrings,
        onOpen: (_) => fail('Visual probe must never open a message'),
        scopeId: 'qa-${language.name}/$compact',
        hasMore: true,
        onLoadMore: () => fail('Visual probe must never fetch mail'),
      ),
    ),
  ),
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    await Directory(_output).create(recursive: true);
    await _loadFont('QaLatin', '$_repo/packages/quds_office_editor/fonts/LiberationSans-Regular.ttf');
    await _loadFont('QaArabic', '$_repo/packages/quds_office_editor/example/fonts/Tajawal-Regular.ttf');
    await _loadFont('MaterialIcons', '$_root/runtime/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf');
  });
  for (final language in StudioLanguage.values) {
    testWidgets('${language.name} actual localized narrow mail controls', (tester) async {
      await tester.binding.setSurfaceSize(const Size(440, 850));
      addTearDown(() => tester.binding.setSurfaceSize(null));
      final strings = StudioStrings(language).mailMessageListStrings;
      final capture = GlobalKey();
      await tester.pumpWidget(_app(language, capture));
      await _capture(tester, capture, '${language.name}-list');
      await tester.tap(find.byKey(const ValueKey('mail-list-sort')));
      await _capture(tester, capture, '${language.name}-sort');
      await tester.tap(find.byKey(const ValueKey('mail-list-sort-newestFirst')));
      await tester.pumpAndSettle();
      await tester.enterText(find.byKey(const ValueKey('mail-list-search')), 'from:alice OR subject:report');
      await _capture(tester, capture, '${language.name}-error');
      await tester.tap(find.byKey(const ValueKey('mail-list-clear-search')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('mail-list-search-help')));
      await _capture(tester, capture, '${language.name}-help');
      await tester.drag(
        find.descendant(of: find.byType(AlertDialog), matching: find.byType(SingleChildScrollView)),
        const Offset(0, -900),
      );
      await _capture(tester, capture, '${language.name}-help-end');
      await tester.tap(find.text(strings.close));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
    });
  }
  for (final language in [StudioLanguage.de, StudioLanguage.ar]) {
    testWidgets('${language.name} compact 320x260 viewport', (tester) async {
      await tester.binding.setSurfaceSize(const Size(320, 260));
      addTearDown(() => tester.binding.setSurfaceSize(null));
      final capture = GlobalKey();
      await tester.pumpWidget(_app(language, capture, compact: true));
      await _capture(tester, capture, '${language.name}-compact');
      final header = tester.widget<SingleChildScrollView>(find.byKey(const ValueKey('mail-list-header-scroll'))).controller!;
      expect(header.position.maxScrollExtent, greaterThan(0));
      expect(tester.getSize(find.byKey(const ValueKey('mail-list-rows'))).height, greaterThanOrEqualTo(48));
    });
  }
}
