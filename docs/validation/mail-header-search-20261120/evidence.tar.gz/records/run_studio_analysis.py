import hashlib
import json
from pathlib import Path
import subprocess
import time

repo = Path('/workspace/scratch/f31e183d600e/quds_office_suite')
runtime = repo.parent / 'runtime'
dart = runtime / 'flutter/bin/cache/dart-sdk/bin/dart'
paths = subprocess.check_output([
    'git', 'diff', '--name-only', '5ad4461a93c835479bf67acab63623944b3900a3',
    'HEAD'], cwd=repo, text=True).splitlines()
paths = [p for p in paths if p.startswith('packages/quds_office_editor/example/') and p.endswith('.dart')]
paths.append('packages/quds_office_editor/example/test/studio_compact_navigation_test.dart')
hashes = {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in paths}
command = [str(dart), 'analyze', '--fatal-infos', *paths]
started = time.monotonic()
result = subprocess.run(command, cwd=repo, capture_output=True, text=True, timeout=600)
(runtime / 'studio-final-analysis.log').write_text(result.stdout + result.stderr)
unchanged = all(hashlib.sha256((repo / p).read_bytes()).hexdigest() == value for p, value in hashes.items())
receipt = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
           'command': command, 'cwd': str(repo), 'source_files': hashes,
           'exit_code': result.returncode, 'source_unchanged': unchanged,
           'duration_seconds': round(time.monotonic() - started, 3),
           'log': 'studio-final-analysis.log'}
(runtime / 'studio-final-analysis.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'files': len(paths), 'exit_code': result.returncode, 'source_unchanged': unchanged,
                  'output': result.stdout + result.stderr}))
raise SystemExit(result.returncode or (0 if unchanged else 2))
