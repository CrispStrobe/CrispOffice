"""Read-only review of committed Office evidence and source continuity."""

import argparse
import collections
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile


parser = argparse.ArgumentParser()
parser.add_argument("--repo", default="/workspace/scratch/9437e96c5547/quds_office_suite")
parser.add_argument("--head", default="55e262ef269634a0d618c0b5102dc9be5430a5f3")
parser.add_argument("--incoming", default="ac1e4c8c788ea608402c2260488235c0189efcba")
parser.add_argument("--output", required=True)
args = parser.parse_args()
evidence_ref = "55e262ef269634a0d618c0b5102dc9be5430a5f3"
source_ref = "5569c055a021c893e941fc54d40499ad9d96a5db"
release = "docs/validation/office-main-completion-20261119/release/"


def git(*command):
    return subprocess.check_output(["git", "-C", args.repo, *command])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def tree(ref):
    result = {}
    for entry in git("ls-tree", "-rz", ref).split(b"\0"):
        if not entry:
            continue
        metadata, path = entry.split(b"\t", 1)
        mode, kind, oid = metadata.decode().split()
        result[path.decode()] = {"mode": mode, "git_blob": oid, "kind": kind}
    return result


archive_bytes = git("show", evidence_ref + ":" + release + "local-qualification.tar.xz")
index = json.loads(git("show", evidence_ref + ":" + release + "local-qualification.index.json"))
assert sha(archive_bytes) == index["archive_sha256"]
assert len(archive_bytes) == index["archive_bytes"]
with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:xz") as archive:
    entries = [member for member in archive.getmembers() if member.isfile()]
    assert len(entries) == index["member_count"]
    assert len({entry.name for entry in entries}) == len(entries)
    content = {entry.name: archive.extractfile(entry).read() for entry in entries}
assert set(content) == {item["path"] for item in index["members"]}
for item in index["members"]:
    raw = content[item["path"]]
    assert len(raw) == item["bytes"] and sha(raw) == item["sha256"], item["path"]
for name, raw in content.items():
    if name.endswith(".gz"):
        assert gzip.decompress(raw) == content[name[:-3]], name


def load(name):
    return json.loads(content[name])


trees = {ref: tree(ref) for ref in {source_ref, args.head, args.incoming}}
manifests = {}
for cohort in ("native", "node"):
    name = f"qualification-release-{cohort}/source-before.json"
    manifest = load(name)
    assert manifest == load(f"qualification-release-{cohort}/source-after.json")
    assert load(f"qualification-release-{cohort}/environment-before.json") == load(
        f"qualification-release-{cohort}/environment-after.json"
    )
    manifests[cohort] = manifest
for cohort, name in (
    ("store", "qualification-release-store/results/receipt.json"),
    ("support", "qualification-release-support/receipt.json"),
):
    receipt = load(name)
    assert receipt["source_before"] == receipt["source_after"]
    manifests[cohort] = {
        path: {**trees[source_ref][path], "sha256": digest}
        for path, digest in receipt["source_before"].items()
    }

union = {}
for manifest in manifests.values():
    for path, item in manifest.items():
        required = {key: item[key] for key in ("mode", "git_blob", "sha256")}
        if path in union:
            assert union[path] == required, path
        union[path] = required
        assert trees[source_ref][path]["mode"] == item["mode"], path
        assert trees[source_ref][path]["git_blob"] == item["git_blob"], path

# Hash each distinct bound blob independently, without checking out or editing it.
batch = subprocess.Popen(
    ["git", "-C", args.repo, "cat-file", "--batch"],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
)
blob_hashes = {}
for item in union.values():
    oid = item["git_blob"]
    if oid not in blob_hashes:
        batch.stdin.write((oid + "\n").encode())
        batch.stdin.flush()
        returned, kind, size = batch.stdout.readline().decode().split()
        assert returned == oid and kind == "blob"
        raw = batch.stdout.read(int(size))
        assert batch.stdout.read(1) == b"\n"
        blob_hashes[oid] = sha(raw)
    assert blob_hashes[oid] == item["sha256"]
batch.stdin.close()
assert batch.wait() == 0

comparisons = {}
for ref in (args.head, args.incoming):
    comparisons[ref] = {
        cohort: {
            "bound_inputs": len(manifest),
            "mismatches": [
                path for path, item in manifest.items()
                if path not in trees[ref]
                or any(trees[ref][path][key] != item[key] for key in ("mode", "git_blob"))
            ],
        }
        for cohort, manifest in manifests.items()
    }

cohort_paths = {
    "transport-native": "packages/quds_mail_transport",
    "mime-consumer-vm": "packages/quds_mail_mime",
    "mail-ui-consumers": "packages/quds_mail_ui",
    "enough-mail-protocol-regressions": "third_party/enough_mail",
    "transport-node-unsupported": "packages/quds_mail_transport",
    "mime-consumer-node": "packages/quds_mail_mime",
    "core-vm": "packages/quds_mail_core",
    "core-node": "packages/quds_mail_core",
    "portable-node": "packages/quds_mail_store",
    "store-vm": "packages/quds_mail_store",
}
cohorts = []
unique_cases = set()
unique_suites = set()
for name, raw in content.items():
    if not name.endswith(".jsonl"):
        continue
    cohort = Path(name).stem
    suite_map = {}
    starts = {}
    completions = {}
    all_suite_count = []
    terminal = []
    non_json = []
    error_events = []
    runner_start_count = 0
    case_identities = []
    for line in raw.decode().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            non_json.append(line)
            continue
        kind = event.get("type")
        if kind == "suite":
            suite = event["suite"]
            assert suite["id"] not in suite_map
            suite_map[suite["id"]] = suite
        elif kind == "testStart":
            test = event["test"]
            assert test["id"] not in starts
            starts[test["id"]] = test
        elif kind == "testDone":
            identity = event["testID"]
            assert identity in starts and identity not in completions
            assert event["result"] == "success" and not event["skipped"]
            completions[identity] = event
        elif kind == "allSuites":
            all_suite_count.append(event["count"])
        elif kind == "done":
            terminal.append(event["success"])
        elif kind == "start":
            runner_start_count += 1
        elif kind == "error":
            error_events.append(event)
    assert runner_start_count == 1 and terminal == [True]
    assert not error_events and starts.keys() == completions.keys()
    assert all_suite_count == [len(suite_map)]
    assert not non_json or all(line.startswith(("Running build hooks", "  Building native assets")) for line in non_json), (name, non_json)
    for identity, event in completions.items():
        test = starts[identity]
        if event.get("hidden") or test["name"] in ("(setUpAll)", "(tearDownAll)"):
            continue
        suite = suite_map[test["suiteID"]]
        raw_path = suite["path"]
        if "/quds_office_suite/" in raw_path:
            path = raw_path.split("/quds_office_suite/", 1)[1]
        else:
            path = str(Path(cohort_paths[cohort]) / raw_path)
        case_identities.append((path, test["name"]))
        unique_cases.add((path, test["name"]))
        unique_suites.add(path)
    assert len(case_identities) == len(set(case_identities))
    cohorts.append({"name": cohort, "executions": len(case_identities), "suite_platform_executions": len(suite_map), "failures": 0, "skips": 0, "complete_starts_and_completions": True, "terminal_success": True})

python_counts = []
for name in [
    "qualification-release-store/results/runner-regressions.log",
    "qualification-release-support/qualification-runner.log",
    "qualification-release-support/runtime-replay.log",
]:
    raw = content[name].decode()
    matches = re.findall(r"Ran (\d+) tests? in", raw)
    assert len(matches) == 1 and re.search(r"\nOK\s*$", raw)
    python_counts.append({"member": name, "passed": int(matches[0])})

report = {
    "evidence_ref": evidence_ref,
    "qualified_source": source_ref,
    "reviewed_head": args.head,
    "incoming_head": args.incoming,
    "archive": {"sha256": sha(archive_bytes), "bytes": len(archive_bytes), "members_verified": len(content)},
    "distinct_bound_source_inputs": len(union),
    "qualified_blob_sha256_checked": len(blob_hashes),
    "source_manifest_comparisons": comparisons,
    "raw_reporter_recount": {
        "cohorts": cohorts,
        "application_case_executions": sum(item["executions"] for item in cohorts),
        "suite_platform_executions": sum(item["suite_platform_executions"] for item in cohorts),
        "distinct_test_files": len(unique_suites),
        "distinct_file_name_case_identities": len(unique_cases),
        "python_control_logs": python_counts,
        "python_controls": sum(item["passed"] for item in python_counts),
    },
    "tests_executed_by_this_review": False,
    "github_actions_queried": False,
    "scope": "Independent committed-archive readback, raw-event recount and immutable Git source comparison. Historical results are not rerun or relabeled. Runtime snapshots are checked for saved before/after equality; current runtime bytes are not available to this review.",
}
assert report["raw_reporter_recount"]["application_case_executions"] == 836
assert report["raw_reporter_recount"]["suite_platform_executions"] == 85
assert report["raw_reporter_recount"]["distinct_test_files"] == 73
assert report["raw_reporter_recount"]["python_controls"] == 78
Path(args.output).write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
