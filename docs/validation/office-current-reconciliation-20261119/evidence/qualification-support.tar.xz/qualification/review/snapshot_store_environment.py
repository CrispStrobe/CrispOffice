"""Capture the prior native gate's complete source/runtime set around Store."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("--repo", required=True, type=Path)
parser.add_argument("--runtime", required=True, type=Path)
parser.add_argument("--native", required=True, type=Path)
parser.add_argument("--head", required=True)
parser.add_argument("--output", required=True, type=Path)
args = parser.parse_args()
repo = args.repo.resolve()
head = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
assert head == args.head


def sha(path):
    if not path.is_file():
        return None
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


source = json.loads((args.native / "source-before.json").read_text())
environment = json.loads((args.native / "environment-before.json").read_text())
source_snapshot = {name: sha(repo / name) for name in source}
runtime_snapshot = {}
runtime_paths = {}
for name in environment:
    if name.startswith("runtime/"):
        candidate = args.runtime / name[len("runtime/"):]
    elif name.startswith("additional/"):
        candidate = Path(name[len("additional/"):])
    elif name == "workspace/package_config.json":
        candidate = repo / ".dart_tool/package_config.json"
    elif name == "workspace/native_assets.yaml":
        candidate = repo / ".dart_tool/native_assets.yaml"
    elif name.startswith("workspace/"):
        candidate = repo / name[len("workspace/"):]
    elif name == "sdk/flutter_tools/package_config.json":
        candidate = args.runtime / "flutter/packages/flutter_tools/.dart_tool/package_config.json"
    else:
        raise AssertionError(("Unknown runtime mapping", name))
    runtime_snapshot[name] = sha(candidate)
    runtime_paths[name] = str(candidate)
record = {
    "captured_at_utc": datetime.now(timezone.utc).isoformat(),
    "source_commit": head,
    "source_tree": subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD^{tree}"], text=True).strip(),
    "source_inputs": source_snapshot,
    "runtime_inputs": runtime_snapshot,
    "runtime_paths": runtime_paths,
    "matches_prior_native_source": source_snapshot == {name: record["sha256"] for name, record in source.items()},
    "matches_prior_native_runtime": runtime_snapshot == environment,
    "scope": "Full source and runtime input set from the preceding native qualification manifest. A before/after pair bounds the subsequent Store execution interval.",
    "snapshot_script_sha256": sha(Path(__file__)),
}
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"output": str(args.output), "source_inputs": len(source_snapshot), "runtime_inputs": len(runtime_snapshot), "matches_prior_native_source": record["matches_prior_native_source"], "matches_prior_native_runtime": record["matches_prior_native_runtime"]}))
assert record["matches_prior_native_source"], "Source drift captured in the saved snapshot"
assert record["matches_prior_native_runtime"], "Runtime drift captured in the saved snapshot"
