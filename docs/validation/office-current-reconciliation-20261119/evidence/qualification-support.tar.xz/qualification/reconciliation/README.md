# Captured-reference and historical-equivalence audit

This frozen capture contains 411 actual references: 215 fork branches, 175 PR
heads, 17 tags and four upstream branches. `capture-provenance.json` records its
inputs. The fork input is a snapshot of fetched local remote refs; it is not an
atomic server advertisement and does not exclude later concurrent updates.

The proposed union of `55e262ef`, `ac1e4c8c` and `dd953dcc` accounts for 383
references through ancestry and 28 through 14 freshly verified historical
equivalents. The union result is a projection. It does not establish that a
merge commit or a correctly resolved merged tree exists.

## Historical proof method

The historical head list is read from the immutable record at
`0e84dc951e7a9e923107d7895fa457cf29a7af71` in
`docs/validation/thesaurus-20261118/resume/incoming-audit.json`.

- Three historical integration heads have exact complete-tree identity with
  existing ancestor commits; both tree IDs and ancestry are recomputed.
- The original ODT proof retains its recomputed complete 37-path delta and
  exact Git mode/type/blob identity at its recorded equivalent ancestor.
- Ten heads previously classified through patch equivalence are freshly
  verified by exact mode/type/blob identity for **every** changed path from
  their recomputed merge base. The audit searches reachable historical
  snapshots, records the matching ancestor commit and all file identities,
  and does not reuse old `git cherry` output. For the two-commit data-bar head,
  the complete delta includes its documentation predecessor.

These are historical source-preservation proofs. They do not make the original
historical heads into ancestors and do not assert that later application
changes leave those files unchanged.

## Audit an actual integrated commit

From this directory, substitute the actual source/merge SHA and repository path:

```bash
python3 audit_refs.py \
  --repo /absolute/path/to/quds_office_suite \
  --head ACTUAL_COMMIT_SHA \
  --refs captured-fork-refs.txt \
  --upstream-refs captured-upstream-refs.txt \
  --expected-total 411 \
  --output actual-head-audit.json
```

For refreshed inputs, supply the new capture files and corresponding expected
total. The expected total may be omitted when its value is unknown; the report
still exposes every row, counts, classification and unresolved reference.
Conflicting SHA values for the same captured reference are rejected.

Use repeated `--union-head` arguments instead of `--head` only for a projection.
`actual_integrated_graph_verified` remains false for all such projections,
including a successful coverage result.

The program exits nonzero for unaccounted references, missing objects, failed
historical proofs or a reference-count mismatch. The retained negative-control
`preintegration-audit.json`, targeted solely at `55e262ef`, correctly fails on
the Mail branch and PR, `ac1e4c8c` and `dd953dcc`; its 14 historical proofs still
pass. `anticipated-union-audit.json` passes the projected coverage checks.

Git lazy fetching is disabled. The audit reads immutable Git objects and makes
no network, GitHub Actions, checkout, index or ref mutations. It writes only
the selected JSON output. It records HEAD/ref/index observations before and
after; concurrent edits can change these observations without changing the
immutable commits being audited. This is a graph/source audit, not a product
test or release-acceptance result.
