Option Explicit
Sub BuildReport()
  Worksheets("Summary").Range("A1").Value2 = 42
  Worksheets("Summary").Range("B1").Formula = "=A1*2"
End Sub
