from concurrent.futures import ThreadPoolExecutor
import hashlib, io, json, tarfile, time, urllib.request, urllib.parse
from pathlib import Path
import yaml
root=Path('/workspace/scratch/a0430e87e61f')
tool=root/'zotero-toolchain'
cache=tool/'pub-cache'
locks=[tool/'setup/flutter-tools-recorded.lock',root/'quds_office_suite/docs/validation/proofing-20261116/integration-resume/workspace-pubspec.lock']
locks.append(tool/'harness/quds_office_engine/pubspec.lock')
entries={}
for lock in locks:
    for name,p in yaml.safe_load(lock.read_text())['packages'].items():
        if p['source']!='hosted': continue
        d=p['description']
        assert d['url']=='https://pub.dev'
        key=name+'-'+p['version']
        entry={'name':name,'version':p['version'],'sha256':d['sha256']}
        assert key not in entries or entries[key]==entry
        entries[key]=entry
for path in (cache/'hosted/pub.dev',cache/'hosted-hashes/pub.dev',cache/'_temp'):
    path.mkdir(exist_ok=True,parents=True)
def fetch(pair):
    key,entry=pair
    target=cache/'hosted/pub.dev'/key
    mark=cache/'hosted-hashes/pub.dev'/(key+'.sha256')
    if target.exists() and mark.exists() and mark.read_text().strip()==entry['sha256']:
        return dict(entry,status='existing-verified-cache')
    url='https://pub.dev/api/archives/'+urllib.parse.quote(key,safe='-._+')+'.tar.gz'
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url,timeout=90) as response:
                data=response.read()
            break
        except Exception:
            if attempt==2: raise
    actual=hashlib.sha256(data).hexdigest()
    assert actual==entry['sha256'],key
    tmp=cache/'_temp'/('restored-'+key)
    tmp.mkdir(exist_ok=False)
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
        archive.extractall(tmp,filter='data')
    if target.exists():
        import shutil
        shutil.rmtree(tmp)
    else:
        tmp.rename(target)
    mark.write_text(actual)
    print('verified '+key,flush=True)
    return dict(entry,status='verified-download',url=url,archive_bytes=len(data))
with ThreadPoolExecutor(max_workers=16) as pool:
    results=list(pool.map(fetch,sorted(entries.items())))
(tool/'logs/pub-cache-receipt.json').write_text(json.dumps({'locks':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in locks},'packages':results},indent=2)+'\n')
print('verified packages '+str(len(results)))
