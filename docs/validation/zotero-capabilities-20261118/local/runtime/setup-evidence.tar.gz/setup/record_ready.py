from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
root=Path('/workspace/scratch/a0430e87e61f')
tool=root/'zotero-toolchain'
repo=root/'quds_office_suite'
ws=root/'zotero-validation'
sdk=tool/'flutter-sdk'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
log=(tool/'logs/flutter-version.log').read_text()
version=json.loads(log[log.index('{'):])
config=json.loads((ws/'.dart_tool/package_config.json').read_text())
manifest_paths=['pubspec.yaml']+[str(p.relative_to(repo)) for p in (repo/'packages').rglob('pubspec.yaml') if p.parent.is_dir() and (ws/p.relative_to(repo)).exists()]+['apps/quds_report_studio/pubspec.yaml']
manifest_paths=sorted(set(manifest_paths))
receipt={
 'status':'ready', 'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
 'sdk':str(sdk),'workspace':str(ws),'source':str(repo),'environment_script':str(tool/'env.sh'),
 'runtime':version,'dart_sha256':sha(sdk/'bin/cache/dart-sdk/bin/dart'),
 'flutter_tester_sha256':sha(sdk/'bin/cache/artifacts/engine/linux-x64/flutter_tester'),
 'framework_tracked_changes':subprocess.check_output(['git','diff','--name-only'],cwd=sdk,text=True).splitlines(),
 'flutter_tools_lock_sha256':sha(sdk/'packages/flutter_tools/pubspec.lock'),
 'flutter_tools_recorded_lock_sha256':sha(tool/'setup/flutter-tools-recorded.lock'),
 'workspace_lock_sha256':sha(ws/'pubspec.lock'),
 'workspace_recorded_lock_sha256':sha(repo/'docs/validation/proofing-20261116/integration-resume/workspace-pubspec.lock'),
 'workspace_package_count':len(config['packages']),
 'workspace_manifest_matches':{p:sha(repo/p)==sha(ws/p) for p in manifest_paths},
 'package_config_sha256':sha(ws/'.dart_tool/package_config.json'),
 'source_graph_link':str(repo/'.dart_tool'),
 'source_graph_target':str((repo/'.dart_tool').resolve()),
 'pub_archive_count':len(json.loads((tool/'logs/pub-cache-receipt.json').read_text())['packages']),
 'setup_smoke_tests':[
 {'command':'dart test test/zotero_catalog_query_test.dart --reporter expanded','cwd':str(tool/'harness/quds_office_engine'),'passed':18,'exit_code':0,'log':'engine-query-smoke.log'},
 {'command':'flutter test --no-pub test/word_zotero_format_test.dart --reporter expanded','cwd':str(ws/'packages/quds_office_editor'),'passed':31,'exit_code':0,'log':'editor-format-smoke.log'}],
 'setup_notes':[
 'All engine/framework binaries and hosted packages are genuine official downloads; no mock runtime packages were used.',
 'Initial workspace resolver failed before sky_engine was downloaded; final exact-lock offline resolver passed after official precache.',
 'Initial engine resolver lacked six versions from its distinct recorded lock; six exact official archives were added, final exact-lock offline resolver passed.',
 'The engine-only wrapper strips workspace resolution from copies of current engine/parser manifests; sources are symlinked and tracked manifests are unchanged.',
 'The main external workspace copies current manifests verbatim and exposes current sources by symlinks.',
 'Initial symlink-only analysis could not resolve source package imports; an ignored source .dart_tool link now points at the generated exact workspace graph.',
 'Strict analysis then found one real use_null_aware_elements lint in the new engine query code and reported it to parent; no claim of passed source analysis is made here.',
 'Official precache called with disabled platform flags downloads defaults; use explicit --universal for future minimal caches.',
 'Smoke executions overlap later product validation and must not be added to final counts.'
 ],
 'logs_sha256':{p.name:sha(p) for p in sorted((tool/'logs').iterdir()) if p.is_file()}
}
assert receipt['dart_sha256']=='01e869e4af277734b02ab8898b870c6b00c9bec61bbcf9c923cd14de7ed85fbb'
assert receipt['flutter_tester_sha256']=='800f4ca182df7dd2fb46a42dea5d76277b9dbc5e8cd2915e02bcbc978681b45f'
assert receipt['workspace_lock_sha256']==receipt['workspace_recorded_lock_sha256']
assert receipt['flutter_tools_lock_sha256']==receipt['flutter_tools_recorded_lock_sha256']
assert not receipt['framework_tracked_changes']
assert all(receipt['workspace_manifest_matches'].values())
(tool/'runtime-ready.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'ready','packages':receipt['workspace_package_count'],'manifest_count':len(manifest_paths),'pub_archive_count':receipt['pub_archive_count'],'receipt':str(tool/'runtime-ready.json')}))
