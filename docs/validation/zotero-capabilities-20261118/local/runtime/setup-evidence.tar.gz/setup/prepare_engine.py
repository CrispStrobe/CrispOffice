import json, hashlib
from pathlib import Path
root=Path('/workspace/scratch/a0430e87e61f')
repo=root/'quds_office_suite'
tool=root/'zotero-toolchain'
r=json.loads((repo/'docs/validation/zotero-citing-20261115/setup-receipt.json').read_text())
for name in ('quds_office_engine','legacy_doc_parser'):
    src=repo/'packages'/name
    dst=tool/'harness'/name
    dst.mkdir(parents=True,exist_ok=True)
    manifest=(src/'pubspec.yaml').read_text().replace('resolution: workspace\n','')
    (dst/'pubspec.yaml').write_text(manifest)
    for sub in ('lib','test','tool'):
        if (src/sub).exists():
            (dst/sub).symlink_to(src/sub,target_is_directory=True)
    (dst/'analysis_options.yaml').write_bytes((repo/'analysis_options.yaml').read_bytes())
(tool/'harness/quds_office_engine/pubspec.lock').write_text(r['harnesses']['engine']['lockfile_text'])
print('Engine harness prepared without production manifest mutation')
