export FLUTTER_ROOT=/workspace/scratch/a0430e87e61f/zotero-toolchain/flutter-sdk
export PUB_CACHE=/workspace/scratch/a0430e87e61f/zotero-toolchain/pub-cache
export TMPDIR=/workspace/scratch/a0430e87e61f/zotero-toolchain/tmp
export XDG_CONFIG_HOME=/workspace/scratch/a0430e87e61f/zotero-toolchain/config
export PATH="$FLUTTER_ROOT/bin:$PATH"
export CI=true DART_SUPPRESS_ANALYTICS=true FLUTTER_SUPPRESS_ANALYTICS=true
