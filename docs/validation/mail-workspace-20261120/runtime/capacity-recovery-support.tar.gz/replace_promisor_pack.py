from pathlib import Path
import subprocess, os, json, hashlib, shutil, datetime
REPO=Path('/workspace/scratch/8e9460dcd580/quds_office_suite')
OUT=Path('/workspace/scratch/8e9460dcd580/runtime/capacity-recovery-2')
os.chdir(REPO)
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def git(*args,**kw):
    result=subprocess.run(['git',*args],capture_output=True,env=ENV,**kw)
    if result.returncode: raise RuntimeError(str(args)+': '+result.stderr.decode()[:2000])
    return result.stdout
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda:handle.read(1048576),b''): h.update(block)
    return h.hexdigest()
def save(name,data):
    path=OUT/name
    with path.open('w') as handle:
        json.dump(data,handle,indent=2);handle.write('\n');handle.flush();os.fsync(handle.fileno())
def metadata():
    lines=git('cat-file','--batch-all-objects','--batch-check=%(objectname) %(objecttype)').decode().splitlines()
    return sorted(line for line in lines if line.split()[1] in ['commit','tree','tag'])
plan=json.loads((OUT/'pack-plan.json').read_text())
old=Path(plan['pack']);oldidx=old.with_suffix('.idx');oldmarker=old.with_suffix('.promisor')
assert old.exists() and oldmarker.exists()
assert git('config','--get','remote.origin.promisor').strip()==b'true'
assert git('config','--get','remote.origin.partialclonefilter').strip()==b'blob:none'
assert json.loads((OUT/'promisor-recovery-probe.json').read_text())['exit_code']==0
keep=set(plan['retained_object_ids'])
refs=git('show-ref','--head');staged=git('ls-files','--stage','-z');meta=metadata()
head=git('rev-parse','HEAD').decode().strip();old_hash=sha(old);old_stat=old.stat()
verification=git('verify-pack','-v',str(oldidx)).decode().splitlines()
old_objects={parts[0]:parts[1] for line in verification if len(parts:=line.split())>=5 and parts[1] in ['blob','tree','commit','tag']}
assert len(old_objects)==plan['object_count']
assert set(old_objects)==keep|{entry['oid'] for entry in plan['drop_objects']}
assert set(old_objects.values())=={'blob'}
print('Original promisor pack verified; building retained pack in memory.',flush=True)
fd=os.memfd_create('quds-retained-promisor-pack',0)
with (OUT/'retained-objects.txt').open('rb') as inputs:
    result=subprocess.run(['git','-c','pack.threads=1','pack-objects','--stdout','--no-reuse-delta','--window=0','--depth=0','--compression=1'],stdin=inputs,stdout=fd,stderr=subprocess.PIPE,env=ENV)
assert result.returncode==0,result.stderr.decode()
new_size=os.fstat(fd).st_size
idx=OUT/'retained-memory.idx'
result=subprocess.run(['git','index-pack','--strict','-o',str(idx),f'/proc/self/fd/{fd}'],capture_output=True,pass_fds=(fd,),env=ENV)
assert result.returncode==0,result.stderr.decode()
pack_oid=result.stdout.decode().strip().split()[-1]
assert len(pack_oid)==40 and all(x in '0123456789abcdef'for x in pack_oid)
with idx.open('rb') as handle:
    result=subprocess.run(['git','show-index'],stdin=handle,capture_output=True,env=ENV)
assert result.returncode==0,result.stderr.decode()
indexed={line.split()[1] for line in result.stdout.decode().splitlines()}
assert indexed==keep,(len(indexed),len(keep))
os.lseek(fd,0,os.SEEK_SET);memory_hash=hashlib.sha256()
while chunk:=os.read(fd,1048576): memory_hash.update(chunk)
new_hash=memory_hash.hexdigest()
assert git('show-ref','--head')==refs
assert git('ls-files','--stage','-z')==staged
assert metadata()==meta
assert old.stat().st_size==old_stat.st_size and sha(old)==old_hash
pins=json.loads((OUT/'pins-before.json').read_text())
assert all(sha(v['path'])==v['sha256'] for v in pins.values())
ready={'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'old_pack':str(old),'old_pack_bytes':old_stat.st_size,'old_pack_sha256':old_hash,'new_pack_oid':pack_oid,'new_pack_bytes':new_size,'new_pack_sha256':new_hash,'retained_object_count':len(keep),'exact_retained_object_set_verified':True,'git_index_pack_strict_exit':0,'old_pack_has_only_blobs':True,'metadata_object_count':len(meta),'remote_recovery_probe_verified':True,'free_before_retirement':shutil.disk_usage(REPO).free}
save('retention-ready.json',ready)
print(json.dumps({'phase':'retained pack verified in memory','new_bytes':new_size,'retained_objects':len(keep),'free_bytes':ready['free_before_retirement']}),flush=True)
packdir=old.parent;newpack=packdir/f'pack-{pack_oid}.pack';newidx=newpack.with_suffix('.idx');newmarker=newpack.with_suffix('.promisor')
assert not newpack.exists()
marker_bytes=oldmarker.read_bytes()
shutil.copyfile(idx,newidx)
with newidx.open('rb') as handle: os.fsync(handle.fileno())
newmarker.write_bytes(marker_bytes)
temp=packdir/f'.retained-{pack_oid}.tmp'
old.unlink()
with temp.open('w+b') as output:
    os.posix_fallocate(output.fileno(),0,new_size)
    os.lseek(fd,0,os.SEEK_SET)
    while chunk:=os.read(fd,1048576): output.write(chunk)
    output.flush();os.fsync(output.fileno())
assert sha(temp)==new_hash
os.replace(temp,newpack)
for suffix in ['.idx','.promisor','.rev','.bitmap']:
    path=old.with_suffix(suffix)
    if path.exists(): path.unlink()
os.close(fd)
verify=git('verify-pack','-v',str(newidx)).decode().splitlines()
actual={parts[0] for line in verify if len(parts:=line.split())>=5 and parts[1] in ['blob','tree','commit','tag']}
assert actual==keep
assert git('show-ref','--head')==refs
assert git('ls-files','--stage','-z')==staged
assert metadata()==meta
assert all(sha(v['path'])==v['sha256'] for v in pins.values())
fsck=subprocess.run(['git','fsck','--connectivity-only','--no-dangling','--no-reflogs'],capture_output=True,env=ENV)
(OUT/'git-connectivity.stdout').write_bytes(fsck.stdout);(OUT/'git-connectivity.stderr').write_bytes(fsck.stderr)
assert fsck.returncode==0,fsck.stderr.decode()[:2000]
final={**ready,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_pack':str(newpack),'old_pack_removed_after_memory_verification':True,'new_disk_pack_verified':True,'metadata_objects_identical':True,'refs_identical':True,'index_entries_identical':True,'seven_pins_identical':True,'connectivity_exit_code':fsck.returncode,'net_pack_bytes_reclaimed':old_stat.st_size-new_size,'free_after_pack_replacement':shutil.disk_usage(REPO).free}
save('pack-replacement.json',final)
print(json.dumps({'phase':'verified pack replacement complete','reclaimed_bytes':final['net_pack_bytes_reclaimed'],'free_bytes':final['free_after_pack_replacement'],'seven_pins_identical':True}),flush=True)
