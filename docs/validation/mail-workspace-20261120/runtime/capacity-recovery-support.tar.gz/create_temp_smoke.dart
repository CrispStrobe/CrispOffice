import 'dart:convert';
import 'dart:io';

void main() {
  Directory? directory;
  final result = <String, Object?>{
    'startedAtUtc': DateTime.now().toUtc().toIso8601String(),
    'runtime': Platform.version,
    'executable': Platform.resolvedExecutable,
    'systemTemp': Directory.systemTemp.path,
    'tmpdirEnvironment': Platform.environment['TMPDIR'],
    'effectiveUid': Process.runSync('id', ['-u']).stdout.toString().trim(),
  };
  try {
    if (Directory.systemTemp.path !=
        '/workspace/scratch/8e9460dcd580/runtime/tmp') {
      throw StateError('Unexpected temporary directory');
    }
    directory = Directory.systemTemp.createTempSync('quds-capacity-');
    result['createdTemporaryDirectory'] = true;
    final file = File('${directory.path}/write-probe.bin');
    final bytes = List<int>.generate(4 * 1024 * 1024, (index) => index % 251);
    file.writeAsBytesSync(bytes, flush: true);
    final read = file.readAsBytesSync();
    if (read.length != bytes.length) throw StateError('Length mismatch');
    for (var index = 0; index < read.length; index++) {
      if (read[index] != bytes[index]) throw StateError('Readback mismatch');
    }
    result['writtenAndReadBytes'] = read.length;
    result['readbackMatched'] = true;
  } finally {
    directory?.deleteSync(recursive: true);
    result['temporaryDirectoryDeleted'] =
        directory == null || !directory.existsSync();
    result['finishedAtUtc'] = DateTime.now().toUtc().toIso8601String();
    stdout.writeln(jsonEncode(result));
  }
}
