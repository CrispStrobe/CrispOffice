import 'package:flutter_test/flutter_test.dart';
import 'package:sqlite3/sqlite3.dart';

void main() {
  test('runtime setup opens the authentic SQLite native asset', () {
    final db = sqlite3.openInMemory();
    try {
      db.execute('CREATE TABLE runtime_smoke (value INTEGER NOT NULL)');
      db.execute('INSERT INTO runtime_smoke VALUES (42)');
      expect(db.select('SELECT value FROM runtime_smoke').single['value'], 42);
      expect(db.select('SELECT sqlite_version()').single.values.single, isA<String>());
    } finally {
      db.close();
    }
  });
}
