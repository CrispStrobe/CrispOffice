# Local Quds Office validation runtime

The official Flutter 3.47.8 Linux x64 release archive was downloaded from its official Google Storage URL and SHA-256 verified before extraction. The independently fetched official release index agrees with revision `737ba8f885dc774b53b442759999a312c9461e4e`, Dart 3.13.7 and archive hash `baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2`. Node is 24.22.3.

`runtime-ready.json` records the exact release data, workspace/SDK lockfile hashes, source-manifest comparisons, initial setup attempts and smoke results. `setup/prefetch-135.json` and `setup/prefetch-101.json` preserve exact root and Flutter-tools hosted archive verifications. No source manifests, lockfiles, dependency policy or SDK source were changed. No GitHub Actions/check/status endpoint was queried.

## Use

```sh
source /workspace/scratch/11a0888870d6/runtime/env.sh
cd /workspace/scratch/11a0888870d6/validation-workspace/packages/quds_office_engine
/workspace/scratch/11a0888870d6/runtime/run_dart_test.sh test/example_test.dart --reporter json
```

The wrapper executes the authentic locked package:test 1.31.1 runner using the explicit isolated package config. Ordinary `dart test` was interrupted after producing no events during tool startup; the direct runner avoids implicit tool dependency resolution. The wrapper accepts normal package:test arguments, including `--platform node`.

```sh
source /workspace/scratch/11a0888870d6/runtime/env.sh
cd /workspace/scratch/11a0888870d6/validation-workspace/packages/quds_office_editor
flutter test --no-pub test/example_test.dart --reporter json
```

For static analysis from the actual source checkout:

```sh
dart analyze --packages=/workspace/scratch/11a0888870d6/validation-workspace/.dart_tool/package_config.json --fatal-infos --format=machine <paths>
dart format --language-version=3.12 --output=none --set-exit-if-changed <paths>
```

All 19 workspace package manifests and the current root lockfile are exact copies. `lib`, `test`, fixture and asset paths are live links to the source checkout. Top-level `third_party`, `tool`, `tools` and `docs` are linked unchanged, preserving local path dependencies. New files written into linked source directories are visible immediately. If manifests change, rerun `prepare_workspace.py`, preserve the selected lockfile, fetch its exact archives and run `dart pub get --offline --enforce-lockfile` in the isolated root.

## Setup smoke only

The engine document-data suite passed 49 cases and the editor formatting suite passed 31 cases, with process exit zero, successful terminal JSON events, zero failures and zero skips. These prove runtime readiness only; they are not claimed as acceptance of the new transfer work. Raw events remain in `logs`.

The unchanged locked `sqlite3-3.9.1` build hook also downloaded its authentic Linux x64 native asset. A runtime-only in-memory SQLite create/insert/select smoke passed one case using Flutter from the Studio example workspace. The 1,823,736-byte library has SHA-256 `0a65852703763619a7a34633b4959b3b86c4103804a4dfe4e8b27b5de1c0647b`, matching the package's expected hash and incoming Mail receipt. `setup/sqlite-native-ready.json` records its exact paths and raw runtime-smoke events. No system substitute or package source edit was used.

## Source-bound cohorts

`qualify_cohort.py` captures source inputs before/after, the exact runtime command, raw JSON/stderr, visible cases and process result. `--platform vm|node` selects the engine target; Flutter runs on its normal VM test target. An optional `--expected-skips setup/layout-expected-skips.json` accepts only the eight named pre-existing image-only fixtures with the exact `no paragraphs to edit` reason. Skips remain separate from passes. Unexpected skip names or reasons fail acceptance.

`setup/editor-final-cohort.json` prepares the 77-suite union of all 49 editor Zotero suites, all 27 proofing/spelling/language suites and the updated layout equivalence suite. It is a launch plan, not a result; the parent must announce source freeze before execution.

## Final editor qualification

The complete 77-suite union was accepted against frozen product commit `9228cb58e960ed9a6c0e91f2531e539c58689364`: **1,369 passed, zero failures/errors, eight explicitly excluded image-only layout fixtures**. The breakdown is 892 passes in 49 Zotero suites, 407 passes in 27 proofing/spelling/language suites, and 70 passes plus eight exclusions in the updated layout-equivalence suite. Both new layout exception-retry cases passed.

The initial concurrent Flutter attempt stopped producing output at two suite-loading sentinels after 641 passing cases. That run was interrupted and retained as unaccepted evidence in `qualification/editor-final-77/interrupted-summary.json`. Its passes are excluded from final acceptance totals. Fresh serial runs of those two files passed 36 cases in 8.7 seconds. Five further disjoint 15-file cohorts completed the full union. Each accepted cohort has a successful terminal event, exit zero and unchanged source inputs. All six source manifests exactly match the same frozen 1,723-input set. No files are missing or duplicated. `qualification/editor-serial-summary.json` records the complete reconciliation; raw events and individual receipts are in `qualification/editor-serial-01` through `editor-serial-06`.

The qualification runner now supports optional `--idle-timeout` and `--max-runtime` bounds. These record process diagnostics inside the executing PID namespace and gracefully stop only the spawned process group on timeout. Interruptions remain failures and preserve a final receipt. The final editor cohorts used concurrency one, a 150-second idle bound and 900-second overall bound; none required watchdog intervention. The receipt also records `QUDS_TYPING_BENCHMARK` so Studio benchmark gating is explicit. No source, SDK or dependency implementation was changed to obtain these results.
