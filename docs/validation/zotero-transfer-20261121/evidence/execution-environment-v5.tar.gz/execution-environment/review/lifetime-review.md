# Independent native Mail lifetime review

## Finding

The four raw closed-database rollback errors in the first 185-case Studio run are explained by the cached-host fixture bypassing the production host's asynchronous cancellation sequence. The test JSON stream passed, but the raw output contained unhandled errors and that run is rejected. No missing cancellation await was found in the native/EWS host paths reviewed.

## Source trace

`SqliteStudioMailDraftStore._serialize` queues ordinary draft, body and metadata operations. Its `close()` sets the closing guard and awaits `_pending` before closing its owned repository. This does not encompass independently subscribed mailbox view streams.

`SqliteStudioMailMailboxStore.watchView` delegates directly to `SqliteMailRepository.watchMailboxView`. A snapshot read uses a database transaction. The stream's cancellation callback cancels the update subscription and awaits its active `reading` future. `StudioMailMailboxSession.close()` awaits that subscription cancellation before finishing.

Both native IMAP and EWS host disposal start `_stopCachedView()`. Their `_closeDraftStore()` then awaits `_mailboxViewClosing` and pending foreground flag work before invoking the storage owner's close. Synchronous Flutter widget disposal initiates this sequence; it does not itself await completion.

The old cached-host fixture removed the widget with `pumpWidget`, then directly invoked `owner.close()` in teardown. That second close could reach the database before the host's outstanding watcher cancellation had drained. The fixture therefore bypassed the ordering the production host implements.

The pinned Drift implementation corroborates the observed stack. A remote close requests `terminateAll`; server shutdown closes the connection. Closing a channel then abandons its remaining managed transaction executors. `_abandonExecutor` rolls those transactions back. If the database has already closed, SQLite reports exactly the observed `This database has already been closed` error. Conversely, the ordinary `transaction()` exception path explicitly awaits rollback before propagating a failed operation, so the injected before-commit fault did not reveal an unawaited rollback in that path.

## Correction and evidence boundary

The research agent's narrow fixture correction observes and awaits the host-initiated owner-close completion, including its error completion, rather than initiating another close. Four provider regressions hold watcher cancellation, verify the owner remains open, release cancellation, and verify both cancellation and close finish. The unchanged-source IMAP pair reproduced one raw error; the corrected pair plus disposal regression passed three cases with no raw error. The complete eight-suite Studio gate subsequently passed 189 cases with zero failures/skips, a normal successful exit, empty raw diagnostic and non-JSON output lists, empty stderr, and all 1,665 captured inputs unchanged. Its version-5 receipt is `runtime/qualification/studio-transfer-raw-clean-final/summary.json`; the benchmark environment was explicitly enabled.

This review does not claim arbitrary external calls to repository `close()` safely drain an unrelated in-flight watcher. The host/session lifetime contract reviewed requires cancellation and draining before owner release; the corrected fixture now exercises that contract. No production source or pinned dependency was edited for this finding.

## Acceptance improvement

Runtime qualifier version 5 additionally scans stdout and stderr for raw Flutter error/fatal lines, unhandled exceptions/rejections, fatal runtime failures and compiler diagnostics. Such output rejects acceptance even when test JSON reports success. The previous 185-case receipt remains untouched; `runtime/qualification/studio-transfer-serial-final/raw-diagnostic-audit.json` records its four raw failures and hashes. The accepted editor, engine VM, engine Node and incoming Word cohorts were independently scanned and contain no such raw diagnostics.
