# Execution environment evidence

This bundle retains official SDK release/checksum metadata, exact dependency
locks and package configuration, source/validation manifest equality proof,
hosted-archive verification receipts, setup logs and smoke events, commands,
tool versions, and reference orchestration scripts. SDK binaries and package
caches are omitted. Setup smoke counts are not final product acceptance.

The earlier accepted engine receipts record runner version 3 (before watchdog
support). Its exact harness bytes were not snapshotted. The retained
qualify_cohort.py is the current version 4 reference runner, not reconstructed
version 3. Independent verification derives results directly from retained raw
events, case identities, commands, and source hashes. Original absolute paths
are historical metadata; verify_qualification.py never needs them to exist.

The archive records its capture's scripts and metadata; reproducing a test run
requires installing the recorded SDK/dependencies and mapping the command's
workspace paths to a checkout. The standalone verifier needs only Python and
the indexed archives. No historical Mail117 run is relabeled as fresh here.


## Version 5 supplement

This separate immutable bundle retains the actual version 5 runner and its
sibling raw-output scanner used for the clean 189-case Studio run. It keeps
the original environment metadata and locks, and adds the retrospective raw
diagnostic audit and independent Mail lifetime review. Earlier version 3/4
receipts are unchanged. The original version 3 harness bytes remain unavailable.
The 185-case Studio run is rejected because raw asynchronous errors occurred;
the clean 189-case run is historical after the later publication-main merge.
The retrospective audit also lists focused diagnostic runs outside the release
cohorts; those entries do not add accepted test counts.
