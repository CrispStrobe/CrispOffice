#!/usr/bin/env python3
"""Detect fatal runtime/compiler output that can bypass test JSON events."""
import argparse
import hashlib
import json
from pathlib import Path
import re

PATTERNS = (
    ('flutter_error', re.compile(r'\[(?:ERROR|FATAL):flutter/[^\]]+\]', re.IGNORECASE)),
    ('unhandled_exception', re.compile(r'^\s*(?:Shell:\s*)?Unhandled\s+(?:exception|error|rejection)\b', re.IGNORECASE)),
    ('unhandled_promise_rejection', re.compile(r'^\s*(?:Shell:\s*)?(?:UnhandledPromiseRejection|uncaughtException|uncaught\s+exception)\b', re.IGNORECASE)),
    ('fatal_runtime_error', re.compile(r'^\s*(?:Shell:\s*)?(?:Fatal error:|FATAL:|(?:Dart|Flutter)\s+(?:VM|runtime)\s+error:|Segmentation fault\b)', re.IGNORECASE)),
    ('dart_compile_error', re.compile(r'^\s*(?:Shell:\s*)?(?:[^\s]+\.dart:\d+:\d+:\s*Error:|Error:\s+(?:Compilation failed|The method|The getter|The setter|Type\s+.+not found|Couldn.t resolve)|Failed to compile\b|Compilation failed\b)', re.IGNORECASE)),
)

def scan_files(paths):
    diagnostics = []
    for path in paths:
        path = Path(path)
        if not path.is_file():
            continue
        for number, line in enumerate(path.read_text(errors='replace').splitlines(), 1):
            message = line
            try:
                event = json.loads(line)
            except ValueError:
                pass
            else:
                # An actual forwarded print can contain shell diagnostics. Do
                # not scan test names or quoted expected values as raw errors.
                if not isinstance(event, dict) or event.get('type') != 'print':
                    continue
                message = str(event.get('message', ''))
            for segment in message.splitlines():
                matches = [name for name, pattern in PATTERNS if pattern.search(segment)]
                if matches:
                    diagnostics.append({'file':path.name,'line':number,
                                        'kinds':matches,'message':segment})
    return diagnostics

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('directory', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    paths = [args.directory/'stdout.jsonl', args.directory/'stderr.log']
    findings = scan_files(paths)
    receipt = {'directory':str(args.directory),'raw_diagnostics':findings,
               'raw_diagnostic_count':len(findings),'raw_diagnostics_clean':not findings,
               'files':{str(path.name):hashlib.sha256(path.read_bytes()).hexdigest()
                        for path in paths if path.is_file()}}
    if args.output:
        args.output.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
    return 1 if findings else 0

if __name__ == '__main__':
    raise SystemExit(main())
