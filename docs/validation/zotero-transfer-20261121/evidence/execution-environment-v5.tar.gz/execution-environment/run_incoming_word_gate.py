#!/usr/bin/env python3
"""Run the reconciled Word automation gate with source-bound local receipts."""
import base64
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/11a0888870d6')
SOURCE = ROOT / 'quds_office_suite'
RUNTIME = ROOT / 'runtime'
WORKSPACE = ROOT / 'validation-workspace'
PACKAGE = 'packages/quds_office_engine'
ENGINE = SOURCE / PACKAGE
WORK_ENGINE = WORKSPACE / PACKAGE
DART = RUNTIME / 'flutter-sdk/bin/cache/dart-sdk/bin/dart'
CONFIG = WORKSPACE / '.dart_tool/package_config.json'
OUT = RUNTIME / 'qualification/incoming-word-engine-extra'

CHANGED = [
    'office_macro_word_orientation_test.dart',
    'office_macro_word_section_start_test.dart',
    'office_vba_word_sections_test.dart',
    'office_vba_word_sections_integration_test.dart',
    'office_vba_word_page_setup_test.dart',
    'office_vba_word_page_setup_integration_test.dart',
]
NATIVE = [
    'office_operations_test.dart', 'office_steps_test.dart',
    'word_steps_vocabulary_test.dart', 'word_step_atomicity_test.dart',
    'word_structure_steps_test.dart', 'word_structure_integrity_test.dart',
    'word_section_clone_fidelity_test.dart',
    'word_header_picture_identity_test.dart',
    'word_header_visual_reconciliation_test.dart',
    'word_layout_test.dart', 'word_incremental_layout_test.dart',
    'fidelity_waves_test.dart',
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot():
    files = set()
    for relative in [
        'packages/quds_office_engine/lib',
        'packages/quds_office_engine/test',
        'packages/quds_office_engine/bin',
        'packages/quds_office_engine/tool',
        'packages/quds_office_engine/example/macros',
        'packages/legacy_doc_parser/lib',
        'packages/legacy_doc_parser/test/fixtures',
        'packages/quds_office_editor/fonts',
        'packages/quds_office_editor/example/fonts',
    ]:
        files.update(p for p in (SOURCE / relative).rglob('*') if p.is_file()
                     and not {'.dart_tool', 'build', '__pycache__'}.intersection(p.parts))
    files.update(SOURCE / p for p in ['pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'])
    return {str(p.relative_to(SOURCE)): sha(p) for p in sorted(files)}


def save_json(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def run(label, command, cwd=WORK_ENGINE):
    started = time.time()
    with (OUT / (label + '.stdout')).open('w') as stdout, (OUT / (label + '.stderr')).open('w') as stderr:
        result = subprocess.run([str(x) for x in command], cwd=cwd, env=os.environ,
                                stdout=stdout, stderr=stderr)
    record = {'label': label, 'command': [str(x) for x in command], 'cwd': str(cwd),
              'exit_code': result.returncode, 'seconds': round(time.time() - started, 3)}
    records.append(record)
    save_json('commands.json', records)
    print(json.dumps(record), flush=True)
    if result.returncode:
        raise RuntimeError(label + ' failed')


OUT.mkdir(parents=True, exist_ok=False)
records = []
portable = {}
before = snapshot()
(OUT / 'source-before.json.gz').write_bytes(gzip.compress(json.dumps(before, sort_keys=True).encode(), mtime=0))
head_before = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip()
tests = sorted({str(p.relative_to(ENGINE)) for pattern in ['office_macro*_test.dart', 'office_vba*_test.dart']
                for p in (ENGINE / 'test').glob(pattern)} | {'test/' + name for name in NATIVE})
save_json('test-files.json', tests)
error = None
try:
    # Strict analysis of all 59 changed Dart files has already passed at the
    # frozen source revision. Broad directory analysis through this symlinked
    # validation workspace produces duplicate URI identities; preserve those
    # rejected attempts and use the independently recorded source gate.
    analysis_receipt = RUNTIME / 'qualification/source-gates/summary.json'
    save_json('analysis-reuse.json', {'receipt': str(analysis_receipt),
                                   'sha256': sha(analysis_receipt),
                                   'reason': 'Reuse the passing frozen 59-file strict analyzer gate.'})
    # The 90-file cohort is running separately through qualify_cohort.py at
    # concurrency two. Its independent before/after receipt is linked below.
    for label, example, define, harness in [
        ('sections', 'word_sections.bas', 'WORD_SECTIONS_BAS_BASE64', 'web_vba_word_sections_smoke.dart'),
        ('page-setup', 'word_page_setup.bas', 'WORD_PAGE_SETUP_BAS_BASE64', 'web_vba_word_page_setup_smoke.dart'),
    ]:
        bas = (ENGINE / 'example/macros' / example).read_bytes()
        variable = '-D' + define + '=' + base64.b64encode(bas).decode()
        entry = WORK_ENGINE / 'tool/macros' / harness
        output = OUT / (label + '.js')
        run(label + '-vm', [DART, '--packages=' + str(CONFIG), variable, entry])
        run(label + '-compile-js', [DART, 'compile', 'js', '--packages=' + str(CONFIG),
                                   '-O1', variable, entry, '-o', output])
        run(label + '-js', [shutil.which('node'), '-e',
                           'globalThis.self=globalThis; require(process.argv[1]);', output])
        vm = (OUT / (label + '-vm.stdout')).read_bytes()
        js = (OUT / (label + '-js.stdout')).read_bytes()
        portable[label] = {'bas_sha256': hashlib.sha256(bas).hexdigest(),
                           'vm_js_byte_identical': vm == js, 'receipt': json.loads(vm),
                           'output_sha256': hashlib.sha256(vm).hexdigest()}
        if vm != js:
            raise RuntimeError(label + ' VM/JavaScript output mismatch')
except Exception as exc:
    error = str(exc)
finally:
    after = snapshot()
    (OUT / 'source-after.json.gz').write_bytes(gzip.compress(json.dumps(after, sort_keys=True).encode(), mtime=0))
    changed = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
    summary = {'status': 'passed' if error is None and not changed else 'failed',
               'error': error, 'source_head_before': head_before,
               'source_head_after': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip(),
               'source_input_count': len(before), 'source_changed_during_run': changed,
               'test_files': tests, 'commands': records, 'portable': portable,
               'package_config_sha256': sha(CONFIG), 'workspace_lock_sha256': sha(WORKSPACE / 'pubspec.lock'),
               'raw_test_receipt': '../incoming-word-engine-final/summary.json',
               'strict_analysis_receipt': '../source-gates/summary.json',
               'strict_analysis_receipt_sha256': sha(RUNTIME / 'qualification/source-gates/summary.json')}
    save_json('summary.json', summary)
    save_json('manifest.json', {p.name: sha(p) for p in OUT.iterdir() if p.is_file()
                               and p.suffix not in {'.js', '.map', '.deps'} and p.name != 'manifest.json'})
    print(json.dumps({'status': summary['status'], 'error': error,
                      'source_changed_during_run': changed}), flush=True)
if summary['status'] != 'passed':
    raise SystemExit(1)
