#!/bin/bash
set -euo pipefail
source /workspace/scratch/11a0888870d6/runtime/env.sh
exec /workspace/scratch/11a0888870d6/runtime/flutter-sdk/bin/cache/dart-sdk/bin/dart --packages=/workspace/scratch/11a0888870d6/validation-workspace/.dart_tool/package_config.json /workspace/scratch/11a0888870d6/runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart "$@"
