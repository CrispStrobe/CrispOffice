#!/usr/bin/env python3
"""Run a local test cohort with exact source and process receipts."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path('/workspace/scratch/11a0888870d6')
runtime = root / 'runtime'
source = root / 'quds_office_suite'
workspace = root / 'validation-workspace'
parser = argparse.ArgumentParser()
parser.add_argument('--name', required=True)
parser.add_argument('--package', required=True)
parser.add_argument('--runner', choices=['engine', 'flutter'], required=True)
parser.add_argument('--concurrency', type=int, default=2)
parser.add_argument('--platform', choices=['vm', 'node'], default='vm')
parser.add_argument('--expected-skips', type=Path)
parser.add_argument('--idle-timeout', type=float, default=0,
                    help='Interrupt after this many seconds without stdout/stderr growth; zero disables.')
parser.add_argument('--max-runtime', type=float, default=0,
                    help='Interrupt after this many total seconds; zero disables.')
parser.add_argument('tests', nargs='+')
args = parser.parse_args()
out = runtime / 'qualification' / args.name
out.mkdir(parents=True, exist_ok=False)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def capture():
    paths = set()
    members=json.loads((runtime/'setup/workspace-prepared.json').read_text())['members']
    for member in members:
        paths.update(p for p in (source/member/'lib').rglob('*') if p.is_file())
        paths.update(p for p in (source/member/'test/fixtures').rglob('*') if p.is_file())
    paths.update(p for p in (source/'third_party/enough_mail/lib').rglob('*') if p.is_file())
    paths.update(p for p in (source/args.package/'test').rglob('*.dart') if p.is_file())
    for name in args.tests:
        paths.add(source/args.package/name)
    paths.update(p for p in source.glob('packages/**/pubspec.yaml') if '.dart_tool' not in p.parts and 'build' not in p.parts)
    paths.update(p for p in source.glob('apps/**/pubspec.yaml') if '.dart_tool' not in p.parts and 'build' not in p.parts)
    paths.add(source/'pubspec.yaml')
    paths.add(source/'pubspec.lock')
    return {str(p.relative_to(source)):digest(p) for p in sorted(paths)}

def save_gzip(name, value):
    data=(json.dumps(value, indent=2, sort_keys=True)+'\n').encode()
    (out/name).write_bytes(gzip.compress(data, mtime=0))

env=os.environ.copy()
for key, value in {
    'FLUTTER_ROOT':str(runtime/'flutter-sdk'), 'PUB_CACHE':str(runtime/'pub-cache'),
    'TMPDIR':str(runtime/'tmp'), 'XDG_CONFIG_HOME':str(runtime/'config'),
    'XDG_CACHE_HOME':str(runtime/'cache'), 'XDG_DATA_HOME':str(runtime/'data'),
    'CI':'true','DART_SUPPRESS_ANALYTICS':'true','DASH__SUPPRESS_ANALYTICS':'true',
    'FLUTTER_SUPPRESS_ANALYTICS':'true',
}.items():
    env[key]=value
env['PATH']=str(runtime/'flutter-sdk/bin')+os.pathsep+env['PATH']
if args.runner=='engine':
    command=[str(runtime/'flutter-sdk/bin/cache/dart-sdk/bin/dart'),
        '--packages='+str(workspace/'.dart_tool/package_config.json'),
        str(runtime/'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),
        '--platform',args.platform,'--reporter','json','--concurrency',str(args.concurrency),*args.tests]
else:
    command=[str(runtime/'flutter-sdk/bin/flutter'),'test','--no-pub','--reporter','json','--concurrency',str(args.concurrency),*args.tests]
started=time.time()
head_before=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
before=capture()
save_gzip('source-before.json.gz',before)
interruption = None
process = None
process_observations = []

def observe_processes(label):
    observation = {'label':label, 'elapsed_seconds':round(time.time()-started,3)}
    try:
        observation['ps'] = subprocess.check_output(
            ['ps','-eo','pid,ppid,pgid,etime,pcpu,rss,args'], text=True,
            timeout=5)
    except (OSError, subprocess.SubprocessError) as error:
        observation['error'] = str(error)
    process_observations.append(observation)
    (out/'process-observations.json').write_text(json.dumps(process_observations,indent=2)+'\n')

def stop_process():
    if process is None or process.poll() is not None:
        return
    observe_processes('before-interruption')
    for sig, grace in ((signal.SIGINT,10),(signal.SIGTERM,10),(signal.SIGKILL,5)):
        try:
            os.killpg(process.pid,sig)
        except ProcessLookupError:
            break
        try:
            process.wait(timeout=grace)
            break
        except subprocess.TimeoutExpired:
            continue
    observe_processes('after-interruption')

with (out/'stdout.jsonl').open('w') as stdout, (out/'stderr.log').open('w') as stderr:
    process=subprocess.Popen(command,cwd=workspace/args.package,env=env,
                             stdout=stdout,stderr=stderr,start_new_session=True)
    (out/'process.json').write_text(json.dumps({'pid':process.pid,'pgid':process.pid,
                                              'command':command},indent=2)+'\n')
    last_size = (-1,-1)
    last_output = time.monotonic()
    process_start = last_output
    last_observation = last_output
    try:
        while process.poll() is None:
            now = time.monotonic()
            sizes = ((out/'stdout.jsonl').stat().st_size,(out/'stderr.log').stat().st_size)
            if sizes != last_size:
                last_output = now
                last_size = sizes
            if now-last_observation >= 30:
                observe_processes('running')
                last_observation = now
            if args.idle_timeout and now-last_output > args.idle_timeout:
                interruption = {'reason':'idle_timeout','seconds':args.idle_timeout}
                stop_process()
                break
            if args.max_runtime and now-process_start > args.max_runtime:
                interruption = {'reason':'maximum_runtime','seconds':args.max_runtime}
                stop_process()
                break
            time.sleep(0.5)
    except KeyboardInterrupt:
        interruption = {'reason':'keyboard_interrupt'}
        stop_process()
    if process.poll() is None:
        stop_process()
after=capture()
head_after=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
save_gzip('source-after.json.gz',after)
events=[]
nonjson=[]
for line in (out/'stdout.jsonl').read_text().splitlines():
    try:
        obj=json.loads(line)
    except json.JSONDecodeError:
        nonjson.append(line)
    else:
        if isinstance(obj, dict): events.append(obj)
        else: nonjson.append(line)
starts={e['test']['id']:e['test'] for e in events if e.get('type')=='testStart'}
done=[e for e in events if e.get('type')=='testDone' and not e.get('hidden')]
cases=[{**starts.get(e['testID'], {'id':e['testID']}), 'result':e['result'], 'skipped':e.get('skipped',False)} for e in done]
save_gzip('cases.json.gz',cases)
expected_skips = json.loads(args.expected_skips.read_text()) if args.expected_skips else []
expected_by_name = {item['name']:item['reason'] for item in expected_skips}
skip_details = []
for case in cases:
    if not case['skipped']:
        continue
    reasons = [event['message'] for event in events
               if event.get('type') == 'print' and event.get('messageType') == 'skip'
               and event.get('testID') == case['id']]
    skip_details.append({'name':case['name'], 'reason':reasons,
                         'expected':case['name'] in expected_by_name
                         and expected_by_name[case['name']] == reasons})
changed=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
receipt={
    'command':command,'cwd':str(workspace/args.package),'exit_code':process.returncode,
    'runner_version':4,'suite_files':args.tests,'platform':args.platform if args.runner=='engine' else 'flutter-vm',
    'runtime_interruption':interruption,
    'watchdog':{'idle_timeout_seconds':args.idle_timeout,'maximum_runtime_seconds':args.max_runtime},
    'selected_environment':{name:env.get(name) for name in ('QUDS_TYPING_BENCHMARK',)},
    'source_head_before':head_before,'source_head_after':head_after,'source_input_count':len(before),
    'source_inputs_unchanged':not changed,'source_inputs_changed':changed,
    'passed':sum(c['result']=='success' and not c['skipped'] for c in cases),
    'failed':sum(c['result']!='success' for c in cases),'skipped':sum(c['skipped'] for c in cases),
    'skip_details':skip_details,'unexpected_skips':sum(not item['expected'] for item in skip_details),
    'expected_skip_manifest':{'path':str(args.expected_skips),'sha256':digest(args.expected_skips),'entries':expected_skips} if args.expected_skips else None,
    'errors':[e for e in events if e.get('type')=='error'],
    'terminal_success':any(e.get('type')=='done' and e.get('success') for e in events),
    'non_json_output_lines':nonjson,'duration_seconds':round(time.time()-started,3),
    'runtime':json.loads((runtime/'logs/flutter-version.json').read_text()),
    'package_config_sha256':digest(workspace/'.dart_tool/package_config.json'),
    'workspace_lock_sha256':digest(workspace/'pubspec.lock'),
}
receipt['accepted_process']=interruption is None and receipt['exit_code']==0 and receipt['terminal_success'] and not receipt['failed'] and not receipt['unexpected_skips'] and not receipt['errors']
receipt['files']={p.name:digest(p) for p in out.iterdir() if p.is_file()}
(out/'summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('exit_code','passed','failed','skipped','terminal_success','source_input_count','source_inputs_unchanged','source_inputs_changed','duration_seconds','accepted_process')},indent=2),flush=True)
raise SystemExit(0 if receipt['accepted_process'] else 1)
