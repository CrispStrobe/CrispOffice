import 'dart:convert';
final RegExp _grammarSimplePredicate = RegExp(
  r'^[ \t\u00a0\u202f]*'
  r'(?:(?:heute|morgen|jetzt|hier|dort|draußen|drinnen|bald|gerne|oft|immer|selten|'
  r'zusammen|wieder|allein|auch|nicht|wirklich|sehr|müde|bereit|fertig|sauber|'
  r'pünktlich|leise|laut|schnell|langsam|lange|gut|schlecht)[ \t\u00a0\u202f]+)*'
  r'(?:heute|morgen|jetzt|hier|dort|draußen|drinnen|bald|gerne|oft|immer|selten|'
  r'zusammen|wieder|allein|auch|nicht|wirklich|sehr|müde|bereit|fertig|sauber|'
  r'pünktlich|leise|laut|schnell|langsam|lange|gut|schlecht)?'
  r'(?:[ \t\u00a0\u202f]*(?:im|am|zum|beim|vom|ins|ans|zur|nach|zu|bei|mit|ohne)'
  r'[ \t\u00a0\u202f]+(?:Hause|[\p{Lu}][\p{L}\p{M}]*))?'
  r'[ \t\u00a0\u202f]*\.?[ \t\r\n\u00a0\u202f]*$',
  unicode: true,
);
void main(List<String> args) { final n=int.parse(args.single); final input=' '*n+'?'; final sw=Stopwatch()..start(); final matched=_grammarSimplePredicate.hasMatch(input); print(jsonEncode({'spaces':n,'matched':matched,'microseconds':sw.elapsedMicroseconds})); }
