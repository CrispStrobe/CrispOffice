import 'dart:convert';
import 'dart:math';
final RegExp _grammarBaselinePredicate = RegExp(
  r'^[ \t\u00a0\u202f]*'
  r'(?:(?:heute|morgen|jetzt|hier|dort|draußen|drinnen|bald|gerne|oft|immer|selten|'
  r'zusammen|wieder|allein|auch|nicht|wirklich|sehr|müde|bereit|fertig|sauber|'
  r'pünktlich|leise|laut|schnell|langsam|lange|gut|schlecht)[ \t\u00a0\u202f]+)*'
  r'(?:heute|morgen|jetzt|hier|dort|draußen|drinnen|bald|gerne|oft|immer|selten|'
  r'zusammen|wieder|allein|auch|nicht|wirklich|sehr|müde|bereit|fertig|sauber|'
  r'pünktlich|leise|laut|schnell|langsam|lange|gut|schlecht)?'
  r'(?:[ \t\u00a0\u202f]*(?:im|am|zum|beim|vom|ins|ans|zur|nach|zu|bei|mit|ohne)'
  r'[ \t\u00a0\u202f]+(?:Hause|[\p{Lu}][\p{L}\p{M}]*))?'
  r'[ \t\u00a0\u202f]*\.?[ \t\r\n\u00a0\u202f]*$',
  unicode: true,
);
const _grammarPredicateAdverbs = <String>{
  'heute',
  'morgen',
  'jetzt',
  'hier',
  'dort',
  'draußen',
  'drinnen',
  'bald',
  'gerne',
  'oft',
  'immer',
  'selten',
  'zusammen',
  'wieder',
  'allein',
  'auch',
  'nicht',
  'wirklich',
  'sehr',
  'müde',
  'bereit',
  'fertig',
  'sauber',
  'pünktlich',
  'leise',
  'laut',
  'schnell',
  'langsam',
  'lange',
  'gut',
  'schlecht',
};
const _grammarPredicatePrepositions = <String>{
  'im',
  'am',
  'zum',
  'beim',
  'vom',
  'ins',
  'ans',
  'zur',
  'nach',
  'zu',
  'bei',
  'mit',
  'ohne',
};
final _grammarPredicateNoun = RegExp(r'^\p{Lu}[\p{L}\p{M}]*$', unicode: true);

bool _grammarPredicateHorizontal(int unit) =>
    unit == 0x20 || unit == 0x09 || unit == 0xa0 || unit == 0x202f;

bool _grammarSimplePredicate(String text, int start) {
  // Scan whitespace once instead of backtracking over overlapping repetitions.
  // Newlines are allowed only after the optional final period or final word.
  var end = text.length;
  while (end > start) {
    final unit = text.codeUnitAt(end - 1);
    if (!_grammarPredicateHorizontal(unit) && unit != 0x0a && unit != 0x0d) {
      break;
    }
    end--;
  }
  if (end > start && text.codeUnitAt(end - 1) == 0x2e) end--;
  while (end > start && _grammarPredicateHorizontal(text.codeUnitAt(end - 1))) {
    end--;
  }
  var cursor = start;
  while (cursor < end) {
    while (cursor < end &&
        _grammarPredicateHorizontal(text.codeUnitAt(cursor))) {
      cursor++;
    }
    if (cursor == end) return true;
    final tokenStart = cursor;
    while (cursor < end &&
        !_grammarPredicateHorizontal(text.codeUnitAt(cursor))) {
      cursor++;
    }
    final token = text.substring(tokenStart, cursor);
    if (_grammarPredicateAdverbs.contains(token)) continue;
    // Preserve the old gate's optional space before the final preposition,
    // including an adjacent adverb/preposition. This checks a fixed-size set.
    final preposition = _grammarPredicatePrepositions.any(
      (word) =>
          token == word ||
          token.endsWith(word) &&
              _grammarPredicateAdverbs.contains(
                token.substring(0, token.length - word.length),
              ),
    );
    if (!preposition) return false;
    while (cursor < end &&
        _grammarPredicateHorizontal(text.codeUnitAt(cursor))) {
      cursor++;
    }
    // Exactly one capitalized noun must finish this optional phrase. The
    // anchored character-class match is linear and cannot split whitespace.
    return cursor < end &&
        _grammarPredicateNoun.hasMatch(text.substring(cursor, end));
  }
  return true;
}



void main() {
  var count = 0;
  final mismatches = <Map<String, Object>>[];
  void check(String tail) {
    count++;
    final expected = _grammarBaselinePredicate.hasMatch(tail);
    final actual = _grammarSimplePredicate('prefix::$tail', 8);
    if (actual != expected && mismatches.length < 20) {
      mismatches.add({'tail': tail, 'expected': expected, 'actual': actual});
    }
  }
  const gaps = ['', ' ', '\t', '\u00a0', '\u202f', ' \t'];
  const endings = ['', '.', ' . ', '.\r\n', '\n', '\n.', '?', '!', '..', '\u000b', '\u2028'];
  for (final leading in gaps) {
    for (final adverb in ['', ..._grammarPredicateAdverbs, 'heute morgen', 'HEUTE', 'unbekannt']) {
      for (final between in gaps) {
        for (final prep in ['', ..._grammarPredicatePrepositions, 'falsch']) {
          for (final ending in endings) {
            check('$leading$adverb$between${prep.isEmpty ? '' : '$prep Garten'}$ending');
          }
        }
      }
    }
  }
  for (final noun in ['Hause', 'Äther', 'A\u0308ther', '𐐀haus', 'haus', 'ǅuro', 'Haus Garten', 'Haus\n', 'Haus\nGarten', 'Haus!', 'Haus-Teil', 'Haus3']) {
    for (final gap in gaps) {
      for (final ending in endings) {
        check(' heute im$gap$noun$ending');
      }
    }
  }
  final random = Random(17261117);
  final atoms = <String>['', ' ', '\t', '\r', '\n', '\u00a0', '\u202f', '.', '?', '\u000b', ..._grammarPredicateAdverbs, ..._grammarPredicatePrepositions, 'Garten', 'Hause', 'A\u0308ther', 'unbekannt'];
  for (var index = 0; index < 20000; index++) {
    check(List.generate(random.nextInt(9), (_) => atoms[random.nextInt(atoms.length)]).join());
  }
  final timings = <Map<String, Object>>[];
  for (final size in [256, 512, 1024, 4096, 16384, 65536]) {
    for (final punctuation in ['?', '.']) {
      final tail = ' ' * size + punctuation;
      final watch = Stopwatch()..start();
      final accepted = _grammarSimplePredicate(tail, 0);
      timings.add({'spaces': size, 'punctuation': punctuation, 'accepted': accepted, 'microseconds': watch.elapsedMicroseconds});
      if (accepted != (punctuation == '.')) throw StateError('Wrong long-tail result');
    }
  }
  print(jsonEncode({'differential_cases': count, 'mismatches': mismatches, 'timings': timings}));
  if (mismatches.isNotEmpty) throw StateError('Predicate language changed');
}
