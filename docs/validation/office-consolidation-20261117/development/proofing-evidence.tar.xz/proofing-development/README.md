# Proofing development controls

The baseline is integrated checkpoint `c175f71839c857f1bb3e8a8c23c504f08075c268`.
`baseline-source.json` binds the original four files, preserved under `baseline-source/`.
`repaired-source/` and `summary.json` bind the repaired files.

The old predicate regex exhibits growing whitespace-rejection cost at 256, 512 and 1,024 spaces; no larger pathological old input was run. The raw probe and receipt are retained. The new parser agrees with the old predicate on 228,692 finite generated cases, and separately handles up to 65,536 spaces. These direct parser comparisons are not additional application-test passes or a representative product performance benchmark.

The focused Dart suite passes 66 cases on both VM and Node with exactly matching case identities/outcomes and no skips. Nineteen regression cases preserve admitted/rejected tails, source ranges, nonmutation and long horizontal whitespace. The Python admission suite has nine cases: six passed and three failed on the baseline; all nine pass after repair. The new accepted-source control uses a mocked native import, with separate stale timestamp-cache, unchecked-hash-cache and post-admission source-change regressions. No model inference occurs in these tests.

The direct analyzer attempt follows source symlinks into a checkout without package configuration and fails with missing imports. Its log remains retained; it is not an accepted static analysis result. The parent final harness supplies normalized configuration and strict analysis. Formatting under language version 3.12 passes with no changed files.
