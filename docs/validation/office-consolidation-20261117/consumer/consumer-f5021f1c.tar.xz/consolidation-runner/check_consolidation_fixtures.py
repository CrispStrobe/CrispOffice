"""Independent LibreOffice/Poppler checks for incoming tabs and table styles."""
from __future__ import annotations

import zipfile
from lxml import etree
from PIL import Image

from check_recovery_fixtures import _resolved_properties, _value, require

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}


def _text(element):
    return ''.join(element.xpath('.//w:t/text()', namespaces=NS))


def _unique_word(pages, target):
    # Poppler may join leader glyphs and the following word into one token.
    # Such tokens still give an unambiguous line location for raster sampling.
    found = [(number, word) for number, page in enumerate(pages, 1)
             for word in page['words'] if word['text'].endswith(target)]
    require(len(found) == 1, 'Expected exactly one visible target ' + target)
    number, word = found[0]
    return {'page': number, **word}


def _border(side):
    return {'kind': _value(side), 'color': _value(side, 'color'),
            'size_eighths': _value(side, 'sz')}


def _cell_borders(cell):
    table = cell.getparent().getparent()
    rows = table.findall('w:tr', NS)
    row = cell.getparent()
    cells = row.findall('w:tc', NS)
    fallback = table.find('w:tblPr/w:tblBorders', NS)
    direct = cell.find('w:tcPr/w:tcBorders', NS)
    result = {}
    for edge, inherited in (
        ('top', 'top' if rows.index(row) == 0 else 'insideH'),
        ('bottom', 'bottom' if rows.index(row) == len(rows) - 1 else 'insideH'),
        ('left', 'left' if cells.index(cell) == 0 else 'insideV'),
        ('right', 'right' if cells.index(cell) == len(cells) - 1 else 'insideV'),
    ):
        side = None if direct is None else direct.find('w:' + edge, NS)
        if side is None and direct is not None and edge in ('left', 'right'):
            side = direct.find('w:' + ('start' if edge == 'left' else 'end'), NS)
        if side is None and fallback is not None:
            side = fallback.find('w:' + inherited, NS)
        result[edge] = _border(side)
    return result


def check_consolidation_reopened(spec, output, pages, semantics):
    if not any(key in spec for key in ('paragraph_tabs', 'minimum_table_rows', 'cell_decorations')):
        return {}
    name = spec['name']
    result = {}
    with zipfile.ZipFile(output / 'converted' / (name + '.docx')) as archive:
        document = etree.fromstring(archive.read('word/document.xml'))
        style_root = etree.fromstring(archive.read('word/styles.xml'))
        styles = {s.get('{%s}styleId' % W): s for s in style_root.findall('w:style', NS)}
        if 'paragraph_tabs' in spec:
            checked = {}
            paragraphs = document.xpath('//w:p', namespaces=NS)
            for target, expected in spec['paragraph_tabs'].items():
                matching = [paragraph for paragraph in paragraphs if _text(paragraph).endswith(target)]
                require(len(matching) == 1, name + ': ambiguous reopened tab paragraph ' + target)
                props = _resolved_properties(matching[0], styles, 'pPr')
                tabs = props.get('tabs')
                active = [] if tabs is None else [tab for tab in tabs if _value(tab) != 'clear']
                require(len(active) == 1, name + ': expected one explicit active tab for ' + target)
                tab = active[0]
                actual = {'position_pt': int(_value(tab, 'pos')) / 20,
                          'alignment': _value(tab), 'leader': _value(tab, 'leader') or 'none'}
                require(actual == expected,
                        name + ': reopened tab for ' + target + ' is ' + repr(actual) + ', expected ' + repr(expected))
                location = _unique_word(pages, target)
                require(location['page'] == 1, name + ': unexpected target page ' + target)
                # For nonleader text the full PDF word box gives independent
                # left/right/center geometry. Leader glyphs can share a word box.
                measured = None
                if expected['leader'] == 'none':
                    require(location['text'] == target, name + ': ambiguous plain tab word box ' + target)
                    measured = {
                        'left': location['xMin'], 'right': location['xMax'],
                        'center': (location['xMin'] + location['xMax']) / 2,
                    }[expected['alignment']]
                    expected_edge = spec['tab_page_left_pt'] + expected['position_pt']
                    require(abs(measured - expected_edge) <= spec['tab_geometry_tolerance_pt'],
                            name + ': PDF tab geometry for ' + target + ' is ' + str(measured) + ', expected ' + str(expected_edge))
                checked[target] = {'reopened_tab': actual, 'pdf_location': location,
                                   'measured_alignment_edge_pt': measured}
            result['reopened_paragraph_tabs'] = checked
        if 'minimum_table_rows' in spec:
            checked = []
            for expected in spec['minimum_table_rows']:
                rows = [row for row in document.xpath('//w:tr', namespaces=NS)
                        if expected['first_word'] in _text(row)]
                require(len(rows) == 1, name + ': ambiguous reopened table row')
                heights = rows[0].findall('w:trPr/w:trHeight', NS)
                require(len(heights) == 1, name + ': missing reopened row minimum')
                actual = {'first_word': expected['first_word'],
                          'height_pt': int(_value(heights[0])) / 20,
                          'rule': _value(heights[0], 'hRule')}
                require(actual['rule'] == 'atLeast', name + ': minimum row became fixed or automatic: ' + repr(actual))
                require(abs(actual['height_pt'] - expected['height_pt']) <= .05,
                        name + ': reopened row minimum changed: ' + repr(actual))
                checked.append(actual)
            deltas = []
            locations = semantics['word_locations']
            for expected in spec['minimum_row_geometry']:
                first, following = locations[expected['first']], locations[expected['next']]
                require(first['page'] == following['page'], name + ': table row unexpectedly paginated')
                delta = following['yMin'] - first['yMin']
                require(delta >= expected['min_delta_pt'],
                        name + ': row content/reserved height collapsed to ' + str(delta))
                deltas.append({**expected, 'measured_delta_pt': delta})
            words = spec['multiline_cell_words']
            for first, second in zip(words, words[1:]):
                delta = locations[second]['yMin'] - locations[first]['yMin']
                require(abs(delta - 18) <= .15, name + ': multiline cell lost its 18pt line step')
            result['reopened_minimum_rows'] = checked
            result['minimum_row_geometry'] = deltas
        if 'cell_decorations' in spec:
            checked = {}
            for word, expected in spec['cell_decorations'].items():
                cells = [cell for cell in document.xpath('//w:tc', namespaces=NS) if _text(cell) == word]
                require(len(cells) == 1, name + ': ambiguous reopened cell ' + word)
                fill = _value(cells[0].find('w:tcPr/w:shd', NS), 'fill')
                fill = fill.upper() if fill else None
                require(fill == expected['fill'] if expected['fill'] is not None else fill in (None, 'AUTO', 'FFFFFF'),
                        name + ': cell fill changed for ' + word + ': ' + str(fill))
                borders = _cell_borders(cells[0])
                if expected['borders']:
                    for edge, border in borders.items():
                        require(border['kind'] == 'single' and
                                (border['color'] or '').upper() == '000000' and
                                border['size_eighths'] == '4',
                                name + ': cell border changed for ' + word + '/' + edge + ': ' + repr(border))
                else:
                    # The plain bottom-right cell shares its other two edges
                    # with bordered neighbors. Check its exposed outer edges.
                    for edge in ('bottom', 'right'):
                        require(borders[edge]['kind'] in (None, 'nil', 'none'),
                                name + ': plain cell acquired an outer border: ' + edge)
                checked[word] = {'fill': fill, 'borders': borders}
            result['reopened_cell_decorations'] = checked
    return result


def check_consolidation_raster(spec, raster, page, semantics):
    if not any(key in spec for key in ('leader_raster_groups', 'cell_decorations')):
        return {}
    result = {}
    with Image.open(raster) as image:
        image = image.convert('RGB')

        def crop(bounds):
            x1, y1, x2, y2 = bounds
            return image.crop((max(0, int(x1 / .75)), max(0, int(y1 / .75)),
                               min(image.width, int(x2 / .75) + 1),
                               min(image.height, int(y2 / .75) + 1)))

        if 'leader_raster_groups' in spec:
            group = spec['leader_raster_groups']
            checked = {}
            for kind in ('dotted', 'hyphen', 'underscore', 'plain'):
                word = group[kind]
                location = semantics['reopened_paragraph_tabs'][word]['pdf_location']
                require(location['page'] == page, spec['name'] + ': leader raster is on wrong page')
                bounds = [group['gap_left_pt'], location['yMin'] - 1,
                          group['gap_right_pt'], location['yMax'] + 3]
                pixels = list(crop(bounds).getdata())
                black = sum(all(value <= 70 for value in pixel) for pixel in pixels)
                if kind == 'plain':
                    require(black <= 3, spec['name'] + ': plain tab inherited visible leader marks')
                else:
                    require(black >= 20, spec['name'] + ': ' + kind + ' leader is not visibly rendered')
                checked[kind] = {'black_pixels': black, 'bounds_pt': bounds}
            result['leader_gap_pixels'] = checked
        if 'cell_decorations' in spec:
            checked = {}
            for word, expected in spec['cell_decorations'].items():
                location = semantics['word_locations'][word]
                require(location['page'] == page, spec['name'] + ': cell raster is on wrong page')
                bounds = [location['xMin'], location['yMin'],
                          location['xMax'] + 12, location['yMax']]
                target = ((255, 255, 255) if expected['fill'] is None else
                          tuple(int(expected['fill'][i:i + 2], 16) for i in (0, 2, 4)))
                pixels = list(crop(bounds).getdata())
                matches = sum(all(abs(value - wanted) <= 20 for value, wanted in zip(pixel, target)) for pixel in pixels)
                require(matches >= max(60, len(pixels) * .45),
                        spec['name'] + ': expected cell background is not visible for ' + word)
                checked[word] = {'target_rgb': target, 'matching_pixels': matches,
                                 'sampled_pixels': len(pixels), 'bounds_pt': bounds}
            result['cell_background_pixels'] = checked
    return result
