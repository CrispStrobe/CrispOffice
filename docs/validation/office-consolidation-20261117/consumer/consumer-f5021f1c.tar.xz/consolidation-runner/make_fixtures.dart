import 'dart:convert';
import 'dart:io';

// ignore: depend_on_referenced_packages
import 'package:quds_office_engine/quds_office_engine.dart';
import '../recovery-runner/make_fixtures.dart' as recovery;

void main(List<String> arguments) {
  // Execute the exact prior generator so all 26 fixture specifications remain
  // unchanged. The independent Python runner verifies their complete equality.
  recovery.main(arguments);
  final directory = Directory(arguments.single);
  final manifest = File('${directory.path}/fixtures.json');
  final records = (jsonDecode(manifest.readAsStringSync()) as List)
      .cast<Map<String, dynamic>>();

  void save(String name, WmlDocument document, Map<String, Object?> spec) {
    File(
      '${directory.path}/$name.odt',
    ).writeAsBytesSync(OdtDocumentWriter.writeBytes(document));
    records.add({'name': name, 'file': '$name.odt', ...spec});
  }

  const size = WmlPageSize(width: 400, height: 500);
  const margins = WmlPageMargins(top: 36, bottom: 36, left: 36, right: 36);
  WmlRun run(String text) => WmlRun(
    text: text,
    properties: WmlRunProps(
      asciiFont: 'Liberation Sans',
      csFont: 'Liberation Sans',
      fontSizeHalfPoints: 24,
    ),
  );
  WmlDocument document(List<WmlBlock> blocks) => WmlDocument(
    sections: [WmlSection(pageSize: size, margins: margins, blocks: blocks)],
  );
  WmlParagraph paragraph(String text, {List<WmlTabStop>? tabs}) => WmlParagraph(
    properties: WmlParagraphProps(
      tabs: tabs,
      spacingBefore: 0,
      spacingAfter: 8,
      lineSpacingRule: WmlLineSpacingRule.exact,
      lineSpacing: 18,
    ),
    inlines: [run(text)],
  );
  WmlParagraph tabbed(
    String prefix,
    String target,
    double position, {
    WmlTabAlignment alignment = WmlTabAlignment.left,
    WmlTabLeader leader = WmlTabLeader.none,
  }) => paragraph(
    '$prefix\t$target',
    tabs: [
      WmlTabStop(position: position, alignment: alignment, leader: leader),
    ],
  );

  save(
    'paragraph-distinct-tab-configurations',
    document([
      tabbed('PosA', 'NearTarget', 90),
      tabbed('PosB', 'FarTarget', 180),
      tabbed('AlignR', 'RightTarget', 270, alignment: WmlTabAlignment.right),
      tabbed('AlignC', 'CenterTarget', 200, alignment: WmlTabAlignment.center),
      tabbed('Dots', 'DottedTarget', 220, leader: WmlTabLeader.dot),
      tabbed('Dash', 'HyphenTarget', 220, leader: WmlTabLeader.hyphen),
      tabbed('Line', 'UnderTarget', 220, leader: WmlTabLeader.underscore),
      tabbed('Plain', 'UndottedTarget', 220),
      tabbed('Repeat', 'RepeatedNear', 90),
    ]),
    {
      'page_sizes_pt': [
        [400, 500],
      ],
      'word_pages': {
        'NearTarget': 1,
        'FarTarget': 1,
        'RightTarget': 1,
        'CenterTarget': 1,
        'UndottedTarget': 1,
        'RepeatedNear': 1,
      },
      'vertical_order': [
        'NearTarget',
        'FarTarget',
        'RightTarget',
        'CenterTarget',
        'UndottedTarget',
        'RepeatedNear',
      ],
      'paragraph_tabs': {
        'NearTarget': {
          'position_pt': 90,
          'alignment': 'left',
          'leader': 'none',
        },
        'FarTarget': {
          'position_pt': 180,
          'alignment': 'left',
          'leader': 'none',
        },
        'RightTarget': {
          'position_pt': 270,
          'alignment': 'right',
          'leader': 'none',
        },
        'CenterTarget': {
          'position_pt': 200,
          'alignment': 'center',
          'leader': 'none',
        },
        'DottedTarget': {
          'position_pt': 220,
          'alignment': 'left',
          'leader': 'dot',
        },
        'HyphenTarget': {
          'position_pt': 220,
          'alignment': 'left',
          'leader': 'hyphen',
        },
        'UnderTarget': {
          'position_pt': 220,
          'alignment': 'left',
          'leader': 'underscore',
        },
        'UndottedTarget': {
          'position_pt': 220,
          'alignment': 'left',
          'leader': 'none',
        },
        'RepeatedNear': {
          'position_pt': 90,
          'alignment': 'left',
          'leader': 'none',
        },
      },
      'tab_page_left_pt': 36,
      'tab_geometry_tolerance_pt': 0.4,
      'leader_raster_groups': {
        'dotted': 'DottedTarget',
        'hyphen': 'HyphenTarget',
        'underscore': 'UnderTarget',
        'plain': 'UndottedTarget',
        'gap_left_pt': 100,
        'gap_right_pt': 240,
      },
      'scope':
          'Otherwise identical adjacent paragraphs keep independent tab '
          'positions, left/right/center alignment and dot/hyphen/underscore/plain '
          'leaders. A repeated configuration remains equivalent.',
    },
  );

  WmlParagraph cellParagraph(String text) => WmlParagraph(
    properties: WmlParagraphProps(
      spacingBefore: 0,
      spacingAfter: 0,
      lineSpacingRule: WmlLineSpacingRule.exact,
      lineSpacing: 18,
    ),
    inlines: [run(text)],
  );
  WmlTableCell cell(List<String> lines, {String? fill, bool borders = true}) =>
      WmlTableCell(
        fillColor: fill,
        borderTop: borders,
        borderBottom: borders,
        borderLeft: borders,
        borderRight: borders,
        blocks: lines.map(cellParagraph).toList(),
      );

  save(
    'table-minimum-height-keeps-multiline-content',
    document([
      WmlTable(
        grid: [260],
        rows: [
          WmlTableRow(
            height: 18,
            cells: [
              cell(['TallOne', 'TallTwo', 'TallThree', 'TallFour']),
            ],
          ),
          WmlTableRow(
            height: 72,
            cells: [
              cell(['ShortRow']),
            ],
          ),
          WmlTableRow(
            cells: [
              cell(['TailRow']),
            ],
          ),
        ],
      ),
      paragraph('AfterTable'),
    ]),
    {
      'page_sizes_pt': [
        [400, 500],
      ],
      'word_pages': {
        'TallOne': 1,
        'TallTwo': 1,
        'TallThree': 1,
        'TallFour': 1,
        'ShortRow': 1,
        'TailRow': 1,
        'AfterTable': 1,
      },
      'vertical_order': [
        'TallOne',
        'TallTwo',
        'TallThree',
        'TallFour',
        'ShortRow',
        'TailRow',
        'AfterTable',
      ],
      'minimum_table_rows': [
        {'first_word': 'TallOne', 'height_pt': 18},
        {'first_word': 'ShortRow', 'height_pt': 72},
      ],
      'minimum_row_geometry': [
        {'first': 'TallOne', 'next': 'ShortRow', 'min_delta_pt': 71},
        {'first': 'ShortRow', 'next': 'TailRow', 'min_delta_pt': 71},
      ],
      'multiline_cell_words': ['TallOne', 'TallTwo', 'TallThree', 'TallFour'],
      'scope':
          'An authored row height is a minimum: all four lines remain '
          'visible and increase the first row beyond 18pt; the short second '
          'row reserves at least 72pt. Reopened DOCX must retain atLeast rules.',
    },
  );

  save(
    'table-normalized-cell-colors-and-borders',
    document([
      WmlTable(
        grid: [130, 130],
        rows: [
          WmlTableRow(
            cells: [
              cell(['MixedCaseFill'], fill: 'aBcDeF'),
              cell(['LowerCaseFill'], fill: 'aA6611'),
            ],
          ),
          WmlTableRow(
            cells: [
              cell(['InvalidFill'], fill: 'not-a-color'),
              cell(['PlainCell'], borders: false),
            ],
          ),
        ],
      ),
    ]),
    {
      'page_sizes_pt': [
        [400, 500],
      ],
      'word_pages': {
        'MixedCaseFill': 1,
        'LowerCaseFill': 1,
        'InvalidFill': 1,
        'PlainCell': 1,
      },
      'cell_decorations': {
        'MixedCaseFill': {'fill': 'ABCDEF', 'borders': true},
        'LowerCaseFill': {'fill': 'AA6611', 'borders': true},
        'InvalidFill': {'fill': null, 'borders': true},
        'PlainCell': {'fill': null, 'borders': false},
      },
      'scope':
          'Mixed-case six-digit cell colors retain their RGB values. '
          'An invalid color is omitted while all four authored 0.5pt black '
          'borders survive; an undecorated neighbor inherits no custom fill.',
    },
  );
  manifest.writeAsStringSync(
    '${const JsonEncoder.withIndent('  ').convert(records)}\n',
  );
  print('Generated ${records.length} ODT consumer fixtures.');
}
