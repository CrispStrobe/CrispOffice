"""Package and restore-check one accepted source-bound consumer run."""
from pathlib import Path,PurePosixPath
import argparse,ast,gzip,hashlib,json,tarfile,tempfile

def sha(data):return hashlib.sha256(data).hexdigest()
def function(path,name):
 text=path.read_text();tree=ast.parse(text);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
 return '\n'.join(text.splitlines()[node.lineno-1:node.end_lineno]).encode()

def main():
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 run=args.run.resolve();out=args.output.resolve();base=Path(__file__).resolve().parent
 receipt=json.loads((run/'receipt.json').read_text());assert receipt['passed'] and receipt['summary']=={'fixtures':29,'passed':29,'failed':0,'schema_parts_passed':116,'schema_parts_total':116}
 assert receipt['source_head']=='f5021f1c364baf010049fda2dd4bf7f414deda79'
 assert receipt['source_tree']=='afd7a513dfa91472f58c27ead4d8be3f4b75c262'
 assert all(receipt[x] for x in ['head_unchanged','source_unchanged','runtime_unchanged','fixtures_unchanged','historical_26_specs_unchanged'])
 assert len(receipt['fixtures'])==29 and len({r['name'] for r in receipt['fixtures']})==29
 assert all(r['passed'] and len(r['schema']['passed_parts'])==4 and not r['schema']['failures'] for r in receipt['fixtures'])
 specs=json.loads((run/'fixtures/fixtures.json').read_text());old=json.loads((base/'consolidation-runner/historical-26-specs.json').read_text());assert specs[:26]==old
 original=function(base/'recovery-runner/verify_consumers.py','check_fixture');current=function(base/'consolidation-runner/verify_consumers.py','check_fixture');assert original==current
 assert (base/'recovery-runner/check_recovery_fixtures.py').read_bytes()==(base/'consolidation-runner/check_recovery_fixtures.py').read_bytes()
 before=json.loads(gzip.decompress((run/'inputs.json.gz').read_bytes()));after=json.loads(gzip.decompress((run/'inputs-after.json.gz').read_bytes()));assert before==after
 for name,digest in receipt['output_hashes'].items():assert sha((run/name).read_bytes())==digest,name
 visual=json.loads((run/'visual-review.json').read_text());assert visual['source_head']==receipt['source_head'] and visual['passed']
 files={}
 for name in ['receipt.json','inputs.json.gz','inputs-after.json.gz','visual-review.json']:files['run/'+name]=run/name
 for dirname in ['fixtures','logs','converted','rasters']:
  for path in (run/dirname).rglob('*'):
   if path.is_file():files['run/'+str(path.relative_to(run))]=path
 for dirname in ['runner-source','recovery-runner','consolidation-runner','schemas']:
  for path in (base/dirname).rglob('*'):
   if path.is_file() and '__pycache__' not in path.parts:files[str(path.relative_to(base))]=path
 for name in ['stdout','stderr']:
  path=run.with_name(run.name+'.'+name+'.log');assert path.is_file();files['run/runner.'+name+'.log']=path
 files['package_final.py']=Path(__file__).resolve()
 assert not out.exists();out.mkdir(parents=True)
 archive=out/('consumer-'+receipt['source_head'][:8]+'.tar.xz');members={}
 with tarfile.open(archive,'w:xz',preset=6) as tar:
  for name,path in sorted(files.items()):
   data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
   import io
   tar.addfile(info,io.BytesIO(data));members[name]={'sha256':sha(data),'size':len(data),'mode':'0644'}
 with tempfile.TemporaryDirectory(prefix='consumer-restore-',dir=base.parent/'tmp') as temporary:
  restored=set()
  with tarfile.open(archive) as tar:
   entries=tar.getmembers();assert len(entries)==len(members)
   for item in entries:
    relative=PurePosixPath(item.name);assert item.isfile() and not relative.is_absolute() and '..' not in relative.parts
    assert item.name in members and item.name not in restored
    data=tar.extractfile(item).read();expected=members[item.name]
    assert len(data)==expected['size'] and sha(data)==expected['sha256']
    target=Path(temporary)/item.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    assert sha(target.read_bytes())==expected['sha256'];restored.add(item.name)
  assert restored==set(members)
 index={'schema':1,'source_head':receipt['source_head'],'source_tree':receipt['source_tree'],'summary':receipt['summary'],'input_counts':receipt['input_counts'],'source_runtime_maps_unchanged':before==after,'historical_26_specs_unchanged':True,'historical_check_fixture_sha256':sha(original),'historical_check_fixture_byte_identical':True,'historical_recovery_checker_byte_identical':True,'raw_output_hashes_verified':True,'visual_review':visual,'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'size':archive.stat().st_size,'member_count':len(members),'uncompressed_bytes':sum(r['size'] for r in members.values())},'members':members,'restore_verification':{'performed':True,'member_set_exact':True,'sizes_and_hashes_exact':True,'restored_file_count':len(restored)}}
 (out/'consumer-index.json').write_text(json.dumps(index,indent=2)+'\n')
 print(json.dumps({k:index[k] for k in ['source_head','summary','input_counts','archive','restore_verification']},indent=2))
if __name__=='__main__':main()
