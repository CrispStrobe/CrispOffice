# Quoted research-note file-converter qualification

Source commit: `e3f6b4e74241f805531156e0f1308041813c4f70` (tree
`6f16fa1faf934e33138e354ff295902d9edf137c`). A separate Git archive comparison
matches all 370 tracked engine source/lock inputs to that commit. Runtime is
verified Flutter 3.47.8 / Dart 3.13.7. Converter is **LibreOfficeDev
26.8.0.0.alpha0**, build `2c87e51eeaa2b413ff4ae097b2705eea1995d8e5`.

This record covers actual headless file conversions. It does not establish
Microsoft Word, stable-release LibreOffice, installed Zotero plugin, visual,
or desktop host-focus acceptance.

## Three primary fixtures with an ordinary hyperlink

The body, authored-footnote and table-cell fixtures each originate from native
`WordZoteroCitingSession` Add Note callbacks. Each has a two-level block quote,
bold text, an italic ordinary text hyperlink, and two active citations.
Placeholder callbacks arrive in the reverse of document order. Citation
metadata includes source URIs, locators, affixes, suppressed author, Unicode,
and unknown extension properties.

All three original native documents pass DOCX reopening, editable ODT import,
and another DOCX reopen. Both actual LibreOffice saves complete for all three
files, giving six saves of three distinct fixtures with six distinct active
citations. Independent ZIP/XML inspection at original, first-save and
second-save stages confirms:

- Exact quoted prose and 18 / 36 / 18 point left indentation.
- Correct body, actual footnote-class, or table-cell ownership.
- Two uniquely named, correctly paired active ReferenceMarks in document order.
- Complete unchanged citation metadata and source identity.
- The ordinary hyperlink target remains intact.

**All six converted native reimport attempts are guarded refusals.** LibreOffice
adds separate `text:style-name="Internet_20_link"` and
`text:visited-style-name="Visited_20_Internet_20_Link"` to the ordinary text
hyperlink. The existing reader refuses this unmodeled distinction with
`Distinct visited ODT hyperlink styles are not supported.` The primary
fixtures and failed assertions are retained unchanged. They are not counted as
successful native round trips after LibreOffice.

The initial full gate stops on this first known reader boundary. The continued
observation runner completes the second saves and records every individual
reader attempt and independent XML result. Source inputs remain unchanged
across those runs. See `primary-linked/receipt.json`,
`primary-linked/continued-observations.json`, and `secondary-audit.json`.

## One separately qualified control without an ordinary hyperlink

The separate `no-ordinary-link` body fixture retains the block quotes, bold and
italic text, active citations, complete metadata, preferences, and the original
full document-state assertions. It contains **no ordinary text hyperlink and no
continued list**. Its derivation diff is retained. It does not replace the three
primary fixtures or change their outcomes.

This one control passes two actual LibreOffice saves. The original and both
saved ODT files import successfully, then save and reopen as DOCX with all
asserted state intact: 18/36-point indentation, prose, field order/ownership,
rich text, preferences and complete citation metadata. It represents one
separate fixture with two active citations. All 373 captured inputs remain
unchanged. See `no-link-control/results/receipt.json`.

## Evidence and reproduction

The archive includes the exact scripts, commands, source manifests, JSON state
snapshots, original and converted ODT/DOCX files, converter version output and
stdout/stderr for each command. It excludes compiled kernels, SDK/Pub caches,
and temporary LibreOffice profiles. The runtime receipt retains its separate
SDK and dependency provenance.

Scripts preserve their original scratch paths; adjust `ROOT`, `BASE`, output
paths and the package-config path when reproducing. Activate the recorded
runtime environment first, which supplies a writable `TMPDIR`. Existing output
folders are deliberately not silently reused by the qualification runners.

Two preliminary fixture-harness API mistakes (missing required note arguments
and reading the optional direct data override instead of
`WordZoteroDocumentData.read`) were corrected before the recorded gates. Their
raw diagnostics are preserved and do not count as product failures or accepted
runs. The source-specific accepted control and primary guarded refusals above
are the conclusions of this record.
