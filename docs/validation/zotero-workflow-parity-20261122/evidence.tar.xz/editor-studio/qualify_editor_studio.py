import datetime, gzip, hashlib, json, os, subprocess, time
from pathlib import Path
from urllib.parse import unquote, urljoin, urlparse

ROOT = Path('/workspace/scratch/1cd79da773f9/quds_office_suite')
OUT = Path('/workspace/scratch/1cd79da773f9/validation/zotero/final')
CHECKPOINT = 'e3f6b4e74241f805531156e0f1308041813c4f70'
CONFIG = ROOT / '.dart_tool/package_config.json'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()

def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def snapshot(name):
    files = git('ls-files').splitlines()
    selected = [path for path in files if (
        (path.startswith('packages/') and '/lib/' in path)
        or path.startswith('packages/quds_office_editor/test/')
        or path.startswith('packages/quds_office_editor/example/test/')
        or path.startswith('packages/quds_office_engine/test/fixtures/')
        or Path(path).name in ('pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.fvmrc')
    )]
    source = {path: digest(ROOT/path) for path in selected if (ROOT/path).is_file()}
    packages = json.loads(CONFIG.read_text())['packages']
    dependencies = {}
    for package in packages:
        uri = urljoin(CONFIG.as_uri(), package['rootUri'].rstrip('/') + '/')
        package_root = Path(unquote(urlparse(uri).path))
        if package_root.is_relative_to(ROOT):
            continue
        library = package_root / package.get('packageUri', 'lib/')
        paths = list(library.rglob('*')) if library.is_dir() else []
        if (package_root/'pubspec.yaml').is_file():
            paths.append(package_root/'pubspec.yaml')
        for path in paths:
            if path.is_file():
                dependencies[f"{package['name']}/{path.relative_to(package_root)}"] = digest(path)
    flutter = Path(os.environ['FLUTTER_ROOT'])
    runtime_paths = [CONFIG, Path('/workspace/scratch/1cd79da773f9/toolchains/env.sh'),
        flutter/'bin/cache/flutter_tools.snapshot',
        flutter/'bin/cache/dart-sdk/bin/dart',
        flutter/'bin/cache/dart-sdk/bin/dartaotruntime',
        flutter/'bin/cache/artifacts/engine/linux-x64/flutter_tester',
        flutter/'bin/cache/artifacts/engine/common/flutter_patched_sdk/platform_strong.dill']
    runtime = {str(path): digest(path) for path in runtime_paths if path.is_file()}
    changed = git('diff', '--name-only', CHECKPOINT, '--', *selected).splitlines()
    manifest = {'time_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'checkpoint': CHECKPOINT, 'checkpoint_tree': git('rev-parse', CHECKPOINT+'^{tree}'),
        'head': git('rev-parse','HEAD'), 'source_diff_from_checkpoint': changed,
        'source':source, 'dependencies':dependencies, 'runtime':runtime}
    with gzip.open(OUT/(name+'.json.gz'), 'wt') as stream:
        json.dump(manifest, stream, sort_keys=True, indent=2)
    if changed:
        raise RuntimeError(f'Selected source differs from checkpoint: {changed}')
    return manifest

cohorts = [
    ('editor', 'packages/quds_office_editor', [
        'test/word_zotero_blockquote_controller_test.dart',
        'test/word_zotero_add_note_controller_test.dart',
        'test/word_zotero_citing_controller_test.dart',
        'test/word_zotero_note_target_test.dart',
        'test/word_zotero_multiparagraph_controller_test.dart',
        'test/word_zotero_nested_table_controller_test.dart',
        'test/word_zotero_note_image_controller_test.dart',
        'test/word_zotero_rich_controller_test.dart',
        'test/word_zotero_notes_pane_test.dart']),
    ('studio', 'packages/quds_office_editor/example', [
        'test/studio_zotero_citing_transport_test.dart',
        'test/studio_zotero_shortcuts_test.dart',
        'test/studio_zotero_odt_export_test.dart'])]
records = []
commands = [{'cohort': name, 'cwd': str(ROOT/cwd), 'argv': ['flutter','test','--no-pub','--reporter','json',*tests]} for name,cwd,tests in cohorts]
write_json('editor-studio-commands.json', {'checkpoint':CHECKPOINT,'environment_script':'/workspace/scratch/1cd79da773f9/toolchains/env.sh','commands':commands})
before = snapshot('editor-studio-inputs-before')
print(json.dumps({'stage':'inputs-ready','source_files':len(before['source']),'dependency_files':len(before['dependencies']),'runtime_files':len(before['runtime'])}), flush=True)
for command in commands:
    name=command['cohort']
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT/(name+'.jsonl')).open('w') as stdout, (OUT/(name+'.stderr')).open('w') as stderr:
        result=subprocess.run(command['argv'],cwd=command['cwd'],stdout=stdout,stderr=stderr)
    events=[]
    non_json=[]
    for index,line in enumerate((OUT/(name+'.jsonl')).read_text().splitlines(),1):
        try: events.append(json.loads(line))
        except json.JSONDecodeError: non_json.append({'line':index,'text':line})
    ended=[event for event in events if event.get('type')=='testDone' and not event.get('hidden')]
    record={**command,'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'exit_code':result.returncode,'passed':sum(event.get('result')=='success' and not event.get('skipped') for event in ended),
        'failed':sum(event.get('result') in ('failure','error') for event in ended),
        'skipped':sum(bool(event.get('skipped')) for event in ended),'completed_visible_tests':len(ended),
        'errors':[event for event in events if event.get('type')=='error'],
        'done':[event for event in events if event.get('type')=='done'],'non_json_output':non_json,
        'stdout_sha256':digest(OUT/(name+'.jsonl')),'stderr_sha256':digest(OUT/(name+'.stderr'))}
    write_json(name+'-receipt.json',record)
    records.append(record)
    print(json.dumps({'stage':name+'-complete','exit_code':result.returncode,'passed':record['passed'],'failed':record['failed'],'skipped':record['skipped']}),flush=True)
    if result.returncode:
        break
after=snapshot('editor-studio-inputs-after')
changes={category:[key for key in sorted(set(before[category])|set(after[category])) if before[category].get(key)!=after[category].get(key)] for category in ('source','dependencies','runtime')}
receipt={'checkpoint':CHECKPOINT,'checkpoint_tree':before['checkpoint_tree'],'head_before':before['head'],'head_after':after['head'],
    'source_files':len(before['source']),'dependency_files':len(before['dependencies']),'runtime_files':len(before['runtime']),
    'input_changes':changes,'all_inputs_unchanged':not any(changes.values()),'cohorts':records}
write_json('editor-studio-qualification.json',receipt)
print(json.dumps({'stage':'complete','all_inputs_unchanged':receipt['all_inputs_unchanged'],'cohorts':len(records)}),flush=True)
raise SystemExit(0 if len(records)==len(cohorts) and all(record['exit_code']==0 for record in records) and receipt['all_inputs_unchanged'] else 1)
