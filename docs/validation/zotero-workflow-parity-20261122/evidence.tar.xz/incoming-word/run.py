import collections,datetime,hashlib,json,pathlib,subprocess
ROOT=pathlib.Path('/workspace/scratch/1cd79da773f9/quds_office_suite')
OUT=ROOT.parent/'validation/incoming-word'
PACKAGE=ROOT/'packages/quds_office_engine'
TESTS=['test/office_vba_word_table_navigation_test.dart','test/office_vba_word_table_navigation_conformance_test.dart','test/office_vba_word_table_navigation_integration_test.dart','test/office_vba_word_table_navigation_cli_test.dart']
paths=sorted(set([*PACKAGE.glob('lib/**/*.dart'),*PACKAGE.glob('tool/macros/**/*.dart'),*PACKAGE.glob('test/support/**/*.dart'),*[PACKAGE/t for t in TESTS],PACKAGE/'test/fixtures/vba_conformance/word_table_navigation_v1.json',PACKAGE/'example/macros/word_table_navigation.bas',ROOT/'pubspec.lock',ROOT/'.dart_tool/package_config.json']))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():return {str(p.relative_to(ROOT)):digest(p) for p in paths}
def write(n,obj):(OUT/n).write_text(json.dumps(obj,indent=2)+'\n')
before=snapshot();write('inputs-before.json',before)
cmd=['dart','--packages='+str(ROOT/'.dart_tool/package_config.json'),str(ROOT.parent/'toolchains/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),*TESTS,'--concurrency=2','--reporter=json']
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),'command':cmd,'cwd':str(PACKAGE),'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtime_receipt_sha256':digest(ROOT.parent/'toolchains/runtime.json')}
write('receipt.json',report)
with (OUT/'events.jsonl').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
 r=subprocess.run(cmd,cwd=PACKAGE,stdout=stdout,stderr=stderr,timeout=600)
after=snapshot();write('inputs-after.json',after)
records={};suites={};errors=[];done=[]
for line in (OUT/'events.jsonl').read_text().splitlines():
 try:e=json.loads(line)
 except ValueError:continue
 if e['type']=='suite':suites[e['suite']['id']]=e['suite']['path']
 if e['type']=='testStart':records[e['test']['id']]=e['test']
 if e['type']=='testDone':records.setdefault(e['testID'],{}).update(e)
 if e['type']=='error':errors.append(e)
 if e['type']=='done':done.append(e)
cases=[dict(suite=suites.get(e.get('suiteID')),name=e.get('name'),result=e.get('result','unfinished'),skipped=e.get('skipped',False)) for e in records.values() if not e.get('hidden') and not e.get('name','').startswith('loading ')]
counts={'passed':sum(e['result']=='success' and not e['skipped'] for e in cases),'failed':sum(e['result']!='success' and e['result']!='unfinished' for e in cases),'skipped':sum(e['skipped'] for e in cases),'unfinished':sum(e['result']=='unfinished' for e in cases)}
report.update(exit_code=r.returncode,counts=counts,inputs_unchanged=before==after,input_count=len(before),changed_inputs=[k for k in before if before[k]!=after[k]],error_events=errors,done_events=done,finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),per_suite={s:{'passed':sum(e['result']=='success' and not e['skipped'] for e in cases if e['suite']==s),'total':sum(e['suite']==s for e in cases)} for s in suites.values()})
write('cases.json',cases)
report['status']='passed' if r.returncode==0 and before==after and len(done)==1 and done[0].get('success') and not errors and not any(counts[k] for k in ['failed','skipped','unfinished']) else 'not_accepted'
report['artifacts_sha256']={p.name:digest(p) for p in OUT.iterdir() if p.is_file() and p.name!='receipt.json'}
write('receipt.json',report)
print(json.dumps(report,indent=2))
