import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/word/model/word_zotero_note.dart';

void main() {
  const samples = <String, String>{
    'empty_heading': '<blockquote><h2></h2></blockquote><p>After</p>',
    'empty_heading_in_cell': '<table><tr><td><blockquote><h2></h2></blockquote></td></tr></table><p>After</p>',
    'empty_quote': '<p>Before</p><blockquote> \n </blockquote><p>After</p>',
    'nested_empty': '<p>Before</p><blockquote><blockquote></blockquote></blockquote><p>After</p>',
    'two_scopes': '<blockquote><p>A</p></blockquote> \n <blockquote><p>B</p></blockquote><p>C</p>',
    'wrapped_text': '<blockquote><div>Alpha <b>Bold</b></div></blockquote><p>After</p>',
    'quoted_list': '<blockquote><ul><li>One</li><li><p>Two</p><p>Continued</p></li></ul><p>Tail</p></blockquote><p>After</p>',
    'vertical_cell': '<table><tr><td rowspan="2"><blockquote><p>A</p></blockquote></td><td>B</td></tr><tr><td><blockquote><p>C</p></blockquote></td></tr></table><blockquote><p>D</p></blockquote>',
  };
  for (final entry in samples.entries) {
    try {
      final note = WordZoteroNoteText.fromHtml(entry.value);
      print(jsonEncode({'name':entry.key,'texts':note.paragraphs.map((p)=>p.text).toList(),'quotes':{'${note.quoteDepths}': true},'headings':note.paragraphs.map((p)=>p.properties.headingLevel).toList(),'lists':note.listItems.keys.toList()}));
      final doc = WmlDocument.empty(text: 'prepost');
      final session=WordZoteroCitingSession(document:doc,documentId:'probe',insertionParagraph:doc.paragraphs.single,insertionOffset:3);
      session.handle('Document.insertText',['probe',entry.value]);
      session.handle('Document.complete',['probe']);
      session.apply();
      for(final mode in ['native','docx']) {
        final current=mode=='native'?doc:WordDeserializer().readBytes(WordSerializer().writeBytes(doc));
        print(jsonEncode({'name':entry.key,'mode':mode,'paragraphs':[for(final p in current.paragraphs){'text':p.text,'left':p.properties.indent.left,'hang':p.properties.indent.hanging,'heading':p.properties.headingLevel,'label':p.properties.listLabel}]}));
      }
    } catch (e,s) {
      print(jsonEncode({'name':entry.key,'error':e.toString(),'stack':s.toString().split('\n').take(3).join('\n')}));
    }
  }
}
