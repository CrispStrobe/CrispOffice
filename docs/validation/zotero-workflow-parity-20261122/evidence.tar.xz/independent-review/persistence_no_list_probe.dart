import 'dart:convert';
import 'dart:io';
import 'package:image/image.dart' as image;
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/word/model/word_zotero_note.dart';

const ids=['A00001','A00002','A00003','A00004'];
String ref(String id)=>'<a href="https://www.zotero.org/?$id">($id)</a>';
Object? call(WordZoteroCitingSession s,String c,[List<Object?> args=const []])=>s.handle(c,['probe',...args]);
List<Map<String,Object?>> describe(WmlDocument d)=>[for(final p in d.paragraphs){'text':p.text,'indent':p.properties.indent.left,'hang':p.properties.indent.hanging,'heading':p.properties.headingLevel,'label':p.properties.listLabel,'pictures':p.inlines.whereType<WmlRun>().where((r)=>r.inlineVisual!=null).length}];
Future<void> main() async {
  final png=base64Encode(image.encodePng(image.Image(width:2,height:2)));
  final html='<blockquote><h2>Title 😀 <img src="data:image/png;base64,$png"/> ${ref(ids[0])}</h2><p>First ${ref(ids[1])}</p><p>Continuation</p><blockquote><p>Inner <b>bold</b></p></blockquote></blockquote><table><tr><td rowspan="2">Plain</td><td>Other</td></tr><tr><td><blockquote><p>Cell ${ref(ids[2])}</p></blockquote></td></tr></table><blockquote><p>Last ${ref(ids[3])}</p></blockquote>';
  final parsed=WordZoteroNoteText.fromHtml(html);
  print(jsonEncode({'phase':'parsed','texts':parsed.paragraphs.map((p)=>p.text).toList(),'quotes':parsed.quoteDepths.toString(),'refs':{for(final e in parsed.placeholders.entries)e.key:{'paragraph':e.value.paragraphIndex,'start':e.value.start,'end':e.value.end,'substring':parsed.paragraphs[e.value.paragraphIndex].text.substring(e.value.start,e.value.end)}}}));
  final d=WmlDocument.empty(text:'BeforeAfter');
  d.zoteroDocumentData=jsonEncode({'dataVersion':4,'style':{'styleID':'http://www.zotero.org/styles/apa','locale':'en-US','bibliographyStyleHasBeenSet':true},'prefs':{'fieldType':'Field','noteType':0}});
  final s=WordZoteroCitingSession(document:d,documentId:'probe',insertionParagraph:d.paragraphs.single,insertionOffset:6);
  call(s,'Document.insertText',[html]);
  final fields=call(s,'Document.convertPlaceholdersToFields',[ids.reversed.toList(),0,'Http']) as List;
  for(final (index,f) in fields.indexed) {
    final id=ids.reversed.elementAt(index);
    final cite=ZoteroCitation(citationId:id,plainCitation:'[$id]',items:[ZoteroCitationItem.fromCsl(itemData:{'id':id,'type':'book','title':'Source $id'},uris:['http://zotero.org/users/42/items/ABCD1234'])]);
    call(s,'Field.setCode',[f['id'],'ITEM CSL_CITATION ${jsonEncode(cite.toJson())}']);
    call(s,'Field.setText',[f['id'],'<i>[$id]</i>',true]);
  }
  call(s,'Document.complete');
  s.apply();
  final before=describe(d);
  print(jsonEncode({'phase':'native','paragraphs':before,'fields':WordZotero.fields(d).map((f)=>{'id':f.citation?.citationId,'text':f.cachedText,'paragraph':f.paragraph.text}).toList()}));
  final docx=WordSerializer().writeBytes(d);
  File('/workspace/scratch/1cd79da773f9/blockquote-review/probe-no-list.docx').writeAsBytesSync(docx);
  final reopened=WordDeserializer().readBytes(docx);
  print(jsonEncode({'phase':'docx','paragraphs':describe(reopened),'matches':jsonEncode(before)==jsonEncode(describe(reopened)),'fields':WordZotero.fields(reopened).map((f)=>f.citation?.citationId).toList()}));
  try {
    final odt=OdtDocumentWriter.writeEditableZoteroBytes(d);
    File('/workspace/scratch/1cd79da773f9/blockquote-review/probe-no-list.odt').writeAsBytesSync(odt);
    final imported=await OdtDocumentReader.readBytes(odt);
    print(jsonEncode({'phase':'odt','paragraphs':describe(imported),'matches':jsonEncode(before)==jsonEncode(describe(imported)),'fields':WordZotero.fields(imported).map((f)=>f.citation?.citationId).toList()}));
  }catch(e,st){print(jsonEncode({'phase':'odt','error':e.toString(),'stack':st.toString().split('\n').take(3).join('\n')}));}
}
