import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_studio/studio_mail_compose.dart';
import 'package:quds_office_studio/studio_strings.dart';

void main() {
  testWidgets('short window retains a usable uncertain-send composer', (tester) async {
    await tester.binding.setSurfaceSize(const Size(640, 360));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    tester.platformDispatcher.textScaleFactorTestValue = 1.5;
    addTearDown(tester.platformDispatcher.clearTextScaleFactorTestValue);
    await tester.pumpWidget(const MaterialApp(home: StudioMailComposeDialog(
      strings: StudioStrings(StudioLanguage.en),
      from: 'sender@example.invalid',
      previousSubmissionUncertain: true,
      initialDraft: StudioMailDraft(to: 'recipient@example.invalid', subject: 'Draft', body: 'Body.'),
    )));
    await tester.pump();
    expect(tester.takeException(), isNull);
  });
}
