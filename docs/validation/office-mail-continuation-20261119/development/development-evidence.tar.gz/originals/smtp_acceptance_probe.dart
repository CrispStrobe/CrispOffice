import 'dart:async';
import 'dart:convert';
import 'package:enough_mail/enough_mail.dart';

final class ProbeClient extends SmtpClient {
  ProbeClient(this.nonSuccessAt, [this.replyCode = 100]) : super('controlled.invalid');
  final int nonSuccessAt;
  final int replyCode;
  final commands = <String>[];

  void respond(String text) {
    final stage = commands.length;
    commands.add(text.startsWith('MAIL FROM') ? 'MAIL FROM'
        : text.startsWith('RCPT TO') ? 'RCPT TO'
        : text == 'DATA' ? 'DATA'
        : text.startsWith('BDAT') ? 'BDAT'
        : text == 'RSET' ? 'RSET'
        : 'PAYLOAD');
    final reply = stage == nonSuccessAt ? '$replyCode not accepted'
        : text == 'DATA' ? '354 send payload' : '250 ok';
    scheduleMicrotask(() => onServerResponse([reply]));
  }

  @override
  Future<void> writeText(String text, [dynamic logObject, Duration? timeout]) async => respond(text);
  @override
  Future<void> writeData(List<int> data, [dynamic logObject]) async => respond(utf8.decode(data));
}

Future<void> main() async {
  final message = (MessageBuilder()
    ..from = const [MailAddress(null, 'from@example.test')]
    ..to = const [MailAddress(null, 'to@example.test')]
    ..addTextPlain('Controlled payload')).buildMimeMessage();
  for (final scenario in [(false, 0, 100), (false, 3, 100), (true, 0, 100), (true, 2, 100), (false, 2, 250), (false, 3, 220), (true, 2, 220)]) {
    final client = ProbeClient(scenario.$2, scenario.$3);
    try {
      final response = scenario.$1
          ? await client.sendChunkedMessage(message, supportUnicode: false)
          : await client.sendMessage(message);
      print(jsonEncode({'bdat': scenario.$1, 'non_success_at': scenario.$2, 'reply': scenario.$3,
        'unexpected_success': response.code, 'commands': client.commands}));
    } catch (error) {
      print(jsonEncode({'bdat': scenario.$1, 'non_success_at': scenario.$2, 'reply': scenario.$3,
        'rejected': error.runtimeType.toString(), 'commands': client.commands}));
    }
  }
}
