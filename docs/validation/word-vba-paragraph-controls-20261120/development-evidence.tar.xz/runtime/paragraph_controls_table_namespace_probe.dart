import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;
void main() {
  final package = OpcPackage.openBytes((DocxDocumentBuilder()..paragraph('template')).build());
  package.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="${OfficeNamespaces.w}"><w:body><w:tbl><w:tblPr><w:tblStyle w:val="TableStyle"/></w:tblPr><w:tblGrid><w:gridCol w:w="2000"/></w:tblGrid><w:tr><w:tc><w:p><w:r><w:t>target</w:t></w:r></w:p></w:tc></w:tr></w:tbl><w:sectPr/></w:body></w:document>');
  package.getPart('/word/styles.xml')!.writeText('<w:styles xmlns:w="${OfficeNamespaces.w}" xmlns:x="urn:foreign"><w:style w:type="table" w:styleId="TableStyle"><x:tblStylePr x:type="wholeTable"><w:pPr><w:spacing w:before="120"/></w:pPr></x:tblStylePr></w:style></w:styles>');
  final doc=WordDeserializer().readBytes(package.save());
  final before=doc.paragraphs.single.properties.spacingBefore;
  String? failure;
  try {native.applyStep(doc, {'op':'paragraphSpaceBefore','paragraph':0,'action':'toggle'});}catch(e){failure=e.toString();}
  print(jsonEncode({'before':before,'after':doc.paragraphs.single.properties.spacingBefore,'error':failure}));
}
