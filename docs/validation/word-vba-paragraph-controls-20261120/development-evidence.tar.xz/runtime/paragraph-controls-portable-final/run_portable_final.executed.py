#!/usr/bin/env python3
"""Run exact incoming/new Word BAS on VM and compiled JavaScript after freeze."""
from __future__ import annotations
import argparse
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--helper', type=Path)
    args = parser.parse_args()
    repo, runtime, out = args.repo.resolve(), args.runtime.resolve(), args.output.resolve()
    helper = args.helper or repo/'docs/validation/word-vba-paragraph-controls-20261120/run_validation.py'
    spec = importlib.util.spec_from_file_location('paragraph_controls_validation', helper)
    assert spec and spec.loader
    shared = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = shared
    spec.loader.exec_module(shared)
    out.mkdir(parents=True, exist_ok=False)
    engine = repo/'packages/quds_office_engine'
    dart = runtime/'dart-sdk/bin/dart'
    environment = shared.load_environment(runtime)
    node = Path(environment['CODEX_PRIMARY_RUNTIME_NODE']).resolve()
    configuration = '--packages='+str(repo/'.dart_tool/package_config.json')
    current_head = lambda: subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
    assert current_head() == args.expected_head, 'Source HEAD must match the explicit freeze'
    script = Path(__file__).resolve()
    extras = (script, node)
    source_before = shared.collect_source_inputs(repo)
    runtime_before = shared.collect_runtime_inputs(repo, runtime, extra_paths=extras)
    head_binding_before = shared.source_matches_head(repo, source_before)
    assert head_binding_before['matches'], 'Source inputs must match the frozen commit'
    shared.write_gzip_json(out/'source-before.json.gz', source_before)
    shared.write_gzip_json(out/'runtime-before.json.gz', runtime_before)
    receipt = {
        'scope':'Source-bound exact-BAS portable qualification',
        'started_utc':shared.utc_now(),
        'source_head':args.expected_head,
        'source_input_count':len(source_before),
        'runtime_input_count':len(runtime_before),
        'source_matches_head_before':head_binding_before,
        'script':shared.file_signature(script),
        'helper':shared.file_signature(helper),
        'examples':[],
        'qualified':False,
    }
    shared.write_json(out/'receipt.json', receipt)
    succeeded = True
    try:
        for label, stem, define_key in [
            ('incoming-line-spacing', 'word_line_spacing', 'WORD_LINE_SPACING_BAS_BASE64'),
            ('paragraph-controls', 'word_paragraph_controls', 'WORD_PARAGRAPH_CONTROLS_BAS_BASE64'),
        ]:
            sample = out/label
            sample.mkdir()
            bas = engine/'example/macros'/f'{stem}.bas'
            driver = engine/'tool/macros'/f'web_vba_{stem}_smoke.dart'
            actual_bas = bas.read_bytes()
            (sample/'actual-example.bas').write_bytes(actual_bas)
            define = '-D'+define_key+'='+base64.b64encode(actual_bas).decode()
            js = sample/(stem+'.js')
            item = {
                'name':label,
                'bas_path':str(bas.relative_to(repo)),
                'bas_bytes':len(actual_bas),
                'bas_sha256':digest(actual_bas),
                'driver_path':str(driver.relative_to(repo)),
                'driver_sha256':digest(driver.read_bytes()),
                'commands':[],
            }
            receipt['examples'].append(item)
            commands = [
                ('vm',[str(dart),configuration,define,str(driver)]),
                ('compile-js',[str(dart),'compile','js','-O1',configuration,define,'-o',str(js),str(driver)]),
                ('node',[str(node),'-e','globalThis.self = globalThis; require(process.argv[1]);',str(js)]),
            ]
            for name, argv in commands:
                print('START '+label+' '+name, flush=True)
                started = shared.utc_now()
                timer = time.monotonic()
                with (sample/(name+'.stdout')).open('wb') as stdout, (sample/(name+'.stderr')).open('wb') as stderr:
                    completed = subprocess.run(argv, cwd=engine, env=environment, stdout=stdout, stderr=stderr, timeout=300)
                command = {
                    'name':name,'argv':argv,'cwd':str(engine),
                    'started_utc':started,'seconds':round(time.monotonic()-timer,3),
                    'exit_code':completed.returncode,
                    'stdout':shared.file_signature(sample/(name+'.stdout')),
                    'stderr':shared.file_signature(sample/(name+'.stderr')),
                }
                item['commands'].append(command)
                shared.write_json(out/'receipt.json', receipt)
                print('END '+label+' '+name+' exit='+str(completed.returncode), flush=True)
                if completed.returncode != 0:
                    raise RuntimeError(f'{label}/{name} failed; inspect recorded stdout/stderr')
            vm = (sample/'vm.stdout').read_bytes()
            javascript = (sample/'node.stdout').read_bytes()
            vm_value, javascript_value = json.loads(vm), json.loads(javascript)
            item.update({
                'raw_outputs_equal':vm==javascript,
                'canonical_results_equal':vm_value==javascript_value,
                'raw_output_bytes':len(vm),
                'raw_output_sha256':digest(vm),
                'canonical_sha256':digest(json.dumps(vm_value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()),
            })
            shared.write_json(sample/'result.json', vm_value)
            shared.write_json(sample/'receipt.json', item)
            assert item['raw_outputs_equal'] and item['canonical_results_equal'], 'Portable outputs differ'
            assert bas.read_bytes()==actual_bas, 'Example source changed while running'
            assert digest(driver.read_bytes())==item['driver_sha256'], 'Portable driver changed while running'
    except BaseException as error:
        succeeded = False
        receipt['error'] = repr(error)
    finally:
        source_after = shared.collect_source_inputs(repo)
        runtime_after = shared.collect_runtime_inputs(repo, runtime, extra_paths=extras)
        shared.write_gzip_json(out/'source-after.json.gz', source_after)
        shared.write_gzip_json(out/'runtime-after.json.gz', runtime_after)
        head_binding_after = shared.source_matches_head(repo, source_after)
        receipt.update({
            'source_matches_head_after':head_binding_after,
            'finished_utc':shared.utc_now(),
            'source_head_after':current_head(),
            'source_inputs_unchanged':source_before==source_after,
            'runtime_inputs_unchanged':runtime_before==runtime_after,
            'source_head_unchanged':current_head()==args.expected_head,
        })
        receipt['qualified'] = bool(succeeded and receipt['source_inputs_unchanged'] and receipt['runtime_inputs_unchanged'] and receipt['source_head_unchanged'] and head_binding_after['matches'])
        shared.write_json(out/'receipt.json', receipt)
        print(json.dumps({k:v for k,v in receipt.items() if k not in ['examples','script','helper']},indent=2), flush=True)
    return 0 if receipt['qualified'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
