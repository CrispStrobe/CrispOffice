export QUDS_VALIDATION_ROOT=/workspace/scratch/b77d79e8305c/quds_office_suite
export QUDS_DART_ROOT=/workspace/scratch/b77d79e8305c/runtime/dart-sdk
export PUB_CACHE=/workspace/scratch/b77d79e8305c/runtime/pub-cache
export TMPDIR=/workspace/scratch/b77d79e8305c/runtime/tmp
export XDG_CONFIG_HOME=/workspace/scratch/b77d79e8305c/runtime/config
export XDG_CACHE_HOME=/workspace/scratch/b77d79e8305c/runtime/cache
export DART_SUPPRESS_ANALYTICS=true
export PATH="$QUDS_DART_ROOT/bin:$PATH"
