import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;

void main() {
  final cases = <String,String>{
    'foreign_default_style': '<w:style w:type="paragraph" w:default="1" w:styleId="Base"><w:pPr><w:spacing w:before="0"/></w:pPr></w:style><x:style x:type="paragraph" x:default="1" x:styleId="Foreign"><w:pPr><w:spacing w:before="120"/></w:pPr></x:style>',
    'foreign_default_attribute': '<w:style w:type="paragraph" x:default="1" w:styleId="Base"><w:pPr><w:spacing w:before="120"/></w:pPr></w:style>',
    'foreign_based_on': '<w:style w:type="paragraph" w:styleId="Positive"><w:pPr><w:spacing w:before="120"/></w:pPr></w:style><w:style w:type="paragraph" w:default="1" w:styleId="Base"><x:basedOn x:val="Positive"/></w:style>',
  };
  final results = <Map<String, Object?>>[];
  for (final entry in cases.entries) {
    final package = OpcPackage.openBytes((DocxDocumentBuilder()..paragraph('template')).build());
    package.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="${OfficeNamespaces.w}"><w:body><w:p><w:r><w:t>target</w:t></w:r></w:p><w:sectPr/></w:body></w:document>');
    package.getPart('/word/styles.xml')!.writeText('<w:styles xmlns:w="${OfficeNamespaces.w}" xmlns:x="urn:foreign">${entry.value}</w:styles>');
    final doc = WordDeserializer().readBytes(package.save());
    final before = doc.paragraphs.single.properties.spacingBefore;
    String? failure;
    try { native.applyStep(doc, {'op':'paragraphSpaceBefore','paragraph':0,'action':'toggle'}); } catch(e) {failure=e.toString();}
    results.add({'case':entry.key,'before':before,'after':doc.paragraphs.single.properties.spacingBefore,'error':failure});
  }
  print(jsonEncode(results));
}
