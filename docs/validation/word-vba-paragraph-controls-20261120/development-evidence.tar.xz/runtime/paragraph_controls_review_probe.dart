import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;

void main() {
  final results = <Map<String, Object?>>[];
  for (final value in ['1', 'true', 'on']) {
    final package = OpcPackage.openBytes((DocxDocumentBuilder()..paragraph('template')).build());
    package.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="${OfficeNamespaces.w}"><w:body><w:p><w:r><w:t>target</w:t></w:r></w:p><w:sectPr/></w:body></w:document>');
    package.getPart('/word/styles.xml')!.writeText('<w:styles xmlns:w="${OfficeNamespaces.w}"><w:style w:type="paragraph" w:default="$value" w:styleId="PositiveDefault"><w:name w:val="Positive default"/><w:pPr><w:spacing w:before="120"/></w:pPr></w:style></w:styles>');
    final doc = WordDeserializer().readBytes(package.save());
    final before = doc.paragraphs.single.properties.spacingBefore;
    String? failure;
    try { native.applyStep(doc, {'op':'paragraphSpaceBefore','paragraph':0,'action':'toggle'}); } catch(e) {failure=e.toString();}
    final after = doc.paragraphs.single.properties.spacingBefore;
    results.add({'defaultAttribute':value,'before':before,'after':after,'error':failure});
  }
  print(jsonEncode(results));
}
