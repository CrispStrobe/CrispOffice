#!/usr/bin/env python3
"""Preserve setup/development evidence separately from final qualification."""
from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile
root=Path('/workspace/scratch/b77d79e8305c')
runtime=root/'runtime'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Recover the exact already-executed pre-JS-binding collector, verified against
# its contemporaneous receipt, without altering the current final runner.
current=(root/'runtime-prep/run_portable_final.py').read_text()
old=current.replace("                if name == 'node':\n                    item['node_input_before'] = shared.file_signature(js)\n                    assert item['node_input_before'] == item['compiled_js'], 'Compiled JavaScript changed before execution'\n",'')
old=old.replace("                if name == 'compile-js' and completed.returncode == 0:\n                    item['compiled_js'] = shared.file_signature(js)\n                if name == 'node':\n                    item['node_input_after'] = shared.file_signature(js)\n                    item['executed_js_unchanged'] = item['compiled_js'] == item['node_input_before'] == item['node_input_after']\n                    assert item['executed_js_unchanged'], 'Executed JavaScript changed during Node execution'\n",'')
prior=runtime/'paragraph-controls-portable-final'
receipt=json.loads((prior/'receipt.json').read_text())
assert hashlib.sha256(old.encode()).hexdigest()==receipt['script']['sha256']
(prior/'run_portable_final.executed.py').write_text(old)
# Preserve the actual interrupted pre-batching collector from its source freeze.
interrupted=runtime/'paragraph-controls-final'
collector_path='docs/validation/word-vba-paragraph-controls-20261120/run_validation.py'
collector=subprocess.check_output(['git','show','7c64246b5bb7c441206ae0bca99948f33b091f13:'+collector_path],cwd=root/'quds_office_suite')
inputs=json.loads(gzip.decompress((interrupted/'regression-source-before.json.gz').read_bytes()))
expected_collector=inputs[collector_path]['sha256']
assert hashlib.sha256(collector).hexdigest()==expected_collector
(interrupted/'run_validation.executed.py').write_bytes(collector)
selected=[]
for name in ['runtime-prep/reproduce_runtime.py','runtime-prep/run-paragraph-controls-portable.py','runtime-prep/package_paragraph_development.py','runtime/env.sh','runtime/environment.json','runtime/setup-verification.json','runtime/reproduction-command.json','runtime/run-engine-tests.sh']:
 p=root/name
 assert p.is_file(),name
 selected.append(p)
selected.extend(p for p in runtime.glob('setup-smoke*') if p.is_file())
selected.extend(p for p in runtime.glob('paragraph*') if p.is_file() and p.name not in {
 'paragraph-controls-development-evidence.tar.xz',
 'paragraph-controls-development-members.json',
 'paragraph-controls-development-packaging.json',
})
review=root/'quds_office_suite/docs/validation/word-vba-paragraph-controls-20261120/source-review.json'
if review.is_file():selected.append(review)
for name in ['paragraph-controls-final','kernel-smoke','kernel-smoke-2','paragraph-controls-portable-development','paragraph-controls-portable-development-2','paragraph-controls-portable-final']:
 selected.extend(p for p in (runtime/name).rglob('*') if p.is_file())
selected=sorted(set(selected))
manifest={'scope':'Setup/development/failed qualification only; excluded from final passing totals','files':[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in selected]}
manifest_path=runtime/'paragraph-controls-development-members.json'
manifest_path.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
archive=runtime/'paragraph-controls-development-evidence.tar.xz'
with tarfile.open(archive,'w:xz') as bundle:
 for p in selected+[manifest_path]:
  info=bundle.gettarinfo(str(p),arcname=str(p.relative_to(root)))
  info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with p.open('rb') as data:bundle.addfile(info,data)
with tarfile.open(archive) as bundle:
 for item in manifest['files']:
  data=bundle.extractfile(item['path']).read()
  assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
result={'scope':manifest['scope'],'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'members_including_manifest':len(selected)+1,'members_verified':True,'recovered_executed_portable_runner_sha256':receipt['script']['sha256'],'recovered_interrupted_collector_sha256':expected_collector}
(runtime/'paragraph-controls-development-packaging.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result,indent=2))
