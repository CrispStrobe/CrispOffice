import base64,hashlib,json,os,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
root=Path('/workspace/scratch/b77d79e8305c')
repo=root/'quds_office_suite'
runtime=root/'runtime'
engine=repo/'packages/quds_office_engine'
out=runtime/'paragraph-controls-portable-development-2'
out.mkdir(exist_ok=True)
source=engine/'example/macros/word_paragraph_controls.bas'
driver=engine/'tool/macros/web_vba_word_paragraph_controls_smoke.dart'
dart=runtime/'dart-sdk/bin/dart'
node=Path(os.environ['CODEX_PRIMARY_RUNTIME_NODE'])
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
define='-DWORD_PARAGRAPH_CONTROLS_BAS_BASE64='+base64.b64encode(source.read_bytes()).decode()
package='--packages='+str(repo/'.dart_tool/package_config.json')
js=out/'paragraph-controls.js'
commands=[('vm',[str(dart),package,define,str(driver)]),('compile-js',[str(dart),'compile','js','-O1',package,define,'-o',str(js),str(driver)]),('node',[str(node),'-e','globalThis.self = globalThis; require(process.argv[1]);',str(js)])]
record={'scope':'Development portable execution; final source-bound qualification is separate','bas_sha256':sha(source),'driver_sha256':sha(driver),'commands':[]}
(out/'actual-example.bas').write_bytes(source.read_bytes())
for name,argv in commands:
 print('START '+name,flush=True)
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  completed=subprocess.run(argv,cwd=engine,stdout=stdout,stderr=stderr,timeout=240)
 record['commands'].append({'name':name,'argv':argv,'exit_code':completed.returncode,'seconds':round(time.monotonic()-start,3),'stdout_sha256':sha(out/(name+'.stdout')),'stderr_sha256':sha(out/(name+'.stderr'))})
 (out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
 print('END '+name+' exit='+str(completed.returncode),flush=True)
 if completed.returncode: raise RuntimeError((out/(name+'.stderr')).read_text()[-8000:])
vm=(out/'vm.stdout').read_bytes();js=(out/'node.stdout').read_bytes()
record['raw_outputs_equal']=vm==js
record['raw_output_bytes']=len(vm)
record['raw_output_sha256']=hashlib.sha256(vm).hexdigest()
record['canonical_results_equal']=json.loads(vm)==json.loads(js)
record['source_driver_unchanged']=record['driver_sha256']==sha(driver)
record['source_bas_unchanged']=record['bas_sha256']==sha(source)
(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
assert all(record[k] for k in ['raw_outputs_equal','canonical_results_equal','source_driver_unchanged','source_bas_unchanged'])
print(json.dumps({k:v for k,v in record.items() if k!='commands'},indent=2),flush=True)
