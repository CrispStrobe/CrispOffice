from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

ROOT = Path('/workspace/scratch/b56a923051a9')
REPO = ROOT / 'quds_office_suite'
DEST = ROOT / 'validation' / (sys.argv[1] if len(sys.argv) > 1 else 'mail-draft-final-checks')
DEST.mkdir(parents=True, exist_ok=True)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()

paths = git('diff', '--name-only', 'd4787143856f83ca80a1928f86ce010a64822268', '--', '*.dart').splitlines()
def hashes():
    return {path: hashlib.sha256((REPO / path).read_bytes()).hexdigest() for path in paths}

receipt = {
    'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit': git('rev-parse', 'HEAD'),
    'source_before': hashes(),
    'scope': 'Changed Dart source/tests relative to the integrated intake; no whole-repository lint claim.',
    'github_actions': 'not used',
    'checks': [],
}
checks = [
    ('format', ['dart', 'format', '--output=none', '--set-exit-if-changed', *paths]),
    ('analysis', ['flutter', 'analyze', '--no-pub', '--fatal-infos', *paths]),
    ('diff-check', ['git', 'diff', '--check']),
]
for name, command in checks:
    log = DEST / (name + '.log')
    with log.open('wb') as stream:
        result = subprocess.run(command, cwd=REPO, stdout=stream, stderr=subprocess.STDOUT)
    entry = {'name': name, 'command': command, 'cwd': str(REPO), 'exit_code': result.returncode,
             'log': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    receipt['checks'].append(entry)
    print(json.dumps({'name': name, 'exit_code': result.returncode}), flush=True)
receipt['source_after'] = hashes()
receipt['source_unchanged'] = receipt['source_before'] == receipt['source_after']
receipt['status'] = 'passed' if receipt['source_unchanged'] and all(x['exit_code'] == 0 for x in receipt['checks']) else 'failed'
receipt['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
raise SystemExit(0 if receipt['status'] == 'passed' else 1)
