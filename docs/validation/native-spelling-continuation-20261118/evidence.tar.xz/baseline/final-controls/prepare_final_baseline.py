#!/usr/bin/env python3
import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import tarfile

ROOT = pathlib.Path('/workspace/scratch/059a4a5dcb30/quds_office_suite')
OUT = pathlib.Path(__file__).resolve().parent / 'final-baseline'
WORK = pathlib.Path(__file__).resolve().parent / 'final-baseline-workspace'
BASE = '1e07cb852766f8651815138785be74c64a09ddc0'
TESTS = [
    'packages/quds_office_engine/test/proofing/german_spelling_continuation_test.dart',
    'packages/quds_office_editor/test/platform_spelling_projection_test.dart',
    'packages/quds_office_editor/test/platform_spelling_projection_review_test.dart',
    'packages/quds_office_editor/test/platform_spelling_dialog_test.dart',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def main():
    OUT.mkdir(exist_ok=True)
    WORK.mkdir(exist_ok=False)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    process = subprocess.Popen(['git', 'archive', BASE], cwd=ROOT, stdout=subprocess.PIPE)
    with tarfile.open(fileobj=process.stdout, mode='r|') as archive:
        archive.extractall(WORK, filter='data')
    assert process.wait() == 0
    tests = {}
    for name in TESTS:
        data = (ROOT / name).read_bytes()
        (WORK / name).parent.mkdir(parents=True, exist_ok=True)
        (WORK / name).write_bytes(data)
        tests[name] = {'sha256': sha(data), 'git_blob': git_blob(data),
                       'copy_sha256': sha((WORK / name).read_bytes())}
    lock = (ROOT / 'pubspec.lock').read_bytes()
    (WORK / 'pubspec.lock').write_bytes(lock)
    assert not git('ls-tree', BASE, 'pubspec.lock').strip()
    source = {}
    for entry in git('ls-tree', '-r', '-z', BASE).split(b'\0'):
        if not entry:
            continue
        header, name = entry.split(b'\t', 1)
        path = name.decode()
        if '/lib/' not in path and not path.endswith(('pubspec.yaml', 'analysis_options.yaml')):
            continue
        mode, kind, blob = header.decode().split()
        if kind != 'blob':
            continue
        data = (WORK / path).read_bytes()
        actual = git_blob(data)
        assert actual == blob, path
        source[path] = {'baseline_git_blob': blob, 'local_git_blob': actual,
                        'sha256': sha(data)}
    record = {
        'schema': 'quds.native_spelling_continuation.final_baseline.v1',
        'prepared_at_utc': started,
        'baseline_commit': BASE,
        'baseline_tree': git('rev-parse', BASE + '^{tree}').decode().strip(),
        'workspace': str(WORK),
        'method': 'Read-only git archive baseline; replace only the four final test files; copy identical ignored root pubspec.lock; offline dependency resolution follows.',
        'tests': tests,
        'lock_sha256': sha(lock),
        'baseline_source_file_count': len(source),
        'source': source,
        'github_actions_workflow_checks_or_status_endpoints_used': False,
    }
    (OUT / 'inputs-before.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({k: v for k, v in record.items() if k not in ['source']}, indent=2))


if __name__ == '__main__':
    main()
