#!/usr/bin/env python3
import collections
import concurrent.futures
import datetime
import hashlib
import json
import pathlib
import subprocess
import time
import urllib.parse

ROOT = pathlib.Path('/workspace/scratch/059a4a5dcb30/quds_office_suite')
HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE / 'final-baseline'
WORK = HERE / 'final-baseline-workspace'
FLUTTER = pathlib.Path('/workspace/scratch/059a4a5dcb30/local_runtime/sdk/flutter')
PUB = pathlib.Path('/workspace/scratch/059a4a5dcb30/local_runtime/pub-cache')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def graph(root):
    config = root / '.dart_tool/package_config.json'
    value = json.loads(config.read_text())
    rows = []
    for entry in value['packages']:
        uri = urllib.parse.urljoin(config.as_uri(), entry['rootUri'])
        path = pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(uri).path)).resolve()
        kind = 'unknown'
        for directory, label in [(root, 'workspace'), (FLUTTER, 'flutter'), (PUB, 'pub-cache')]:
            if path.is_relative_to(directory):
                kind = label
                canonical = label + '/' + str(path.relative_to(directory))
                break
        if kind == 'unknown':
            raise AssertionError((entry['name'], str(path)))
        rows.append(dict(name=entry['name'], root=canonical,
                         packageUri=entry['packageUri'],
                         languageVersion=entry.get('languageVersion')))
    return sorted(rows, key=lambda r: r['name'])


def snapshots(inputs):
    return dict(source={name: sha(WORK / name) for name in inputs['source']},
                copied_tests={name: sha(WORK / name) for name in inputs['tests']},
                current_tests={name: sha(ROOT / name) for name in inputs['tests']},
                lock=sha(WORK / 'pubspec.lock'), current_lock=sha(ROOT / 'pubspec.lock'),
                package_config=sha(WORK / '.dart_tool/package_config.json'))


def run(name, relative_cwd, command):
    begin = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    with (OUT / (name + '.jsonl')).open('wb') as output, (OUT / (name + '.stderr.log')).open('wb') as error:
        process = subprocess.run(command, cwd=WORK / relative_cwd, stdout=output, stderr=error)
    result = dict(name=name, command=command, cwd=relative_cwd, started_at_utc=begin,
                  completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  duration_seconds=round(time.monotonic() - tick, 3),
                  process_exit_code=process.returncode,
                  events_sha256=sha(OUT / (name + '.jsonl')),
                  stderr_sha256=sha(OUT / (name + '.stderr.log')))
    events = []
    non_json = []
    for line in (OUT / (name + '.jsonl')).read_text().splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            non_json.append(line)
    starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    cases = []
    for event in events:
        if event.get('type') == 'testDone' and not event.get('hidden'):
            test = starts[event['testID']]
            cases.append(dict(name=test['name'], result=event['result'],
                              skipped=event['skipped'], test_id=event['testID']))
    result['counts'] = dict(collections.Counter(c['result'] for c in cases))
    result['skipped'] = sum(c['skipped'] for c in cases)
    result['substantive_test_count'] = len(cases)
    result['done'] = [e for e in events if e.get('type') == 'done']
    result['non_json_lines'] = non_json
    result['cases'] = cases
    (OUT / (name + '-summary.json')).write_text(json.dumps(result, indent=2) + '\n')
    return result


def main():
    inputs = json.loads((OUT / 'inputs-before.json').read_text())
    baseline_graph = graph(WORK)
    current_graph = graph(ROOT)
    assert baseline_graph == current_graph
    before = snapshots(inputs)
    assert before['lock'] == before['current_lock'] == inputs['lock_sha256']
    assert all(before['source'][p] == d['sha256'] for p, d in inputs['source'].items())
    assert all(before['copied_tests'][p] == before['current_tests'][p] == d['sha256'] for p,d in inputs['tests'].items())
    dart_version = subprocess.run(['dart','--version'],capture_output=True,text=True)
    assert dart_version.returncode == 0
    (OUT / 'graph.json').write_text(json.dumps(baseline_graph,indent=2)+'\n')
    (OUT / 'before-run.json').write_text(json.dumps(before,indent=2)+'\n')
    commands = [
        ('engine', 'packages/quds_office_engine',
         ['dart','test','--reporter=json','test/proofing/german_spelling_continuation_test.dart']),
        ('editor', 'packages/quds_office_editor',
         ['flutter','test','--no-pub','--reporter','json',
          'test/platform_spelling_projection_test.dart',
          'test/platform_spelling_projection_review_test.dart',
          'test/platform_spelling_dialog_test.dart']),
    ]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda x: run(*x), commands))
    after = snapshots(inputs)
    (OUT / 'after-run.json').write_text(json.dumps(after,indent=2)+'\n')
    assert before == after
    summary = dict(baseline_commit=inputs['baseline_commit'],
                   baseline_tree=inputs['baseline_tree'],
                   toolchain=(dart_version.stdout+dart_version.stderr).strip(),
                   source_files_bound_to_baseline_git=inputs['baseline_source_file_count'],
                   unchanged_source_and_test_guard=True, identical_dependency_graph=True,
                   dependency_graph_package_count=len(baseline_graph),
                   exact_final_tests_bound=True, lock_unchanged=True,
                   runs=[{k:v for k,v in r.items() if k not in ['cases']} for r in results],
                   github_actions_workflow_checks_or_status_endpoints_used=False)
    (OUT / 'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__ == '__main__':
    main()
