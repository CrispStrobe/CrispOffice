# Final-regression baseline control

This is an unchanged-product negative control at main
`1e07cb852766f8651815138785be74c64a09ddc0`, using the exact final bytes of the
four continuation test files. The baseline was extracted with read-only
`git archive` to a separate workspace. No shared working-tree source or Git
state was modified.

Only these tracked test paths were overlaid:

- `packages/quds_office_engine/test/proofing/german_spelling_continuation_test.dart`
- `packages/quds_office_editor/test/platform_spelling_projection_test.dart`
- `packages/quds_office_editor/test/platform_spelling_projection_review_test.dart`
- `packages/quds_office_editor/test/platform_spelling_dialog_test.dart`

The ignored root `pubspec.lock` was copied unchanged from the qualified runtime
workspace. `flutter pub get --offline` regenerated local package locations.
Normalized package roots, language versions and package URIs match all **110
packages** in the current workspace. All **581 baseline library/manifest
files** match the baseline Git blobs. Before/after hashes confirm that those
files, the four copied tests, their final counterparts, the lock and generated
package configuration did not change during execution. The pinned runtime is
Dart 3.13.7 from the restored Flutter distribution.

## Observed result

| Cohort | Cases | Behavioral nonpasses | Passed | Skipped |
| --- | ---: | ---: | ---: | ---: |
| German continuation | 17 | 13 | 4 | 0 |
| Native projection | 10 | 10 | 0 | 0 |
| Native review guards | 4 | 2 | 2 | 0 |
| Native Word dialog | 4 | 2 | 2 | 0 |
| **Total** | **35** | **27** | **8** | **0** |

The 35 cases contain **33 newly added tests and two pre-existing dialog
controls**. Six new compatibility controls and both existing dialog controls
already pass on the baseline. Both test processes exit 1 as expected, finish
their JSON event streams normally and emit empty stderr. All four suites
compile and load. There are no compiler or loading failures.

The 13 German nonpasses consist of three marked-identifier cases producing
extra findings and ten cases missing short accented corrections, their
casing/locale variants or explicit-compound suggestions. The 14 editor
nonpasses expose the missing soft-hyphen request projection, layout-only
suggestions, partial identifiers, incorrect empty-input dispatch and ranges
validated against the wrong text or grapheme space.

The test runner labels cardinality exceptions from `.single` and Flutter
widget assertion wrappers as `error`; those labels are retained in the raw
events and per-case summaries. Their cause is incorrect runtime behavior,
not compilation. In the projected-email case, the controlled native fixture
cannot find `user` in the unprojected `u\u00adser`, and the test rejects the
baseline provider's failed result. The exact mechanism for every case is
recorded in [classification.json](classification.json).

## Receipts

- [summary.json](summary.json): commands, dates, process exits, totals, runtime
  version and guard outcomes.
- [inputs-before.json](inputs-before.json): baseline Git tree/blob identities
  and exact final test hashes.
- [before-run.json](before-run.json), [after-run.json](after-run.json), and
  [graph.json](graph.json): immutable-input and dependency mapping checks.
- `engine.jsonl` and `editor.jsonl`: complete raw event streams; corresponding
  stderr files are empty. The per-cohort summary files retain case names and
  original result labels.
- `prepare_final_baseline.py` and `run_final_baseline.py`: the executed archive,
  binding and test procedure. Their absolute paths document this execution
  environment; adapt those locations when reproducing in another checkout.

Earlier initial controls remain separate and are not added to these totals.
This run does not claim new device dictionaries or language-quality acceptance.
No Actions, workflow, check or CI-status endpoint was queried or awaited.
