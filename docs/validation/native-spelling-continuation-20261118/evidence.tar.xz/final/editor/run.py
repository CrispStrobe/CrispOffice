from pathlib import Path
import datetime,gzip,hashlib,json,os,re,subprocess,time,urllib.parse,yaml
W=Path('/workspace/scratch/059a4a5dcb30'); R=W/'quds_office_suite'; P=R/'packages/quds_office_editor'; O=W/'spelling_evidence/final-editor'; SDK=W/'local_runtime/sdk/flutter'
TESTS=sorted(str(x.relative_to(P)) for x in (P/'test').rglob('*test.dart') if re.search(r'(proofing|platform_spelling).*test\.dart$',str(x)))
assert len(TESTS)==11, TESTS

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return h.hexdigest()

def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()

def snap():
 paths={}
 def add(p,key):
  if p.is_file(): paths[key]={'bytes':p.stat().st_size,'sha256':sha(p)}
 for name in ['legacy_doc_parser','quds_office_engine','quds_office_editor','quds_reports']:
  p=R/'packages'/name
  for f in (p/'lib').rglob('*'):
   if f.is_file():add(f,'workspace/'+str(f.relative_to(R)))
  for sub in ['fonts']:
   for f in (p/sub).rglob('*'):
    if f.is_file():add(f,'workspace/'+str(f.relative_to(R)))
 for f in TESTS:add(P/f,'workspace/'+str((P/f).relative_to(R)))
 for f in [R/'pubspec.yaml',R/'pubspec.lock',R/'.dart_tool/package_config.json',R/'analysis_options.yaml']:
  add(f,'workspace/'+str(f.relative_to(R)))
 for x in yaml.safe_load((R/'pubspec.yaml').read_text())['workspace']:
  f=R/x/'pubspec.yaml';add(f,'workspace/'+str(f.relative_to(R)))
 config=R/'.dart_tool/package_config.json'
 for x in json.loads(config.read_text())['packages']:
  root=Path(urllib.parse.unquote(urllib.parse.urlparse(urllib.parse.urljoin(config.as_uri(),x['rootUri'])).path))
  if root.is_relative_to(R):continue
  package=root/x.get('packageUri','lib/')
  for f in package.rglob('*'):
   if f.is_file():add(f,'dependency/'+x['name']+'/'+str(f.relative_to(root)))
  add(root/'pubspec.yaml','dependency/'+x['name']+'/pubspec.yaml')
 for key in ['bin/cache/dart-sdk/bin/dart','bin/cache/dart-sdk/bin/dartvm','bin/cache/dart-sdk/bin/dartaotruntime','bin/cache/dart-sdk/bin/snapshots/dartdev_aot.dart.snapshot','bin/cache/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot','bin/cache/artifacts/engine/linux-x64/flutter_tester','bin/cache/flutter_tools.snapshot','bin/cache/artifacts/engine/common/flutter_patched_sdk/platform_strong.dill','bin/cache/dart-sdk/lib/_internal/vm_platform_strong.dill']:
  add(SDK/key,'runtime/'+key)
 return paths

def save_snapshot(label,data):
 b=(json.dumps(data,indent=2)+'\n').encode();(O/(label+'.json.gz')).write_bytes(gzip.compress(b,mtime=0));return hashlib.sha256(b).hexdigest()

def differences(a,b):return sorted(k for k in a.keys()|b.keys() if a.get(k)!=b.get(k))

def run(label,argv):
 start=time.monotonic(); at=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (O/(label+'.stdout')).open('wb') as stdout,(O/(label+'.stderr')).open('wb') as stderr:
  proc=subprocess.run(argv,cwd=P,env=dict(os.environ),stdout=stdout,stderr=stderr)
 result={'argv':argv,'cwd':str(P),'started_at':at,'exit_code':proc.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':sha(O/(label+'.stdout')),'stderr_sha256':sha(O/(label+'.stderr'))}
 (O/(label+'-command.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'phase':label,'exit_code':proc.returncode,'elapsed_seconds':result['elapsed_seconds']}),flush=True);return result

def parse(path):
 tests={};done={};errors=[];nonjson=[];final=None
 for i,line in enumerate(path.read_text(errors='replace').splitlines()):
  try:e=json.loads(line)
  except Exception:
   if line.strip():nonjson.append({'line':i+1,'text':line[:1000]})
   continue
  if e.get('type')=='testStart':tests[e['test']['id']]=e['test']
  if e.get('type')=='testDone':done[e['testID']]=e
  if e.get('type')=='error':errors.append(e)
  if e.get('type')=='done':final=e
 selected={i:t for i,t in tests.items() if not done.get(i,{}).get('hidden',False)}
 counts={'passed':0,'failed':0,'skipped':0,'unfinished':0}
 for i in selected:
  d=done.get(i)
  if d is None:counts['unfinished']+=1
  elif d.get('skipped'):counts['skipped']+=1
  elif d.get('result')=='success':counts['passed']+=1
  else:counts['failed']+=1
 return {'counts':counts,'selected_test_count':len(selected),'hidden_tests_excluded':len(tests)-len(selected),'errors':errors,'non_json_lines':nonjson,'done':final}

info={'schema':'quds.native_spelling.final_editor.v1','head_before':head(),'selected_tests':TESTS,'ci_queried_or_waited':False,'scope':'Eleven editor proofing/native-spelling test files and strict analysis of whole editor library plus same tests.'}
before=snap();info['before_bindings_sha256']=save_snapshot('bindings-before',before);info['input_counts']={label:sum(k.startswith(label+'/') for k in before) for label in ['workspace','dependency','runtime']}
print(json.dumps({'phase':'bound','input_counts':info['input_counts'],'selected_tests':len(TESTS)}),flush=True)
test=run('tests',[str(SDK/'bin/flutter'),'test','--no-pub','--reporter','json','--concurrency=2',*TESTS])
after_tests=snap();info['after_tests_bindings_sha256']=save_snapshot('bindings-after-tests',after_tests);info['test_input_changes']=differences(before,after_tests)
info['test_command']=test;info['results']=parse(O/'tests.stdout')
analysis=run('analysis',[str(SDK/'bin/flutter'),'analyze','--no-pub','--fatal-infos','lib',*TESTS]);info['analysis_command']=analysis
final=snap();info['after_analysis_bindings_sha256']=save_snapshot('bindings-after-analysis',final);info['analysis_input_changes']=differences(after_tests,final);info['all_input_changes']=differences(before,final);info['head_after']=head();info['source_and_runtime_unchanged']=before==after_tests==final
c=info['results']['counts'];info['qualifying']=test['exit_code']==0 and analysis['exit_code']==0 and info['source_and_runtime_unchanged'] and c['failed']==0 and c['skipped']==0 and c['unfinished']==0 and info['results']['done'].get('success',False)
info['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(O/'verification.json').write_text(json.dumps(info,indent=2)+'\n')
(O/'events.jsonl.gz').write_bytes(gzip.compress((O/'tests.stdout').read_bytes(),mtime=0))
(O/'README.md').write_text(f'''# Final editor proofing validation\n\nThe selected eleven-file cohort passed **{c['passed']} substantive tests**, with\n{c['failed']} failures, {c['skipped']} skips and {c['unfinished']} unfinished cases. Hidden loading events\nare excluded using `testDone.hidden`. Strict analysis covers the full editor\n`lib` plus the same eleven selected test files. Its exit code is\n{analysis['exit_code']}.\n\nQualification accepted: **{info['qualifying']}**.\n\nBefore tests, after tests and after analysis, all bound workspace sources,\nselected tests, font assets, manifests, lock/package configuration, restored\ndependency library bytes and runtime binaries match. Input counts:\n{json.dumps(info['input_counts'])}. Exact input maps are compressed without\nchanging their JSON bytes. `verification.json` records their hashes, exact\ncommands, runtimes, source heads and substantive outcomes.\n\nThe command's starting source head was `{info['head_before']}`;\nsource identity is the exact input map, including the then-uncommitted German\ncontinuation fix and new review tests. The ending source head is\n`{info['head_after']}`. Documentation, changelogs and the separate portable\nsmoke tool are outside this cohort's imported input set.\n\n`events.jsonl.gz` preserves the full original event stream; `tests.stdout`\ncontains the same uncompressed bytes for immediate inspection. Do not count\nfocused review/baseline reruns again in this total. Controlled native-service\nand channel responses do not qualify installed device dictionaries, target\ndevice performance or full application builds.\n\nNo GitHub CI endpoint was queried or awaited.\n''')
print(json.dumps({'phase':'complete','qualifying':info['qualifying'],'counts':c,'changes':info['all_input_changes'],'analysis_exit':analysis['exit_code']}),flush=True)
