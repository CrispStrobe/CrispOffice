# Final editor proofing validation

The selected eleven-file cohort passed **167 substantive tests**, with
0 failures, 0 skips and 0 unfinished cases. Hidden loading events
are excluded using `testDone.hidden`.

Strict analysis passed for the full editor library and all eleven selected
test files. The actual entry point was `dart analyze --fatal-infos`: one
invocation for `lib`, then one for each selected test, using the authentic
Flutter SDK's bundled Dart binary and unchanged Flutter package configuration.
All twelve invocations exit zero. Exact commands and raw stdout/stderr are
recorded separately; no unsupported `--no-pub` argument was passed to Dart.

Qualification accepted: **True**.

All bound inputs match before tests, after tests, before Dart analysis and
after Dart analysis: workspace source, selected tests, font assets,
workspace manifests, lock/package configuration, restored dependency library
bytes and runtime binaries. Input counts: {"workspace": 507, "dependency": 5011, "runtime": 9}.
The compressed maps retain exact original JSON bytes; `verification.json`
records their hashes, commands, timing, source heads and substantive outcomes.

The command's starting source head was `d6a9ca51b16daa9d3d54e163bc723b76659d70ac`;
all tested tracked workspace source, tests and assets match that product
checkpoint, including the German continuation code and new review tests.
`product-source-binding.json` verifies all 505 tracked workspace inputs;
ignored dependency lock and package configuration are bound separately. The ending source head is
`d6a9ca51b16daa9d3d54e163bc723b76659d70ac`. Documentation, changelogs and the separate portable
smoke tool are outside this cohort's imported input set.

## Retained analyzer preflight

The requested `flutter analyze --no-pub --fatal-infos ...` invocation exited
before analysis because it attempted to enumerate `flutter/dev/`, omitted
by the authenticated SDK extraction selection. `analysis.stdout`,
`analysis.stderr` and `analysis-command.json` preserve that failed preflight.
The equivalent genuine Dart analysis completed with no SDK changes and no
repeat test run.

## Evidence and limits

`events.jsonl.gz` preserves the full original event stream; `tests.stdout`
has the same uncompressed bytes for immediate inspection. Focused review and
baseline reruns are not added to this final total. Controlled native-service
and channel responses do not qualify installed device dictionaries, target
device performance or full application builds.

No GitHub CI endpoint was queried or awaited.
