from pathlib import Path
import datetime,gzip,hashlib,json,os,re,subprocess,time,urllib.parse,yaml
W=Path('/workspace/scratch/059a4a5dcb30'); R=W/'quds_office_suite'; P=R/'packages/quds_office_editor'; O=W/'spelling_evidence/final-editor'; SDK=W/'local_runtime/sdk/flutter'
TESTS=sorted(str(x.relative_to(P)) for x in (P/'test').rglob('*test.dart') if re.search(r'(proofing|platform_spelling).*test\.dart$',str(x)))
assert len(TESTS)==11, TESTS

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return h.hexdigest()

def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()

def snap():
 paths={}
 def add(p,key):
  if p.is_file(): paths[key]={'bytes':p.stat().st_size,'sha256':sha(p)}
 for name in ['legacy_doc_parser','quds_office_engine','quds_office_editor','quds_reports']:
  p=R/'packages'/name
  for f in (p/'lib').rglob('*'):
   if f.is_file():add(f,'workspace/'+str(f.relative_to(R)))
  for sub in ['fonts']:
   for f in (p/sub).rglob('*'):
    if f.is_file():add(f,'workspace/'+str(f.relative_to(R)))
 for f in TESTS:add(P/f,'workspace/'+str((P/f).relative_to(R)))
 for f in [R/'pubspec.yaml',R/'pubspec.lock',R/'.dart_tool/package_config.json',R/'analysis_options.yaml']:
  add(f,'workspace/'+str(f.relative_to(R)))
 for x in yaml.safe_load((R/'pubspec.yaml').read_text())['workspace']:
  f=R/x/'pubspec.yaml';add(f,'workspace/'+str(f.relative_to(R)))
 config=R/'.dart_tool/package_config.json'
 for x in json.loads(config.read_text())['packages']:
  root=Path(urllib.parse.unquote(urllib.parse.urlparse(urllib.parse.urljoin(config.as_uri(),x['rootUri'])).path))
  if root.is_relative_to(R):continue
  package=root/x.get('packageUri','lib/')
  for f in package.rglob('*'):
   if f.is_file():add(f,'dependency/'+x['name']+'/'+str(f.relative_to(root)))
  add(root/'pubspec.yaml','dependency/'+x['name']+'/pubspec.yaml')
 for key in ['bin/cache/dart-sdk/bin/dart','bin/cache/dart-sdk/bin/dartvm','bin/cache/dart-sdk/bin/dartaotruntime','bin/cache/dart-sdk/bin/snapshots/dartdev_aot.dart.snapshot','bin/cache/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot','bin/cache/artifacts/engine/linux-x64/flutter_tester','bin/cache/flutter_tools.snapshot','bin/cache/artifacts/engine/common/flutter_patched_sdk/platform_strong.dill','bin/cache/dart-sdk/lib/_internal/vm_platform_strong.dill']:
  add(SDK/key,'runtime/'+key)
 return paths

def save_snapshot(label,data):
 b=(json.dumps(data,indent=2)+'\n').encode();(O/(label+'.json.gz')).write_bytes(gzip.compress(b,mtime=0));return hashlib.sha256(b).hexdigest()

def differences(a,b):return sorted(k for k in a.keys()|b.keys() if a.get(k)!=b.get(k))

def run(label,argv):
 start=time.monotonic(); at=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (O/(label+'.stdout')).open('wb') as stdout,(O/(label+'.stderr')).open('wb') as stderr:
  proc=subprocess.run(argv,cwd=P,env=dict(os.environ),stdout=stdout,stderr=stderr)
 result={'argv':argv,'cwd':str(P),'started_at':at,'exit_code':proc.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':sha(O/(label+'.stdout')),'stderr_sha256':sha(O/(label+'.stderr'))}
 (O/(label+'-command.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'phase':label,'exit_code':proc.returncode,'elapsed_seconds':result['elapsed_seconds']}),flush=True);return result

def parse(path):
 tests={};done={};errors=[];nonjson=[];final=None
 for i,line in enumerate(path.read_text(errors='replace').splitlines()):
  try:e=json.loads(line)
  except Exception:
   if line.strip():nonjson.append({'line':i+1,'text':line[:1000]})
   continue
  if e.get('type')=='testStart':tests[e['test']['id']]=e['test']
  if e.get('type')=='testDone':done[e['testID']]=e
  if e.get('type')=='error':errors.append(e)
  if e.get('type')=='done':final=e
 selected={i:t for i,t in tests.items() if not done.get(i,{}).get('hidden',False)}
 counts={'passed':0,'failed':0,'skipped':0,'unfinished':0}
 for i in selected:
  d=done.get(i)
  if d is None:counts['unfinished']+=1
  elif d.get('skipped'):counts['skipped']+=1
  elif d.get('result')=='success':counts['passed']+=1
  else:counts['failed']+=1
 return {'counts':counts,'selected_test_count':len(selected),'hidden_tests_excluded':len(tests)-len(selected),'errors':errors,'non_json_lines':nonjson,'done':final}


from concurrent.futures import ThreadPoolExecutor
info=json.loads((O/'verification.json').read_text())
before_tests=json.loads(gzip.decompress((O/'bindings-before.json.gz').read_bytes()))
before=snap();info['before_dart_analysis_bindings_sha256']=save_snapshot('bindings-before-dart-analysis',before)
info['pre_analysis_changes']=differences(before_tests,before)
targets=['lib',*TESTS]
def analyze(pair):
 i,target=pair
 return run('dart-analysis-'+str(i).zfill(2),[str(SDK/'bin/cache/dart-sdk/bin/dart'),'analyze','--fatal-infos',target])
with ThreadPoolExecutor(max_workers=2) as pool:
 analyses=list(pool.map(analyze,enumerate(targets)))
final=snap();info['after_dart_analysis_bindings_sha256']=save_snapshot('bindings-after-dart-analysis',final)
info['flutter_analysis_preflight']=info.pop('analysis_command')
info['analysis_commands']=analyses
info['analysis_input_changes']=differences(before,final)
info['all_input_changes']=differences(before_tests,final)
info['head_after']=head()
info['source_and_runtime_unchanged']=not info['test_input_changes'] and before_tests==before==final
c=info['results']['counts'];info['qualifying']=info['test_command']['exit_code']==0 and all(a['exit_code']==0 for a in analyses) and info['source_and_runtime_unchanged'] and c['failed']==0 and c['skipped']==0 and c['unfinished']==0 and info['results']['done'].get('success',False)
info['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
info['analysis_recovery']={'failed_preflight':'flutter analyze attempted to enumerate SDK dev/, excluded by authenticated runtime restoration selection. It failed before analysis; raw stdout/stderr are retained.','replacement':'Genuine Dart analyzer with existing unchanged Flutter package_config; one --fatal-infos invocation for lib and one for each exact selected test file.','sdk_modified':False,'tests_rerun':False}
(O/'verification.json').write_text(json.dumps(info,indent=2)+'\n')
(O/'README.md').write_text(f"""# Final editor proofing validation

The selected eleven-file cohort passed **{c['passed']} substantive tests**, with
{c['failed']} failures, {c['skipped']} skips and {c['unfinished']} unfinished cases. Hidden loading events
are excluded using `testDone.hidden`.

Strict analysis passed for the full editor library and all eleven selected
test files. The actual entry point was `dart analyze --fatal-infos`: one
invocation for `lib`, then one for each selected test, using the authentic
Flutter SDK's bundled Dart binary and unchanged Flutter package configuration.
All twelve invocations exit zero. Exact commands and raw stdout/stderr are
recorded separately; no unsupported `--no-pub` argument was passed to Dart.

Qualification accepted: **{info['qualifying']}**.

All bound inputs match before tests, after tests, before Dart analysis and
after Dart analysis: workspace source, selected tests, font assets,
workspace manifests, lock/package configuration, restored dependency library
bytes and runtime binaries. Input counts: {json.dumps(info['input_counts'])}.
The compressed maps retain exact original JSON bytes; `verification.json`
records their hashes, commands, timing, source heads and substantive outcomes.

The command's starting source head was `{info['head_before']}`;
source identity is the exact input map. The tested tracked sources and
tests match that product checkpoint, as independently verified by
`product-source-binding.json`. The ending source head is
`{info['head_after']}`. Documentation, changelogs and the separate portable
smoke tool are outside this cohort's imported input set.

## Retained analyzer preflight

The requested `flutter analyze --no-pub --fatal-infos ...` invocation exited
before analysis because it attempted to enumerate `flutter/dev/`, omitted
by the authenticated SDK extraction selection. `analysis.stdout`,
`analysis.stderr` and `analysis-command.json` preserve that failed preflight.
The equivalent genuine Dart analysis completed with no SDK changes and no
repeat test run.

## Evidence and limits

`events.jsonl.gz` preserves the full original event stream; `tests.stdout`
has the same uncompressed bytes for immediate inspection. Focused review and
baseline reruns are not added to this final total. Controlled native-service
and channel responses do not qualify installed device dictionaries, target
device performance or full application builds.

No GitHub CI endpoint was queried or awaited.
""")
print(json.dumps({'phase':'complete','qualifying':info['qualifying'],'counts':c,'changes':info['all_input_changes'],'analysis_exits':[a['exit_code'] for a in analyses]}),flush=True)
