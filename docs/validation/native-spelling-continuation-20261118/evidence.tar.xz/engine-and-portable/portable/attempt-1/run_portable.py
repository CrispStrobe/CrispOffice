import concurrent.futures, datetime, hashlib, json, os, pathlib, shutil, subprocess, time, urllib.parse

repo=pathlib.Path('/workspace/scratch/059a4a5dcb30/quds_office_suite')
work=repo/'packages/quds_office_engine'
out=pathlib.Path('/workspace/scratch/059a4a5dcb30/german_validation/portable')
sdk=pathlib.Path('/workspace/scratch/059a4a5dcb30/local_runtime/sdk/flutter/bin/cache/dart-sdk')
dart=sdk/'bin/dart'
node=pathlib.Path(shutil.which('node')).resolve()
script='tool/check_native_spelling.dart'

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()

def write(name,value):
 (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

graph=json.loads((repo/'.dart_tool/package_graph.json').read_text())
packages={p['name']:p for p in graph['packages']}
closure=set();pending=['quds_office_engine']
while pending:
 name=pending.pop()
 if name in closure:continue
 closure.add(name);pending+=packages[name]['dependencies']
config=repo/'.dart_tool/package_config.json'
entries={p['name']:p for p in json.loads(config.read_text())['packages']}
inputs=[work/script,config,repo/'.dart_tool/package_graph.json',repo/'pubspec.yaml',repo/'pubspec.lock']
for name in sorted(closure):
 entry=entries[name]
 root=pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(urllib.parse.urljoin(config.as_uri(),entry['rootUri'])).path))
 inputs.append(root/'pubspec.yaml')
 inputs+=list((root/entry['packageUri']).rglob('*.dart'))
inputs=sorted(set(p.resolve() for p in inputs))
runtime=[sdk/'version',sdk/'revision',node]
runtime+=[sdk/f for f in ['bin/dart','bin/dartvm','bin/dartaotruntime','bin/utils/gen_snapshot']]
runtime+=list((sdk/'bin/snapshots').glob('*.snapshot'))
runtime+=list((sdk/'lib/_internal').glob('*.dill'))
runtime+=list((sdk/'lib').rglob('*.dart'))
runtime=sorted(set(p for p in runtime if p.is_file()))
before={str(p):digest(p) for p in inputs}
runtime_before={str(p):digest(p) for p in runtime}
write('inputs-before.json',before)
write('runtime-before.json',runtime_before)
write('dependency-closure.json',{'packages':sorted(closure),'package_count':len(closure),'source_inputs':len(inputs),'runtime_inputs':len(runtime)})
write('versions.json',{'dart':subprocess.check_output([str(dart),'--version'],stderr=subprocess.STDOUT,text=True).strip(),'node':subprocess.check_output([str(node),'--version'],text=True).strip()})
commands={}
def run(label,args,stdout_name=None):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();begin=time.monotonic()
 with (out/(stdout_name or label+'.stdout.log')).open('wb') as stdout, (out/(label+'.stderr.log')).open('wb') as stderr:
  result=subprocess.run([str(a) for a in args],cwd=work,stdout=stdout,stderr=stderr)
 receipt={'args':[str(a) for a in args],'cwd':str(work),'exit_code':result.returncode,'started_at':started,'seconds':round(time.monotonic()-begin,3)}
 commands[label]=receipt
 write(label+'.command.json',receipt)
 return result.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
 jobs={'vm':executor.submit(run,'vm',[dart,'run',script],'vm.json'),
       'compile-native':executor.submit(run,'compile-native',[dart,'compile','exe',script,'-o',out/'spelling-smoke']),
       'compile-js':executor.submit(run,'compile-js',[dart,'compile','js','-O2',script,'-o',out/'spelling-smoke.js'])}
 results={label:job.result() for label,job in jobs.items()}
if results['compile-native']==0:results['native']=run('native',[out/'spelling-smoke'],'native.json')
if results['compile-js']==0:results['js']=run('js',[node,'-e','globalThis.self = globalThis; require(process.argv[1]);',out/'spelling-smoke.js'],'js.json')
after={str(p):digest(p) for p in inputs}
runtime_after={str(p):digest(p) for p in runtime}
write('inputs-after.json',after)
write('runtime-after.json',runtime_after)
outputs={label:(out/(label+'.json')).read_bytes() for label in ['vm','native','js'] if (out/(label+'.json')).is_file()}
parsed={label:json.loads(data) for label,data in outputs.items()}
receipt={'schema_version':1,'status':'passed','commands':commands,'source_inputs':len(inputs),'runtime_inputs':len(runtime),'source_inputs_unchanged':before==after,'runtime_inputs_unchanged':runtime_before==runtime_after,'changed_inputs':[p for p in before if before[p]!=after[p]],'changed_runtime':[p for p in runtime_before if runtime_before[p]!=runtime_after[p]],'byte_identical':len(outputs)==3 and len(set(outputs.values()))==1,'structurally_identical':len(parsed)==3 and parsed.get('vm')==parsed.get('native')==parsed.get('js'),'outputs':{label:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'case_count':parsed[label]['caseCount'],'failed':parsed[label]['failed'],'all_accepted':all(c['accepted'] for c in parsed[label]['cases'])} for label,data in outputs.items()},'compiled_artifacts':{p.name:{'sha256':digest(p),'bytes':p.stat().st_size} for p in [out/'spelling-smoke',out/'spelling-smoke.js'] if p.exists()},'limits':['Finite source-bound smoke panel, not a general language-quality measure.','JavaScript executed in Node with globalThis.self binding, not a browser qualification.','Compiled assets retained only as local scratch intermediates.','No GitHub Actions/workflow/check/CI-status endpoint queried or awaited.']}
passed=all(value==0 for value in results.values()) and receipt['byte_identical'] and receipt['structurally_identical'] and before==after and runtime_before==runtime_after and all(v['caseCount']==35 and v['failed']==0 and all(c['accepted'] for c in v['cases']) for v in parsed.values())
if not passed:receipt['status']='failed'
write('verification.json',receipt)
print(json.dumps({'status':receipt['status'],'source_inputs':len(inputs),'runtime_inputs':len(runtime),'byte_identical':receipt['byte_identical'],'structurally_identical':receipt['structurally_identical'],'outputs':receipt['outputs'],'results':results},indent=2))
raise SystemExit(0 if passed else 1)
