Portable spelling smoke qualification

Final acceptance is verification.json and vm.json/native.json/js.json.
All 35 cases pass identically on Dart VM, a real native executable, and compiled
JavaScript executed by Node. Count 105 final case executions, not the preserved
prior attempt as additional coverage. No engine product files were changed.

The runner validates finding counts, status, complete original UTF-16 source
spans, required corrections and suggestion caps. Its 10 new cases cover marked
numeric/connector identifiers, nearby prose, accented nouns/names/lowercase/
uppercase/decomposed source, explicit compounds, and Swiss locale behavior.
These are regression and target-parity checks, not an accuracy estimate.

The nine-package runtime dependency closure is recorded with 650 source and
configuration hashes. The 504 actual-runtime hashes include the Dart executable,
VM, AOT runtime, gen_snapshot, compiler snapshots, SDK source/platform inputs,
libraries.json, version/revision and Node binary. All remain unchanged before
and after the final run. All 756 compiler-reported dependencies are covered.

Archive readable evidence only. Exclude compiled scratch assets spelling-smoke,
spelling-smoke.js, spelling-smoke.js.map and spelling-smoke.js.deps. The latter
is copied to compiler-js.dependencies.txt for readable evidence.

Node uses globalThis.self = globalThis for the generated Dart runtime. This
does not establish browser interaction, physical-device spelling or performance.
No GitHub Actions/workflow/check/status endpoint was queried or awaited.
