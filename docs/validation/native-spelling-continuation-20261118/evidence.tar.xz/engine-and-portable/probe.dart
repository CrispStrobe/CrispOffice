import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';

Future<void> main() async {
  final provider = GermanSpellingProvider();
  final results = <String, Object?>{};
  for (final source in <String>[
    'Cafè', 'Abbè', 'Renè', 'rosè', 'Joêl', 'Tète', 'Caf', 'CAFÈ', 'café',
    'Caxè', 'Rqè', '1\u0301Huas', '_\u0301\u0308Huas', '𝟘\u0301Huas',
    'Huas', 'Feler', 'Fahl', 'Türr', 'Huas-Türr', 'Café', 'Abbé', 'René', 'rosé',
  ]) {
    final r = await provider.check(OfficeProofingRequest(documentId: 'probe',blockId:'p',revision:1,text:'hier $source'));
    results[source] = r.findings.map((f) => <String, Object?>{'original':f.originalText,'start':f.start,'end':f.end,'replacements':f.replacements}).toList();
  }
  await provider.dispose();
  print(const JsonEncoder.withIndent('  ').convert(results));
}
