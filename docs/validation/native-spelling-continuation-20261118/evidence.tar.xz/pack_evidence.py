"""Preserve exact local spelling evidence and bind it to the saved product."""
import collections
import gzip
import hashlib
import io
import json
import pathlib
import shutil
import subprocess
import tarfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
REPO = ROOT / 'quds_office_suite'
OUT = REPO / 'docs/validation/native-spelling-continuation-20261118'
BUNDLE = ROOT / 'spelling_evidence/bundle'
PRODUCT = 'd6a9ca51b16daa9d3d54e163bc723b76659d70ac'
BASE = '1e07cb852766f8651815138785be74c64a09ddc0'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def copy_file(source, name):
    target = BUNDLE / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)


def copy_tree(source, name, exclude=()):
    for path in sorted(source.rglob('*')):
        if path.is_file() and path.name not in exclude:
            copy_file(path, str(pathlib.Path(name) / path.relative_to(source)))


def test_counts(path):
    counts = collections.Counter()
    skipped = 0
    errors = []
    done = []
    for line in path.read_text().splitlines():
        event = json.loads(line)
        if event['type'] == 'testDone' and not event.get('hidden', False):
            counts[event['result']] += 1
            skipped += int(event.get('skipped', False))
        elif event['type'] == 'error':
            errors.append(event)
        elif event['type'] == 'done':
            done.append(event)
    return dict(counts=counts, skipped=skipped, error_events=len(errors), done=done)


assert git('rev-parse', 'HEAD').decode().strip() == PRODUCT
BUNDLE.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)

copy_tree(ROOT / 'local_runtime/delivery', 'runtime-and-initial-baseline')
copy_tree(ROOT / 'spelling_evidence/final-editor', 'final/editor')
copy_tree(ROOT / 'incoming_audit/final-baseline', 'baseline/final-controls')
copy_tree(ROOT / 'german_validation', 'engine-and-portable',
          exclude=('spelling-smoke', 'spelling-smoke.js',
                   'spelling-smoke.js.map', 'spelling-smoke.js.deps'))
copy_tree(ROOT / 'spelling_evidence/checks', 'checks')
copy_tree(ROOT / 'spelling_evidence/baseline', 'development/native-baseline')
copy_tree(ROOT / 'spelling_evidence/focused', 'development/native-focused')
copy_file(ROOT / 'spelling_evidence/run_checks.py', 'checks/run_checks.py')
copy_file(pathlib.Path(__file__), 'pack_evidence.py')
for name in ['audit_incoming.py', 'equivalence.json', 'refs.json',
             'fork-ls-remote.txt', 'upstream-ls-remote.txt',
             'final-frontier.json', 'final-open-prs.json',
             'reconciliation.md', 'review.md', 'dialog-baseline.jsonl',
             'dialog-baseline-inputs.json']:
    copy_file(ROOT / 'incoming_audit' / name, 'integration/' + name)
for path in sorted((ROOT / 'incoming_audit').glob('final-*-ls-remote.txt')):
    copy_file(path, 'integration/' + path.name)

engine = test_counts(ROOT / 'german_validation/engine-final.jsonl')
editor = test_counts(ROOT / 'spelling_evidence/final-editor/tests.stdout')
baseline_engine = test_counts(ROOT / 'incoming_audit/final-baseline/engine.jsonl')
baseline_editor = test_counts(ROOT / 'incoming_audit/final-baseline/editor.jsonl')
assert engine['counts'] == {'success': 1095}
assert editor['counts'] == {'success': 167}
assert engine['skipped'] == editor['skipped'] == 0
assert engine['done'][-1]['success'] and editor['done'][-1]['success']
editor_receipt = read_json(ROOT / 'spelling_evidence/final-editor/verification.json')
assert editor_receipt['qualifying']
checks = read_json(ROOT / 'spelling_evidence/checks/summary.json')
assert checks['passed']
portable = read_json(ROOT / 'german_validation/portable/verification.json')
assert portable['status'] == 'passed'
assert portable['byte_identical'] and portable['structurally_identical']
outputs = [(ROOT / 'german_validation/portable' / (name + '.json')).read_bytes()
           for name in ['vm', 'native', 'js']]
assert outputs[0] == outputs[1] == outputs[2]
assert json.loads(outputs[0])['caseCount'] == 35
assert json.loads(outputs[0])['failed'] == 0

inputs = {}
def add_input(path, digest):
    if path in inputs:
        assert inputs[path] == digest, path
    inputs[path] = digest

for path, digest in read_json(ROOT / 'german_validation/engine-before.sha256.json').items():
    add_input(path, digest)
editor_inputs = json.loads(gzip.decompress(
    (ROOT / 'spelling_evidence/final-editor/bindings-before.json.gz').read_bytes()))
for path, metadata in editor_inputs.items():
    if path.startswith('workspace/'):
        add_input(path.removeprefix('workspace/'), metadata['sha256'])
for path, digest in read_json(ROOT / 'german_validation/portable/inputs-before.json').items():
    file_path = pathlib.Path(path)
    if file_path.is_relative_to(REPO):
        add_input(str(file_path.relative_to(REPO)), digest)
tracked = {}
ignored = {}
for path, digest in sorted(inputs.items()):
    data = (REPO / path).read_bytes()
    assert sha(data) == digest, path
    blob = subprocess.run(['git', 'show', PRODUCT + ':' + path], cwd=REPO,
                          capture_output=True)
    if blob.returncode == 0:
        assert sha(blob.stdout) == digest, path
        tracked[path] = digest
    else:
        assert path in ['pubspec.lock', '.dart_tool/package_config.json',
                        '.dart_tool/package_graph.json'], path
        ignored[path] = digest
source_binding = dict(product=PRODUCT, tracked_count=len(tracked),
                      all_match_product_and_test_inputs=True,
                      tracked=tracked, ignored_configuration=ignored)
(BUNDLE / 'delivery-source-binding.json').write_text(
    json.dumps(source_binding, indent=2) + '\n')

initial = read_json(ROOT / 'incoming_audit/refs.json')
frontier = read_json(ROOT / 'incoming_audit/final-frontier.json')
summary = dict(
    schema='quds.native_spelling_continuation.verification.v1',
    integrated_main=BASE, qualified_product=PRODUCT,
    initial_remote_branch='2292548eb69de2dbb5240ab9da59256f362137c6',
    checkpoints=[
        dict(sha='4b7a0798fc970e3df08a6ba464537d2537a3c4e4',
             purpose='Native soft-hyphen projection, review regressions and initial reconciliation'),
        dict(sha=PRODUCT,
             purpose='Short accented German corrections, marked identifiers, review guards and portable panel'),
    ],
    initial_frontier=dict(captured_at=initial['captured_at_utc'],
                          refs=initial['counts']['refs'],
                          distinct_heads=initial['counts']['distinct_heads'],
                          unresolved=0),
    final_frontier=dict(captured_at=frontier['captured_at_utc'],
                        refs=frontier['counts']['refs'],
                        distinct_heads=frontier['counts']['distinct_heads'],
                        concurrent_not_integrated=[
                            dict(ref=x['ref'], sha=x['sha'])
                            for x in frontier['concurrent_work']]),
    final_tests=dict(engine=dict(files=29, passed=1095, failed=0, skipped=0),
                     editor=dict(files=11, passed=167, failed=0, skipped=0),
                     disjoint_total=1262, new_tests_included_once=33),
    baseline_control=dict(total=35, new_tests=33, existing_controls=2,
                          passed=8, behavioral_nonpasses=27, skipped=0,
                          engine=baseline_engine, editor=baseline_editor,
                          exact_final_test_bytes=True,
                          isolated_baseline_git_source=True),
    portable=dict(cases_per_target=35, targets=['Dart VM', 'native executable', 'JavaScript/Node'],
                  final_executions=105, all_pass=True, byte_identical=True,
                  output_bytes=len(outputs[0]), output_sha256=sha(outputs[0]),
                  source_dependency_inputs=portable['source_inputs'],
                  runtime_inputs=portable['runtime_inputs'],
                  compiler_dependencies=portable['compiler_dependency_coverage']),
    analysis=dict(engine='dart analyze --fatal-infos on changed source/test/tool: passed',
                  editor='dart analyze --fatal-infos on full editor lib plus each of 11 selected tests: 12 passed',
                  flutter_wrapper_preflight='Retained failed preflight: selected SDK omitted flutter/dev; actual Dart analysis passed with unchanged SDK and package configuration.',
                  formatted_dart_files=7, format_changed=0, whitespace_pass=True),
    runtime=dict(flutter='3.47.8', dart='3.13.7', node='24.22.3',
                 sdk_archive_bytes=1581444364,
                 sdk_archive_sha256='baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2',
                 verified_hosted_archives=162, workspace_packages=110,
                 lock_sha256='344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130'),
    delivery=dict(tracked_inputs_bound_to_product=len(tracked),
                  ignored_configuration_inputs=len(ignored),
                  editor_input_counts=editor_receipt['input_counts']),
    github_actions_workflow_checks_or_status_endpoints_used=False,
    limits=[
        'Finite authored regression/smoke panels, not a population language-quality estimate.',
        'Native mobile tests use controlled service/channel responses; no Android/iOS device dictionary or latency qualification.',
        'Compiled JavaScript executes in Node, not a browser or full application build.',
        'No new native spaCy/model acceptance, sealed panel rerun, dictionary data, runtime dependency or default activation.',
        'Three concurrent post-integration branches remain separate as recorded in final-frontier.json.',
        'Development attempts, baseline controls and repeated portable attempt are retained but excluded from final totals.',
    ])
(BUNDLE / 'verification.json').write_text(json.dumps(summary, indent=2) + '\n')

archive = OUT / 'evidence.tar.xz'
members = []
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for path in sorted(BUNDLE.rglob('*')):
        if not path.is_file():
            continue
        name = str(path.relative_to(BUNDLE))
        data = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
        members.append(dict(path=name, bytes=len(data), sha256=sha(data)))
index = dict(schema='quds.spelling_evidence_index.v1',
             archive=archive.name, archive_bytes=archive.stat().st_size,
             archive_sha256=sha(archive.read_bytes()),
             member_count=len(members), members=members)
with tarfile.open(archive, 'r:xz') as tar:
    assert len(tar.getmembers()) == len(members)
    for item in members:
        data = tar.extractfile(item['path']).read()
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
(OUT / 'evidence-index.json').write_text(json.dumps(index, indent=2) + '\n')
summary['evidence'] = {k:v for k,v in index.items() if k != 'members'}
(OUT / 'verification.json').write_text(json.dumps(summary, indent=2) + '\n')
shutil.copyfile(ROOT / 'incoming_audit/reconciliation.md', OUT / 'reconciliation.md')
compact_frontier = {k:v for k,v in frontier.items() if k != 'refs'}
compact_frontier['complete_snapshot_in_archive'] = 'integration/final-frontier.json'
(OUT / 'final-frontier.json').write_text(json.dumps(compact_frontier, indent=2) + '\n')
shutil.copyfile(ROOT / 'incoming_audit/review.md', OUT / 'review.md')
print(json.dumps(dict(archive_bytes=index['archive_bytes'],
                      archive_sha256=index['archive_sha256'],
                      member_count=len(members), tracked_inputs=len(tracked),
                      final_passes=1262), indent=2))
