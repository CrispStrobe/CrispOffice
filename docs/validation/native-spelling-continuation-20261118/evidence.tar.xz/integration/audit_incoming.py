#!/usr/bin/env python3
"""Capture read-only source reconciliation; never uses CI endpoints."""
import collections
import concurrent.futures
import datetime
import json
import pathlib
import subprocess

REPO = pathlib.Path('/workspace/scratch/059a4a5dcb30/quds_office_suite')
OUT = pathlib.Path(__file__).resolve().parent
BASE = '2292548eb69de2dbb5240ab9da59256f362137c6'
INITIAL_MAIN = '1ffcf91a3443caf9a6e8b45a3e6cab3f041831ae'
MERGED_MAIN = '1e07cb852766f8651815138785be74c64a09ddc0'


def git(*args, binary=False):
    return subprocess.check_output(['git', *args], cwd=REPO, text=not binary)


def ancestor(a, b):
    return subprocess.run(['git', 'merge-base', '--is-ancestor', a, b],
                          cwd=REPO, capture_output=True).returncode == 0


def ls_remote(repository):
    return git('ls-remote', 'https://github.com/' + repository + '.git',
               'refs/heads/*', 'refs/pull/*/head')


def main():
    repositories = ['CrispStrobe/quds_office_suite',
                    'MohammedAsaadAsaad/quds_office_suite']
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        live = list(pool.map(ls_remote, repositories))
    captured = datetime.datetime.now(datetime.timezone.utc).isoformat()
    prior = json.loads((REPO / 'docs/validation/native-spelling-20261118/reconciliation.json').read_text())
    equivalence = json.loads((OUT / 'equivalence.json').read_text())
    patch_map = {x['branch']: x for x in equivalence['patch']}
    tree_map = {x['branch']: x for x in equivalence['tree']}
    rows = []
    for repository, data in zip(repositories, live):
        (OUT / ('fork-ls-remote.txt' if repository.startswith('Crisp')
                else 'upstream-ls-remote.txt')).write_text(data)
        for line in data.splitlines():
            sha, ref = line.split()
            row = dict(repository=repository, ref=ref, sha=sha,
                       kind='branch' if ref.startswith('refs/heads/') else 'pull_request')
            exists = subprocess.run(['git', 'cat-file', '-e', sha + '^{commit}'],
                                    cwd=REPO, capture_output=True).returncode == 0
            row['commit_object_available'] = exists
            if ancestor(sha, BASE):
                row['disposition'] = 'ancestor_of_integration'
            elif sha in patch_map:
                row['disposition'] = 'patch_equivalent_on_main'
                row['accepted_commit'] = patch_map[sha]['main']
                row['pr'] = patch_map[sha]['pr']
            elif sha in tree_map:
                row['disposition'] = 'tree_equivalent_on_main'
                row['accepted_commit'] = tree_map[sha]['main']
                row['pr'] = tree_map[sha]['pr']
            elif sha == MERGED_MAIN:
                row['disposition'] = 'current_task_integration_merge'
            elif ref == 'refs/heads/codex/native-spelling-continuation-20261118':
                row['disposition'] = 'current_task_continuation'
            else:
                row['disposition'] = 'unresolved'
            rows.append(row)
    preservation = {}
    for pr, sha in [(157, '9fc211f6c72be9495767bd7cacfd8df51abf2fad'),
                    (158, '5dd3eb7c1434f0c1063290d5698fa5c760c201e2')]:
        paths = git('diff', '--name-only', INITIAL_MAIN, sha, '--', 'packages', 'tool').splitlines()
        paths = [p for p in paths if not p.endswith('CHANGELOG.md')]
        preservation[str(pr)] = [dict(path=p,
             source_blob=git('rev-parse', sha + ':' + p).strip(),
             integration_blob=git('rev-parse', BASE + ':' + p).strip()) for p in paths]
    record = dict(
        schema='quds.native_spelling_continuation.reconciliation.v1',
        captured_at_utc=captured,
        integration=BASE, initial_main=INITIAL_MAIN, merged_main=MERGED_MAIN,
        scope='Live fork/upstream branches and pull request head refs, excluding symbolic refs; current-task continuation is identified explicitly.',
        github_actions_workflow_checks_or_status_endpoints_used=False,
        counts=dict(refs=len(rows), distinct_heads=len({r['sha'] for r in rows}),
                    by_repository={repo:dict(collections.Counter(r['kind'] for r in rows if r['repository']==repo)) for repo in repositories},
                    dispositions=dict(collections.Counter(r['disposition'] for r in rows))),
        integration_contains={ref:ancestor(ref,BASE) for ref in [
            INITIAL_MAIN, '9fc211f6c72be9495767bd7cacfd8df51abf2fad',
            '5dd3eb7c1434f0c1063290d5698fa5c760c201e2',
            'e397671e815232847d7223314ba946d1d6740f44',
            '2e013f26c7d4db54ecabe2c955117cbce5379408']},
        equivalence=equivalence,
        spelling_and_zotero_source_preservation=preservation,
        office_history_merge_source_paths=git('diff','--name-only','ea0e430d^','ea0e430d','--','packages').splitlines(),
        aot_package_present=bool(git('ls-tree',BASE,'packages/quds_proofing_aot').strip()),
        preservation_rules=prior['preservation_rules'],
        notes=[
            'PR159 combines 157, 158 and office-continue history/evidence; its office merge deliberately retains accepted main product files.',
            'All 11 patch pairs and all 3 exact tree pairs were recomputed locally from Git objects; accepted counterparts are ancestors of integration.',
            'The only open PRs at initial GitHub API observation were 159,158,157 and stacked draft153; 153 source already belongs to initial main.',
            'Root merged PR159 using expected_head_sha 2292548eb69de2dbb5240ab9da59256f362137c6; merge result SHA recorded here. The postmerge ref snapshot is distinct from the initial API observation.',
            'No runtime qualification is asserted by this source reconciliation; later concurrent work must be recorded separately.'
        ], refs=rows)
    (OUT / 'refs.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record['counts'],indent=2))
    print('Unresolved:',[r for r in rows if r['disposition']=='unresolved'])
    assert not any(r['disposition']=='unresolved' for r in rows)
    assert all(x['match'] and x['main_ancestor'] for x in equivalence['patch']+equivalence['tree'])
    assert all(x['source_blob']==x['integration_blob'] for group in preservation.values() for x in group)


if __name__ == '__main__':
    main()
