# Native discretionary-hyphen projection review

No blocking implementation issue was found. The helper projects only U+00AD,
keeps a UTF-16 index for every retained code unit, and checks native ranges
against both projected and source grapheme boundaries before constructing
findings. Original and projected protected spans are both respected; numeric
and connector edges are checked in the projected text. Leading/trailing
layout controls stay outside a correction, while controls inside the
reported word stay inside its original replacement interval.

Suggestion comparison uses the candidate's SHY-free form. This closes the
review concern that a candidate with a different discretionary-hyphen
placement could otherwise offer a layout-only correction. Availability,
exact dictionary locale, disposal, serialized channel ownership and timeout
semantics remain in effect.

Four independent guard controls pass. A regional-indicator case proves why
the original grapheme check is necessary: source A / SHY / BC projects to
AB / C, so the native C interval would split the source BC flag without that
check. The other controls cover alternate SHY-placement no-ops and empty
inputs for unavailable, unsupported and disposed providers. Strict analysis
of the added review file reports no issues.

The focused review logs do not establish physical-device spelling quality.
Include these four cases in the final source-bound editor cohort; do not add
this focused run to that cohort's total.
