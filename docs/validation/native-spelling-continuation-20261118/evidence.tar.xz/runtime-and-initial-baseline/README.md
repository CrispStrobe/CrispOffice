# Local runtime and integrated baseline

The authentic Flutter 3.47.8 / Dart 3.13.7 runtime was restored from the full
official 1,581,444,364-byte archive, authenticated against SHA-256
`baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2`.
Selected extracted members include Linux debug Flutter test artifacts, the
complete Dart SDK and Flutter libraries/tools. Other target build artifacts
were omitted by the existing restoration helper. All 162 hosted package
archives matched their pinned hashes. Offline resolution produced 110
packages and retained workspace lock SHA-256
`344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130`.
Runtime files and all current workspace manifests are bound in
`runtime/runtime-ready.json`.

## Baseline controls

Both cohorts ran against integrated baseline
`1e07cb852766f8651815138785be74c64a09ddc0`, before production edits.
The engine cohort pins the 28 pre-existing files in `test/proofing`, excluding
the concurrently authored new continuation regression file. The editor
cohort selects `platform_spelling_provider_test.dart` and
`platform_spelling_dialog_test.dart`.

| Cohort | Files | Substantive passes | Failures | Skips | Bound inputs |
| --- | ---: | ---: | ---: | ---: | ---: |
| Engine proofing | 28 | 1,078 | 0 | 0 | 422 |
| Editor native spelling | 2 | 32 | 0 | 0 | 492 |

Every before/after source/dependency configuration hash matches. Each result
file records its exact command, source commit, timestamps, exit, log hashes,
and unchanged-input check. Counts exclude hidden loading tests using the
JSON reporter's `testDone.hidden` field. The initial progress parser included
loading events; the final receipts were recounted from unchanged raw logs,
as recorded in `baseline/recount-receipt.json`.

These are **baseline** results, not qualification of the new implementation.
Focused and final new-product runs must be reported separately.

## Evidence layout

- `runtime/` retains restoration scripts, authentic runtime identities, pinned
  package archive receipts and exact offline-resolution logs.
- `baseline/engine/` and `baseline/editor/` retain commands, results, source
  bindings, stderr, and compressed original JSON event streams.
- `baseline-summary.json` provides compact disjoint counts.

The `.gz` files decompress to the original evidence bytes. SDK files,
compiled caches and downloaded dependency payloads are omitted.

No GitHub Actions, workflow, check or CI-status endpoint was queried or
awaited. No full application build, installed device dictionary or general
language-accuracy claim follows from these controls.
