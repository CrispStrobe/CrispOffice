# Office continuation development evidence

This archive preserves authoring and independent review evidence during recovery. It does not qualify the final frozen repository, and repeated or historical case counts must not be added to the final qualification totals.

- `studio-review/`: retained failed fixture/compile invocation and the corrected 34-case focused pass, including compact multilingual status controls, Settings, Zotero/Notes and VM web-host cancellation.
- `word-merge*` and `word-*-tests*`: earlier merge repair logs and decisions. These precede the independent same-value mixed-run finding and have separate source hashes.
- `independent-review/`: saved-message source-preservation review, failing mixed-run reproduction, five-file routing repair, pre/post source snapshots, invocation record, strict analysis and the successful 196-case engine and 57-case editor runs. Failed or interrupted launcher attempts remain separate.
- `saved-mail-tests*` and `saved-mail-analysis.log`: 16 retained saved-reader/lifecycle cases, before the later live Mail session repair.
- `mail-session-evidence.tar.xz` with its index: completed independent authoring archive for the live Mail lifecycle repair; contains original and corrected fixtures, raw failed/passing logs and exact source copies. It has no live-account or external-network claim.
- `ayaspell-controls.log`: earlier build-control output retained for provenance, without adding a test count.

All member bytes and SHA-256 values are listed in the external development-evidence index. Packaging verifies each archived payload. No ongoing final-qualification output, source publication artifacts, or remote workflow observations are included here.
