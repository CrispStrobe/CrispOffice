import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_editor/quds_office_editor.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('choosing existing Latin metadata separates selected text from Arabic tail', () {
    final document = WmlDocument.empty();
    final paragraph = document.paragraphs.single;
    paragraph.inlines = [
      WmlRun(
        text: 'Text فكرة',
        properties: WmlRunProps(
          proofingLanguage: 'en-GB',
          complexScriptLanguage: 'ar-SA',
        ),
      ),
    ];
    final controller = WordEditorController(document: document);
    addTearDown(controller.dispose);
    controller.caret
      ..selectionAnchor = 0
      ..logicalIndex = 4;
    expect(controller.textProofingTarget!.language, 'ar-SA');
    expect(controller.setTextProofingLanguage('en-GB', target: controller.textProofingTarget!), isTrue);
    expect(controller.textProofingTarget!.language, 'en-GB');
    final runs = paragraph.inlines.whereType<WmlRun>().toList();
    expect(runs.map((r) => r.text), ['Text', ' فكرة']);
    expect(runs.last.properties.complexScriptLanguage, 'ar-SA');
  });
}
