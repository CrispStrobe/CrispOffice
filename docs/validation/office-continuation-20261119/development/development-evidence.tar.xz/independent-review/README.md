# Independent recovery review and Word routing repair

## Saved-message restoration

The restored `studio_saved_message.dart` is the c63558c0 reader with the class renamed from `StudioMailDialog` to `StudioSavedMessageDialog`; ignoring formatter whitespace, its tokens are unchanged. Both mounted checks, delayed controller disposal, selection cancellation, empty results, localized error feedback, and post-dismissal failure handling remain present. The live Mail workspace exposes that retained reader through an AppBar action.

The c63558c0 nine-case test file is retained as `studio_saved_message_test.dart`, with imports/class names adjusted and its untyped `noSuchMethod` fake replaced by Flutter's `Fake` superclass. Its nine assertions and scenarios remain intact. Existing six saved-reader/module tests and one lifecycle test retain their behavior. Independent raw-event readback confirms 16 successful application cases in the supplied saved-mail run, with no errors or skips. That run predates the separately reviewed live-session repair.

## Word finding and repair

Review found a reproducible edge: selecting `Text` from a mixed `Text فكرة` run with Latin `en-GB` and complex-script `ar-SA`, then choosing `en-GB`, returned success but left the target routed to `ar-SA`. The isolated Latin fragment already had the requested property, so the edit discarded its necessary split. Unconditional coalescing could also recombine equal-property fragments into a mixed-script run.

The scratch-only failing reproduction is retained as `word_mixed_noop_review_test.dart` with its raw failed reporter output. Root authorized the reviewer to implement the repair and independently reviewed the resulting patch.

The repair keeps runs separate when joining them would change their language-routing class. Coalescing classifies each original run once, avoiding repeated scans of accumulated text. `splitProofingRange` reports a selected fragment that changes slots when isolated; both explicit language assignment and active-slot reset preserve that semantic split, including when the stored property already has the desired value. Neither inactive language metadata nor `rtl`/`cs` direction markers are changed to force a boundary. Existing property-identity handling remains valid because splits precede identity collection and coalescing follows callbacks.

Three engine regressions cover language-route boundaries, explicit complex-script coalescing, and unchanged formatting. Two editor regressions cover same-value selection and already-inherited reset, repeat-operation idempotence, undo/redo and DOCX reload. All five repair files were hash-checked before and after verification and are retained under `word-fix-source/`.

## Development verification

- `word-fix-editor`: 57 successful cases across three editor suites, zero failures/skips, exit 0.
- `word-fix-engine-direct`: 196 successful cases across twelve engine suites, zero failures/skips, exit 0. Includes run editing, source fidelity, inheritance, complex-script routing, content controls, small caps, bookmarks, fields, auxiliary stories and the fidelity oracle.
- Strict analysis with fatal infos/warnings passed all five repair files; formatting and whitespace passed.

The first broad engine invocation used `flutter test`: 195 cases passed and the bookmark CLI subprocess timed out, because the test launches `Platform.resolvedExecutable` and that executable was `flutter_tester`. The direct `dart test` startup produced no reporter output and was interrupted with exit 130. Both attempts remain separate. The successful engine command invoked the pinned `test-1.31.1/bin/test.dart` directly with `dart --disable-dart-dev --packages=<workspace package_config.json> --reporter json`; this also ran the bookmark CLI case successfully. The corresponding editor command was `flutter test --no-pub --reporter json`.

These are focused development results, not final frozen-source acceptance. None of these counts should be added to the later aggregate qualification.

## Replay provenance

`invocations.json` records the working directories, environment sources and launcher arguments. `word-fix-base.json` names the committed pre-repair source; `word-fix-base-source/` and `word-fix-source/` retain both source versions. `word-fix.patch` captures the five-file repair against that commit. The failed scratch reproduction targets the pre-repair source. Final qualification adds its own explicit compiler/concurrency settings and must be audited separately.
