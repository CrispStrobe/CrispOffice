# Focused Studio merge checks

These are development checks on the ongoing reconciliation checkout. They do not qualify the later frozen aggregate source or contribute additional cases to its totals.

Both attempts used the pinned Flutter/Dart environment from `runtime/test/env.sh` and native environment from `runtime/test/native-env.sh`, running from `packages/quds_office_editor/example`:

```sh
flutter test --no-pub --reporter json \
  test/studio_review_status_test.dart \
  test/studio_settings_test.dart \
  test/studio_zotero_shortcuts_test.dart \
  test/studio_hunspell_web_cancellation_test.dart \
  test/studio_hunspell_web_host_test.dart
```

`focused-01` failed. The Zotero fixture retained one obsolete `enableStudioSetting` call after the merged setup already enabled Notes. The status fixture also changed layout constraints with `setSurfaceSize` while leaving `MediaQuery` at the default 800px view size, causing compact actions at the nominal wide widths. Its status assertions remained intact; the fixture now sets view physical size and pixel ratio as well as layout size.

`focused-02` passed 34 application cases in 5 suites, with zero failures or skips and a successful terminal event. Counts: 10 review-status cases, 1 settings case, 15 Zotero shortcuts, 4 fake-client web cancellation cases and 4 real-loopback web-host HTTP cases. The three added compact status cases cover English, German and Arabic at 390px and 820px with 1.4x text, truthful partial/paused icons and tooltips, reachable review actions and absence of layout errors. The loopback cases exercise the web host contract on the VM; they do not claim browser or Wasm execution.

The unchanged original seven review-status tests, settings behavior, both cancellation fixture families and all Zotero assertions remain present. Raw stdout and stderr from each attempt are retained separately. `summary.json` recounts raw cases and hashes those logs.
