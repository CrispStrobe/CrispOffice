from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,importlib.util,json,re,urllib.request
root=Path('/workspace/scratch/688e1d3b1ee4');repo=root/'quds_office_suite'
catalog=repo/'packages/quds_arabic_morph/lib/src/morph_catalog.dart';text=catalog.read_text()
repository=re.search(r"repository: '([^']+)'",text)[1];revision=re.search(r"revision: '([^']+)'",text)[1];directory=re.search(r"directory: '([^']+)'",text)[1]
pins=re.findall(r"MorphArtifact\(\s*'([^']+)',\s*'([0-9a-f]{64})',\s*(\d+),\s*\)",text)
assert len(pins)==4,pins
output=root/'runtime/native/morph-data';output.mkdir(parents=True,exist_ok=True)
def one(pin):
 name,digest,size=pin;url=f'https://huggingface.co/{repository}/resolve/{revision}/{directory}/{name}'
 with urllib.request.urlopen(url,timeout=90) as r:data=r.read()
 assert len(data)==int(size) and hashlib.sha256(data).hexdigest()==digest,name
 (output/name).write_bytes(data)
 return {'file':name,'path':str(output/name),'bytes':len(data),'sha256':digest,'url':url}
with ThreadPoolExecutor(max_workers=4) as pool:files=list(pool.map(one,pins))
receipt={'source':str(catalog.relative_to(repo)),'source_sha256':hashlib.sha256(catalog.read_bytes()).hexdigest(),'repository':repository,'revision':revision,'files':files,'verified':True}
(root/'runtime/native/morph-data-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
source=repo/'packages/quds_arabic_morph/tool/build.py';spec=importlib.util.spec_from_file_location('morph_build',source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
result=module.fetch_source(root/'runtime/native/morph-build/source')
print('Verified data',len(files),sum(x['bytes'] for x in files),'and source',result)
