from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shlex,subprocess
ROOT=Path('/workspace/scratch/688e1d3b1ee4');REPO=ROOT/'quds_office_suite';RUNTIME=ROOT/'runtime/test';OUT=ROOT/'runtime/native'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
receipt=read(RUNTIME/'runtime.json');assert receipt['status']=='ready'
preserved=RUNTIME/'runtime-sdk.json'
if not preserved.exists():preserved.write_bytes((RUNTIME/'runtime.json').read_bytes())
verification=read(OUT/'build-verification.json');fixtures=read(OUT/'fixtures.json');dictionary=read(OUT/'ayaspell-receipt.json');poppler=read(OUT/'poppler.json')
for path,digest in verification['compiled_inputs'].items():assert sha(REPO/path)==digest,path
assert sha(REPO/dictionary['source'])==dictionary['source_sha256']
for fixture in fixtures.values():assert sha(REPO/fixture['source'])==fixture['source_sha256']
inputs=receipt.setdefault('additional_inputs',{})
for path in [OUT/'build-verification.json',OUT/'source-before.json',OUT/'source-after.json',OUT/'build-install.log',Path(verification['build_receipt']),Path(verification['source_archive']['path']),Path(verification['native_library']['path']),OUT/'fixtures.json',OUT/'ayaspell-receipt.json',OUT/'poppler.json',ROOT/'runtime/cmake-receipt.json',ROOT/'runtime/restore_local.py',ROOT/'runtime/prepare_native.py',ROOT/'runtime/bind_native.py',preserved]:inputs[str(path)]=sha(path)
for path,identity in verification['installed_files'].items():assert sha(path)==identity['sha256'];inputs[path]=identity['sha256']
for fixture in fixtures.values():
 for key in ('library','receipt','log','compiler'):
  path=fixture[key];assert sha(path)==fixture[key+'_sha256'];inputs[path]=sha(path)
for artifact in dictionary['files']:
 assert sha(artifact['path'])==artifact['sha256'];inputs[artifact['path']]=artifact['sha256']
for path,identity in poppler['bound_files'].items():assert sha(path)==identity['sha256'];inputs[path]=identity['sha256']
for path in (ROOT/'runtime/cmake/cmake/data/bin').iterdir():
 if path.is_file():inputs[str(path)]=sha(path)
primary=fixtures['QUDS_HUNSPELL_LIFECYCLE_LIBRARY']
receipt['hunspell_preparation']={'build_receipt':verification['build_receipt'],'build_receipt_sha256':verification['build_receipt_sha256'],'build_verification':str(OUT/'build-verification.json'),'build_verification_sha256':sha(OUT/'build-verification.json'),'lifecycle_receipt':primary['receipt'],'lifecycle_receipt_sha256':primary['receipt_sha256']}
receipt['lifecycle_fixtures']=fixtures
receipt['qualification_environment']={'QUDS_HUNSPELL_TEST_LIBRARY':verification['installed_library']['path'],'QUDS_HUNSPELL_TEST_DICTIONARY':str(OUT/'ayaspell'),'QUDS_HUNSPELL_LIVE_DOWNLOAD':'1',**{key:value['library'] for key,value in fixtures.items()}}
receipt['tail_preparation']={'poppler_wrapper':poppler['wrapper'],'poppler_receipt':str(OUT/'poppler.json'),'poppler_receipt_sha256':sha(OUT/'poppler.json')}
if (OUT/'morph-build-verification.json').exists() and (OUT/'morph-data-receipt.json').exists():
 morph=read(OUT/'morph-build-verification.json');data=read(OUT/'morph-data-receipt.json')
 for path,digest in morph['compiled_inputs'].items():assert sha(REPO/path)==digest,path
 assert sha(REPO/data['source'])==data['source_sha256']
 for path in [OUT/'morph-build-verification.json',OUT/'morph-source-before.json',OUT/'morph-source-after.json',OUT/'morph-build-install.log',OUT/'morph-build-clean.log',OUT/'morph-build-install-initial.log',OUT/'morph-build-initial-verification.json',Path(morph['build_receipt']),OUT/'morph-data-receipt.json',ROOT/'runtime/prepare_morph.py',ROOT/'runtime/fetch_morph.py']:
  inputs[str(path)]=sha(path)
 for path,identity in morph['installed_files'].items():assert sha(path)==identity['sha256'];inputs[path]=identity['sha256']
 for artifact in data['files']:
  assert sha(artifact['path'])==artifact['sha256'];inputs[artifact['path']]=artifact['sha256']
 receipt['morphology_preparation']=morph
 receipt['morphology_environment']={'QUDS_ARABIC_MORPH_TEST_LIBRARY':morph['library'],'QUDS_ARABIC_MORPH_TEST_BUNDLE':str(OUT/'morph-data'),'QUDS_ARABIC_MORPH_LIVE_DOWNLOAD':'1'}
native_env={**receipt['qualification_environment'],**receipt.get('morphology_environment',{})}
(RUNTIME/'native-env.sh').write_text('\n'.join('export '+k+'='+shlex.quote(v) for k,v in native_env.items())+'\n')
inputs[str(RUNTIME/'native-env.sh')]=sha(RUNTIME/'native-env.sh')
receipt['native_preparation']={'at_utc':datetime.now(timezone.utc).isoformat(),'source_commit':subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip(),'newly_built':True,'historical_results_reused':False}
receipt['archive']['upstream_url']='https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.47.8-stable.tar.xz'
write(RUNTIME/'runtime.json',receipt)
print('Bound',len(inputs),'additional inputs; runtime ready')
