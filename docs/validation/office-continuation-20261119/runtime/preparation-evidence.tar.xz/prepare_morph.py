from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/workspace/scratch/688e1d3b1ee4');repo=root/'quds_office_suite';out=root/'runtime/native';package=repo/'packages/quds_arabic_morph'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
inputs={str(p.relative_to(repo)):sha(p) for p in [package/'tool/build.py',package/'native/CMakeLists.txt',package/'native/src/quds_arabic_morph.cpp',*sorted((package/'licenses').rglob('*'))] if p.is_file()}
(out/'morph-source-before.json').write_text(json.dumps(inputs,indent=2)+'\n')
env=dict(os.environ);env['PATH']=str(root/'runtime/cmake/cmake/data/bin')+os.pathsep+env['PATH']
command=['python',str(package/'tool/build.py'),'--native','--jobs','2','--output',str(out/'morph-build'),'--install-native',str(out/'morph-host'),'--install-licenses',str(out/'morph-host/licenses/arabic_morph')]
with (out/'morph-build-install.log').open('wb') as log:subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
after={p:sha(repo/p) for p in inputs};assert inputs==after
(out/'morph-source-after.json').write_text(json.dumps(after,indent=2)+'\n')
built=out/'morph-build/native/libquds_arabic_morph.so';installed=out/'morph-host/libquds_arabic_morph.so';assert sha(built)==sha(installed)
receipt={'compiled_inputs':inputs,'command':command,'build_receipt':str(out/'morph-build/build-receipt.json'),'build_receipt_sha256':sha(out/'morph-build/build-receipt.json'),'log':str(out/'morph-build-install.log'),'log_sha256':sha(out/'morph-build-install.log'),'library':str(installed),'library_sha256':sha(installed),'installed_files':{str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((out/'morph-host').rglob('*')) if p.is_file()}}
(out/'morph-build-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Morphology native build verified',sha(installed))
