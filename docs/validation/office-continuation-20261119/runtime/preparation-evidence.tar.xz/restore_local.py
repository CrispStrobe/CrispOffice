from pathlib import Path
import importlib.util
import sys
root = Path('/workspace/scratch/688e1d3b1ee4')
source = root/'quds_office_suite/docs/validation/document-review-notes-20261118/runtime/restore_runtime.py'
spec = importlib.util.spec_from_file_location('quds_restore',source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
archive = root/'runtime/flutter_linux_3.47.8-stable.tar.xz'
if module.sha256(archive) != module.SDK_SHA256 or archive.stat().st_size != module.SDK_BYTES:
    raise RuntimeError('Downloaded archive differs from pinned source')
module.SDK_URL = archive.as_uri()
sys.argv = [str(source),'--repo',str(root/'quds_office_suite'),'--runtime-root',str(root/'runtime/test'),'--node-tests']
module.main()
