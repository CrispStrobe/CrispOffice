from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess
ROOT=Path('/workspace/scratch/688e1d3b1ee4')
REPO=ROOT/'quds_office_suite'
RUNTIME=ROOT/'runtime/test'
OUT=ROOT/'runtime/native'
OUT.mkdir(exist_ok=True)
def sha(p):
 with Path(p).open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def write(p,data):Path(p).write_text(json.dumps(data,indent=2)+'\n')
def run(name,args,env=None):
 log=OUT/(name+'.log')
 print('START',name,flush=True)
 with log.open('wb') as f:subprocess.run([str(x) for x in args],cwd=REPO,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('END',name,flush=True)
 return log
package=REPO/'packages/quds_proofing_hunspell'
inputs={str(p.relative_to(REPO)):sha(p) for p in [package/'tool/build.py',package/'native/CMakeLists.txt',package/'native/src/quds_hunspell.cpp',*sorted((package/'licenses').rglob('*'))] if p.is_file()}
write(OUT/'source-before.json',inputs)
env=dict(os.environ)
env['PATH']=str(ROOT/'runtime/cmake/cmake/data/bin')+os.pathsep+env['PATH']
build=OUT/'build';installed=OUT/'host'
log=run('build-install',['python',package/'tool/build.py','--native','--jobs','2','--output',build,'--install-native',installed,'--install-licenses',installed/'licenses/hunspell'],env)
after={p:sha(REPO/p) for p in inputs}
write(OUT/'source-after.json',after)
assert inputs==after,'native compilation inputs changed'
manifest=json.loads((package/'licenses/manifest.json').read_text())
source=build/'source/hunspell-1.7.2'
if not source.exists():
 source=next(p for p in build.rglob('hunspell-1.7.2') if p.is_dir())
for name,digest in manifest['component']['compiled_files'].items():assert sha(source/'src/hunspell'/name)==digest,name
built=build/'native/libquds_proofing_hunspell.so';library=installed/'libquds_proofing_hunspell.so'
assert sha(built)==sha(library)
build_receipt=build/'build-receipt.json'
if not build_receipt.exists():
 candidates=list(build.glob('*receipt*.json'))
 assert len(candidates)==1,candidates
 build_receipt=candidates[0]
archive=next(build.rglob('hunspell-1.7.2.tar.gz'))
verification={'compiled_inputs':inputs,'build_receipt':str(build_receipt),'build_receipt_sha256':sha(build_receipt),'build_log_sha256':sha(log),'source_archive':{'path':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size},'native_library':{'path':str(built),'sha256':sha(built)},'installed_library':{'path':str(library),'sha256':sha(library)},'installed_files':{str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(installed.rglob('*')) if p.is_file()}}
write(OUT/'build-verification.json',verification)
fixture_sources={
 'QUDS_HUNSPELL_LIFECYCLE_LIBRARY':'test/fixtures/lifecycle_hunspell.cpp',
 'QUDS_HUNSPELL_OWNERSHIP_LIBRARY':'test/support/lifecycle_library.cpp',
 'QUDS_HUNSPELL_PROVIDER_LIFECYCLE_LIBRARY':'test/support/hunspell_lifecycle_shim.cpp',
}
fixtures={};compiler=Path(shutil.which('g++')).resolve()
for environment,relative in fixture_sources.items():
 source=package/relative;short=source.stem
 fixture_library=OUT/(short+'.so')
 command=[compiler,'-std=c++17','-O2','-shared','-fPIC','-pthread',source,'-o',fixture_library]
 source_hash=sha(source)
 log=run(short+'-build',command)
 assert sha(source)==source_hash
 receipt={'source':str(source.relative_to(REPO)),'source_sha256':source_hash,'command':[str(x) for x in command],'compiler':str(compiler),'compiler_sha256':sha(compiler),'library':str(fixture_library),'library_sha256':sha(fixture_library),'log':str(log),'log_sha256':sha(log)}
 receipt_path=OUT/(short+'-receipt.json');write(receipt_path,receipt)
 fixtures[environment]={**receipt,'receipt':str(receipt_path),'receipt_sha256':sha(receipt_path)}
write(OUT/'fixtures.json',fixtures)
poppler=Path(shutil.which('pdftoppm'))
asset_root=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/poppler/poppler')
executable=asset_root/'bin/pdftoppm';inner=asset_root.parent/'bin/pdftoppm'
version=subprocess.run([str(poppler),'-v'],capture_output=True,text=True,check=True)
ldd=subprocess.check_output(['ldd',str(executable)],text=True)
paths={poppler,inner,executable,*(p for p in asset_root.rglob('*') if p.is_file())}
for line in ldd.splitlines():
 match=re.search(r'(?:=>\s+)?(/\S+)\s+\(',line)
 if match:paths.add(Path(match[1]))
paths={p for p in paths if p.is_file()}
poppler_receipt={'source':'Preinstalled primary-runtime Poppler; no download or installation performed','wrapper':str(poppler),'inner_wrapper':str(inner),'executable':str(executable),'asset_root':str(asset_root),'version_stdout':version.stdout,'version_stderr':version.stderr,'dependency_loader_output':ldd,'bound_files':{str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(paths)}}
write(OUT/'poppler.json',poppler_receipt)
print('Native preparation complete; run bind_native.py after SDK restore is ready',flush=True)
