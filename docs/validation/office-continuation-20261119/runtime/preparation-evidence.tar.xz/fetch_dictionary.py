from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,re,urllib.request
root=Path('/workspace/scratch/688e1d3b1ee4')
source=root/'quds_office_suite/packages/quds_proofing_hunspell/lib/src/hunspell_catalog.dart'
text=source.read_text()
repo=re.search(r"repository: '([^']+)'",text)[1]
rev=re.search(r"revision: '([^']+)'",text)[1]
pins=re.findall(r"HunspellArtifact\(\s*'([^']+)',\s*'([0-9a-f]{64})',\s*(\d+),\s*\)",text)
assert len(pins)==8,pins
output=root/'runtime/native/ayaspell'
output.mkdir(parents=True,exist_ok=True)
def one(pin):
 name,sha,size=pin
 url=f'https://huggingface.co/{repo}/resolve/{rev}/{name}'
 with urllib.request.urlopen(url,timeout=60) as r:data=r.read()
 assert len(data)==int(size) and hashlib.sha256(data).hexdigest()==sha,name
 (output/name).write_bytes(data)
 return {'file':name,'path':str(output/name),'bytes':len(data),'sha256':sha,'url':url}
with ThreadPoolExecutor(max_workers=8) as pool:files=list(pool.map(one,pins))
receipt={'source':str(source.relative_to(root/'quds_office_suite')),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'repository':repo,'revision':rev,'files':files,'verified':True}
(root/'runtime/native/ayaspell-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Verified',len(files),'files',sum(x['bytes'] for x in files),'bytes')
