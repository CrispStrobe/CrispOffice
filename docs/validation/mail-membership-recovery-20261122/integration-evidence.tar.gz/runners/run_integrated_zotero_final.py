from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path('/workspace/scratch/be9367db5e45/quds_office_suite')
runtime = root.parent / 'mail-runtime'
sys.path.insert(0, str(root / 'tools/mail'))
from check_store import execute, test_summary
from check_reader import write_receipt

cohort = sys.argv[1]
if cohort == 'engine':
    cwd = root / 'packages/quds_office_engine'
    files = [
        'test/word_note_numbering_test.dart',
        'test/odt_zotero_writer_test.dart',
        'test/odt_zotero_note_numbering_test.dart',
        'test/odt_document_reader_test.dart',
        'test/odt_document_writer_test.dart',
        'test/odt_reader_styles_test.dart',
        'test/odt_reader_guards_test.dart',
        'test/odt_reader_libreoffice_defaults_test.dart',
        'test/odt_zotero_export_lifecycle_test.dart',
        'test/odt_note_configuration_styles_test.dart',
        'test/odt_libreoffice_note_offsets_test.dart',
        'test/odt_note_fidelity_test.dart',
    ]
    packages = ['packages/quds_office_engine', 'packages/legacy_doc_parser']
elif cohort == 'editor':
    cwd = root / 'packages/quds_office_editor'
    files = ['test/word_odt_note_numbering_test.dart', 'test/word_note_numbering_test.dart']
    packages = ['packages/quds_office_engine', 'packages/legacy_doc_parser', 'packages/quds_reports', 'packages/quds_office_editor']
elif cohort == 'studio':
    cwd = root / 'packages/quds_office_editor/example'
    files = ['test/studio_zotero_odt_export_test.dart']
    packages = [str(p.relative_to(root)) for p in sorted((root / 'packages').iterdir()) if (p / 'lib').is_dir()]
    packages += ['packages/quds_office_editor/example', 'third_party/enough_mail']
else:
    raise ValueError(cohort)

out = runtime / 'logs/membership-integrated-zotero' / (cohort + '-final')
out.mkdir(parents=True, exist_ok=True)
command = [str(runtime / 'bin/flutter'), 'test', '--no-pub', '--reporter=json', '--concurrency=2', *files]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source_hashes():
    paths = {root / name for name in ['.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml']}
    for relative in packages:
        package = root / relative
        paths.update(p for p in (package / 'lib').rglob('*') if p.is_file())
        paths.add(package / 'pubspec.yaml')
        for config in ['analysis_options.yaml', 'dart_test.yaml']:
            if (package / config).is_file():
                paths.add(package / config)
    paths.update(cwd / name for name in files)
    paths.add(root / 'packages/quds_office_engine/test/fixtures/zotero/word_document.xml')
    if cohort != 'engine':
        for folder in ['packages/quds_office_editor/fonts', 'packages/quds_office_editor/example/fonts']:
            paths.update(p for p in (root / folder).rglob('*') if p.is_file())
    return {str(p.relative_to(root)): digest(p) for p in sorted(paths)}

runtime_paths = [
    Path(__file__), root / 'tools/mail/check_store.py', root / 'tools/mail/check_reader.py',
    root / '.dart_tool/package_config.json', runtime / 'bin/flutter', runtime / 'bin/dart', runtime / 'env.sh',
    runtime / 'runtime.json', runtime / 'package-restoration.json',
    runtime / 'flutter/bin/flutter', runtime / 'flutter/bin/cache/flutter_tools.snapshot',
    runtime / 'flutter/bin/cache/dart-sdk/bin/dart',
    runtime / 'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',
    runtime / 'flutter/bin/cache/artifacts/engine/linux-x64/icudtl.dat',
    runtime / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart',
]

def runtime_hashes():
    return {str(p): digest(p) for p in runtime_paths}

record = {
    'status': 'RUNNING', 'cohort': cohort, 'started_at_utc': datetime.now(timezone.utc).isoformat(),
    'argv': command, 'cwd': str(cwd), 'timeout_seconds': 900,
    'starting_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'source_binding': 'The before/after source manifests identify tested working-tree inputs; commit metadata is context.',
    'incoming_word_commit': '258ae2a5d73bccd293b4b423918fc3d7646e9bc4', 'incoming_zotero_commit': '89789360590b6dd0af0a378bfc257a3c4a18fc9c',
    'source_before': source_hashes(), 'runtime_before': runtime_hashes(),
    'github_actions': 'NOT USED',
    'scope': 'Targeted local regression acceptance of native Roman note numbering across Word/ODT read-write, editor import-save ownership and Studio save lifecycle. No live LibreOffice/Zotero application qualification is inferred.',
    'runtime': json.loads((runtime / 'runtime.json').read_text())['framework'],
}
receipt = out / 'receipt.json'
write_receipt(receipt, record)
started = time.monotonic()
print(json.dumps({'status': 'RUNNING', 'cohort': cohort, 'source_inputs': len(record['source_before']), 'argv': command, 'receipt': str(receipt)}), flush=True)
try:
    with (out / 'test.jsonl').open('wb') as log, (out / 'test.stderr').open('wb') as err:
        code = execute(command, cwd=cwd, env=dict(os.environ), stdout=log, stderr=err, timeout=900)
    record['exit_code'] = code
    summary = test_summary(out / 'test.jsonl')
    (out / 'cases.json').write_text(json.dumps(summary, indent=2) + '\n')
    record['tests'] = {k: v for k, v in summary.items() if k != 'cases'}
    suites = {}
    for line in (out / 'test.jsonl').read_text().split('\n'):
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if isinstance(event, dict) and event.get('type') == 'suite':
            suite = event.get('suite', {})
            suites[suite.get('id')] = suite.get('path')
    counts = {}
    for case in summary['cases']:
        path = suites.get(case['suite_id'], 'unknown')
        counts.setdefault(path, {'passed': 0, 'failed': 0, 'skipped': 0})
        label = 'skipped' if case.get('skipped') else 'passed' if case.get('result') == 'success' else 'failed'
        counts[path][label] += 1
    record['suite_counts'] = counts
    record['all_requested_suites_executed'] = all(str(cwd / name) in counts and counts[str(cwd / name)]['passed'] > 0 for name in files)
    record['status'] = 'PASS' if code == 0 and summary['valid'] and record['all_requested_suites_executed'] else 'FAIL'
except BaseException as error:
    record['status'] = 'ERROR'
    record['error'] = repr(error)
finally:
    record['source_after'] = source_hashes()
    record['source_unchanged'] = record['source_before'] == record['source_after']
    record['runtime_after'] = runtime_hashes()
    record['runtime_unchanged'] = record['runtime_before'] == record['runtime_after']
    if not record['source_unchanged']:
        record['status'] = 'SOURCE_CHANGED'
    if not record['runtime_unchanged']:
        record['status'] = 'RUNTIME_CHANGED'
    for name in ['test.jsonl', 'test.stderr', 'cases.json']:
        p = out / name
        if p.exists():
            record[name] = {'path': str(p), 'sha256': digest(p), 'bytes': p.stat().st_size}
    record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    record['duration_seconds_monotonic'] = time.monotonic() - started
    write_receipt(receipt, record)
print(json.dumps({k: v for k, v in record.items() if k not in ['source_before', 'source_after', 'runtime_before', 'runtime_after', 'runtime']}, indent=2), flush=True)
sys.exit(0 if record['status'] == 'PASS' else 1)
