from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import subprocess
import sys

sys.dont_write_bytecode = True
root = Path('/workspace/scratch/be9367db5e45/quds_office_suite')
runtime = root.parent / 'mail-runtime'
cwd = root / 'packages/quds_office_engine'
output = runtime / 'logs/final-word-delta'
output.mkdir(parents=True, exist_ok=True)
dart = str(runtime / 'bin/dart')
test_runner = runtime / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
parser_path = root / 'tools/mail/check_store.py'
sys.path.insert(0, str(parser_path.parent))
spec = importlib.util.spec_from_file_location('mail_test_protocol', parser_path)
protocol = importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
tests = [
    'test/office_macro_word_cell_prefix_test.dart',
    'test/office_vba_word_cell_prefix_conformance_test.dart',
    'test/office_vba_word_cell_prefix_integration_test.dart',
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_snapshot():
    paths = set()
    for directory in ['lib', 'test', 'tool', 'example/macros']:
        paths.update(p for p in (cwd / directory).rglob('*') if p.is_file())
    paths.update(root / p for p in ['pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.fvmrc', '.dart_tool/package_config.json'])
    paths.update([cwd / 'pubspec.yaml', parser_path])
    return {str(p.relative_to(root)): digest(p) for p in sorted(paths)}


def runtime_snapshot():
    paths = [Path(__file__), Path(dart), runtime / 'flutter/bin/cache/dart-sdk/bin/dart', test_runner]
    return {str(p): digest(p) for p in paths}


def save():
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')


def run(name, command):
    started = datetime.now(timezone.utc).isoformat()
    with (output / f'{name}.stdout').open('w') as stdout, (output / f'{name}.stderr').open('w') as stderr:
        try:
            result = subprocess.run(command, cwd=cwd, stdout=stdout, stderr=stderr, timeout=600)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 124
    receipt['runs'].append({'name': name, 'argv': command, 'cwd': str(cwd), 'started_at': started, 'finished_at': datetime.now(timezone.utc).isoformat(), 'exit_code': code, 'stdout': f'{name}.stdout', 'stderr': f'{name}.stderr'})
    save()
    return code


original_receipt = runtime / 'logs/incoming-word-cell-prefix/receipt.json'
receipt = {
    'purpose': 'Final three changed Word suites after captured late heads and integrated XmlParseException guards. The earlier 1,564-case full Word/compiler acceptance remains evidence for its earlier exact source, not a rerun on this tree.',
    'started_at': datetime.now(timezone.utc).isoformat(),
    'starting_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'captured_word_tip': subprocess.check_output(['git', 'rev-parse', '258ae2a5'], cwd=root, text=True).strip(),
    'captured_zotero_tip': subprocess.check_output(['git', 'rev-parse', '89789360'], cwd=root, text=True).strip(),
    'earlier_full_acceptance_receipt': {'path': str(original_receipt), 'sha256': digest(original_receipt)},
    'source_before': source_snapshot(),
    'runtime_before': runtime_snapshot(),
    'dart_version': subprocess.check_output([dart, '--version'], text=True, stderr=subprocess.STDOUT).strip(),
    'runs': [],
    'github_actions': 'not queried or awaited',
    'limits': 'Synthetic engine fixtures; no installed Microsoft Word execution or full Office parity claim. Zotero production and regression strict analysis is recorded separately by the final Zotero gate.',
}
save()
try:
    code = run('native-tests', [dart, '--disable-dart-dev', '--packages=' + str(root / '.dart_tool/package_config.json'), str(test_runner), '--compiler=kernel', '--concurrency=1', '--reporter=json', *tests])
    summary = protocol.test_summary(output / 'native-tests.stdout')
    (output / 'test-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    receipt['native'] = {key: value for key, value in summary.items() if key != 'cases'}
    receipt['native']['exit_code'] = code
    run('strict-analysis', [dart, 'analyze', '--fatal-infos', *tests])
except BaseException as error:
    receipt['exception'] = repr(error)
finally:
    receipt['source_after'] = source_snapshot()
    receipt['runtime_after'] = runtime_snapshot()
    receipt['source_unchanged'] = receipt['source_before'] == receipt['source_after']
    receipt['runtime_unchanged'] = receipt['runtime_before'] == receipt['runtime_after']
    receipt['earlier_receipt_unchanged'] = digest(original_receipt) == receipt['earlier_full_acceptance_receipt']['sha256']
    receipt['finished_at'] = datetime.now(timezone.utc).isoformat()
    receipt['accepted'] = bool(receipt.get('native', {}).get('valid') and len(receipt['runs']) == 2 and all(run['exit_code'] == 0 for run in receipt['runs']) and receipt['source_unchanged'] and receipt['runtime_unchanged'] and receipt['earlier_receipt_unchanged'] and 'exception' not in receipt)
    receipt['artifact_sha256'] = {p.name: digest(p) for p in output.iterdir() if p.is_file() and p.name != 'receipt.json'}
    save()
print(json.dumps({key: value for key, value in receipt.items() if key not in ['source_before', 'source_after', 'runtime_before', 'runtime_after', 'runs']}, indent=2))
sys.exit(0 if receipt['accepted'] else 1)
