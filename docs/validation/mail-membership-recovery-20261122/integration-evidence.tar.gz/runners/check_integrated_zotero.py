from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,subprocess,sys,time
root=Path('/workspace/scratch/be9367db5e45/quds_office_suite')
runtime=root.parent/'mail-runtime'
out=runtime/'logs/membership-integrated-zotero/static-checks'
out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'tools/mail'))
from check_store import execute
from check_reader import write_receipt
files=[
 'packages/quds_office_engine/test/odt_reader_styles_test.dart',
 'packages/quds_office_engine/test/odt_zotero_export_lifecycle_test.dart',
 'packages/quds_office_engine/lib/src/word/model/word_note_numbering.dart',
 'packages/quds_office_engine/lib/src/word/serial/odt_document_reader.dart',
 'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart',
 'packages/quds_office_engine/lib/src/word/serial/odt_reader_styles.dart',
 'packages/quds_office_editor/test/word_odt_note_numbering_test.dart',
 'packages/quds_office_editor/example/test/studio_zotero_odt_export_test.dart',
]
reference=json.loads((runtime/'logs/membership-integrated-zotero/studio-isolated/receipt.json').read_text())
source_paths=set(reference['source_before'])|set(files)
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def source_hashes():return {p:sha(root/p) for p in sorted(source_paths)}
runtime_paths=set(reference['runtime_before'])|{str(Path(__file__))}
sdk=runtime/'flutter/bin/cache/dart-sdk/bin'
runtime_paths.update(str(p) for p in (sdk/'snapshots').glob('*analy*'))
runtime_paths.update(str(p) for p in (sdk/'snapshots').glob('*dartdev*'))
if (sdk/'dartaotruntime').is_file():runtime_paths.add(str(sdk/'dartaotruntime'))
def runtime_hashes():return {p:sha(Path(p)) for p in sorted(runtime_paths)}
commands={
 'analyze':[str(runtime/'bin/dart'),'analyze','--fatal-infos',*files],
 'format':[str(runtime/'bin/dart'),'format','--output=none','--set-exit-if-changed',*files[:2]],
}
r={'status':'RUNNING','started_at_utc':datetime.now(timezone.utc).isoformat(),'cwd':str(root),'argv':commands,'source_before':source_hashes(),'runtime_before':runtime_hashes(),'starting_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'github_actions':'NOT USED','scope':'Strict analyzer for the requested four incoming production sources, two updated engine tests, new editor test and Studio test; nonmutating format check of the two updated engine tests only.'}
receipt=out/'receipt.json';write_receipt(receipt,r)
started=time.monotonic()
try:
 r['checks']={}
 for name,command in commands.items():
  with (out/(name+'.stdout')).open('wb') as log,(out/(name+'.stderr')).open('wb') as err:
   code=execute(command,cwd=root,env=dict(os.environ),stdout=log,stderr=err,timeout=300)
  r['checks'][name]={'exit_code':code,'stdout':(out/(name+'.stdout')).read_text(),'stderr':(out/(name+'.stderr')).read_text()}
 r['status']='PASS' if all(v['exit_code']==0 for v in r['checks'].values()) else 'FAIL'
except BaseException as error:
 r['status']='ERROR';r['error']=repr(error)
finally:
 r['source_after']=source_hashes();r['source_unchanged']=r['source_before']==r['source_after']
 r['runtime_after']=runtime_hashes();r['runtime_unchanged']=r['runtime_before']==r['runtime_after']
 if not r['source_unchanged']:r['status']='SOURCE_CHANGED'
 if not r['runtime_unchanged']:r['status']='RUNTIME_CHANGED'
 editor=json.loads((runtime/'logs/membership-integrated-zotero/editor/receipt.json').read_text())
 r['prior_editor_source_still_matches']=all(sha(root/p)==digest for p,digest in editor['source_after'].items())
 for name in ['analyze.stdout','analyze.stderr','format.stdout','format.stderr']:
  path=out/name
  if path.exists():r[name]={'path':str(path),'sha256':sha(path),'bytes':path.stat().st_size}
 r['finished_at_utc']=datetime.now(timezone.utc).isoformat();r['duration_seconds_monotonic']=time.monotonic()-started
 write_receipt(receipt,r)
print(json.dumps({k:v for k,v in r.items() if k not in ['source_before','source_after','runtime_before','runtime_after']},indent=2),flush=True)
sys.exit(0 if r['status']=='PASS' else 1)
