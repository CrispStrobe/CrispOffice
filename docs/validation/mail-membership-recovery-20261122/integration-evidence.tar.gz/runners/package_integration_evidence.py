from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
ROOT = Path('/workspace/scratch/be9367db5e45/quds_office_suite')
RUNTIME = ROOT.parent / 'mail-runtime'
DEST = ROOT / 'docs/validation/mail-membership-recovery-20261122'
DEST.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / 'tools/mail'))
from check_store import test_summary


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
    return digest.hexdigest()


def read(path):
    return json.loads(path.read_text())


def artifact(path):
    return {'path': str(path.relative_to(RUNTIME)), 'sha256': sha(path), 'bytes': path.stat().st_size}


def input_path(name):
    path = Path(name)
    return path if path.is_absolute() else ROOT / path


def compare_inputs(expected):
    changed = []
    for name, digest in expected.items():
        path = input_path(name)
        actual = sha(path) if path.is_file() else None
        if actual != digest:
            changed.append({'path': name, 'recorded_sha256': digest, 'current_sha256': actual})
    return {'checked_inputs': len(expected), 'matches_current_checkout': not changed, 'differences': changed}


def verify_declared_artifacts(path, record):
    verified = 0
    for name, digest in record.get('artifact_sha256', {}).items():
        target = path.parent / name
        assert target.is_file() and sha(target) == digest, f'Artifact changed: {target}'
        verified += 1
    for name, value in record.items():
        if isinstance(value, dict) and set(('path', 'sha256')) <= value.keys():
            target = Path(value['path'])
            if target.is_file():
                assert sha(target) == value['sha256'], f'Artifact changed: {target}'
                verified += 1
    return verified


def accepted_record(relative, *, test_log=None, expected_cases=None, is_static=False):
    path = RUNTIME / 'logs' / relative
    record = read(path)
    assert record.get('status') == 'PASS' or record.get('accepted') is True, f'Not accepted: {path}'
    assert record['source_unchanged'] and record['source_before'] == record['source_after']
    assert record['runtime_unchanged'] and record['runtime_before'] == record['runtime_after']
    sources = compare_inputs(record['source_after'])
    runtime = compare_inputs(record['runtime_after'])
    assert sources['matches_current_checkout'], f'Final source changed: {path}'
    assert runtime['matches_current_checkout'], f'Final runtime changed: {path}'
    result = {'receipt': artifact(path), 'source_comparison': sources, 'runtime_comparison': runtime,
              'declared_artifacts_verified': verify_declared_artifacts(path, record)}
    if test_log is not None:
        log = path.parent / test_log
        summary = test_summary(log)
        assert summary['valid'] and summary['passed'] == expected_cases, (path, summary)
        result['tests'] = {key: value for key, value in summary.items() if key != 'cases'}
        result['raw_log'] = artifact(log)
    if is_static:
        assert all(check['exit_code'] == 0 for check in record['checks'].values())
        result['checks'] = record['checks']
        result['checked_source_files'] = record['argv']['analyze'][3:]
    return result


captured_at = datetime.now(timezone.utc).isoformat()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
word_tip = '258ae2a5d73bccd293b4b423918fc3d7646e9bc4'
zotero_tip = '89789360590b6dd0af0a378bfc257a3c4a18fc9c'
final = {
    'zotero_engine': accepted_record('membership-integrated-zotero/engine-final/receipt.json', test_log='test.jsonl', expected_cases=395),
    'zotero_editor': accepted_record('membership-integrated-zotero/editor-final/receipt.json', test_log='test.jsonl', expected_cases=14),
    'zotero_studio': accepted_record('membership-integrated-zotero/studio-final/receipt.json', test_log='test.jsonl', expected_cases=8),
    'zotero_static': accepted_record('membership-integrated-zotero/static-final/receipt.json', is_static=True),
    'xml_guard_focused': accepted_record('incoming-zotero-xml-guard/focused-receipt.json', test_log='focused.stdout', expected_cases=2),
    'word_late_delta': accepted_record('final-word-delta/receipt.json', test_log='native-tests.stdout', expected_cases=160),
}
word_delta = read(RUNTIME / 'logs/final-word-delta/receipt.json')
assert len(word_delta['runs']) == 2 and all(run['exit_code'] == 0 for run in word_delta['runs'])
final['word_late_delta']['strict_analysis'] = {'exit_code': 0, 'log': artifact(RUNTIME / 'logs/final-word-delta/strict-analysis.stdout')}
final['word_late_delta']['meaning'] = 'The three late-changed Word assertion/formatting suites were run on the final source. This is not a rerun of all 1,564 original Word cases.'

old_path = RUNTIME / 'logs/incoming-word-cell-prefix/receipt.json'
old = read(old_path)
assert old['status'] == 'PASS' and old['native']['accepted']
assert old['source_unchanged'] and old['source_before'] == old['source_after']
assert old['runtime_unchanged'] and old['runtime_before'] == old['runtime_after']
old_native = test_summary(old_path.parent / 'native-tests.stdout')
assert old_native['valid'] and old_native['passed'] == 1564
old_artifacts_verified = verify_declared_artifacts(old_path, old)
old_comparison = compare_inputs(old['source_after'])
assert len(old['source_after']) == 1270 and len(old_comparison['differences']) == 9
zotero_production = {
    'packages/quds_office_engine/lib/src/word/model/word_note_numbering.dart',
    'packages/quds_office_engine/lib/src/word/model/word_notes.dart',
    'packages/quds_office_engine/lib/src/word/serial/odt_reader_styles.dart',
}
zotero_tests = {
    'packages/quds_office_engine/test/odt_libreoffice_note_offsets_test.dart',
    'packages/quds_office_engine/test/odt_reader_styles_test.dart',
    'packages/quds_office_engine/test/odt_zotero_export_lifecycle_test.dart',
}
word_tests = {
    'packages/quds_office_engine/test/office_macro_word_cell_prefix_test.dart',
    'packages/quds_office_engine/test/office_vba_word_cell_prefix_conformance_test.dart',
    'packages/quds_office_engine/test/office_vba_word_cell_prefix_integration_test.dart',
}
assert {change['path'] for change in old_comparison['differences']} == zotero_production | zotero_tests | word_tests
for change in old_comparison['differences']:
    change['classification'] = ('reviewed Zotero numbering/default/parser production change' if change['path'] in zotero_production else
                                'reviewed Zotero fixture/acceptance update' if change['path'] in zotero_tests else
                                'late Word assertion/formatting update; qualified by final 160-case delta')
automation = {name: digest for name, digest in old['source_after'].items() if name.startswith('packages/quds_office_engine/lib/src/automation/')}
automation_comparison = compare_inputs(automation)
assert automation and automation_comparison['matches_current_checkout']
old_runtime = compare_inputs(old['runtime_after'])
assert old_runtime['matches_current_checkout']
portable = []
for item in old['portable']:
    assert item['vm_exit'] == 0 and item['compile_exit'] == 0 and item['node_exit'] == 0 and item['semantic_json_equal']
    vm = old_path.parent / (item['name'] + '-vm.stdout')
    node = old_path.parent / (item['name'] + '-node.stdout')
    assert read(vm) == read(node)
    fixture = ROOT / 'packages/quds_office_engine' / item['fixture']
    assert sha(fixture) == item['fixture_sha256']
    portable.append({**item, 'vm_output': artifact(vm), 'node_output': artifact(node), 'fixture_matches_current': True,
                     'source_scope': 'Earlier captured source of the immutable original Word receipt; not a final-tree rerun.'})

source_dirs = [
    RUNTIME / 'logs/membership-integrated-zotero',
    RUNTIME / 'logs/incoming-word-cell-prefix',
    RUNTIME / 'logs/incoming-zotero-xml-guard',
    RUNTIME / 'logs/final-word-delta',
]
members = {}
excluded = []
for directory in source_dirs:
    for path in sorted(directory.rglob('*')):
        if not path.is_file():
            continue
        assert not path.is_symlink(), f'Unexpected symlink: {path}'
        name = str(path.relative_to(RUNTIME))
        if path.name.endswith(('.js', '.js.map', '.js.deps', '.dill', '.deps', '.pyc')):
            excluded.append({'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path),
                             'reason': 'Reproducible compiler output. Original command, source/fixture hashes, compiler logs and VM/Node semantic outputs are retained.'})
            continue
        members[name] = path
for name in [
    'run_integrated_zotero.py', 'run_integrated_zotero_isolated.py', 'run_integrated_zotero_final.py',
    'check_integrated_zotero.py', 'check_integrated_zotero_final.py', 'run_incoming_word_acceptance.py',
    'run_final_word_delta.py', 'package_integration_evidence.py',
]:
    path = RUNTIME / name
    assert path.is_file(), path
    members['runners/' + name] = path
for name in ['env.sh', 'bin/dart', 'bin/flutter', 'runtime.json', 'package-restoration.json']:
    members['runtime/' + name] = RUNTIME / name
for name in ['tools/mail/check_store.py', 'tools/mail/check_reader.py']:
    members['repository-helpers/' + name] = ROOT / name

entries = []
for name, path in sorted(members.items()):
    assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
    entries.append({'path': name, 'source_path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)})

archive_temp = RUNTIME / 'integration-evidence.tar.gz.tmp'
with archive_temp.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', compresslevel=9, fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for entry in entries:
                path = members[entry['path']]
                info = tarfile.TarInfo(entry['path'])
                info.size = entry['bytes']
                info.mode = 0o644
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                with path.open('rb') as stream:
                    archive.addfile(info, stream)

expected = {entry['path']: entry for entry in entries}
verified = set()
with tarfile.open(archive_temp, 'r:gz') as archive:
    for info in archive:
        assert info.isfile() and info.name in expected and info.name not in verified
        item = expected[info.name]
        stream = archive.extractfile(info)
        digest = hashlib.sha256()
        size = 0
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
            size += len(chunk)
        assert size == item['bytes'] and digest.hexdigest() == item['sha256'], info.name
        verified.add(info.name)
assert verified == set(expected)
for entry in entries:
    assert sha(members[entry['path']]) == entry['sha256'], f'Original changed while packaging: {entry["path"]}'

archive_name = 'integration-evidence.tar.gz'
archive_details = {'file': archive_name, 'sha256': sha(archive_temp), 'bytes': archive_temp.stat().st_size,
                   'members': len(entries), 'uncompressed_member_bytes': sum(entry['bytes'] for entry in entries)}
acceptance = {
    'schema_version': 1,
    'kind': 'captured_integration_acceptance',
    'status': 'PASS_WITH_EXPLICIT_HISTORICAL_WORD_SCOPE',
    'created_at_utc': captured_at,
    'checked_checkout_head': head,
    'captured_tips': {
        'word': {'ref': 'origin/codex/word-vba-continuation-20261122', 'sha': word_tip},
        'zotero': {'ref': 'origin/codex/zotero-native-parity-20261122', 'sha': zotero_tip},
    },
    'captured_tips_are_ancestors_of_checked_head': {label: subprocess.run(['git', 'merge-base', '--is-ancestor', tip, head], cwd=ROOT).returncode == 0 for label, tip in [('word', word_tip), ('zotero', zotero_tip)]},
    'github_actions': 'Not queried or awaited for acceptance.',
    'final_source_bound_acceptance': final,
    'case_count_interpretation': {
        'final_zotero_substantive_cases': 417,
        'zotero_components': {'engine': 395, 'editor': 14, 'studio': 8},
        'final_changed_word_substantive_cases': 160,
        'focused_xml_cases': 2,
        'focused_xml_cases_overlap_zotero_engine': True,
        'historical_word_native_cases': 1564,
        'historical_word_vm_and_node_cases': {'prefix_conformance': 78, 'paragraph_conformance': 32},
        'note': 'Counts describe named cohorts. The XML proof is a subset of the final engine suite, and the late Word suite overlaps the earlier Word acceptance; these are not a single disjoint test total.',
    },
    'historical_word_acceptance': {
        'receipt': artifact(old_path),
        'incoming_tip_at_original_run': old['incoming_word_tip'],
        'starting_head': old['starting_head'],
        'started_at': old['started_at'], 'finished_at': old['finished_at'],
        'source_inputs_during_original_run': 1270,
        'source_unchanged_during_original_run': True,
        'runtime_unchanged_during_original_run': True,
        'native_summary_reparsed_from_raw_log': {key: value for key, value in old_native.items() if key != 'cases'},
        'portable': portable,
        'declared_original_artifacts_verified': old_artifacts_verified,
        'current_source_comparison': old_comparison,
        'word_automation_and_compiler_production': automation_comparison,
        'original_runtime_matches_current': old_runtime,
        'qualification_limit': 'The original 1,564-case native run plus VM/Node 78-case and 32-case conformance and six-operation BAS round trip is acceptance of its earlier captured source. Its full 1,270-input map now differs in nine reviewed note/parser/test inputs. It is not a complete final-tree Word rerun. The unchanged Word automation/compiler production, final 160-case changed-Word run and final 417-case Zotero run establish the stated narrower continuation evidence.',
        'older_applicability_supplement': {'path': 'logs/incoming-word-cell-prefix/current-applicability.json', 'treatment': 'Preserved historical snapshot for its recorded a76cd5c8 head. Its earlier two-test-difference conclusion is superseded for current applicability by the nine-input comparison in this report.'},
    },
    'independent_review_and_repairs': [
        {'finding': 'Three older tests still required Roman note numbering to be rejected after Roman support was introduced.',
         'repair': 'Changed refusal fixtures to unsupported alphabetic numbering; retained the negative boundary and added four positive configuration cases and two source-preserving Roman lifecycle cases.',
         'verification': 'Final engine 395 cases and strict analysis pass; earlier assertion diagnostics retained.'},
        {'finding': 'XmlPullReader throws XmlParseException while the strict numbering guards and legacy _xml helper caught only FormatException, allowing malformed native XML to escape the intended bounded fallback.',
         'repair': 'Added precise XmlParseException handling at the two catch sites, with mismatched-closing-tag and unterminated-child regression cases. Broader exception swallowing was not introduced.',
         'verification': 'Focused two-case receipt and final new 62-case numbering suite pass; all three affected production files are included in final strict analysis.'},
    ],
    'diagnostic_history': [
        {'path': 'logs/membership-integrated-zotero/engine/receipt.json', 'meaning': 'Interrupted initial engine run: 298 passes, three obsolete assertions, one stalled suite loader, no successful terminal event. Explicit diagnostic only.'},
        {'path': 'logs/membership-integrated-zotero/studio/receipt.json', 'meaning': 'Initial concurrent Studio attempt completed eight assertions but reported a Dart compiler exit and failed overall. Later sequential isolated and final runs passed.'},
        {'path': 'logs/membership-integrated-zotero/engine-isolated/receipt.json', 'meaning': 'Earlier 333-case corrected engine PASS before the final captured Zotero guard continuation; retained without relabeling it as final-source evidence.'},
        {'path': 'logs/final-word-delta/bootstrap-diagnostic.txt', 'meaning': 'Python runner import-path bootstrap error corrected before any Dart execution; no product source change.'},
    ],
    'limits': [
        'Local synthetic/independently authored format and controller fixtures; no installed Microsoft Word, LibreOffice or live Zotero plugin run is claimed by this package.',
        'Original receipts and logs are byte-preserved. Original commands retain their original workspace paths and runtime context.',
        'Compiled JavaScript, source maps, dependency files, dill files, SDK/cache trees and downloads are excluded as reproducible outputs; command/source/runtime hashes and semantic execution logs remain available.',
    ],
    'archive': archive_details,
}
acceptance_temp = RUNTIME / 'integration-acceptance.json.tmp'
acceptance_temp.write_text(json.dumps(acceptance, indent=2) + '\n')
manifest = {
    'schema_version': 1,
    'created_at_utc': captured_at,
    'archive': archive_details,
    'acceptance_report': {'file': 'integration-acceptance.json', 'sha256': sha(acceptance_temp), 'bytes': acceptance_temp.stat().st_size},
    'members': entries,
    'excluded_reproducible_files': excluded,
    'unselected_runtime_roots': [
        {'path': 'mail-runtime/flutter/', 'reason': 'SDK/tool binaries are reproducible from the verified runtime archive; runtime metadata and hashes are retained.'},
        {'path': 'mail-runtime/pub-cache/', 'reason': 'Dependency cache binaries/source are reproducible from lockfile and verified package-archive metadata.'},
        {'path': 'mail-runtime/tmp/ and SDK/package downloads', 'reason': 'Ephemeral compiler/build outputs and downloaded archives are unnecessary to inspect the original execution records.'},
    ],
    'archive_policy': 'Only regular files; normalized tar ownership/mode/time and gzip timestamp. Original file bytes are unchanged. No receipt is rewritten.',
    'verification': {'every_member_sha256_and_size_read_back_from_archive': True, 'member_set_exact_no_duplicates': True, 'original_inputs_still_match_after_archiving': True, 'verified_members': len(verified)},
}
manifest_temp = RUNTIME / 'integration-evidence-manifest.json.tmp'
manifest_temp.write_text(json.dumps(manifest, indent=2) + '\n')
for temporary, target in [(archive_temp, DEST/archive_name), (acceptance_temp, DEST/'integration-acceptance.json'), (manifest_temp, DEST/'integration-evidence-manifest.json')]:
    os.replace(temporary, target)
print(json.dumps({'status': acceptance['status'], 'checked_head': head,
                  'files': [{'path': str(DEST/name), 'bytes': (DEST/name).stat().st_size, 'sha256': sha(DEST/name)} for name in ['integration-acceptance.json', archive_name, 'integration-evidence-manifest.json']],
                  'archive_members': len(entries), 'excluded_compiled_files': len(excluded),
                  'excluded_compiled_bytes': sum(item['bytes'] for item in excluded),
                  'word_automation_inputs_unchanged': len(automation), 'historical_word_source_differences': len(old_comparison['differences']),
                  'final_counts': {'zotero': 417, 'changed_word': 160, 'focused_xml_subset': 2}}, indent=2))
