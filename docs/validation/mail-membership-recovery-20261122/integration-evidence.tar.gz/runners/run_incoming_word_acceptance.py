from pathlib import Path
from datetime import datetime, timezone
import base64
import hashlib
import json
import os
import subprocess
import sys

root = Path('/workspace/scratch/be9367db5e45/quds_office_suite')
runtime = root.parent / 'mail-runtime'
cwd = root / 'packages/quds_office_engine'
out = runtime / 'logs/incoming-word-cell-prefix'
out.mkdir(parents=True, exist_ok=True)
dart = str(runtime / 'bin/dart')
packages = '--packages=' + str(root / '.dart_tool/package_config.json')
runner = str(runtime / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart')
files = [
    'office_macro_word_cell_prefix_test.dart',
    'office_vba_word_cell_prefix_test.dart',
    'office_vba_word_cell_prefix_conformance_test.dart',
    'office_vba_word_cell_prefix_integration_test.dart',
    'office_vba_string_constants_test.dart',
    'office_vba_word_cell_formatting_test.dart',
    'office_vba_word_cell_paragraphs_test.dart',
    'office_vba_word_cell_paragraphs_conformance_test.dart',
    'office_vba_word_cell_paragraphs_integration_test.dart',
    'office_vba_word_table_cells_test.dart',
    'office_macro_word_table_cells_test.dart',
    'office_macro_word_cell_formatting_test.dart',
    'office_vba_language_test.dart',
    'office_vba_arguments_test.dart',
    'office_vba_arguments_integration_test.dart',
    'office_vba_procedures_test.dart',
    'office_vba_string_intrinsics_test.dart',
    'office_vba_text_construction_test.dart',
    'office_vba_text_intrinsics_test.dart',
    'office_vba_word_language_test.dart',
    'office_vba_word_integration_test.dart',
    'office_vba_word_headers_footers_test.dart',
    'office_vba_word_headers_footers_integration_test.dart',
    'office_vba_word_text_integration_test.dart',
]
production = [
    'lib/src/automation/office_operations.dart',
    'lib/src/automation/office_vba_language.dart',
    'lib/src/automation/operations/word_steps.dart',
    'lib/src/automation/operations/word_table_cell_text_steps.dart',
]

def hashes():
    paths = set()
    for directory in ['lib', 'test', 'tool', 'example/macros']:
        paths.update(p for p in (cwd / directory).rglob('*') if p.is_file())
    paths.update(root / p for p in ['pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.fvmrc', '.dart_tool/package_config.json'])
    paths.add(cwd / 'pubspec.yaml')
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths) if p.is_file()}

def runtime_hashes():
    paths = [Path(__file__), runtime / 'flutter/bin/cache/dart-sdk/bin/dart', Path(runner), runtime / 'bin/dart', root / '.dart_tool/package_config.json']
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}

def write(name, obj):
    (out / name).write_text(json.dumps(obj, indent=2) + '\n')

record = {'started_at': datetime.now(timezone.utc).isoformat(), 'incoming_word_tip': '806525fdb06d501fff09d4fb6b12ee95ef6cf4b2', 'cwd': str(cwd), 'starting_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'runs': [], 'source_before': hashes(), 'runtime_before': runtime_hashes(), 'github_actions': 'not queried or awaited', 'limits': 'Synthetic engine fixtures; no installed Microsoft Word execution or complete Office parity claim.'}
record['dart_version'] = subprocess.check_output([dart, '--version'], text=True, stderr=subprocess.STDOUT).strip()
record['node_version'] = subprocess.check_output(['node', '--version'], text=True).strip()
write('receipt.json', record)

def run(name, argv, timeout=600):
    started = datetime.now(timezone.utc).isoformat()
    with (out / (name + '.stdout')).open('w') as stdout, (out / (name + '.stderr')).open('w') as stderr:
        try:
            process = subprocess.run(argv, cwd=cwd, env=dict(os.environ), stdout=stdout, stderr=stderr, timeout=timeout)
            code = process.returncode
        except subprocess.TimeoutExpired:
            code = 124
    record['runs'].append({'name': name, 'argv': argv, 'started_at': started, 'finished_at': datetime.now(timezone.utc).isoformat(), 'exit_code': code, 'stdout': name + '.stdout', 'stderr': name + '.stderr'})
    write('receipt.json', record)
    return code

try:
    code = run('native-tests', [dart, '--disable-dart-dev', packages, runner, '--compiler=kernel', '--concurrency=2', '--reporter=json', *['test/' + f for f in files]], timeout=900)
    rows = []
    for line in (out / 'native-tests.stdout').read_text().splitlines():
        try:
            rows.append(json.loads(line))
        except ValueError:
            pass
    started = {r['test']['id']: r['test'] for r in rows if r.get('type') == 'testStart'}
    cases = []
    for row in rows:
        if row.get('type') != 'testDone' or row.get('hidden'):
            continue
        test = started.get(row['testID'], {})
        if test.get('name', '').startswith('loading '):
            continue
        cases.append({'name': test.get('name'), 'source': test.get('url', '').replace('file://' + str(root) + '/', ''), 'result': row['result'], 'skipped': row.get('skipped', False)})
    errors = [r for r in rows if r.get('type') == 'error']
    done = [r for r in rows if r.get('type') == 'done']
    record['native'] = {'visible_cases': len(cases), 'passed': sum(r['result'] == 'success' and not r['skipped'] for r in cases), 'failures': sum(r['result'] != 'success' for r in cases), 'skips': sum(r['skipped'] for r in cases), 'errors': errors, 'done': done, 'accepted': code == 0 and not errors and all(r['result'] == 'success' and not r['skipped'] for r in cases) and len(done) == 1 and done[0].get('success') is True}
    write('native-cases.json', cases)
    run('analysis', [dart, 'analyze', '--fatal-infos', *production, *['test/' + f for f in files], 'tool/macros/web_vba_word_cell_prefix_smoke.dart', 'tool/macros/web_vba_word_cell_prefix_conformance.dart'])
    record['portable'] = []
    for name, fixture, definition, script in [
        ('prefix-conformance', 'test/fixtures/vba_conformance/word_cell_prefix_v1.json', 'VBA_CONFORMANCE_BASE64', 'tool/macros/web_vba_word_cell_prefix_conformance.dart'),
        ('paragraph-conformance', 'test/fixtures/vba_conformance/word_cell_paragraphs_v1.json', 'VBA_CONFORMANCE_BASE64', 'tool/macros/web_vba_conformance.dart'),
        ('prefix-bas', 'example/macros/word_table_prefix.bas', 'WORD_CELL_PREFIX_BAS_BASE64', 'tool/macros/web_vba_word_cell_prefix_smoke.dart'),
    ]:
        encoded = base64.b64encode((cwd / fixture).read_bytes()).decode()
        define = '-D' + definition + '=' + encoded
        js = out / (name + '.js')
        vm = run(name + '-vm', [dart, '--disable-dart-dev', packages, define, script])
        compiled = run(name + '-compile', [dart, 'compile', 'js', '-O1', packages, define, script, '-o', str(js)])
        node = run(name + '-node', ['node', '-e', 'globalThis.self=globalThis;require(process.argv[1]);', str(js)]) if compiled == 0 else None
        same = False
        result = None
        if vm == 0 and node == 0:
            left = json.loads((out / (name + '-vm.stdout')).read_text())
            right = json.loads((out / (name + '-node.stdout')).read_text())
            same = left == right
            result = {'caseCount': left.get('caseCount')} if 'caseCount' in left else {k: v for k, v in left.items() if k != 'state'}
        record['portable'].append({'name': name, 'fixture': fixture, 'fixture_sha256': hashlib.sha256((cwd / fixture).read_bytes()).hexdigest(), 'vm_exit': vm, 'compile_exit': compiled, 'node_exit': node, 'semantic_json_equal': same, 'result': result})
        write('receipt.json', record)
except BaseException as error:
    record['error'] = repr(error)
finally:
    record['source_after'] = hashes()
    record['runtime_after'] = runtime_hashes()
    record['source_unchanged'] = record['source_before'] == record['source_after']
    record['runtime_unchanged'] = record['runtime_before'] == record['runtime_after']
    record['finished_at'] = datetime.now(timezone.utc).isoformat()
    record['status'] = 'PASS' if record.get('native', {}).get('accepted') and len(record.get('portable', [])) == 3 and all(p['semantic_json_equal'] for p in record['portable']) and all(r['exit_code'] == 0 for r in record['runs']) and record['source_unchanged'] and record['runtime_unchanged'] and 'error' not in record else 'FAIL'
    record['artifact_sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name != 'receipt.json'}
    write('receipt.json', record)
print(json.dumps({k: v for k, v in record.items() if k not in ['source_before', 'source_after', 'runtime_before', 'runtime_after', 'runs', 'artifact_sha256']}, indent=2))
sys.exit(0 if record['status'] == 'PASS' else 1)
