from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path('/workspace/scratch/be9367db5e45/quds_office_suite')
runtime = root.parent / 'mail-runtime'
out = runtime / 'logs/membership-transport-native-final'
out.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(root / 'tools/mail'))
from check_store import execute, test_summary
from check_reader import write_receipt

cwd = root / 'packages/quds_mail_transport'
files = [
    'test/native_membership_observation_test.dart',
    'test/native_provider_test.dart',
    'test/native_flag_observation_test.dart',
    'test/cloud_provider_test.dart',
    'test/ews_provider_test.dart',
    'test/ews_soap_test.dart',
]
command = [str(runtime / 'bin/flutter'), 'test', '--no-pub', '--reporter=json', *files]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source_hashes():
    paths = {root / name for name in ['.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml']}
    for relative in ['packages/quds_mail_core', 'packages/quds_mail_mime', 'packages/quds_mail_transport', 'third_party/enough_mail']:
        package = root / relative
        paths.update(p for p in (package / 'lib').rglob('*') if p.is_file())
        paths.add(package / 'pubspec.yaml')
        for config in ['analysis_options.yaml', 'dart_test.yaml']:
            if (package / config).is_file():
                paths.add(package / config)
    paths.update(cwd / name for name in files)
    paths.update(p for p in (cwd / 'test/support').rglob('*') if p.is_file())
    return {str(p.relative_to(root)): digest(p) for p in sorted(paths)}

runtime_paths = [
    Path(__file__), root / 'tools/mail/check_store.py', root / 'tools/mail/check_reader.py',
    root / '.dart_tool/package_config.json', runtime / 'bin/flutter', runtime / 'bin/dart', runtime / 'env.sh',
    runtime / 'runtime.json', runtime / 'package-restoration.json',
    runtime / 'flutter/bin/flutter', runtime / 'flutter/bin/cache/flutter_tools.snapshot',
    runtime / 'flutter/bin/cache/dart-sdk/bin/dart',
    runtime / 'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',
    runtime / 'flutter/bin/cache/artifacts/engine/linux-x64/icudtl.dat',
    runtime / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart',
]

def runtime_hashes():
    return {str(p): digest(p) for p in runtime_paths}

record = {
    'status': 'RUNNING', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
    'argv': command, 'cwd': str(cwd), 'timeout_seconds': 900,
    'starting_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'source_before': source_hashes(), 'runtime_before': runtime_hashes(),
    'github_actions': 'NOT USED',
    'scope': 'Six requested native transport suites with IMAP loopback/fake transport and fake cloud/EWS fixtures. This run does not establish live-account/provider or browser qualification.',
    'runtime': json.loads((runtime / 'runtime.json').read_text())['framework'],
}
receipt = out / 'receipt.json'
write_receipt(receipt, record)
started = time.monotonic()
print(json.dumps({'status': 'RUNNING', 'source_inputs': len(record['source_before']), 'argv': command, 'receipt': str(receipt)}), flush=True)
try:
    with (out / 'test.jsonl').open('wb') as log, (out / 'test.stderr').open('wb') as err:
        code = execute(command, cwd=cwd, env=dict(os.environ), stdout=log, stderr=err, timeout=900)
    record['exit_code'] = code
    summary = test_summary(out / 'test.jsonl')
    (out / 'cases.json').write_text(json.dumps(summary, indent=2) + '\n')
    record['tests'] = {k: v for k, v in summary.items() if k != 'cases'}
    suites = {}
    for line in (out / 'test.jsonl').read_text().split('\n'):
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if isinstance(event, dict) and event.get('type') == 'suite':
            suite = event.get('suite', {})
            suites[suite.get('id')] = suite.get('path')
    counts = {}
    for case in summary['cases']:
        path = suites.get(case['suite_id'], 'unknown')
        counts.setdefault(path, {'passed': 0, 'failed': 0, 'skipped': 0})
        label = 'skipped' if case.get('skipped') else 'passed' if case.get('result') == 'success' else 'failed'
        counts[path][label] += 1
    record['suite_counts'] = counts
    record['all_requested_suites_executed'] = all(str(cwd / name) in counts and counts[str(cwd / name)]['passed'] > 0 for name in files)
    record['status'] = 'PASS' if code == 0 and summary['valid'] and record['all_requested_suites_executed'] else 'FAIL'
except BaseException as error:
    record['status'] = 'ERROR'
    record['error'] = repr(error)
finally:
    record['source_after'] = source_hashes()
    record['source_unchanged'] = record['source_before'] == record['source_after']
    record['runtime_after'] = runtime_hashes()
    record['runtime_unchanged'] = record['runtime_before'] == record['runtime_after']
    if not record['source_unchanged']:
        record['status'] = 'SOURCE_CHANGED'
    if not record['runtime_unchanged']:
        record['status'] = 'RUNTIME_CHANGED'
    for name in ['test.jsonl', 'test.stderr', 'cases.json']:
        p = out / name
        if p.exists():
            record[name] = {'path': str(p), 'sha256': digest(p), 'bytes': p.stat().st_size}
    record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    record['duration_seconds_monotonic'] = time.monotonic() - started
    write_receipt(receipt, record)
print(json.dumps({k: v for k, v in record.items() if k not in ['source_before', 'source_after', 'runtime_before', 'runtime_after', 'runtime']}, indent=2), flush=True)
sys.exit(0 if record['status'] == 'PASS' else 1)
