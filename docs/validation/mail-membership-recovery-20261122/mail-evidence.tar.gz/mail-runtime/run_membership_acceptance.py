from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

root = Path('/workspace/scratch/be9367db5e45/quds_office_suite')
output = Path('/workspace/scratch/be9367db5e45/mail-runtime/logs/membership')
runtime = Path('/workspace/scratch/be9367db5e45/mail-runtime')

def snapshot():
    files = set()
    for package in ['quds_mail_core', 'quds_mail_store']:
        for directory in ['lib', 'test']:
            files.update(p for p in (root / 'packages' / package / directory).rglob('*') if p.is_file())
        files.add(root / 'packages' / package / 'pubspec.yaml')
    files.update(root / p for p in ['pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.dart_tool/package_config.json'])
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}

def write_json(name, data):
    (output / name).write_text(json.dumps(data, indent=2) + '\n')

started = datetime.now(timezone.utc).isoformat()
before = snapshot()
write_json('accepted-inputs-before.json', before)
command = [str(runtime / 'bin/dart'), '--disable-dart-dev', '--packages=' + str(root / '.dart_tool/package_config.json'), str(runtime / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'), '--compiler=kernel', '--reporter=json', 'packages/quds_mail_core/test', 'packages/quds_mail_store/test']
with (output / 'accepted-native-core-store.jsonl').open('w') as stream:
    process = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
after = snapshot()
write_json('accepted-inputs-after.json', after)
rows = []
unparsed = []
for line in (output / 'accepted-native-core-store.jsonl').read_text().splitlines():
    try:
        rows.append(json.loads(line))
    except ValueError:
        unparsed.append(line)
tests = {r['test']['id']: r['test'] for r in rows if r.get('type') == 'testStart'}
cases = []
for row in rows:
    if row.get('type') != 'testDone' or row.get('hidden'):
        continue
    test = tests.get(row['testID'], {})
    if test.get('name', '').startswith('loading '):
        continue
    cases.append({'id': row['testID'], 'name': test.get('name'), 'source': test.get('url', '').replace('file://' + str(root) + '/', ''), 'result': row['result'], 'skipped': row.get('skipped', False)})
changed = [p for p in sorted(before.keys() | after.keys()) if before.get(p) != after.get(p)]
errors = [r for r in rows if r.get('type') == 'error']
done = [r for r in rows if r.get('type') == 'done']
counts = {name: len([r for r in cases if r['source'].startswith('packages/' + name + '/') and r['result'] == 'success' and not r['skipped']]) for name in ['quds_mail_core', 'quds_mail_store']}
receipt = {'started_at': started, 'finished_at': datetime.now(timezone.utc).isoformat(), 'cwd': str(root), 'command': command, 'exit_code': process.returncode, 'source_inputs': len(before), 'changed_inputs': changed, 'counts': counts, 'visible_cases': len(cases), 'failures': len([r for r in cases if r['result'] != 'success']), 'skips': len([r for r in cases if r['skipped']]), 'errors': errors, 'done': done, 'unparsed_output': unparsed, 'cases': cases}
receipt['accepted'] = process.returncode == 0 and not changed and not errors and not receipt['failures'] and not receipt['skips'] and len(done) == 1 and done[0].get('success') is True
write_json('native-core-store-receipt.json', receipt)
print(json.dumps({k: v for k, v in receipt.items() if k not in ['cases', 'command', 'unparsed_output']}, indent=2))
sys.exit(0 if receipt['accepted'] else 1)
