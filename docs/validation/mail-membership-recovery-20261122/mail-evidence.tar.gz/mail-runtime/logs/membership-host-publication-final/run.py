from pathlib import Path
import os,sys,json,hashlib,datetime,subprocess
repo=Path('/workspace/scratch/be9367db5e45/quds_office_suite')
runtime=repo.parent/'mail-runtime'
out=Path(__file__).resolve().parent
cwd=repo/'packages/quds_office_editor/example'
sys.path.insert(0,str(repo/'tools/mail'))
from check_store import execute,test_summary
from check_reader import write_receipt
files=['test/studio_mail_membership_reconciliation_test.dart','test/studio_mail_flag_recovery_dialog_test.dart','test/studio_mail_journal_dialog_test.dart','test/studio_mail_flag_reconciliation_test.dart','test/studio_mail_message_loader_test.dart','test/studio_mail_journal_host_test.dart']
shots=runtime/'screenshots/membership-bound-publication-final'
cmd=[str(runtime/'bin/flutter'),'test','--no-pub','--machine','--dart-define=MAIL_RECOVERY_SCREENSHOT_DIR='+str(shots),*files]
assert all((cwd/name).is_file() for name in files)
assert not shots.exists() or not list(shots.iterdir()),'Screenshot directory must be fresh'
shots.mkdir(parents=True,exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source_hashes():
 paths=[repo/n for n in ['.fvmrc','pubspec.yaml','pubspec.lock','analysis_options.yaml','tools/mail/check_store.py','tools/mail/check_reader.py']]
 for package in (repo/'packages').iterdir():
  if not package.is_dir():continue
  paths.extend((package/'lib').rglob('*'))
  paths.extend([package/'pubspec.yaml',package/'analysis_options.yaml'])
 paths.extend((repo/'third_party/enough_mail/lib').rglob('*'))
 paths.append(repo/'third_party/enough_mail/pubspec.yaml')
 paths.extend((cwd/'lib').rglob('*'))
 paths.extend((cwd/'test/support').rglob('*'))
 paths.extend(cwd/name for name in files)
 paths.extend(cwd/name for name in ['pubspec.yaml','analysis_options.yaml','flutter_test_config.dart','test/flutter_test_config.dart'])
 return {str(p.relative_to(repo)):digest(p) for p in sorted(set(paths)) if p.is_file() and not any(n in p.parts for n in ['.dart_tool','build','__pycache__'])}
runtime_paths=[Path(__file__).resolve(),runtime/'env.sh',runtime/'bin/flutter',runtime/'flutter/bin/flutter',runtime/'flutter/bin/cache/flutter_tools.snapshot',runtime/'flutter/bin/cache/dart-sdk/bin/dart',runtime/'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',repo/'.dart_tool/package_config.json',repo/'.dart_tool/native_assets.yaml']
runtime_paths.extend((repo/'.dart_tool/hooks_runner/shared/sqlite3/build').rglob('libsqlite3.so'))
def runtime_hashes():return {str(p):digest(p) for p in runtime_paths if p.is_file()}
record={'status':'RUNNING','started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':cmd,'cwd':str(cwd),'starting_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source_before':source_hashes(),'runtime_before':runtime_hashes(),'framework':json.loads((runtime/'logs/flutter-version.json').read_text()),'timeout_seconds':600,'scope':'Six focused native Flutter host suites with synthetic providers and new bound screenshots. No live-provider or installed-platform acceptance.','github_actions':'NOT USED'}
receipt=out/'receipt.json';write_receipt(receipt,record)
try:
 with (out/'test.jsonl').open('wb') as stdout,(out/'test.stderr').open('wb') as stderr:
  code=execute(cmd,cwd=cwd,env=dict(os.environ),stdout=stdout,stderr=stderr,timeout=600)
 record['exit_code']=code
 raw_bytes=(out/'test.jsonl').read_bytes()
 allowed=[{'event':'test.startedProcess','params':{'vmServiceUri':None}}]
 frames=[];test_lines=[]
 for number,line in enumerate(raw_bytes.decode('utf-8').split('\n'),1):
  if not line.strip():continue
  if line.strip().startswith('['):
   obj=json.loads(line)
   if obj!=allowed:raise ValueError(f'Unexpected Flutter daemon envelope at line {number}: {obj!r}')
   frames.append({'line':number,'frame':obj})
  else:test_lines.append(line)
 if len(frames)!=len(files):raise ValueError('Expected exactly one known Flutter start-process frame per requested suite')
 normalized=out/'test-events.jsonl';normalized.write_text('\n'.join(test_lines)+'\n')
 summary=test_summary(normalized)
 events=[json.loads(line) for line in test_lines if line.strip().startswith('{')]
 record['flutter_daemon_notifications']=frames
 record['normalization']={'allowed_frame':allowed,'removed_frames':len(frames),'raw_log_unchanged':(out/'test.jsonl').read_bytes()==raw_bytes,'note':'Only exact Flutter daemon start-process arrays are separated from package:test events. Every test event remains unchanged.'}
 suites={e['suite']['id']:e['suite']['path'] for e in events if e.get('type')=='suite'}
 cases=[];seen=set();duplicates=[]
 for c in summary['cases']:
  path=str(Path(suites[c['suite_id']]).resolve())
  key=(path,c['name'])
  if key in seen:duplicates.append({'path':path,'name':c['name']})
  else:seen.add(key);cases.append(dict(c,path=path))
 unique_passed=sum(c.get('result')=='success' and not c.get('skipped') for c in cases)
 expected={str((cwd/f).resolve()) for f in files}
 actual={str(Path(p).resolve()) for p in suites.values()}
 record['suites_match_requested']=actual==expected
 record['suites']=sorted(actual)
 record['unique_passed']=unique_passed
 record['duplicate_case_count']=len(duplicates)
 record['duplicate_cases']=duplicates
 record['tests']={k:v for k,v in summary.items() if k!='cases'}
 (out/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
 record['status']='PASS' if code==0 and summary['valid'] and actual==expected and not duplicates else 'FAIL'
except BaseException as e:
 record['status']='ERROR';record['error']=repr(e)
finally:
 record['source_after']=source_hashes();record['source_unchanged']=record['source_before']==record['source_after']
 record['runtime_after']=runtime_hashes();record['runtime_unchanged']=record['runtime_before']==record['runtime_after']
 if not record['source_unchanged']:record['status']='SOURCE_CHANGED'
 if not record['runtime_unchanged']:record['status']='RUNTIME_CHANGED'
 record['screenshots']=[{'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(shots.glob('*.png'))]
 for name in ['test.jsonl','test-events.jsonl','test.stderr','cases.json']:
  p=out/name
  if p.exists():record[name]={'path':str(p),'sha256':digest(p)}
 record['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 write_receipt(receipt,record)
print(json.dumps({k:v for k,v in record.items() if k not in ['source_before','source_after','runtime_before','runtime_after']},indent=2))
sys.exit(0 if record['status']=='PASS' else 1)
