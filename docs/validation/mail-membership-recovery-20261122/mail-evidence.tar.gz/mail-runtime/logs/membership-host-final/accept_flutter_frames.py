from pathlib import Path
import json,hashlib,sys,datetime
out=Path(__file__).resolve().parent
repo=Path('/workspace/scratch/be9367db5e45/quds_office_suite')
sys.path.insert(0,str(repo/'tools/mail'))
from check_store import test_summary
from check_reader import write_receipt
raw=out/'test.jsonl';receipt=out/'receipt.json'
r=json.loads(receipt.read_text())
raw_bytes=raw.read_bytes();frames=[];events=[]
allowed=[{'event':'test.startedProcess','params':{'vmServiceUri':None}}]
for line_number,line in enumerate(raw_bytes.decode('utf-8').split('\n'),1):
 if not line.strip():continue
 obj=json.loads(line)
 if isinstance(obj,list):
  if obj!=allowed:raise ValueError(f'Unexpected non-test event at line {line_number}: {obj!r}')
  frames.append({'line':line_number,'frame':obj})
 else:
  if not isinstance(obj,dict):raise ValueError(f'Unexpected JSON record at line {line_number}')
  events.append(line)
assert len(frames)==6==len(r['suites']), 'Expected one exact Flutter start frame per requested suite'
normalized=out/'test-events.jsonl';normalized.write_text('\n'.join(events)+'\n')
s=test_summary(normalized)
assert s['valid'] and s['passed']==r['unique_passed']==277
assert r['exit_code']==0 and r['duplicate_case_count']==0 and r['suites_match_requested']
assert r['source_unchanged'] and r['runtime_unchanged']
current_mismatch=[name for name,digest in r['source_after'].items() if not (repo/name).is_file() or hashlib.sha256((repo/name).read_bytes()).hexdigest()!=digest]
assert not current_mismatch,current_mismatch
accepted=dict(r)
accepted['status']='PASS'
accepted['tests']={k:v for k,v in s.items() if k!='cases'}
accepted['raw_parser_diagnostic']=r['tests']
accepted['invocation_receipt']={'path':str(receipt),'sha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),'note':'Preserved unchanged. Its initial FAIL is solely the generic Dart parser rejecting the six known Flutter start-process arrays.'}
accepted['flutter_daemon_notifications']=frames
accepted['normalization']={'script':str(Path(__file__).resolve()),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'allowed_frame':allowed,'removed_frames':len(frames),'test_events_preserved':len(events),'raw_log_unchanged':hashlib.sha256(raw.read_bytes()).hexdigest()==hashlib.sha256(raw_bytes).hexdigest(),'normalized_log':str(normalized),'normalized_log_sha256':hashlib.sha256(normalized.read_bytes()).hexdigest(),'note':'Only exact Flutter daemon start-process envelopes were separated from package:test events. No test outcome, error, skip, loading record or other event was removed or changed.'}
accepted['accepted_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
accepted['current_applicability_mismatches']=current_mismatch
write_receipt(out/'acceptance.json',accepted)
print(json.dumps({'status':accepted['status'],'unique_passed':accepted['unique_passed'],'source_paths':len(accepted['source_after']),'runtime_paths':len(accepted['runtime_after']),'normalized_test_summary':accepted['tests'],'raw_log_unchanged':accepted['normalization']['raw_log_unchanged'],'screenshots':len(accepted['screenshots'])},indent=2))
