import concurrent.futures, hashlib, json, pathlib, subprocess, tarfile, datetime
root=pathlib.Path(__file__).resolve().parent
receipts=json.loads((root/'prior-package-restoration.json').read_text())['receipts']
def restore(item):
    name,version,expected=item['name'],item['version'],item['sha256']
    archive=root/'downloads'/f'{name}-{version}.tar.gz'
    if not archive.exists() or hashlib.sha256(archive.read_bytes()).hexdigest()!=expected:
        subprocess.run(['curl','-sS','-L','--fail','--retry','2','--connect-timeout','15','--max-time','180','-o',str(archive),item['url']],check=True)
    digest=hashlib.sha256(archive.read_bytes()).hexdigest()
    if digest != expected: raise ValueError(f'Hash mismatch {name} {version}: {digest}')
    target=root/'pub-cache'/'hosted'/'pub.dev'/f'{name}-{version}'
    target.mkdir(parents=True,exist_ok=True)
    with tarfile.open(archive) as tar: tar.extractall(target,filter='data')
    hashfile=root/'pub-cache'/'hosted-hashes'/'pub.dev'/f'{name}-{version}.sha256'
    hashfile.parent.mkdir(parents=True,exist_ok=True)
    hashfile.write_text(expected)
    print(f'verified {name} {version}',flush=True)
    return dict(item,bytes=archive.stat().st_size,verified=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
    results=list(pool.map(restore,receipts))
(root/'package-restoration.json').write_text(json.dumps({'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'receipts':results},indent=2)+'\n')
print(f'Restored {len(results)} verified package archives',flush=True)
