from pathlib import Path
import sys,json,hashlib,datetime,subprocess,os
root=Path('/workspace/scratch/be9367db5e45/quds_office_suite')
runtime=root.parent/'mail-runtime'
sys.path.insert(0,str(root/'tools/mail'))
from check_store import execute,test_summary
from check_reader import write_receipt
cohort=sys.argv[1]
if cohort=='transport':
 package='quds_mail_transport'
 files=['test/cloud_provider_test.dart','test/unsupported_test.dart','test/cloud_unsupported_test.dart','test/ews_unsupported_test.dart']
 deps=['packages/quds_mail_core/lib','packages/quds_mail_mime/lib','packages/quds_mail_transport/lib','third_party/enough_mail/lib']
elif cohort=='core':
 package='quds_mail_core';files=[];deps=['packages/quds_mail_core/lib','packages/quds_mail_core/test']
elif cohort=='portable-store':
 package='quds_mail_store';files=['test/codec_test.dart','test/platform_configuration_test.dart','test/browser_problem_test.dart','test/archive_export_manifest_test.dart'];deps=['packages/quds_mail_core/lib','packages/quds_mail_store/lib','packages/quds_mail_store/tool']
else:raise ValueError(cohort)
out=runtime/'logs'/('membership-node-'+cohort+'-final')
out.mkdir(parents=True,exist_ok=True)
cwd=root/'packages'/package
cmd=[str(runtime/'bin/dart'),'--disable-dart-dev','--packages='+str(root/'.dart_tool/package_config.json'),str(runtime/'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),'--platform=node','--compiler=dart2js','--concurrency=2','--reporter=json',*files]
def hashes():
 paths=[root/x for x in ['pubspec.yaml','pubspec.lock','analysis_options.yaml','.fvmrc']]
 for d in deps:paths.extend((root/d).rglob('*.dart'))
 for name in files:paths.append(cwd/name)
 for p in ['quds_mail_core','quds_mail_mime','quds_mail_store','quds_mail_transport']:paths.append(root/'packages'/p/'pubspec.yaml')
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths)) if p.is_file()}
record={'status':'RUNNING','started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':cmd,'cwd':str(cwd),'timeout_seconds':900,'source_before':hashes(),'starting_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'node_version':subprocess.check_output(['node','--version'],text=True).strip(),'github_actions':'NOT USED','scope':'Genuine Node execution; does not qualify browser runtime or live providers.'}
runtime_paths=[Path(__file__),root/'.dart_tool/package_config.json',root/'tools/mail/check_store.py',root/'tools/mail/check_reader.py',runtime/'flutter/bin/cache/dart-sdk/bin/dart',runtime/'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart']
def runtime_hashes():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in runtime_paths}
record['runtime_before']=runtime_hashes()
receipt=out/'receipt.json';write_receipt(receipt,record)
code=1
try:
 with (out/'test.jsonl').open('wb') as log,(out/'test.stderr').open('wb') as err:
  code=execute(cmd,cwd=cwd,env=dict(os.environ),stdout=log,stderr=err,timeout=900)
 record['exit_code']=code
 summary=test_summary(out/'test.jsonl')
 (out/'cases.json').write_text(json.dumps(summary,indent=2)+'\n')
 record['tests']={k:v for k,v in summary.items() if k!='cases'}
 record['status']='PASS' if code==0 and summary['valid'] else 'FAIL'
except BaseException as e:
 record['status']='ERROR';record['error']=repr(e)
finally:
 record['source_after']=hashes();record['source_unchanged']=record['source_before']==record['source_after']
 record['runtime_after']=runtime_hashes();record['runtime_unchanged']=record['runtime_before']==record['runtime_after']
 if not record['runtime_unchanged']:record['status']='RUNTIME_CHANGED'
 if not record['source_unchanged']:record['status']='SOURCE_CHANGED'
 for name in ['test.jsonl','test.stderr','cases.json']:
  p=out/name
  if p.exists():record[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 record['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 write_receipt(receipt,record)
print(json.dumps({k:v for k,v in record.items() if k not in ['source_before','source_after']},indent=2))
sys.exit(0 if record['status']=='PASS' else 1)
