#!/usr/bin/env python3
"""Assemble the Mail qualification evidence without changing its original records."""
from __future__ import annotations

from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

BASE = Path('/workspace/scratch/be9367db5e45')
ROOT = BASE / 'quds_office_suite'
RUNTIME = BASE / 'mail-runtime'
OUT = ROOT / 'docs/validation/mail-membership-recovery-20261122'
sys.path.insert(0, str(ROOT / 'tools/mail'))
from check_store import test_summary


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    if not path.is_file():
        return None
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(relative):
    return json.loads((RUNTIME / relative).read_text())


def relative_file(path):
    return str(path.relative_to(BASE))


def clean_summary(summary):
    return {key: value for key, value in summary.items() if key != 'cases'}


def main():
    cohort_specs = [
        ('native-core-store', 'native Dart', 'logs/membership/native-core-store-receipt.json',
         'logs/membership/accepted-native-core-store.jsonl', 1635),
        ('native-providers', 'native Flutter', 'logs/membership-transport-native-final/receipt.json',
         'logs/membership-transport-native-final/test.jsonl', 338),
        ('integrated-host', 'native Flutter', 'logs/membership-host-publication-final/receipt.json',
         'logs/membership-host-publication-final/test-events.jsonl', 277),
        ('node-core', 'Node / dart2js', 'logs/membership-node-core-final/receipt.json',
         'logs/membership-node-core-final/test.jsonl', 574),
        ('node-transport', 'Node / dart2js', 'logs/membership-node-transport-final/receipt.json',
         'logs/membership-node-transport-final/test.jsonl', 160),
        ('node-portable-store', 'Node / dart2js', 'logs/membership-node-portable-store-final/receipt.json',
         'logs/membership-node-portable-store-final/test.jsonl', 52),
    ]
    accepted_records = {name: read(receipt) for name, _, receipt, _, _ in cohort_specs}
    cohorts, log_checks = [], []
    for name, platform, receipt_name, log_name, expected in cohort_specs:
        receipt = accepted_records[name]
        assert receipt.get('accepted', receipt.get('status') == 'PASS'), name
        assert receipt['exit_code'] == 0, name
        log = RUNTIME / log_name
        summary = test_summary(log)
        assert summary['valid'] and summary['passed'] == expected, (name, clean_summary(summary))
        suites = {}
        for line in log.read_text().split('\n'):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except ValueError:
                continue
            if isinstance(event, dict) and event.get('type') == 'suite':
                suites[event['suite']['id']] = event['suite']['path']
        labels = Counter((suites.get(case['suite_id']), case['name']) for case in summary['cases'])
        collisions = [dict(suite=path, label=label, executions=count)
                      for (path, label), count in labels.items() if count > 1]
        for collision in collisions:
            assert name in {'native-core-store', 'node-core'}
            assert collision['suite'].endswith('saved_header_search_folders_test.dart')
            assert collision['label'] == 'rejects malformed account with length 2'
            assert collision['executions'] == 2
        cohorts.append(dict(name=name, platform=platform, passed=expected,
                            receipt='mail-runtime/' + receipt_name,
                            receipt_sha256=file_sha(RUNTIME / receipt_name),
                            parsed_log='mail-runtime/' + log_name,
                            parsed_log_sha256=file_sha(log), tests=clean_summary(summary),
                            display_label_collisions=collisions))
        for key in ['test.jsonl', 'test-events.jsonl', 'test.stderr', 'cases.json']:
            if key in receipt:
                record = receipt[key]
                actual = file_sha(Path(record['path']))
                assert actual == record['sha256'], (name, key)
                log_checks.append(dict(cohort=name, artifact=record['path'], sha256=actual))
    native = accepted_records['native-core-store']
    for name, expected in native['artifact_sha256'].items():
        path = RUNTIME / 'logs/membership' / name
        assert file_sha(path) == expected, name
        log_checks.append(dict(cohort='native-core-store', artifact=str(path), sha256=expected))
    assert native['counts'] == {'quds_mail_core': 574, 'quds_mail_store': 1061}
    assert not native['changed_inputs'] and not native['supplemental_fixture_changed_inputs']

    # Prove that the normalized host stream removes only exact daemon frames.
    host_folder = RUNTIME / 'logs/membership-host-publication-final'
    host = accepted_records['integrated-host']
    frame = [{'event': 'test.startedProcess', 'params': {'vmServiceUri': None}}]
    normalized, frames = [], []
    for number, line in enumerate((host_folder / 'test.jsonl').read_text().split('\n'), 1):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except ValueError:
            event = None
        if event == frame:
            frames.append(dict(line=number, frame=event))
        else:
            normalized.append(line)
    assert len(frames) == 6 and frames == host['flutter_daemon_notifications']
    assert '\n'.join(normalized) + '\n' == (host_folder / 'test-events.jsonl').read_text()

    source_maps, runtime_maps, original_files = [], [], {}
    root_originals = [
        'archive-receipt.json', 'env.sh', 'node-qualification.json', 'package-restoration.json',
        'prior-package-restoration.json', 'restore_packages.py', 'run_membership_acceptance.py',
        'run_node_checks.py', 'run_node_final.py', 'run_transport_native_final.py',
        'runtime.json', 'runtime_smoke.dart', 'transport-review.json',
    ]
    paths = [RUNTIME / name for name in root_originals]
    for folder in ['logs', 'screenshots', 'bin']:
        for path in (RUNTIME / folder).rglob('*'):
            if not path.is_file() or path.is_symlink():
                continue
            parts = path.relative_to(RUNTIME).parts
            if any(part.startswith('incoming-') or 'zotero' in part or 'word-cell-prefix' in part
                   or part == '__pycache__' for part in parts):
                continue
            paths.append(path)
    for path in sorted(set(paths)):
        original_files[relative_file(path)] = path.read_bytes()

    accepted_source_fields = set()
    accepted_runtime_fields = set()
    for _, _, receipt, _, _ in cohort_specs:
        if receipt.endswith('native-core-store-receipt.json'):
            continue
        for key in ['source_before', 'source_after']:
            accepted_source_fields.add(('mail-runtime/' + receipt, key))
        for key in ['runtime_before', 'runtime_after']:
            accepted_runtime_fields.add(('mail-runtime/' + receipt, key))
    accepted_source_fields.update({
        ('mail-runtime/logs/membership/accepted-inputs-before.json', '$'),
        ('mail-runtime/logs/membership/accepted-inputs-after.json', '$'),
        ('mail-runtime/logs/membership/subprocess-fixture-inputs.json', '$'),
        ('mail-runtime/logs/mail-static-final/receipt.json', 'before'),
        ('mail-runtime/logs/mail-static-final/receipt.json', 'after'),
        ('mail-runtime/node-qualification.json', 'source_sha256'),
        ('mail-runtime/transport-review.json', 'source_sha256'),
    })

    def inspect_map(origin, field, values, kind):
        if not isinstance(values, dict) or not values:
            return
        normalized = {}
        for path, value in values.items():
            expected = value.get('sha256') if isinstance(value, dict) else value
            if not isinstance(expected, str) or not re.fullmatch('[0-9a-f]{64}', expected):
                return
            normalized[path] = expected
        mismatches = []
        for name, expected in normalized.items():
            path = Path(name) if name.startswith('/') else ROOT / name
            actual = file_sha(path)
            if actual != expected:
                mismatches.append(dict(path=name, expected=expected, actual=actual))
        accepted = (origin, field) in (accepted_source_fields if kind == 'source' else accepted_runtime_fields)
        item = dict(record=origin, field=field, kind=kind, accepted_input=accepted,
                    path_count=len(normalized), mismatch_count=len(mismatches), mismatches=mismatches)
        (source_maps if kind == 'source' else runtime_maps).append(item)
        if accepted:
            assert not mismatches, item
        return normalized

    source_union, runtime_union = {}, {}
    standalone = {'accepted-inputs-before.json', 'accepted-inputs-after.json',
                  'subprocess-fixture-inputs.json', 'source-manifest-postrun.json'}
    for origin, data in original_files.items():
        if not origin.endswith('.json'):
            continue
        document = json.loads(data)
        if not isinstance(document, dict):
            continue
        fields = []
        if Path(origin).name in standalone:
            fields.append(('$', document, 'source'))
        for field in ['source_before', 'source_after', 'source_sha256']:
            if field in document:
                fields.append((field, document[field], 'source'))
        for field in ['runtime_before', 'runtime_after', 'runtime_hashes_at_capture']:
            if field in document:
                fields.append((field, document[field], 'runtime'))
        if origin == 'mail-runtime/logs/mail-static-final/receipt.json':
            fields += [('before', document['before'], 'source'), ('after', document['after'], 'source')]
        for field, values, kind in fields:
            result = inspect_map(origin, field, values, kind)
            if result and (origin, field) in (accepted_source_fields if kind == 'source' else accepted_runtime_fields):
                target = source_union if kind == 'source' else runtime_union
                for name, digest in result.items():
                    assert name not in target or target[name] == digest, (origin, field, name)
                    target[name] = digest
    assert set((x['record'], x['field']) for x in source_maps if x['accepted_input']) == accepted_source_fields
    assert set((x['record'], x['field']) for x in runtime_maps if x['accepted_input']) == accepted_runtime_fields

    static = read('logs/mail-static-final/receipt.json')
    assert static['accepted'] and static['source_unchanged']
    assert len(static['mail_changed_dart_files']) == 46
    assert all(command['exit_code'] == 0 for command in static['commands'])
    assert '46 files (0 changed)' in (RUNTIME / 'logs/mail-static-final/format.txt').read_text()
    assert 'No issues found' in (RUNTIME / 'logs/mail-static-final/analysis.txt').read_text()
    prior_host = read('logs/host-membership-postrun-evidence/receipt.json')
    prior_analyzer = prior_host['analyzer']
    assert file_sha(Path(prior_analyzer['log'])) == prior_analyzer['sha256']
    assert 'No issues found' in Path(prior_analyzer['log']).read_text()

    runtime = read('runtime.json')
    lock = (ROOT / 'pubspec.lock').read_bytes()
    lock_sha = sha(lock)
    baseline_lock = subprocess.check_output(['git', 'show', 'b13a170c:pubspec.lock'], cwd=ROOT)
    lock_status = subprocess.check_output(['git', 'status', '--porcelain', '--', 'pubspec.lock'], cwd=ROOT, text=True)
    assert lock_sha == runtime['workspace_lock_sha256'] and lock == baseline_lock and not lock_status
    assert runtime['framework']['frameworkVersion'] == '3.47.8'
    assert runtime['framework']['dartSdkVersion'] == '3.13.7'
    node_version = subprocess.check_output(['node', '--version'], text=True).strip()
    assert node_version == 'v24.22.3'

    visual = json.loads((host_folder / 'visual-review.json').read_text())
    comparison = json.loads((host_folder / 'screenshot-comparison.json').read_text())
    assert visual['status'] == comparison['status'] == 'PASS'
    assert len(host['screenshots']) == len(comparison['images']) == 12
    assert len(visual['images']) == 3
    assert all(image['pixels_identical'] and image['changed_pixels'] == 0
               and image['before_sha256'] == image['after_sha256'] for image in comparison['images'])
    for image in host['screenshots']:
        assert file_sha(Path(image['path'])) == image['sha256']

    supplemental = {
        'qualification/source-map-audit.json': encoded(source_maps),
        'qualification/runtime-map-audit.json': encoded(runtime_maps),
        'qualification/accepted-source-sha256.json': encoded(source_union),
        'qualification/accepted-runtime-sha256.json': encoded(runtime_union),
        'qualification/strict-reparse.json': encoded(cohorts),
        'qualification/original-log-integrity.json': encoded(log_checks),
        'qualification/host-frame-normalization.json': encoded(dict(
            exact_allowed_frame=frame, separated_frames=frames, original_raw_unchanged=True,
            reconstructed_normalized_log_matches=True)),
        'replay/replay_mail_evidence.py': (RUNTIME / 'replay_mail_evidence.py').read_bytes(),
        'replay/verify_mail_evidence.py': (RUNTIME / 'verify_mail_evidence.py').read_bytes(),
        'replay/package_mail_evidence.py': Path(__file__).read_bytes(),
        'repo-tools/mail/check_store.py': (ROOT / 'tools/mail/check_store.py').read_bytes(),
        'repo-tools/mail/check_reader.py': (ROOT / 'tools/mail/check_reader.py').read_bytes(),
        'repo-tools/mail/test_check_store.py': (ROOT / 'tools/mail/test_check_store.py').read_bytes(),
        'repository-runtime/package_config.json': (ROOT / '.dart_tool/package_config.json').read_bytes(),
        'repository-runtime/native_assets.yaml': (ROOT / '.dart_tool/native_assets.yaml').read_bytes(),
        'repository-inputs/pubspec.lock': lock,
        'repository-inputs/.fvmrc': (ROOT / '.fvmrc').read_bytes(),
    }
    supplemental['replay/REPLAY.md'] = b'''# Mail evidence replay

The original record bodies, runners, logs and screenshots under `mail-runtime/`
are preserved byte for byte. Their absolute paths describe the original run.
The archive contains no SDK, Pub cache, downloaded package archive or account
credential. Obtain the pinned official Flutter 3.47.8 / Dart 3.13.7 distribution
and Node v24.22.3. `mail-runtime/archive-receipt.json` records the official Flutter
URL and verified SHA-256; `package-restoration.json` records 204 verified locked
package archives. Prepare the checkout dependencies with `pub get --offline
--enforce-lockfile` after restoring that cache, preserving the recorded lock.
Native tests additionally require the package-hook-generated SQLite asset map;
`repository-runtime/native_assets.yaml` is the original mapping, with its source
and binary digest recorded in `runtime.json`. Regenerate local absolute paths
through the package hooks when relocating, rather than reusing stale paths.

Use a checkout matching `qualification/accepted-source-sha256.json`. The manifest
and runtime provenance are evidence, not a self-contained offline toolchain.
To plan a replay without executing tests:

```sh
python3 replay/replay_mail_evidence.py --repo /path/to/checkout --runtime /path/to/prepared-mail-runtime --output /path/to/new-replay
```

Add `--run` to execute all six cohorts, or `--cohort integrated-host` (and any of
the other named cohorts shown by `--help`) for a selected cohort. The new output
directory must not exist and must be outside this extracted evidence directory.
Tracked source and lock hashes are required to match. The generated package
configuration is permitted to have relocated absolute paths, and its actual
before/after hash is recorded. The adapter invokes the prepared SDK directly;
original wrappers remain archived without changes. It captures new raw logs,
before/after sources and runtime inputs, exact argv/cwd, exit status and strict
test summaries. The host adapter separates only the six exact Flutter daemon
start-process frames before parsing package:test events.

The original native core/store, final Node, native transport and final integrated
host runners are also retained in their original locations. Their hardcoded
workspace paths can be studied without editing the accepted records. Run the
original 46-file formatter and strict analysis commands listed in
`mail-runtime/logs/mail-static-final/receipt.json` from the relocated checkout
when reproducing those separate checks. Earlier host analysis is retained with
its original post-run source-binding limitation; it adds no accepted test count.

To check the distributed archive and every member against the adjacent manifest:

```sh
python3 replay/verify_mail_evidence.py --artifacts /path/to/validation-directory
```

The totals count successful substantive executions, including platform overlap.
Loading/hidden lifecycle records do not add passes. Distinct core parameter
cases can share a display label; duplicate event IDs or completions are rejected
by the strict parser. Diagnostic and repeated runs add no accepted executions.
Archive member timestamps are normalized to zero; no filesystem modification
time or original record timestamp is used to infer source applicability.
'''

    all_files = dict(original_files)
    all_files.update(supplemental)
    assert len(all_files) == len(original_files) + len(supplemental)
    for name in all_files:
        parts = Path(name).parts
        assert not (len(parts) >= 2 and parts[0] == 'mail-runtime'
                    and parts[1] in {'flutter', 'pub-cache', 'downloads'}), name
        assert '__pycache__' not in parts, name
        assert not any(part.startswith('incoming-') or 'zotero' in part or 'word-cell-prefix' in part for part in parts), name
    members = [dict(path=name, bytes=len(data), sha256=sha(data),
                    origin='preserved original' if name in original_files else 'packaging supplement')
               for name, data in sorted(all_files.items())]
    OUT.mkdir(parents=True, exist_ok=True)
    archive_path = OUT / 'mail-evidence.tar.gz'
    with archive_path.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for member in members:
                    data = all_files[member['path']]
                    info = tarfile.TarInfo(member['path'])
                    info.size, info.mtime = len(data), 0
                    info.mode = 0o755 if member['path'].endswith('.py') else 0o644
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    archive.addfile(info, io.BytesIO(data))
    # Read every archived member back before producing a PASS acceptance.
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert sorted(archive.getnames()) == sorted(all_files)
        for member in members:
            assert sha(archive.extractfile(member['path']).read()) == member['sha256']
    for name, expected in source_union.items():
        assert file_sha(ROOT / name) == expected, ('source changed during packaging', name)
    for name, expected in runtime_union.items():
        assert file_sha(Path(name)) == expected, ('runtime changed during packaging', name)
    # Original files must still equal their captured bytes; they are never rewritten.
    for name, data in original_files.items():
        assert file_sha(BASE / name) == sha(data), ('original changed during packaging', name)

    acceptance = dict(
        schema_version=1, status='PASS', scope='Mail membership recovery local qualification',
        checkout_commit_at_packaging=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        accepted_executions=3036, cohorts=cohorts,
        counting=dict(native_core=574, native_store=1061, native_providers=338,
                      integrated_host=277, node_core=574, node_transport=160, node_portable_store=52,
                      platform_overlap=True, globally_unique_test_count_claimed=False,
                      excluded='All diagnostic, setup smoke, preliminary and repeated cohorts; loading and hidden lifecycle events.',
                      duplicate_protocol_events=0,
                      label_collision='Native core and Node core each execute two distinct parameter values with the label rejects malformed account with length 2: leading-space account and unpaired-surrogate account. Each has a separate test ID and completion; both executions count.'),
        source_applicability=dict(
            status='PASS', accepted_source_maps=len(accepted_source_fields),
            unique_source_config_fixture_paths=len(source_union), accepted_mismatches=0,
            source_union='qualification/accepted-source-sha256.json', source_union_sha256=sha(encoded(source_union)),
            all_recorded_source_maps_audited=len(source_maps),
            diagnostic_maps_with_differences=sum(bool(item['mismatches']) for item in source_maps if not item['accepted_input']),
            audit='qualification/source-map-audit.json',
            method='Current SHA-256 comparison of all recorded maps. Accepted before/after maps must agree with the checkout; diagnostic mismatches are retained explicitly. No modification-time chronology is inferred.',
            native_core_store='142 contemporaneous before/after inputs plus seven supplemental unchanged subprocess fixtures.',
            integrated_host='Contemporaneous before/after source/config/test inputs include the final captured Office production imports. Earlier host capture is retained as a repeated cohort.'),
        runtime=dict(status='PASS', flutter='3.47.8', dart='3.13.7', node=node_version,
                     accepted_runtime_maps=len(accepted_runtime_fields), unique_runtime_paths=len(runtime_union),
                     current_mismatches=0, audit='qualification/runtime-map-audit.json',
                     provenance='mail-runtime/runtime.json', dependency_archives_verified=204,
                     native_core_store_limitation='The native core/store runner recorded exact argv and source before/after but no separate per-run runtime hash pair. Shared pinned runtime provenance and current hashed runtime inputs are retained; no extra contemporaneous runtime snapshot is claimed.'),
        lock=dict(path='pubspec.lock', sha256=lock_sha, unchanged_from_commit='b13a170c',
                  unchanged_from_setup=True, worktree_clean=True),
        static_checks=dict(status='PASS', changed_dart_files_formatted=46, format_changes=0,
                           strict_analysis_packages=['quds_mail_core', 'quds_mail_store', 'quds_mail_transport'],
                           receipt='mail-runtime/logs/mail-static-final/receipt.json',
                           receipt_sha256=file_sha(RUNTIME / 'logs/mail-static-final/receipt.json'),
                           native_core_store_analysis='mail-runtime/logs/membership/analyze-core-store-acceptance.txt',
                           prior_host_analysis=dict(log='mail-runtime/logs/host-membership-analyze-final.log',
                                                    sha256=prior_analyzer['sha256'], result='No issues found',
                                                    binding='Original post-run source binding limitation retained. This log adds no test executions.')),
        visual=dict(status='PASS', generated_integrated_pngs=12, directly_inspected=3,
                    byte_identical_to_prior_integrated=12, pixel_identical_to_prior_integrated=12,
                    accepted_receipt='mail-runtime/logs/membership-host-publication-final/receipt.json',
                    review='mail-runtime/logs/membership-host-publication-final/visual-review.json',
                    comparison='mail-runtime/logs/membership-host-publication-final/screenshot-comparison.json',
                    limitations='Representative English/German/Arabic enlarged-text captures reviewed; synthetic widget runs do not establish installed-platform or live-account acceptance.'),
        diagnostics_retained=[
            'Initial native core/store generic-fixture, migration-import and synthetic-v7-fixture failures; preliminary full run predates final UTF-16 inputs.',
            'Initial Node core has 549 passes but changed source inputs; initial Node transport/store are repeats. None contributes to the accepted total.',
            'Initial native provider and host attempts, including host generic analyzer and corrected test expectations.',
            'Preintegration host raw receipt reports protocol errors for Flutter daemon arrays; its exact-frame supplemental acceptance is retained. The integrated 277-case cohort is counted once.',
            'Setup launcher stalls/interruption and readiness smoke are retained separately from feature qualification.',
        ],
        boundaries=['No live-provider account qualification', 'No browser runtime or persistent browser storage qualification',
                    'No installed Android/iOS/macOS/Windows/Linux package qualification',
                    'Incoming Word/Zotero integration tests are outside this Mail archive'],
        github_actions='NOT USED OR AWAITED',
        evidence_archive=dict(path='mail-evidence.tar.gz', sha256=file_sha(archive_path), bytes=archive_path.stat().st_size,
                              members=len(members), manifest='mail-evidence-manifest.json'),
        replay='replay/REPLAY.md', record_preservation='Original record bodies and raw artifacts are archived byte for byte; added audits do not rewrite original receipts.'
    )
    assert sum(cohort['passed'] for cohort in cohorts) == acceptance['accepted_executions']
    acceptance_path = OUT / 'mail-acceptance.json'
    acceptance_path.write_bytes(encoded(acceptance))
    manifest = dict(schema_version=1, archive=acceptance['evidence_archive'],
                    acceptance=dict(path='mail-acceptance.json', sha256=file_sha(acceptance_path), bytes=acceptance_path.stat().st_size),
                    format='gzip-compressed POSIX pax tar; regular files only; deterministic member order; normalized uid/gid and zero timestamps',
                    verification='Every member was read back and SHA-256 checked after writing. Original bytes and accepted source/runtime maps were rechecked before acceptance.',
                    preserved_original_members=len(original_files), supplemental_members=len(supplemental),
                    uncompressed_member_bytes=sum(member['bytes'] for member in members), members=members)
    manifest_path = OUT / 'mail-evidence-manifest.json'
    manifest_path.write_bytes(encoded(manifest))
    print(json.dumps(dict(status='PASS', accepted_executions=3036,
                          source_maps=len(source_maps), accepted_source_maps=len(accepted_source_fields),
                          source_paths=len(source_union), runtime_paths=len(runtime_union),
                          diagnostic_source_maps_with_differences=acceptance['source_applicability']['diagnostic_maps_with_differences'],
                          files=[dict(path=str(path), bytes=path.stat().st_size, sha256=file_sha(path))
                                 for path in [acceptance_path, archive_path, manifest_path]]), indent=2))


if __name__ == '__main__':
    main()
