# Mail evidence replay

The original record bodies, runners, logs and screenshots under `mail-runtime/`
are preserved byte for byte. Their absolute paths describe the original run.
The archive contains no SDK, Pub cache, downloaded package archive or account
credential. Obtain the pinned official Flutter 3.47.8 / Dart 3.13.7 distribution
and Node v24.22.3. `mail-runtime/archive-receipt.json` records the official Flutter
URL and verified SHA-256; `package-restoration.json` records 204 verified locked
package archives. Prepare the checkout dependencies with `pub get --offline
--enforce-lockfile` after restoring that cache, preserving the recorded lock.
Native tests additionally require the package-hook-generated SQLite asset map;
`repository-runtime/native_assets.yaml` is the original mapping, with its source
and binary digest recorded in `runtime.json`. Regenerate local absolute paths
through the package hooks when relocating, rather than reusing stale paths.

Use a checkout matching `qualification/accepted-source-sha256.json`. The manifest
and runtime provenance are evidence, not a self-contained offline toolchain.
To plan a replay without executing tests:

```sh
python3 replay/replay_mail_evidence.py --repo /path/to/checkout --runtime /path/to/prepared-mail-runtime --output /path/to/new-replay
```

Add `--run` to execute all six cohorts, or `--cohort integrated-host` (and any of
the other named cohorts shown by `--help`) for a selected cohort. The new output
directory must not exist and must be outside this extracted evidence directory.
Tracked source and lock hashes are required to match. The generated package
configuration is permitted to have relocated absolute paths, and its actual
before/after hash is recorded. The adapter invokes the prepared SDK directly;
original wrappers remain archived without changes. It captures new raw logs,
before/after sources and runtime inputs, exact argv/cwd, exit status and strict
test summaries. The host adapter separates only the six exact Flutter daemon
start-process frames before parsing package:test events.

The original native core/store, final Node, native transport and final integrated
host runners are also retained in their original locations. Their hardcoded
workspace paths can be studied without editing the accepted records. Run the
original 46-file formatter and strict analysis commands listed in
`mail-runtime/logs/mail-static-final/receipt.json` from the relocated checkout
when reproducing those separate checks. Earlier host analysis is retained with
its original post-run source-binding limitation; it adds no accepted test count.

To check the distributed archive and every member against the adjacent manifest:

```sh
python3 replay/verify_mail_evidence.py --artifacts /path/to/validation-directory
```

The totals count successful substantive executions, including platform overlap.
Loading/hidden lifecycle records do not add passes. Distinct core parameter
cases can share a display label; duplicate event IDs or completions are rejected
by the strict parser. Diagnostic and repeated runs add no accepted executions.
Archive member timestamps are normalized to zero; no filesystem modification
time or original record timestamp is used to infer source applicability.
