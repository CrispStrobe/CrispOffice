#!/usr/bin/env python3
"""Verify the distributed Mail evidence archive, acceptance and member manifest."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifacts', type=Path, required=True,
                        help='Directory containing mail-acceptance.json, mail-evidence.tar.gz and mail-evidence-manifest.json.')
    parser.add_argument('--repo', type=Path,
                        help='Optionally check recorded tracked source/config/fixture hashes against this checkout; generated package configuration is reported separately.')
    args = parser.parse_args()
    root = args.artifacts.resolve()
    manifest = json.loads((root / 'mail-evidence-manifest.json').read_text())
    acceptance_path = root / manifest['acceptance']['path']
    assert digest(acceptance_path.read_bytes()) == manifest['acceptance']['sha256'], 'Acceptance digest mismatch'
    acceptance = json.loads(acceptance_path.read_text())
    archive_path = root / manifest['archive']['path']
    assert archive_path.stat().st_size == manifest['archive']['bytes'], 'Archive size mismatch'
    assert digest(archive_path.read_bytes()) == manifest['archive']['sha256'], 'Archive digest mismatch'
    assert acceptance['evidence_archive'] == manifest['archive'], 'Acceptance/archive binding mismatch'
    expected = {entry['path']: entry for entry in manifest['members']}
    assert len(expected) == len(manifest['members']), 'Duplicate manifest member'
    source_mismatches, generated = [], []
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(expected), 'Archive member count mismatch'
        assert sorted(member.name for member in members) == sorted(expected), 'Archive member set mismatch'
        for member in members:
            path = Path(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts, 'Unsafe archive member'
            data = archive.extractfile(member).read()
            assert len(data) == expected[member.name]['bytes'], member.name
            assert digest(data) == expected[member.name]['sha256'], member.name
        if args.repo:
            sources = json.loads(archive.extractfile('qualification/accepted-source-sha256.json').read())
            for name, expected_digest in sources.items():
                local = args.repo.resolve() / name
                actual = digest(local.read_bytes()) if local.is_file() else None
                if name.startswith('.dart_tool/'):
                    generated.append(dict(path=name, expected=expected_digest, actual=actual,
                                          matches_original=actual == expected_digest))
                elif actual != expected_digest:
                    source_mismatches.append(dict(path=name, expected=expected_digest, actual=actual))
    result = dict(status='PASS' if not source_mismatches else 'SOURCE_DIFFERENCES',
                  archive_sha256=manifest['archive']['sha256'], archive_members=len(expected),
                  accepted_executions=acceptance['accepted_executions'],
                  current_source_mismatches=source_mismatches, generated_local_inputs=generated)
    print(json.dumps(result, indent=2))
    return 0 if not source_mismatches else 1


if __name__ == '__main__':
    raise SystemExit(main())
