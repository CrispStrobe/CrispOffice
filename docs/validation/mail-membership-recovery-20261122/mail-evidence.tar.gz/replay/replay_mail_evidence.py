#!/usr/bin/env python3
"""Plan or replay the six accepted Mail cohorts against an explicit checkout.

Original runners and receipts remain unchanged in the evidence archive. This
adapter relocates their argv, keeps outputs outside the original evidence, and
uses the archived strict package:test parser. It does not restore dependencies.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ORIGINAL_REPO = '/workspace/scratch/be9367db5e45/quds_office_suite'
ORIGINAL_RUNTIME = '/workspace/scratch/be9367db5e45/mail-runtime'
COHORTS = {
    'native-core-store': ('logs/membership/native-core-store-receipt.json', 1635),
    'native-providers': ('logs/membership-transport-native-final/receipt.json', 338),
    'integrated-host': ('logs/membership-host-publication-final/receipt.json', 277),
    'node-core': ('logs/membership-node-core-final/receipt.json', 574),
    'node-transport': ('logs/membership-node-transport-final/receipt.json', 160),
    'node-portable-store': ('logs/membership-node-portable-store-final/receipt.json', 52),
}
FRAME = [{'event': 'test.startedProcess', 'params': {'vmServiceUri': None}}]


def digest(path: Path) -> str | None:
    if not path.is_file():
        return None
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence-root', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True,
                        help='Prepared runtime containing flutter/ and pub-cache/.')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cohort', choices=['all', *COHORTS], default='all')
    parser.add_argument('--run', action='store_true',
                        help='Execute; default is a read-only command/input plan.')
    args = parser.parse_args()
    evidence, repo, runtime, output = (p.resolve() for p in (
        args.evidence_root, args.repo, args.runtime, args.output))
    if output == evidence or evidence in output.parents:
        parser.error('Replay output must be outside the original evidence directory.')
    sys.path.insert(0, str(evidence / 'repo-tools/mail'))
    from check_store import execute, test_summary

    def relocate(value: str) -> str:
        return value.replace(ORIGINAL_REPO, str(repo)).replace(ORIGINAL_RUNTIME, str(runtime))

    selected = list(COHORTS) if args.cohort == 'all' else [args.cohort]
    plans = []
    for name in selected:
        relative, expected = COHORTS[name]
        receipt_path = evidence / 'mail-runtime' / relative
        original = json.loads(receipt_path.read_text())
        command = [relocate(value) for value in original.get('argv', original.get('command'))]
        command[0] = str(runtime / 'flutter' / (
            'bin/flutter' if command[0].endswith('/bin/flutter') else 'bin/cache/dart-sdk/bin/dart'))
        command = [('--dart-define=MAIL_RECOVERY_SCREENSHOT_DIR=' + str(output / name / 'screenshots'))
                   if value.startswith('--dart-define=MAIL_RECOVERY_SCREENSHOT_DIR=') else value
                   for value in command]
        expected_sources = original.get('source_after')
        if expected_sources is None:
            expected_sources = json.loads((receipt_path.parent / 'accepted-inputs-after.json').read_text())
            supplemental = json.loads((receipt_path.parent / 'subprocess-fixture-inputs.json').read_text())
            expected_sources.update({path: record['sha256'] for path, record in supplemental.items()})
        # Package configuration contains absolute local paths. Record its new
        # hash on replay, while enforcing every tracked source and lock digest.
        generated = {path: digest(repo / path) for path in expected_sources if path.startswith('.dart_tool/')}
        mismatches = [{'path': path, 'expected': sha, 'actual': digest(repo / path)}
                      for path, sha in expected_sources.items()
                      if not path.startswith('.dart_tool/') and digest(repo / path) != sha]
        plans.append(dict(name=name, argv=command, cwd=relocate(original['cwd']),
                          expected_passed=expected, expected_sources=expected_sources,
                          source_mismatches=mismatches, relocated_generated_inputs=generated,
                          original_receipt=str(receipt_path), original_receipt_sha256=digest(receipt_path)))
    if not args.run:
        print(json.dumps(plans, indent=2))
        return 1 if any(plan['source_mismatches'] for plan in plans) else 0
    if any(plan['source_mismatches'] for plan in plans):
        print(json.dumps(plans, indent=2))
        return 1
    output.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ)
    env.update(PUB_CACHE=str(runtime / 'pub-cache'), FLUTTER_ROOT=str(runtime / 'flutter'),
               CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true',
               DASH__SUPPRESS_ANALYTICS='true')
    for key, child in [('TMPDIR', 'tmp'), ('XDG_CONFIG_HOME', 'config'),
                       ('XDG_CACHE_HOME', 'cache'), ('XDG_DATA_HOME', 'data')]:
        location = output / 'environment' / child
        location.mkdir(parents=True, exist_ok=True)
        env[key] = str(location)
    env['PATH'] = os.pathsep.join([str(runtime / 'flutter/bin/cache/dart-sdk/bin'),
                                 str(runtime / 'flutter/bin'), env.get('PATH', '')])
    framework = json.loads(subprocess.check_output(
        [str(runtime / 'flutter/bin/flutter'), '--version', '--machine'], env=env, text=True))
    node = subprocess.check_output(['node', '--version'], env=env, text=True).strip()
    if framework.get('frameworkVersion') != '3.47.8' or framework.get('dartSdkVersion') != '3.13.7' or node != 'v24.22.3':
        raise RuntimeError('Replay requires Flutter 3.47.8, Dart 3.13.7 and Node v24.22.3.')
    all_ok = True
    for plan in plans:
        folder = output / plan['name']
        folder.mkdir()
        sources = [repo / path for path in plan['expected_sources']]
        runtime_paths = [Path(__file__), evidence / 'repo-tools/mail/check_store.py',
                         evidence / 'repo-tools/mail/check_reader.py', repo / '.dart_tool/package_config.json',
                         repo / '.dart_tool/native_assets.yaml', runtime / 'flutter/bin/flutter',
                         runtime / 'flutter/bin/cache/flutter_tools.snapshot',
                         runtime / 'flutter/bin/cache/dart-sdk/bin/dart',
                         runtime / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart']
        snapshot = lambda paths: {str(path): digest(path) for path in paths}
        record = dict(plan, status='RUNNING', framework=framework, node_version=node,
                      started_at_utc=datetime.now(timezone.utc).isoformat(),
                      source_before=snapshot(sources), runtime_before=snapshot(runtime_paths),
                      github_actions='NOT USED')
        receipt = folder / 'receipt.json'
        receipt.write_text(json.dumps(record, indent=2) + '\n')
        try:
            with (folder / 'test.jsonl').open('wb') as stream, (folder / 'test.stderr').open('wb') as err:
                record['exit_code'] = execute(plan['argv'], cwd=Path(plan['cwd']), env=env,
                                               stdout=stream, stderr=err, timeout=900)
            raw = (folder / 'test.jsonl').read_text()
            parsed_log = folder / 'test.jsonl'
            if plan['name'] == 'integrated-host':
                lines, notifications = [], []
                for number, line in enumerate(raw.split('\n'), 1):
                    try:
                        event = json.loads(line)
                    except ValueError:
                        event = None
                    if event == FRAME:
                        notifications.append({'line': number, 'frame': event})
                    else:
                        lines.append(line)
                parsed_log = folder / 'test-events.jsonl'
                parsed_log.write_text('\n'.join(lines))
                record['flutter_daemon_notifications'] = notifications
                if len(notifications) != 6:
                    raise RuntimeError('Expected exactly six Flutter start-process notifications.')
            summary = test_summary(parsed_log)
            (folder / 'cases.json').write_text(json.dumps(summary, indent=2) + '\n')
            record['tests'] = {key: value for key, value in summary.items() if key != 'cases'}
            record['status'] = 'PASS' if (record['exit_code'] == 0 and summary['valid']
                                         and summary['passed'] == plan['expected_passed']) else 'FAIL'
        except BaseException as error:
            record['status'], record['error'] = 'ERROR', repr(error)
            if isinstance(error, (KeyboardInterrupt, SystemExit)):
                raise
        finally:
            record['source_after'] = snapshot(sources)
            record['runtime_after'] = snapshot(runtime_paths)
            record['source_unchanged'] = record['source_before'] == record['source_after']
            record['runtime_unchanged'] = record['runtime_before'] == record['runtime_after']
            if not record['source_unchanged'] or not record['runtime_unchanged']:
                record['status'] = 'INPUT_CHANGED'
            record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
            record['artifacts'] = {p.name: digest(p) for p in folder.iterdir() if p.is_file() and p != receipt}
            receipt.write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps({'cohort': plan['name'], 'status': record['status'], 'receipt': str(receipt)}), flush=True)
        all_ok &= record['status'] == 'PASS'
    return 0 if all_ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
