# Post-main Mail qualification supplement

Keep this supplement next to the original mail-acceptance.json, mail-evidence.tar.gz
and mail-evidence-manifest.json. Those three original artifacts are immutable.
The composite count is 3036 executions: unchanged original native/Node cohorts
plus this supplement's 277 host executions. The old host count is replaced.

The original pinned toolchain, restore provenance, strict parser and portable
replay helpers remain in the base archive. New exact host and two-helper static
runner scripts are in mail-runtime/logs/membership-host-post-main-final/.
Their receipt argv/cwd and original workspace paths are recorded explicitly.
For a relocated checkout, use those argv with the new runtime/checkout paths,
or adapt a copy of the base replay helper to this supplement's host receipt.
Never overwrite the historical receipts. The current source union is supplied
as qualification/composite-source-sha256.json; all tracked inputs must match.

No PNG is duplicated here. image-references.json binds all twelve new captures
to byte-identical original PNG members in mail-evidence.tar.gz; the comparison
receipt and original comparison script record decoded RGBA equality as well.

Verify both packages and every supplement member with:

    python3 replay/verify_publication_supplement.py --artifacts /path/to/validation-directory --repo /path/to/checkout

The two helper changes remove four redundant non-null assertions. No Mail,
engine or editor production input changed relative to the prior host snapshot.
The original 46-file formatter remains applicable to 44 unchanged inputs;
both changed helpers have fresh nonmutating format and strict analyzer records.
The original records' timestamps are not used to infer current applicability.
