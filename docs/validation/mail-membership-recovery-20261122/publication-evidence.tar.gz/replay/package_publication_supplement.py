#!/usr/bin/env python3
"""Package post-main Mail qualification while preserving the original archive."""
from __future__ import annotations

import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

BASE = Path('/workspace/scratch/be9367db5e45')
REPO = BASE / 'quds_office_suite'
RUNTIME = BASE / 'mail-runtime'
RUN = RUNTIME / 'logs/membership-host-post-main-final'
OUT = REPO / 'docs/validation/mail-membership-recovery-20261122'
sys.path.insert(0, str(REPO / 'tools/mail'))
from check_store import test_summary


def encode(data):
    return (json.dumps(data, indent=2, sort_keys=True) + '\n').encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(path.read_bytes()) if path.is_file() else None


def current_audit(mapping, *, absolute=False):
    differences = []
    for name, expected in mapping.items():
        if isinstance(expected, dict):
            expected = expected['sha256']
        actual = digest(Path(name) if absolute else REPO / name)
        if actual != expected:
            differences.append(dict(path=name, expected=expected, actual=actual))
    return differences


def main():
    base_bindings = json.loads((RUN / 'base-artifact-integrity-before.json').read_text())
    for name, record in base_bindings.items():
        assert digest(OUT / name) == record['sha256'], name
        assert (OUT / name).stat().st_size == record['bytes'], name
    original = json.loads((OUT / 'mail-acceptance.json').read_text())
    assert original['accepted_executions'] == 3036
    with tarfile.open(OUT / 'mail-evidence.tar.gz', 'r:gz') as base_archive:
        def read_base(name):
            return json.loads(base_archive.extractfile(name).read())
        old_sources = read_base('qualification/accepted-source-sha256.json')
        old_runtime = read_base('qualification/accepted-runtime-sha256.json')
        base_manifest = json.loads((OUT / 'mail-evidence-manifest.json').read_text())
        base_member_sha = {item['path']: item['sha256'] for item in base_manifest['members']}
        reuse_audits, reused = [], []
        for cohort in original['cohorts']:
            if cohort['name'] == 'integrated-host':
                continue
            receipt = read_base(cohort['receipt'])
            mappings = []
            if cohort['name'] == 'native-core-store':
                for filename in ['accepted-inputs-before.json', 'accepted-inputs-after.json', 'subprocess-fixture-inputs.json']:
                    mappings.append((filename, read_base('mail-runtime/logs/membership/' + filename), False))
            else:
                for key in ['source_before', 'source_after', 'runtime_before', 'runtime_after']:
                    mappings.append((key, receipt[key], key.startswith('runtime')))
            for key, values, absolute in mappings:
                mismatches = current_audit(values, absolute=absolute)
                assert not mismatches, (cohort['name'], key, mismatches)
                reuse_audits.append(dict(cohort=cohort['name'], field=key, paths=len(values), mismatches=mismatches))
            reused.append(dict(name=cohort['name'], passed=cohort['passed'],
                               original_archive='mail-evidence.tar.gz', receipt=cohort['receipt'],
                               receipt_sha256=cohort['receipt_sha256'], current_applicability='PASS'))

        host = json.loads((RUN / 'receipt.json').read_text())
        static = json.loads((RUN / 'static/receipt.json').read_text())
        assert host['status'] == static['status'] == 'PASS'
        assert host['unique_passed'] == 277 and host['duplicate_case_count'] == 0
        assert host['exit_code'] == 0 and host['source_unchanged'] and host['runtime_unchanged']
        assert static['source_unchanged'] and static['runtime_unchanged']
        assert all(check['exit_code'] == 0 for check in static['checks'])
        assert '2 files (0 changed)' in (RUN / 'static/format.txt').read_text()
        assert 'No issues found' in (RUN / 'static/analysis.txt').read_text()
        summary = test_summary(RUN / 'test-events.jsonl')
        assert summary['valid'] and summary['passed'] == 277
        allowed = [{'event': 'test.startedProcess', 'params': {'vmServiceUri': None}}]
        lines, frames = [], []
        for number, line in enumerate((RUN / 'test.jsonl').read_text().split('\n'), 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except ValueError:
                value = None
            if value == allowed:
                frames.append(dict(line=number, frame=value))
            else:
                lines.append(line)
        assert len(frames) == 6 and frames == host['flutter_daemon_notifications']
        assert '\n'.join(lines) + '\n' == (RUN / 'test-events.jsonl').read_text()
        for key in ['test.jsonl', 'test-events.jsonl', 'test.stderr', 'cases.json']:
            assert digest(Path(host[key]['path'])) == host[key]['sha256'], key

        expected_changes = {
            'packages/quds_office_editor/example/test/support/mail_membership_host_cases.dart',
            'packages/quds_office_editor/example/test/support/mail_membership_recovery_cases.dart',
        }
        base_differences = current_audit(old_sources)
        assert {item['path'] for item in base_differences} == expected_changes
        composite_sources = dict(old_sources)
        composite_sources.update(host['source_after'])
        composite_sources.update(static['source_after'])
        assert not current_audit(composite_sources)
        assert not current_audit(old_runtime, absolute=True)
        composite_runtime = dict(old_runtime)
        composite_runtime.update(host['runtime_after'])
        composite_runtime.update(static['runtime_after'])
        assert not current_audit(composite_runtime, absolute=True)
        for record in [host, static]:
            for key in ['source_before', 'source_after']:
                assert not current_audit(record[key]), key
            for key in ['runtime_before', 'runtime_after']:
                assert not current_audit(record[key], absolute=True), key
        old_static = read_base('mail-runtime/logs/mail-static-final/receipt.json')
        old_static_differences = current_audit(old_static['after'])
        assert {item['path'] for item in old_static_differences} == expected_changes
        assert len(old_static['after']) == 46

        comparison = json.loads((RUN / 'screenshot-comparison.json').read_text())
        assert comparison['status'] == 'PASS' and len(comparison['images']) == 12
        assert not comparison['only_before'] and not comparison['only_after']
        assert comparison['accepted_invocation_sha256'] == digest(RUN / 'receipt.json')
        images = []
        for item in comparison['images']:
            assert item['pixels_identical'] and item['changed_pixels'] == 0
            assert item['before_sha256'] == item['after_sha256']
            assert digest(Path(item['after_path'])) == item['after_sha256']
            archived_path = str(Path(item['before_path']).relative_to(BASE))
            assert base_member_sha[archived_path] == item['after_sha256']
            assert sha(base_archive.extractfile(archived_path).read()) == item['after_sha256']
            images.append(dict(name=item['name'], sha256=item['after_sha256'],
                               original_archive='mail-evidence.tar.gz', original_member=archived_path,
                               captured_post_main_path=item['after_path'], pixels=item['after_shape'][:2],
                               byte_identical=True, decoded_rgba_identical=True))
    lock = REPO / 'pubspec.lock'
    assert digest(lock) == original['lock']['sha256']
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--', 'pubspec.lock'], cwd=REPO, text=True)

    audit = dict(status='PASS', reused_cohort_maps=reuse_audits,
                 prior_combined_source_differences=base_differences,
                 changed_inputs_are_test_support_only=True,
                 composite_source_inputs=len(composite_sources), current_composite_source_mismatches=[],
                 current_composite_runtime_inputs=len(composite_runtime), current_composite_runtime_mismatches=[],
                 original_format_inputs=46, unchanged_original_format_inputs=44,
                 refreshed_helper_format_inputs=2, original_static_differences=old_static_differences,
                 method='SHA-256 content comparisons. Original records stay historical and unchanged; no timestamp chronology is used.')
    (RUN / 'composite-input-audit.json').write_bytes(encode(audit))
    (RUN / 'image-references.json').write_bytes(encode(images))
    (RUN / 'base-artifact-integrity-after.json').write_bytes(encode(base_bindings))

    members = {}
    for path in sorted(RUN.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.png':
            members[str(path.relative_to(BASE))] = path.read_bytes()
    members['qualification/composite-source-sha256.json'] = encode(composite_sources)
    members['qualification/composite-runtime-sha256.json'] = encode(composite_runtime)
    members['qualification/strict-host-reparse.json'] = encode({key: value for key, value in summary.items() if key != 'cases'})
    members['replay/package_publication_supplement.py'] = Path(__file__).read_bytes()
    members['replay/verify_publication_supplement.py'] = (RUNTIME / 'verify_publication_supplement.py').read_bytes()
    members['replay/POST_MAIN_REPLAY.md'] = b'''# Post-main Mail qualification supplement

Keep this supplement next to the original mail-acceptance.json, mail-evidence.tar.gz
and mail-evidence-manifest.json. Those three original artifacts are immutable.
The composite count is 3036 executions: unchanged original native/Node cohorts
plus this supplement's 277 host executions. The old host count is replaced.

The original pinned toolchain, restore provenance, strict parser and portable
replay helpers remain in the base archive. New exact host and two-helper static
runner scripts are in mail-runtime/logs/membership-host-post-main-final/.
Their receipt argv/cwd and original workspace paths are recorded explicitly.
For a relocated checkout, use those argv with the new runtime/checkout paths,
or adapt a copy of the base replay helper to this supplement's host receipt.
Never overwrite the historical receipts. The current source union is supplied
as qualification/composite-source-sha256.json; all tracked inputs must match.

No PNG is duplicated here. image-references.json binds all twelve new captures
to byte-identical original PNG members in mail-evidence.tar.gz; the comparison
receipt and original comparison script record decoded RGBA equality as well.

Verify both packages and every supplement member with:

    python3 replay/verify_publication_supplement.py --artifacts /path/to/validation-directory --repo /path/to/checkout

The two helper changes remove four redundant non-null assertions. No Mail,
engine or editor production input changed relative to the prior host snapshot.
The original 46-file formatter remains applicable to 44 unchanged inputs;
both changed helpers have fresh nonmutating format and strict analyzer records.
The original records' timestamps are not used to infer current applicability.
'''
    assert not any(name.endswith('.png') for name in members)
    archive_path = OUT / 'publication-evidence.tar.gz'
    entries = [dict(path=name, bytes=len(data), sha256=sha(data)) for name, data in sorted(members.items())]
    with archive_path.open('wb') as stream:
        with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for item in entries:
                    info = tarfile.TarInfo(item['path'])
                    info.size, info.mtime = item['bytes'], 0
                    info.mode = 0o755 if item['path'].endswith('.py') else 0o644
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    archive.addfile(info, io.BytesIO(members[item['path']]))
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert sorted(archive.getnames()) == sorted(members)
        for item in entries:
            assert sha(archive.extractfile(item['path']).read()) == item['sha256']
    for name, record in base_bindings.items():
        assert digest(OUT / name) == record['sha256'], name
    assert not current_audit(composite_sources)
    assert not current_audit(composite_runtime, absolute=True)

    host_prefix = 'mail-runtime/logs/membership-host-post-main-final/'
    acceptance = dict(
        schema_version=1, status='PASS', scope='Composite Mail acceptance after reconciling remote main 253c7d28',
        checkout_commit_at_packaging=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
        accepted_executions=3036, reused_executions=sum(item['passed'] for item in reused),
        replacement_host_executions=277, previous_host_executions_replaced=277,
        counting='Successful substantive executions with platform overlap, not globally unique test names. Loading/hidden events, prior host repetitions and diagnostic runs do not add passes. Original distinct core parameter label collisions remain documented in mail-acceptance.json.',
        reused_cohorts=reused,
        post_main_host=dict(receipt=host_prefix + 'receipt.json', receipt_sha256=digest(RUN / 'receipt.json'),
                            tests={key: value for key, value in summary.items() if key != 'cases'},
                            exit_code=0, unique_passed=277, source_inputs=len(host['source_after']),
                            runtime_inputs=len(host['runtime_after']), source_unchanged=True, runtime_unchanged=True,
                            flutter_daemon_frames_separated=6, original_raw_log_preserved=True),
        source_applicability=dict(status='PASS', composite_source_inputs=len(composite_sources),
                                  current_mismatches=0, prior_changed_inputs=sorted(expected_changes),
                                  change='Four redundant non-null assertions removed from two Mail test-support parts.',
                                  production_changes=[], source_union='qualification/composite-source-sha256.json',
                                  source_union_sha256=sha(encode(composite_sources)), audit=host_prefix + 'composite-input-audit.json',
                                  delta=host_prefix + 'source-delta.json'),
        runtime_applicability=dict(status='PASS', composite_runtime_inputs=len(composite_runtime), current_mismatches=0,
                                   flutter='3.47.8', dart='3.13.7', node='v24.22.3', lock_sha256=digest(lock),
                                   original_lock_unchanged=True, original_runtime_provenance_preserved=True),
        static_checks=dict(status='PASS', original_46_file_format_unchanged_inputs=44,
                           newly_formatted_helpers=2, helper_format_changes=0, helper_strict_analysis='No issues found',
                           receipt=host_prefix + 'static/receipt.json', receipt_sha256=digest(RUN / 'static/receipt.json'),
                           original_core_store_transport_analysis_applicability='Unchanged sources; original clean analysis retained.'),
        screenshots=dict(status='PASS', new_captures=12, byte_identical_to_original_archive=12,
                         decoded_rgba_identical=12, embedded_pngs=0,
                         references=host_prefix + 'image-references.json', comparison=host_prefix + 'screenshot-comparison.json',
                         visual_review='The new captures are byte- and pixel-identical to the previously inspected archived English/German/Arabic and other fixture captures. No new direct visual-inspection claim is required.'),
        zotero_scope_note=dict(record=host_prefix + 'zotero-scope-note.json',
                               note='Broad historical Studio snapshots can include unused Mail-only support fixtures. The checked local final Zotero Studio receipt excludes both changed helpers and has zero current source mismatches; no Zotero production or invoked Zotero test changed during main reconciliation. Zotero counts/logs remain outside Mail acceptance.'),
        original_artifacts=base_bindings,
        original_artifact_policy='All three original files remain byte-identical historical records. This supplement replaces only the accepted host cohort and the static coverage for the two changed helpers.',
        boundaries=original['boundaries'], github_actions='NOT USED OR AWAITED',
        evidence_archive=dict(path='publication-evidence.tar.gz', bytes=archive_path.stat().st_size,
                              sha256=digest(archive_path), members=len(entries), manifest='publication-evidence-manifest.json'),
    )
    assert acceptance['reused_executions'] + acceptance['replacement_host_executions'] == 3036
    acceptance_path = OUT / 'publication-acceptance.json'
    acceptance_path.write_bytes(encode(acceptance))
    manifest = dict(schema_version=1, archive=acceptance['evidence_archive'],
                    acceptance=dict(path='publication-acceptance.json', bytes=acceptance_path.stat().st_size, sha256=digest(acceptance_path)),
                    original_artifacts=base_bindings, members=entries, embedded_pngs=0,
                    uncompressed_member_bytes=sum(item['bytes'] for item in entries),
                    format='gzip POSIX pax tar; regular files only; deterministic order; normalized owner and zero timestamps',
                    verification='Every member read back and SHA-256 checked; original artifacts and current composite inputs rechecked before acceptance.')
    manifest_path = OUT / 'publication-evidence-manifest.json'
    manifest_path.write_bytes(encode(manifest))
    print(json.dumps(dict(status='PASS', accepted_executions=3036, reused_executions=acceptance['reused_executions'],
                          source_inputs=len(composite_sources), runtime_inputs=len(composite_runtime),
                          base_artifacts_unchanged=True, embedded_pngs=0,
                          files=[dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path))
                                 for path in [acceptance_path, archive_path, manifest_path]]), indent=2))


if __name__ == '__main__':
    main()
