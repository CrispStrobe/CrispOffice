#!/usr/bin/env python3
"""Verify immutable base bindings and every Mail publication supplement member."""
from pathlib import Path
import argparse
import hashlib
import json
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifacts', type=Path, required=True)
    parser.add_argument('--repo', type=Path)
    args = parser.parse_args()
    root = args.artifacts.resolve()
    manifest = json.loads((root / 'publication-evidence-manifest.json').read_text())
    for name, record in manifest['original_artifacts'].items():
        path = root / name
        assert path.stat().st_size == record['bytes'] and sha(path.read_bytes()) == record['sha256'], name
    acceptance_path = root / manifest['acceptance']['path']
    assert sha(acceptance_path.read_bytes()) == manifest['acceptance']['sha256']
    acceptance = json.loads(acceptance_path.read_text())
    archive_path = root / manifest['archive']['path']
    assert archive_path.stat().st_size == manifest['archive']['bytes']
    assert sha(archive_path.read_bytes()) == manifest['archive']['sha256']
    assert acceptance['evidence_archive'] == manifest['archive']
    expected = {entry['path']: entry for entry in manifest['members']}
    assert len(expected) == len(manifest['members'])
    mismatches = []
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert sorted(archive.getnames()) == sorted(expected)
        for member in archive.getmembers():
            path = Path(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert path.suffix != '.png'
            data = archive.extractfile(member).read()
            assert len(data) == expected[member.name]['bytes']
            assert sha(data) == expected[member.name]['sha256'], member.name
        if args.repo:
            sources = json.loads(archive.extractfile('qualification/composite-source-sha256.json').read())
            for name, wanted in sources.items():
                path = args.repo.resolve() / name
                actual = sha(path.read_bytes()) if path.is_file() else None
                if actual != wanted:
                    mismatches.append(dict(path=name, expected=wanted, actual=actual))
        references = json.loads(archive.extractfile('mail-runtime/logs/membership-host-post-main-final/image-references.json').read())
        with tarfile.open(root / 'mail-evidence.tar.gz', 'r:gz') as original:
            for image in references:
                assert sha(original.extractfile(image['original_member']).read()) == image['sha256']
    print(json.dumps(dict(status='PASS' if not mismatches else 'SOURCE_DIFFERENCES',
                          accepted_executions=acceptance['accepted_executions'],
                          original_artifacts_unchanged=True, archive_members=len(expected),
                          embedded_pngs=0, image_references_verified=len(references),
                          current_source_mismatches=mismatches), indent=2))
    return 0 if not mismatches else 1


if __name__ == '__main__':
    raise SystemExit(main())
