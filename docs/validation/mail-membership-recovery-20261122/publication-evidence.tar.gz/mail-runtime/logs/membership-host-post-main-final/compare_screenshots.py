from pathlib import Path
import json,hashlib,datetime
import numpy as np
from PIL import Image
root=Path('/workspace/scratch/be9367db5e45/mail-runtime')
old=root/'screenshots/membership-bound-publication-final'
new=root/'screenshots/membership-bound-post-main-final'
out=Path(__file__).resolve().parent
receipt_path=out/'receipt.json'
receipt=json.loads(receipt_path.read_text())
assert receipt['status']=='PASS', 'Compare only completed accepted integrated output'
old_files={p.name:p for p in old.glob('*.png')};new_files={p.name:p for p in new.glob('*.png')}
results=[]
for name in sorted(old_files.keys()&new_files.keys()):
 before,after=old_files[name],new_files[name]
 with Image.open(before) as im:a=np.asarray(im.convert('RGBA'))
 with Image.open(after) as im:b=np.asarray(im.convert('RGBA'))
 equal=a.shape==b.shape
 changed=None if not equal else int(np.count_nonzero(np.any(a!=b,axis=-1)))
 results.append({'name':name,'before_path':str(before),'after_path':str(after),'before_sha256':hashlib.sha256(before.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(after.read_bytes()).hexdigest(),'before_shape':list(a.shape),'after_shape':list(b.shape),'changed_pixels':changed,'pixels_identical':equal and changed==0})
record={'compared_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if old_files.keys()==new_files.keys() and all(r['pixels_identical'] for r in results) else 'DIFFERENCES','scope':'Exact decoded RGBA comparison of prior accepted and postintegration bound host PNGs. Direct representative visual inspection is recorded separately.','accepted_invocation':str(receipt_path),'accepted_invocation_sha256':hashlib.sha256(receipt_path.read_bytes()).hexdigest(),'only_before':sorted(old_files.keys()-new_files.keys()),'only_after':sorted(new_files.keys()-old_files.keys()),'images':results}
(out/'screenshot-comparison.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
