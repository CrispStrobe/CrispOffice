#!/usr/bin/env python3
"""Nonmutating format and strict analysis for the two reconciled Mail helpers."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys

repo = Path('/workspace/scratch/be9367db5e45/quds_office_suite')
runtime = repo.parent / 'mail-runtime'
out = Path(__file__).resolve().parent / 'static'
out.mkdir(exist_ok=True)
cwd = repo / 'packages/quds_office_editor/example'
files = ['test/support/mail_membership_host_cases.dart', 'test/support/mail_membership_recovery_cases.dart']
sys.path.insert(0, str(repo / 'tools/mail'))
from check_store import execute


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sources():
    paths = [cwd / name for name in files]
    paths += [repo / name for name in ['analysis_options.yaml', 'pubspec.yaml', 'pubspec.lock', '.fvmrc']]
    paths += [cwd / name for name in ['analysis_options.yaml', 'pubspec.yaml'] if (cwd / name).is_file()]
    return {str(path.relative_to(repo)): digest(path) for path in paths}


runtime_paths = [Path(__file__), runtime / 'env.sh', runtime / 'bin/dart',
                 runtime / 'flutter/bin/cache/dart-sdk/bin/dart',
                 repo / '.dart_tool/package_config.json', repo / 'tools/mail/check_store.py',
                 repo / 'tools/mail/check_reader.py']
runtime_hashes = lambda: {str(path): digest(path) for path in runtime_paths}
record = dict(status='RUNNING', started_at_utc=datetime.now(timezone.utc).isoformat(),
              source_before=sources(), runtime_before=runtime_hashes(), checks=[],
              scope='Only the two Mail test-support helpers changed by current-main reconciliation.',
              github_actions='NOT USED')
receipt = out / 'receipt.json'
receipt.write_text(json.dumps(record, indent=2) + '\n')
try:
    for name, args in [
        ('format', ['format', '--output=none', '--set-exit-if-changed', *files]),
        ('analysis', ['analyze', '--fatal-infos', *files]),
    ]:
        argv = [str(runtime / 'bin/dart'), *args]
        with (out / (name + '.txt')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
            code = execute(argv, cwd=cwd, env=dict(os.environ), stdout=stdout, stderr=stderr, timeout=300)
        record['checks'].append(dict(name=name, argv=argv, cwd=str(cwd), exit_code=code,
                                     stdout=name + '.txt', stdout_sha256=digest(out / (name + '.txt')),
                                     stderr=name + '.stderr', stderr_sha256=digest(out / (name + '.stderr'))))
    record['status'] = 'PASS' if all(check['exit_code'] == 0 for check in record['checks']) else 'FAIL'
except BaseException as error:
    record['status'], record['error'] = 'ERROR', repr(error)
finally:
    record['source_after'] = sources()
    record['runtime_after'] = runtime_hashes()
    record['source_unchanged'] = record['source_before'] == record['source_after']
    record['runtime_unchanged'] = record['runtime_before'] == record['runtime_after']
    if not record['source_unchanged'] or not record['runtime_unchanged']:
        record['status'] = 'INPUT_CHANGED'
    record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    receipt.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items()
                  if key not in ['source_before', 'source_after', 'runtime_before', 'runtime_after']}, indent=2))
raise SystemExit(0 if record['status'] == 'PASS' else 1)
