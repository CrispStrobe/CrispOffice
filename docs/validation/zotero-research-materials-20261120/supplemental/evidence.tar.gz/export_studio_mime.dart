// Supplemental export for independent receiver inspection.
// Imports the actual Studio MIME builder from the frozen workspace.
// Synthetic reserved addresses only; this program never sends or opens sockets.
import 'dart:convert';
import 'dart:io';

import 'package:quds_office_studio/studio_mail_draft.dart';
import 'package:quds_office_studio/studio_mail_submission.dart';

void main(List<String> arguments) {
  if (arguments.length != 3) {
    throw ArgumentError('Usage: input.json output.eml envelope.json');
  }
  final input =
      jsonDecode(File(arguments[0]).readAsStringSync()) as Map<String, Object?>;
  final draft = StudioMailDraft(
    to: input['to']! as String,
    cc: input['cc']! as String,
    bcc: input['bcc']! as String,
    subject: input['subject']! as String,
    body: input['body']! as String,
    attachments: StudioMailAttachments.from([
      StudioMailAttachment(
        name: input['attachmentName']! as String,
        mediaType: 'application/octet-stream',
        bytes: base64Decode(input['attachmentBase64']! as String),
      ),
    ]),
  );
  final message = buildStudioMailMessage(draft, input['from']! as String);
  final wire = ascii.encode(message.renderMessage());
  File(arguments[1]).writeAsBytesSync(wire);
  File(arguments[2]).writeAsStringSync(
    jsonEncode({
      'to': draft.recipients.to,
      'cc': draft.recipients.cc,
      'bcc': draft.recipients.bcc,
      'envelope': draft.recipients.envelope,
      'wireBytes': wire.length,
      'attachmentBytes': draft.attachments.totalBytes,
    }),
  );
  stdout.writeln('Exported synthetic MIME with the actual Studio builder.');
}

