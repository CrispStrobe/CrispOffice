#!/usr/bin/env python3
"""Qualify portable VBA receipts and inspect actual Studio MIME with Python.

All outputs are synthetic and local. Imports the frozen workspace normally
through its real root package configuration. No source/config mutation, package
resolution, network calls, mail submission, or Office-host claim.
"""
from __future__ import annotations
import argparse
import base64
from datetime import datetime, timezone
import email
from email import policy
from email.parser import BytesParser
from email.utils import getaddresses
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent

def utc():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n')

def load_validation_module():
    spec = importlib.util.spec_from_file_location('qualified_inputs', HERE / 'run_validation.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def parse_mime(out, fixture):
    raw = (out / 'studio-attachment.eml').read_bytes()
    envelope = json.loads((out / 'studio-envelope.json').read_text())
    message = BytesParser(policy=policy.default).parsebytes(raw)
    check_records = []
    def require(name, condition, details=None):
        check_records.append({'name': name, 'passed': bool(condition), 'details': details})
    defects = []
    for index, part in enumerate(message.walk()):
        defects.extend({'part': index, 'where': 'body', 'defect': repr(d)} for d in part.defects)
        for name, value in part.items():
            defects.extend({'part': index, 'where': name, 'defect': repr(d)} for d in getattr(value, 'defects', ()))
    require('No Python MIME/header parser defects', not defects, defects)
    require('Complete MIME wire is ASCII', all(byte < 128 for byte in raw))
    without_crlf = raw.replace(b'\r\n', b'')
    require('Wire uses CRLF without bare CR or LF', b'\r' not in without_crlf and b'\n' not in without_crlf)
    require('Root is multipart/mixed', message.get_content_type() == 'multipart/mixed')
    root_parts = list(message.iter_parts())
    require('Mixed root contains exactly body plus attachment', len(root_parts) == 2)
    require('Subject decodes to exact Unicode', str(message['Subject']) == fixture['subject'])
    require('Sender matches', getaddresses(message.get_all('From', [])) == [('', fixture['from'])])
    expected_to = [s.strip() for s in fixture['to'].split(',')]
    expected_cc = [s.strip() for s in fixture['cc'].split(',')]
    expected_bcc = [s.strip() for s in fixture['bcc'].split(',')]
    require('Visible To addresses are exact', [a for _, a in getaddresses(message.get_all('To', []))] == expected_to)
    require('Visible Cc addresses are exact', [a for _, a in getaddresses(message.get_all('Cc', []))] == expected_cc)
    require('No Bcc MIME header at any level', all(part.get('Bcc') is None for part in message.walk()))
    require('Private Bcc addresses never appear on MIME wire', all(a.encode('ascii') not in raw for a in expected_bcc))
    require('Explicit envelope retains To Cc and private Bcc', envelope['envelope'] == expected_to + expected_cc + expected_bcc)
    require('Envelope groups remain separate', envelope['to'] == expected_to and envelope['cc'] == expected_cc and envelope['bcc'] == expected_bcc)
    alternative = root_parts[0] if root_parts else None
    require('Body is multipart/alternative', alternative is not None and alternative.get_content_type() == 'multipart/alternative')
    text_parts = list(alternative.iter_parts()) if alternative is not None and alternative.is_multipart() else []
    require('Alternative contains plain then HTML', [p.get_content_type() for p in text_parts] == ['text/plain', 'text/html'])
    if len(text_parts) == 2:
        plain, html = text_parts
        expected_plain = fixture['body'].replace('\r\n', '\n').replace('\n', '\r\n')
        decoded_plain = plain.get_payload(decode=True).decode('utf-8')
        expected_html = '<p>' + fixture['body'].replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace('\r\n', '\n').replace('\r', '\n').replace('\n', '<br>') + '</p>'
        require('Plain text retains multibyte characters and terminal spaces/tabs', decoded_plain == expected_plain, {'expectedSha256': hashlib.sha256(expected_plain.encode()).hexdigest(), 'actualSha256': hashlib.sha256(decoded_plain.encode()).hexdigest()})
        require('HTML decodes with exact escaping and line breaks', html.get_payload(decode=True).decode('utf-8') == expected_html)
        for part in text_parts:
            encoded = part.get_payload()
            lines = encoded.splitlines()
            require(part.get_content_type() + ' uses quoted-printable', part['Content-Transfer-Encoding'].lower() == 'quoted-printable')
            require(part.get_content_type() + ' encoded lines stay within 76 columns', all(len(line) <= 76 for line in lines), {'maximumLineLength': max(map(len, lines), default=0)})
            require(part.get_content_type() + ' has no literal trailing transport padding', all(not line.endswith((' ', '\t')) for line in lines))
    attachment = root_parts[1] if len(root_parts) > 1 else None
    if attachment is not None:
        expected_bytes = base64.b64decode(fixture['attachmentBase64'])
        actual_bytes = attachment.get_payload(decode=True)
        require('Attachment disposition is attachment', attachment.get_content_disposition() == 'attachment')
        require('RFC 2231 Unicode quoted filename decodes exactly', attachment.get_filename() == fixture['attachmentName'], {'decodedFilename': attachment.get_filename()})
        require('Attachment media type is exact', attachment.get_content_type() == 'application/octet-stream')
        require('Attachment charset is not guessed', attachment.get_content_charset() is None)
        require('Binary attachment is byte-exact', actual_bytes == expected_bytes, {'length': len(actual_bytes), 'expectedSha256': hashlib.sha256(expected_bytes).hexdigest(), 'actualSha256': hashlib.sha256(actual_bytes).hexdigest()})
        require('Attachment transport is base64', attachment['Content-Transfer-Encoding'].lower() == 'base64')
        require('Binary encoded lines stay within 76 columns', all(len(line) <= 76 for line in attachment.get_payload().splitlines()))
    result = {
        'kind': 'independent Python standard-library receiver inspection of actual Studio builder output',
        'messageCount': 1,
        'fixture': 'Reserved example.invalid addresses, synthetic Unicode text and generated binary bytes.',
        'allChecksPassed': all(record['passed'] for record in check_records),
        'checkCount': len(check_records),
        'checks': check_records,
        'rawMimeSha256': hashlib.sha256(raw).hexdigest(),
        'envelopeSha256': sha(out / 'studio-envelope.json'),
        'noNetworkOrMailSubmission': True,
        'doesNotClaimExternalProviderOrInstalledAppAcceptance': True,
    }
    write_json(out / 'mime-inspection.json', result)
    if not result['allChecksPassed']:
        raise AssertionError('Independent MIME inspection failed: ' + ', '.join(r['name'] for r in check_records if not r['passed']))
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    repo, out = args.repo.resolve(), args.output.resolve()
    if out.exists():
        raise RuntimeError('Evidence directory already exists: ' + str(out))
    out.mkdir(parents=True)
    sdk = Path(os.environ['FLUTTER_ROOT']).resolve()
    dart = sdk / 'bin/cache/dart-sdk/bin/dart'
    node = Path(os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')).resolve()
    lock = (sdk.parent / 'qualified-local-validation.lock').open('a')
    print('Waiting for shared validation lock', flush=True)
    fcntl.flock(lock, fcntl.LOCK_EX)
    print('Acquired shared validation lock', flush=True)
    validation = load_validation_module()
    initial_head = validation.git_head(repo)
    if initial_head != args.expected_head:
        raise RuntimeError(f'Expected frozen head {args.expected_head}, found {initial_head}')
    engine = validation.Inputs(repo, sdk, 'engine-vba', validation.select_tests(repo, 'engine-vba'))
    mail = validation.Inputs(repo, sdk, 'mail-host', validation.select_tests(repo, 'mail-host'))
    engine.external.update(mail.external)
    engine.selected = sorted(set(engine.selected) | set(mail.selected))
    def snapshot():
        value = engine.snapshot()
        # Actual dart2js SDK inputs, supplementing the cohort runtime identity.
        extra = {}
        sdk_dir = sdk / 'bin/cache/dart-sdk'
        for path in sorted(validation.files_under(sdk_dir / 'lib')):
            if path.is_file():
                extra[str(path.relative_to(sdk))] = validation.file_record(path)
        for name in ['version', 'revision', 'bin/snapshots/dart2js_aot.dart.snapshot', 'bin/snapshots/dartdev_aot.dart.snapshot', 'bin/snapshots/kernel-service.dart.snapshot', 'bin/snapshots/gen_kernel_aot.dart.snapshot', 'bin/snapshots/kernel_worker_aot.dart.snapshot']:
            path = sdk_dir / name
            if path.is_file():
                extra[str(path.relative_to(sdk))] = validation.file_record(path)
        extra[str(node)] = validation.file_record(node)
        extra[str(Path(sys.executable).resolve())] = validation.file_record(Path(sys.executable).resolve())
        for path in sorted(Path(email.__file__).parent.rglob('*.py')):
            extra[str(path)] = validation.file_record(path)
        value['supplemental_runtime'] = extra
        value['qualification_helpers'] = {
            str(path): validation.file_record(path)
            for path in [Path(__file__).resolve(), HERE / 'run_validation.py', HERE / 'export_studio_mime.dart']
        }
        return value
    print('Fingerprinting source, dependency and runtime inputs', flush=True)
    before = snapshot()
    matches = validation.source_matches_head(repo, initial_head, before['source'])
    write_json(out / 'source-matches-head.json', matches)
    if not matches['matches']:
        raise RuntimeError('Source fingerprints do not match frozen HEAD')
    def write_compressed(name, value):
        with (out / name).open('wb') as raw:
            with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as stream:
                stream.write(json.dumps(value, sort_keys=True, indent=2).encode() + b'\n')
    write_compressed('inputs-before.json.gz', before)
    steps = []
    started = utc()
    failure = None
    parity = None
    mime = None
    def run(label, argv, cwd, timeout=180):
        step = {'label': label, 'argv': [str(x) for x in argv], 'cwd': str(cwd), 'startedAt': utc()}
        start = time.monotonic()
        print('Running ' + label, flush=True)
        with (out / (label + '.stdout')).open('wb') as stdout, (out / (label + '.stderr')).open('wb') as stderr:
            result = subprocess.run(step['argv'], cwd=cwd, stdout=stdout, stderr=stderr, timeout=timeout)
        step.update(returnCode=result.returncode, elapsedSeconds=round(time.monotonic()-start, 3), finishedAt=utc())
        steps.append(step)
        write_json(out / 'commands.json', steps)
        if result.returncode != 0:
            raise RuntimeError(f'{label} failed with exit {result.returncode}')
    try:
        run('dart-version', [dart, '--version'], repo)
        run('node-version', [node, '--version'], repo)
        corpus = repo / 'packages/quds_office_engine/test/fixtures/vba_conformance/string_intrinsics_v1.json'
        raw_corpus = corpus.read_bytes()
        (out / 'canonical-vba-corpus.json').write_bytes(raw_corpus)
        parsed_corpus = json.loads(raw_corpus)
        if len(parsed_corpus['cases']) != 69:
            raise RuntimeError('Expected exact 69-case frozen corpus')
        definition = '-DVBA_CONFORMANCE_BASE64=' + base64.b64encode(raw_corpus).decode('ascii')
        package_config = '--packages=' + str(repo / '.dart_tool/package_config.json')
        engine_cwd = repo / 'packages/quds_office_engine'
        entry = 'tool/macros/web_vba_string_conformance.dart'
        run('vba-vm', [dart, package_config, definition, entry], engine_cwd)
        run('vba-dart2js', [dart, 'compile', 'js', '-O1', package_config, definition, entry, '-o', out / 'strings.js'], engine_cwd)
        run('vba-node', [node, '-e', 'globalThis.self = globalThis; require(process.argv[1]);', out / 'strings.js'], engine_cwd)
        vm, js = (out / 'vba-vm.stdout').read_bytes(), (out / 'vba-node.stdout').read_bytes()
        parity = {
            'caseCount': 69,
            'fixtureSha256': hashlib.sha256(raw_corpus).hexdigest(),
            'vmReceiptSha256': hashlib.sha256(vm).hexdigest(),
            'javascriptReceiptSha256': hashlib.sha256(js).hexdigest(),
            'compiledJavascriptSha256': sha(out / 'strings.js'),
            'receiptsByteIdentical': vm == js,
            'additionalDistinctUnitTests': 0,
            'reason': 'Same 69 corpus cases are already counted in office_vba_conformance_test.dart.',
        }
        vm_receipt = json.loads(vm)
        js_receipt = json.loads(js)
        parity['vmCaseCount'] = vm_receipt.get('caseCount')
        parity['javascriptCaseCount'] = js_receipt.get('caseCount')
        parity['completeCaseIdentitiesMatchFixture'] = (
            [case['id'] for case in vm_receipt.get('cases', [])]
            == [case['id'] for case in parsed_corpus['cases']]
            == [case['id'] for case in js_receipt.get('cases', [])]
        )
        write_json(out / 'vba-portable-parity.json', parity)
        if vm != js:
            raise AssertionError('VM and JavaScript corpus receipts differ')
        if parity['vmCaseCount'] != 69 or parity['javascriptCaseCount'] != 69 or not parity['completeCaseIdentitiesMatchFixture']:
            raise AssertionError('Portable receipts do not contain all exact fixture case identities')
        fixture = {
            'from': 'writer@example.invalid',
            'to': 'reader.one@example.invalid, reader.two@example.invalid',
            'cc': 'copy@example.invalid',
            'bcc': 'hidden@example.invalid',
            'subject': 'Attachment receiver check — العربية 😀',
            'body': 'x' * 74 + '😀é= \t\r\n' + 'متن & <tag> "quoted"\t \n' + 'last line \t',
            'attachmentName': '研究 سجل "alpha"; 100%😀.bin',
            'attachmentBase64': base64.b64encode(bytes(i % 256 for i in range(4097))).decode('ascii'),
        }
        write_json(out / 'mime-fixture.json', fixture)
        shutil.copyfile(HERE / 'export_studio_mime.dart', out / 'export_studio_mime.dart')
        run('studio-mime-export', [dart, package_config, out / 'export_studio_mime.dart', out / 'mime-fixture.json', out / 'studio-attachment.eml', out / 'studio-envelope.json'], repo)
        mime = parse_mime(out, fixture)
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)}
        (out / 'failure.txt').write_text(traceback.format_exc())
    finally:
        print('Verifying unchanged source, dependency and runtime inputs', flush=True)
        after = snapshot()
        write_compressed('inputs-after.json.gz', after)
        changed = validation.changed_paths(before, after)
        final_head = validation.git_head(repo)
        final_matches = validation.source_matches_head(repo, final_head, after['source'])
        stable = not any(changed.values()) and initial_head == final_head and final_matches['matches']
        receipt = {
            'startedAt': started, 'finishedAt': utc(),
            'sourceHead': initial_head, 'sourceHeadAfter': final_head,
            'sourceMatchesHeadBefore': matches, 'sourceMatchesHeadAfter': final_matches,
            'sourceRuntimeAndDependenciesUnchanged': stable, 'changedInputs': changed,
            'inputInventoryBeforeSha256': validation.digest(before),
            'inputInventoryAfterSha256': validation.digest(after),
            'pythonVersion': sys.version, 'steps': [{k:v for k,v in step.items() if k != 'argv'} for step in steps],
            'portableVba': parity,
            'mimeInspection': {'checkCount': mime['checkCount'], 'allChecksPassed': mime['allChecksPassed']} if mime else None,
            'failure': failure,
            'passed': failure is None and stable and parity is not None and parity['receiptsByteIdentical'] and mime is not None and mime['allChecksPassed'],
            'scope': 'Local portable compiler receipt parity and Python standard-library MIME interpretation of synthetic actual Studio builder output. No network, mail send, provider account, installed Office or native-app claim.',
            'additionalDistinctUnitTests': 0,
            'policy': {'ciActionsQueried': False, 'ciActionsAwaited': False, 'sourceMutations': False, 'packageResolutionMutations': False},
        }
        write_json(out / 'receipt.json', receipt)
        print(json.dumps({'passed':receipt['passed'],'sourceHead':initial_head,'portableVba':parity,'mimeInspection':receipt['mimeInspection'],'failure':failure,'inputsUnchanged':stable}, indent=2), flush=True)
        fcntl.flock(lock, fcntl.LOCK_UN)
    return 0 if receipt['passed'] else 1

if __name__ == '__main__':
    raise SystemExit(main())

