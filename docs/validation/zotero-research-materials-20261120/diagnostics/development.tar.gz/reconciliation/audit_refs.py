import collections
import datetime
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path('/workspace/scratch/ee4fc9e59992')
REPO = ROOT / 'quds_office_suite'
MAIN = 'a452efdadc9000c51a8e5e9ba2f16405d4979e2e'

def git(*args, raw=False):
    value = subprocess.check_output(['git', '-C', str(REPO), *args])
    return value if raw else value.decode().strip()

def ancestor(sha):
    result = subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', sha, MAIN], capture_output=True)
    if result.returncode not in (0, 1):
        raise RuntimeError(result.stderr.decode())
    return result.returncode == 0

snapshot = json.loads((ROOT / 'reconciliation/remote-snapshot.json').read_text())
previous_path = REPO / 'docs/validation/zotero-workflow-20261119/initial-reconciliation.json'
previous = json.loads(previous_path.read_text())
proofs = {}
for item in previous['freshHistoricalEquivalenceProofs']:
    original, equivalent = item['original'], item['equivalent']
    base = git('merge-base', original, equivalent)
    paths = [p for p in git('diff', '--no-renames', '--name-only', '-z', base, original, raw=True).decode().split('\0') if p]
    if item['method'] == 'exact_complete_tree_identity':
        matches = git('rev-parse', original+'^{tree}') == git('rev-parse', equivalent+'^{tree}')
        identities = []
    else:
        identities = []
        for path in paths:
            left = git('ls-tree', original, '--', path)
            right = git('ls-tree', equivalent, '--', path)
            identities.append({'path':path, 'originalTreeEntry':left, 'equivalentTreeEntry':right, 'identical':left==right})
        matches = all(p['identical'] for p in identities)
    proof = {'original':original, 'equivalent':equivalent, 'method':item['method'], 'commonBase':base, 'commonBaseMatchesPrior':base==item['common_base'], 'completeOriginalDeltaPaths':len(paths), 'equivalentIsAncestorOfMain':ancestor(equivalent), 'identityMatches':matches, 'pathIdentities':identities}
    proof['passed'] = proof['commonBaseMatchesPrior'] and proof['equivalentIsAncestorOfMain'] and matches
    proofs[original] = proof

branches = []
incoming = []
for b in snapshot['branches']:
    sha = b['commit']['sha']
    entry = {'name':b['name'], 'sha':sha, 'ancestorOfMain':ancestor(sha)}
    if entry['ancestorOfMain']:
        entry['disposition'] = 'included by ancestry'
    elif sha in proofs and proofs[sha]['passed']:
        entry['disposition'] = 'included by freshly verified historical equivalence'
        entry['equivalent'] = proofs[sha]['equivalent']
    else:
        entry['disposition'] = 'new incoming work to integrate'
        base = git('merge-base', MAIN, sha)
        entry['mergeBase'] = base
        entry['commitsNotInMain'] = [dict(zip(('sha','title'),line.split('\t',1))) for line in git('log','--format=%H%x09%s',MAIN+'..'+sha).splitlines()]
        entry['changedPathsFromMergeBase'] = git('diff','--name-status',base,sha).splitlines()
        incoming.append(entry)
    branches.append(entry)

prs = []
for p in snapshot['pullRequests']:
    sha = p['headSha']
    entry = {'number':p['number'], 'headSha':sha, 'title':p['title'], 'state':p['state'], 'mergedAt':p['mergedAt'], 'fetchedRefMatchesApi':git('rev-parse','refs/remotes/pull/'+str(p['number']))==sha, 'ancestorOfMain':ancestor(sha)}
    if entry['ancestorOfMain']:
        entry['disposition'] = 'included by ancestry'
    elif sha in proofs and proofs[sha]['passed']:
        entry['disposition'] = 'included by freshly verified historical equivalence'
        entry['equivalent'] = proofs[sha]['equivalent']
    else:
        entry['disposition'] = 'unresolved'
    prs.append(entry)

out = {'repository':snapshot['repository'], 'capturedAt':snapshot['capturedAt'], 'auditedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'main':MAIN, 'baselinePr218Merge':'88513f04cfbdec210340f2d70a674cf3f23e31c0', 'baselinePr218IsAncestor':ancestor('88513f04cfbdec210340f2d70a674cf3f23e31c0'), 'openPullRequestCount':len(snapshot['openPullRequests']), 'pullRequestCount':len(prs), 'branchCount':len(branches), 'branches':branches, 'pullRequests':prs, 'historicalEquivalenceProofs':list(proofs.values()), 'incoming':incoming, 'policy':{'ciActionsQueried':False,'ciActionsAwaited':False,'remoteRefMutations':False}, 'sourceSnapshotSha256':hashlib.sha256((ROOT/'reconciliation/remote-snapshot.json').read_bytes()).hexdigest(), 'previousProofSource':str(previous_path.relative_to(REPO)), 'summary':{'branches':dict(collections.Counter(b['disposition'] for b in branches)), 'pullRequests':dict(collections.Counter(p['disposition'] for p in prs)), 'equivalenceProofsPassed':sum(p['passed'] for p in proofs.values()), 'fetchedRefsMatchApi':all(p['fetchedRefMatchesApi'] for p in prs)}}
(ROOT/'reconciliation/initial-reconciliation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['summary'],indent=2))
print('Unresolved PRs:', [p['number'] for p in prs if p['disposition']=='unresolved'])
print('Incoming branches:',[b['name'] for b in incoming])
