# Independent local-validation audit

Status: **partial**. Frozen product commit: `0aac0e0aa5610d6e4dc9427ffa13ebf14a8fcec8`.

Source verification: **historical Git object bytes; superseded wave, not qualification of current worktree**.

2 of 10 cohorts have completed and passed the independent audit: **1274 application cases across 72 suites**. Pending or running cohorts are excluded from this total.

| Cohort | Audit status | Passed cases | Suites |
|---|---|---:|---:|
| engine-zotero | verified | 642 | 29 |
| editor-zotero | verified | 632 | 43 |
| engine-rendering | pending | — | 11 |
| editor-rendering | pending | — | 9 |
| engine-vba | pending | — | 21 |
| mail-host | pending | — | 11 |
| mail-mime | pending | — | 6 |
| mail-transport | pending | — | 2 |
| engine-docx | pending | — | 1 |
| editor-docx | pending | — | 1 |

The independent selection contains 134 distinct suite paths, with no overlapping selections if the machine-readable errors list is empty. The audit verifies raw completion events, lifecycle exclusions, final success, per-suite counts, artifact checksums, source bytes against the frozen commit, resolved dependency inventories, workspace metadata, named runtime hashes and unchanged input digests. It checks identities by suite path and complete test name across cohorts.

Static final analysis/formatting audit: **verified**, 48 Dart targets. Actual CLI-process test cases completed: **0**; genuine Dart executable: **True**.

Supplemental SDK capture began `2026-11-20T04:31:01.283106+00:00` and contains 1144 files. This was after the first cohort started, and the manifest records which cohorts were already running or complete. No pre-run capture is claimed for those cohorts. Final after-capture comparison is pending.

See `audit.json` for exact checks, failures, paths and limitations, and `application-cases.json.gz` for every recounted application identity. This auditor ran no tests and modified no product or runtime files.
