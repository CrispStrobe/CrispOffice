#!/usr/bin/env python3
from datetime import datetime,timezone
import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path(__file__).resolve().parent;repo=root.parent/'quds_office_suite';sdk=root/'flutter-sdk'
env=dict(os.environ,FLUTTER_ROOT=str(sdk),PUB_CACHE=str(root/'pub-cache'),TMPDIR=str(root/'tmp'),XDG_CONFIG_HOME=str(root/'config'),XDG_CACHE_HOME=str(root/'cache'),XDG_DATA_HOME=str(root/'data'),CI='true',DART_SUPPRESS_ANALYTICS='true',DASH__SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true')
env['PATH']=str(sdk/'bin')+':'+env['PATH']
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
def run(label,cmd,cwd):
 start=time.monotonic()
 with (root/'logs'/f'{label}.log').open('wb') as f:
  result=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 record={'label':label,'command':cmd,'cwd':str(cwd),'exit_code':result.returncode,'seconds':time.monotonic()-start,'log':f'logs/{label}.log'}
 print(json.dumps(record),flush=True)
 assert result.returncode==0,record
 return record
before=json.loads((root/'setup/manifests-before.json').read_text());sdk_lock=sha(sdk/'packages/flutter_tools/pubspec.lock')
started=datetime.now(timezone.utc).isoformat();initial=head();checks=[]
dart=str(sdk/'bin/cache/dart-sdk/bin/dart');flutter=str(sdk/'bin/flutter')
checks.append(run('workspace-pub-get',[dart,'pub','get','--offline','--enforce-lockfile'],repo))
checks.append(run('flutter-tools-pub-get',[dart,'pub','get','--offline','--enforce-lockfile'],sdk/'packages/flutter_tools'))
checks.append(run('dart-version',[dart,'--version'],repo))
checks.append(run('flutter-version',[flutter,'--version','--machine'],repo))
manifest_matches={p:sha(repo/p)==v for p,v in before.items()}
assert all(manifest_matches.values())
assert sha(sdk/'packages/flutter_tools/pubspec.lock')==sdk_lock
source_changes=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=sdk,text=True).strip()
assert not source_changes,source_changes
version=json.loads((root/'logs/flutter-version.log').read_text())
assert version['frameworkVersion']=='3.47.8' and version['dartSdkVersion']=='3.13.7'
smoke_file=repo/'packages/quds_office_editor/test/word_zotero_format_test.dart'
smoke_before=sha(smoke_file);smoke_head=head()
checks.append(run('setup-format-smoke',[flutter,'test','--no-pub','test/word_zotero_format_test.dart','--reporter','json','--concurrency','1'],repo/'packages/quds_office_editor'))
assert sha(smoke_file)==smoke_before
receipt={'status':'ready','started_at_utc':started,'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'source_head_at_start':initial,'source_head_at_finish':head(),'source':str(repo),'sdk':str(sdk),'environment_script':str(root/'env.sh'),'runtime':version,'archive':json.loads((root/'setup/archive.json').read_text()),'executable_sha256':json.loads((root/'setup/executable-hashes.json').read_text()),'manifest_locks_unchanged':manifest_matches,'flutter_tools_lock_sha256':sdk_lock,'framework_tracked_changes':source_changes,'commands':checks,'prefetch_receipt':'setup/prefetch-194.json','setup_smoke':{'source_head_at_start':smoke_head,'test_source_sha256':smoke_before,'counted_as_product_acceptance':False},'product_acceptance_tests_run':0,'no_ci_actions_used':True}
(root/'runtime-ready.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Runtime ready',flush=True)
