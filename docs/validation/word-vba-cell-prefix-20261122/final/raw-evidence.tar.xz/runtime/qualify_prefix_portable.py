from pathlib import Path
import base64
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

from run_dart import environment

BASE = Path('/workspace/scratch/2ade9cf2abb0')
SOURCE = BASE / 'quds_office_suite'
TARGET = BASE / 'engine-validation/packages/quds_office_engine'
RUNTIME = BASE / 'runtime'
OUTPUT = BASE / 'validation-results'
DART = RUNTIME / 'dart-sdk/bin/dart'
HARNESS = RUNTIME / 'run_dart.py'
NODE = Path(shutil.which('node'))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def dart_stage(label, arguments):
    command = [sys.executable, str(HARNESS), label, *arguments]
    print(json.dumps({'stage': label, 'started_utc': now()}), flush=True)
    with (OUTPUT / (label + '.harness.stdout.log')).open('w') as out, \
            (OUTPUT / (label + '.harness.stderr.log')).open('w') as err:
        result = subprocess.run(command, cwd=BASE, env=environment(), stdout=out, stderr=err)
    receipt_path = OUTPUT / (label + '.receipt.json')
    if not receipt_path.exists():
        raise RuntimeError(f'{label}: harness produced no receipt, exit {result.returncode}')
    receipt = json.loads(receipt_path.read_text())
    print(json.dumps({'stage': label, 'exit': result.returncode,
                      'acceptance_passed': receipt.get('acceptance_passed'),
                      'seconds': receipt.get('seconds')}), flush=True)
    if result.returncode or not receipt.get('acceptance_passed'):
        raise RuntimeError(f'{label}: failed; inspect {receipt_path}')
    return receipt


def node_stage(label, compiled_js, compilation_receipt):
    command = [str(NODE), '-e', 'globalThis.self = globalThis; require(process.argv[1]);', str(compiled_js)]
    before = {str(path): sha(path) for path in [NODE, compiled_js]}
    started = now()
    wall = time.monotonic()
    out_path = OUTPUT / (label + '.stdout.log')
    err_path = OUTPUT / (label + '.stderr.log')
    with out_path.open('w') as out, err_path.open('w') as err:
        result = subprocess.run(command, cwd=TARGET, env=environment(), stdout=out, stderr=err)
    after = {str(path): sha(path) for path in [NODE, compiled_js]}
    receipt = {
        'label': label, 'command': command, 'cwd': str(TARGET),
        'started_utc': started, 'finished_utc': now(),
        'seconds': round(time.monotonic() - wall, 2),
        'process_returncode': result.returncode,
        'stdout': str(out_path), 'stderr': str(err_path),
        'hashes_before': before, 'hashes_after': after,
        'stdout_sha256': sha(out_path), 'stderr_sha256': sha(err_path),
        'compilation_receipt': str(OUTPUT / (compilation_receipt['label'] + '.receipt.json')),
        'input_integrity_passed': before == after,
        'acceptance_passed': result.returncode == 0 and before == after,
    }
    (OUTPUT / (label + '.receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'stage': label, 'exit': result.returncode,
                      'acceptance_passed': receipt['acceptance_passed'],
                      'seconds': receipt['seconds']}), flush=True)
    if not receipt['acceptance_passed']:
        raise RuntimeError(f'{label}: failed')
    return receipt


def main():
    OUTPUT.mkdir(exist_ok=True)
    source_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip()
    versions = {
        'dart': subprocess.check_output([DART, '--version'], text=True).strip(),
        'node': subprocess.check_output([NODE, '--version'], text=True).strip(),
        'python': sys.version,
    }
    stages = []
    comparisons = []
    suites = [
        ('prefix-portable-example', 'example/macros/word_table_prefix.bas',
         'WORD_CELL_PREFIX_BAS_BASE64', 'tool/macros/web_vba_word_cell_prefix_smoke.dart', 'semantic'),
        ('prefix-portable-conformance', 'test/fixtures/vba_conformance/word_cell_prefix_v1.json',
         'VBA_CONFORMANCE_BASE64', 'tool/macros/web_vba_word_cell_prefix_conformance.dart', 'canonical'),
    ]
    for prefix, relative, define, entrypoint, comparison in suites:
        source = SOURCE / 'packages/quds_office_engine' / relative
        content = source.read_bytes()
        flag = '-D' + define + '=' + base64.b64encode(content).decode('ascii')
        before_hash = sha(source)
        vm = dart_stage(prefix + '-vm', [flag, entrypoint])
        stages.append(vm)
        js = OUTPUT / (prefix + '.js')
        compiled = dart_stage(prefix + '-compile-js', ['compile', 'js', '-O1', flag, entrypoint, '-o', str(js)])
        stages.append(compiled)
        node = node_stage(prefix + '-node', js, compiled)
        stages.append(node)
        vm_bytes = Path(vm['stdout']).read_bytes()
        node_bytes = Path(node['stdout']).read_bytes()
        vm_result = json.loads(vm_bytes)
        node_result = json.loads(node_bytes)
        equivalent = vm_result == node_result
        identical = vm_bytes == node_bytes
        after_hash = sha(source)
        matched = equivalent and (comparison != 'canonical' or identical) and before_hash == after_hash
        result = {
            'name': prefix, 'source': str(source), 'entrypoint': entrypoint,
            'source_sha256_before': before_hash, 'source_sha256_after': after_hash,
            'source_bytes': len(content), 'define': define,
            'comparison_required': comparison,
            'vm_stdout_sha256': sha(vm['stdout']), 'node_stdout_sha256': sha(node['stdout']),
            'vm_js_semantically_identical': equivalent,
            'vm_js_byte_identical': identical,
            'acceptance_passed': matched,
            'vm_result': vm_result,
        }
        if comparison == 'canonical':
            result['corpus_case_count'] = len(json.loads(content)['cases'])
        comparisons.append(result)
        (OUTPUT / (prefix + '.comparison.json')).write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({key: value for key, value in result.items() if key != 'vm_result'}), flush=True)
        if not matched:
            raise RuntimeError(f'{prefix}: VM/JS comparison or source integrity failed')
    summary = {
        'versions': versions, 'source_head_observed_before': source_head,
        'source_head_observed_after': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip(),
        'completed_utc': now(),
        'script': str(Path(__file__)), 'script_sha256': sha(__file__),
        'stage_receipts': [str(OUTPUT / (stage['label'] + '.receipt.json')) for stage in stages],
        'comparisons': [str(OUTPUT / (item['name'] + '.comparison.json')) for item in comparisons],
        'all_six_stages_accepted': all(stage['acceptance_passed'] for stage in stages),
        'all_comparisons_accepted': all(item['acceptance_passed'] for item in comparisons),
    }
    (OUTPUT / 'prefix-portable-final-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    main()
