from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import lzma
import subprocess
import tarfile

BASE = Path('/workspace/scratch/2ade9cf2abb0')
REPO = BASE / 'quds_office_suite'
RESULTS = BASE / 'validation-results'
DEST = REPO / 'docs/validation/word-vba-cell-prefix-20261122/final'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def git_hashes(commit, paths):
    result = {}
    proc = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=REPO,
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    for path in paths:
        proc.stdin.write((commit + ':' + path + '\n').encode())
        proc.stdin.flush()
        header = proc.stdout.readline().decode().strip().split()
        if len(header) != 3 or header[1] != 'blob':
            raise RuntimeError('Not a committed source blob: ' + path)
        contents = proc.stdout.read(int(header[2]))
        if proc.stdout.read(1) != b'\n':
            raise RuntimeError('Invalid git batch framing')
        result[path] = {'git_blob': header[0], 'sha256': sha(contents)}
    proc.stdin.close()
    if proc.wait() != 0:
        raise RuntimeError('git cat-file failed')
    return result


def main():
    commit = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    receipts = {}
    for path in sorted(RESULTS.glob('*.receipt.json')):
        if path.name.startswith(('prefix-', 'runtime-baseline-cell-paragraphs.')):
            receipts[path.name] = json.loads(path.read_text())
    accepted = {name: value for name, value in receipts.items()
                if value.get('acceptance_passed') is True}
    required = ['prefix-table-cells-timeout-recheck.receipt.json',
                'prefix-format-final.receipt.json',
                'prefix-final-analysis-formatted.receipt.json']
    for name in required:
        if name not in accepted:
            raise RuntimeError('Missing passing final gate: ' + name)
    broad_name = 'prefix-full-regression.receipt.json'
    broad = receipts[broad_name]
    if not (broad['input_integrity_passed'] and broad['passed'] == 7508
            and broad['failed'] == 1 and broad['skipped'] == 0
            and len(broad['errors']) == 1
            and broad['errors'][0]['error'].startswith('TimeoutException after 0:00:30.')):
        raise RuntimeError('Unexpected broad regression outcome')
    portable_path = RESULTS / 'prefix-portable-final-summary.json'
    if not portable_path.is_file():
        raise RuntimeError('Missing portable comparison summary')
    source_bound_runs = {**{name: value for name, value in accepted.items()
                          if 'source_before_manifest' in value}, broad_name: broad}
    manifests = {name: json.loads(Path(value['source_before_manifest']).read_text())
                 for name, value in source_bound_runs.items()}
    paths = sorted(set().union(*(set(value) for value in manifests.values())))
    committed = git_hashes(commit, paths)
    allowed = {
        'packages/quds_office_engine/test/office_macro_word_cell_prefix_test.dart',
        'packages/quds_office_engine/test/office_vba_word_cell_prefix_conformance_test.dart',
    }
    bindings = {}
    for name, manifest in manifests.items():
        differences = {path: {'tested_sha256': digest,
                              'published_sha256': committed[path]['sha256']}
                       for path, digest in manifest.items()
                       if committed[path]['sha256'] != digest}
        if set(differences) - allowed:
            raise RuntimeError('Unexpected source drift for ' + name + ': ' + str(differences))
        if name in required[1:] and differences:
            raise RuntimeError('Final formatted gate does not match committed input')
        bindings[name] = {
            'manifest_files': len(manifest),
            'source_before_manifest_sha256': sha(Path(source_bound_runs[name]['source_before_manifest']).read_bytes()),
            'differences_from_publication_source': differences,
            'all_production_files_match': not any('/lib/' in path for path in differences),
            'interpretation': 'Exact committed inputs' if not differences else
                'Only pinned formatter edits to two new tests; both were rerun on the final committed bytes.',
        }
    summary = {
        'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'qualified_source_commit': commit, 'qualified_source_tree': tree,
        'initial_reconciled_commit': 'ee3ba4f6a7d5f2a9d73926d95d41e16580bf97c0',
        'broad_regression_source_commit': '806525fdb06d501fff09d4fb6b12ee95ef6cf4b2',
        'github_actions_queried_or_awaited': False,
        'installed_word_host_executed': False,
        'broad_regression_status': '7508 passed, one existing table-cell integration case hit its original 30-second deadline. The entire affected suite passed separately with the original timeout and unchanged implementation. The original nonzero result is retained; no claim of a clean broad invocation is made.',
        'scope': 'Pure Dart engine VBA/Word automation and related regression suites; not full Flutter/editor or installed Office acceptance.',
        'runs': {name: {key: value[key] for key in (
            'label', 'exit_code', 'process_returncode', 'harness_exit_code',
            'acceptance_passed', 'input_integrity_passed', 'seconds',
            'passed', 'failed', 'skipped') if key in value}
                 for name, value in receipts.items()},
        'source_bindings': bindings,
        'portable_comparison': json.loads(portable_path.read_text()),
    }
    write_json(DEST / 'qualification.json', summary)
    source_index = json.dumps(committed, sort_keys=True, indent=2).encode() + b'\n'
    (DEST / 'committed-source-index.json.gz').write_bytes(gzip.compress(source_index, mtime=0))
    files = {}
    for path in RESULTS.iterdir():
        if path.is_file() and path.name.startswith(('prefix-', 'runtime-baseline-cell-paragraphs.')):
            files['validation-results/' + path.name] = path.read_bytes()
    for name in ('run_dart.py', 'sync_validation.py', 'runtime-provenance.json',
                 'sdk-provenance.json', 'dartsdk.sha256sum', 'finalize_prefix_evidence.py',
                 'qualify_prefix_portable.py'):
        path = BASE / 'runtime' / name
        files['runtime/' + name] = path.read_bytes()
    for root_name in ('format-audit-806525fd', 'format-audit-final'):
        root = BASE / root_name
        for path in root.glob('*'):
            if path.is_file():
                files[root_name + '/' + path.name] = path.read_bytes()
    for relative in ('pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.dart_tool/package_config.json'):
        path = BASE / 'engine-validation' / relative
        files['isolated-workspace/' + relative] = path.read_bytes()
    write_json(DEST / 'archive-manifest.json', {
        name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())})
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w') as archive:
        for name, data in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mtime, info.mode = len(data), 0, 0o644
            archive.addfile(info, io.BytesIO(data))
    payload = lzma.compress(raw.getvalue(), preset=6)
    (DEST / 'raw-evidence.tar.xz').write_bytes(payload)
    (DEST / 'raw-evidence.tar.gz').unlink(missing_ok=True)
    write_json(DEST / 'artifacts.json', {
        path.name: {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
        for path in sorted(DEST.iterdir()) if path.is_file() and path.name != 'artifacts.json'})
    print(json.dumps({'source_commit': commit, 'accepted_runs': len(accepted),
                      'source_files_bound': len(paths), 'archive_entries': len(files),
                      'archive_bytes': len(payload)}, indent=2))


if __name__ == '__main__':
    main()
