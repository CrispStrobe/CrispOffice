from pathlib import Path
import fcntl
import hashlib
import json
import os
import subprocess
import sys
import time

from sync_validation import BASE, SOURCE, TARGET, PATHS, SKIP, sync

RUNTIME = BASE / 'runtime'
DART = RUNTIME / 'dart-sdk/bin/dart'

def environment():
    env = os.environ.copy()
    env.update({
        'PUB_CACHE': str(RUNTIME / 'pub-cache'),
        'TMPDIR': str(RUNTIME / 'tmp'),
        'DART_SUPPRESS_ANALYTICS': 'true',
        'CI': 'true',
        'PATH': str(DART.parent) + os.pathsep + env.get('PATH', ''),
    })
    return env


def file_hash(path):
    try:
        with path.open('rb') as handle:
            digest = hashlib.sha256()
            for chunk in iter(lambda: handle.read(1024 * 1024), b''):
                digest.update(chunk)
            return digest.hexdigest()
    except FileNotFoundError:
        return None


def input_manifest(root, previous=(), target=False):
    paths = set(previous) | {'analysis_options.yaml', 'pubspec.yaml', 'pubspec.lock'}
    for relative_root in PATHS:
        for path in (root / relative_root).rglob('*'):
            relative = path.relative_to(root)
            if not any(part in SKIP for part in relative.parts) and path.is_file():
                paths.add(relative.as_posix())
    if target:
        paths.add('.dart_tool/package_config.json')
        for package in ('quds_office_engine', 'legacy_doc_parser'):
            paths.add('packages/' + package + '/pubspec.yaml')
        paths.add('packages/quds_office_engine/example/pubspec.yaml')
        for relative in ('packages/quds_office_engine', 'packages/legacy_doc_parser',
                         'packages/quds_office_engine/example'):
            config = relative + '/.dart_tool/package_config.json'
            if (root / config).is_file():
                paths.add(config)
    return {name: file_hash(root / name) for name in sorted(paths)}


def toolchain_manifest(previous=()):
    paths = set(previous) | {
        'dart-sdk/bin/dart', 'dart-sdk/bin/dartaotruntime', 'dart-sdk/bin/dartvm',
        'dart-sdk/version', 'sdk-provenance.json', 'runtime-provenance.json',
        'dartsdk.sha256sum', 'run_dart.py', 'sync_validation.py',
    }
    for path in (RUNTIME / 'dart-sdk/bin/snapshots').rglob('*'):
        if path.is_file():
            paths.add(path.relative_to(RUNTIME).as_posix())
    return {name: file_hash(RUNTIME / name) for name in sorted(paths)}


def manifest_drift(before, after):
    return {name: {'before': before.get(name), 'after': after.get(name)}
            for name in sorted(set(before) | set(after))
            if before.get(name) != after.get(name)}


def write_manifest(output, label, kind, values):
    path = output / (label + '.' + kind + '-manifest.json')
    path.write_text(json.dumps(values, sort_keys=True, indent=2) + '\n')
    return str(path)


def main():
    if len(sys.argv) < 3:
        raise SystemExit('Usage: python3 toolchain/run_dart.py LABEL test/analyze/run/compile ARGS...')
    label = sys.argv[1]
    changed, manifest = sync()
    output = BASE / 'validation-results'
    output.mkdir(exist_ok=True)
    (output / (label + '.source-manifest.json')).write_text(json.dumps(manifest, sort_keys=True, indent=2)+'\n')
    source_before = input_manifest(SOURCE, manifest)
    target_before = input_manifest(TARGET, manifest, target=True)
    toolchain_before = toolchain_manifest()
    before_paths = {
        name + '_before_manifest': write_manifest(output, label, name + '-before', values)
        for name, values in [('source', source_before), ('target', target_before),
                             ('toolchain', toolchain_before)]
    }
    command = [str(DART), *sys.argv[2:]]
    cwd = TARGET / 'packages/quds_office_engine'
    started = time.time()
    print(json.dumps({'label': label, 'command': command, 'cwd': str(cwd), 'source_files': len(manifest), 'changed_files': len(changed)}), flush=True)
    with (output / (label + '.stdout.log')).open('w') as out, (output / (label + '.stderr.log')).open('w') as err:
        result = subprocess.run(command, cwd=cwd, env=environment(), stdout=out, stderr=err)
    receipt = {'label': label, 'command': command, 'cwd': str(cwd), 'exit_code': result.returncode, 'seconds': round(time.time()-started,2), 'source_manifest': str(output / (label + '.source-manifest.json')), 'stdout': str(output / (label + '.stdout.log')), 'stderr': str(output / (label + '.stderr.log'))}
    # Never resync after execution: preserve evidence of modified/missing inputs.
    source_after = input_manifest(SOURCE, source_before)
    target_after = input_manifest(TARGET, target_before, target=True)
    toolchain_after = toolchain_manifest(toolchain_before)
    source_drift = manifest_drift(source_before, source_after)
    target_drift = manifest_drift(target_before, target_after)
    toolchain_drift = manifest_drift(toolchain_before, toolchain_after)
    copy_mismatches = {name: digest for name, digest in manifest.items()
                       if target_before.get(name) != digest}
    source_copy_mismatches = {name: digest for name, digest in manifest.items()
                              if source_before.get(name) != digest}
    missing_before = {
        name: [path for path, digest in values.items() if digest is None]
        for name, values in [('source', source_before), ('target', target_before),
                             ('toolchain', toolchain_before)]
    }
    integrity = not (source_drift or target_drift or toolchain_drift or copy_mismatches
                     or source_copy_mismatches or any(missing_before.values()))
    harness_exit_code = result.returncode if result.returncode != 0 else (0 if integrity else 86)
    receipt.update({
        **before_paths,
        **{name + '_after_manifest': write_manifest(output, label, name + '-after', values)
           for name, values in [('source', source_after), ('target', target_after),
                                ('toolchain', toolchain_after)]},
        'process_returncode': result.returncode,
        'harness_exit_code': harness_exit_code,
        'acceptance_passed': result.returncode == 0 and integrity,
        'input_integrity_passed': integrity,
        'source_drift': source_drift, 'target_drift': target_drift,
        'toolchain_drift': toolchain_drift,
        'copy_mismatches': copy_mismatches,
        'source_copy_mismatches': source_copy_mismatches,
        'missing_inputs_before': missing_before,
        'lock': str(RUNTIME / 'validation.lock'),
        'source_root': str(SOURCE), 'target_root': str(TARGET),
        'qualification_scope': 'Executed inputs are the isolated target-before snapshot; no repository HEAD identity is inferred from copies.',
    })
    events = []
    for line in (output / (label + '.stdout.log')).read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(event, dict):
            events.append(event)
    starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    finished = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden')]
    if finished:
        receipt.update({'passed': sum(e['result']=='success' and not e.get('skipped') for e in finished), 'failed': sum(e['result']!='success' for e in finished), 'skipped': sum(bool(e.get('skipped')) for e in finished), 'failed_tests': [starts.get(e['testID'], {}) for e in finished if e['result']!='success'], 'errors': [e for e in events if e.get('type')=='error']})
    (output / (label + '.receipt.json')).write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt, indent=2), flush=True)
    if not finished:
        print((output / (label + '.stdout.log')).read_text()[-10000:])
        print((output / (label + '.stderr.log')).read_text()[-5000:])
    return harness_exit_code


if __name__ == '__main__':
    # Exclusive advisory lock spans sync, subprocess and all post-run evidence.
    with (RUNTIME / 'validation.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        sys.exit(main())
