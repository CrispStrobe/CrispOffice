import concurrent.futures
import hashlib
import json
from pathlib import Path
import time
import urllib.request

root = Path(__file__).resolve().parents[2]
rows = json.loads((root / 'quds_office_suite/tools/proofing/german_model/artifacts.json').read_text())
output = root / 'runtime/native-recovery/proofbird'
output.mkdir(parents=True, exist_ok=True)

def one(row):
    dest = output / row['file']
    started = time.time()
    for attempt in range(3):
        try:
            if not dest.exists():
                with urllib.request.urlopen(row['url'], timeout=45) as response, dest.with_suffix(dest.suffix + '.partial').open('wb') as stream:
                    while block := response.read(1024*1024):
                        stream.write(block)
                dest.with_suffix(dest.suffix + '.partial').replace(dest)
            digest = hashlib.file_digest(dest.open('rb'), 'sha256').hexdigest()
            assert dest.stat().st_size == row['size'], (dest.stat().st_size, row['size'])
            assert digest == row['sha256'], (digest, row['sha256'])
            result = dict(row, status='verified', seconds=round(time.time()-started, 2))
            print(json.dumps(result), flush=True)
            return result
        except Exception as exc:
            if attempt == 2:
                result = dict(row, status='failed', error=repr(exc))
                print(json.dumps(result), flush=True)
                return result
    raise AssertionError('unreachable')

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    result = list(pool.map(one, rows))
(root / 'recovery/native/download-receipt.json').write_text(json.dumps(result, indent=2)+'\n')
raise SystemExit(0 if all(x['status']=='verified' for x in result) else 1)
