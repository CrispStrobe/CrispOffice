#!/usr/bin/env python3
"""Independently reconstruct historical suite selection from exact Git trees.

Only the suite-selection portion of the sealed adapter is reproduced here.
No historical runtime outcome, source formatting result, or generated-data
validation result is borrowed. The actual current adapter supplies its plan.
"""
from pathlib import Path, PurePosixPath
import fnmatch
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT / 'quds_office_suite'
OLD = '6a32a919325d71c121c63e3879cfd1b28d64312e'
CURRENT = '1d8325d41526a55e3d6cd6031371458d2ee396e5'
BASELINE = '518fb28b'
PACKAGES = {'engine':'quds_office_engine','editor':'quds_office_editor',
            'harper':'quds_proofing_harper','gector':'quds_proofing_gector','aot':'quds_proofing_aot'}
def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args])
def sha(data):
    return hashlib.sha256(data).hexdigest()
def tree(commit):
    rows={}
    for row in git('ls-tree','-r','-z',commit).split(b'\0'):
        if not row: continue
        meta,path=row.split(b'\t',1)
        mode,kind,oid=meta.decode().split()
        if kind=='blob': rows[path.decode()]={'mode':mode,'git_blob':oid}
    return rows
old_tree=tree(OLD)
current_tree=tree(CURRENT)
fidelity_path='docs/validation/office-fidelity-20261117/cohorts.json'
old_fidelity_bytes=git('show',OLD+':'+fidelity_path)
fidelity=json.loads(old_fidelity_bytes)
historical_path='docs/validation/office-reconcile-20261117/qualified-ec5ecbff/historical-plan-179.json'
historical_bytes=git('show',OLD+':'+historical_path)
historical=json.loads(historical_bytes)
assert historical['unique_test_files']==179
cohorts={}
for kind in ('engine','editor'):
    prefix='packages/'+PACKAGES[kind]+'/'
    candidates={p[len(prefix):] for p in old_tree if p.startswith(prefix+'test/')}
    zotero={p for p in candidates if fnmatch.fnmatch(PurePosixPath(p).name,'*zotero*test.dart')}
    selected={'test/'+p for p in fidelity[kind]}-zotero
    if kind=='engine':
        selected.update(p for p in candidates if str(PurePosixPath(p).parent)=='test/proofing' and fnmatch.fnmatch(PurePosixPath(p).name,'*_test.dart'))
        selected.update(('test/word_layout_test.dart','test/word_styles_layout_test.dart'))
    else:
        selected.update(p for p in candidates if str(PurePosixPath(p).parent)=='test' and any(fnmatch.fnmatch(PurePosixPath(p).name,pattern) for pattern in ('word_proofing*_test.dart','word_hyphenation*_test.dart')))
        selected.add('test/platform_spelling_provider_test.dart')
    changed=git('diff','--name-only',BASELINE,OLD,'--',prefix+'test').decode().splitlines()
    selected.update(p[len(prefix):] for p in changed if p.endswith('_test.dart') and p in old_tree)
    if kind=='engine':
        selected.update(p for p in candidates if str(PurePosixPath(p).parent)=='test' and any(fnmatch.fnmatch(PurePosixPath(p).name,pattern) for pattern in ('odt*_test.dart','ods*_test.dart','odp*_test.dart','odf*_test.dart','office_text*_test.dart','office_search*_test.dart')))
    selected-=zotero
    cohorts[kind+'-zotero']={'kind':kind,'tests':sorted(zotero)}
    cohorts[kind+'-integration']={'kind':kind,'tests':sorted(selected)}
cohorts['harper-contract']={'kind':'harper','tests':sorted('test/'+p for p in fidelity['harper'])}
for kind in ('gector','aot'):
    prefix='packages/'+PACKAGES[kind]+'/'
    cohorts[kind+'-contract']={'kind':kind,'tests':sorted(p[len(prefix):] for p in old_tree if p.startswith(prefix+'test/') and fnmatch.fnmatch(PurePosixPath(p).name,'*_test.dart'))}
cohorts['editor-integration']['tests']=sorted(set(cohorts['editor-integration']['tests'])|{'example/test/studio_aot_test.dart'})
for name,group in historical['cohorts'].items():
    assert cohorts[name]['kind']==group['kind']
    cohorts[name]['tests']=sorted(set(cohorts[name]['tests'])|set(group['tests']))
pairs=[(g['kind'],p) for g in cohorts.values() for p in g['tests']]
assert len(pairs)==len(set(pairs))
assert all('packages/'+PACKAGES[k]+'/'+p in old_tree for k,p in pairs)
old_pairs=set(pairs)
excluded={p for p in old_pairs if p[0]=='aot' or p[1]=='example/test/studio_aot_test.dart'}
retained=old_pairs-excluded
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'recovery/qualification'))
import run_qualification
current_plan=run_qualification.make_plan(ROOT/'source-1d8325d4',CURRENT)
current_pairs={(g['kind'],p) for g in current_plan['cohorts'].values() for p in g['tests']}
assert len(current_pairs)==current_plan['unique_test_files']
assert all('packages/'+PACKAGES[k]+'/'+p in current_tree for k,p in current_pairs)
missing=retained-current_pairs
added=current_pairs-old_pairs
baseline={(g['kind'],p) for g in historical['cohorts'].values() for p in g['tests']}
result={
 'method':__doc__.strip(),'old_commit':OLD,'current_commit':CURRENT,
 'analysis_baseline':git('rev-parse',BASELINE).decode().strip(),
 'historical_selected_files':len(old_pairs),'intentional_removed_files':len(excluded),
 'retained_old_files':len(retained),'current_selected_files':len(current_pairs),
 'historical_baseline_retained':len(baseline & current_pairs),
 'old_count_211_claim_verified':False,
 'old_count_discrepancy':'The exact source-based sealed selection reproduces210. The older handoff211 count has one unlocated file and is not claimed.',
 'missing_retained_files':sorted(missing),'added_since_old_files':sorted(added),
 'intentional_exclusions':sorted(excluded),'duplicates':[],
 'cohorts_old':{k:len(v['tests']) for k,v in cohorts.items()},
 'cohorts_current':{k:len(v['tests']) for k,v in current_plan['cohorts'].items()},
 'source_fidelity_manifest':{'path':fidelity_path,'sha256':sha(old_fidelity_bytes)},
 'source_historical_plan':{'path':historical_path,'sha256':sha(historical_bytes)},
 'old_adapter':{'path':'docs/validation/office-reconcile-20261117/qualified-ec5ecbff/run_qualification.py','sha256':sha(git('show',OLD+':docs/validation/office-reconcile-20261117/qualified-ec5ecbff/run_qualification.py'))},
 'current_adapter_sha256':sha((ROOT/'recovery/qualification/run_qualification.py').read_bytes()),
 'audit_script_sha256':sha(Path(__file__).read_bytes()),
 'historical_outcomes_counted':False,
 'passed':not missing and baseline<=current_pairs,
}
output=ROOT/'recovery/canonical'
(output/'reconstructed-selection-6a32a919.json').write_text(json.dumps({'source_commit':OLD,'cohorts':cohorts,'unique_test_files':len(old_pairs),'selected_input_blobs':{k+'/'+p:old_tree['packages/'+PACKAGES[k]+'/'+p] for k,p in sorted(old_pairs)}},indent=2,sort_keys=True)+'\n')
(output/'current-plan-1d8325d4.json').write_text(json.dumps(current_plan,indent=2,sort_keys=True)+'\n')
(output/'independent-selection-retention.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:result[k] for k in ('historical_selected_files','intentional_removed_files','retained_old_files','current_selected_files','historical_baseline_retained','missing_retained_files','added_since_old_files','passed')},indent=2))
