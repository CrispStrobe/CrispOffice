# Canonical reconstruction after executor reset

The executor lost the earlier `/workspace/scratch/a9bb52a606ba` filesystem during qualification. Published source `4595e30813a7864889953baa8c964809043efb88` is the retained authority. Unpublished intermediate raw results cannot be claimed as available evidence; regenerate controls and complete qualification against a fresh frozen source.

## Authored column ordering

A runless paragraph PAGE marker with inlines bookmark-start, column-break, bookmark-end produces a native page field before the bookmark end. Therefore its authored order is start, break, field, end. The existing Word serializer also emits its fallback cache after the break. The independent consumer's original expectation that this field precedes the break was an oracle error; retain that failed attempt if any remote copy exists and explicitly document the corrected oracle.

The original native packets are not interchangeable: LibreOffice renders a raw no-cache PAGE envelope around these inlines with PAGE before the break, while the Word serializer's added fallback cache after the inlines places PAGE after it. The flattened paragraph marker cannot distinguish those source encodings. The repair retains the existing marker/export ordering and does not claim exact native no-cache packet placement. The independent plain no-PAGE DOCX reference establishes the leading-column layout defect without this ambiguity.

A possible separate product defect is that `fo:break-before="column"` on the first paragraph of a two-column ODF section can be ignored by LibreOffice. Compare the authored DOCX and the ODF for an unambiguous first paragraph `[column break, visible text]`, plus two following paragraphs, before applying a repair. Preserve existing later-section page/section precedence and all zero-width bookmark endpoint order.

## First source repairs already published

1. A single empty cached native PAGE field counts as content before an inline column break.
2. The corresponding NUMPAGES case does too.
3. A runless PAGE marker before a bookmark end counts as content before a later break (start, end, break order).
4. A malformed-ID named bookmark start reserves its name; it cannot permit an ambiguous inferred end to bind to another start.

The writer uses one pure native-field plan for layout and emission. It retains the admitted single cache and its style/link. ODF permits styled/linked page-count elements. The initial lxml rejection of the official schema's combined-name field pattern was a validator defect; independent Jing with the unchanged official schema accepted that current-main fixture. Do not restore the old direct-only page-count workaround.

Restored tests at the published source include `odt_complex_field_fidelity_test.dart`, `odt_page_marker_column_break_test.dart`, and `odt_bookmark_name_ambiguity_test.dart`. The complex-field suite adapts obsolete native-empty-placeholder assumptions to the current single-cache contract; ownership and fallback tests remain. The latter two were restored unchanged.

## Suite accounting

The sealed historical adapter at the qualified 6a32a919 source reproducibly selects 210 files, comprising 199 retained files plus 10 intentionally removed AOT package suites and one intentionally removed Studio AOT suite. The current 214-file plan comprises all 199 survivors plus 15 additions. The older handoff's claim of 211 selected files contains an unlocated extra file and must not be repeated as verified. The new 214 selection has 179 historical baseline files plus 35 additions, with six disjoint cohorts: engine-zotero 19, editor-zotero 13, engine-integration 128, editor-integration 37, harper 3, and gector 14.

The partially completed full run against source 4595e308 was interrupted by the executor reset; its raw outputs were lost before remote preservation. No final pass count from that attempt is supported.
