# Independent Office consumer qualification

These runners bind generated artifacts to an exact Git source commit, package graph, runtime inputs, and before/after SHA-256 inventories. The retained 33-fixture runner and its 14 source/schema support files are unchanged from the previously qualified archive. Seven disjoint current controls add empty-cache native fields, runless PAGE and first-column ordering, styled linked single-run caches, split-cache literal fallback, and a TOC beginning a differently sized section. Count only the selected source's 33 + 7 fixtures and 132 + 28 XML parts; historical runs and schema diagnostics are separate.

## Source-order correction

The first pre-reset exploratory run incorrectly expected a paragraph-wide runless PAGE to appear before a break inside `BookmarkStart → column break → BookmarkEnd`. The existing ODT field rule emits its generated display before the closing bookmark, so this model puts the display after the break. `WordSerializer` also appends the generated fallback cache after inline boundaries. The corrected fixture expects PAGE and both followers in the right column, and the runner generates and independently renders the actual model's WordSerializer DOCX as a reference.

The unambiguous plain control has no fields: a first paragraph containing a column break followed by `AfterLeading`, then two following paragraphs. Native authored DOCX puts all three labels in the right column. The corrected ODT retains an empty prefix paragraph before applying the explicit column break to the destination. Two followers prevent natural balancing from imitating this behavior.

`native-order-reference` also preserves a distinct raw host DOCX packet: an outer complex PAGE envelope with bookmark start, break, bookmark end, and **no cached result run**. LibreOffice displays that packet's generated PAGE at the left origin while both followers go right. Adding the serializer's generated cache run `1` after the inline boundaries puts PAGE and both followers right. Both source packets and observations remain in the archive. The earlier manually authored file named `serializer-runless-order.docx` is only a visible-order approximation; `serializer-field-envelope-order.docx` captures the actual envelope order, and every current positive/negative run also includes the real `WordSerializer` output. No blanket field-placement claim is made across these different packets.

Initial exploratory raw files in the transient workspace were lost in the environment reset. Fresh exact-commit negative runs with the corrected, fixed seven-fixture oracle are retained separately; historical observations are not presented as surviving raw evidence.

## Independent schema oracle

The pinned official [OASIS ODF 1.3 main grammar](https://docs.oasis-open.org/office/OpenDocument/v1.3/os/schemas/OpenDocument-v1.3-schema.rng) and [manifest grammar](https://docs.oasis-open.org/office/OpenDocument/v1.3/os/schemas/OpenDocument-v1.3-manifest-schema.rng) were downloaded again and match the retained bytes exactly. Main SHA-256 is `40bad03efdbb02825230d357da0aa6ac679934c5bf56c6281752c0c24d58e4e6`; manifest SHA-256 is `8aee71f03484be112af972d622cc9031280c007b0a454ae8815e8e333c9bdd17`.

The unchanged current-main `toc-fields.odt` artifact contains a valid styled `text:page-count`. lxml 6.1.1 / libxml2 2.14.6 reports an extra-content error for this legal construct. Independent Jing accepts it against the unmodified grammar. The [OASIS prose specification §7.5.18.2](https://docs.oasis-open.org/office/OpenDocument/v1.3/os/part3-schema/OpenDocument-v1.3-os-part3-schema.html) permits `text:page-count` inside spans and hyperlinks. The production writer retains styling, links, and exact source caches.

The independent validator is [Jing 20241231](https://repo.maven.apache.org/maven2/org/relaxng/jing/20241231/jing-20241231.jar), 773895 bytes, SHA-256 `ea5e9026244d977e607d8b52212d6871498ece51939f9c49d0e7a77aad91133a`; its publisher SHA-1, POM, and license are included. The [documented `-i` option](https://relaxng.org/jclark/jing.html) disables optional DTD compatibility ID/IDREF checks. It leaves the RelaxNG grammar checks active. The controls accept the original and linked styled field, and reject a field with an illegal child span and a field with an illegal attribute. No grammar transformation is used for acceptance. lxml results remain explicit diagnostics.

## Consumer semantics and limits

Native PAGE/NUMPAGES single-run cache text is checked before any consumer opens the ODT. Empty authored caches remain empty. Unsupported or split caches remain exact literal text, including repeated spaces and tabs. Separate LibreOffice PDF and DOCX reopen operations check live refresh to `1 of 2`, the locked literal `23`, hyperlink targets and field instructions, bookmarks, cache run styles, TOC entry caches, page sizes, and explicit column positions.

The PDF shows bold colored PAGE and italic colored NUMPAGES. LibreOffice's DOCX export preserves PAGE styling on its field-begin run, while its cached-result run may use defaults. The evidence records this converter limitation; it does not claim full DOCX cached-result-run style retention.

## Reproduction

Restore the exact pinned Flutter 3.47.8 / Dart 3.13.7 runtime, then use the repository's `prepare_workspace.py` to resolve an external graph with the unchanged lock and `dart pub get --offline --enforce-lockfile`. The source library symlinks must resolve to the frozen commit. Do not edit a graph while a runner fingerprints it.

```sh
python3 wave3-runner/verify_consumers.py \
  --output FRESH_RETAINED_OUTPUT --schemas schemas --dart EXACT_DART \
  --repo EXTERNAL_WORKSPACE --source-repo FROZEN_SOURCE --expected-head EXACT_COMMIT
python3 verify_current_consumers.py \
  --output FRESH_CURRENT_OUTPUT --schemas schemas --dart EXACT_DART \
  --repo EXTERNAL_WORKSPACE --source-repo FROZEN_SOURCE --expected-head EXACT_COMMIT
```

`package_consumer_evidence.py` checks both input maps, every recorded output checksum, all retained files and fixture specs, disjoint counts, then rereads every archive member and verifies its hash. Intermediate and negative results are never added to the selected final count. No GitHub Actions interfaces are queried or awaited.
