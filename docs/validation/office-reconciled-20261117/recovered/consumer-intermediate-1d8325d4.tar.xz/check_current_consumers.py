"""Independent XML, PDF and reopened-DOCX checks for the current seven fixtures."""
from pathlib import Path
import re
import zipfile
from lxml import etree
import fitz

NS = {
    'office': 'urn:oasis:names:tc:opendocument:xmlns:office:1.0',
    'text': 'urn:oasis:names:tc:opendocument:xmlns:text:1.0',
    'style': 'urn:oasis:names:tc:opendocument:xmlns:style:1.0',
    'fo': 'urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0',
    'xlink': 'http://www.w3.org/1999/xlink',
    'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'rel': 'http://schemas.openxmlformats.org/package/2006/relationships',
}

def require(condition, message):
    if not condition:
        raise AssertionError(message)

def q(prefix, name):
    return '{' + NS[prefix] + '}' + name

def visible(node):
    if node.tag == q('office', 'annotation'):
        return ''
    if node.tag == q('text', 's'):
        return ' ' * int(node.get(q('text', 'c'), '1'))
    if node.tag == q('text', 'tab'):
        return '\t'
    if node.tag == q('text', 'line-break'):
        return '\n'
    return (node.text or '') + ''.join(visible(c) + (c.tail or '') for c in node)

def docx_visible(p):
    return ''.join(n.text or '' if n.tag == q('w', 't') else '\t' if n.tag == q('w', 'tab') else '\n'
                   for n in p.iter() if n.tag in (q('w', 't'), q('w', 'tab'), q('w', 'br')))

def read_part(file, part):
    with zipfile.ZipFile(file) as archive:
        return etree.fromstring(archive.read(part))

def style_properties(root, element, child):
    name = element.get(q('text', 'style-name'))
    matches = root.xpath('./office:automatic-styles/style:style[@style:name=$name]', namespaces=NS, name=name)
    require(len(matches) == 1, 'Missing unique style for ' + str(name))
    result = matches[0].find('style:' + child, NS)
    require(result is not None, 'Missing style properties ' + child)
    return result

def check_raw(spec, path):
    root = read_part(path, 'content.xml')
    paragraphs = root.xpath('./office:body/office:text//text:p', namespaces=NS)
    fields = root.xpath('.//text:page-number | .//text:page-count', namespaces=NS)
    kinds = [etree.QName(n).localname for n in fields]
    breaks = [style_properties(root, p, 'paragraph-properties').get(q('fo', 'break-before')) for p in paragraphs]
    result = {'native_fields': kinds, 'paragraphs': [visible(p) for p in paragraphs], 'break_before': breaks}
    kind = spec['kind']
    if kind == 'empty-field-column':
        require(kinds == [spec['field']], 'Native empty-cache field must occur exactly once')
        require(visible(fields[0]) == '' and len(fields[0]) == 0, 'Native cache was invented or changed')
        require(len(paragraphs) == 3 and fields[0] in list(paragraphs[0].iter()), 'Field must own the first paragraph')
        require(breaks == [None, 'column', None], 'Column break must remain after the empty-cache native field')
        require(result['paragraphs'][1:] == spec['right_words'], 'Column destination/follower text changed')
    elif kind in ('runless-leading-column', 'plain-leading-column'):
        require(len(paragraphs) == 4 and visible(paragraphs[0]) == '', 'First-column break needs an empty prefix anchor')
        require(breaks == [None, 'column', None, None], 'Leading column must apply to content after the prefix')
        if kind == 'runless-leading-column':
            require(kinds == ['page-number'] and visible(fields[0]) == '', 'Runless PAGE should remain a single uncached native field')
            nodes = [n for n in root.iter() if n.tag in (q('text','bookmark-start'), q('text','page-number'), q('text','bookmark-end'))]
            require([etree.QName(n).localname for n in nodes] == ['bookmark-start', 'page-number', 'bookmark-end'], 'Bookmark and generated field order changed')
            require(nodes[0].get(q('text','name')) == nodes[2].get(q('text','name')) == spec['bookmark'], 'Bookmark pairing changed')
            require(nodes[0].getparent() is paragraphs[0] and fields[0].getparent() is paragraphs[1], 'Bookmark start/field source fragments changed')
            require(result['paragraphs'][2:] == spec['right_words'][1:], 'Runless followers changed')
        else:
            require(not fields and result['paragraphs'][1:] == spec['right_words'], 'Plain control text changed')
    elif kind == 'styled-linked-fields':
        require(kinds == ['page-number', 'page-count'], 'Expected exactly PAGE and NUMPAGES')
        require([visible(n) for n in fields] == [spec['cached_page'], spec['cached_count']], 'Authored native caches changed')
        for field, suffix, prop, value, color in zip(fields, ['page','count'], ['font-weight','font-style'], ['bold','italic'], ['#123456','#AA0000']):
            require(len(field) == 0, 'Native page field may contain text only')
            span = field.getparent(); link = span.getparent()
            require(span.tag == q('text','span') and link.tag == q('text','a'), 'Native field style or hyperlink wrapper dropped')
            require(link.get(q('xlink','href')) == 'https://example.test/' + suffix, 'Hyperlink target changed')
            props = style_properties(root, span, 'text-properties')
            require(props.get(q('fo',prop)) == value and props.get(q('fo','color')).upper() == color, 'Native field styling changed')
        require(result['paragraphs'][1] == 'Page 17 of 99' and result['paragraphs'][2] == 'Locked 23', 'Cached text/locked literal changed')
    elif kind == 'split-cache-fallback':
        require(not fields, 'Split/unsupported field cache must remain literal')
        require(result['paragraphs'] == spec['exact_paragraphs'], 'Readable cache whitespace or text changed')
        for target, prop, value in [('12','font-weight','bold'),('7','font-style','italic')]:
            spans = root.xpath('.//text:span', namespaces=NS)
            spans = [s for s in spans if visible(s) == target]
            require(len(spans) == 1 and style_properties(root,spans[0],'text-properties').get(q('fo',prop)) == value, 'Split cache style changed for ' + target)
    elif kind == 'toc-after-fields':
        require(kinds == ['page-number','page-count'] and [visible(n) for n in fields] == ['17','99'], 'TOC preceding live field cache changed')
        require(result['paragraphs'] == ['FirstTocSection', 'Page 17 of 99', 'SecondPageContents', 'IntroductionEntry\t3', 'DetailsEntry\t4'], 'TOC title or cached entries changed')
        require(breaks[2] == 'page', 'Leading TOC lost its next-section page break')
    else:
        raise AssertionError('Unknown fixture kind ' + kind)
    return result

def check_positions(words, spec):
    result = {}
    for side, expected in [('left_words',36),('right_words',212)]:
        for text in spec.get(side, []):
            matches = [w for w in words if w['text'] == text]
            require(len(matches) == 1, 'Expected unique visible token ' + text + ': ' + repr(matches))
            require(abs(matches[0]['xMin'] - expected) < 1.5, text + ' is not in expected column: ' + str(matches[0]['xMin']))
            result[text] = matches[0]
    right = [result[s] for s in spec.get('right_words', [])]
    require(all(a['yMin'] < b['yMin'] for a,b in zip(right,right[1:])), 'Right column follower order changed')
    return result

def check_consumer(spec, output, pages, native_pages=None):
    name = spec['name']
    require(len(pages) == len(spec['page_sizes_pt']), 'Unexpected PDF page count')
    for page, size in zip(pages, spec['page_sizes_pt']):
        require(abs(page['width'] - size[0]) < .2 and abs(page['height'] - size[1]) < .2, 'Page geometry changed')
    docx = output / 'converted' / (name + '.docx')
    root = read_part(docx, 'word/document.xml')
    p = root.xpath('//w:body//w:p', namespaces=NS)
    texts = [docx_visible(n) for n in p]
    instructions = [' '.join((n.text or '').split()) for n in root.xpath('//w:instrText',namespaces=NS)]
    result = {'page_sizes_pt': [[x['width'],x['height']] for x in pages], 'reopened_paragraphs': texts, 'reopened_instructions': instructions}
    kind = spec['kind']
    if kind in ('empty-field-column','runless-leading-column','plain-leading-column'):
        result['column_positions'] = check_positions(pages[0]['words'], spec)
        expected_instruction = 'PAGE' if kind == 'runless-leading-column' or spec.get('field') == 'page-number' else 'NUMPAGES'
        if kind == 'plain-leading-column':
            require(not instructions, 'Plain control unexpectedly gained a field')
        else:
            require(sum(i == expected_instruction for i in instructions) == 1, 'Reopened native field missing or duplicated')
        for word in spec['right_words']:
            require(sum(word in t for t in texts) == 1, 'Reopened destination/follower missing or duplicated: ' + word)
        if kind == 'runless-leading-column':
            starts=root.xpath('//w:bookmarkStart[@w:name=$name]',namespaces=NS,name=spec['bookmark'])
            require(len(starts)==1, 'Reopened bookmark missing')
            require(len(root.xpath('//w:bookmarkEnd[@w:id=$id]',namespaces=NS,id=starts[0].get(q('w','id'))))==1,'Reopened bookmark not paired')
        if native_pages is not None:
            require(len(native_pages)==1,'Native serialized reference changed page count')
            result['native_serializer_positions']=check_positions(native_pages[0]['words'], spec)
    elif kind == 'styled-linked-fields':
        words=[w['text'] for x in pages for w in x['words']]
        require('17' not in words and '99' not in words and '23' in words, 'PDF native values failed to refresh or locked literal changed')
        first=''.join(w['text'] for w in pages[0]['words'])
        require('Page1of2' in first and 'Locked23' in first, 'PDF field/literal phrase changed')
        require('SecondFieldPage' in [w['text'] for w in pages[1]['words']], 'Second page content misplaced')
        with fitz.open(output/'converted'/(name+'.pdf')) as pdf:
            spans=[s for b in pdf[0].get_text('dict')['blocks'] if 'lines' in b for line in b['lines'] for s in line['spans']]
            evidence=[]
            for text,color,flag in [('1',0x123456,16),('2',0xAA0000,2)]:
                found=[s for s in spans if s['text'].strip()==text and s['color']==color and s['flags'] & flag]
                require(len(found)==1,'Visible PDF field style did not survive: '+text)
                evidence.append(found[0])
            result['visible_pdf_field_styles']=evidence
        require(sorted(instructions)==['NUMPAGES','PAGE'], 'Reopened field instructions changed')
        relationships=read_part(docx,'word/_rels/document.xml.rels')
        targets={r.get('Id'):r.get('Target') for r in relationships}
        links=[]
        for link in root.xpath('//w:hyperlink',namespaces=NS):
            target=targets.get(link.get(q('r','id')))
            if target in ('https://example.test/page','https://example.test/count'):
                links.append({'target':target,'cache':docx_visible(link),'instructions':[' '.join((n.text or '').split()) for n in link.xpath('.//w:instrText',namespaces=NS)],'xml':etree.tostring(link).decode()})
        require(sorted((x['target'],x['cache'],x['instructions']) for x in links)==[('https://example.test/count','2',['NUMPAGES']),('https://example.test/page','1',['PAGE'])], 'Reopened hyperlinks/live field cache changed')
        result['reopened_linked_fields']=links
        result['docx_style_scope_note']='LibreOffice preserves PAGE bold/color on its field-begin run; the DOCX cached-result run may use defaults. The independent PDF preserves visible PAGE styling. No claim of full cached-result-run style retention in DOCX.'
    elif kind == 'split-cache-fallback':
        require(not instructions and texts==spec['exact_paragraphs'], 'Reopened literal caches or exact whitespace changed')
        for token,tag in [('12','b'),('7','i')]:
            runs=[r for r in root.xpath('//w:r',namespaces=NS) if docx_visible(r)==token]
            require(len(runs)==1 and runs[0].find('w:rPr/w:'+tag,NS) is not None,'Reopened split style changed '+token)
    elif kind == 'toc-after-fields':
        require('FirstTocSection' in [w['text'] for w in pages[0]['words']], 'First section text moved')
        require('Page1of2' in ''.join(w['text'] for w in pages[0]['words']), 'TOC document live fields failed to refresh')
        second=[w['text'] for w in pages[1]['words']]
        require(all(t in second for t in ['SecondPageContents','IntroductionEntry','DetailsEntry','3','4']), 'TOC entry cache or second-page placement changed')
        require(sorted(instructions)==['NUMPAGES','PAGE'], 'TOC reopened preceding fields changed')
        require(any(t=='IntroductionEntry\t3' for t in texts) and any(t=='DetailsEntry\t4' for t in texts), 'Reopened TOC literal entries changed')
    return result
