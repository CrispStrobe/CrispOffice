import 'dart:convert';
import 'dart:io';

// ignore: depend_on_referenced_packages
import 'package:quds_office_engine/quds_office_engine.dart';
import '../runner-source/make_fixtures.dart' as historical;

void main(List<String> arguments) {
  // The prior 24 fixtures and all their numerical expectations are unchanged.
  historical.main(arguments);
  final directory = Directory(arguments.single);
  final manifest = File('${directory.path}/fixtures.json');
  final records = (jsonDecode(manifest.readAsStringSync()) as List)
      .cast<Map<String, dynamic>>();

  void save(String name, WmlDocument document, Map<String, Object?> spec) {
    File(
      '${directory.path}/$name.odt',
    ).writeAsBytesSync(OdtDocumentWriter.writeBytes(document));
    records.add({'name': name, 'file': '$name.odt', ...spec});
  }

  const size = WmlPageSize(width: 400, height: 500);
  const margins = WmlPageMargins(top: 36, bottom: 36, left: 36, right: 36);
  WmlParagraph painted(String text, String? fill, String? border) =>
      WmlParagraph(
        properties: WmlParagraphProps(shadingFill: fill, borderColor: border),
        inlines: [WmlRun(text: text)],
      );
  save(
    'paragraph-distinct-shading-borders',
    WmlDocument(
      sections: [
        WmlSection(
          pageSize: size,
          margins: margins,
          blocks: [
            painted('RedShade', 'FF0000', '0000FF'),
            painted('GreenShade', '00FF00', 'FF00FF'),
            painted('PlainUnshaded', null, null),
          ],
        ),
      ],
    ),
    {
      'page_sizes_pt': [
        [400, 500],
      ],
      'word_pages': {'RedShade': 1, 'GreenShade': 1, 'PlainUnshaded': 1},
      'vertical_order': ['RedShade', 'GreenShade', 'PlainUnshaded'],
      'paragraph_decorations': {
        'RedShade': {'fill': 'FF0000', 'border': '0000FF'},
        'GreenShade': {'fill': '00FF00', 'border': 'FF00FF'},
        'PlainUnshaded': {'fill': null, 'border': null},
      },
      'scope':
          'Adjacent paragraphs retain independent fills and borders; '
          'unshaded content stays unshaded in independently reopened DOCX.',
    },
  );
  save(
    'page-field-styled-footer',
    WmlDocument(
      sections: [
        WmlSection(
          pageSize: size,
          margins: margins,
          linkToPrevious: false,
          blocks: [
            WmlParagraph(inlines: [WmlRun(text: 'FirstBody')]),
            WmlParagraph(
              properties: WmlParagraphProps(pageBreakBefore: true),
              inlines: [WmlRun(text: 'SecondBody')],
            ),
          ],
          footer: [
            WmlParagraph(
              properties: WmlParagraphProps(pageNumberField: true),
              inlines: [
                WmlRun(
                  text: '1  |  Al Tahreer Neighborhood Profile',
                  properties: WmlRunProps(
                    bold: true,
                    color: '0000FF',
                    fontSizeHalfPoints: 28,
                  ),
                ),
              ],
            ),
          ],
        ),
      ],
    ),
    {
      'page_sizes_pt': [
        [400, 500],
        [400, 500],
      ],
      'word_pages': {'FirstBody': 1, 'SecondBody': 2},
      'styled_footer': {
        'suffix': '| Al Tahreer Neighborhood Profile',
        'page_numbers': [1, 2],
        'bold': true,
        'color': '0000FF',
        'font_size_half_points': 28,
      },
      'scope':
          'Live footer PAGE field renders 1 and 2 with the entire authored '
          'title suffix; field and suffix retain bold blue 14pt styling.',
    },
  );
  WmlParagraph text(String value) => WmlParagraph(inlines: [WmlRun(text: value)]);
  save(
    'custom-tabs-independent-positions',
    WmlDocument(sections: [WmlSection(pageSize: size, margins: margins, blocks: [
      text('TabsSection'),
      WmlParagraph(properties: WmlParagraphProps(tabs: [WmlTabStop(position: 72)]), inlines: [WmlRun(text: 'NearLabel\tNearValue')]),
      WmlParagraph(properties: WmlParagraphProps(tabs: [WmlTabStop(position: 144)]), inlines: [WmlRun(text: 'FarLabel\tFarValue')]),
    ])]),
    {
      'page_sizes_pt': [[400, 500]],
      'word_pages': {'TabsSection': 1, 'NearLabel': 1, 'NearValue': 1, 'FarLabel': 1, 'FarValue': 1},
      'vertical_order': ['TabsSection', 'NearValue', 'FarValue'],
      'tab_positions': {
        'NearValue': {'position_pt': 72, 'page_left_pt': 108},
        'FarValue': {'position_pt': 144, 'page_left_pt': 180},
      },
      'scope': 'Independent PDF text placement and reopened DOCX retain distinct authored custom tabs for otherwise equal paragraphs.',
    },
  );
  save(
    'table-minimum-row-grows',
    WmlDocument(sections: [WmlSection(pageSize: size, margins: margins, blocks: [
      text('MinimumSection'),
      WmlTable(grid: [328], rows: [WmlTableRow(height: 6, cells: [WmlTableCell(
        fillColor: 'cCeEfF', borderTop: true, borderBottom: true, borderLeft: true, borderRight: true,
        blocks: [text('RowTop'), text('RowMiddle'), text('RowBottom')],
      )])]),
      text('AfterTable'),
    ])]),
    {
      'page_sizes_pt': [[400, 500]],
      'word_pages': {'MinimumSection': 1, 'RowTop': 1, 'RowMiddle': 1, 'RowBottom': 1, 'AfterTable': 1},
      'vertical_order': ['MinimumSection', 'RowTop', 'RowMiddle', 'RowBottom', 'AfterTable'],
      'minimum_row': {'minimum_pt': 6, 'words': ['RowTop', 'RowMiddle', 'RowBottom']},
      'scope': 'A six-point minimum row grows around three authored lines in an independent consumer and remains non-fixed in reopened DOCX.',
    },
  );
  save(
    'table-invalid-properties-preserve-content',
    WmlDocument(sections: [WmlSection(pageSize: size, margins: margins, blocks: [
      text('InvalidSection'),
      WmlTable(grid: [double.nan], rows: [
        WmlTableRow(height: double.nan, cells: [WmlTableCell(fillColor: 'auto', borderRight: true, blocks: [text('InvalidOne')])]),
        WmlTableRow(height: -1, cells: [WmlTableCell(fillColor: 'invalid"color', borderRight: true, blocks: [text('InvalidTwo')])]),
        WmlTableRow(height: double.infinity, cells: [WmlTableCell(fillColor: '#FF0000', borderRight: true, blocks: [text('InvalidThree')])]),
      ]),
    ])]),
    {
      'page_sizes_pt': [[400, 500]],
      'word_pages': {'InvalidSection': 1, 'InvalidOne': 1, 'InvalidTwo': 1, 'InvalidThree': 1},
      'vertical_order': ['InvalidSection', 'InvalidOne', 'InvalidTwo', 'InvalidThree'],
      'invalid_cells': ['InvalidOne', 'InvalidTwo', 'InvalidThree'],
      'scope': 'Invalid dimensions and fill strings are omitted while source cell text and valid right borders remain visible and the ODF package validates.',
    },
  );
  save(
    'section-columns-explicit-break',
    WmlDocument(sections: [WmlSection(
      pageSize: size, margins: margins, columnCount: 2, columnSpace: 24,
      blocks: [
        text('LeftColumn'),
        WmlParagraph(properties: WmlParagraphProps(
          columnBreakBefore: true, keepTogether: true,
        ), inlines: [WmlRun(text: 'RightColumn')]),
        text('RightFollower'),
      ],
    )]),
    {
      'page_sizes_pt': [[400, 500]],
      'word_pages': {'LeftColumn': 1, 'RightColumn': 1, 'RightFollower': 1},
      'column_geometry': {'count': 2, 'gap_pt': 24,
        'words': {'LeftColumn': 36, 'RightColumn': 212, 'RightFollower': 212}},
      'keep_together': {'LeftColumn': false, 'RightColumn': true, 'RightFollower': false},
      'scope': 'A two-column section keeps its authored gap and explicit column break in an independent PDF; neighboring paragraphs retain independent keep-together values in reopened DOCX.',
    },
  );
  save(
    'paragraph-keep-isolation-reverse',
    WmlDocument(sections: [WmlSection(pageSize: size, margins: margins, blocks: [
      WmlParagraph(properties: WmlParagraphProps(keepTogether: true), inlines: [WmlRun(text: 'KeepFirst')]),
      text('PlainAfterKeep'),
      WmlParagraph(properties: WmlParagraphProps(keepTogether: true), inlines: [WmlRun(text: 'KeepLast')]),
    ])]),
    {
      'page_sizes_pt': [[400, 500]],
      'word_pages': {'KeepFirst': 1, 'PlainAfterKeep': 1, 'KeepLast': 1},
      'vertical_order': ['KeepFirst', 'PlainAfterKeep', 'KeepLast'],
      'keep_together': {'KeepFirst': true, 'PlainAfterKeep': false, 'KeepLast': true},
      'scope': 'A keep-together paragraph followed by a plain paragraph and another kept paragraph remains distinct in independently reopened DOCX.',
    },
  );
  WmlDocument importedColumnDocument(String name, String body) {
    const wml = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
    final package = OpcPackage.create(OpcPackageKind.word);
    // Independently authored Word XML: the break is a run child, not a
    // constructor flag or output from the Word serializer under test.
    package.getPart('/word/document.xml')!.writeText('''<w:document xmlns:w="$wml"><w:body>
$body
<w:sectPr><w:pgSz w:w="8000" w:h="10000"/>
<w:pgMar w:top="720" w:bottom="720" w:left="720" w:right="720"/>
<w:cols w:num="2" w:space="480"/></w:sectPr>
</w:body></w:document>''');
    final bytes = package.save();
    File('${directory.path}/$name.source.docx').writeAsBytesSync(bytes);
    final document = WordDeserializer().read(OpcPackage.openBytes(bytes));
    final paragraphs = document.sections.single.blocks.whereType<WmlParagraph>().toList();
    final breaks = paragraphs.expand((p) => p.inlines).whereType<WmlBreak>().where((b) => b.type == WmlBreakType.column).length;
    if (breaks != 1 || paragraphs.any((p) => p.properties.columnBreakBefore)) {
      throw StateError('Fixture no longer exercises exactly one imported inline column break.');
    }
    return document;
  }
  const leadingName = 'docx-leading-inline-column-break';
  save(leadingName, importedColumnDocument(leadingName, '''
<w:p><w:r><w:t>ImportedLeadLeft</w:t></w:r></w:p>
<w:p><w:pPr><w:keepLines/></w:pPr><w:r><w:br w:type="column"/><w:t>ImportedLeadRight</w:t></w:r></w:p>
<w:p><w:r><w:t>ImportedLeadFollower</w:t></w:r></w:p>'''), {
    'page_sizes_pt': [[400, 500]],
    'word_pages': {'ImportedLeadLeft': 1, 'ImportedLeadRight': 1, 'ImportedLeadFollower': 1},
    'imported_column_break': {
      'kind': 'leading', 'count': 2, 'gap_pt': 24,
      'words': {'ImportedLeadLeft': 36, 'ImportedLeadRight': 212, 'ImportedLeadFollower': 212},
      'after_word': 'ImportedLeadRight', 'follower_word': 'ImportedLeadFollower',
    },
    'keep_together': {'ImportedLeadLeft': false, 'ImportedLeadRight': true, 'ImportedLeadFollower': false},
    'scope': 'Raw DOCX run-child leading column break imports as an inline model node and independently renders in the right ODT column without leaking into the following plain paragraph.',
  });
  const midName = 'docx-midparagraph-inline-column-break';
  save(midName, importedColumnDocument(midName, '''
<w:p><w:pPr><w:spacing w:before="240" w:after="360"/><w:ind w:firstLine="240"/></w:pPr>
<w:r><w:rPr><w:b/></w:rPr><w:t>ImportedMidBefore</w:t><w:br w:type="column"/></w:r>
<w:r><w:rPr><w:i/></w:rPr><w:t>ImportedMidAfter</w:t></w:r></w:p>
<w:p><w:r><w:t>ImportedMidFollower</w:t></w:r></w:p>'''), {
    'page_sizes_pt': [[400, 500]],
    'word_pages': {'ImportedMidBefore': 1, 'ImportedMidAfter': 1, 'ImportedMidFollower': 1},
    'imported_column_break': {
      'kind': 'midparagraph', 'count': 2, 'gap_pt': 24,
      'words': {'ImportedMidBefore': 48, 'ImportedMidAfter': 212, 'ImportedMidFollower': 212},
      'after_word': 'ImportedMidAfter', 'follower_word': 'ImportedMidFollower',
      'run_styles': {'ImportedMidBefore': 'b', 'ImportedMidAfter': 'i'},
    },
    'scope': 'Raw DOCX midparagraph column break stays at its exact content boundary, preserving bold/italic runs and applying the authored first-line indent only to the first fragment.',
  });
  manifest.writeAsStringSync(
    '${const JsonEncoder.withIndent('  ').convert(records)}\n',
  );
  print(
    'Generated ${records.length} ODT fixtures including nine recovery and reconciliation controls.',
  );
}
