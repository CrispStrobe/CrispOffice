"""Independently reopen raw-DOCX-imported inline column breaks after ODT export."""
from __future__ import annotations

import zipfile
from lxml import etree
from check_recovery_fixtures import W, NS, _resolved_properties, _value, require


def check_inline_breaks(spec, output, pages):
    if 'imported_column_break' not in spec:
        return {}
    name = spec['name']
    expected = spec['imported_column_break']
    with zipfile.ZipFile(output / 'converted' / (name + '.docx')) as archive:
        document = etree.fromstring(archive.read('word/document.xml'))
        style_root = etree.fromstring(archive.read('word/styles.xml'))
    styles = {s.get('{%s}styleId' % W): s for s in style_root.findall('w:style', NS)}
    columns = document.xpath('//w:sectPr/w:cols', namespaces=NS)
    matched = [c for c in columns if int(_value(c, 'num') or '1') == expected['count']]
    require(bool(matched), name + ': imported column count lost in reopened DOCX')
    gap_twips = round(expected['gap_pt'] * 20)
    require(any(int(_value(c, 'space') or '0') == gap_twips for c in matched),
            name + ': imported column gap lost in reopened DOCX')
    positions = {}
    for word, x in expected['words'].items():
        matches = [w for page in pages for w in page['words'] if w['text'] == word]
        require(len(matches) == 1, name + ': missing/duplicate imported word ' + word)
        observed = matches[0]
        require(abs(observed['xMin'] - x) <= .4,
                name + ': ' + word + ' at ' + str(observed['xMin']) + ', expected ' + str(x))
        positions[word] = observed
    after = positions[expected['after_word']]
    follower = positions[expected['follower_word']]
    require(follower['yMin'] > after['yMin'], name + ': following paragraph did not stay below the continuation')
    retained_styles = {}
    for word, required in expected.get('run_styles', {}).items():
        paragraphs = document.xpath('//w:p[.//w:t[text()=$word]]', namespaces=NS, word=word)
        require(len(paragraphs) == 1, name + ': ambiguous reopened styled paragraph ' + word)
        runs = paragraphs[0].xpath('.//w:r[w:t[text()=$word]]', namespaces=NS, word=word)
        require(len(runs) == 1, name + ': missing/ambiguous reopened styled run ' + word)
        props = _resolved_properties(paragraphs[0], styles, 'rPr', run=runs[0],
            defaults=style_root.find('w:docDefaults/w:rPrDefault/w:rPr', NS))
        value = props.get(required)
        require(value is not None and _value(value) not in ('0', 'false', 'off'),
                name + ': authored run style lost for ' + word)
        retained_styles[word] = required
    return {'independent_imported_column_break': {
        'kind': expected['kind'], 'positions': positions, 'gap_twips': gap_twips,
        'run_styles': retained_styles, 'horizontal_tolerance_pt': .4,
    }}
