#!/usr/bin/env python3
"""Reproduce the unchanged official-schema false negative and discriminating controls."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request
from lxml import etree

HERE=Path(__file__).resolve().parent
OUT=HERE/'schema-controls'
NS={'text':'urn:oasis:names:tc:opendocument:xmlns:text:1.0','xlink':'http://www.w3.org/1999/xlink'}
def digest(payload): return hashlib.sha256(payload).hexdigest()
def main():
    OUT.mkdir(exist_ok=False)
    downloads=[
      ('OpenDocument-v1.3-schema.rng','https://docs.oasis-open.org/office/OpenDocument/v1.3/os/schemas/OpenDocument-v1.3-schema.rng','40bad03efdbb02825230d357da0aa6ac679934c5bf56c6281752c0c24d58e4e6'),
      ('OpenDocument-v1.3-manifest-schema.rng','https://docs.oasis-open.org/office/OpenDocument/v1.3/os/schemas/OpenDocument-v1.3-manifest-schema.rng','8aee71f03484be112af972d622cc9031280c007b0a454ae8815e8e333c9bdd17'),
      ('jing-20241231.jar.sha1','https://repo.maven.apache.org/maven2/org/relaxng/jing/20241231/jing-20241231.jar.sha1',None),
      ('jing-20241231.pom','https://repo.maven.apache.org/maven2/org/relaxng/jing/20241231/jing-20241231.pom',None),
    ]
    def fetch(item):
        name,url,expected=item
        with urllib.request.urlopen(url,timeout=45) as response: payload=response.read()
        (OUT/name).write_bytes(payload)
        actual=digest(payload)
        assert expected is None or actual==expected,(name,actual)
        return {'file':name,'url':url,'bytes':len(payload),'sha256':actual,'expected_sha256':expected}
    with ThreadPoolExecutor(max_workers=4) as pool: receipts=list(pool.map(fetch,downloads))
    jar=HERE/'tools/jing-20241231.jar'
    assert digest(jar.read_bytes())=='ea5e9026244d977e607d8b52212d6871498ece51939f9c49d0e7a77aad91133a'
    assert hashlib.sha1(jar.read_bytes()).hexdigest()==(OUT/'jing-20241231.jar.sha1').read_text().strip()
    schema=HERE/'schemas/OpenDocument-v1.3-schema.rng'
    assert schema.read_bytes()==(OUT/schema.name).read_bytes()
    original=(HERE/'schema-oracle/content.xml').read_bytes()
    base=etree.fromstring(original)
    linked=deepcopy(base)
    count=linked.xpath('//text:page-count',namespaces=NS)[0]
    owner=count.getparent(); offset=owner.index(count); owner.remove(count)
    link=etree.Element('{'+NS['text']+'}a')
    link.set('{'+NS['xlink']+'}href','https://example.test/count'); link.set('{'+NS['xlink']+'}type','simple')
    link.append(count); owner.insert(offset,link)
    child=deepcopy(base); field=child.xpath('//text:page-count',namespaces=NS)[0]
    field.append(etree.Element('{'+NS['text']+'}span'))
    attr=deepcopy(base); attr.xpath('//text:page-count',namespaces=NS)[0].set('{'+NS['text']+'}not-a-field-attribute','invalid')
    cases=[('unchanged-styled-page-count',original,True),('linked-styled-page-count',etree.tostring(linked),True),
           ('invalid-field-child-span',etree.tostring(child),False),('invalid-field-attribute',etree.tostring(attr),False)]
    results=[]
    validator=etree.RelaxNG(etree.parse(str(schema)))
    for name,payload,expected in cases:
        path=OUT/(name+'.xml'); path.write_bytes(payload)
        command=['java','-jar',str(jar),'-i',str(schema),str(path)]
        run=subprocess.run(command,capture_output=True,timeout=30)
        (OUT/(name+'.stdout')).write_bytes(run.stdout); (OUT/(name+'.stderr')).write_bytes(run.stderr)
        valid=validator.validate(etree.fromstring(payload))
        result={'name':name,'expected_valid':expected,'jing_valid':run.returncode==0,'jing_exit_code':run.returncode,'lxml_valid':valid,
          'lxml_errors':str(validator.error_log),'input_sha256':digest(payload),'command':command}
        assert result['jing_valid']==expected,result
        results.append(result)
    result={'passed':True,'original_artifact_source':'e3a38789359adaa33b2da1345c952fa1c2d8aebb:docs/validation/proofing-office-followup-20261117/evidence/toc-fields.odt.gz',
      'official_schema_unchanged':True,'schema_sha256':digest(schema.read_bytes()),'downloads':receipts,'controls':results,
      'jing':{'version':'20241231','url':'https://repo.maven.apache.org/maven2/org/relaxng/jing/20241231/jing-20241231.jar','bytes':jar.stat().st_size,'sha256':digest(jar.read_bytes()),'publisher_sha1':hashlib.sha1(jar.read_bytes()).hexdigest(),
        'license_url':'https://raw.githubusercontent.com/relaxng/jing-trang/V20241231/copying.txt','license_sha256':digest((HERE/'tools/JING-COPYING.txt').read_bytes()),
        'option_i':'Disables optional RELAX NG DTD Compatibility ID/IDREF/IDREFS checks; ordinary RelaxNG grammar validation stays enabled. Invalid child/attribute controls both reject.',
        'documentation':'https://relaxng.org/jclark/jing.html'},
      'odf_prose':'https://docs.oasis-open.org/office/OpenDocument/v1.3/os/part3-schema/OpenDocument-v1.3-os-part3-schema.html',
      'odf_clause':'7.5.18.2 permits page-count in text:span and text:a.',
      'lxml_version':etree.LXML_VERSION,'libxml_version':etree.LIBXML_VERSION,
      'finding':'The unchanged original valid styled page count is rejected by this libxml2 build and accepted by independent Jing against the byte-identical official grammar. No production style/link fallback or altered validation schema is justified.'}
    (OUT/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'passed':True,'controls':len(results),'jing_sha256':result['jing']['sha256']}))
if __name__=='__main__': main()
