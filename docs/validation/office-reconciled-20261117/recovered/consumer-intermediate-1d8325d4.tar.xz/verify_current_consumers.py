#!/usr/bin/env python3
"""Frozen-source current field/TOC/leading-column independent consumer qualification."""
import argparse
import gzip
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile
from lxml import etree
import fitz
import pymupdf

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'wave3-runner'))
import verify_consumers as base
from check_current_consumers import check_raw, check_consumer

JING_SHA256='ea5e9026244d977e607d8b52212d6871498ece51939f9c49d0e7a77aad91133a'

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('output','schemas','dart','repo','source-repo'):
        parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--expected-head',required=True)
    args=parser.parse_args()
    output,schemas,dart,repo,source=[p.resolve() for p in (args.output,args.schemas,args.dart,args.repo,args.source_repo)]
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source).decode().strip()
    base.require(head==args.expected_head,'Frozen source HEAD mismatch')
    base.require(not subprocess.check_output(['git','diff','--name-only',head,'--','packages/quds_office_engine/lib','packages/legacy_doc_parser/lib'],cwd=source),'Frozen production source is dirty')
    base.require(not output.exists(),'Output must be fresh')
    for folder in ('logs','converted','rasters','tmp','schema-inputs'):
        (output/folder).mkdir(parents=True,exist_ok=True)
    commands=[]
    receipt={'started_at_utc':base.now(),'source_head':head,'source_repository':str(source),'source_root':str(repo),
        'source_tree':subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=source).decode().strip(),
        'scope':'Seven disjoint current field/cache/style/link/TOC/leading-column fixtures; original33 retained separately unchanged.',
        'schema_oracle':'Unmodified official OASIS ODF1.3 RNG validated by Jing20241231 -i. lxml/libxml2 outcomes retained as diagnostics, including known valid page-count false negatives.',
        'oracle_correction':'Initial pre-reset runless PAGE-left expectation withdrawn. Model fixture uses existing generated-cache order after break, confirmed by actual WordSerializer native DOCX. Distinct raw host no-cache envelope is documented separately.',
        'github_actions_queried_or_awaited':False,'fixtures':[],'commands':commands}
    env=dict(os.environ,TMPDIR=str(output/'tmp'),DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true',CI='true',PYTHONDONTWRITEBYTECODE='1')
    def run(argv,label,*,timeout=120,allow_failure=False):
        started=time.monotonic(); result=subprocess.run([str(a) for a in argv],cwd=repo,env=env,capture_output=True,timeout=timeout)
        (output/'logs'/(label+'.stdout.log')).write_bytes(result.stdout)
        (output/'logs'/(label+'.stderr.log')).write_bytes(result.stderr)
        commands.append({'argv':[str(a) for a in argv],'cwd':str(repo),'exit_code':result.returncode,'duration_seconds':round(time.monotonic()-started,3),'label':label})
        base.require(allow_failure or result.returncode==0,label+' failed: '+result.stderr.decode(errors='replace'))
        return result
    def source_inputs():
        return base.source_inputs(repo)+[HERE/'make_current_fixtures.dart',HERE/'check_current_consumers.py',Path(__file__).resolve()]
    def runtime_inputs():
        java=Path(shutil.which('java'))
        extra=base.all_files(Path(fitz.__file__).parent)+base.all_files(Path(pymupdf.__file__).parent)
        return base.runtime_inputs(dart,schemas,repo)+[java,java.resolve(),HERE/'tools/jing-20241231.jar']+[p for p in extra if '__pycache__' not in p.parts]
    def write_inputs(name,source_map,runtime_map):
        with gzip.GzipFile(filename=str(output/name),mode='wb',mtime=0) as target:
            target.write(json.dumps({'source':source_map,'runtime':runtime_map},indent=2).encode())
    try:
        for name,expected in base.SCHEMAS.items():
            base.require(base.digest(schemas/name)==expected,'Official schema bytes differ '+name)
        jar=HERE/'tools/jing-20241231.jar'
        base.require(base.digest(jar)==JING_SHA256,'Jing binary differs from pinned official release')
        for name in ('quds_office_engine','legacy_doc_parser'):
            base.require((repo/'packages'/name/'lib').resolve()==(source/'packages'/name/'lib').resolve(),'Source package binding mismatch '+name)
        source_before=base.snapshot(source_inputs()); runtime_before=base.snapshot(runtime_inputs())
        write_inputs('inputs.json.gz',source_before,runtime_before)
        receipt['input_counts']={'source':len(source_before),'runtime':len(runtime_before)}
        receipt['versions']={tool:run([tool,arg],tool+'-version').stdout.decode()+commands[-1].get('unused','') for tool,arg in [('soffice','--version'),('pdftotext','-v'),('pdfinfo','-v')]}
        run(['java','-version'],'java-version'); run([dart,'--version'],'dart-version')
        receipt['lxml_version']=etree.LXML_VERSION; receipt['libxml_version']=etree.LIBXML_VERSION
        run([dart,'--packages='+str(repo/'.dart_tool/package_config.json'),HERE/'make_current_fixtures.dart',output/'fixtures'],'generate-fixtures')
        specs=json.loads((output/'fixtures/fixtures.json').read_text())
        base.require(len(specs)==7 and len({s['name'] for s in specs})==7,'Expected seven unique current fixtures')
        inventory=base.snapshot(base.all_files(output/'fixtures')); receipt['fixture_inventory']=inventory
        schema_results={}
        validators={False:etree.RelaxNG(etree.parse(str(schemas/'OpenDocument-v1.3-schema.rng'))),True:etree.RelaxNG(etree.parse(str(schemas/'OpenDocument-v1.3-manifest-schema.rng')))}
        for spec in specs:
            result={'jing_passed_parts':[],'jing_failures':[],'lxml_diagnostics':[]}
            with zipfile.ZipFile(output/'fixtures'/spec['file']) as archive:
                base.require(archive.testzip() is None,'ZIP CRC failure '+spec['name'])
                for part in ('content.xml','styles.xml','meta.xml','META-INF/manifest.xml'):
                    dest=output/'schema-inputs'/spec['name']/part; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(archive.read(part))
                    manifest=part.startswith('META-INF'); schema=schemas/('OpenDocument-v1.3-manifest-schema.rng' if manifest else 'OpenDocument-v1.3-schema.rng')
                    check=run(['java','-jar',jar,'-i',schema,dest],spec['name']+'-jing-'+part.replace('/','-'),allow_failure=True)
                    if check.returncode==0: result['jing_passed_parts'].append(part)
                    else: result['jing_failures'].append({'part':part,'exit_code':check.returncode,'stderr':check.stderr.decode(errors='replace'),'stdout':check.stdout.decode(errors='replace')})
                    validator=validators[manifest]; valid=validator.validate(etree.fromstring(archive.read(part)))
                    result['lxml_diagnostics'].append({'part':part,'valid':valid,'errors':str(validator.error_log) if not valid else ''})
            schema_results[spec['name']]=result
        inputs=[output/'fixtures'/s['file'] for s in specs]
        native_inputs=sorted((output/'fixtures').glob('*.source.docx'))
        run(['soffice','-env:UserInstallation='+(output/'profile-pdf').as_uri(),'--headless','--convert-to','pdf:writer_pdf_Export:{"IsSkipEmptyPages":{"type":"boolean","value":"false"}}','--outdir',output/'converted',*inputs,*native_inputs],'libreoffice-pdf')
        run(['soffice','-env:UserInstallation='+(output/'profile-docx').as_uri(),'--headless','--convert-to','docx','--outdir',output/'converted',*inputs],'libreoffice-docx')
        for spec in specs:
            name=spec['name']; result={'name':name,'schema':schema_results[name],'errors':[]}; receipt['fixtures'].append(result)
            try: result['raw_odf']=check_raw(spec,output/'fixtures'/spec['file'])
            except Exception as error: result['errors'].append({'scope':'raw_odf','error':str(error)})
            try:
                pdf=output/'converted'/(name+'.pdf')
                run(['pdftotext','-layout',pdf,output/'converted'/(name+'.txt')],name+'-text')
                bbox=output/'converted'/(name+'.bbox.xhtml'); run(['pdftotext','-bbox',pdf,bbox],name+'-bbox'); pages=base.page_words(bbox)
                native_pages=None
                if (output/'fixtures'/(name+'.source.docx')).exists():
                    nbbox=output/'converted'/(name+'.source.bbox.xhtml')
                    run(['pdftotext','-bbox',output/'converted'/(name+'.source.pdf'),nbbox],name+'-native-bbox')
                    native_pages=base.page_words(nbbox)
                result['consumer']=check_consumer(spec,output,pages,native_pages)
            except Exception as error: result['errors'].append({'scope':'independent_consumer','error':str(error)})
            if schema_results[name]['jing_failures']: result['errors'].append({'scope':'schema','error':'Jing rejected XML part(s)'})
            result['passed']=not result['errors']
            for page in range(1,len(spec['page_sizes_pt'])+1):
                run(['pdftoppm','-f',str(page),'-singlefile','-r','96','-png',output/'converted'/(name+'.pdf'),output/'rasters'/(name+'-page'+str(page))],name+'-raster'+str(page))
        source_after=base.snapshot(source_inputs()); runtime_after=base.snapshot(runtime_inputs())
        write_inputs('inputs-after.json.gz',source_after,runtime_after)
        receipt['source_unchanged']=source_before==source_after; receipt['runtime_unchanged']=runtime_before==runtime_after
        receipt['fixtures_unchanged']=inventory==base.snapshot(base.all_files(output/'fixtures'))
        receipt['head_unchanged']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source).decode().strip()==head
        receipt['summary']={'fixtures':7,'passed':sum(r['passed'] for r in receipt['fixtures']),'failed':sum(not r['passed'] for r in receipt['fixtures']),
            'schema_parts_passed':sum(len(s['jing_passed_parts']) for s in schema_results.values()),'schema_parts_total':28,
            'lxml_false_negatives':sum(not d['valid'] for s in schema_results.values() for d in s['lxml_diagnostics'])}
        receipt['passed']=all(r['passed'] for r in receipt['fixtures']) and all(receipt[k] for k in ('source_unchanged','runtime_unchanged','fixtures_unchanged','head_unchanged'))
    except Exception as error:
        receipt.update(passed=False,fatal_error=repr(error))
    finally:
        receipt['finished_at_utc']=base.now()
        receipt['output_hashes']={str(p.relative_to(output)):base.digest(p) for folder in ('fixtures','logs','converted','rasters','schema-inputs') for p in base.all_files(output/folder)}
        if (output/'inputs.json.gz').exists(): receipt['inputs_sha256']=base.digest(output/'inputs.json.gz')
        base.json_write(output/'receipt.json',receipt)
    print(json.dumps({k:receipt.get(k) for k in ('passed','summary','fatal_error')},indent=2))
    for result in receipt['fixtures']:
        if not result['passed']: print(result['name'],result['errors'])
    return 0 if receipt.get('passed') else 1

if __name__=='__main__':
    sys.exit(main())
