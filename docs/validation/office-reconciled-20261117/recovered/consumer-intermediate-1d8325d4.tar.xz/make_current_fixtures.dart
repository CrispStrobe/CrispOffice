import 'dart:convert';
import 'dart:io';

// ignore: depend_on_referenced_packages
import 'package:quds_office_engine/quds_office_engine.dart';

const size = WmlPageSize(width: 400, height: 500);
const margins = WmlPageMargins(top: 36, bottom: 36, left: 36, right: 36);

List<WmlInline> field(String instruction, List<WmlRun> cache) => [
  WmlFieldBoundary(kind: WmlFieldBoundaryKind.begin),
  WmlFieldBoundary(
    kind: WmlFieldBoundaryKind.instruction,
    text: ' $instruction ',
  ),
  WmlFieldBoundary(kind: WmlFieldBoundaryKind.separate),
  ...cache,
  WmlFieldBoundary(kind: WmlFieldBoundaryKind.end),
];

WmlParagraph text(String value) => WmlParagraph(inlines: [WmlRun(text: value)]);

WmlDocument document(List<WmlBlock> blocks, {bool columns = false}) =>
    WmlDocument(
      sections: [
        WmlSection(
          pageSize: size,
          margins: margins,
          columnCount: columns ? 2 : 1,
          columnSpace: 24,
          blocks: blocks,
        ),
      ],
    );

Object modelState(WmlDocument doc) => doc.sections
    .map(
      (s) => {
        'columns': s.columnCount,
        'blocks': s.blocks
            .map(
              (b) => b is WmlParagraph
                  ? {
                      'page': b.properties.pageNumberField,
                      'column': b.properties.columnBreakBefore,
                      'inlines': b.inlines
                          .map(
                            (i) => switch (i) {
                              WmlRun() => [
                                'run',
                                i.text,
                                i.fieldInstruction,
                                i.fieldLocked,
                                i.hyperlink?.url,
                                i.properties.bold,
                                i.properties.italic,
                                i.properties.color,
                              ],
                              WmlBreak() => ['break', i.type.toString()],
                              WmlFieldBoundary() => [
                                'field',
                                i.kind.toString(),
                                i.text,
                              ],
                              WmlBookmarkBoundary() => [
                                'bookmark',
                                i.id,
                                i.isStart,
                                i.name,
                              ],
                              _ => [i.runtimeType.toString()],
                            },
                          )
                          .toList(),
                    }
                  : b is WmlToc
                  ? {
                      'toc': b.title,
                      'entries': b.entries
                          .map(
                            (e) => [
                              e.text,
                              e.level,
                              e.headingParagraphIndex,
                              e.pageNumber,
                            ],
                          )
                          .toList(),
                    }
                  : {'type': b.runtimeType.toString()},
            )
            .toList(),
      },
    )
    .toList();

void main(List<String> arguments) {
  final output = Directory(arguments.single)..createSync(recursive: true);
  final specs = <Map<String, Object?>>[];
  void save(
    String name,
    WmlDocument doc,
    Map<String, Object?> spec, {
    bool nativeReference = false,
  }) {
    final before = jsonEncode(modelState(doc));
    File('${output.path}/$name.odt')
        .writeAsBytesSync(OdtDocumentWriter.writeBytes(doc));
    if (before != jsonEncode(modelState(doc))) {
      throw StateError('ODT writer mutated fixture model: $name');
    }
    File('${output.path}/$name.model.json').writeAsStringSync('$before\n');
    if (nativeReference) {
      File('${output.path}/$name.source.docx')
          .writeAsBytesSync(WordSerializer().writeBytes(doc));
    }
    specs.add({
      'name': name,
      'file': '$name.odt',
      'model_unchanged': true,
      'page_sizes_pt': [
        [400, 500],
      ],
      ...spec,
    });
  }

  for (final kind in [
    ('PAGE', 'page', 'AfterEmptyPage', 'EmptyPageFollower'),
    ('NUMPAGES', 'numpages', 'AfterEmptyCount', 'EmptyCountFollower'),
  ]) {
    save(
      'empty-${kind.$2}-before-column',
      document([
        WmlParagraph(
          inlines: [
            ...field(kind.$1, [WmlRun(text: '')]),
            WmlBreak(WmlBreakType.column),
            WmlRun(text: kind.$3),
          ],
        ),
        text(kind.$4),
      ], columns: true),
      {
        'kind': 'empty-field-column',
        'field': kind.$1 == 'PAGE' ? 'page-number' : 'page-count',
        'cache': '',
        'left_words': ['1'],
        'right_words': [kind.$3, kind.$4],
        'scope': 'An admitted native field with an authored empty cache owns content before the following explicit column break.',
      },
    );
  }

  save(
    'runless-bookmarked-page-before-column',
    document([
      WmlParagraph(
        properties: WmlParagraphProps(pageNumberField: true),
        inlines: [
          WmlBookmarkBoundary(id: '13', isStart: true, name: 'RunlessPage'),
          WmlBreak(WmlBreakType.column),
          WmlBookmarkBoundary(id: '13', isStart: false, name: 'RunlessPage'),
        ],
      ),
      text('RunlessPageFollower'),
      text('RunlessSecondFollower'),
    ], columns: true),
    {
      'kind': 'runless-leading-column',
      'left_words': <String>[],
      'right_words': ['1', 'RunlessPageFollower', 'RunlessSecondFollower'],
      'bookmark': 'RunlessPage',
      'scope': 'Current model ordering puts the runless generated PAGE after the break and before the closing bookmark. The cached WordSerializer envelope is the native reference; the distinct empty-cache raw host packet has different native field placement.',
      'oracle_correction': 'The pre-reset first attempt incorrectly expected PAGE left. That expectation is withdrawn; the plain first-leading-column control independently establishes lost-break behavior.',
    },
    nativeReference: true,
  );

  save(
    'styled-linked-single-field-caches',
    document([
      text('FieldSummary'),
      WmlParagraph(
        inlines: [
          WmlRun(text: 'Page '),
          ...field('PAGE', [
            WmlRun(
              text: '17',
              properties: WmlRunProps(bold: true, color: '123456'),
              hyperlink: const WmlHyperlink(url: 'https://example.test/page'),
            ),
          ]),
          WmlRun(text: ' of '),
          ...field('NUMPAGES', [
            WmlRun(
              text: '99',
              properties: WmlRunProps(italic: true, color: 'AA0000'),
              hyperlink: const WmlHyperlink(url: 'https://example.test/count'),
            ),
          ]),
        ],
      ),
      WmlParagraph(
        inlines: [
          WmlRun(text: 'Locked '),
          WmlRun(text: '23', fieldInstruction: 'PAGE', fieldLocked: true),
        ],
      ),
      WmlParagraph(
        properties: WmlParagraphProps(pageBreakBefore: true),
        inlines: [WmlRun(text: 'SecondFieldPage')],
      ),
    ]),
    {
      'kind': 'styled-linked-fields',
      'page_sizes_pt': [
        [400, 500],
        [400, 500],
      ],
      'cached_page': '17',
      'cached_count': '99',
      'locked_literal': '23',
      'scope': 'Exact authored single-run cache, bold/color/italic and hyperlinks surround native PAGE/NUMPAGES; independent PDF refreshes fields to 1 of 2 and leaves locked literal 23.',
    },
  );

  save(
    'split-cache-readable-fallback',
    document([
      WmlParagraph(
        inlines: [
          WmlRun(text: 'CachedStart '),
          ...field('NUMPAGES', [
            WmlRun(text: '12', properties: WmlRunProps(bold: true)),
            WmlRun(text: '7', properties: WmlRunProps(italic: true)),
          ]),
          WmlRun(text: ' CachedEnd'),
        ],
      ),
      WmlParagraph(
        inlines: field('TITLE', [WmlRun(text: '  Authored  Cache\tTail ')]),
      ),
    ]),
    {
      'kind': 'split-cache-fallback',
      'exact_paragraphs': [
        'CachedStart 127 CachedEnd',
        '  Authored  Cache\tTail ',
      ],
      'scope': 'Split field caches and unsupported fields remain readable literal cache, preserving concatenated text, authored multiple spaces/tab, and each cache run style.',
    },
  );

  save(
    'toc-section-after-live-fields',
    WmlDocument(
      sections: [
        WmlSection(
          pageSize: size,
          margins: margins,
          blocks: [
            text('FirstTocSection'),
            WmlParagraph(
              inlines: [
                WmlRun(text: 'Page '),
                ...field('PAGE', [WmlRun(text: '17')]),
                WmlRun(text: ' of '),
                ...field('NUMPAGES', [WmlRun(text: '99')]),
              ],
            ),
          ],
        ),
        WmlSection(
          pageSize: const WmlPageSize(width: 600, height: 400),
          margins: margins,
          blocks: [
            WmlToc(
              title: 'SecondPageContents',
              entries: [
                WmlTocEntry(
                  text: 'IntroductionEntry',
                  level: 1,
                  headingParagraphIndex: 0,
                  pageNumber: 3,
                ),
                WmlTocEntry(
                  text: 'DetailsEntry',
                  level: 2,
                  headingParagraphIndex: 1,
                  pageNumber: 4,
                ),
              ],
            ),
          ],
        ),
      ],
    ),
    {
      'kind': 'toc-after-fields',
      'page_sizes_pt': [
        [400, 500],
        [600, 400],
      ],
      'scope': 'A TOC as the first block of the next differently sized section retains the section break; live fields refresh while TOC entry cache page numbers remain 3 and 4.',
    },
  );

  save(
    'plain-first-leading-column',
    document([
      WmlParagraph(
        inlines: [
          WmlBreak(WmlBreakType.column),
          WmlRun(text: 'AfterLeading'),
        ],
      ),
      text('LeadingFollower'),
      text('LeadingSecondFollower'),
    ], columns: true),
    {
      'kind': 'plain-leading-column',
      'left_words': <String>[],
      'right_words': [
        'AfterLeading',
        'LeadingFollower',
        'LeadingSecondFollower',
      ],
      'scope': 'Native manually authored DOCX and model WordSerializer both put all three labels in the right column. An explicit first-paragraph column break must not be lost or mimicked by natural balancing.',
    },
    nativeReference: true,
  );

  File(
    '${output.path}/fixtures.json',
  ).writeAsStringSync('${const JsonEncoder.withIndent('  ').convert(specs)}\n');
}
