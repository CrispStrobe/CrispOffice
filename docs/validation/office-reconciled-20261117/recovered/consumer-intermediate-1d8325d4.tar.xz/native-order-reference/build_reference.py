from pathlib import Path
import zipfile,json,hashlib
ROOT=Path(__file__).resolve().parent
ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
section='<w:sectPr><w:pgSz w:w="8000" w:h="10000"/><w:pgMar w:top="720" w:bottom="720" w:left="720" w:right="720"/><w:cols w:num="2" w:space="480"/></w:sectPr>'
styles='<?xml version="1.0"?><w:styles xmlns:w="'+ns+'"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="22"/></w:rPr></w:rPrDefault></w:docDefaults></w:styles>'
def paragraph(text):return '<w:p><w:r><w:t>'+text+'</w:t></w:r></w:p>'
fixtures={
 'plain-leading-column':('<w:p><w:r><w:br w:type="column"/><w:t>AfterLeading</w:t></w:r></w:p>'+paragraph('LeadingFollower')+paragraph('LeadingSecondFollower')),
 'runless-field-after-leading-column':('<w:p><w:bookmarkStart w:id="13" w:name="RunlessPage"/><w:r><w:br w:type="column"/></w:r><w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r><w:bookmarkEnd w:id="13"/></w:p>'+paragraph('RunlessPageFollower')+paragraph('RunlessSecondFollower')),
 'serializer-runless-order':('<w:p><w:bookmarkStart w:id="13" w:name="RunlessPage"/><w:r><w:br w:type="column"/></w:r><w:bookmarkEnd w:id="13"/><w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>1</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p>'+paragraph('RunlessPageFollower')+paragraph('RunlessSecondFollower')),
}
records=[]
for name,body in fixtures.items():
 document='<?xml version="1.0"?><w:document xmlns:w="'+ns+'"><w:body>'+body+section+'</w:body></w:document>'
 contents={'[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>','_rels/.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>','word/document.xml':document,'word/styles.xml':styles,'word/_rels/document.xml.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'}
 path=ROOT/(name+'.docx')
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED) as archive:
  for n,data in contents.items():
   info=zipfile.ZipInfo(n,date_time=(2026,11,17,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,data)
 (ROOT/(name+'.document.xml')).write_text(document)
 records.append({'name':name,'docx_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'column_count':2,'page_width_pt':400,'page_margins_pt':36,'column_gap_pt':24,'right_column_origin_pt':212,'authored_order':'break precedes displayed text or field','kind':'independently authored WordprocessingML'})
(ROOT/'reference-inputs.json').write_text(json.dumps(records,indent=2)+'\n')
