#!/usr/bin/env python3
"""Verify consumer receipts and build a fully read-back-checked evidence archive."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

HERE=Path(__file__).resolve().parent
def sha(payload): return hashlib.sha256(payload).hexdigest()
def write(path,value): path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--runs',nargs='+',required=True)
    p.add_argument('--additional-runs',nargs='*',default=[])
    p.add_argument('--label',required=True)
    p.add_argument('--historical-archive',type=Path,required=True)
    a=p.parse_args(); output=a.output.resolve(); assert not output.exists(); output.parent.mkdir(parents=True,exist_ok=True)
    historical=a.historical_archive.resolve(); archive_hash=sha(historical.read_bytes())
    assert archive_hash=='735a13266f0f0ee7a8fc2ba109e2651f370a590850a206004b23feed90648894'
    retained=[]
    with tarfile.open(historical) as archive:
        for member in archive.getmembers():
            if member.isfile() and member.name.startswith(('runner-source/','schemas/','wave3-runner/')):
                payload=archive.extractfile(member).read()
                assert (HERE/member.name).read_bytes()==payload,member.name
                retained.append({'path':member.name,'sha256':sha(payload),'bytes':len(payload)})
    assert len(retained)==14
    audit={'source_archive_sha256':archive_hash,'source_qualified_commit':'6a32a919325d71c121c63e3879cfd1b28d64312e','all14_retained_files_byte_identical':True,'files':retained,'runs':[]}
    positive=[]; history=[]; names=[]; source_heads=set(); expected_current=None
    for run_name in a.runs+a.additional_runs:
        root=HERE/run_name; r=json.loads((root/'receipt.json').read_text())
        before=json.loads(gzip.decompress((root/'inputs.json.gz').read_bytes())); after=json.loads(gzip.decompress((root/'inputs-after.json.gz').read_bytes()))
        assert before==after,run_name
        assert all(r[k] for k in ('source_unchanged','runtime_unchanged','head_unchanged','fixtures_unchanged')),run_name
        for name,digest in r['output_hashes'].items(): assert sha((root/name).read_bytes())==digest,(run_name,name)
        assert sha((root/'inputs.json.gz').read_bytes())==r['inputs_sha256']
        specs=json.loads((root/'fixtures/fixtures.json').read_text())
        if len(specs)==33:
            assert specs==json.loads((HERE/'historical-fixtures-33.json').read_text())
            audit['runs'].append({'run':run_name,'full33_fixture_specs_identical':True})
        if len(specs)==7:
            if expected_current is None: expected_current=specs
            assert specs==expected_current,run_name+' current-seven oracle drift'
        summary={'run':run_name,'source_head':r['source_head'],'source_tree':r['source_tree'],'passed':r['passed'],
          'summary':r['summary'],'input_counts':r['input_counts'],'input_maps_equal':True,
          'all_recorded_output_hashes_verified':True,'receipt_sha256':sha((root/'receipt.json').read_bytes())}
        if run_name in a.runs:
            assert r['passed'],run_name; positive.append(summary); source_heads.add(r['source_head']); names.extend(s['name'] for s in specs)
        else: history.append(summary)
    assert len(names)==len(set(names))==40 and len(source_heads)==1
    assert sum(x['summary']['schema_parts_passed'] for x in positive)==160
    write(HERE/'retention-audit.json',audit)
    summary={'label':a.label,'source_head':next(iter(source_heads)),'accepted_fixture_count':40,'accepted_schema_parts':160,
      'positive_runs':positive,'historical_or_negative_runs':history,'counting_note':'Only disjoint retained33+current7 positive fixtures at the selected source count toward40. Earlier runs, raw schema controls, and native DOCX references are separate evidence.',
      'raw_schema_controls':'schema-controls/receipt.json','schema_false_negative':'schema-oracle/receipt.json',
      'oracle_correction':'Initial pre-reset runless PAGE-left expectation was incorrect. Corrected source-order oracle is fixed identically across fresh baseline/intermediate/final runs; the distinct empty-cache raw DOCX packet is documented separately.',
      'github_actions_queried_or_awaited':False}
    write(HERE/('summary-'+a.label+'.json'),summary)
    common=['wave3-runner','runner-source','schemas','tools','schema-oracle','schema-controls','native-order-reference']
    candidates=[f for f in HERE.iterdir() if f.is_file() and f.suffix in ('.py','.dart','.json','.md','.log')]
    for dirname in common+a.runs+a.additional_runs:
        candidates += [p for p in (HERE/dirname).rglob('*') if p.is_file()]
    excluded={'__pycache__','tmp','profile','envelope-profile','profile-pdf','profile-docx'}
    files=sorted({p for p in candidates if not any(part in excluded for part in p.relative_to(HERE).parts)})
    members=[]
    with tarfile.open(output,'w:xz',preset=6) as archive:
        for path in files:
            relative=path.relative_to(HERE).as_posix(); payload=path.read_bytes()
            info=archive.gettarinfo(str(path),arcname=relative); info.uid=info.gid=0; info.uname=info.gname='';info.mtime=0
            with path.open('rb') as stream: archive.addfile(info,stream)
            members.append({'path':relative,'bytes':len(payload),'sha256':sha(payload)})
    with tarfile.open(output) as archive:
        actual=archive.getmembers(); assert len(actual)==len(members)
        for member,expected in zip(actual,members):
            assert member.isfile() and member.name==expected['path']
            payload=archive.extractfile(member).read();assert len(payload)==expected['bytes'] and sha(payload)==expected['sha256'],member.name
    index={'archive':output.name,'bytes':output.stat().st_size,'sha256':sha(output.read_bytes()),'member_count':len(members),'full_readback_verified':True,'qualification':summary,'members':members}
    write(output.with_suffix('.index.json'),index)
    print(json.dumps({k:index[k] for k in ('archive','bytes','sha256','member_count','full_readback_verified')},indent=2))
if __name__=='__main__': main()
