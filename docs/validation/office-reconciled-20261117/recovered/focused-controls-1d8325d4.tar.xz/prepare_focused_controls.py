#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'source-1d8325d4'
REPO = ROOT / 'quds_office_suite'
ENGINE = SOURCE / 'packages/quds_office_engine'
OUTPUT = ROOT / 'recovery/canonical/controls-1d8325d4'
OUTPUT.mkdir(parents=True, exist_ok=True)
TESTS = [
    'odt_complex_field_fidelity_test.dart',
    'odt_bookmark_name_ambiguity_test.dart',
    'odt_page_marker_column_break_test.dart',
    'odt_inline_field_fidelity_test.dart',
    'odt_inline_column_break_fidelity_test.dart',
    'odt_bookmark_end_fidelity_test.dart',
    'odt_bookmark_range_fidelity_test.dart',
]
VARIANTS = {
    'incoming-main': ('e3a38789359adaa33b2da1345c952fa1c2d8aebb', [
        'lib/src/word/serial/odt_document_writer.dart',
        'lib/src/word/model/word_bookmarks.dart']),
    'prior-repair-4595e308': ('4595e30813a7864889953baa8c964809043efb88', [
        'lib/src/word/serial/odt_document_writer.dart']),
}
manifest = {'positive_source_commit':'1d8325d41526a55e3d6cd6031371458d2ee396e5',
            'positive_engine':str(ENGINE),'tests':{},'negative_variants':{},
            'method':'Each negative package copies the frozen positive engine library, substitutes only the listed exact historical source files, and runs byte-identical final controls with the same dependency graph. These are isolated causal source substitutions, not complete historical application qualifications.'}
for name in TESTS:
    data=(ENGINE/'test'/name).read_bytes()
    manifest['tests'][name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
for name,(commit,files) in VARIANTS.items():
    package=OUTPUT/name
    if package.exists():
        raise RuntimeError('Do not overwrite an existing control package: '+str(package))
    package.mkdir()
    shutil.copytree(ENGINE/'lib',package/'lib')
    shutil.copy2(ENGINE/'pubspec.yaml',package/'pubspec.yaml')
    (package/'test').mkdir()
    for test in TESTS:
        shutil.copy2(ENGINE/'test'/test,package/'test'/test)
    rows={}
    for relative in files:
        repository_path='packages/quds_office_engine/'+relative
        data=subprocess.check_output(['git','-C',str(REPO),'show',commit+':'+repository_path])
        (package/relative).write_bytes(data)
        rows[relative]={'commit':commit,'sha256':hashlib.sha256(data).hexdigest(),
                       'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
    manifest['negative_variants'][name]={'package':str(package),'substituted_source':rows}
(OUTPUT/'input-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'directory':str(OUTPUT),'variants':list(VARIANTS),'test_files':len(TESTS)}))
