#!/usr/bin/env python3
from pathlib import Path
import collections
import gzip
import hashlib
import io
import json
import shutil
import tarfile

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'recovery/canonical'
CONTROL=BASE/'controls-1d8325d4'
STAGE=BASE/'focused-evidence-1d8325d4'
assert not STAGE.exists()
STAGE.mkdir()
receipt=json.loads((CONTROL/'receipt.json').read_text())
assert receipt['all_expectations_met'] and receipt['status']=='passed'
manifest=json.loads((CONTROL/'input-manifest.json').read_text())
audit=[]
for row in receipt['attempts']:
    packed=(CONTROL/row['stdout']['path']).read_bytes()
    raw=gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest()==row['stdout']['gzip_sha256']
    assert hashlib.sha256(raw).hexdigest()==row['stdout']['sha256']
    events=[]
    for line in raw.splitlines():
        try: e=json.loads(line)
        except ValueError: continue
        if isinstance(e,dict): events.append(e)
    starts=[e['test'] for e in events if e.get('type')=='testStart']
    assert len(starts)==len({s['id'] for s in starts})
    names={s['id']:s['name'] for s in starts}
    done=[e for e in events if e.get('type')=='testDone' and not e.get('hidden')]
    assert len(done)==len({e['testID'] for e in done})
    assert all(e['testID'] in names for e in done)
    assert not any(e.get('skipped') for e in done)
    counts=dict(collections.Counter(e['result'] for e in done))
    assert counts==row['summary']['counts']
    failed_ids={e['testID'] for e in done if e['result']!='success'}
    errors=[e for e in events if e.get('type')=='error']
    assert len(errors)==len(failed_ids)
    assert {e['testID'] for e in errors}==failed_ids
    assert {names[i] for i in failed_ids}==set(row['expected_failure_names'])
    final=[e for e in events if e.get('type')=='done']
    assert len(final)==1 and final[0]['success']==(not failed_ids)
    audit.append({'variant':row['variant'],'substantive_cases':len(done),'counts':counts,
                  'start_ids_unique':True,'terminal_ids_unique':True,
                  'error_events_exactly_expected_failed_tests':True,
                  'exactly_one_final_done':True,'skips':0})
(STAGE/'independent-event-audit.json').write_text(json.dumps({'source_commit':receipt['positive_source_commit'],'variants':audit,'focused_counts_added_to_full_qualification':False,'passed':True},indent=2)+'\n')
for name in ('receipt.json','input-manifest.json','incoming-main-summary.json','prior-repair-4595e308-summary.json','positive-summary.json','format.stdout','format.stderr'):
    shutil.copy2(CONTROL/name,STAGE/name)
for name in ('prepare_focused_controls.py','run_focused_controls.py','archive_focused_controls.py'):
    shutil.copy2(BASE/name,STAGE/name)
for row in receipt['attempts']:
    for stream in ('stdout','stderr'):
        shutil.copy2(CONTROL/row[stream]['path'],STAGE/row[stream]['path'])
for name in ('incoming-main','prior-repair-4595e308','positive'):
    destination=STAGE/'source'/name
    destination.mkdir(parents=True)
    for path in ('lib/src/word/serial/odt_document_writer.dart','lib/src/word/model/word_bookmarks.dart'):
        target=destination/path
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(CONTROL/name/path,target)
    shutil.copy2(CONTROL/name/'.dart_tool/package_config.json',destination/'package_config.json')
for name in manifest['tests']:
    target=STAGE/'tests'/name
    target.parent.mkdir(exist_ok=True)
    data=(CONTROL/'positive/test'/name).read_bytes()
    assert hashlib.sha256(data).hexdigest()==manifest['tests'][name]['sha256']
    target.write_bytes(data)
config=Path(receipt['upstream_graph'])
shutil.copy2(config,STAGE/'upstream-package-config.json')
shutil.copy2(config.parent.parent/'pubspec.lock',STAGE/'workspace-pubspec.lock')
(STAGE/'format-receipt.json').write_text(json.dumps({'source_commit':receipt['positive_source_commit'],'command':[str(ROOT/'runtime/flutter-sdk/bin/cache/dart-sdk/bin/dart'),'format','--language-version=3.12','--output=none','--set-exit-if-changed','source-1d8325d4/packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart','source-1d8325d4/packages/quds_office_engine/test/odt_page_marker_column_break_test.dart'],'exit_code':0,'stdout':'format.stdout','stderr':'format.stderr'},indent=2)+'\n')
(STAGE/'README.md').write_text('''# Intermediate canonical field and bookmark controls

This evidence binds only source `1d8325d41526a55e3d6cd6031371458d2ee396e5`. Subsequent incoming main changes require a fresh qualification; these outcomes must not be presented as validation of a later merged source.

The frozen source passes all 69 cases in seven field, bookmark and inline-column files, with zero skips or errors. Exact final control bytes are also run against isolated historical source substitutions: incoming main writer/bookmark helper `e3a38789359adaa33b2da1345c952fa1c2d8aebb` gives 45 passes and exactly six expected failures in 51 cases. The prior repaired writer `4595e30813a7864889953baa8c964809043efb88` gives one pass and exactly the two new leading-break failures in the three-case page-marker file. These are causal control variants, not full historical repository qualifications, and their cases are not added to the later broad qualification total.

The six incoming-main negative cases cover four earlier repairs plus two representations of the first-section leading-column defect. One negative checks a plain paragraph whose first inline is a column break; the other checks a runless PAGE marker with bookmark-start, column-break, bookmark-end. The original restored trailing-break PAGE case remains intact. The final writer keeps the empty source prefix only when the first section uses multiple columns, giving the following paragraph a column break that LibreOffice honors. Zero-width bookmark endpoints retain their authored order. A runless model PAGE field remains after the break and before the bookmark end.

Native no-cache PAGE packets have an additional import ambiguity: a raw field envelope with no cache can render PAGE before the column break, whereas the model Word serializer adds a fallback cache after the inlines and renders PAGE after the break. This repair retains the existing model/ODT ordering and does not claim that the flattened marker preserves both native packet placements. Independent plain no-PAGE DOCX evidence establishes the layout defect without that ambiguity; the consumer evidence archive contains those original DOCX/PDF observations.

The controls use a copied, normalized 109-package graph with the inherited lock unchanged. Positive and negative test sources are byte-identical. Source library hashes, Dart binary, test CLI and upstream graph remain unchanged during the run. Each raw terminal event has a unique ID; every negative error corresponds to an expected failed test; the positive run has no errors; and each invocation has exactly one final done event. The two modified Dart files also pass the explicit Dart 3.12 formatting gate.

`receipt.json` contains the exact invocations, source maps and hashes. `independent-event-audit.json` independently recounts the archived JSON events. Historical substitutions and final source/test bytes are included for review; other package source is bound to the positive frozen source by its hash map. No GitHub CI endpoint was used.
''')
archive=BASE/'focused-controls-1d8325d4.tar.xz'
rows=[]
with tarfile.open(archive,'w:xz') as out:
    for path in sorted(STAGE.rglob('*')):
        if not path.is_file(): continue
        relative=path.relative_to(STAGE).as_posix(); data=path.read_bytes()
        info=tarfile.TarInfo(relative); info.size=len(data); info.mode=0o644; info.mtime=0
        out.addfile(info,io.BytesIO(data)); rows.append({'path':relative,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive,'r:xz') as check:
    assert len(check.getnames())==len(rows)
    for row in rows: assert hashlib.sha256(check.extractfile(row['path']).read()).hexdigest()==row['sha256']
index={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'source_commit':receipt['positive_source_commit'],'members':rows,'member_count':len(rows),'readback_verified':True,'substantive_positive_passes':69,'negative_expectations_met':True,'intermediate_source_only':True}
(BASE/'focused-controls-1d8325d4.index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({k:index[k] for k in ('archive','bytes','sha256','member_count','readback_verified')}))
