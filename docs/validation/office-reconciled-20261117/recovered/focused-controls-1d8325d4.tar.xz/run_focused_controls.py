#!/usr/bin/env python3
"""Run byte-identical positive/negative field and bookmark controls."""
from pathlib import Path
import argparse
import collections
import datetime
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import urllib.parse

ROOT = Path(__file__).resolve().parents[2]
OUTPUT = ROOT / 'recovery/canonical/controls-1d8325d4'
SOURCE = ROOT / 'source-1d8325d4'
DART = ROOT / 'runtime/flutter-sdk/bin/cache/dart-sdk/bin/dart'
TEST_CLI = ROOT / 'runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
MANIFEST = json.loads((OUTPUT/'input-manifest.json').read_text())
TESTS = list(MANIFEST['tests'])
BASE_TESTS = ['odt_complex_field_fidelity_test.dart','odt_bookmark_name_ambiguity_test.dart',
              'odt_page_marker_column_break_test.dart','odt_inline_field_fidelity_test.dart']
NEW_FAILURES = {
 'a runless bookmarked PAGE stays after a leading column break',
 'a first-section leading column break retains its empty source fragment',
}
OLD_FAILURES = {
 'empty native PAGE cache keeps a following column break after the field',
 'empty native NUMPAGES cache keeps a following column break after the field',
 'a malformed bookmark id still reserves its emitted name',
 'an empty bookmarked PAGE field precedes its trailing column break',
}
def sha(data): return hashlib.sha256(data).hexdigest()
def file_sha(path): return sha(path.read_bytes())
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path,value): path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def tree_snapshot(path):
    return {str(p.relative_to(path)):file_sha(p) for p in sorted(path.rglob('*')) if p.is_file()}
def summary(raw,selected,cwd):
    events=[]
    for line in raw.decode(errors='replace').splitlines():
        try: event=json.loads(line)
        except ValueError: continue
        if isinstance(event,dict): events.append(event)
    starts={e['test']['id']:e['test'] for e in events if e.get('type')=='testStart'}
    suites={e['suite']['id']:e['suite'] for e in events if e.get('type')=='suite'}
    rows=[]
    for event in events:
        if event.get('type')!='testDone' or event.get('hidden'): continue
        start=starts[event['testID']]
        rows.append({'id':event['testID'],'suite_id':start['suiteID'],'name':start['name'],
                     'outcome':'skipped' if event.get('skipped') else event.get('result')})
    ids=[r['id'] for r in rows]
    actual=set()
    for suite in suites.values():
        path=Path(urllib.parse.unquote(urllib.parse.urlparse(suite['path']).path) if suite['path'].startswith('file:') else suite['path'])
        actual.add((path if path.is_absolute() else cwd/path).resolve())
    expected={(cwd/'test'/p).resolve() for p in selected}
    done=[e for e in events if e.get('type')=='done']
    return {'counts':dict(collections.Counter(r['outcome'] for r in rows)),
            'completed_tests':rows,'duplicate_terminal_ids':[i for i,n in collections.Counter(ids).items() if n!=1],
            'missing_suites':sorted(str(p) for p in expected-actual),
            'unexpected_suites':sorted(str(p) for p in actual-expected),
            'last_done':done[-1] if done else None,
            'errors':[e for e in events if e.get('type')=='error']}

parser=argparse.ArgumentParser()
parser.add_argument('--packages',type=Path,required=True)
args=parser.parse_args()
assert not (OUTPUT/'receipt.json').exists(), 'Never overwrite a control attempt.'
config=args.packages.resolve()
graph=json.loads(config.read_text())
for package in graph['packages']:
    package['rootUri']=urllib.parse.urljoin(config.as_uri(),package['rootUri'])
assert len([p for p in graph['packages'] if p['name']=='quds_office_engine'])==1
positive=OUTPUT/'positive'
positive.mkdir()
(positive/'lib').symlink_to(SOURCE/'packages/quds_office_engine/lib',target_is_directory=True)
shutil.copy2(SOURCE/'packages/quds_office_engine/pubspec.yaml',positive/'pubspec.yaml')
(positive/'test').mkdir()
for name in TESTS: shutil.copy2(SOURCE/'packages/quds_office_engine/test'/name,positive/'test'/name)
(OUTPUT/'tmp').mkdir(exist_ok=True); (OUTPUT/'config').mkdir(exist_ok=True)
env=dict(os.environ,FLUTTER_ROOT=str(ROOT/'runtime/flutter-sdk'),PUB_CACHE=str(ROOT/'runtime/pub-cache'),
         TMPDIR=str(OUTPUT/'tmp'),XDG_CONFIG_HOME=str(OUTPUT/'config'),CI='true',
         DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true')
receipt={'started_utc':now(),'positive_source_commit':MANIFEST['positive_source_commit'],
         'upstream_graph':str(config),'upstream_graph_sha256':file_sha(config),
         'dart':str(DART),'dart_sha256':file_sha(DART),'dart_version':subprocess.check_output([str(DART),'--version'],env=env,stderr=subprocess.STDOUT).decode().strip(),
         'package_count':len(graph['packages']),'test_cli_sha256':file_sha(TEST_CLI),
         'input_manifest_sha256':file_sha(OUTPUT/'input-manifest.json'),'runner_sha256':file_sha(Path(__file__)),
         'positive_source_files_before':tree_snapshot(SOURCE/'packages/quds_office_engine/lib'),
         'status':'running','attempts':[],'full_qualification_counts_combined':False}
save(OUTPUT/'receipt.json',receipt)
variants=[('incoming-main',BASE_TESTS,OLD_FAILURES|NEW_FAILURES),
          ('prior-repair-4595e308',['odt_page_marker_column_break_test.dart'],NEW_FAILURES),
          ('positive',TESTS,set())]
for name,tests,expected_failures in variants:
    package=OUTPUT/name
    local_graph=json.loads(json.dumps(graph))
    for row in local_graph['packages']:
        if row['name']=='quds_office_engine': row['rootUri']=package.as_uri()+'/'
    (package/'.dart_tool').mkdir(exist_ok=True)
    package_config=package/'.dart_tool/package_config.json'
    save(package_config,local_graph)
    for test in tests: assert file_sha(package/'test'/test)==MANIFEST['tests'][test]['sha256']
    before=tree_snapshot(package/'lib')
    command=[str(DART),'--packages='+str(package_config),str(TEST_CLI),'--concurrency=2','--reporter=json',*('test/'+t for t in tests)]
    row={'variant':name,'command':command,'cwd':str(package),'expected_failure_names':sorted(expected_failures),
         'started_utc':now(),'source_before':before,'graph_sha256':file_sha(package_config)}
    receipt['attempts'].append(row); save(OUTPUT/'receipt.json',receipt)
    print(json.dumps({'event':'start','variant':name}),flush=True)
    with (OUTPUT/(name+'.stdout')).open('wb') as out,(OUTPUT/(name+'.stderr')).open('wb') as err:
        result=subprocess.run(command,cwd=package,env=env,stdout=out,stderr=err,timeout=240)
    for stream in ('stdout','stderr'):
        path=OUTPUT/(name+'.'+stream); raw=path.read_bytes()
        compressed=gzip.compress(raw,mtime=0)
        packed=OUTPUT/(name+'.'+stream+'.gz'); packed.write_bytes(compressed)
        row[stream]={'path':packed.name,'sha256':sha(raw),'gzip_sha256':sha(compressed),'bytes':len(raw)}
        if stream=='stdout': counts=summary(raw,tests,package)
        path.unlink()
    failures={r['name'] for r in counts['completed_tests'] if r['outcome']!='success'}
    unchanged=before==tree_snapshot(package/'lib')
    tests_unchanged=all(file_sha(package/'test'/t)==MANIFEST['tests'][t]['sha256'] for t in tests)
    accepted=(failures==expected_failures and not counts['duplicate_terminal_ids'] and not counts['missing_suites']
              and not counts['unexpected_suites'] and not counts['counts'].get('skipped') and unchanged and tests_unchanged
              and result.returncode==(1 if expected_failures else 0)
              and bool(counts['last_done']) and bool(counts['last_done'].get('success'))==(not expected_failures))
    if not expected_failures: accepted=accepted and not counts['errors']
    row.update(finished_utc=now(),exit_code=result.returncode,summary=counts,source_unchanged=unchanged,
               tests_unchanged=tests_unchanged,expectation_met=accepted)
    save(OUTPUT/(name+'-summary.json'),row)
    save(OUTPUT/'receipt.json',receipt)
    print(json.dumps({'event':'finish','variant':name,'counts':counts['counts'],'expected_failures_matched':failures==expected_failures,'expectation_met':accepted}),flush=True)
    if not accepted: raise RuntimeError('Unexpected control result: '+name)
receipt['positive_source_unchanged']=receipt['positive_source_files_before']==tree_snapshot(SOURCE/'packages/quds_office_engine/lib')
receipt['dart_unchanged']=receipt['dart_sha256']==file_sha(DART)
receipt['test_cli_unchanged']=receipt['test_cli_sha256']==file_sha(TEST_CLI)
receipt['upstream_graph_unchanged']=receipt['upstream_graph_sha256']==file_sha(config)
receipt['all_expectations_met']=all(row['expectation_met'] for row in receipt['attempts']) and all(receipt[k] for k in ('positive_source_unchanged','dart_unchanged','test_cli_unchanged','upstream_graph_unchanged'))
receipt['status']='passed' if receipt['all_expectations_met'] else 'failed'
receipt['finished_utc']=now(); save(OUTPUT/'receipt.json',receipt)
print(json.dumps({'status':receipt['status'],'source':receipt['positive_source_commit']}),flush=True)
raise SystemExit(0 if receipt['all_expectations_met'] else 1)
