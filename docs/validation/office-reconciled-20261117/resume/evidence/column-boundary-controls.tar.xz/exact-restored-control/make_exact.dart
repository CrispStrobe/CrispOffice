import 'dart:convert';
import 'dart:io';
import 'package:quds_office_engine/quds_office_engine.dart';
void main(List<String> args) {
 final out=Directory(args.single)..createSync(recursive:true);
 final package=OpcPackage.create(OpcPackageKind.word);
 package.getPart('/word/document.xml')!.writeText(
  '<w:document xmlns:w="${OfficeNamespaces.w}"><w:body>'
  '<w:p><w:pPr><w:sectPr><w:cols w:num="2"/></w:sectPr></w:pPr>'
  '<w:r><w:t>First section</w:t></w:r></w:p>'
  '<w:p><w:pPr><w:pageBreakBefore/></w:pPr>'
  '<w:r><w:br w:type="column"/><w:t>Second section</w:t>'
  '<w:br w:type="column"/><w:t>Continuation</w:t></w:r></w:p>'
  '<w:sectPr><w:cols w:num="2" w:space="360"/></w:sectPr>'
  '</w:body></w:document>');
 File('${out.path}/exact.source.docx').writeAsBytesSync(package.save());
 final doc=WordDeserializer().read(package);
 File('${out.path}/exact.odt').writeAsBytesSync(OdtDocumentWriter.writeBytes(doc));
 File('${out.path}/model.json').writeAsStringSync(jsonEncode([for(final s in doc.sections){'cols':s.columnCount,'gap':s.columnSpace,'kind':s.breakKind.name,'width':s.pageSize.width,'height':s.pageSize.height,'paragraphs':[for(final p in s.blocks.whereType<WmlParagraph>()){'text':p.text,'pageBefore':p.properties.pageBreakBefore,'columnBefore':p.properties.columnBreakBefore,'breaks':[for(final b in p.inlines.whereType<WmlBreak>())b.type.name]}]}]));
}
