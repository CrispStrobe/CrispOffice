#!/usr/bin/env python3
"""Run the exact Word list-level BAS on the Dart VM and compiled JavaScript."""
import argparse
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

import word_office_gate as gate

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
out = args.out.resolve()
assert not out.exists(), 'Use a new output directory; earlier evidence is retained'
out.mkdir(parents=True)
runtime = Path(__file__).resolve().parent
repo = runtime.parent / 'quds_office_suite'
engine = repo / 'packages/quds_office_engine'
dart = runtime / 'dart-sdk/bin/dart'
packages = repo / '.dart_tool/package_config.json'
bas = engine / 'example/macros/word_list_levels.bas'
driver = engine / 'tool/macros/web_vba_word_list_levels_smoke.dart'
define = '-DWORD_LIST_LEVELS_BAS_BASE64=' + base64.b64encode(bas.read_bytes()).decode()
node = shutil.which('node')
assert node
environment = os.environ.copy()
environment.update({
    'PUB_CACHE': str(runtime / 'pub-cache'),
    'TMPDIR': str(runtime / 'tmp'),
    'XDG_CONFIG_HOME': str(runtime / 'config'),
    'XDG_CACHE_HOME': str(runtime / 'cache'),
    'DART_SUPPRESS_ANALYTICS': 'true',
    'PATH': str(runtime / 'dart-sdk/bin') + os.pathsep + environment['PATH'],
})
before = gate.source_manifest()
gate.save(out / 'inputs-before.json.gz', before)
commands = [
    ('vm', [str(dart), f'--packages={packages}', define, str(driver)]),
    ('compile-js', [str(dart), 'compile', 'js', f'--packages={packages}',
                    define, '-o', str(out / 'word-list-levels.js'), str(driver)]),
    ('node', [node, str(out / 'word-list-levels.js')]),
]
receipts = []
for name, command in commands:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    beginning = time.monotonic()
    with (out / f'{name}.stdout').open('wb') as stdout, (out / f'{name}.stderr').open('wb') as stderr:
        result = subprocess.run(command, cwd=engine, env=environment, stdout=stdout, stderr=stderr)
    receipt = {'name': name, 'argv': command, 'cwd': str(engine),
               'started_utc': started, 'seconds': round(time.monotonic()-beginning, 3),
               'exit_code': result.returncode}
    receipts.append(receipt)
    gate.save(out / 'commands.json', receipts)
    print(json.dumps({key: receipt[key] for key in ['name', 'seconds', 'exit_code']}), flush=True)
    if result.returncode:
        break
after = gate.source_manifest()
gate.save(out / 'inputs-after.json.gz', after)
summary = {'commands_succeeded': len(receipts) == 3 and all(c['exit_code'] == 0 for c in receipts),
           'source_commit_before': before['source_commit'],
           'source_tree_before': before['source_tree'],
           'head_matches_worktree': before['head_matches_worktree'],
           'complete_source_input_count': len(before['entries']),
           'source_inputs_unchanged': before['entries'] == after['entries'],
           'bas_sha256': hashlib.sha256(bas.read_bytes()).hexdigest(),
           'driver_sha256': hashlib.sha256(driver.read_bytes()).hexdigest(),
           'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'commands': receipts}
if summary['commands_succeeded']:
    vm = (out / 'vm.stdout').read_bytes()
    js = (out / 'node.stdout').read_bytes()
    summary['raw_outputs_equal'] = vm == js
    summary['raw_output_bytes'] = len(vm)
    summary['raw_output_sha256'] = hashlib.sha256(vm).hexdigest()
    vm_result, js_result = json.loads(vm), json.loads(js)
    summary['canonical_results_equal'] = vm_result == js_result
    canonical = (json.dumps(vm_result, sort_keys=True, separators=(',', ':')) + '\n').encode()
    (out / 'result.json').write_bytes(canonical)
    summary['canonical_sha256'] = hashlib.sha256(canonical).hexdigest()
gate.save(out / 'summary.json', summary)
complete = summary['commands_succeeded'] and summary.get('raw_outputs_equal') and summary.get('canonical_results_equal')
print(json.dumps({key: summary.get(key) for key in ['commands_succeeded', 'source_inputs_unchanged', 'raw_outputs_equal', 'canonical_results_equal', 'canonical_sha256']}), flush=True)
raise SystemExit(0 if complete else 1)
