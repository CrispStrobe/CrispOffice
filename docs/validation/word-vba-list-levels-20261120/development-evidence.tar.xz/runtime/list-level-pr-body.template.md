<!-- PR261 BODY TEMPLATE. Replace every named placeholder from accepted records before publishing. Pending qualification rows are not claims that checks passed. Root fills Publication verification after the merge. -->

## Problem and behavior

The previous paragraph `ListFormat` support could apply or remove single-level lists, but macros could not create an outline or move items between levels. This adds four operations on explicitly selected existing body paragraphs:

| VBA member | Result |
| --- | --- |
| `ApplyOutlineNumberDefault` | Toggle a validated numeric outline off, or apply a separately named nine-level Quds decimal outline at level 1 |
| `ListLevelNumber = n` | Select an existing supported level using an exact numeric integer from 1 through 9; the property is write-only |
| `ListIndent` | Increase the current list level by one |
| `ListOutdent` | Decrease the current list level by one |

Typed aliases, required `ByVal` helpers, nested `With`, and statement/`Call` forms are supported. The outline uses hierarchical labels, 18-point left indentation per source level and 9-point hanging indentation. The executable [BAS example][example] explicitly clears numbering before default application to make its outline creation repeatable.

Level changes resolve the current level during execution and use the actual target definition or complete override. Missing lists, undefined levels, boundary overflow and pending restarts refuse before mutation. Existing single-level defaults retain their behavior.

## Preservation fixes

- Level changes preserve numbering instances/definitions, unrelated paragraph properties and foreign metadata. New outline IDs avoid existing definitions/references; reuse requires the complete expected scheme.
- New geometry retains both the right-indent value and its direct or inherited ownership. Later style changes still affect inherited right indentation; deliberate earlier direct writes remain direct.
- A narrow style-cascade fix resolves indentation by namespace identity, including alternate/rebound prefixes, while preserving original XML and opaque foreign `ind` elements through import and save/reopen.
- Unsupported geometry, inherited indentation conflicts, ambiguous definitions and unsafe field boundaries refuse before publication. Validation leaves the document unchanged; failed plans publish no edits, and failed native calls are excluded from recording.

Ordinary serialization can still normalize numbering XML or add existing fallback definitions. Tests compare original imported definition/instance semantics and complete bytes for normalized fixtures; arbitrary whole-part byte identity is not promised.

## Local qualification — fill from accepted final records

Source freeze: [`3c87debcd4d50cac88981ec39255c3c6890fe8fa`][freeze]. Raw streams, commands, manifests and archive inventories are in the [committed validation directory][validation]. GitHub Actions, workflow runs and status endpoints were neither queried nor awaited.

| Check | Recorded result |
| --- | --- |
| Word/Office regression | {{REGRESSION_STATUS}} — {{PASSING_CASES}} passing cases across 70 modules; {{FAILED_CASES}} failures and {{SKIPPED_CASES}} skips |
| New increment coverage, included above | 233 cases: 88 compiler, 101 native, 44 integration |
| Previous unchanged modules | {{UNCHANGED_MODULES}} modules retain their previous counts, totaling {{UNCHANGED_CASES}} cases |
| Whole-engine strict analysis | {{ANALYSIS_STATUS}} — `dart analyze --fatal-infos packages/quds_office_engine` |
| Formatting | {{FORMAT_STATUS}} — all 9 changed Dart files; {{FORMATTING_CHANGES}} changes |
| Exact BAS on Dart VM and compiled JavaScript | {{PORTABLE_STATUS}} — {{PORTABLE_RAW_BYTES}}-byte raw outputs; {{PORTABLE_EQUALITY_RESULT}} |
| Complete source binding | {{SOURCE_BINDING_STATUS}} — 1,123 inputs, including complete path sets, modes, Git objects and SHA-256 identities |
| Recorded runtime binding | {{RUNTIME_BINDING_STATUS}} — 11 regression inputs, 20 analysis/format inputs, 20 portable inputs |
| Supplemental independent probes | 18 passed; separately recorded and excluded from the regression total |
| Independent evidence review | {{EVIDENCE_REVIEW_STATUS}} |

See [regression][regression], [analysis/format][checks], [portable][portable], [source review][source-review] and [evidence review][evidence-review]. Original modules run as separate Dart libraries in one serial VM suite, without separate test-file isolates. Development streams are retained separately; the correction receipt acknowledges discarded `quds_dummy` stdout, which supplies no qualification.

## Incoming history and checkpoints

{{INCOMING_RECONCILIATION_DETAILS}}

The [final intake][intake] accounts for {{FORK_BRANCH_HEADS}} fork branch heads, {{EXISTING_PR_HEADS}} existing PR heads and {{UPSTREAM_BRANCH_HEADS}} upstream branch heads, with {{UNCOVERED_HEADS}} uncovered heads. {{HISTORICAL_EQUIVALENCE_PROOF_SUMMARY}}

The work was saved incrementally on `codex/word-vba-list-levels-20261120`. Final preserved checkpoint: `{{FINAL_CHECKPOINT_SHA}}`. Incoming Mail, provider and Flutter changes retain their separate runtime qualification.

## Compatibility boundaries

This remains a bounded source adapter: no live list reads, arbitrary ranges, galleries/customized templates, COM or embedded VBA execution. Default-list behavior accepts omitted arguments or `wdWord8ListBehavior`. Outline toggling requires explicit supported multilevel metadata and complete numeric levels. Explicit level editing accepts validated bullets and the six existing numeric formats; ambiguous/partial definitions, linked/picture numbering and unsupported geometry/restart rules refuse. The [Word contract][contract] specifies the exact subset, evaluation order and label-cache boundary.

## Publication verification

<!-- RESERVED: root fills this section only after fetching and checking merged remote main. Do not replace pending values with an assumption. -->

| Verification | Recorded outcome |
| --- | --- |
| Final published checkpoint | `{{FINAL_CHECKPOINT_SHA}}` |
| Merged remote main | `{{MERGED_MAIN_SHA}}` |
| Published checkpoint/main complete tree equality | {{TREE_EQUALITY_VERIFICATION}} |
| All 1,123 qualified input identities preserved | {{QUALIFIED_INPUT_VERIFICATION}} |
| Reconciled ancestry retained | {{RECONCILED_ANCESTRY_VERIFICATION}} |
| Publication/source-consistency receipts | {{PUBLICATION_RECEIPT_LINKS}} |

[freeze]: https://github.com/CrispStrobe/quds_office_suite/commit/3c87debcd4d50cac88981ec39255c3c6890fe8fa
[example]: https://github.com/CrispStrobe/quds_office_suite/blob/codex/word-vba-list-levels-20261120/packages/quds_office_engine/example/macros/word_list_levels.bas
[contract]: https://github.com/CrispStrobe/quds_office_suite/blob/codex/word-vba-list-levels-20261120/docs/VBA_WORD_MACROS.md#outline-numbering-and-list-levels
[validation]: https://github.com/CrispStrobe/quds_office_suite/tree/codex/word-vba-list-levels-20261120/docs/validation/word-vba-list-levels-20261120
[regression]: https://github.com/CrispStrobe/quds_office_suite/blob/codex/word-vba-list-levels-20261120/docs/validation/word-vba-list-levels-20261120/regression.json
[checks]: https://github.com/CrispStrobe/quds_office_suite/blob/codex/word-vba-list-levels-20261120/docs/validation/word-vba-list-levels-20261120/analysis-format.json
[portable]: https://github.com/CrispStrobe/quds_office_suite/blob/codex/word-vba-list-levels-20261120/docs/validation/word-vba-list-levels-20261120/portable.json
[source-review]: https://github.com/CrispStrobe/quds_office_suite/blob/codex/word-vba-list-levels-20261120/docs/validation/word-vba-list-levels-20261120/source-review.json
[evidence-review]: https://github.com/CrispStrobe/quds_office_suite/blob/codex/word-vba-list-levels-20261120/docs/validation/word-vba-list-levels-20261120/evidence-review.json
[intake]: https://github.com/CrispStrobe/quds_office_suite/blob/codex/word-vba-list-levels-20261120/docs/validation/word-vba-list-levels-20261120/final-intake.json
