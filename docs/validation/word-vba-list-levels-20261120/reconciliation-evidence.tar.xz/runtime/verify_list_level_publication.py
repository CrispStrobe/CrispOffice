#!/usr/bin/env python3
"""Verify a published Git tree against every qualified source input.

This reads Git objects, including complete selected path sets and modes. It does
not run tests, query GitHub Actions, or mutate the checkout or any remote ref.
"""
from __future__ import annotations

import argparse
import datetime as dt
import gzip
import hashlib
import json
from pathlib import Path
import subprocess


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--qualified-inputs', type=Path, required=True)
    parser.add_argument('--target', required=True)
    parser.add_argument('--published-checkpoint', required=True)
    parser.add_argument('--required-ancestor', action='append', default=[])
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()

    def git(*argv: str) -> bytes:
        return subprocess.check_output(['git', *argv], cwd=repo)

    def resolve(ref: str, kind: str = 'commit') -> str:
        return git('rev-parse', '--verify', f'{ref}^{{{kind}}}').decode().strip()

    raw_inputs = args.qualified_inputs.read_bytes()
    decoded = gzip.decompress(raw_inputs) if args.qualified_inputs.suffix == '.gz' else raw_inputs
    manifest = json.loads(decoded)
    qualified = manifest['source_commit']
    expected = manifest['entries']
    assert manifest['head_matches_worktree'] is True
    assert all(value['head'] == {
        'mode': value['worktree_mode'], 'type': 'blob',
        'blob': value['worktree_blob'],
    } for value in expected.values())

    target = resolve(args.target)
    checkpoint = resolve(args.published_checkpoint)
    target_tree = resolve(target, 'tree')
    checkpoint_tree = resolve(checkpoint, 'tree')
    selection = manifest['selection']
    paths = selection['directories'] + selection['configuration_files']
    tree = {}
    for entry in git('ls-tree', '-rz', target, '--', *paths).split(b'\0'):
        if not entry:
            continue
        metadata, path = entry.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split()
        tree[path.decode()] = {'mode': mode, 'type': kind, 'blob': oid}

    missing = sorted(set(expected) - set(tree))
    added = sorted(set(tree) - set(expected))
    metadata_differences = sorted(
        path for path in set(expected) & set(tree)
        if tree[path] != expected[path]['head']
    )

    # A single batch read verifies object content in addition to Git identities.
    oids = sorted({entry['blob'] for entry in tree.values() if entry['type'] == 'blob'})
    objects = subprocess.run(
        ['git', 'cat-file', '--batch'], cwd=repo,
        input=('\n'.join(oids) + '\n').encode(),
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True,
    ).stdout
    offset, object_hashes = 0, {}
    for oid in oids:
        end = objects.index(b'\n', offset)
        observed, kind, size = objects[offset:end].decode().split()
        assert observed == oid and kind == 'blob'
        offset = end + 1
        size = int(size)
        data = objects[offset:offset + size]
        assert len(data) == size and objects[offset + size:offset + size + 1] == b'\n'
        offset += size + 1
        assert hashlib.sha1(f'blob {size}\0'.encode() + data).hexdigest() == oid
        object_hashes[oid] = {'bytes': size, 'sha256': hashlib.sha256(data).hexdigest()}
    assert offset == len(objects)
    entries = {
        path: {**entry, **object_hashes[entry['blob']]}
        for path, entry in sorted(tree.items()) if entry['type'] == 'blob'
    }
    content_differences = sorted(
        path for path in set(expected) & set(entries)
        if any(entries[path][key] != expected[path][key] for key in ['bytes', 'sha256'])
    )
    ancestors = {}
    for ref in dict.fromkeys([qualified, checkpoint, *args.required_ancestor]):
        commit = resolve(ref)
        check = subprocess.run(['git', 'merge-base', '--is-ancestor', commit, target], cwd=repo)
        assert check.returncode in (0, 1)
        ancestors[ref] = {'commit': commit, 'is_ancestor': check.returncode == 0}
    problems = []
    if missing or added or metadata_differences or content_differences:
        problems.append('Qualified source path set, mode, object identity or content differs')
    if target_tree != checkpoint_tree:
        problems.append('Published target complete tree differs from the checkpoint')
    if not all(value['is_ancestor'] for value in ancestors.values()):
        problems.append('Required reconciled ancestry is missing')
    canonical = (json.dumps(entries, sort_keys=True, separators=(',', ':')) + '\n').encode()
    report = {
        'schema': 'quds-word-list-level-publication-verification/v1',
        'verified_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'qualified': not problems, 'problems': problems,
        'qualified_source_commit': qualified,
        'qualified_source_tree': manifest['source_tree'],
        'qualified_manifest_sha256': hashlib.sha256(raw_inputs).hexdigest(),
        'target_ref': args.target, 'target_commit': target, 'target_tree': target_tree,
        'published_checkpoint': checkpoint, 'published_checkpoint_tree': checkpoint_tree,
        'whole_tree_matches_published_checkpoint': target_tree == checkpoint_tree,
        'source_selection': selection,
        'qualified_input_count': len(expected), 'published_input_count': len(tree),
        'complete_path_sets_equal': not missing and not added,
        'complete_modes_and_objects_equal': not metadata_differences,
        'complete_content_hashes_equal': not content_differences,
        'missing_inputs': missing, 'added_inputs': added,
        'metadata_differences': metadata_differences,
        'content_differences': content_differences,
        'required_ancestors': ancestors,
        'canonical_published_inputs_sha256': hashlib.sha256(canonical).hexdigest(),
        'published_inputs': entries,
        'remote_observation': 'Target remote-tracking ref must be freshly fetched; this verifier itself reads local Git objects only.',
        'github_actions_queried_or_awaited': False,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(report, indent=2, sort_keys=True) + '\n').encode()
    if args.output.suffix == '.gz':
        with args.output.open('wb') as out:
            with gzip.GzipFile(filename='', mode='wb', fileobj=out, mtime=0) as compressed:
                compressed.write(encoded)
    else:
        args.output.write_bytes(encoded)
    print(json.dumps({key: value for key, value in report.items() if key != 'published_inputs'}, indent=2))
    return 0 if report['qualified'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
