#!/usr/bin/env python3
"""Record the bounded publication decision without altering raw intake data."""
import collections
import datetime
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path('/workspace/scratch/33048a5794d3')
REPO = ROOT / 'quds_office_suite'
RUNTIME = ROOT / 'runtime'
OUT = RUNTIME / 'list-level-review'
TARGET = '273d78f54d2d4448c25791060eb41ae65e3d3674'
WORD_FREEZE = '3c87debcd4d50cac88981ec39255c3c6890fe8fa'
MAIL_HEAD = '0730e7f61293b8e2dbe1f25150bc8754a563b101'
DEFERRED_REFS = {
    'refs/remotes/origin/work/mail-cached-workspace-20261120',
    'refs/remotes/pull/262',
}
INITIAL_PATH = RUNTIME / 'intake-audit/initial-reconciled.json'
FINAL_PATH = RUNTIME / 'final-intake.json'
REFRESH_PATH = RUNTIME / 'intake-final-refresh.json'
MAIL_REVIEW_PATH = OUT / 'incoming-mail-0730e7-review.json'


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=REPO)


def text(*arguments):
    return git(*arguments).decode().strip()


def ancestor(head, target=TARGET):
    result = subprocess.run(['git', 'merge-base', '--is-ancestor', head, target], cwd=REPO, capture_output=True)
    if result.returncode not in (0, 1):
        raise RuntimeError(result.stderr.decode())
    return result.returncode == 0


def identity(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def load(path):
    return json.loads(path.read_bytes())


def tree(commit, paths):
    result = {}
    for row in git('ls-tree', '-rz', commit, '--', *paths).split(b'\0'):
        if row:
            metadata, path = row.split(b'\t', 1)
            mode, kind, blob = metadata.decode().split()
            result[path.decode()] = {'mode': mode, 'type': kind, 'blob': blob}
    return result


if not MAIL_REVIEW_PATH.exists():
    print(json.dumps({'scope_review_accepted': False, 'pending': str(MAIL_REVIEW_PATH)}))
    raise SystemExit(2)

initial, final, refresh, mail_review = map(load, [INITIAL_PATH, FINAL_PATH, REFRESH_PATH, MAIL_REVIEW_PATH])
bound_inputs = {str(p): identity(p) for p in [INITIAL_PATH, FINAL_PATH, REFRESH_PATH, MAIL_REVIEW_PATH]}
problems = []
def check(condition, message):
    if not condition:
        problems.append(message)

check(final['target_commit'] == TARGET, 'Final raw audit target differs from the reviewed Word checkpoint')
check(text('rev-parse', TARGET + '^{tree}') == final['target_tree'], 'Final raw target tree differs from Git')
check(initial['audited_at_utc'] < final['audited_at_utc'], 'Initial/final observation order is invalid')
check(final['all_historical_proofs_verified'] is True, 'Final raw historical proofs are not all verified')
check(final['github_actions_used'] is False and refresh['github_actions_queried_or_awaited'] is False,
      'Unexpected Actions use in intake')
exit_codes = [entry.get('exit_code') for entry in refresh['commands']]
check(exit_codes == [0, 0, 1], 'Raw final refresh must retain both successful fetches and uncovered-audit exit1')

initial_rows = [{**entry, 'group': group} for group in ['branches', 'pull_requests', 'upstream'] for entry in initial[group]]
final_rows = [{**entry, 'group': group} for group in ['branches', 'pull_requests', 'upstream'] for entry in final[group]]
initial_counts = dict(collections.Counter(entry['group'] for entry in initial_rows))
final_counts = dict(collections.Counter(entry['group'] for entry in final_rows))
check(initial_counts == {'branches': 21, 'pull_requests': 260, 'upstream': 4}, 'Initial capture counts differ from the authorized intake')
check(not initial['uncovered_ref_entries'], 'Original reconciled intake itself contained uncovered heads')
initial_refs = {entry['ref'] for entry in initial_rows}
raw_uncovered = final['uncovered_ref_entries']
expected_deferred = [{'ref': ref, 'sha': MAIL_HEAD, 'status': 'uncovered'} for ref in sorted(DEFERRED_REFS)]
canonical = lambda rows: sorted(rows, key=lambda item: (item['ref'], item['sha']))
check(canonical(raw_uncovered) == canonical(expected_deferred), 'Final uncovered refs/SHAs differ from the exact reviewed draft')
check(DEFERRED_REFS.isdisjoint(initial_refs), 'A deferred ref was present in the initial capture')
check(ancestor(WORD_FREEZE, MAIL_HEAD), 'Deferred Mail head does not descend from the frozen Word checkpoint')
check(not ancestor(MAIL_HEAD), 'Deferred Mail head has already been integrated; reassess classification')

# Verify each historical content inclusion proof against the publication target.
historical = {}
for old in initial['historical_equivalence_proofs']:
    head, accepted = old['historical_head'], old['accepted_ancestor']
    historical_tree = text('rev-parse', head + '^{tree}')
    accepted_tree = text('rev-parse', accepted + '^{tree}')
    proof = {
        'historical_head': head, 'accepted_ancestor': accepted,
        'accepted_is_ancestor_of_publication_target': ancestor(accepted),
        'historical_tree': historical_tree, 'accepted_tree': accepted_tree,
    }
    if historical_tree == accepted_tree:
        proof.update({'method': 'identical_full_tree', 'verified': ancestor(accepted)})
    else:
        paths = text('diff', '--name-only', old['comparison_base'], head).splitlines()
        original_paths = [entry['path'] for entry in old['entries']]
        left, right = tree(head, paths), tree(accepted, paths)
        valid = (head == 'c34945761e7991f5fe49037d79529acdd260b31c'
                 and accepted == '2c47165d01d01cc883135a434ac9f6591ce6e770'
                 and len(paths) == 37 and set(paths) == set(original_paths)
                 and left == right and ancestor(accepted))
        proof.update({
            'method': 'exact_changed_path_continuation', 'comparison_base': old['comparison_base'],
            'changed_path_count': len(paths), 'matches_initial_path_inventory': set(paths) == set(original_paths),
            'paths': [{
                'path': path, 'historical_entry': left.get(path), 'accepted_entry': right.get(path),
                'equal': left.get(path) == right.get(path),
            } for path in sorted(paths)], 'verified': valid,
        })
    check(proof['verified'], 'Historical inclusion proof failed: ' + head)
    historical[head] = proof
check(len(historical) == 14, 'Expected all14 explicit historical equivalence proofs')

ancestry_cache = {}
initial_proofs = []
for entry in initial_rows:
    head = entry['sha']
    ancestry_cache.setdefault(head, ancestor(head))
    proof = {key: entry[key] for key in ['group', 'ref', 'sha']}
    if ancestry_cache[head]:
        proof.update({'inclusion_method': 'ancestor', 'included': True})
    elif head in historical and historical[head]['verified']:
        proof.update({'inclusion_method': 'historical_equivalence', 'included': True,
                      'accepted_ancestor': historical[head]['accepted_ancestor'],
                      'historical_proof_head': head})
    else:
        proof.update({'inclusion_method': 'uncovered', 'included': False})
        check(False, 'Initial head is not included: ' + entry['ref'] + ' ' + head)
    initial_proofs.append(proof)

# Verify every claimed covered final row too; the two deferred rows stay uncovered.
for entry in final_rows:
    head, status = entry['sha'], entry['status']
    if status in ('ancestor', 'exact_target'):
        check(ancestor(head), 'Final claimed ancestor is absent: ' + entry['ref'])
    elif status == 'historically_superseded_equivalent':
        check(head in historical and historical[head]['verified'], 'Final equivalence is not proved: ' + entry['ref'])
    elif status == 'uncovered':
        check({'ref': entry['ref'], 'sha': head, 'status': status} in raw_uncovered,
              'Final uncovered row missing from raw uncovered set')
    else:
        check(False, 'Unrecognized final classification: ' + status)
main_rows = [entry for entry in final_rows if entry['ref'] == 'refs/remotes/origin/main']
check(len(main_rows) == 1 and ancestor(main_rows[0]['sha']), 'Captured current origin/main is not included')
main = main_rows[0]

observed = {}
for namespace in ['refs/remotes/origin', 'refs/remotes/pull', 'refs/remotes/upstream']:
    for row in text('for-each-ref', '--format=%(objectname) %(refname)', namespace).splitlines():
        sha, ref = row.split(' ', 1)
        if not ref.endswith('/HEAD'):
            observed[ref] = sha
check(observed == {entry['ref']: entry['sha'] for entry in final_rows},
      'Locally fetched ref inventory changed after raw final capture; refresh and reassess')

# The current code correction must not be mislabeled as still unfixed.
review_head = mail_review.get('captured_commit', mail_review.get('captured_source', {}).get('commit'))
check(review_head == MAIL_HEAD, 'Current Mail review is not bound to the exact deferred head')
check(mail_review.get('source_review_only') is True
      and mail_review.get('no_fresh_execution_claim') is True
      and mail_review.get('mail_runtime_qualified_by_this_review') is False
      and mail_review.get('supports_explicit_deferral') is True
      and mail_review.get('classification') == 'post_intake_draft_awaiting_source_bound_qualification'
      and mail_review.get('earlier_omissions_not_reasserted_as_unfixed') is True,
      'Current Mail review does not support the precise source-only deferral classification')
historical_reviews = []
for name, commit in [
    ('incoming-mail-2d3799-review.json', '2d3799af2d9b32e115fee4ba2f8326795fc6b29f'),
    ('incoming-mail-47d3fc-review.json', '47d3fc0d140724d64632049f398d988d540965ab'),
]:
    path = OUT / name
    bound_inputs[str(path)] = identity(path)
    historical_reviews.append({**identity(path), 'commit': commit,
                               'role': 'historical findings at this earlier head; not a claim that 0730 leaves them unfixed'})

all_initial = all(entry['included'] for entry in initial_proofs)
unclassified = [entry for entry in raw_uncovered if entry not in expected_deferred]
for name, bound in bound_inputs.items():
    check(identity(pathlib.Path(name)) == bound, 'Bound audit input changed during the scope review: ' + name)

record = {
    'schema': 'quds-word-list-level-publication-scope-review/v1',
    'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope_review_accepted': not problems, 'problems': problems,
    'decision': 'publish_qualified_word_and_defer_post_intake_mail_draft',
    'publication_target': {'commit': TARGET, 'tree': final['target_tree']},
    'word_qualified_source': WORD_FREEZE,
    'scope_basis': 'The user requested bringing recent work in first, then extending and merging Word VBA. The initial captured source set is the bounded intake obligation. This later new Mail branch/PR was absent from that capture and remains a separately developing draft; it is recorded and preserved without claiming current-inventory integration.',
    'inclusion_definition': 'Included means commit ancestry or an explicit independently rechecked historical content-equivalence proof whose accepted commit is an ancestor; it does not claim every historical commit is itself an ancestor.',
    'initial_capture': {**identity(INITIAL_PATH), 'observed_at_utc': initial['audited_at_utc'], 'counts': initial_counts},
    'initial_head_inclusion_proofs': initial_proofs,
    'historical_equivalence_proofs': list(historical.values()),
    'final_capture': {**identity(FINAL_PATH), 'observed_at_utc': final['audited_at_utc'], 'counts': final_counts},
    'final_refresh': {**identity(REFRESH_PATH), 'exit_codes': exit_codes, 'audit_exit_code': exit_codes[-1]},
    'current_origin_main': {'ref': main['ref'], 'sha': main['sha'], 'inclusion_method': 'ancestor'},
    'all_initial_heads_included': all_initial,
    'all_final_heads_included': False,
    'deferred_ref_entries': raw_uncovered,
    'deferred_head_reviews': [{
        **identity(MAIL_REVIEW_PATH), 'commit': MAIL_HEAD,
        'classification': 'post_intake_draft_awaiting_source_bound_qualification',
        'findings_note': 'The 0730 source delta contains corrections for the earlier quota-recovery and metadata-preflight findings. The captured Mail validation remains an earlier checkpoint, so these corrections are not described as freshly qualified here.',
    }],
    'historical_mail_reviews': historical_reviews,
    'historical_review_bindings': [{key: item[key] for key in ['path', 'bytes', 'sha256']} for item in historical_reviews],
    'unclassified_uncovered_ref_entries': unclassified,
    'all_deferred_refs_absent_from_initial_capture': DEFERRED_REFS.isdisjoint(initial_refs),
    'all_deferred_heads_descend_from_word_freeze': ancestor(WORD_FREEZE, MAIL_HEAD),
    'preservation': {
        'mail_branch': 'work/mail-cached-workspace-20261120', 'mail_pr': 262,
        'immutable_commit': MAIL_HEAD,
        'prior_heads_remain_ancestors_of_deferred_head': all(ancestor(item['commit'], MAIL_HEAD) for item in historical_reviews),
        'captured_ref_set_matches_current_local_fetched_refs': observed == {entry['ref']: entry['sha'] for entry in final_rows},
        'raw_final_audit_and_refresh_modified': False,
    },
    'publication_conditions': [
        'Publish the qualified Word checkpoint and descendants that retain its qualified source inputs and all initial inclusion proofs.',
        'Retain raw final uncovered refs and audit exit1; do not describe the entire final inventory as incorporated.',
        'Only the exact two new Mail refs at the reviewed SHA are classified as deferred. Any new unclassified ref or different captured Mail head requires reassessment.',
        'Fresh remote main must remain included. Preserve the Mail branch, draft PR and immutable review/evidence hashes; do not erase or abandon that work.',
        'The Word test results do not qualify Mail, provider or Flutter code, including the corrected but not freshly qualified post-intake draft.',
    ],
    'github_actions_queried_or_awaited': False,
    'scope_review_script': identity(pathlib.Path(__file__)),
}
(OUT / 'publication-scope-review.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: record[key] for key in ['scope_review_accepted', 'problems', 'publication_target',
    'all_initial_heads_included', 'all_final_heads_included', 'deferred_ref_entries', 'unclassified_uncovered_ref_entries']}, indent=2))
raise SystemExit(0 if not problems else 1)
