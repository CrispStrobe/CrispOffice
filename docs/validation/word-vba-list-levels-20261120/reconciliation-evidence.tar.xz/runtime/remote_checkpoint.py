"""Export an explicitly staged checkpoint for authenticated GitHub API publication.

This helper never sends credentials or network requests. Its manifest binds the
parent, full index tree, and exact object identities; blobs are read separately
by SHA so ongoing working-tree edits cannot alter an in-flight checkpoint.
"""
import base64
import json
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1] / 'quds_office_suite'

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

if sys.argv[1] == 'manifest':
    parent = git('rev-parse', 'HEAD').decode().strip()
    entries = []
    for record in git('diff-index', '--cached', '--raw', '--no-abbrev', '-z', parent).split(b'\0'):
        if not record:
            continue
        if record.startswith(b':'):
            old_mode, mode, old_sha, sha, status = record.decode().split()
        else:
            path = record.decode()
            entries.append({'path': path, 'mode': mode, 'sha': sha,
                            'deleted': status == 'D',
                            'size': 0 if status == 'D' else int(git('cat-file', '-s', sha))})
    print(json.dumps({'parent': parent, 'base_tree': git('rev-parse', parent + '^{tree}').decode().strip(),
                      'tree': git('write-tree').decode().strip(), 'entries': entries}))
elif sys.argv[1] == 'blob':
    payload = git('cat-file', 'blob', sys.argv[2])
    start = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    count = int(sys.argv[4]) if len(sys.argv) > 4 else len(payload)
    print(base64.b64encode(payload[start:start+count]).decode())
else:
    raise SystemExit('Expected manifest or blob')
