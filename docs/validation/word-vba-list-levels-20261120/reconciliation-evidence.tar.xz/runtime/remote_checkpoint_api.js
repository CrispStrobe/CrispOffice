// Recorded code-mode GitHub API orchestration; requires tools, load, store and text globals.
async function checkpoint(message, additionalParents = []) {
 const repo="/workspace/scratch/33048a5794d3/quds_office_suite", helper="/workspace/scratch/33048a5794d3/runtime/remote_checkpoint.py", branch="codex/word-vba-list-levels-20261120", full="CrispStrobe/quds_office_suite";
 const run=async(cmd)=>{let r=await tools.exec_command({cmd,workdir:repo,yield_time_ms:1000,max_output_tokens:40000});let combined=r.output;while(r.session_id){r=await tools.write_stdin({session_id:r.session_id,chars:"",yield_time_ms:1000,max_output_tokens:40000});combined+=r.output;}if(r.exit_code!==0)throw new Error(combined);return combined;};
 const data=(r)=>{if(r.isError)throw new Error(JSON.stringify(r));if(r.structuredContent)return r.structuredContent;throw new Error("Missing result: "+JSON.stringify(r));};
 const m=JSON.parse(await run(`python ${helper} manifest`));
 if(!m.entries.length)throw new Error("No staged changes");
 const existing=new Set(load("uploadedGitBlobs")||[]);
 for(const e of m.entries){
  if(e.deleted||existing.has(e.sha))continue;
  const chunks=[];
  for(let start=0;start<e.size;start+=8190)chunks.push({start,count:Math.min(8190,e.size-start)});
  const b64=[];
  for(let k=0;k<chunks.length;k+=8){
   const group=await Promise.allSettled(chunks.slice(k,k+8).map(c=>run(`python ${helper} blob ${e.sha} ${c.start} ${c.count}`)));
   for(let j=0;j<group.length;j++){const g=group[j];if(g.status!=="fulfilled")throw g.reason;const s=g.value.trim();if(s.length!==Math.ceil(chunks[k+j].count/3)*4)throw new Error("Truncated blob "+e.path);b64.push(s);}
  }
  const r=data(await tools.mcp__codex_apps__github_create_blob({repository_full_name:full,content:b64.join(""),encoding:"base64"}));
  if(r.sha!==e.sha)throw new Error("Blob mismatch "+JSON.stringify(r));
  existing.add(e.sha);store("uploadedGitBlobs",[...existing]);
 }
 const tree=data(await tools.mcp__codex_apps__github_create_tree({repository_full_name:full,base_tree_sha:m.base_tree,tree_elements:m.entries.map(e=>({path:e.path,mode:e.deleted?"100644":e.mode,type:"blob",sha:e.deleted?null:e.sha}))}));
 if(tree.sha!==m.tree)throw new Error("Tree mismatch "+JSON.stringify(tree));
 const commit=data(await tools.mcp__codex_apps__github_create_commit({repository_full_name:full,parent_sha:m.parent,additional_parent_shas:additionalParents,message,tree_sha:m.tree}));
 if(!/^[a-f0-9]{40}$/.test(commit.sha))throw new Error("Commit shape "+JSON.stringify(commit));
 const ref=data(await tools.mcp__codex_apps__github_update_ref({repository_full_name:full,branch_name:branch,sha:commit.sha,expected_sha:m.parent,force:false}));
 await run(`git fetch origin '+refs/heads/${branch}:refs/remotes/origin/${branch}'`);
 await run(`git update-ref refs/heads/${branch} ${commit.sha} ${m.parent}`);
 const actual=(await run("git rev-parse 'HEAD^{tree}'")).trim();
 if(actual!==m.tree)throw new Error("Local tree mismatch");
 const receipt={message,parent:m.parent,additionalParents,sha:commit.sha,tree:m.tree,files:m.entries.map(e=>({path:e.path,sha:e.sha,mode:e.mode})),branch,ref,verified:true};
 const receipts=load("checkpointReceipts")||[];receipts.push(receipt);store("checkpointReceipts",receipts);
 text({checkpoint:commit.sha,tree:m.tree,files:m.entries.length,branch,verified:true});
 return receipt;
}
