#!/usr/bin/env python3
"""Refresh fork, PR and upstream heads, recording exact fetch commands/results."""
import argparse
import datetime as dt
import json
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--label', required=True)
parser.add_argument('--audit-output', type=Path, required=True)
args = parser.parse_args()
assert args.label.replace('-', '').replace('_', '').isalnum()
runtime = Path(__file__).resolve().parent
repo = runtime.parent / 'quds_office_suite'
record = {'github_actions_queried_or_awaited': False, 'commands': []}
commands = [
    ['git', 'fetch', 'origin', '+refs/heads/*:refs/remotes/origin/*',
     '+refs/pull/*/head:refs/remotes/pull/*'],
    ['git', 'fetch', 'upstream', '+refs/heads/*:refs/remotes/upstream/*'],
    ['python', 'docs/validation/word-vba-list-levels-20261120/audit_intake.py',
     '--repo', str(repo), '--target', 'HEAD', '--output', str(args.audit_output.resolve())],
]
with (runtime / f'{args.label}.stdout').open('xb') as stdout, (runtime / f'{args.label}.stderr').open('xb') as stderr:
    for command in commands:
        start = dt.datetime.now(dt.timezone.utc).isoformat()
        beginning = time.monotonic()
        result = subprocess.run(command, cwd=repo, stdout=stdout, stderr=stderr)
        record['commands'].append({'argv': command, 'cwd': str(repo),
            'started_utc': start, 'seconds': round(time.monotonic() - beginning, 3),
            'exit_code': result.returncode})
        (runtime / f'{args.label}.json').write_text(json.dumps(record, indent=2) + '\n')
        if result.returncode:
            raise SystemExit(result.returncode)
record['complete'] = True
(runtime / f'{args.label}.json').write_text(json.dumps(record, indent=2) + '\n')
audit = json.loads(args.audit_output.read_text())
print(json.dumps({key: audit[key] for key in ['target_commit', 'target_tree', 'summary',
      'uncovered_ref_entries', 'all_historical_proofs_verified']}, indent=2))
