#!/usr/bin/env python3
"""Prepare or run source-bound whole-engine analysis and changed-file formatting."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

import word_office_gate as gate


RUNTIME = Path(__file__).resolve().parent
REPO = RUNTIME.parent / 'quds_office_suite'
DART = RUNTIME / 'dart-sdk/bin/dart'
DEFAULT_BASELINE = '46e98c8c7ec65e67e8f71dc386804693e8ef1163'


def file_identity(path: Path) -> dict[str, object]:
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return {'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def runtime_manifest() -> dict[str, object]:
    result = gate.runtime_manifest(Path(__file__).resolve())
    for path in [
        DART.resolve(), Path(sys.executable).resolve(),
        RUNTIME / 'dart-sdk/bin/dartaotruntime',
        RUNTIME / 'dart-sdk/bin/snapshots/dartdev_aot.dart.snapshot',
        RUNTIME / 'dart-sdk/bin/snapshots/analysis_server_aot.dart.snapshot',
        RUNTIME / 'dart-sdk/bin/snapshots/analysis_server.dart.snapshot',
        RUNTIME / 'dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot',
        RUNTIME / 'dart-sdk/bin/snapshots/gen_kernel_aot.dart.snapshot',
        RUNTIME / 'dart-sdk/bin/snapshots/kernel-service.dart.snapshot',
    ]:
        assert path.is_file(), f'Missing runtime input: {path}'
        result[str(path)] = file_identity(path)
    return result


def prepare(out: Path, baseline: str, expected_file_count: int) -> dict[str, object]:
    out.mkdir(parents=True, exist_ok=False)
    files = subprocess.check_output(
        ['git', 'diff', '--name-only', baseline, '--',
         'packages/quds_office_engine'],
        cwd=REPO, text=True,
    ).splitlines()
    files = sorted(name for name in files if name.endswith('.dart'))
    plan = {
        'prepared_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'source_commit_at_preparation': gate.git('rev-parse', 'HEAD'),
        'baseline': baseline,
        'file_selection': 'All tracked engine Dart changes since baseline, including the current worktree; execution requires complete inputs to match HEAD. No exclusions.',
        'files': files,
        'file_count': len(files),
        'expected_file_count': expected_file_count,
        'commands': [
            {
                'name': 'analysis',
                'argv': [str(DART), 'analyze', '--fatal-infos',
                         'packages/quds_office_engine'],
                'cwd': str(REPO),
            },
            {
                'name': 'format',
                'argv': [str(DART), 'format', '--output=none',
                         '--set-exit-if-changed', *files],
                'cwd': str(REPO),
            },
        ],
        'checks_started': False,
    }
    gate.save(out / 'plan.json', plan)
    return plan


def execute(out: Path, plan: dict[str, object]) -> int:
    before = gate.source_manifest()
    before['runtime_inputs'] = runtime_manifest()
    gate.save(out / 'inputs-before.json.gz', before)
    shutil.copyfile(Path(__file__), out / 'runner.py')
    shutil.copyfile(Path(gate.__file__), out / 'gate-helper.py')
    files = plan['files']
    preflight = []
    if len(files) != plan['expected_file_count']:
        preflight.append('Changed Dart-file count differs from the reviewed scope')
    if not before['head_matches_worktree']:
        preflight.append('Source input worktree is not identical to HEAD')
    for name in files:
        if name not in before['entries']:
            preflight.append(f'Changed Dart file is outside the input manifest: {name}')
    if preflight:
        gate.save(out / 'summary.json', {
            'qualified': False, 'checks_started': False, 'problems': preflight,
            'source_commit': before['source_commit'],
            'source_tree': before['source_tree'],
        })
        print(json.dumps({'qualified': False, 'problems': preflight}), flush=True)
        return 1

    environment = os.environ.copy()
    environment.update({
        'PUB_CACHE': str(RUNTIME / 'pub-cache'),
        'TMPDIR': str(RUNTIME / 'tmp'),
        'XDG_CONFIG_HOME': str(RUNTIME / 'config'),
        'XDG_CACHE_HOME': str(RUNTIME / 'cache'),
        'DART_SUPPRESS_ANALYTICS': 'true',
        'PATH': str(RUNTIME / 'dart-sdk/bin') + os.pathsep + environment['PATH'],
    })
    receipts = []
    for command in plan['commands']:
        name = command['name']
        started = dt.datetime.now(dt.timezone.utc).isoformat()
        beginning = time.monotonic()
        with (out / f'{name}.stdout').open('wb') as stdout, (out / f'{name}.stderr').open('wb') as stderr:
            result = subprocess.run(command['argv'], cwd=command['cwd'],
                                    env=environment, stdout=stdout, stderr=stderr)
        receipt = {
            **command, 'source_commit': before['source_commit'],
            'source_tree': before['source_tree'], 'started_utc': started,
            'seconds': round(time.monotonic() - beginning, 3),
            'exit_code': result.returncode,
            'stdout': file_identity(out / f'{name}.stdout'),
            'stderr': file_identity(out / f'{name}.stderr'),
        }
        if name == 'format':
            receipt.update({'files': files, 'file_count': len(files)})
        receipts.append(receipt)
        gate.save(out / f'{name}.json', receipt)
        print(json.dumps({key: receipt[key] for key in ['name', 'exit_code', 'seconds']}), flush=True)

    after = gate.source_manifest()
    after['runtime_inputs'] = runtime_manifest()
    gate.save(out / 'inputs-after.json.gz', after)
    problems = []
    source_unchanged = before['entries'] == after['entries']
    runtime_unchanged = before['runtime_inputs'] == after['runtime_inputs']
    if not source_unchanged:
        problems.append('Complete source input identities or path set changed')
    if not runtime_unchanged:
        problems.append('Runtime inputs changed')
    if not after['head_matches_worktree']:
        problems.append('Final source input worktree is not identical to HEAD')
    for receipt in receipts:
        if receipt['exit_code']:
            problems.append(f"{receipt['name']} exited {receipt['exit_code']}")
    analysis_clean = 'No issues found!' in (out / 'analysis.stdout').read_text()
    if not analysis_clean:
        problems.append('Analysis did not report No issues found')
    formatting = re.search(
        r'Formatted\s+(\d+)\s+files?\s+\((\d+)\s+changed\)',
        (out / 'format.stdout').read_text(),
    )
    formatting_clean = bool(formatting and int(formatting.group(1)) == len(files)
                            and int(formatting.group(2)) == 0)
    if not formatting_clean:
        problems.append('Formatting did not report the complete file set with zero changes')
    summary = {
        'qualified': not problems,
        'checks_started': True,
        'problems': problems,
        'source_commit': before['source_commit'],
        'source_tree': before['source_tree'],
        'source_commit_after': after['source_commit'],
        'source_tree_after': after['source_tree'],
        'head_matches_worktree_before': before['head_matches_worktree'],
        'head_matches_worktree_after': after['head_matches_worktree'],
        'source_inputs_unchanged': source_unchanged,
        'runtime_inputs_unchanged': runtime_unchanged,
        'source_input_count': len(before['entries']),
        'runtime_input_count': len(before['runtime_inputs']),
        'analysis_clean': analysis_clean,
        'formatting_clean': formatting_clean,
        'formatted_files': files,
        'formatted_file_count': len(files),
        'commands': receipts,
        'hashes': {path.name: file_identity(path) for path in sorted(out.iterdir()) if path.is_file()},
    }
    gate.save(out / 'summary.json', summary)
    print(json.dumps({key: summary[key] for key in [
        'qualified', 'source_input_count', 'runtime_input_count',
        'formatted_file_count', 'source_inputs_unchanged', 'runtime_inputs_unchanged', 'problems',
    ]}), flush=True)
    return 0 if summary['qualified'] else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'run'])
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--baseline', default=DEFAULT_BASELINE)
    parser.add_argument('--expected-dart-files', type=int, default=9)
    args = parser.parse_args()
    out = args.out.resolve()
    plan = prepare(out, args.baseline, args.expected_dart_files)
    if args.action == 'prepare':
        print(json.dumps({'prepared': True, 'checks_started': False,
                          'file_count': plan['file_count'], 'plan': str(out / 'plan.json')}))
        return 0
    return execute(out, plan)


if __name__ == '__main__':
    raise SystemExit(main())
