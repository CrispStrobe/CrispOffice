export QUDS_VALIDATION_ROOT=/workspace/scratch/33048a5794d3/quds_office_suite
export QUDS_DART_ROOT=/workspace/scratch/33048a5794d3/runtime/dart-sdk
export PUB_CACHE=/workspace/scratch/33048a5794d3/runtime/pub-cache
export TMPDIR=/workspace/scratch/33048a5794d3/runtime/tmp
export XDG_CONFIG_HOME=/workspace/scratch/33048a5794d3/runtime/config
export XDG_CACHE_HOME=/workspace/scratch/33048a5794d3/runtime/cache
export DART_SUPPRESS_ANALYTICS=true
export PATH="$QUDS_DART_ROOT/bin:$PATH"
