import datetime
import hashlib
import json
import pathlib
import subprocess
import time

workspace = pathlib.Path('/workspace/scratch/33048a5794d3')
repo = workspace / 'quds_office_suite'
evidence = workspace / 'runtime/list-level-review'
dart = workspace / 'runtime/dart-sdk/bin/dart'
config = repo / '.dart_tool/package_config.json'


def manifest():
    paths = sorted((repo / 'packages/quds_office_engine/lib').rglob('*.dart'))
    paths += sorted((repo / 'packages/quds_office_fonts/lib').rglob('*.dart'))
    paths += [config, dart, evidence / 'probe.dart']
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}


before = manifest()
cmd = [str(dart), '--old_gen_heap_size=768', '--packages=' + str(config), str(evidence / 'probe.dart')]
for name in ['probe-final.json', 'probe-final.stderr', 'probe-final-receipt.json']:
    old = evidence / name
    archived = evidence / name.replace('probe-final', 'probe-nine-accepted')
    if old.exists() and not archived.exists():
        archived.write_bytes(old.read_bytes())
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
result = subprocess.run(cmd, cwd=repo, capture_output=True)
duration = time.monotonic() - start
(evidence / 'probe-final.json').write_bytes(result.stdout)
(evidence / 'probe-final.stderr').write_bytes(result.stderr)
after = manifest()
parsed = json.loads(result.stdout) if result.returncode == 0 else None
receipt = {
    'schema': 'quds-word-list-level-independent-probes/v1',
    'started_utc': started,
    'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'cwd': str(repo),
    'command': cmd,
    'duration_seconds': duration,
    'exit_code': result.returncode,
    'source_before': before,
    'source_after': after,
    'inputs_unchanged': before == after,
    'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
    'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(),
    'passed': parsed['passed'] if parsed else 0,
    'count': parsed['count'] if parsed else 0,
    'accepted': result.returncode == 0 and before == after and parsed['passed'] == parsed['count'],
    'scope': 'Eighteen independent preservation, geometry, inherited-right, rebound-namespace, and plain import probes on Dart VM; this is not the main regression gate or Word COM execution.',
}
(evidence / 'probe-final-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['source_before','source_after']}, indent=2))
raise SystemExit(0 if receipt['accepted'] else 1)
