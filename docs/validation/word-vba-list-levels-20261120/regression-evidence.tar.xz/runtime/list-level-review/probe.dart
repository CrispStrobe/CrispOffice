import 'dart:convert';
import 'dart:typed_data';
import 'package:quds_office_engine/quds_office_automation.dart';
import 'package:quds_office_engine/quds_office_engine.dart';

const w = OfficeNamespaces.w;

Uint8List fixture({String style = '', String targetIndent = 'w:left="720" w:hanging="180"', String overrides = '', String sourceIndent = ''}) {
  final p = OpcPackage.openBytes((DocxDocumentBuilder()..paragraph('seed')).build());
  p.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="$w"><w:body><w:p><w:pPr><w:pStyle w:val="Probe"/><w:numPr><w:ilvl w:val="0"/><w:numId w:val="71"/></w:numPr>$sourceIndent</w:pPr><w:r><w:t>value</w:t></w:r></w:p><w:sectPr/></w:body></w:document>');
  p.getPart('/word/styles.xml')!.writeText('<w:styles xmlns:w="$w"><w:style w:type="paragraph" w:styleId="Probe"><w:name w:val="Probe"/><w:pPr>$style</w:pPr></w:style></w:styles>');
  final number = '<w:numbering xmlns:w="$w"><w:abstractNum w:abstractNumId="42"><w:multiLevelType w:val="multilevel"/><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1."/><w:pPr><w:ind w:left="360" w:hanging="180"/></w:pPr></w:lvl><w:lvl w:ilvl="1"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1.%2."/><w:pPr><w:ind $targetIndent/></w:pPr></w:lvl></w:abstractNum><w:num w:numId="71"><w:abstractNumId w:val="42"/>$overrides</w:num></w:numbering>';
  final part = p.getPart('/word/numbering.xml');
  if (part == null) { p.createPart('/word/numbering.xml', OfficeContentTypes.wordNumbering, utf8.encode(number)); } else { part.writeText(number); }
  final rels = p.relationshipsFor('/word/document.xml');
  if (rels.firstByType(RelationshipTypes.numbering) == null) { rels.add(type: RelationshipTypes.numbering, target: 'numbering.xml'); }
  return p.save();
}

Future<Map<String,Object?>> probe(String name, Uint8List bytes, {bool refuse=false, double first=0, double hanging=9}) async {
  final session = OfficeMacroSession(bytes, format: OfficeMacroFormat.docx);
  final numberBefore = OpcPackage.openBytes(bytes).getPart('/word/numbering.xml')!.readBytes();
  Map<String,String> definitions(List<int> raw) {
    final root = XmlDocument.parse(utf8.decode(raw)).root!;
    return {
      for (final n in root.childElements)
        if (n.localName=='abstractNum' || n.localName=='num')
          '${n.localName}:${n.getAttribute(n.localName=='num'?'numId':'abstractNumId',namespaceUri:w)}': XmlDocument(root:n.copy()).toXmlString(declaration:false),
    };
  }
  final originalDefinitions = definitions(numberBefore);
  try {
    await session.run(OfficeMacro(name:'probe',format:OfficeMacroFormat.docx,steps:[OfficeMacroStep(tool:'docx.listLevel',arguments:{'paragraph':0,'level':1})]));
    final doc = WordDeserializer().readBytes(session.bytes);
    final props = doc.paragraphs.single.properties;
    final package = OpcPackage.openBytes(session.bytes);
    final numberAfter = package.getPart('/word/numbering.xml')!.readBytes();
    final afterDefinitions = definitions(numberAfter);
    final equal = originalDefinitions.entries.every((e)=>afterDefinitions[e.key]==e.value);
    final success = !refuse && props.numId==71 && props.ilvl==1 && props.indent.left==36 && props.indent.firstLine==first && props.indent.hanging==hanging && equal;
    return {'name':name,'success':success,'refused':false,'expectedRefusal':refuse,'numId':props.numId,'level':props.ilvl,'left':props.indent.left,'firstLine':props.indent.firstLine,'hanging':props.indent.hanging,'originalDefinitionsUnchanged':equal,'completeNumberingPartBytesEqual':base64.encode(numberBefore)==base64.encode(numberAfter),'xml':package.getPart('/word/document.xml')!.readText()};
  } catch (e) {
    return {'name':name,'success':refuse && base64.encode(session.bytes)==base64.encode(bytes) && session.revision==0,'refused':true,'expectedRefusal':refuse,'error':'$e'};
  }
}

Future<Map<String, Object?>> rightInheritanceProbe(String name, {bool outline = false, bool priorWrite = false, bool explicitRight = false, bool reboundStyle = false}) async {
  var bytes = fixture(style: '<w:ind w:right="240"/>', sourceIndent: explicitRight ? '<w:ind w:right="340"/>' : '');
  if (reboundStyle) {
    final input = OpcPackage.openBytes(bytes);
    input.getPart('/word/styles.xml')!.writeText('<q:styles xmlns:q="$w" xmlns:w="urn:review-style-extension"><q:style q:type="paragraph" q:styleId="Probe"><q:name q:val="Probe"/><q:pPr><q:ind q:right="240"/></q:pPr></q:style></q:styles>');
    bytes=input.save();
  }
  if (outline) {
    final input = OpcPackage.openBytes(bytes);
    final part = input.getPart('/word/document.xml')!;
    part.writeText(part.readText().replaceFirst('<w:numPr><w:ilvl w:val="0"/><w:numId w:val="71"/></w:numPr>', ''));
    bytes = input.save();
  }
  final session = OfficeMacroSession(bytes, format: OfficeMacroFormat.docx);
  try {
    await session.run(OfficeMacro(name: name, format: OfficeMacroFormat.docx, steps: [
      if (priorWrite) OfficeMacroStep(tool:'docx.paragraphFormat', arguments:{'paragraph':0, 'right':33}),
      OfficeMacroStep(tool: outline ? 'docx.listOutlineDefault' : 'docx.listLevel', arguments:{'paragraph':0, if (!outline) 'level':1}),
    ]));
    String? directRight(Uint8List saved) {
      final xml = XmlDocument.parse(OpcPackage.openBytes(saved).getPart('/word/document.xml')!.readText());
      return xml.root!.firstChild('body', namespaceUri:w)!.firstChild('p', namespaceUri:w)!.firstChild('pPr', namespaceUri:w)!.firstChild('ind', namespaceUri:w)!.getAttribute('right', namespaceUri:w);
    }
    final expectedDirect = priorWrite ? '660' : explicitRight ? '340' : null;
    final expectedInitial = priorWrite ? 33.0 : explicitRight ? 17.0 : 12.0;
    var saved = session.bytes;
    var stable = true;
    for (var cycle = 0; cycle < 3; cycle++) {
      final props = WordDeserializer().readBytes(saved).paragraphs.single.properties;
      stable = stable && directRight(saved) == expectedDirect && props.indent.right == expectedInitial;
      if (cycle < 2) saved = WordSerializer().writeBytes(WordDeserializer().readBytes(saved));
    }
    final beforeDirect = directRight(saved);
    final styleSession = OfficeMacroSession(saved, format:OfficeMacroFormat.docx);
    await styleSession.run(OfficeMacro(name:'later right style write', format:OfficeMacroFormat.docx, steps:[OfficeMacroStep(tool:'docx.styleDefinition', arguments:{'style':'Probe','pPr':{'ind':{'right':'500'}}})]));
    final after = WordDeserializer().readBytes(styleSession.bytes).paragraphs.single.properties;
    final afterDirect = directRight(styleSession.bytes);
    final expectedFinal = priorWrite ? 33.0 : explicitRight ? 17.0 : 25.0;
    return {'name':name,'success':stable && afterDirect == expectedDirect && after.indent.right == expectedFinal && after.indent.left == (outline ? 18.0 : 36.0), 'stableAcrossTwoAdditionalReopens':stable,'directRightBeforeStyleEdit':beforeDirect,'directRightAfterStyleEdit':afterDirect,'rightAfterStyleEdit':after.indent.right,'leftAfterStyleEdit':after.indent.left,'priorExplicitWrite':priorWrite,'originalDirectRight':explicitRight};
  } catch (error) {
    return {'name':name,'success':false,'error':'$error'};
  }
}

Future<Map<String, Object?>> namespaceProbe({bool outline = false, bool noOperation = false}) async {
  const extension = 'urn:review-extension';
  const metadata = 'urn:review-metadata';
  final package = OpcPackage.openBytes(fixture());
  final document = package.getPart('/word/document.xml')!;
  const prefixProperties = '<q:pPr xmlns:q="$w" xmlns:w="$extension" xmlns:x="$metadata" x:w1="root" w:keep="extension"><q:numPr x:w1="num"><q:ilvl q:val="0" x:w1="level"/><q:numId q:val="71" x:w1="id"/></q:numPr><q:ind q:left="1440" q:right="240" x:w1="indent"/><w:opaque w:keep="child"/></q:pPr>';
  document.writeText('<w:document xmlns:w="$w"><w:body><w:p>$prefixProperties<w:r><w:t>value</w:t></w:r></w:p><w:sectPr/></w:body></w:document>');
  if (outline) {
    final numbering = package.getPart('/word/numbering.xml')!;
    numbering.writeText(numbering.readText().replaceFirst('w:val="multilevel"', 'w:val="singleLevel"'));
  }
  final session = OfficeMacroSession(package.save(), format:OfficeMacroFormat.docx);
  final name = '${noOperation ? 'plain import' : outline ? 'outline' : 'level'} rebound Word prefix preserves native right and foreign indentation metadata';
  try {
    if (!noOperation) await session.run(OfficeMacro(name:name, format:OfficeMacroFormat.docx, steps:[OfficeMacroStep(tool:outline ? 'docx.listOutlineDefault' : 'docx.listLevel', arguments:{'paragraph':0, if (!outline) 'level':1})]));
    var saved = session.bytes;
    final cycles = <Map<String,Object?>>[];
    for (var cycle=0;cycle<3;cycle++) {
      final raw = XmlDocument.parse(OpcPackage.openBytes(saved).getPart('/word/document.xml')!.readText());
      final pp = raw.root!.firstChild('body', namespaceUri:w)!.firstChild('p', namespaceUri:w)!.firstChild('pPr', namespaceUri:w)!;
      final direct = pp.firstChild('ind', namespaceUri:w)!;
      final number = pp.firstChild('numPr', namespaceUri:w)!;
      final props = WordDeserializer().readBytes(saved).paragraphs.single.properties;
      final foreign = pp.getAttribute('w1', namespaceUri:metadata)=='root' && pp.getAttribute('keep', namespaceUri:extension)=='extension' && pp.firstChild('opaque', namespaceUri:extension)?.getAttribute('keep', namespaceUri:extension)=='child' && direct.getAttribute('w1', namespaceUri:metadata)=='indent' && number.getAttribute('w1', namespaceUri:metadata)=='num' && number.firstChild('ilvl', namespaceUri:w)?.getAttribute('w1', namespaceUri:metadata)=='level' && number.firstChild('numId', namespaceUri:w)?.getAttribute('w1', namespaceUri:metadata)=='id';
      cycles.add({'cycle':cycle,'foreignMetadataPreserved':foreign,'right':props.indent.right,'left':props.indent.left,'hanging':props.indent.hanging,'success':foreign && props.indent.right==12 && props.indent.left==(noOperation?72:outline?18:36) && props.indent.hanging==(noOperation?0:9),'propertiesXml':XmlDocument(root:pp.copy()).toXmlString(declaration:false)});
      if (cycle<2) saved=WordSerializer().writeBytes(WordDeserializer().readBytes(saved));
    }
    return {'name':name,'success':cycles.every((c)=>c['success']==true),'cycles':cycles};
  } catch (error) {
    return {'name':name,'success':false,'error':'$error'};
  }
}

Future<void> main() async {
  final results = <Map<String,Object?>>[];
  results.add(await probe('plain inherited numbered level', fixture()));
  results.add(await probe('positive first line raw source',fixture(targetIndent:'w:left="720" w:firstLine="180"'),first:9,hanging:0));
  results.add(await probe('positive first line with inherited hanging',fixture(style:'<w:ind w:left="1440" w:hanging="360"/>',targetIndent:'w:left="720" w:firstLine="180"'),refuse:true));
  results.add(await probe('positive first line alongside explicit zero hanging',fixture(targetIndent:'w:left="720" w:firstLine="180" w:hanging="0"'),refuse:true));
  results.add(await probe('inherited character indentation',fixture(style:'<w:ind w:left="1440" w:hangingChars="300"/>'),refuse:true));
  results.add(await probe('inherited logical indentation',fixture(style:'<w:ind w:start="1440"/>'),refuse:true));
  results.add(await probe('duplicate ancestor starts',fixture(overrides:'<w:lvlOverride w:ilvl="0"><w:startOverride w:val="2"/><w:startOverride w:val="3"/></w:lvlOverride>'),refuse:true));
  results.add(await probe('nonpositive ancestor start',fixture(overrides:'<w:lvlOverride w:ilvl="0"><w:startOverride w:val="0"/></w:lvlOverride>'),refuse:true));
  results.add(await probe('imported ancestor start preserved',fixture(overrides:'<w:lvlOverride w:ilvl="0"><w:startOverride w:val="7"/></w:lvlOverride>')));
  results.add(await rightInheritanceProbe('level geometry retains right inheritance under later style edit'));
  results.add(await rightInheritanceProbe('outline geometry retains right inheritance under later style edit', outline:true));
  results.add(await rightInheritanceProbe('level geometry retains prior explicit right write', priorWrite:true));
  results.add(await rightInheritanceProbe('level geometry retains original direct right indent', explicitRight:true));
  results.add(await namespaceProbe());
  results.add(await namespaceProbe(outline:true));
  results.add(await namespaceProbe(noOperation:true));
  results.add(await rightInheritanceProbe('level geometry retains rebound-style right inheritance under later style edit', reboundStyle:true));
  results.add(await rightInheritanceProbe('outline geometry retains rebound-style right inheritance under later style edit', reboundStyle:true, outline:true));
  print(jsonEncode({'results':results,'passed':results.where((r)=>r['success']==true).length,'count':results.length}));
}
