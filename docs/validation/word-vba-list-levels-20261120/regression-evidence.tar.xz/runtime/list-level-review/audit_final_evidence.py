#!/usr/bin/env python3
"""Independent audit of completed final evidence; does not import collectors."""
import base64
import collections
import datetime
import gzip
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import tarfile

ROOT = pathlib.Path('/workspace/scratch/33048a5794d3')
REPO = ROOT / 'quds_office_suite'
RUNTIME = ROOT / 'runtime'
OUT = RUNTIME / 'list-level-review'
FROZEN = '3c87debcd4d50cac88981ec39255c3c6890fe8fa'
TREE = '9bd6e399e689cc12d6ff51090c038c72f4901d05'
BASELINE = '46e98c8c7ec65e67e8f71dc386804693e8ef1163'
DIRS = [
    'packages/quds_office_engine/lib', 'packages/quds_office_engine/test',
    'packages/quds_office_engine/tool', 'packages/quds_office_engine/example',
    'packages/legacy_doc_parser/lib',
]
CONFIGS = [
    'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
    'packages/quds_office_engine/pubspec.yaml',
    'packages/quds_office_engine/analysis_options.yaml',
    'packages/legacy_doc_parser/pubspec.yaml',
    'packages/legacy_doc_parser/analysis_options.yaml',
]
STAGES = {
    'regression': RUNTIME / 'word-office-final',
    'checks': RUNTIME / 'list-level-final-checks',
    'portable': RUNTIME / 'list-level-portable-final',
}
problems = []


def check(condition, message):
    if not condition:
        problems.append(message)


def read(path):
    if path.suffix == '.gz':
        return json.loads(gzip.decompress(path.read_bytes()))
    return json.loads(path.read_bytes())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': digest(data)}


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=REPO)


def tree_entries(commit, paths):
    result = {}
    for item in git('ls-tree', '-rz', commit, '--', *paths).split(b'\0'):
        if not item:
            continue
        metadata, path = item.split(b'\t', 1)
        mode, kind, blob = metadata.decode().split()
        result[path.decode()] = {'mode': mode, 'type': kind, 'blob': blob}
    return result


missing = [str(path / 'summary.json') for path in STAGES.values()
           if not (path / 'summary.json').exists()]
invocation_path = RUNTIME / 'final-gates-invocation.json'
invocation = read(invocation_path) if invocation_path.is_file() else {}
if invocation.get('complete') is not True:
    missing.append('completed final-gates-invocation.json')
if missing:
    print(json.dumps({'complete': False, 'waiting_for': missing}, indent=2))
    raise SystemExit(2)

check(invocation['source_commit'] == FROZEN and invocation['source_tree'] == TREE,
      'Outer invocation source differs from freeze')
check(invocation.get('sequential') is True, 'Outer invocation is not sequential')
expected_phases = [
    ('regression', ['python', 'runtime/word_office_gate.py', 'run', '--out', 'runtime/word-office-final'], STAGES['regression']),
    ('analysis-format', ['python', 'runtime/run_word_list_levels_checks.py', 'run', '--out', 'runtime/list-level-final-checks'], STAGES['checks']),
    ('portable', ['python', 'runtime/run_word_list_levels_portable.py', '--out', 'runtime/list-level-portable-final'], STAGES['portable']),
]
phases = invocation.get('phases', [])
check(len(phases) == 3, 'Outer invocation does not contain all three phases')
last_finish = None
outer_files = {'final-gates-invocation.json': identity(invocation_path)}
for phase, (name, arguments, directory) in zip(phases, expected_phases):
    check(phase['name'] == name and phase['argv'] == arguments, 'Unexpected outer phase command/order: ' + name)
    check(phase.get('exit_code') == 0 and phase.get('accepted') is True and phase.get('summary_accepted') is True,
          'Outer phase did not complete with explicit success: ' + name)
    check(phase.get('head_unchanged') is True, 'Outer phase HEAD moved: ' + name)
    check(phase['summary'] == str((directory / 'summary.json').relative_to(ROOT)), 'Outer phase summary path mismatch: ' + name)
    started = datetime.datetime.fromisoformat(phase['started_utc'])
    finished = datetime.datetime.fromisoformat(phase['finished_utc'])
    check(started <= finished and (last_finish is None or last_finish <= started), 'Outer phase timing is not sequential: ' + name)
    last_finish = finished
    for stream in ['stdout', 'stderr']:
        path = RUNTIME / phase[stream]
        outer_files[phase[stream]] = identity(path)
        if stream == 'stderr':
            check(path.read_bytes() == b'', 'Outer phase stderr is nonempty: ' + name)

expected_tree = tree_entries(FROZEN, DIRS + CONFIGS)
check(git('rev-parse', FROZEN + '^{tree}').decode().strip() == TREE,
      'Frozen commit does not have the declared tree')
worktree_names = {name for name in CONFIGS if (REPO / name).is_file()}
for directory in DIRS:
    worktree_names.update(str(p.relative_to(REPO)) for p in (REPO / directory).rglob('*') if p.is_file())
check(worktree_names == set(expected_tree), 'Current complete source input path set differs from frozen Git tree')
current_entries = {}
for name in sorted(worktree_names):
    path = REPO / name
    check(not path.is_symlink(), 'Source input symlink: ' + name)
    data = path.read_bytes()
    mode = '100755' if path.stat().st_mode & 0o111 else '100644'
    blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
    current_entries[name] = {
        'bytes': len(data), 'sha256': digest(data),
        'worktree_mode': mode, 'worktree_blob': blob,
        'head': expected_tree.get(name),
    }
    check(expected_tree.get(name) == {'mode': mode, 'type': 'blob', 'blob': blob},
          'Current source input mode/type/blob differs from frozen tree: ' + name)

input_reviews = {}
all_runtime = {}
stage_data = {}
for stage, directory in STAGES.items():
    before = read(directory / 'inputs-before.json.gz')
    after = read(directory / 'inputs-after.json.gz')
    summary = read(directory / 'summary.json')
    stage_data[stage] = (before, after, summary)
    for label, manifest in [('before', before), ('after', after)]:
        check(manifest['source_commit'] == FROZEN, f'{stage} {label} source commit differs from freeze')
        check(manifest['source_tree'] == TREE, f'{stage} {label} source tree differs from freeze')
        check(manifest['head_matches_worktree'] is True, f'{stage} {label} did not match HEAD')
        check(manifest['selection'] == {'directories': DIRS, 'configuration_files': CONFIGS},
              f'{stage} {label} changed source selection')
        check(manifest['entries'] == current_entries, f'{stage} {label} complete source identities differ')
    check(before['runtime_inputs'] == after['runtime_inputs'], f'{stage} runtime path set/content changed')
    for name, expected in before['runtime_inputs'].items():
        path = pathlib.Path(name)
        check(path.is_file() and identity(path) == expected, f'{stage} runtime differs now: {name}')
        if name in all_runtime:
            check(all_runtime[name] == expected, 'Runtime input changed between stages: ' + name)
        all_runtime[name] = expected
    input_reviews[stage] = {
        'source_input_count': len(before['entries']),
        'runtime_input_count': len(before['runtime_inputs']),
        'complete_path_mode_blob_sha256_sets_equal': before['entries'] == after['entries'] == current_entries,
        'runtime_sets_equal': before['runtime_inputs'] == after['runtime_inputs'],
        'before_after_match_frozen_commit_and_tree': before['source_commit'] == after['source_commit'] == FROZEN and before['source_tree'] == after['source_tree'] == TREE,
    }

# Rebuild the regression registry and every completed case from reporter events.
gate_dir = STAGES['regression']
plan = read(gate_dir / 'plan.json')
summary = stage_data['regression'][2]
prior_path = REPO / 'docs/validation/word-vba-lists-20261120/regression.json'
prior = read(prior_path)
test_dir = REPO / 'packages/quds_office_engine/test'
risk_files = {
    'word_list_numbering_snapshot_test.dart', 'numbering_collision_test.dart',
    'word_style_introduction_test.dart', 'xml_namespace_capture_test.dart',
    'odt_paragraph_properties_test.dart',
}
expected_files = set(prior['per_file_cases']) | risk_files
expected_files.update(p.name for p in test_dir.glob('office_vba_*_test.dart'))
expected_files.update(p.name for p in test_dir.glob('office_macro_word_*_test.dart'))
names = plan['files']
check(names == sorted(expected_files) and len(names) == 70, 'Gate selection is not the exact reviewed70-module union')
check(plan['file_count'] == len(names), 'Gate plan file count mismatch')
harness = gate_dir / 'word_office_gate_test.dart'
expected_harness = "\n".join([
    "import 'package:test/test.dart';", '',
    *[f"import '{(test_dir / name).as_uri()}' as suite{i};" for i, name in enumerate(names)],
    '', 'void main() {',
    *[f"  group('{name}', suite{i}.main);" for i, name in enumerate(names)],
    '}', '',
])
check(harness.read_text() == expected_harness, 'Harness did not register each original test module exactly once')
check(plan['harness_sha256'] == digest(harness.read_bytes()), 'Harness plan hash mismatch')
module_records = {x['file']: x for x in plan['reviewed_modules']}
check(set(module_records) == set(names), 'Reviewed-module manifest differs from selected files')
for name in names:
    source = (test_dir / name).read_text()
    check(module_records[name]['sha256'] == digest((test_dir / name).read_bytes()), 'Module preparation hash differs: ' + name)
    check(re.search(r'^void main\(\)\s*\{', source, re.M) is not None, 'Unexpected module main: ' + name)
    check(re.search(r'^\s*@(TestOn|Timeout|Tags|Skip|OnPlatform)\b', source, re.M) is None, 'Library metadata requires review: ' + name)
check(not (REPO / 'dart_test.yaml').exists() and not (test_dir.parent / 'dart_test.yaml').exists(), 'External test configuration requires review')
events = [json.loads(line) for line in (gate_dir / 'stdout.jsonl').read_text().splitlines() if line.strip()]
starts, finishes, groups, suites = {}, {}, {}, {}
finish_order = []
for event in events:
    kind = event['type']
    if kind == 'testStart':
        item = event['test']; key = item['id']; destination = starts
    elif kind == 'testDone':
        item = event; key = item['testID']; destination = finishes
        finish_order.append(key)
    elif kind == 'group':
        item = event['group']; key = item['id']; destination = groups
    elif kind == 'suite':
        item = event['suite']; key = item['id']; destination = suites
    else:
        continue
    check(key not in destination, f'Duplicate {kind} ID {key}')
    destination[key] = item
check(set(starts) == set(finishes), 'Raw test-start and completion ID sets differ')
check(len(suites) == 1 and all(x['platform'] == 'vm' and x['path'] == str(harness) for x in suites.values()), 'Expected one VM harness suite')
check(sum(x['type'] == 'done' for x in events) == 1 and events[-1]['type'] == 'done' and events[-1]['success'] is True,
      'Expected one successful final reporter done event')
errors = [x for x in events if x['type'] == 'error']
check(not errors, 'Raw reporter contains errors')
per_file = {name: 0 for name in names}
declared = {}
for group in groups.values():
    check(group['suiteID'] in suites, 'Group has unknown suite')
    check(group['parentID'] is None or group['parentID'] in groups, 'Group has unknown parent')
    if group['name'] in per_file:
        check(group['name'] not in declared, 'Duplicate filename group ' + group['name'])
        declared[group['name']] = group['testCount']
occurrences = collections.Counter()
cases = []
failed = skipped = hidden = 0
for key in finish_order:
    finish, start = finishes[key], starts[key]
    failed += finish['result'] != 'success'
    skipped += bool(finish.get('skipped') or start.get('metadata', {}).get('skip'))
    check(start['suiteID'] in suites, f'Test {key} has unknown suite')
    if finish.get('hidden'):
        hidden += 1
        continue
    check(all(group_id in groups for group_id in start['groupIDs']), f'Test {key} has unknown group')
    owners = [groups[x]['name'] for x in start['groupIDs'] if groups[x]['name'] in per_file]
    check(len(owners) == 1, f'Test {key} has no unique module owner')
    owner = owners[0]
    check(start['name'].startswith(owner + ' '), f'Test {key} lacks filename prefix')
    original = start['name'][len(owner) + 1:]
    occurrences[owner, original] += 1
    per_file[owner] += 1
    cases.append({'file': owner, 'name': original, 'occurrence': occurrences[owner, original],
                  'test_id': key, 'result': finish['result'], 'skipped': finish.get('skipped', False)})
check(not failed and not skipped, 'Raw events contain failed or skipped tests')
check(declared == per_file and all(per_file.values()), 'Declared/completed module counts differ')
roots = [x for x in groups.values() if x['parentID'] is None]
check(len(roots) == 1 and roots[0]['testCount'] == len(cases), 'Root declared count differs from completed case identities')
check(read(gate_dir / 'cases.json.gz') == cases, 'Saved case manifest differs from independently rebuilt raw events')
check(summary['passing_cases'] == len(cases) and summary['failed_cases'] == failed and summary['skipped_cases'] == skipped and summary['hidden_completions'] == hidden,
      'Gate summary totals differ from raw reporter')
check(summary['per_file_cases'] == per_file and summary['declared_per_file_cases'] == declared,
      'Gate per-file summary differs from raw reporter')
check(summary['exit_code'] == 0 and summary['accepted'] and summary['complete'] and not summary['problems'], 'Gate command did not report complete success')
check((gate_dir / 'stderr.log').read_bytes() == b'', 'Gate stderr is not empty')
command = read(gate_dir / 'command.json')
check(command['argv'] == [str(RUNTIME / 'run-engine-tests.sh'), '--reporter=json', str(harness)], 'Unexpected gate runner command')
check(command['cwd'] == str(test_dir.parent), 'Gate command cwd differs from original engine cwd')
check(command['runner_sha256'] == identity(RUNTIME / 'run-engine-tests.sh')['sha256'], 'Gate runner command hash mismatch')
check(command['collector_sha256'] == identity(RUNTIME / 'word_office_gate.py')['sha256'], 'Gate collector command hash mismatch')
for name, expected in summary['hashes'].items():
    check(digest((gate_dir / name).read_bytes()) == expected, 'Gate archived hash mismatch: ' + name)

# Compare previous raw identities for every unchanged source module.
archive_path = REPO / 'docs/validation/word-vba-lists-20261120/regression-evidence.tar.xz'
with tarfile.open(archive_path) as archive:
    members = [m for m in archive.getmembers() if m.name.endswith('/word-office-gate-final-v3/cases.json.gz')]
    check(len(members) == 1, 'Previous raw case evidence is ambiguous')
    old_cases = json.loads(gzip.decompress(archive.extractfile(members[0]).read()))
prior_tree = tree_entries(prior['source_commit'], ['packages/quds_office_engine/test'])
def case_set(values, name):
    return collections.Counter((x['name'], x['occurrence']) for x in values if x['file'] == name)
unchanged = {}
changed_previous = {}
for name, previous_count in prior['per_file_cases'].items():
    path = 'packages/quds_office_engine/test/' + name
    same = prior_tree[path] == expected_tree[path]
    old_ids, new_ids = case_set(old_cases, name), case_set(cases, name)
    if same:
        check(old_ids == new_ids and previous_count == per_file[name], 'Unchanged module lost/changed identities: ' + name)
        unchanged[name] = {'cases': per_file[name], 'exact_case_identities_retained': old_ids == new_ids}
    else:
        changed_previous[name] = {'previous_cases': previous_count, 'current_cases': per_file[name],
                                  'removed_identities': list((old_ids - new_ids).elements()),
                                  'added_identities': list((new_ids - old_ids).elements())}
new_files = {name: count for name, count in per_file.items() if name not in prior['per_file_cases']}
regression_review = {
    'passing_cases': len(cases), 'failed_cases': failed, 'skipped_cases': skipped,
    'file_count': len(names), 'hidden_completions': hidden,
    'test_start_count': len(starts), 'test_done_count': len(finishes),
    'matching_start_done_ids': set(starts) == set(finishes), 'raw_error_events': len(errors),
    'per_file_cases': per_file, 'exact_raw_case_manifest_reconstructed': True,
    'unchanged_previous_modules': unchanged,
    'unchanged_previous_module_count': len(unchanged),
    'unchanged_previous_cases': sum(x['cases'] for x in unchanged.values()),
    'changed_previous_modules': changed_previous, 'newly_selected_modules': new_files,
    'source_isolation': 'Original modules remain separate Dart libraries within one serial VM suite. Separate-file isolate boundaries are not claimed.',
    'supplemental_or_development_runs_counted': False,
}

# Analysis and formatting: inspect exact commands and raw output.
check_dir = STAGES['checks']
check_plan = read(check_dir / 'plan.json')
check_summary = stage_data['checks'][2]
dart_changes = sorted(name for name in git('diff', '--name-only', BASELINE, FROZEN, '--', 'packages/quds_office_engine').decode().splitlines() if name.endswith('.dart'))
check(check_plan['files'] == dart_changes and len(dart_changes) == 9, 'Format file selection is not all9 changed engine Dart files')
check(check_plan['baseline'] == BASELINE, 'Unexpected formatting baseline')
analysis = read(check_dir / 'analysis.json')
formatting = read(check_dir / 'format.json')
check(analysis['argv'] == [str(RUNTIME / 'dart-sdk/bin/dart'), 'analyze', '--fatal-infos', 'packages/quds_office_engine'], 'Unexpected analyzer command')
check(formatting['argv'] == [str(RUNTIME / 'dart-sdk/bin/dart'), 'format', '--output=none', '--set-exit-if-changed', *dart_changes], 'Unexpected formatting command')
for name, receipt in [('analysis', analysis), ('format', formatting)]:
    check(receipt['exit_code'] == 0 and receipt['cwd'] == str(REPO), name + ' did not exit0 in repository cwd')
    check(receipt['source_commit'] == FROZEN and receipt['source_tree'] == TREE, name + ' receipt source mismatch')
    for stream in ['stdout', 'stderr']:
        check(receipt[stream] == identity(check_dir / f'{name}.{stream}'), name + ' stream hash mismatch')
    check((check_dir / f'{name}.stderr').read_bytes() == b'', name + ' stderr is nonempty')
analysis_text = (check_dir / 'analysis.stdout').read_text()
format_text = (check_dir / 'format.stdout').read_text()
check('No issues found!' in analysis_text, 'Analyzer did not report a clean result')
match = re.search(r'Formatted\s+(\d+)\s+files?\s+\((\d+)\s+changed\)', format_text)
check(match is not None and match.groups() == ('9', '0'), 'Format output is not9 files/0 changed')
check(check_summary['qualified'] and not check_summary['problems'], 'Analysis/format collector did not qualify')
for name, expected in check_summary['hashes'].items():
    check(identity(check_dir / name) == expected, 'Analysis/format archived identity mismatch: ' + name)
checks_review = {'analysis_exit_code': analysis['exit_code'], 'analysis_clean': 'No issues found!' in analysis_text,
                 'format_exit_code': formatting['exit_code'], 'formatted_files': dart_changes,
                 'formatted_file_count': len(dart_changes), 'format_changed_count': int(match.group(2)) if match else None}

# Exact BAS supplied to both VM and JavaScript compilation; raw and semantic equality.
portable_dir = STAGES['portable']
portable_summary = stage_data['portable'][2]
commands = read(portable_dir / 'commands.json')
check([x['name'] for x in commands] == ['vm', 'compile-js', 'node'], 'Portable pipeline is incomplete or reordered')
check(commands == portable_summary['commands'], 'Portable summary commands differ from raw receipts')
bas_path = REPO / 'packages/quds_office_engine/example/macros/word_list_levels.bas'
bas_bytes = bas_path.read_bytes()
check((portable_dir / 'actual-example.bas').read_bytes() == bas_bytes, 'Executed BAS snapshot differs from frozen/current example')
check(git('show', FROZEN + ':' + str(bas_path.relative_to(REPO))) == bas_bytes, 'BAS differs from frozen Git object')
driver = REPO / 'packages/quds_office_engine/tool/macros/web_vba_word_list_levels_smoke.dart'
expected_define = '-DWORD_LIST_LEVELS_BAS_BASE64=' + base64.b64encode(bas_bytes).decode()
for receipt in commands:
    name, argv = receipt['name'], receipt['argv']
    check(receipt['exit_code'] == 0, name + ' did not exit0')
    check(receipt['cwd'] == str(test_dir.parent), name + ' cwd differs from engine')
    check((portable_dir / f'{name}.stderr').read_bytes() == b'', name + ' stderr is nonempty')
    if name in ['vm', 'compile-js']:
        defines = [x for x in argv if x.startswith('-DWORD_LIST_LEVELS_BAS_BASE64=')]
        check(defines == [expected_define], name + ' BAS define differs from exact committed bytes')
        check(argv[-1] == str(driver), name + ' uses a different driver')
        check('--packages=' + str(REPO / '.dart_tool/package_config.json') in argv, name + ' package roots differ')
check(commands[0]['argv'] == [str(RUNTIME / 'dart-sdk/bin/dart'), '--packages=' + str(REPO / '.dart_tool/package_config.json'), expected_define, str(driver)], 'Unexpected portable VM command')
check(commands[1]['argv'] == [str(RUNTIME / 'dart-sdk/bin/dart'), 'compile', 'js', '-O1', '--packages=' + str(REPO / '.dart_tool/package_config.json'), expected_define, '-o', str(portable_dir / 'word-list-levels.js'), str(driver)], 'Unexpected JavaScript compile command')
check(commands[2]['argv'][1:] == ['-e', 'globalThis.self = globalThis; require(process.argv[1]);', str(portable_dir / 'word-list-levels.js')], 'Node did not execute the compiled artifact directly')
vm_bytes, js_bytes = (portable_dir / 'vm.stdout').read_bytes(), (portable_dir / 'node.stdout').read_bytes()
vm_result, js_result = json.loads(vm_bytes), json.loads(js_bytes)
canonical = (json.dumps(vm_result, sort_keys=True, separators=(',', ':')) + '\n').encode()
check(vm_bytes == js_bytes and vm_result == js_result, 'VM/JS raw or canonical results differ')
check((portable_dir / 'result.json').read_bytes() == canonical, 'Saved canonical result differs from independently canonicalized output')
check(portable_summary['bas_sha256'] == digest(bas_bytes), 'BAS summary hash mismatch')
check(portable_summary['driver_sha256'] == digest(driver.read_bytes()), 'Portable driver summary hash mismatch')
check(portable_summary['raw_output_bytes'] == len(vm_bytes) and portable_summary['raw_output_sha256'] == digest(vm_bytes) and portable_summary['canonical_sha256'] == digest(canonical), 'Portable result summary hash/size mismatch')
check(portable_summary['qualified'] is True, 'Portable collector did not qualify')
check(vm_result['example']['operations'] == 13 and vm_result['example']['revision'] == 1 and vm_result['example']['additionalReopens'] == 2 and vm_result['example']['opaqueVbaPreserved'] is True,
      'Example semantic result differs from the reviewed contract')
check(vm_result['exampleReplay'] == {'operationsPerRun': 13, 'revision': 2, 'sameSavedState': True}, 'Example replay result differs from contract')
check(vm_result['transitions']['absoluteLevels'] == 9 and vm_result['transitions']['relativeLevels'] == [7, 8] and vm_result['transitions']['revision'] == 14, 'Transition semantic result differs')
check(vm_result['nativeGuards'] == {'refusedPlans': 9, 'validateAndRunRollback': True}, 'Portable native refusal coverage differs')
check(vm_result['policies'] == {'refusedPolicies': 4, 'completeAllowlistRevision': 1}, 'Portable policy coverage differs')
check(vm_result['recording'] == {'recordedSteps': 2, 'failedCallExcluded': True, 'replayRevision': 1} and vm_result['refusedSources'] == 12, 'Portable recording/source-refusal results differ')
portable_review = {
    'subprocess_exit_codes': {x['name']: x['exit_code'] for x in commands},
    'actual_bas_sha256': digest(bas_bytes), 'actual_bas_bytes': len(bas_bytes),
    'both_command_payloads_match_exact_committed_bas': True,
    'driver_sha256': digest(driver.read_bytes()),
    'raw_outputs_equal': vm_bytes == js_bytes, 'raw_output_bytes': len(vm_bytes),
    'raw_output_sha256': digest(vm_bytes), 'canonical_results_equal': vm_result == js_result,
    'canonical_sha256': digest(canonical), 'compiled_js': identity(portable_dir / 'word-list-levels.js'),
    'semantic_result': vm_result,
}

# Bind every final evidence file and preserve the limits of this qualification.
source_review = read(OUT / 'source-review.json')
source_review_files = {}
for name, recorded in source_review['reviewed_files'].items():
    frozen_bytes = git('show', FROZEN + ':' + name)
    frozen_identity = {'bytes': len(frozen_bytes), 'sha256': digest(frozen_bytes)}
    current_identity = identity(REPO / name)
    check(frozen_identity == recorded, 'Source-review receipt differs from frozen source: ' + name)
    current_changed = current_identity != frozen_identity
    check(not current_changed or name.startswith('docs/'), 'Reviewed product/test/example changed after freeze: ' + name)
    source_review_files[name] = {
        'reviewed_identity': recorded, 'frozen_identity': frozen_identity,
        'current_identity': current_identity,
        'receipt_matches_frozen_source': frozen_identity == recorded,
        'later_docs_only_drift': current_changed and name.startswith('docs/'),
    }
check(len(source_review_files) == 11, 'Expected all11 independently source-reviewed files')
source_review_binding = {
    'receipt_head_label': source_review['head_at_receipt'],
    'receipt_sha256': identity(OUT / 'source-review.json')['sha256'],
    'frozen_commit': FROZEN,
    'all11_reviewed_file_hashes_match_frozen_source': all(x['receipt_matches_frozen_source'] for x in source_review_files.values()),
    'later_docs_only_drift': [name for name, item in source_review_files.items() if item['later_docs_only_drift']],
    'files': source_review_files,
    'binding_note': 'The earlier HEAD label records review timing; explicit file hashes, including uncommitted reviewed changes at that time, bind the accepted review to the frozen source. Later documentation wording is recorded separately and does not change the frozen runtime qualification.',
}
file_hashes = {
    stage: {str(p.relative_to(directory)): identity(p) for p in sorted(directory.rglob('*')) if p.is_file()}
    for stage, directory in STAGES.items()
}
review = {
    'schema': 'quds-word-list-level-independent-final-evidence-review/v1',
    'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'accepted': not problems, 'problems': problems,
    'frozen_source_commit': FROZEN, 'frozen_source_tree': TREE,
    'current_head_at_review': git('rev-parse', 'HEAD').decode().strip(),
    'method': 'Independent raw JSON reporter reconstruction, Git mode/type/blob and SHA256 comparison, exact command/BAS decoding and independent JSON canonicalization; no collector validation function reused.',
    'inputs': input_reviews, 'regression': regression_review,
    'outer_sequential_invocation': {'record': invocation, 'file_identities': outer_files},
    'source_review_binding': source_review_binding,
    'analysis_and_formatting': checks_review, 'portable': portable_review,
    'evidence_files': file_hashes,
    'audit_script': identity(pathlib.Path(__file__)),
    'audit_command': [sys.executable, str(pathlib.Path(__file__).resolve())],
    'audit_cwd': str(pathlib.Path.cwd()),
    'limits': [
        'Supplemental18 reviewer probes and all development/superseded runs are excluded from the main regression total.',
        'The gate uses one serial VM suite and separate Dart libraries, not separate test-file isolates.',
        'Runtime binding covers the explicitly recorded input sets; it does not claim a hash of every installed SDK/dependency file.',
        'This qualifies the selected Word/Office engine source; Mail, provider and Flutter runtimes keep separate validation scope.',
        'No Microsoft Word COM or embedded VBA execution is claimed. No GitHub Actions endpoints were queried or waited on.',
    ],
}
(OUT / 'evidence-review.json').write_text(json.dumps(review, indent=2, sort_keys=True) + '\n')
print(json.dumps({'accepted': review['accepted'], 'problems': problems,
                  'passing_cases': len(cases), 'file_count': len(names),
                  'source_inputs': len(current_entries), 'unchanged_previous_modules': len(unchanged),
                  'unchanged_previous_cases': regression_review['unchanged_previous_cases'],
                  'formatted_files': len(dart_changes), 'canonical_sha256': digest(canonical)}, indent=2))
raise SystemExit(0 if not problems else 1)
