import datetime
import hashlib
import json
import pathlib
import subprocess

workspace = pathlib.Path('/workspace/scratch/33048a5794d3')
repo = workspace / 'quds_office_suite'
evidence = workspace / 'runtime/list-level-review'
production = [
    'packages/quds_office_engine/lib/src/automation/office_vba_language.dart',
    'packages/quds_office_engine/lib/src/automation/operations/word_list_steps.dart',
    'packages/quds_office_engine/lib/src/automation/operations/word_steps.dart',
    'packages/quds_office_engine/lib/src/word/serial/word_style_cascade.dart',
]
reviewed = production + [
    'packages/quds_office_engine/test/office_vba_word_lists_test.dart',
    'packages/quds_office_engine/test/office_vba_word_list_levels_test.dart',
    'packages/quds_office_engine/test/office_macro_word_list_levels_test.dart',
    'packages/quds_office_engine/test/office_vba_word_list_levels_integration_test.dart',
    'packages/quds_office_engine/tool/macros/web_vba_word_list_levels_smoke.dart',
    'packages/quds_office_engine/example/macros/word_list_levels.bas',
    'docs/VBA_WORD_MACROS.md',
]
probe = json.loads((evidence / 'probe-final-receipt.json').read_text())
hashes = {
    name: {
        'sha256': hashlib.sha256((repo / name).read_bytes()).hexdigest(),
        'bytes': (repo / name).stat().st_size,
    }
    for name in reviewed
}
bound = all(
    probe['source_after'][str(repo / name)] == hashes[name]['sha256']
    for name in production
)
if not probe['accepted'] or not bound or probe['count'] != 18:
    raise SystemExit('Final review requires accepted probes bound to all production files')
review = {
    'schema': 'quds-word-list-level-independent-source-review/v1',
    'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': 'independent intake_audit agent; no product edits or Git ref mutations',
    'head_at_receipt': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'disposition': 'accepted within the documented bounded source-adapter and native operation contract',
    'reviewed_files': hashes,
    'production_bound_to_final_probe': bound,
    'probe_receipt': 'probe-final-receipt.json',
    'probe_receipt_sha256': hashlib.sha256((evidence / 'probe-final-receipt.json').read_bytes()).hexdigest(),
    'compiler_review': [
        'Only the selected Word paragraph ListFormat object admits the new setter and methods; static receiver/member checks retain source-language isolation.',
        'ListLevelNumber exact numeric 1..9 values lower to native 0..8; strings, Booleans, live reads, Set, indexed property forms, invalid shapes, and unsupported optional behaviors remain refused.',
        'Assignment intentionally retains existing scalar RHS-then-selector order exactly once, while methods evaluate the receiver first; explicit regression tests and documentation disclose this adapter contract without claiming COM conformance.',
        'Aliases, ByVal selector passing, nested With, step/execution budgets, method arity and named argument checks reuse existing adapter mechanisms.',
    ],
    'native_review': [
        'New operations validate detached state before publishing. Level changes preserve list identity and original native definitions, and resolve actual supported target indentation.',
        'Missing lists/levels, boundaries, pending restart, duplicate/partial definitions, unsupported formats/linked or legacy semantics, forward/repeated counter references and invalid ancestor starts refuse atomically.',
        'Outline identity uses explicit metadata and validated numeric levels; generated default reuse checks the entire scheme and IDs are allocated against existing references.',
        'Foreign source metadata, right indentation ownership/inheritance and imported definition identity are tested across save/reopen; whole numbering-part byte identity is not promised for arbitrary raw input.',
        'Inherited logical/character geometry and positive firstLine with hanging precedence are guarded; derived labels are recomputed on ordinary reopen.',
        'Existing unbalanced-field and opaque-package preservation guards are retained rather than broad serializer behavior being changed by these new operations.',
    ],
    'resolved_findings': [
        {
            'finding': 'A hanging attribute, including zero, can suppress a positive firstLine in Word; inherited character/logical/hanging geometry can outrank new physical values.',
            'resolution': 'Positive firstLine writes omit hanging entirely; conflicting target/inherited hanging and inherited logical/character attributes are refused before publication. Independent probes cover successful and refused paths.',
        },
        {
            'finding': 'Ancestor placeholders require valid referenced ancestor start overrides, not only selected-level checks.',
            'resolution': 'checkedLevel validates ancestor starts recursively with strictly decreasing level references; duplicate/nonpositive starts refuse and positive preserved starts pass.',
        },
        {
            'finding': 'Ordinary serialization can normalize XML and add absent legacy numbering defaults, so raw complete-part byte equality overstates preservation.',
            'resolution': 'Documentation distinguishes unchanged original definitions from serializer normalization; raw-import tests compare complete original definition and instance nodes while normalized fixtures can compare full-part bytes.',
        },
        {
            'finding': 'Generic serialization materializes inherited right indentation when list projection changes the aggregate indentation snapshot.',
            'resolution': 'New geometry paths retain original right-family direct ownership when imported right is unchanged; explicit prior writes remain direct. Independent probes follow with later style edits and repeated reopen.',
        },
        {
            'finding': 'Detached effective indentation can lose a native prefix binding and cause generic property serialization to replace foreign indentation metadata.',
            'resolution': 'A new native-ind projection normalizes native attribute names only in detached effective geometry, alongside the unchanged numPr namespace-context projection. Raw direct/style XML remains intact and foreign ind lookalikes stay opaque. The final new-operation source, plain import, inherited style and rebound-prefix preservation probes were reviewed together; raw metadata and effective right/left/hanging values survive the operation and two additional save/reopen cycles.',
        },
        {
            'finding': 'The third paragraph in the example applied a toggle without explicit removal and failed on its own prior output.',
            'resolution': 'The example now explicitly removes paragraph numbering on all three selected paragraphs, with replay validation.',
        },
    ],
    'verification_scope': {
        'independent_probe_count': probe['count'],
        'independent_probe_passed': probe['passed'],
        'inputs_unchanged_during_probes': probe['inputs_unchanged'],
        'native_and_compiler_suites': 'Source coverage reviewed; owner/root execution receipts provide authoritative suite counts.',
        'portable': 'Portable runner and integration assertions reviewed, including exact BAS, dry run, atomic publication/rollback, DOCM/VBA opaque preservation, native IDs/definitions and replay; root/owner VM-JS receipts qualify execution.',
        'no_github_actions_queries_or_waits': True,
        'no_word_com_execution_claim': True,
        'not_a_whole_repository_or_flutter_runtime_qualification': True,
    },
    'primary_contract_references': [
        'https://learn.microsoft.com/en-us/office/vba/api/word.listformat.applyoutlinenumberdefault',
        'https://learn.microsoft.com/en-us/office/vba/api/word.listformat.listlevelnumber',
        'https://learn.microsoft.com/en-us/office/vba/api/word.listformat.listindent',
        'https://learn.microsoft.com/en-us/office/vba/api/word.listformat.listoutdent',
        'https://learn.microsoft.com/en-us/openspecs/wordpad_standards_support/ms-wpe376/0c89d796-e1c8-447c-8f53-73cffb3117ed',
        'https://learn.microsoft.com/en-us/openspecs/office_standards/ms-oi29500/138732dc-507a-4164-af66-808c2fd9f2f9',
    ],
}
(evidence / 'source-review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'files_reviewed': len(reviewed), 'production_bound': bound, 'independent_probes': probe['count'], 'disposition': review['disposition']}, indent=2))
