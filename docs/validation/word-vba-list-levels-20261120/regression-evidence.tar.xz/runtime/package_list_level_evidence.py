#!/usr/bin/env python3
"""Package the completed Word list-level qualification without running checks.

Inspect safely while checks are running:
  python runtime/package_list_level_evidence.py --inspect
Package only after the final audit and final intake exist:
  python runtime/package_list_level_evidence.py --out /path/to/evidence
After adding the publication reports, refresh the complete delivered-file index:
  python runtime/package_list_level_evidence.py --manifest-only --out /path/to/evidence
Verify an existing packet without reading the original runtime:
  python runtime/package_list_level_evidence.py --verify --out /path/to/evidence

The four archives use explicit allowlists, never a recursive runtime/cache grab.
Archive members retain workspace-relative runtime/... and quds_office_suite/...
paths. README.md, qualification.json and publication reports are never replaced.
"""
from __future__ import annotations

import argparse
import collections
from dataclasses import dataclass
from functools import lru_cache
import gzip
import hashlib
import io
import json
import lzma
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import tempfile


ARCHIVES = {
    "regression": "regression-evidence.tar.xz",
    "portable": "portable-evidence.tar.xz",
    "development": "development-evidence.tar.xz",
    "reconciliation": "reconciliation-evidence.tar.xz",
}
MAX_MEMBER_BYTES = 32 * 1024 * 1024
MAX_TOTAL_BYTES = 256 * 1024 * 1024
FINAL_DIRS = {
    "regression": "word-office-final",
    "checks": "list-level-final-checks",
    "portable": "list-level-portable-final",
}
# This is one reviewed publication decision, not a configurable bypass. A
# changed Mail head or ref set must acquire a new review and a code review of
# this explicit binding before an uncovered final inventory can be packaged.
DEFERRED_MAIL_HEAD = "0730e7f61293b8e2dbe1f25150bc8754a563b101"
DEFERRED_MAIL_REFS = (
    "refs/remotes/origin/work/mail-cached-workspace-20261120",
    "refs/remotes/pull/262",
)
SCOPED_PUBLICATION_TARGET = "273d78f54d2d4448c25791060eb41ae65e3d3674"
SCOPE_REVIEW_MEMBER = "runtime/list-level-review/publication-scope-review.json"
CURRENT_MAIL_REVIEW_MEMBER = "runtime/list-level-review/incoming-mail-0730e7-review.json"
HISTORICAL_MAIL_REVIEWS = {
    "runtime/list-level-review/incoming-mail-2d3799-review.json": "2d3799af2d9b32e115fee4ba2f8326795fc6b29f",
    "runtime/list-level-review/incoming-mail-47d3fc-review.json": "47d3fc0d140724d64632049f398d988d540965ab",
}
REGRESSION_FILES = (
    "command.json", "plan.json", "word_office_gate_test.dart",
    "word_office_gate_test.bootstrap.isolate.dart", "stdout.jsonl", "stderr.log",
    "inputs-before.json.gz", "inputs-after.json.gz", "cases.json.gz", "summary.json",
)
CHECK_FILES = (
    "plan.json", "runner.py", "gate-helper.py", "inputs-before.json.gz",
    "inputs-after.json.gz", "analysis.stdout", "analysis.stderr", "analysis.json",
    "format.stdout", "format.stderr", "format.json", "summary.json",
)
PORTABLE_FILES = (
    "actual-example.bas", "commands.json", "runner.py", "gate-helper.py",
    "inputs-before.json.gz", "inputs-after.json.gz", "vm.stdout", "vm.stderr",
    "compile-js.stdout", "compile-js.stderr", "node.stdout", "node.stderr",
    "word-list-levels.js", "word-list-levels.js.deps", "word-list-levels.js.map",
    "result.json", "summary.json",
)
RUNTIME_FILES = (
    "environment.json", "list-level-runtime-verification.json", "reproduce_runtime.py",
    "final-gates-small-summary.json",
    "env.sh", "run-engine-tests.sh", "reproduction-command.json", "setup-receipt.json",
    "runtime-setup.stdout", "runtime-setup.stderr", "setup-smoke.jsonl",
    "setup-smoke.stderr", "setup-smoke-summary.json", "word_office_gate.py",
    "run_word_list_levels_checks.py", "package_list_level_evidence.py",
    "engine-validation/packages/quds_office_engine/pubspec.yaml",
    "engine-validation/packages/quds_office_engine/pubspec.lock",
    "engine-validation/packages/quds_office_engine/.dart_tool/package_config.json",
    "engine-validation/packages/quds_office_engine/.dart_tool/package_graph.json",
    "engine-validation/packages/legacy_doc_parser/pubspec.yaml",
)
REVIEW_FILES = (
    "probe.dart", "run_probe.py", "write_review.py", "audit_final_evidence.py",
    "source-review.json", "evidence-review.json", "probe-final-receipt.json",
    "probe-final.json", "probe-final.stderr",
)
OLD_REVIEW_FILES = (
    "probe-initial.json", "probe-initial.stderr", "probe-definitions.json",
    "probe-definitions.stderr", "probe-nine-accepted-receipt.json",
    "probe-nine-accepted.json", "probe-nine-accepted.stderr",
)
RECONCILIATION_FILES = (
    "remote_checkpoint_api.js", "publication-upload-retry.json",
    "pre-gate-intake.json", "checkpoint-receipts.json", "remote_checkpoint.py",
    "verify_list_level_publication.py", "refresh_list_level_intake.py", "intake-audit/audit_intake.py",
    "intake-audit/initial-reconciled.json", "intake-refresh.stdout",
    "intake-refresh.stderr", "intake-refresh-2.stdout", "intake-refresh-2.stderr",
    "intake-pre-gate.stdout", "intake-pre-gate.stderr",
    "intake-late-gate.json", "intake-late-gate.stdout", "intake-late-gate.stderr",
    "late-gate-intake.json", "intake-final-refresh.json", "intake-final-refresh.stdout",
    "intake-final-refresh.stderr",
    "intake-pre-publication.json", "intake-pre-publication.stdout",
    "intake-pre-publication.stderr", "pre-publication-intake.json",
    "mail-corrections-fetch.json", "mail-corrections-fetch.stdout",
    "mail-corrections-fetch.stderr",
)
DEVELOPMENT_FILES = (
    "list-level-evidence-plan.json", "list-level-development-command-correction.json",
    "list-level-qualification-readme.template.md", "list-level-pr-body.template.md",
    "compiler-levels-analysis.stdout", "compiler-levels-analysis.stderr",
    "compiler-levels-development.jsonl", "compiler-levels-development.stderr",
    "compiler-levels-development-v2.jsonl", "compiler-levels-development-v2.stderr",
    "native-list-levels-development.jsonl", "native-list-levels-development.stderr",
    "native-list-levels-namespace-probe.jsonl", "native-list-levels-namespace-probe.stderr",
    *tuple(f"native-list-levels-development-v{v}.{suffix}"
           for v in (2, 3, 4) for suffix in ("jsonl", "stderr")),
    *tuple(f"list-level-integration-analysis{version}.{suffix}"
           for version in ("", "-v2", "-v3") for suffix in ("stdout", "stderr")),
    *tuple(f"list-level-integration-development-v{v}.{suffix}"
           for v in (1, 2, 3, 4) for suffix in ("jsonl", "stderr", "summary.json")),
    *tuple(f"list-level-portable-development-v{v}.log" for v in (1, 2, 3, 4)),
)
DEVELOPMENT_PORTABLE_FILES = {
    1: ("commands.json", "gate-helper.py", "inputs-before.json.gz", "inputs-after.json.gz",
        "runner.py", "summary.json", "vm.stdout", "vm.stderr"),
    2: ("actual-example.bas", "commands.json", "gate-helper.py", "inputs-before.json.gz",
        "inputs-after.json.gz", "runner.py", "summary.json", "vm.stdout", "vm.stderr"),
    3: ("actual-example.bas", "collector-failure.json", "commands.json", "compile-js.stdout",
        "compile-js.stderr", "gate-helper.py", "inputs-before.json.gz", "inputs-after.json.gz",
        "node.stdout", "node.stderr", "runner.py", "vm.stdout", "vm.stderr",
        "word-list-levels.js", "word-list-levels.js.deps", "word-list-levels.js.map"),
    4: PORTABLE_FILES,
}
PREPARED_DIRS = {
    "prepared-word-office-gate": ("plan.json", "word_office_gate_test.dart"),
    "list-level-regression-prepared-70": ("plan.json", "word_office_gate_test.dart"),
    "list-level-final-checks-prepared": ("plan.json",),
    "list-level-final-checks-prepared-v2": ("plan.json",),
    "list-level-final-checks-prepared-nine": ("plan.json",),
}
EXCLUDED = (
    "Dart SDK installation and downloaded archive",
    "Hosted dependency cache, generic caches, configuration directories and temporary fixtures",
    "Compiled test-runner kernel binary (its identity and exact build argv are preserved)",
    "Git metadata, authentication configuration, credentials and unrelated workspace files",
)
QUALIFICATION_LIMITS = (
    "Qualified totals come only from word-office-final, list-level-final-checks and list-level-portable-final.",
    "Development, setup-smoke and supplemental reviewer probes are separate and add no cases to the final regression total.",
    "The regression gate executes the original modules as separate Dart libraries in one serial VM suite; separate test-file isolates are not claimed.",
    "The accidental quds_dummy selector discarded stdout to /dev/null. Its correction receipt is retained; the missing stdout is not claimed as preserved and no product acceptance depends on it.",
    "This packet does not qualify Microsoft Word COM, embedded VBA execution, Mail/provider/Flutter runtimes or GitHub Actions.",
    "Runtime hashes cover the explicitly recorded input sets, not every installed SDK or dependency file.",
)
REPRODUCTION = (
    "Retrieve the repository at the source commit recorded in the final manifests; the archives do not duplicate the full source checkout.",
    "Use a fresh checkout and a fresh runtime directory with reproduce_runtime.py, --repo, --runtime and --record pointing to the archived environment.json.",
    "Runtime setup downloads the recorded Dart SDK archive, verifies its SHA-256, resolves the recorded exact hosted pins and rebuilds the test-runner kernel. SDK/cache/kernel binaries are deliberately absent.",
    "Use the recorded Node version for the portable JavaScript run. Node provisioning is not performed by reproduce_runtime.py.",
    "Keep a sibling runtime and quds_office_suite layout for the archived gate helpers, or deliberately adapt their root constants. Historical commands and package-config snapshots retain the original absolute paths.",
    "Regenerate package configuration and runner paths using the runtime reproduction helper in a relocated checkout; do not mistake the archived absolute-path snapshots for portable configuration.",
    "Run word_office_gate.py run, run_word_list_levels_checks.py run and run_word_list_levels_portable.py --out with new output directories. Existing evidence directories are immutable inputs and should not be reused as run destinations.",
    "The final independent audit script records this session's original absolute workspace, frozen commit and tree; adapting its workspace root is necessary for a relocated reproduction.",
    "Normalized tar metadata (mtime/uid/gid zero, empty owner names, regular files sorted by path), explicit modes and fixed XZ settings make packaging the same selected bytes reproducible.",
)
SECRET_PATTERNS = (
    re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    re.compile(rb"\bgh[pousr]_[A-Za-z0-9]{30,}\b"),
    re.compile(rb"\bgithub_pat_[A-Za-z0-9_]{40,}\b"),
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def identity(data: bytes) -> dict:
    return {"bytes": len(data), "sha256": digest(data)}


def json_bytes(value) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def read_stable(path: Path) -> tuple[bytes, int]:
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or path.resolve() != path.absolute():
        raise ValueError(f"Only regular files with no symlink parents are allowed: {path}")
    if before.st_size > MAX_MEMBER_BYTES:
        raise ValueError(f"Selected file exceeds the explicit size cap: {path}")
    data = path.read_bytes()
    after = path.lstat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_mode) != (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_mode):
        raise ValueError(f"Selected input changed while reading: {path}")
    if len(data) != before.st_size:
        raise ValueError(f"Selected input size changed while reading: {path}")
    return data, 0o755 if before.st_mode & 0o111 else 0o644


def scan_credentials(name: str, data: bytes) -> None:
    if name.endswith(".json.gz"):
        with gzip.GzipFile(fileobj=io.BytesIO(data)) as source:
            data = source.read(MAX_MEMBER_BYTES + 1)
        if len(data) > MAX_MEMBER_BYTES:
            raise ValueError(f"Decompressed manifest exceeds the explicit size cap: {name}")
    if any(pattern.search(data) for pattern in SECRET_PATTERNS):
        raise ValueError(f"Credential-shaped content requires review; contents are not printed: {name}")


@dataclass(frozen=True)
class Member:
    group: str
    name: str
    path: Path


class Selection:
    def __init__(self, runtime: Path, repo: Path, final_intake: Path):
        self.runtime, self.repo = runtime, repo
        self.final_intake = final_intake
        self.members: dict[str, Member] = {}
        self.required: set[str] = set()
        self.directory_allowlists: dict[str, set[str]] = {}
        self.problems: list[str] = []
        self.invocation: dict = {}
        self.copies: dict[str, str] = {}
        self._select()

    def add(self, group: str, relative: str, *, root: str = "runtime", required: bool = True):
        base = self.runtime if root == "runtime" else self.repo
        path = base / relative
        name = f"{root}/{relative}"
        if name in self.members:
            raise ValueError(f"Duplicate selected member: {name}")
        self.members[name] = Member(group, name, path)
        if required:
            self.required.add(name)
        return name

    def directory(self, group: str, directory: str, names: tuple[str, ...]):
        self.directory_allowlists.setdefault(directory, set()).update(names)
        for name in names:
            self.add(group, f"{directory}/{name}")

    def _select(self):
        self.directory("regression", FINAL_DIRS["regression"], REGRESSION_FILES)
        self.directory("regression", FINAL_DIRS["checks"], CHECK_FILES)
        self.directory("portable", FINAL_DIRS["portable"], PORTABLE_FILES)
        for name in RUNTIME_FILES:
            self.add("regression", name)
        for name in (".dart_tool/package_config.json", ".dart_tool/package_graph.json",
                     "docs/validation/word-vba-lists-20261120/environment.json",
                     "docs/validation/word-vba-lists-20261120/regression.json"):
            self.add("regression", name, root="quds_office_suite")
        self.directory("regression", "list-level-review", REVIEW_FILES)
        self.directory("development", "list-level-review", OLD_REVIEW_FILES)
        self.directory("reconciliation", "list-level-review", (
            "late-mail-docs-review.json", "incoming-mail-2d3799-review.json",
            "incoming-mail-47d3fc-review.json", "incoming-mail-0730e7-review.json",
            "review_publication_scope.py", "publication-scope-review.json",
        ))
        self.add("portable", "run_word_list_levels_portable.py")
        for name in ("packages/quds_office_engine/example/macros/word_list_levels.bas",
                     "packages/quds_office_engine/tool/macros/web_vba_word_list_levels_smoke.dart"):
            self.add("portable", name, root="quds_office_suite")
        for name in DEVELOPMENT_FILES:
            self.add("development", name)
        for version, files in DEVELOPMENT_PORTABLE_FILES.items():
            self.directory("development", f"list-level-portable-development-v{version}", files)
        for directory, files in PREPARED_DIRS.items():
            self.directory("development", directory, files)
        for name in RECONCILIATION_FILES:
            self.add("reconciliation", name)
        self.directory_allowlists["intake-audit"] = {"audit_intake.py", "initial-reconciled.json"}
        for name in ("final-intake.stdout", "final-intake.stderr", "intake-final.stdout", "intake-final.stderr"):
            self.add("reconciliation", name, required=False)
        relative = self.final_intake.relative_to(self.runtime).as_posix()
        final_intake_member = self.add("reconciliation", relative)
        self.add("reconciliation", "docs/validation/word-vba-lists-20261120/final-intake.json",
                 root="quds_office_suite")
        self.add("regression", "final-gates-invocation.json")
        if (self.runtime / "final-gates-invocation.json").is_file():
            self.invocation = json.loads((self.runtime / "final-gates-invocation.json").read_bytes())
            for phase in self.invocation.get("phases", []):
                for field in ("stdout", "stderr"):
                    name = phase.get(field, "")
                    if not re.fullmatch(r"final-[a-z0-9-]+\.(stdout|stderr)", name):
                        self.problems.append(f"Unexpected outer phase {field} filename")
                    elif f"runtime/{name}" not in self.members:
                        self.add("regression", name)
        self.copies = {
            "regression.json": "runtime/word-office-final/summary.json",
            "analysis-format.json": "runtime/list-level-final-checks/summary.json",
            "portable.json": "runtime/list-level-portable-final/summary.json",
            "source-review.json": "runtime/list-level-review/source-review.json",
            "evidence-review.json": "runtime/list-level-review/evidence-review.json",
            "portable-result.json": "runtime/list-level-portable-final/result.json",
            "initial-intake.json": "runtime/intake-audit/initial-reconciled.json",
            "pre-gate-intake.json": "runtime/pre-gate-intake.json",
            "final-intake.json": final_intake_member,
            "environment.json": "runtime/environment.json",
            "runtime-verification.json": "runtime/list-level-runtime-verification.json",
            "checkpoints.json": "runtime/checkpoint-receipts.json",
            "final-gates-invocation.json": "runtime/final-gates-invocation.json",
            "publication-scope-review.json": SCOPE_REVIEW_MEMBER,
        }

    def unknown_candidates(self) -> list[str]:
        unknown = []
        selected = {member.path for member in self.members.values()}
        watched = ("compiler-levels-", "native-list-levels-", "list-level-", "intake-",
                   "pre-publication-", "mail-corrections-", "final-", "checkpoint-")
        for path in self.runtime.iterdir():
            if path.is_file() and path.name.startswith(watched) and path not in selected:
                unknown.append(f"runtime/{path.name}")
            elif path.is_dir() and path.name.startswith(("list-level-", "word-office-")):
                if path.name not in self.directory_allowlists:
                    unknown.append(f"runtime/{path.name}/")
        for directory, allowed in self.directory_allowlists.items():
            path = self.runtime / directory
            if path.is_dir():
                for child in path.iterdir():
                    if child.name not in allowed or not child.is_file() or child.is_symlink():
                        unknown.append(f"runtime/{directory}/{child.name}")
        return sorted(unknown)


def load_snapshot(selection: Selection) -> tuple[dict[str, tuple[bytes, int]], list[str]]:
    snapshot, missing = {}, []
    for name, member in sorted(selection.members.items()):
        if not member.path.exists():
            if name in selection.required:
                missing.append(name)
            continue
        data, mode = read_stable(member.path)
        scan_credentials(name, data)
        snapshot[name] = (data, mode)
    if sum(len(data) for data, _ in snapshot.values()) > MAX_TOTAL_BYTES:
        raise ValueError("Selected inputs exceed the explicit total size cap")
    return snapshot, missing


def scoped_reconciliation(selection: Selection, snapshot: dict, intake: dict, refresh: dict) -> tuple[dict, list[str]]:
    """Verify the one explicit post-intake Mail deferral without changing raw data."""
    problems = []

    def check(condition, message):
        if not condition:
            problems.append("Publication scope: " + message)

    def read(name):
        item = snapshot.get(name)
        return json.loads(item[0]) if item is not None else None

    def bound(record, name):
        item = snapshot.get(name)
        valid = (isinstance(record, dict) and record.get("path") == name and item is not None
                 and {key: record.get(key) for key in ("bytes", "sha256")} == identity(item[0]))
        check(valid, "bound artifact identity differs: " + name)
        return valid

    @lru_cache(maxsize=None)
    def git(*arguments):
        result = subprocess.run(["git", *arguments], cwd=selection.repo, capture_output=True)
        if result.returncode:
            raise ValueError("Read-only publication-scope Git comparison failed: " + arguments[0])
        return result.stdout

    @lru_cache(maxsize=None)
    def ancestor(head, target):
        if not all(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{40}", value)
                   for value in (head, target)):
            return False
        result = subprocess.run(["git", "merge-base", "--is-ancestor", head, target],
                                cwd=selection.repo, capture_output=True)
        if result.returncode not in (0, 1):
            raise ValueError("Read-only publication-scope ancestry comparison failed")
        return result.returncode == 0

    def tree(ref, paths):
        result = {}
        for item in git("ls-tree", "-rz", ref, "--", *paths).split(b"\0"):
            if item:
                metadata, name = item.split(b"\t", 1)
                mode, kind, blob = metadata.decode().split()
                result[name.decode()] = {"mode": mode, "type": kind, "blob": blob}
        return result

    scope = read(SCOPE_REVIEW_MEMBER)
    initial = read("runtime/intake-audit/initial-reconciled.json")
    mail_review = read(CURRENT_MAIL_REVIEW_MEMBER)
    if scope is None or initial is None or mail_review is None:
        return {"accepted": False, "mode": "explicit_post_intake_mail_deferral"}, [
            "Publication scope: exact independent scope/current-Mail/initial records are required"]
    check(scope.get("schema") == "quds-word-list-level-publication-scope-review/v1",
          "unexpected independent receipt schema")
    check(scope.get("scope_review_accepted") is True and scope.get("problems") == [],
          "independent scope review is not accepted")
    check(scope.get("decision") == "publish_qualified_word_and_defer_post_intake_mail_draft",
          "receipt is not the explicit reviewed publication decision")
    bound(scope.get("initial_capture"), "runtime/intake-audit/initial-reconciled.json")
    bound(scope.get("final_capture"), selection.copies["final-intake.json"])
    bound(scope.get("final_refresh"), "runtime/intake-final-refresh.json")
    bound(scope.get("scope_review_script"), "runtime/list-level-review/review_publication_scope.py")
    target = scope.get("publication_target", {})
    check(target == {"commit": SCOPED_PUBLICATION_TARGET, "tree": intake.get("target_tree")}
          and intake.get("target_commit") == SCOPED_PUBLICATION_TARGET,
          "target is not the exact reviewed Word checkpoint")
    check(git("rev-parse", SCOPED_PUBLICATION_TARGET + "^{tree}").decode().strip() == target.get("tree"),
          "publication target tree differs from Git")
    freeze = "3c87debcd4d50cac88981ec39255c3c6890fe8fa"
    check(scope.get("word_qualified_source") == freeze and ancestor(freeze, SCOPED_PUBLICATION_TARGET),
          "qualified Word ancestry is missing")
    expected_deferred = [{"ref": ref, "sha": DEFERRED_MAIL_HEAD, "status": "uncovered"}
                         for ref in DEFERRED_MAIL_REFS]
    canonical_rows = lambda rows: sorted(rows, key=lambda item: (item["ref"], item["sha"]))
    check(canonical_rows(intake.get("uncovered_ref_entries", [])) == expected_deferred
          and canonical_rows(scope.get("deferred_ref_entries", [])) == expected_deferred,
          "raw uncovered refs/SHAs differ from the exact reviewed two-ref Mail draft")
    flags = {"all_initial_heads_included": True, "all_final_heads_included": False,
             "all_deferred_refs_absent_from_initial_capture": True,
             "all_deferred_heads_descend_from_word_freeze": True,
             "github_actions_queried_or_awaited": False}
    for name, expected in flags.items():
        check(scope.get(name) is expected, "required explicit scope flag differs: " + name)
    check(scope.get("unclassified_uncovered_ref_entries") == [], "there are unclassified uncovered refs")
    initial_rows = [{**row, "group": group} for group in ("branches", "pull_requests", "upstream") for row in initial[group]]
    final_rows = [{**row, "group": group} for group in ("branches", "pull_requests", "upstream") for row in intake[group]]
    initial_counts = dict(collections.Counter(row["group"] for row in initial_rows))
    final_counts = dict(collections.Counter(row["group"] for row in final_rows))
    check(initial_counts == {"branches": 21, "pull_requests": 260, "upstream": 4}
          and scope["initial_capture"].get("counts") == initial_counts,
          "initial captured scope/counts differ")
    check(final_counts == {"branches": 23, "pull_requests": 262, "upstream": 4}
          and scope["final_capture"].get("counts") == final_counts, "final capture/counts differ")
    check(initial.get("uncovered_ref_entries") == [] and initial.get("all_historical_proofs_verified") is True,
          "initial intake was not fully reconciled")
    check(set(DEFERRED_MAIL_REFS).isdisjoint(row["ref"] for row in initial_rows),
          "a deferred ref was already part of the initial obligation")
    check(ancestor(freeze, DEFERRED_MAIL_HEAD) and not ancestor(DEFERRED_MAIL_HEAD, SCOPED_PUBLICATION_TARGET),
          "Mail head has an unexpected relationship to the Word target")

    # Independently recheck the fourteen equivalence proofs, including the one
    # exact 37-path continuation, before using them to classify any initial row.
    original_proofs = {item["historical_head"]: item for item in initial["historical_equivalence_proofs"]}
    scope_proofs = {item["historical_head"]: item for item in scope.get("historical_equivalence_proofs", [])}
    check(len(scope.get("historical_equivalence_proofs", [])) == len(scope_proofs) == len(original_proofs) == 14
          and set(scope_proofs) == set(original_proofs), "historical proof set is incomplete or duplicated")
    verified_historical = {}
    for head, old in original_proofs.items():
        proof = scope_proofs.get(head, {})
        accepted = old["accepted_ancestor"]
        left_tree = git("rev-parse", head + "^{tree}").decode().strip()
        right_tree = git("rev-parse", accepted + "^{tree}").decode().strip()
        valid = (proof.get("verified") is True and proof.get("accepted_ancestor") == accepted
                 and proof.get("historical_tree") == left_tree and proof.get("accepted_tree") == right_tree
                 and proof.get("accepted_is_ancestor_of_publication_target") is True
                 and ancestor(accepted, SCOPED_PUBLICATION_TARGET))
        if left_tree == right_tree:
            valid = valid and proof.get("method") == "identical_full_tree"
        else:
            paths = [value.decode() for value in git("diff", "--name-only", "-z", old["comparison_base"], head).split(b"\0") if value]
            left, right = tree(head, paths), tree(accepted, paths)
            records = [{"path": path, "historical_entry": left.get(path), "accepted_entry": right.get(path),
                        "equal": left.get(path) == right.get(path)} for path in sorted(paths)]
            valid = (valid and head == "c34945761e7991f5fe49037d79529acdd260b31c"
                     and accepted == "2c47165d01d01cc883135a434ac9f6591ce6e770"
                     and len(paths) == 37 and set(paths) == {item["path"] for item in old["entries"]}
                     and left == right and proof.get("method") == "exact_changed_path_continuation"
                     and proof.get("comparison_base") == old["comparison_base"]
                     and proof.get("changed_path_count") == 37 and proof.get("paths") == records)
        check(valid, "historical equivalence proof failed: " + head)
        if valid:
            verified_historical[head] = accepted
    row_key = lambda row: (row["group"], row["ref"], row["sha"])
    initial_proofs = {row_key(item): item for item in scope.get("initial_head_inclusion_proofs", [])}
    check(len(scope.get("initial_head_inclusion_proofs", [])) == len(initial_proofs) == 285
          and set(initial_proofs) == {row_key(item) for item in initial_rows},
          "initial inclusion proof rows differ from all 285 captured entries")
    for row in initial_rows:
        proof = initial_proofs.get(row_key(row), {})
        included = ancestor(row["sha"], SCOPED_PUBLICATION_TARGET)
        if included:
            valid = proof.get("inclusion_method") == "ancestor"
        else:
            accepted = verified_historical.get(row["sha"])
            valid = (accepted is not None and proof.get("inclusion_method") == "historical_equivalence"
                     and proof.get("accepted_ancestor") == accepted and proof.get("historical_proof_head") == row["sha"])
        check(valid and proof.get("included") is True, "initial head inclusion failed: " + row["ref"])
    raw_uncovered = []
    for row in final_rows:
        status, head = row["status"], row["sha"]
        if status in ("ancestor", "exact_target"):
            check(ancestor(head, SCOPED_PUBLICATION_TARGET), "final claimed ancestor is absent: " + row["ref"])
            check(status != "exact_target" or head == SCOPED_PUBLICATION_TARGET, "incorrect exact-target classification")
        elif status == "historically_superseded_equivalent":
            check(head in verified_historical and verified_historical[head] == row.get("accepted_ancestor"),
                  "final historical inclusion failed: " + row["ref"])
        elif status == "uncovered":
            raw_uncovered.append({key: row[key] for key in ("ref", "sha", "status")})
        else:
            check(False, "unrecognized final ref classification")
    check(canonical_rows(raw_uncovered) == expected_deferred, "final rows and raw uncovered list differ")
    observed = {}
    for namespace in ("refs/remotes/origin", "refs/remotes/pull", "refs/remotes/upstream"):
        for row in git("for-each-ref", "--format=%(objectname) %(refname)", namespace).decode().splitlines():
            sha, ref = row.split(" ", 1)
            if not ref.endswith("/HEAD"):
                observed[ref] = sha
    check(len(final_rows) == len({row["ref"] for row in final_rows})
          and observed == {row["ref"]: row["sha"] for row in final_rows},
          "locally fetched inventory changed since the raw final capture; reassessment is required")
    main = scope.get("current_origin_main", {})
    main_rows = [row for row in final_rows if row["ref"] == "refs/remotes/origin/main"]
    check(len(main_rows) == 1 and main == {"ref": "refs/remotes/origin/main", "sha": main_rows[0]["sha"], "inclusion_method": "ancestor"}
          and ancestor(main.get("sha"), SCOPED_PUBLICATION_TARGET), "captured current origin/main is not included")
    expected_commands = [
        ["git", "fetch", "origin", "+refs/heads/*:refs/remotes/origin/*", "+refs/pull/*/head:refs/remotes/pull/*"],
        ["git", "fetch", "upstream", "+refs/heads/*:refs/remotes/upstream/*"],
        ["python", "docs/validation/word-vba-list-levels-20261120/audit_intake.py", "--repo", str(selection.repo),
         "--target", "HEAD", "--output", str(selection.final_intake)],
    ]
    commands = refresh.get("commands", [])
    check([item.get("argv") for item in commands] == expected_commands
          and all(item.get("cwd") == str(selection.repo) for item in commands), "final fetch/audit commands differ")
    check([item.get("exit_code") for item in commands] == [0, 0, 1] and refresh.get("complete") is not True
          and scope.get("final_refresh", {}).get("exit_codes") == [0, 0, 1]
          and scope.get("final_refresh", {}).get("audit_exit_code") == 1,
          "raw uncovered-audit exit 1 must be retained, not converted to success")
    historical_bindings = scope.get("historical_review_bindings", [])
    check(len(historical_bindings) == 2 and {item.get("path") for item in historical_bindings} == set(HISTORICAL_MAIL_REVIEWS),
          "historical Mail finding bindings are incomplete")
    for item in historical_bindings:
        path = item.get("path")
        if path in HISTORICAL_MAIL_REVIEWS and bound(item, path):
            prior = read(path)
            prior_head = prior.get("captured_commit", prior.get("captured_source", {}).get("commit"))
            check(prior_head == HISTORICAL_MAIL_REVIEWS[path] and prior.get("blocks_main_publication_at_captured_head") is True,
                  "historical Mail review identifies a different head or disposition")
    deferred_reviews = scope.get("deferred_head_reviews", [])
    check(len(deferred_reviews) == 1, "exactly one reviewed deferred head is required")
    if len(deferred_reviews) == 1:
        item = deferred_reviews[0]
        bound(item, CURRENT_MAIL_REVIEW_MEMBER)
        check(item.get("commit") == DEFERRED_MAIL_HEAD and item.get("classification") == "post_intake_draft_awaiting_source_bound_qualification",
              "deferred review head/classification differs")
    check(mail_review.get("captured_commit") == DEFERRED_MAIL_HEAD
          and mail_review.get("classification") == "post_intake_draft_awaiting_source_bound_qualification"
          and mail_review.get("supports_explicit_deferral") is True
          and mail_review.get("source_review_only") is True
          and mail_review.get("no_fresh_execution_claim") is True
          and mail_review.get("mail_runtime_qualified_by_this_review") is False
          and mail_review.get("earlier_omissions_not_reasserted_as_unfixed") is True,
          "current Mail review does not support the precise corrected-but-unqualified classification")
    check(git("rev-parse", DEFERRED_MAIL_HEAD + "^{tree}").decode().strip() == mail_review.get("captured_tree"),
          "deferred Mail tree differs from its source review")
    for path, expected in mail_review.get("reviewed_source_bindings", {}).items():
        check(identity(git("show", DEFERRED_MAIL_HEAD + ":" + path)) == expected,
              "deferred Mail source binding differs: " + path)
    gate_inputs = json.loads(gzip.decompress(snapshot["runtime/word-office-final/inputs-before.json.gz"][0]))
    source_paths = gate_inputs["selection"]["directories"] + gate_inputs["selection"]["configuration_files"]
    expected_inputs = {path: item["head"] for path, item in gate_inputs["entries"].items()}
    check(tree(DEFERRED_MAIL_HEAD, source_paths) == expected_inputs and len(expected_inputs) == 1123,
          "deferred head changed the qualified Word input set")
    preservation = scope.get("preservation", {})
    check(preservation.get("raw_final_audit_and_refresh_modified") is False
          and preservation.get("captured_ref_set_matches_current_local_fetched_refs") is True,
          "scope receipt does not affirm preservation of raw capture/failure")
    return {"accepted": not problems, "mode": "explicit_post_intake_mail_deferral",
            "all_initial_heads_included": True, "all_final_heads_included": False,
            "initial_counts": initial_counts, "captured_final_counts": final_counts,
            "incorporated_final_counts": {"branches": 22, "pull_requests": 261, "upstream": 4},
            "raw_final_audit_exit_code": 1, "deferred_ref_entries": expected_deferred,
            "scope_review": {"path": SCOPE_REVIEW_MEMBER, **identity(snapshot[SCOPE_REVIEW_MEMBER][0])},
            "caveat": "The two exact new Mail refs remain outside the published Word history; their corrected source awaits separate Mail acceptance. Raw uncovered entries and audit exit 1 are preserved."}, problems


def qualifications(selection: Selection, snapshot: dict) -> tuple[dict, list[str]]:
    problems = list(selection.problems)
    selected_by_path = {str(selection.members[name].path): (name, data)
                        for name, (data, _) in snapshot.items()}

    def read(name):
        item = snapshot.get(name)
        if item is None:
            return None
        data = item[0]
        return json.loads(gzip.decompress(data) if name.endswith(".gz") else data)

    def check(condition, message):
        if not condition:
            problems.append(message)

    invocation = read("runtime/final-gates-invocation.json") or {}
    check(invocation.get("complete") is True, "Final sequential invocation is not complete")
    check(invocation.get("sequential") is True, "Final invocation does not record sequential phases")
    phases = invocation.get("phases", [])
    check(len(phases) == 3, "Final invocation must record all three phases")
    check(all(p.get("exit_code") == 0 for p in phases), "A recorded outer phase failed or lacks explicit exit metadata")
    frozen_commit, frozen_tree = invocation.get("source_commit"), invocation.get("source_tree")
    stages = {}
    expected_runtime_counts = {"regression": 11, "checks": 20, "portable": 20}
    common_source = None
    for stage, directory in FINAL_DIRS.items():
        prefix = f"runtime/{directory}/"
        summary = read(prefix + "summary.json")
        before, after = read(prefix + "inputs-before.json.gz"), read(prefix + "inputs-after.json.gz")
        if summary is None or before is None or after is None:
            problems.append(f"Final {stage} summary/manifests are incomplete")
            continue
        check(summary.get("accepted" if stage == "regression" else "qualified") is True,
              f"Final {stage} summary is not accepted")
        check(not summary.get("problems"), f"Final {stage} summary reports problems")
        check(before.get("entries") == after.get("entries"), f"Final {stage} source identities changed")
        check(before.get("runtime_inputs") == after.get("runtime_inputs"), f"Final {stage} runtime identities changed")
        selected_runtime_bindings = []
        for path, expected in before.get("runtime_inputs", {}).items():
            selected = selected_by_path.get(path)
            if selected is not None:
                name, data = selected
                check(identity(data) == expected, f"Selected runtime input differs from final {stage} manifest: {name}")
                selected_runtime_bindings.append(name)
        source_count, runtime_count = len(before.get("entries", {})), len(before.get("runtime_inputs", {}))
        check(source_count == 1123, f"Final {stage} does not bind the reviewed 1,123 source inputs")
        check(runtime_count == expected_runtime_counts[stage], f"Final {stage} runtime input count differs from reviewed scope")
        for label, manifest in (("before", before), ("after", after)):
            check(manifest.get("head_matches_worktree") is True, f"Final {stage} {label} worktree did not match HEAD")
            check(manifest.get("source_commit") == frozen_commit and manifest.get("source_tree") == frozen_tree,
                  f"Final {stage} {label} source differs from the invocation freeze")
        if common_source is None:
            common_source = before["entries"]
        else:
            check(common_source == before["entries"], "Source identities differ across final stages")
        for name, expected in summary.get("hashes", {}).items():
            item = snapshot.get(prefix + name)
            actual = identity(item[0]) if item is not None else None
            check(actual is not None and (actual == expected if isinstance(expected, dict) else actual["sha256"] == expected),
                  f"Final {stage} summary file binding differs: {name}")
        stages[stage] = {"source_inputs": source_count, "runtime_inputs": runtime_count,
                         "selected_runtime_bindings": sorted(selected_runtime_bindings)}
        if stage == "regression":
            check(summary.get("complete") is True and summary.get("exit_code") == 0,
                  "Final regression did not complete successfully")
            check(summary.get("file_count") == 70 and summary.get("failed_cases") == 0 and summary.get("skipped_cases") == 0,
                  "Final regression scope or results differ from the reviewed gate")
            stages[stage].update({"modules": summary.get("file_count"), "passing_cases": summary.get("passing_cases")})
        elif stage == "checks":
            check(summary.get("analysis_clean") is True and summary.get("formatting_clean") is True,
                  "Final analysis/format checks are not clean")
            check(summary.get("formatted_file_count") == 9, "Final formatting selection differs from the nine reviewed files")
            stages[stage]["formatted_files"] = summary.get("formatted_file_count")
        else:
            check(summary.get("commands_succeeded") is True and summary.get("raw_outputs_equal") is True
                  and summary.get("canonical_results_equal") is True, "Final portable execution is not accepted")
            vm = snapshot.get(prefix + "vm.stdout", (b"", 0))[0]
            node = snapshot.get(prefix + "node.stdout", (b"", 0))[0]
            check(bool(vm) and vm == node, "Final portable raw outputs are missing or different")
            if vm:
                canonical = (json.dumps(json.loads(vm), sort_keys=True, separators=(",", ":")) + "\n").encode()
                check(snapshot.get(prefix + "result.json", (None, 0))[0] == canonical,
                      "Final portable canonical result differs from raw output")
            bas = snapshot.get(prefix + "actual-example.bas", (b"", 0))[0]
            check(digest(bas) == summary.get("bas_sha256"), "Final actual BAS snapshot hash differs")
            check(bas == snapshot.get("quds_office_suite/packages/quds_office_engine/example/macros/word_list_levels.bas", (None, 0))[0],
                  "Current BAS differs from the final exact BAS snapshot")
            driver = snapshot.get("quds_office_suite/packages/quds_office_engine/tool/macros/web_vba_word_list_levels_smoke.dart", (b"", 0))[0]
            check(digest(driver) == summary.get("driver_sha256"), "Current portable driver differs from the final qualification")
            stages[stage]["canonical_sha256"] = summary.get("canonical_sha256")
    review = read("runtime/list-level-review/evidence-review.json")
    if review is None:
        problems.append("Independent final evidence review is not yet available")
    else:
        check(review.get("accepted") is True and not review.get("problems"), "Independent final evidence review is not accepted")
        check(review.get("frozen_source_commit") == frozen_commit and review.get("frozen_source_tree") == frozen_tree,
              "Independent evidence review source differs from the final invocation")
        for stage, files in review.get("evidence_files", {}).items():
            directory = FINAL_DIRS.get(stage)
            if directory is None:
                problems.append("Independent evidence review has an unknown stage")
                continue
            selected_names = {name.removeprefix(f"runtime/{directory}/") for name in snapshot
                              if name.startswith(f"runtime/{directory}/")}
            check(set(files) == selected_names, f"Independent {stage} evidence file set differs from the archive selection")
            for name, expected in files.items():
                item = snapshot.get(f"runtime/{directory}/{name}")
                check(item is not None and identity(item[0]) == expected,
                      f"Independent {stage} evidence binding differs: {name}")
    probe = read("runtime/list-level-review/probe-final-receipt.json")
    source_review = read("runtime/list-level-review/source-review.json")
    if probe is None or source_review is None:
        problems.append("Independent final probe/source review is incomplete")
    else:
        check(probe.get("accepted") is True and probe.get("exit_code") == 0
              and probe.get("inputs_unchanged") is True and probe.get("count") == probe.get("passed") == 18,
              "Independent final eighteen-probe receipt is not accepted")
        for key, name in (("stdout_sha256", "probe-final.json"), ("stderr_sha256", "probe-final.stderr")):
            item = snapshot.get("runtime/list-level-review/" + name)
            check(item is not None and digest(item[0]) == probe.get(key), f"Independent probe output binding differs: {name}")
        check(source_review.get("production_bound_to_final_probe") is True
              and source_review.get("disposition", "").startswith("accepted"), "Independent source review is not accepted")
        receipt = snapshot["runtime/list-level-review/probe-final-receipt.json"][0]
        check(digest(receipt) == source_review.get("probe_receipt_sha256"), "Source review probe-receipt binding differs")
    intake = read(selection.copies["final-intake.json"])
    reconciliation = {"accepted": False, "mode": "complete_final_inventory"}
    if intake is None:
        problems.append("Final reconciliation intake is not yet available")
    else:
        check(intake.get("all_historical_proofs_verified") is True,
              "Final reconciliation has unverified historical proofs")
        check(intake.get("github_actions_used") is False, "Final reconciliation does not affirm Actions were unused")
    refresh = read("runtime/intake-final-refresh.json")
    if refresh is None:
        problems.append("Final remote inventory refresh receipt is not yet available")
    else:
        check(refresh.get("github_actions_queried_or_awaited") is False,
              "Final inventory refresh does not affirm Actions were unused")
        if intake is not None and intake.get("uncovered_ref_entries"):
            reconciliation, scope_problems = scoped_reconciliation(selection, snapshot, intake, refresh)
            problems.extend(scope_problems)
        else:
            complete = (refresh.get("complete") is True and len(refresh.get("commands", [])) == 3
                        and all(command.get("exit_code") == 0 for command in refresh.get("commands", [])))
            check(complete, "Final remote inventory refresh did not complete successfully")
            check(intake is not None and intake.get("uncovered_ref_entries") == [],
                  "Final reconciliation does not record an empty uncovered set")
            reconciliation = {"accepted": bool(complete and intake is not None and intake.get("uncovered_ref_entries") == []),
                              "mode": "complete_final_inventory", "all_final_heads_included": True}
    return {"frozen_source_commit": frozen_commit, "frozen_source_tree": frozen_tree, "stages": stages,
            "independent_probe_cases": 18 if probe and probe.get("accepted") else None,
            "reconciliation": reconciliation}, problems


def make_archive(members: list[Member], snapshot: dict) -> tuple[bytes, list[dict]]:
    raw = io.BytesIO()
    records = []
    with tarfile.open(fileobj=raw, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for member in sorted(members, key=lambda item: item.name):
            data, mode = snapshot[member.name]
            info = tarfile.TarInfo(member.name)
            info.size, info.mode, info.mtime = len(data), mode, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            info.type = tarfile.REGTYPE
            info.pax_headers = {}
            archive.addfile(info, io.BytesIO(data))
            records.append({"path": member.name, "mode": f"{mode:04o}", **identity(data)})
    compressed = lzma.compress(raw.getvalue(), format=lzma.FORMAT_XZ, check=lzma.CHECK_CRC64, preset=6)
    return compressed, records


def verify_archive(data: bytes, expected: dict):
    if identity(data) != expected["identity"]:
        raise ValueError("Archive file bytes differ from the archive manifest")
    records = expected["members"]
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:xz") as archive:
        members = archive.getmembers()
        if [item.name for item in members] != [item["path"] for item in records]:
            raise ValueError("Archive member path/order set differs from the archive manifest")
        for item, record in zip(members, records):
            if (not item.isfile() or item.uid != 0 or item.gid != 0 or item.mtime != 0
                    or item.uname or item.gname or f"{item.mode:04o}" != record["mode"]):
                raise ValueError(f"Archive metadata differs from the normalized contract: {item.name}")
            source = archive.extractfile(item)
            if source is None or identity(source.read()) != {key: record[key] for key in ("bytes", "sha256")}:
                raise ValueError(f"Archive member identity differs: {item.name}")


def atomic_write(path: Path, data: bytes):
    if path.exists():
        current, _ = read_stable(path)
        if current == data:
            return
    fd, temporary = tempfile.mkstemp(prefix=".evidence-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        os.chmod(temporary, 0o644)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def output_inventory(out: Path) -> dict:
    result = {}
    for path in sorted(out.iterdir()):
        if path.name == "evidence-files.json":
            continue
        if path.name.startswith(".") or not path.is_file() or path.is_symlink():
            raise ValueError(f"Unexpected non-deliverable output entry; review explicitly: {path.name}")
        data, _ = read_stable(path)
        scan_credentials(path.name, data)
        result[path.name] = identity(data)
    return result


def verify_output_archives(out: Path):
    manifest = json.loads((out / "archive-members.json").read_bytes())
    if set(manifest["archives"]) != set(ARCHIVES.values()):
        raise ValueError("Expected exactly the four explicit evidence archives")
    for name, expected in manifest["archives"].items():
        data, _ = read_stable(out / name)
        verify_archive(data, expected)


def write_file_manifest(out: Path) -> dict:
    verify_output_archives(out)
    first = output_inventory(out)
    second = output_inventory(out)
    if first != second:
        raise ValueError("Delivered files changed while building the final manifest")
    result = {
        "schema": "quds-word-list-level-evidence-files/v1",
        "scope": "Every regular file directly in this evidence directory, excluding this manifest itself; subdirectories and hidden entries are refused.",
        "excluded_self": "evidence-files.json", "files": first,
    }
    atomic_write(out / "evidence-files.json", json_bytes(result))
    return result


def validate_output_path(path: Path, runtime: Path, repo: Path) -> Path:
    absolute = path.absolute()
    if absolute != path.resolve() or absolute in (runtime, repo, runtime.parent):
        raise ValueError("Use a distinct evidence directory with no symlink parents")
    if not absolute.is_relative_to(runtime.parent):
        raise ValueError("Evidence output must be inside this authorized workspace")
    return absolute


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--runtime", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--repo", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--final-intake", type=Path)
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--inspect", action="store_true", help="Read selected existing inputs and report readiness; do not write files")
    action.add_argument("--manifest-only", action="store_true", help="Verify archived members and refresh the final output-file manifest only")
    action.add_argument("--verify", action="store_true", help="Verify the complete output-file manifest and every archive member only")
    parser.add_argument("--details", action="store_true", help="Include selected input identities in the inspection output")
    args = parser.parse_args()
    runtime = args.runtime.resolve()
    repo = (args.repo or runtime.parent / "quds_office_suite").resolve()
    if runtime.parent != repo.parent:
        raise ValueError("Runtime and repository must share a workspace parent")
    out = validate_output_path(args.out, runtime, repo) if args.out else None
    if args.manifest_only or args.verify:
        if out is None or not out.is_dir():
            raise ValueError("An existing --out directory is required")
        if args.manifest_only:
            result = write_file_manifest(out)
            print(json.dumps({"manifest_updated": True, "files": len(result["files"]), "out": str(out)}))
        else:
            manifest = json.loads((out / "evidence-files.json").read_bytes())
            if output_inventory(out) != manifest["files"]:
                raise ValueError("Delivered file identity/path set differs from evidence-files.json")
            verify_output_archives(out)
            print(json.dumps({"verified": True, "files": len(manifest["files"]), "archives": len(ARCHIVES), "out": str(out)}))
        return 0
    final_intake = (args.final_intake or runtime / "final-intake.json").absolute()
    if not final_intake.is_relative_to(runtime) or final_intake.resolve() != final_intake:
        raise ValueError("Final intake must be an explicit file beneath runtime with no symlink parents")
    selection = Selection(runtime, repo, final_intake)
    snapshot, missing = load_snapshot(selection)
    qualification, problems = qualifications(selection, snapshot)
    unknown = selection.unknown_candidates()
    groups = {}
    for group, archive_name in ARCHIVES.items():
        names = [name for name in snapshot if selection.members[name].group == group]
        groups[archive_name] = {"members": len(names), "uncompressed_bytes": sum(len(snapshot[name][0]) for name in names)}
    ready = not missing and not problems and not unknown
    preview = {"ready": ready, "missing_required": missing, "qualification_problems": problems,
               "unselected_relevant_candidates": unknown, "archives": groups,
               "qualification": qualification, "copied_reports": selection.copies,
               "excluded": EXCLUDED, "limits": QUALIFICATION_LIMITS}
    if args.details:
        preview["selected_inputs"] = {name: {"archive": ARCHIVES[selection.members[name].group], "mode": f"{mode:04o}", **identity(data)}
                                      for name, (data, mode) in snapshot.items()}
    if args.inspect:
        print(json.dumps(preview, indent=2, sort_keys=True))
        return 0
    if out is None:
        raise ValueError("--out is required to package completed evidence")
    if not ready:
        print(json.dumps(preview, indent=2, sort_keys=True))
        return 2
    products, archive_manifest = {}, {}
    for group, name in ARCHIVES.items():
        members = [member for member in selection.members.values() if member.group == group and member.name in snapshot]
        data, records = make_archive(members, snapshot)
        products[name] = data
        archive_manifest[name] = {"identity": identity(data), "member_count": len(records), "members": records}
        verify_archive(data, archive_manifest[name])
    for name, source in selection.copies.items():
        products[name] = snapshot[source][0]
    products["archive-members.json"] = json_bytes({
        "schema": "quds-word-list-level-archive-members/v1",
        "format": {"container": "POSIX PAX tar in XZ", "xz_preset": 6, "xz_check": "CRC64",
                   "tar_mtime": 0, "tar_uid": 0, "tar_gid": 0, "tar_owner_names": "",
                   "mode_policy": "0755 when the source has an executable bit, otherwise 0644",
                   "member_order": "lexicographic path order", "directory_entries": False},
        "archives": archive_manifest,
    })
    products["packaging.json"] = json_bytes({
        "schema": "quds-word-list-level-evidence-packaging/v1",
        "qualification": qualification, "copied_reports": selection.copies,
        "selected_input_count": len(snapshot), "selected_input_bytes": sum(len(data) for data, _ in snapshot.values()),
        "development_logs_separate": True, "explicit_missing_output_exception": "Accidental quds_dummy stdout was redirected to /dev/null and is unavailable; see the archived correction receipt.",
        "source_selection": "Exact allowlisted files only; no recursive runtime or repository collection.",
        "excluded": EXCLUDED, "limits": QUALIFICATION_LIMITS, "reproduction": REPRODUCTION,
        "final_output_directories": FINAL_DIRS,
        "preserved_existing_reports": "Existing README.md, qualification.json and publication/source-consistency reports are never replaced; evidence-files.json binds all delivered files when refreshed after publication.",
    })
    # Finish compression and validation before touching the destination. Refuse
    # a concurrently updated input even when its replacement has the same name.
    for name, (data, mode) in snapshot.items():
        again, again_mode = read_stable(selection.members[name].path)
        if data != again or mode != again_mode:
            raise ValueError(f"Selected input changed during packaging: {name}")
    out.mkdir(parents=True, exist_ok=True)
    for name, data in sorted(products.items()):
        atomic_write(out / name, data)
    final_manifest = write_file_manifest(out)
    print(json.dumps({"packaged": True, "out": str(out), "archive_count": len(archive_manifest),
                      "archive_bytes": sum(item["identity"]["bytes"] for item in archive_manifest.values()),
                      "selected_inputs": len(snapshot), "delivered_files": len(final_manifest["files"]),
                      "qualification": qualification}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError, tarfile.TarError, lzma.LZMAError) as error:
        print(f"Evidence packaging refused: {error}", file=sys.stderr)
        raise SystemExit(2)
