#!/usr/bin/env python3
"""Run the exact Word list-level BAS on the Dart VM and compiled JavaScript."""
import argparse
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

import word_office_gate as gate

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
out = args.out.resolve()
assert not out.exists(), 'Use a new output directory; earlier evidence is retained'
out.mkdir(parents=True)
runtime = Path(__file__).resolve().parent
repo = runtime.parent / 'quds_office_suite'
engine = repo / 'packages/quds_office_engine'
dart = runtime / 'dart-sdk/bin/dart'
packages = repo / '.dart_tool/package_config.json'
bas = engine / 'example/macros/word_list_levels.bas'
driver = engine / 'tool/macros/web_vba_word_list_levels_smoke.dart'
bas_bytes = bas.read_bytes()
(out / 'actual-example.bas').write_bytes(bas_bytes)
define = '-DWORD_LIST_LEVELS_BAS_BASE64=' + base64.b64encode(bas_bytes).decode()
node = shutil.which('node')
assert node
environment = os.environ.copy()
environment.update({
    'PUB_CACHE': str(runtime / 'pub-cache'),
    'TMPDIR': str(runtime / 'tmp'),
    'XDG_CONFIG_HOME': str(runtime / 'config'),
    'XDG_CACHE_HOME': str(runtime / 'cache'),
    'DART_SUPPRESS_ANALYTICS': 'true',
    'PATH': str(runtime / 'dart-sdk/bin') + os.pathsep + environment['PATH'],
})
def file_identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return {'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def runtime_manifest():
    result = gate.runtime_manifest(driver)
    paths = [Path(__file__).resolve(), dart.resolve(), Path(node).resolve(),
             runtime / 'dart-sdk/bin/dartaotruntime',
             runtime / 'dart-sdk/bin/snapshots/dartdev_aot.dart.snapshot',
             runtime / 'dart-sdk/bin/snapshots/dart2js_aot.dart.snapshot',
             runtime / 'dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot',
             runtime / 'dart-sdk/bin/snapshots/gen_kernel_aot.dart.snapshot',
             runtime / 'dart-sdk/bin/snapshots/kernel-service.dart.snapshot']
    for path in paths:
        if path.exists():
            result[str(path)] = file_identity(path)
    return result


before = gate.source_manifest()
before['runtime_inputs'] = runtime_manifest()
assert before['entries'][str(bas.relative_to(repo))]['sha256'] == hashlib.sha256(bas_bytes).hexdigest()
gate.save(out / 'inputs-before.json.gz', before)
shutil.copyfile(Path(__file__), out / 'runner.py')
shutil.copyfile(Path(gate.__file__), out / 'gate-helper.py')
commands = [
    ('vm', [str(dart), f'--packages={packages}', define, str(driver)]),
    ('compile-js', [str(dart), 'compile', 'js', '-O1', f'--packages={packages}',
                    define, '-o', str(out / 'word-list-levels.js'), str(driver)]),
    ('node', [node, '-e', 'globalThis.self = globalThis; require(process.argv[1]);',
              str(out / 'word-list-levels.js')]),
]
receipts = []
for name, command in commands:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    beginning = time.monotonic()
    with (out / f'{name}.stdout').open('wb') as stdout, (out / f'{name}.stderr').open('wb') as stderr:
        result = subprocess.run(command, cwd=engine, env=environment, stdout=stdout, stderr=stderr)
    receipt = {'name': name, 'argv': command, 'cwd': str(engine),
               'started_utc': started, 'seconds': round(time.monotonic()-beginning, 3),
               'exit_code': result.returncode}
    receipts.append(receipt)
    gate.save(out / 'commands.json', receipts)
    print(json.dumps({key: receipt[key] for key in ['name', 'seconds', 'exit_code']}), flush=True)
    if result.returncode:
        break
after = gate.source_manifest()
after['runtime_inputs'] = runtime_manifest()
gate.save(out / 'inputs-after.json.gz', after)
summary = {'commands_succeeded': len(receipts) == 3 and all(c['exit_code'] == 0 for c in receipts),
           'source_commit_before': before['source_commit'],
           'source_tree_before': before['source_tree'],
           'head_matches_worktree': before['head_matches_worktree'],
           'head_matches_worktree_after': after['head_matches_worktree'],
           'complete_source_input_count': len(before['entries']),
           'source_inputs_unchanged': before['entries'] == after['entries'],
           'runtime_inputs_unchanged': before['runtime_inputs'] == after['runtime_inputs'],
           'runtime_input_count': len(before['runtime_inputs']),
           'bas_sha256': hashlib.sha256(bas_bytes).hexdigest(),
           'bas_snapshot': 'actual-example.bas',
           'driver_sha256': before['entries'][str(driver.relative_to(repo))]['sha256'],
           'runner_sha256': before['runtime_inputs'][str(Path(__file__).resolve())]['sha256'],
           'commands': receipts}
if summary['commands_succeeded']:
    vm = (out / 'vm.stdout').read_bytes()
    js = (out / 'node.stdout').read_bytes()
    summary['raw_outputs_equal'] = vm == js
    summary['raw_output_bytes'] = len(vm)
    summary['raw_output_sha256'] = hashlib.sha256(vm).hexdigest()
    try:
        vm_result, js_result = json.loads(vm), json.loads(js)
        summary['canonical_results_equal'] = vm_result == js_result
        canonical = (json.dumps(vm_result, sort_keys=True, separators=(',', ':')) + '\n').encode()
        (out / 'result.json').write_bytes(canonical)
        summary['canonical_sha256'] = hashlib.sha256(canonical).hexdigest()
    except (ValueError, UnicodeError) as error:
        summary['canonical_results_equal'] = False
        summary['result_parse_error'] = str(error)
complete = (summary['commands_succeeded'] and summary.get('raw_outputs_equal')
            and summary.get('canonical_results_equal') and summary['source_inputs_unchanged']
            and summary['runtime_inputs_unchanged'] and summary['head_matches_worktree']
            and summary['head_matches_worktree_after'])
summary['qualified'] = bool(complete)
gate.save(out / 'summary.json', summary)
print(json.dumps({key: summary.get(key) for key in ['commands_succeeded', 'source_inputs_unchanged', 'runtime_inputs_unchanged', 'head_matches_worktree', 'raw_outputs_equal', 'canonical_results_equal', 'canonical_sha256', 'qualified']}), flush=True)
raise SystemExit(0 if complete else 1)
