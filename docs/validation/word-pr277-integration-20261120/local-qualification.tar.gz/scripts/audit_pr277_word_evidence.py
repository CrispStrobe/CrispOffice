"""Read-only PR277 Word/Zotero event, archive, and Git source audit."""
from collections import Counter
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
from urllib.parse import unquote, urlparse

ROOT = Path('/workspace/scratch/03cd41fa0e7e')
REPO = ROOT / 'quds_merge_final'
RUNTIME = ROOT / 'runtime'
INCOMING = '383c0c0c5d3b4b1a6edccc8d09ffd1ca64029537'
OURS = '0e4e999a08996a6b8696ca3adba11e303331b73e'
EXECUTED = '520d0ca8870c6a169e23603660f2cde96366f9b2'
PREFIX = 'docs/validation/zotero-vertical-tables-20261120/'
ENV = {**os.environ, 'GIT_NO_LAZY_FETCH': '1'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env=ENV)


def blob(path, head=INCOMING):
    return git('show', head + ':' + path)


def doc(path):
    return json.loads(blob(PREFIX + path))


def tree(head):
    rows = {}
    for row in git('ls-tree', '-r', '-z', head).split(b'\0'):
        if row:
            meta, name = row.split(b'\t', 1)
            mode, kind, oid = meta.decode().split()
            if kind == 'blob':
                rows[name.decode()] = oid
    return rows


archives, archive_report = {}, {}
for archive_name, index_name in (
        ('local-validation.tar.gz', 'local-validation-index.json'),
        ('post-main-evidence.tar.gz', 'post-main-evidence-index.json'),
        ('freshness-tail-evidence.tar.gz', 'freshness-tail-evidence-index.json')):
    index = doc(index_name)
    data = blob(PREFIX + archive_name)
    spec = index['archive'] if isinstance(index['archive'], dict) else index
    assert sha(data) == spec['sha256'] and len(data) == spec['bytes']
    expected = index.get('members', index.get('files'))
    members = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        rows = archive.getmembers()
        assert len(rows) == len({r.name for r in rows})
        for row in rows:
            path = PurePosixPath(row.name)
            assert row.isfile() and not path.is_absolute() and '..' not in path.parts
            content = archive.extractfile(row).read()
            assert expected[row.name] == {'bytes': len(content), 'sha256': sha(content)}, row.name
            members[row.name] = content
    assert set(members) == set(expected)
    archives[archive_name] = members
    archive_report[archive_name] = {'sha256': sha(data), 'bytes': len(data), 'members': len(members)}

local = archives['local-validation.tar.gz']
inventory = doc('acceptance-suite-review.json')
all_cases, raw_report = [], {}
for cohort in ('engine', 'editor', 'incoming'):
    receipt = json.loads(local['acceptance/' + cohort + '-receipt.json'])
    raw = local['acceptance/' + cohort + '.jsonl']
    stderr = local['acceptance/' + cohort + '.stderr']
    before = local['acceptance/' + cohort + '-sources-before.json']
    after = local['acceptance/' + cohort + '-sources-after.json']
    assert receipt['head'] == EXECUTED and receipt['exit_code'] == 0
    assert receipt['tree'] == git('rev-parse', EXECUTED + '^{tree}').decode().strip()
    assert sha(raw) == receipt['log_sha256'] and sha(stderr) == receipt['stderr_sha256']
    assert stderr == b'' and before == after and sha(before) == receipt['source_manifest_sha256']
    assert receipt['source_stable'] and receipt['source_count'] == 5254
    events = [json.loads(line) for line in raw.splitlines() if line.strip()]
    assert len(events) == len(raw.splitlines())
    starts = {e['test']['id']: e['test'] for e in events if e['type'] == 'testStart'}
    suite_paths = {e['suite']['id']: e['suite']['path'] for e in events if e['type'] == 'suite'}
    assert len(starts) == sum(e['type'] == 'testStart' for e in events)
    ends = [e for e in events if e['type'] == 'testDone']
    assert Counter(e['testID'] for e in ends) == Counter({i: 1 for i in starts})
    terminals = [e for e in events if e['type'] == 'done']
    assert len(terminals) == 1 and terminals[0]['success'] and events[-1] == terminals[0]
    assert not any(e['type'] == 'error' for e in events)
    paths = inventory[cohort]['paths']
    by_basename = {Path(p).name: p for p in paths}
    assert len(by_basename) == len(paths)
    case_counts, suite_counts, skips, cases = Counter(), Counter(), [], []
    reasons = {e['testID']: e['message'] for e in events
               if e['type'] == 'print' and e.get('messageType') == 'skip'}
    for end in ends:
        start = starts[end['testID']]
        name = start['name']
        if (end.get('hidden') or name.startswith('loading ') or
                name.endswith('(setUpAll)') or name.endswith('(tearDownAll)')):
            continue
        original_url = unquote(urlparse(start.get('url') or '').path)
        candidates = [p for p in paths if original_url.endswith('/' + p)]
        if not candidates:
            candidates = [p for p in paths if Path(p).name + ' ' in name]
        if not candidates:
            suite_basename = Path(suite_paths[start['suiteID']]).name
            candidates = [p for p in paths if Path(p).name == suite_basename]
        assert len(candidates) == 1, (cohort, name, candidates, original_url)
        path = candidates[0]
        basename = Path(path).name
        # Aggregate groups add a filename prefix; original case identity does not.
        canonical_name = name.split(basename + ' ', 1)[1] if basename + ' ' in name else name
        case_counts[(path, canonical_name)] += 1
        status = 'skipped' if end.get('skipped') else end['result']
        assert status in ('success', 'skipped')
        suite_counts[(path, status)] += 1
        case = {'file': path, 'name': canonical_name, 'occurrence': case_counts[(path, canonical_name)],
                'result': end['result'], 'skipped': bool(end.get('skipped')),
                'cohort': cohort, 'executed_source': EXECUTED}
        if case['skipped']:
            case['reason'] = reasons.get(end['testID'])
            assert case['reason'] == 'no paragraphs to edit'
            skips.append(case)
        cases.append(case)
    passed = sum(not c['skipped'] for c in cases)
    assert passed == receipt['acceptance']['passed']
    assert len(skips) == receipt['acceptance']['skipped']
    assert {c['file'] for c in cases} == set(paths)
    raw_report[cohort] = {'passed': passed, 'skipped': len(skips), 'files': len(paths),
        'per_file': {p: {'passed': suite_counts[(p, 'success')], 'skipped': suite_counts[(p, 'skipped')]}
                     for p in paths}, 'receipt_sha256': sha(local['acceptance/' + cohort + '-receipt.json'])}
    all_cases.extend(cases)
assert len({(c['file'], c['name'], c['occurrence']) for c in all_cases}) == len(all_cases)
assert sum(not c['skipped'] for c in all_cases) == 2395

# Bind the execution manifest to immutable Git blobs, then preserve each
# recorded execution's source attribution rather than treating it as a new run.
source_manifest_bytes = local['acceptance/engine-sources-before.json']
source = json.loads(source_manifest_bytes)
assert len(source) == 5254
trees = {head: tree(head) for head in (EXECUTED, INCOMING, OURS)}
batch = subprocess.Popen(['git', '-C', str(REPO), 'cat-file', '--batch'],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, env=ENV)
hashes = {}


def oid_hash(oid):
    if oid not in hashes:
        batch.stdin.write((oid + '\n').encode())
        batch.stdin.flush()
        header = batch.stdout.readline().decode().strip().split()
        if len(header) == 2 and header[1] == 'missing':
            hashes[oid] = None
            return None
        assert len(header) == 3 and header[1] == 'blob', header
        data = batch.stdout.read(int(header[2]))
        assert batch.stdout.read(1) == b'\n'
        hashes[oid] = sha(data)
    return hashes[oid]


untracked_manifest, unavailable_git_blobs = {}, {}
for path, expected in source.items():
    oid = trees[EXECUTED].get(path)
    if oid is None:
        untracked_manifest[path] = expected
    else:
        actual_hash = oid_hash(oid)
        if actual_hash is None:
            unavailable_git_blobs[path] = {'blob': oid, 'recorded_sha256': expected}
        else:
            assert actual_hash == expected, path
assert set(untracked_manifest) == {'.dart_tool/package_config.json'}
changed_since_execution = [p for p in source if p in trees[EXECUTED]
                          and trees[EXECUTED][p] != trees[INCOMING].get(p)]
word_roots = ('packages/quds_office_engine/', 'packages/quds_office_editor/lib/',
              'packages/quds_office_editor/test/', 'packages/quds_office_editor/tool/',
              'legacy_doc_parser/')
assert not any(p.startswith(word_roots) for p in changed_since_execution)
assert not any(p.startswith(word_roots) for p in unavailable_git_blobs)
for path in ('pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'):
    assert trees[EXECUTED][path] == trees[INCOMING][path] == trees[OURS][path]

production = [
    'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
    'packages/quds_office_engine/lib/src/word/layout/word_note_layout.dart',
    'packages/quds_office_engine/lib/src/word/layout/word_table_row_layout.dart',
    'packages/quds_office_engine/lib/src/word/model/word_zotero_note.dart',
    'packages/quds_office_engine/lib/src/word/serial/word_serializer.dart',
    'packages/quds_office_editor/lib/src/editor_word/render_word_canvas.dart',
    'packages/quds_office_editor/lib/src/embed/office_controller.dart',
]
selected = {}
for path in production:
    data = (REPO / path).read_bytes()
    assert sha(data) == oid_hash(trees[INCOMING][path]) == source[path]
    selected[path] = sha(data)
preserved = {}
for path in (
    'packages/quds_office_engine/lib/src/automation/office_vba_language.dart',
    'packages/quds_office_engine/lib/src/word/serial/word_deserializer.dart',
    'packages/quds_office_engine/example/macros/word_measurements.bas',
    'packages/quds_office_engine/example/macros/word_named_measurements.bas',
    'packages/quds_office_engine/example/macros/word_unit_conversions.bas',
):
    assert trees[EXECUTED][path] == trees[INCOMING][path] == trees[OURS][path]
    assert sha((REPO / path).read_bytes()) == source[path]
    preserved[path] = source[path]

# All direct Word implementation/parser/fixtures are the recorded source;
# the retained stronger 13-case header test is the one original-suite mismatch.
closure_differences = []
for path in source:
    if path.startswith(word_roots):
        current = REPO / path
        if not current.exists() or sha(current.read_bytes()) != source[path]:
            closure_differences.append(path)
header = 'packages/quds_office_engine/test/word_header_picture_identity_test.dart'
assert closure_differences == [header], closure_differences
assert sha((REPO / header).read_bytes()) == oid_hash(trees[OURS][header])
suite_deltas = []
for path in sorted({c['file'] for c in all_cases}):
    ours_oid = trees[OURS].get(path)
    if ours_oid != trees[INCOMING][path]:
        suite_deltas.append({'file': path, 'kind': 'added' if ours_oid is None else 'changed',
                            'incoming_passed': sum(c['file'] == path and not c['skipped'] for c in all_cases)})
batch.stdin.close()
batch.wait()

studio_files = [p for p in inventory['editor']['paths'] if '/example/' in p]
applicable = [c for c in all_cases if c['file'] != header and c['file'] not in studio_files]
report = {
    'schema': 1, 'passed': True, 'incoming_main': INCOMING, 'previous_completed_head': OURS,
    'execution_source': EXECUTED, 'execution_tree': git('rev-parse', EXECUTED + '^{tree}').decode().strip(),
    'archives': archive_report, 'cohorts': raw_report,
    'raw_total': {'passed': 2395, 'skipped': 8, 'files': 72, 'all_started_tests_completed_once': True},
    'source_binding': {'source_manifest_sha256': sha(source_manifest_bytes), 'captured_inputs': len(source),
        'git_blob_hashes_verified': len(source) - len(untracked_manifest) - len(unavailable_git_blobs),
        'untracked_config_hash_only': untracked_manifest,
        'unavailable_unrelated_historical_git_blobs_not_fetched': unavailable_git_blobs,
        'changed_captured_paths_since_execution': changed_since_execution,
        'word_parser_original_fixture_differences_from_execution_to_incoming': [],
        'prospective_union_captured_word_closure_differences': closure_differences,
        'selected_production_sha256': selected, 'preserved_compiler_deserializer_examples_sha256': preserved},
    'incoming_test_deltas_from_previous_completed_head': suite_deltas,
    'direct_exact_source_applicability': {
        'passed': sum(not c['skipped'] for c in applicable),
        'skipped': sum(c['skipped'] for c in applicable),
        'files': len({c['file'] for c in applicable}),
        'excluded_incoming_header_variant': {'file': header, 'incoming_passed': 11, 'ours_preserved_passed_scope': 13},
        'excluded_shared_studio_shell': studio_files,
        'scope': 'Direct incoming Word/Zotero evidence retains its actual520 execution/runtime attribution. These overlapping populations are not added to historical3598 macros.'},
    'limits': [
        'No tests, source/config/ref edits, CI operations, or remote refresh were performed.',
        'The prospective union is not yet a final published source freeze.',
        'The execution archive records a stable package-config hash and locked runtime versions, but does not include that configuration content or a full external dependency byte inventory.',
        'Unavailable historical Mail blobs are reported explicitly; no lazy fetch was permitted. Every selected Word/parser/fixture input was Git-bound.',
        'Incoming positional alias suites have separate paths but overlap canonical measurement assertions; do not count them as new VBA functionality.',
        'Incoming StudioShell results include a different Mail implementation and are not adopted as exact-current shared-shell results.'],
    'auditor_sha256': sha(Path(__file__).read_bytes()),
}
out = RUNTIME / 'pr277-word-evidence-audit.json'
out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
(RUNTIME / 'pr277-incoming-word-cases.json').write_text(json.dumps(all_cases, indent=2, sort_keys=True) + '\n')
print(json.dumps({'path': str(out), 'sha256': sha(out.read_bytes()), 'raw_passed':2395,
                  'direct_exact_applicable_passed':report['direct_exact_source_applicability']['passed'],
                  'git_blobs_verified':report['source_binding']['git_blob_hashes_verified'], 'success':True}))
