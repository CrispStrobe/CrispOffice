#!/usr/bin/env python3
"""Qualify the retained header-identity suite on a published PR277 union."""
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path('/workspace/scratch/03cd41fa0e7e')
RUNTIME = BASE / 'runtime'
DART = RUNTIME / 'toolchain/dart-sdk/bin/dart'
FDART = RUNTIME / 'flutter-toolchain/flutter/bin/cache/dart-sdk/bin/dart'
KERNEL = RUNTIME / 'toolchain/test-runner/test-runner.dill'
TEST = 'packages/quds_office_engine/test/word_header_picture_identity_test.dart'
EXPECTED_TEST_HASH = 'afae2a679af7095c68d86d028472cc6a13fd80eed1952fece3553d2f4b5be3d3'
COMPILER_HASH = '41de865411b884d18c1097e9a80d68cd6bf1fb245e1844a46f72af05636f5ecd'
INCOMING = '383c0c0c5d3b4b1a6edccc8d09ffd1ca64029537'
LIBRARIES = [
    'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
    'packages/quds_office_engine/lib/src/word/layout/word_note_layout.dart',
    'packages/quds_office_engine/lib/src/word/layout/word_table_row_layout.dart',
    'packages/quds_office_engine/lib/src/word/model/word_zotero_note.dart',
    'packages/quds_office_engine/lib/src/word/serial/word_serializer.dart',
    'packages/quds_office_editor/lib/src/editor_word/render_word_canvas.dart',
    'packages/quds_office_editor/lib/src/embed/office_controller.dart',
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


parser = argparse.ArgumentParser()
parser.add_argument('--source', required=True)
parser.add_argument('--repo', type=Path, default=BASE / 'quds_merge_final')
parser.add_argument('--out', type=Path, default=RUNTIME / 'pr277-word-followup')
parser.add_argument('--incoming-audit', type=Path, required=True)
parser.add_argument('--incoming-audit-sha256', required=True)
args = parser.parse_args()
REPO = args.repo.resolve()
ENGINE = REPO / 'packages/quds_office_engine'
CONFIG = REPO / '.dart_tool/package_config.json'
OUT = args.out.resolve()


def git(*arguments):
    return subprocess.check_output(['git', '-C', str(REPO), *arguments], text=True).strip()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


assert len(args.source) == 40 and git('rev-parse', 'HEAD') == args.source
assert not git('status', '--porcelain'), 'The published source must be clean'
assert sha(args.incoming_audit) == args.incoming_audit_sha256
assert sha(REPO / TEST) == EXPECTED_TEST_HASH
assert sha(ENGINE / 'lib/src/automation/office_vba_language.dart') == COMPILER_HASH
for path in LIBRARIES:
    incoming = subprocess.check_output(['git', '-C', str(REPO), 'show', f'{INCOMING}:{path}'])
    assert incoming == (REPO / path).read_bytes(), path

prior_cases_path = RUNTIME / 'word-late-main-qualification/word-bridge-cases.json'
ledger_path = RUNTIME / 'pr277-word-retention-ledger.json'
audited_expected_path = RUNTIME / 'pr277-word-header-expected-cases.json'
assert sha(ledger_path) == '08d5bae84d34053e25886b5cb6637393768d859a7b3d909df67f246c01c5af37'
assert sha(audited_expected_path) == 'f85d94f7a5a2f55a29185b9e346d0fbafc6f0e5b3c847d8440033cb518e3556b'
expected_cases = [case for case in json.loads(prior_cases_path.read_text()) if case['file'] == TEST]
assert len(expected_cases) == 13
assert all(case['result'] == 'success' and not case['skipped'] for case in expected_cases)
expected_identities = sorted((c['file'], c['name'], c['occurrence']) for c in expected_cases)
assert expected_identities == sorted(
    (c['file'], c['name'], c['occurrence']) for c in json.loads(audited_expected_path.read_text())
)

OUT.mkdir(exist_ok=False)
for name in ('tmp', 'config', 'cache'):
    (OUT / name).mkdir()
environment = dict(os.environ)
environment.update({
    'PATH': str(DART.parent) + os.pathsep + os.environ['PATH'],
    'PUB_CACHE': str(RUNTIME / 'flutter-toolchain/pub-cache'),
    'TMPDIR': str(OUT / 'tmp'),
    'XDG_CONFIG_HOME': str(OUT / 'config'),
    'XDG_CACHE_HOME': str(OUT / 'cache'),
    'DART_SUPPRESS_ANALYTICS': 'true',
    'DASH__SUPPRESS_ANALYTICS': 'true',
    'CI': 'true',
})
source_paths = git(
    'ls-files', '--', ':(glob)packages/**/lib/**', ':(glob)packages/**/test/**',
    ':(glob)packages/**/fonts/**', ':(glob)packages/**/pubspec.yaml',
    ':(glob)packages/**/analysis_options.yaml', 'third_party/enough_mail/lib',
    'third_party/enough_mail/pubspec.yaml', 'pubspec.yaml', 'pubspec.lock',
    'analysis_options.yaml', '.fvmrc', 'packages/quds_office_engine/tool',
    'packages/quds_office_engine/example/macros',
).splitlines()
runtime_paths = [
    DART, FDART, KERNEL, CONFIG, REPO / '.dart_tool/package_graph.json',
    DART.parent / 'snapshots/analysis_server_aot.dart.snapshot',
    RUNTIME / 'toolchain/environment.json', RUNTIME / 'flutter-toolchain/runtime.json',
    RUNTIME / 'quds-merge-final-runtime-mapping.json',
    args.incoming_audit, prior_cases_path, ledger_path, audited_expected_path, Path(__file__).resolve(),
]
assert all(path.is_file() for path in runtime_paths)


def sources():
    return {path: sha(REPO / path) for path in source_paths}


def runtimes():
    return {str(path): sha(path) for path in runtime_paths}


before, runtime_before = sources(), runtimes()
save('source-before.json', before)
save('runtime-before.json', runtime_before)
save('expected-case-identities.json', expected_cases)
(OUT / 'incoming-retention-audit.json').write_bytes(args.incoming_audit.read_bytes())
(OUT / 'incoming-retention-ledger.json').write_bytes(ledger_path.read_bytes())
report = {
    'source_head': args.source,
    'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'source_parents': git('show', '-s', '--format=%P', 'HEAD').split(),
    'started_utc': now(),
    'incoming_source': INCOMING,
    'incoming_audit_sha256': args.incoming_audit_sha256,
    'incoming_retention_ledger_sha256': sha(ledger_path),
    'audited_expected_cases_sha256': sha(audited_expected_path),
    'incoming_production_hashes': {path: before[path] for path in LIBRARIES},
    'incoming_production_byte_identical': True,
    'selection': {TEST: 13},
    'selection_rationale': 'Retain all thirteen independent header/footer visual-node cases, including the two distinct-node/shared-asset/same-placement cases absent from incoming PR277. Run the complete retained file against the exact incoming vertical-table libraries; other incoming executions retain their own source/runtime attribution.',
    'compiler_sha256': COMPILER_HASH,
    'source_files_hashed': len(before),
    'runtime_files_hashed': len(runtime_before),
    'dart_version': subprocess.check_output([DART, '--version'], text=True).strip(),
    'commands': [],
    'github_actions_used': False,
}


def run(name, command, cwd):
    print(f'Starting {name}', flush=True)
    start, started = time.monotonic(), now()
    stdout, stderr = OUT / f'{name}.stdout.log', OUT / f'{name}.stderr.log'
    with stdout.open('w') as out, stderr.open('w') as err:
        result = subprocess.run([str(v) for v in command], cwd=cwd, env=environment, stdout=out, stderr=err)
    report['commands'].append({
        'name': name, 'command': [str(v) for v in command], 'cwd': str(cwd),
        'started_utc': started, 'finished_utc': now(),
        'seconds': round(time.monotonic() - start, 3), 'exit_code': result.returncode,
        'stdout': stdout.name, 'stdout_sha256': sha(stdout),
        'stderr': stderr.name, 'stderr_sha256': sha(stderr),
    })
    save('progress.json', report)
    print(f'Finished {name}: exit {result.returncode}', flush=True)


run('header-identity', [DART, '--old_gen_heap_size=768', f'--packages={CONFIG}', KERNEL,
    '--compiler', 'source', '--concurrency=1', '--timeout=4x', '--reporter=json',
    str((REPO / TEST).relative_to(ENGINE))], ENGINE)
events, malformed = [], []
for number, line in enumerate((OUT / 'header-identity.stdout.log').read_text().splitlines(), 1):
    if line.startswith('{'):
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            malformed.append(number)
suites = {}
for event in events:
    if event.get('type') == 'suite':
        path = Path(event['suite']['path'])
        path = path if path.is_absolute() else ENGINE / path
        suites[event['suite']['id']] = str(path.resolve().relative_to(REPO))
starts = {event['test']['id']: event['test'] for event in events if event.get('type') == 'testStart'}
done = [event for event in events if event.get('type') == 'testDone']
completion_counts = collections.Counter(event['testID'] for event in done)
occurrences, cases = collections.Counter(), []
for event in done:
    if event.get('hidden'):
        continue
    test = starts[event['testID']]
    path = suites[test['suiteID']]
    occurrences[(path, test['name'])] += 1
    cases.append({'file': path, 'name': test['name'], 'occurrence': occurrences[(path, test['name'])],
                  'result': event['result'], 'skipped': bool(event.get('skipped'))})
save('header-identity-cases.json', cases)
report['tests'] = {
    'passed': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
    'failed': sum(c['result'] != 'success' for c in cases),
    'skipped': sum(c['skipped'] for c in cases),
    'exact_prior_case_identities': sorted((c['file'], c['name'], c['occurrence']) for c in cases) == expected_identities,
    'malformed_reporter_lines': malformed,
    'reporter_errors': sum(e.get('type') == 'error' for e in events),
    'every_started_test_completed_once': set(starts) == set(completion_counts) and all(n == 1 for n in completion_counts.values()),
    'terminal_success': bool(events and events[-1].get('type') == 'done' and events[-1].get('success')),
}
run('header-analysis', [DART, 'analyze', '--fatal-infos', str((REPO / TEST).relative_to(ENGINE))], ENGINE)
run('header-format', [FDART, 'format', '--output=none', '--set-exit-if-changed', TEST], REPO)
after, runtime_after = sources(), runtimes()
save('source-after.json', after)
save('runtime-after.json', runtime_after)
report.update({
    'source_unchanged': before == after, 'runtime_unchanged': runtime_before == runtime_after,
    'head_unchanged': git('rev-parse', 'HEAD') == args.source,
    'worktree_clean': not git('status', '--porcelain'), 'finished_utc': now(),
})
checks = report['tests']
report['success'] = (
    all(c['exit_code'] == 0 for c in report['commands']) and checks['passed'] == 13
    and checks['failed'] == checks['skipped'] == checks['reporter_errors'] == 0
    and not malformed and checks['exact_prior_case_identities']
    and checks['every_started_test_completed_once'] and checks['terminal_success']
    and all(report[k] for k in ('source_unchanged', 'runtime_unchanged', 'head_unchanged', 'worktree_clean'))
)
save('qualification.json', report)
print(json.dumps({'success': report['success'], 'tests': checks, 'source_unchanged': report['source_unchanged'],
                  'runtime_unchanged': report['runtime_unchanged']}), flush=True)
raise SystemExit(0 if report['success'] else 1)
