"""Independently close PR277 Word retention from saved raw events; no tests."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/03cd41fa0e7e')
RUNTIME = ROOT / 'runtime'
REPO = ROOT / 'quds_merge_final'
RUN = RUNTIME / 'pr277-word-followup'
HEAD = '5c7b76a6137bc9373276ce2e7fccc6ed48903998'
INCOMING = '383c0c0c5d3b4b1a6edccc8d09ffd1ca64029537'
HEADER = 'packages/quds_office_engine/test/word_header_picture_identity_test.dart'
ENV = {**os.environ, 'GIT_NO_LAZY_FETCH': '1'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def key(c):
    return c['file'], c['name'], c['occurrence']


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env=ENV)


receipt = read(RUN / 'qualification.json')
audit = read(RUNTIME / 'pr277-word-evidence-audit.json')
ledger = read(RUNTIME / 'pr277-word-retention-ledger.json')
assert receipt['success'] and receipt['source_head'] == HEAD
assert receipt['source_tree'] == git('rev-parse', HEAD + '^{tree}').decode().strip()
assert receipt['source_parents'] == git('show', '-s', '--format=%P', HEAD).decode().split()
assert receipt['source_parents'] == [ledger.get('previous_completed_head',
    '0e4e999a08996a6b8696ca3adba11e303331b73e'), INCOMING]
for name, field in (('pr277-word-evidence-audit.json', 'incoming_audit_sha256'),
                    ('pr277-word-retention-ledger.json', 'incoming_retention_ledger_sha256'),
                    ('pr277-word-header-expected-cases.json', 'audited_expected_cases_sha256')):
    assert sha((RUNTIME / name).read_bytes()) == receipt[field]
assert (RUN / 'incoming-retention-audit.json').read_bytes() == (RUNTIME / 'pr277-word-evidence-audit.json').read_bytes()
assert (RUN / 'incoming-retention-ledger.json').read_bytes() == (RUNTIME / 'pr277-word-retention-ledger.json').read_bytes()
assert len(receipt['commands']) == 3
for command in receipt['commands']:
    assert command['exit_code'] == 0
    for stream in ('stdout', 'stderr'):
        content = (RUN / command[stream]).read_bytes()
        assert sha(content) == command[stream + '_sha256']
        if stream == 'stderr':
            assert not content
assert '--fatal-infos' in receipt['commands'][1]['command']
assert '--output=none' in receipt['commands'][2]['command']
assert '--set-exit-if-changed' in receipt['commands'][2]['command']

events = [json.loads(line) for line in (RUN / receipt['commands'][0]['stdout']).read_text().splitlines()]
starts = {e['test']['id']: e['test'] for e in events if e['type'] == 'testStart'}
assert len(starts) == sum(e['type'] == 'testStart' for e in events)
ends = [e for e in events if e['type'] == 'testDone']
assert Counter(e['testID'] for e in ends) == Counter({i: 1 for i in starts})
done = [e for e in events if e['type'] == 'done']
assert len(done) == 1 and done[0]['success'] and events[-1] == done[0]
assert not any(e['type'] == 'error' for e in events)
suites = {}
for event in events:
    if event['type'] == 'suite':
        path = Path(event['suite']['path'])
        if not path.is_absolute():
            path = Path(receipt['commands'][0]['cwd']) / path
        suites[event['suite']['id']] = str(path.resolve().relative_to(REPO))
counts, fresh = Counter(), []
for end in ends:
    if end.get('hidden'):
        continue
    start = starts[end['testID']]
    file = suites[start['suiteID']]
    assert file == HEADER and end['result'] == 'success' and not end.get('skipped')
    counts[(file, start['name'])] += 1
    fresh.append({'file': file, 'name': start['name'], 'occurrence': counts[(file, start['name'])],
                  'result': end['result'], 'skipped': False})
assert len(fresh) == 13
assert fresh == read(RUN / 'header-identity-cases.json')
assert Counter(map(key, fresh)) == Counter(map(key, read(RUNTIME / 'pr277-word-header-expected-cases.json')))
assert Counter(map(key, fresh)) == Counter(map(key, read(RUN / 'expected-case-identities.json')))

source, runtime = read(RUN / 'source-before.json'), read(RUN / 'runtime-before.json')
assert source == read(RUN / 'source-after.json') and len(source) == 2877
assert runtime == read(RUN / 'runtime-after.json') and len(runtime) == 14
for path, expected in runtime.items():
    assert sha(Path(path).read_bytes()) == expected, path
rows = {}
for line in git('ls-tree', '-r', '-z', HEAD).split(b'\0'):
    if line:
        meta, name = line.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        if kind == 'blob':
            rows[name.decode()] = oid
batch = subprocess.Popen(['git', '-C', str(REPO), 'cat-file', '--batch'],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, env=ENV)
hashes = {}
for path, expected in source.items():
    assert sha((REPO / path).read_bytes()) == expected, path
    oid = rows[path]
    if oid not in hashes:
        batch.stdin.write((oid + '\n').encode())
        batch.stdin.flush()
        header = batch.stdout.readline().decode().split()
        assert len(header) == 3 and header[1] == 'blob', header
        data = batch.stdout.read(int(header[2]))
        assert batch.stdout.read(1) == b'\n'
        hashes[oid] = sha(data)
    assert hashes[oid] == expected, path
batch.stdin.close()
assert batch.wait() == 0
assert receipt['incoming_production_hashes'] == audit['source_binding']['selected_production_sha256']
for path, expected in receipt['incoming_production_hashes'].items():
    assert source[path] == expected and sha(git('show', INCOMING + ':' + path)) == expected
assert not git('diff', '--name-only', INCOMING, HEAD, '--',
    'packages/quds_office_engine/lib', 'packages/quds_office_editor/lib', 'packages/legacy_doc_parser')
for flag in ('head_unchanged', 'source_unchanged', 'runtime_unchanged', 'worktree_clean'):
    assert receipt[flag]

retained = read(RUNTIME / 'pr277-word-retained-execution-cases.json')
canonical_retained = read(RUNTIME / 'pr277-word-retained-canonical-cases.json')
for name, spec in ledger['case_exports'].items():
    data = (RUNTIME / name).read_bytes()
    assert spec == {'bytes': len(data), 'sha256': sha(data)}
fresh = [{**c, 'cohort': 'fresh-header-identity', 'executed_source': HEAD} for c in fresh]
actual, canonical = retained + fresh, canonical_retained + fresh


def population(cases):
    assert len(set(map(key, cases))) == len(cases)
    assert all(c['result'] == 'success' for c in cases)
    return {'passed': sum(not c['skipped'] for c in cases),
            'skipped': sum(c['skipped'] for c in cases), 'files': len({c['file'] for c in cases})}


assert population(actual) == {'passed': 2381, 'skipped': 8, 'files': 70}
assert population(canonical) == {'passed': 2178, 'skipped': 8, 'files': 68}
assert all(c['executed_source'] == HEAD for c in actual if c['file'] == HEADER)
assert sum(c['file'] == HEADER for c in actual) == 13
exports = {}
for name, content in (('pr277-word-accepted-execution-cases.json', actual),
                      ('pr277-word-accepted-canonical-cases.json', canonical)):
    data = (json.dumps(content, indent=2, sort_keys=True) + '\n').encode()
    (RUNTIME / name).write_bytes(data)
    exports[name] = {'bytes': len(data), 'sha256': sha(data)}
report = {
    'schema': 1, 'success': True, 'actionable_findings': [],
    'accepted_source_head': HEAD, 'accepted_source_tree': receipt['source_tree'],
    'source_parents': receipt['source_parents'],
    'qualification_sha256': sha((RUN / 'qualification.json').read_bytes()),
    'incoming_audit_sha256': receipt['incoming_audit_sha256'],
    'conditional_ledger_sha256': receipt['incoming_retention_ledger_sha256'],
    'fresh_header': {'passed': 13, 'files': 1, 'failed': 0, 'skipped': 0,
        'exact_prior_case_identities': True, 'incoming11_superseded_as_complete_file': True},
    'accepted_actual_execution_identities': population(actual),
    'accepted_canonical_identities': population(canonical),
    'retained_actual_execution_identities': {'passed': 2368, 'skipped': 8, 'files': 69},
    'retained_canonical_identities': {'passed': 2165, 'skipped': 8, 'files': 67},
    'macro_attribution': {'incoming_execution_identities': 974, 'canonical_identities': 771,
        'positional_alias_executions': 203, 'new_cases_added_to_historical3598': 0},
    'historical_macro_corpus': {'cases': 3598, 'files': 69, 'compiler_unchanged': True,
                              'not_a_whole_corpus_rerun': True},
    'source_inputs_git_and_working_bytes_verified': 2877,
    'runtime_inputs_verified_unchanged': 14,
    'three_command_exits_and_six_log_hashes_verified': True,
    'all_started_raw_tests_completed_once': True,
    'incoming_seven_word_libraries_retained_exactly': True,
    'static_scope': {'fresh': 'one stronger header file, fatal-info analysis and no-write format',
                     'retained': '30 exact Word paths from incoming75-file strict static gate'},
    'case_exports': exports,
    'limits': ['No new tests, captures, source/config/ref edits, CI calls, or remote refresh.',
               'Incoming runs retain their actual520 execution source/runtime; only13 header cases ran freshly at5c7.',
               'Canonical deduplication removes the two proved positional alias files; totals must not be added to overlapping historical macro, Word, or Mail populations.',
               'Incoming16 shared-Studio-shell cases remain excluded from exact-current acceptance.',
               'Incoming package-config content and one unrelated old Mail Git blob are unavailable, as disclosed in the original audit.'],
    'auditor_sha256': sha(Path(__file__).read_bytes()),
}
out = RUNTIME / 'pr277-word-final-independent-review.json'
out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'path': str(out), 'sha256': sha(out.read_bytes()), 'success': True,
                  'actual': population(actual), 'canonical': population(canonical)}))
