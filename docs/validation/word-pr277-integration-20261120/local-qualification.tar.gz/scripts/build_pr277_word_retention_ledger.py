"""Record source-attributed PR277 retention without inflating alias coverage."""
from collections import Counter
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/03cd41fa0e7e')
RUNTIME = ROOT / 'runtime'
REPO = ROOT / 'quds_merge_final'
HEAD = '383c0c0c5d3b4b1a6edccc8d09ffd1ca64029537'
PREFIX = 'docs/validation/zotero-vertical-tables-20261120/'
ENGINE = 'packages/quds_office_engine/'
HEADER = ENGINE + 'test/word_header_picture_identity_test.dart'
ENV = {**os.environ, 'GIT_NO_LAZY_FETCH': '1'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def blob(path):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', HEAD + ':' + path], env=ENV)


def key(c):
    return c['file'], c['name'], c['occurrence']


audit_path = RUNTIME / 'pr277-word-evidence-audit.json'
audit = read(audit_path)
assert audit['passed']
incoming = read(RUNTIME / 'pr277-incoming-word-cases.json')
excluded_studio = set(audit['direct_exact_source_applicability']['excluded_shared_studio_shell'])
retained = [c for c in incoming if c['file'] != HEADER and c['file'] not in excluded_studio]
alias_map = {
    ENGINE + 'test/office_vba_word_measurements_positional_test.dart':
        ENGINE + 'test/office_vba_word_measurements_test.dart',
    ENGINE + 'test/office_vba_word_measurements_positional_integration_test.dart':
        ENGINE + 'test/office_vba_word_measurements_integration_test.dart',
}
alias_cases = [c for c in retained if c['file'] in alias_map]
canonical = [c for c in retained if c['file'] not in alias_map]
assert len(alias_cases) == 203 and not any(c['skipped'] for c in alias_cases)
keys = set(map(key, canonical))
assert all((alias_map[c['file']], c['name'], c['occurrence']) in keys for c in alias_cases)
alias_proofs = []
for alias, original in alias_map.items():
    a, b = blob(alias), blob(original)
    normalized = a.replace(b'word_measurements_positional', b'word_measurements')
    normalized = normalized.replace(
        b"import '../tool/macros/web_vba_word_measurements_smoke.dart'\n    as portable;",
        b"import '../tool/macros/web_vba_word_measurements_smoke.dart' as portable;")
    assert normalized == b
    alias_proofs.append({'alias_file': alias, 'canonical_file': original,
        'alias_sha256': sha(a), 'canonical_sha256': sha(b), 'raw_identical': a == b,
        'only_normalizations': [] if a == b else ['helper/BAS filename alias', 'one wrapped import'],
        'equivalent_case_identities': sum(c['file'] == alias for c in alias_cases)})
for alias, original in (
    ('example/macros/word_measurements_positional.bas', 'example/macros/word_measurements.bas'),
    ('tool/macros/web_vba_word_measurements_positional_smoke.dart', 'tool/macros/web_vba_word_measurements_smoke.dart')):
    assert blob(ENGINE + alias) == blob(ENGINE + original)

expected_header = []
for c in read(RUNTIME / 'word-late-main-qualification/word-bridge-cases.json'):
    path = c['file'] if c['file'].startswith('packages/') else ENGINE + c['file']
    if path == HEADER:
        expected_header.append({**c, 'file': path})
assert len(expected_header) == 13
old_header = [c for c in incoming if c['file'] == HEADER]
renames = {'shared model node paints exactly once': 'shared node at the same placement paints exactly once'}
normalized_header = set()
for c in old_header:
    name = c['name']
    for old, new in renames.items():
        name = name.replace(old, new)
    normalized_header.add((c['file'], name, c['occurrence']))
expected_keys = set(map(key, expected_header))
assert len(normalized_header) == 11 and normalized_header <= expected_keys
additional = sorted(expected_keys - normalized_header)
assert len(additional) == 2 and all('distinct nodes may reuse one asset at the same placement' in k[1] for k in additional)

archive = blob(PREFIX + 'freshness-tail-evidence.tar.gz')
assert sha(archive) == audit['archives']['freshness-tail-evidence.tar.gz']['sha256']
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as t:
    static = json.load(t.extractfile('static/receipt.json'))
    before = json.load(t.extractfile('static/source-before.json'))
    after = json.load(t.extractfile('static/source-after.json'))
    assert before['files'] == after['files'] and len(before['files']) == 75
    assert static['frozenHead'] == static['headAfter'] == before['head']
    assert static['sourceStable'] and not static['changedDuringVerification']
    for name, result in static['results'].items():
        assert result['exitCode'] == 0
        assert sha(t.extractfile('static/' + name + '.log').read()) == result['logSha256']
    assert '--fatal-infos' in static['results']['analysis']['command']
    assert '--fatal-warnings' in static['results']['analysis']['command']
    assert '--output=none' in static['results']['format']['command']
    assert '--set-exit-if-changed' in static['results']['format']['command']
static_word = {}
for path, expected in before['files'].items():
    if (path.startswith('packages/quds_office_engine/') or
            path.startswith(('packages/quds_office_editor/lib/',
                             'packages/quds_office_editor/test/',
                             'packages/quds_office_editor/tool/'))):
        if path != HEADER:
            assert sha(blob(path)) == sha((REPO / path).read_bytes()) == expected
            static_word[path] = expected
assert set(audit['source_binding']['selected_production_sha256']) <= set(static_word)


def population(cases):
    return {'passed': sum(not c['skipped'] for c in cases),
            'skipped': sum(c['skipped'] for c in cases),
            'files': len({c['file'] for c in cases})}


assert population(retained) == {'passed': 2368, 'skipped': 8, 'files': 69}
assert population(canonical) == {'passed': 2165, 'skipped': 8, 'files': 67}
incoming_macro = [c for c in incoming if c['cohort'] == 'incoming']
canonical_macro = [c for c in incoming_macro if c['file'] not in alias_map]
assert population(incoming_macro) == {'passed': 974, 'skipped': 0, 'files': 11}
assert population(canonical_macro) == {'passed': 771, 'skipped': 0, 'files': 9}
exports = {}
for name, content in (
        ('pr277-word-retained-execution-cases.json', retained),
        ('pr277-word-retained-canonical-cases.json', canonical),
        ('pr277-word-header-expected-cases.json', expected_header)):
    data = (json.dumps(content, indent=2, sort_keys=True) + '\n').encode()
    (RUNTIME / name).write_bytes(data)
    exports[name] = {'sha256': sha(data), 'bytes': len(data)}
report = {
    'schema': 1, 'status': 'retention_proved_header_followup_pending',
    'incoming_main': HEAD, 'evidence_audit_sha256': sha(audit_path.read_bytes()),
    'retained_actual_execution_identities': population(retained),
    'retained_canonical_identities': population(canonical),
    'incoming_macro_executions': population(incoming_macro),
    'incoming_canonical_macro_identities': population(canonical_macro),
    'positional_alias_executions': {'passed': 203, 'files': 2, 'canonical_new_coverage': 0,
                                  'proofs': alias_proofs},
    'historical_macro_corpus': {'cases': 3598, 'suites': 69,
        'compiler_and_examples_unchanged': True,
        'new_cases_added_by_incoming974': 0,
        'not_a_whole_corpus_rerun': True},
    'header_replacement': {'file': HEADER, 'old_incoming_cases_superseded': 11,
        'complete_fresh_file_expected': 13, 'pending_fresh_execution': True,
        'equivalent_shared_node_title_substitution': renames,
        'additional_canonical_cases': [{'file': f, 'name': n, 'occurrence': o} for f, n, o in additional]},
    'expected_accepted_union_only_after_header_pass': {
        'actual_execution_identities': {'passed': 2381, 'skipped': 8, 'files': 70},
        'canonical_identities': {'passed': 2178, 'skipped': 8, 'files': 68},
        'actual_populations': {'engine_native': 825, 'editor_direct': 582, 'macro_including_aliases': 974},
        'canonical_populations': {'engine_native': 825, 'editor_direct': 582, 'macro': 771}},
    'shared_studio_shell_results_not_adopted': {'passed': 16, 'files': sorted(excluded_studio),
        'reason': 'Incoming shell compiles different Mail implementations; keep historical source attribution.'},
    'incoming_static_retention': {'execution_source': static['frozenHead'], 'full_scoped_files': 75,
        'retained_exact_word_paths_count': len(static_word), 'retained_exact_word_sha256': static_word,
        'format_and_fatal_warning_info_analysis_passed': True,
        'stronger_header_file_requires_its_own_fresh_analysis_format': True},
    'case_exports': exports,
    'limits': ['No test execution or repository/source/config/ref changes.',
               '2381 and2178 are conditional expected totals until the13-case fresh gate passes.',
               'Do not add these overlapping Word/Zotero populations to historical3598 or Mail totals.'],
    'builder_sha256': sha(Path(__file__).read_bytes()),
}
out = RUNTIME / 'pr277-word-retention-ledger.json'
out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'path': str(out), 'sha256': sha(out.read_bytes()),
    'retained_actual': population(retained), 'retained_canonical': population(canonical),
    'expected_after13': report['expected_accepted_union_only_after_header_pass'],
    'static_word_paths_retained': len(static_word)}))
