#!/usr/bin/env python3
"""Assemble the bounded Word PR277 follow-up without modifying the repository."""
import argparse
import collections
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path('/workspace/scratch/03cd41fa0e7e')
RUNTIME = BASE / 'runtime'
RECEIPT = RUNTIME / 'pr277-word-followup'
REPO = BASE / 'quds_merge_final'
SOURCE = '5c7b76a6137bc9373276ce2e7fccc6ed48903998'
TREE = 'c3ac8ba4f302e6d4057e49d989ce3b81cd1dcd3c'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def key(case):
    return case['file'], case['name'], case['occurrence']


def population(cases):
    return {
        'passed': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
        'failed': sum(c['result'] != 'success' for c in cases),
        'skipped': sum(c['skipped'] for c in cases),
        'files': len({c['file'] for c in cases}),
    }


parser = argparse.ArgumentParser()
parser.add_argument('--review', type=Path, required=True)
parser.add_argument('--review-sha256', required=True)
parser.add_argument('--out', type=Path, default=RUNTIME / 'pr277-word-package')
args = parser.parse_args()
OUT = args.out.resolve()
assert sha(args.review.read_bytes()) == args.review_sha256
review = read(args.review)
assert review['success'] and review['accepted_source_head'] == SOURCE
q = read(RECEIPT / 'qualification.json')
assert q['success'] and q['source_head'] == SOURCE and q['source_tree'] == TREE
assert q['tests']['passed'] == 13 and q['tests']['exact_prior_case_identities']
assert sha((RECEIPT / 'qualification.json').read_bytes()) == review['qualification_sha256']
audit_path = RUNTIME / 'pr277-word-evidence-audit.json'
ledger_path = RUNTIME / 'pr277-word-retention-ledger.json'
audit, ledger = read(audit_path), read(ledger_path)
assert audit['passed']
assert sha(audit_path.read_bytes()) == q['incoming_audit_sha256']
assert sha(ledger_path.read_bytes()) == q['incoming_retention_ledger_sha256']
for name, expected in ledger['case_exports'].items():
    data = (RUNTIME / name).read_bytes()
    assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
fresh = [{**c, 'cohort': 'fresh-header-identity', 'executed_source': SOURCE} for c in read(RECEIPT / 'header-identity-cases.json')]
retained_execution = read(RUNTIME / 'pr277-word-retained-execution-cases.json')
retained_canonical = read(RUNTIME / 'pr277-word-retained-canonical-cases.json')
actual, canonical = retained_execution + fresh, retained_canonical + fresh
assert len(set(map(key, actual))) == len(actual)
assert len(set(map(key, canonical))) == len(canonical)
assert population(actual) == {'passed': 2381, 'failed': 0, 'skipped': 8, 'files': 70}
assert population(canonical) == {'passed': 2178, 'failed': 0, 'skipped': 8, 'files': 68}
accepted_exports = {}
for name, cases in [('pr277-word-accepted-execution-cases.json', actual),
                    ('pr277-word-accepted-canonical-cases.json', canonical)]:
    data = (RUNTIME / name).read_bytes()
    expected = review['case_exports'][name]
    assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
    assert json.loads(data) == cases
    accepted_exports[name] = data
skips = [{**c, 'reason': 'no paragraphs to edit'} for c in canonical if c['skipped']]
assert len(skips) == 8
assert all(c['file'].endswith('word_incremental_layout_equivalence_test.dart') for c in skips)
summary = {
    'schema': 1, 'success': True, 'qualified_source': SOURCE, 'qualified_tree': TREE,
    'parents': q['source_parents'],
    'fresh': {'source': SOURCE, 'passed': 13, 'files': 1, 'failed': 0, 'skipped': 0,
              'header_analysis_and_format_passed': True,
              'source_files_sealed': q['source_files_hashed'], 'runtime_files_sealed': q['runtime_files_hashed']},
    'retained': {'execution_source': audit['execution_source'],
                 'actual': population(retained_execution), 'canonical': population(retained_canonical)},
    'accepted_actual_executions': population(actual),
    'accepted_canonical_identities': population(canonical),
    'populations': ledger['expected_accepted_union_only_after_header_pass'],
    'positional_aliases': {'executions': 203, 'additional_canonical_cases': 0,
                           'proof': 'incoming-retention-ledger.json'},
    'header_replacement': {**ledger['header_replacement'], 'pending_fresh_execution': False,
                           'fresh_execution_source': SOURCE, 'fresh_passed': 13},
    'editor_exclusions': skips,
    'excluded_shared_studio_results': ledger['shared_studio_shell_results_not_adopted'],
    'historical_macro_corpus': ledger['historical_macro_corpus'],
    'source_resolution': 'source-resolution.json',
    'seven_incoming_libraries_byte_identical': q['incoming_production_hashes'],
    'compiler_sha256': q['compiler_sha256'],
    'incoming_static_retention': ledger['incoming_static_retention'],
    'independent_review_sha256': args.review_sha256,
    'accepted_case_exports': review['case_exports'],
    'incoming_audit_sha256': q['incoming_audit_sha256'],
    'incoming_retention_ledger_sha256': q['incoming_retention_ledger_sha256'],
    'incoming_archives': audit['archives'],
    'incoming_archive_directory': '../zotero-vertical-tables-20261120',
    'counting_policy': 'These scopes overlap prior Word/Zotero and historical VBA coverage. Only thirteen cases were freshly executed here. Positional aliases are executions, not new canonical cases. Do not add this scope to the historical3598 or Mail totals.',
    'limitations': [
        'Incoming executions retain their actual520d0ca8 source and runtime attribution; this is not2381 executions at the final source.',
        'Incoming archives retain a stable package-config hash and locked runtime versions, but not that configuration content or a complete external-dependency byte inventory.',
        'One unavailable unrelated historical Mail blob was excluded; all selected Word/parser/fixture inputs were Git-bound.',
        'Sixteen incoming shared-Studio cases compile a different Mail implementation and are not adopted as exact-current shared-shell acceptance.',
        'Eight image-only editing-equivalence fixtures have no paragraphs to edit and remain explicit exclusions.',
        'This report does not claim installed Word/Zotero interoperability, full VBA/COM, Single emulation, or DOCM signature validity.',
    ],
    'github_actions_used': False,
    'merge_record': 'https://github.com/CrispStrobe/quds_office_suite/pull/278',
}
README = f'''# PR #277 Word and Zotero follow-up

The bounded Word closure **passed** at published source `{SOURCE}`, tree
`{TREE}`. Its parents retain completed delivery `0e4e999a` and incoming main
`383c0c0c` (PR #277). The fresh gate ran **13 header-picture cases**, with zero
failures, errors or skips; one-file fatal-info analysis and read-only formatting
also passed. All **{q['source_files_hashed']:,} source inputs**, **{q['runtime_files_hashed']} runtime inputs**,
HEAD and the clean checkout were unchanged. [Receipt](fresh-qualification.json)

## Source resolution

The seven incoming engine/editor libraries are preserved byte-for-byte. They
support bounded vertical/combined Zotero table spans, citation and list ownership,
merged-cell page geometry, physical row handles, continuation navigation and
explicit cell-border DOCX roundtrips. The retained header suite keeps all13 cases,
including the two independent distinct-node/shared-asset/same-placement cases
absent from incoming's11-case file. The complete13-case result replaces that
incoming file; equivalent shared-node titles are mapped explicitly.

The VBA compiler and existing eight-, nine- and thirteen-operation BAS examples
are unchanged from both parents. The additional positional BAS and driver are
byte-identical aliases of the original measurement example/driver; their197
compiler and6 integration executions add no new canonical assertions. The
existing **3,598-case /69-suite historical macro record remains unchanged**.
[Source resolution](source-resolution.json) · [Alias ledger](incoming-retention-ledger.json)

## Accepted coverage and provenance

| Scope | Accepted cases | Execution attribution |
| --- | ---: | --- |
| Incoming engine/native cohort | 825 | 812 retained at520d0ca8 +13 fresh here |
| Direct editor cohort | 582 +8 exclusions | Retained at520d0ca8;16 shared-Studio cases excluded |
| Macro cohort | 771 canonical; 974 actual executions | Retained at520d0ca8;203 positional aliases |
| This bounded union | **2,178 canonical /68files +8 exclusions** | **2,381 actual executions /70files**, including the203 aliases |

These populations overlap prior Word/Zotero and VBA evidence. They are neither
a project-wide total nor one execution at the final SHA. The incoming823 engine,
598 editor and974 macro runs were independently recounted. Excluding incoming's
11-case header variant and16 shared-Studio cases leaves2,368 retained executions;
the13-case closure yields2,381. Incoming strict analysis/formatting at6045998d
retains30 exact Word paths, including all seven production libraries. The changed
header test has its own fresh analysis/format result.
[Accepted summary](accepted-summary.json) · [Incoming audit](incoming-evidence-audit.json)

The eight unchanged exclusions belong to
`word_incremental_layout_equivalence_test.dart`, with the exact reason
`no paragraphs to edit`. Their complete names and source paths are in the accepted
summary and canonical case export; none is counted as a pass.

## Evidence and limits

The deterministic `local-qualification.tar.gz` contains the fresh raw reporter
events, case identities, exact commands, source/runtime seals, independent reviews,
incoming/canonical identity exports and scripts. `archive-manifest.json` hashes
each member; `SHA256SUMS` covers the outer readable records and archive. The three
incoming archives remain in [their original preserved package](../zotero-vertical-tables-20261120/README.md),
with hashes and source attribution recorded here. SDKs, caches and build outputs
are excluded.

Incoming archives record a stable package-config hash and locked runtime versions,
but not that configuration's bytes or a full external-dependency inventory. One
unavailable old Mail blob is explicitly excluded; every selected Word/parser/
fixture input was Git-bound. The16 incoming shared-Studio cases are historical
because the reconciled Mail implementation differs. These boundaries are preserved
in the independent review rather than treated as fresh final-source executions.

Fresh execution used Dart3.14.1, the pinned package:test runner and Dart3.13.7's
formatter. Exact historical scripts retain their original session paths; the final
auditor also checks live SDK bytes. They require path/runtime adaptation rather
than running unchanged from an extracted archive. Commands/cwd are in the fresh
receipt. Reproduction needs the pinned runtime and matching ignored package
configuration. No GitHub Actions were awaited
or used. The earlier successful, failed and interrupted records remain unchanged;
this follow-up does not claim installed Word/Zotero acceptance or broader VBA/COM
support. [PR #278](https://github.com/CrispStrobe/quds_office_suite/pull/278) tracks
the final integration; merge and remote readback are recorded there when completed.
'''
# Keep prose readable without modifying the frozen input records.
for old, new in [('all13', 'all 13'), ('incoming\'s11', "incoming's 11"),
                 ('complete13', 'complete 13'), ('their197', 'their 197'),
                 ('and6 ', 'and 6 '), ('/69-suite', '/ 69-suite'),
                 ('at520', 'at 520'), ('+13 ', '+ 13 '), ('+8 ', '+ 8 '),
                 (';16 ', '; 16 '), (';203 ', '; 203 '), ('/68files', '/ 68 files'),
                 ('/70files', '/ 70 files'), ('the203', 'the 203'),
                 ('incoming823', 'incoming 823'), ('and974', 'and 974'),
                 ('and16', 'and 16'), ('leaves2,368', 'leaves 2,368'),
                 ('the13', 'the 13'), ('yields2,381', 'yields 2,381'),
                 ('at604', 'at 604'), ('retains30', 'retains 30'),
                 ('The16', 'The 16'), ('Dart3.', 'Dart 3.')]:
    README = README.replace(old, new)

outer = {
    'README.md': README.encode(),
    'accepted-summary.json': encoded(summary),
    'fresh-qualification.json': (RECEIPT / 'qualification.json').read_bytes(),
    'incoming-evidence-audit.json': audit_path.read_bytes(),
    'incoming-retention-ledger.json': ledger_path.read_bytes(),
    'source-resolution.json': (RUNTIME / 'pr277-word-resolution.json').read_bytes(),
    'independent-review.json': args.review.read_bytes(),
}
members = {f'fresh/{p.name}': p.read_bytes() for p in RECEIPT.iterdir() if p.is_file()}
members.update({f'review/{name}': data for name, data in outer.items()})
members.update({f'cases/{name}': data for name, data in accepted_exports.items()})
for name in ledger['case_exports']:
    members[f'cases/{name}'] = (RUNTIME / name).read_bytes()
members['cases/pr277-incoming-word-cases.json'] = (RUNTIME / 'pr277-incoming-word-cases.json').read_bytes()
members['historical/word-bridge-cases.json'] = (RUNTIME / 'word-late-main-qualification/word-bridge-cases.json').read_bytes()
for name in ('qualify_pr277_word_followup.py', 'package_pr277_word_followup.py',
             'audit_pr277_word_evidence.py', 'build_pr277_word_retention_ledger.py',
             'audit_pr277_word_followup.py'):
    members[f'scripts/{name}'] = (RUNTIME / name).read_bytes()
index = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())}
members['MANIFEST.json'] = encoded(index)


def build_archive():
    buffer = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=buffer, compresslevel=9, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                archive.addfile(info, io.BytesIO(data))
    return buffer.getvalue()


archive = build_archive()
assert archive == build_archive(), 'Archive must rebuild deterministically'
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as check:
    assert set(check.getnames()) == set(members)
    for name, expected in members.items():
        assert check.extractfile(name).read() == expected
outer['local-qualification.tar.gz'] = archive
outer['archive-manifest.json'] = encoded({
    'archive': 'local-qualification.tar.gz', 'bytes': len(archive), 'sha256': sha(archive),
    'members': len(members), 'member_sha256': index,
    'internal_manifest': 'MANIFEST.json',
    'internal_manifest_sha256': sha(members['MANIFEST.json']),
    'deterministic_rebuild_equal': True,
})
outer['SHA256SUMS'] = ''.join(f'{sha(data)}  {name}\n' for name, data in sorted(outer.items())).encode()
OUT.mkdir(exist_ok=False)
for name, data in outer.items():
    (OUT / name).write_bytes(data)
print(json.dumps({'package': str(OUT), 'files': len(outer), 'bytes': sum(map(len, outer.values())),
                  'archive_bytes': len(archive), 'archive_members': len(members), 'archive_sha256': sha(archive),
                  'canonical': population(canonical), 'actual': population(actual)}, indent=2))
