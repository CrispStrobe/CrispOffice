# Source before independent consumer qualification.
export QUALIFICATION_CONSUMER_PYTHON=/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3
export CONSUMER_ROOT=/workspace/scratch/3cddf06175f0/consumer-qualification
export CONSUMER_SCHEMAS=/workspace/scratch/3cddf06175f0/consumer-qualification/schemas
export TMPDIR=/workspace/scratch/3cddf06175f0/consumer-qualification/tmp
export XDG_CONFIG_HOME=/workspace/scratch/3cddf06175f0/consumer-qualification/config
export PYTHONDONTWRITEBYTECODE=1
export CI=true DART_SUPPRESS_ANALYTICS=true FLUTTER_SUPPRESS_ANALYTICS=true
