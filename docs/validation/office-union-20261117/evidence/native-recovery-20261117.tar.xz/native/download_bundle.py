import hashlib, json, pathlib, urllib.request, concurrent.futures, time
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root.parent/'runtime-recovery/native/model-download-verification.json').read_text())
dest=root/'proofbird'
dest.mkdir(exist_ok=True)
def one(row):
 p=dest/row['file']
 if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
  temp=p.with_name(p.name+'.partial')
  with urllib.request.urlopen(row['url'],timeout=90) as src, temp.open('wb') as out:
   while block:=src.read(2**20): out.write(block)
  assert temp.stat().st_size==row['size'], row
  assert hashlib.sha256(temp.read_bytes()).hexdigest()==row['sha256'], row
  temp.rename(p)
 print(row['file'],p.stat().st_size,row['sha256'],flush=True)
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 rows=list(pool.map(one, manifest['manifest']))
(root/'model-download-verification.json').write_text(json.dumps({'revision':manifest['revision'],'manifest':rows},indent=2)+'\n')
