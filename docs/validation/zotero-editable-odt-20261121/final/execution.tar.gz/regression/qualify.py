from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import subprocess, hashlib, json, datetime, time, os
ROOT=Path('/workspace/scratch/78195b33b741')
REPO=ROOT/'quds_office_suite'
OUT=ROOT/'zotero-final-validation'
RUNTIME=ROOT/'zotero-runtime'
ENGINE=[
 'test/odt_document_reader_test.dart',
 'test/odt_merged_table_zotero_test.dart',
 'test/odt_libreoffice_fixture_test.dart',
 'test/odf_zotero_ownership_test.dart',
 'test/odf_zotero_resource_test.dart',
 'test/word_table_vertical_merge_layout_test.dart',
 'test/word_zotero_note_tables_integration_test.dart',
 'test/word_zotero_nested_tables_integration_test.dart',
 'test/odt_zotero_writer_test.dart',
 'test/odt_zotero_export_lifecycle_test.dart',
 'test/odt_document_writer_test.dart',
 'test/word_zotero_document_data_test.dart',
 'test/odt_note_fidelity_test.dart',
 'test/odt_section_fidelity_test.dart',
 'test/word_note_numbering_test.dart',
 'test/word_zotero_transfer_test.dart',
 'test/word_zotero_transfer_session_test.dart',
 'test/zotero_transfer_protocol_test.dart',
]
EDITOR=[
 'test/word_odt_load_test.dart',
 'test/word_odt_merged_table_load_test.dart',
 'test/word_zotero_vertical_table_controller_test.dart',
 'test/word_zotero_citing_controller_test.dart',
]
ANALYSIS=[
 'packages/quds_office_engine/lib/src/word/serial/odt_document_reader.dart',
 'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart',
 'packages/quds_office_engine/lib/src/word/serial/odt_writer_zotero.dart',
 'packages/quds_office_engine/lib/src/word/model/word_zotero_data.dart',
 'packages/quds_office_engine/test/odt_document_reader_test.dart',
 'packages/quds_office_engine/test/odt_zotero_writer_test.dart',
 'packages/quds_office_engine/test/odt_zotero_export_lifecycle_test.dart',
 'packages/quds_office_engine/tool/zotero/odt_export_acceptance.dart',
]
assert len(ENGINE)==len(set(ENGINE))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snapshot(name):
 paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','packages/quds_office_engine/lib','packages/quds_office_editor/lib','packages/quds_office_engine/tool/zotero',':(glob)**/pubspec.yaml',':(glob)**/pubspec.lock','pubspec.yaml','pubspec.lock'],cwd=REPO,text=True).splitlines()
 paths += ['packages/quds_office_engine/'+p for p in ENGINE]+['packages/quds_office_editor/'+p for p in EDITOR]
 paths += ['.dart_tool/package_config.json']
 rows=[{'path':p,'sha256':sha(REPO/p),'bytes':(REPO/p).stat().st_size} for p in sorted(set(paths)) if (REPO/p).is_file()]
 result={'captured_at_utc':utc(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'files':rows}
 (OUT/name).write_text(json.dumps(result,indent=2)+'\n')
 return result
before=snapshot('source-before.json')
receipt={'started_at_utc':utc(),'source_before':'source-before.json','runtime_receipt':str(RUNTIME/'runtime.json'),'runtime_receipt_sha256':sha(RUNTIME/'runtime.json'),'hosted_archive_receipt_sha256':sha(RUNTIME/'pub-cache-receipt.json'),'engine_paths':ENGINE,'editor_paths':EDITOR,'analysis_paths':ANALYSIS,'runs':[],'status':'running'}
def save():(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(name,args,cwd,json_reporter=False):
 started=utc();clock=time.monotonic();output=OUT/(name+('.jsonl' if json_reporter else '.log'));errors=OUT/(name+'.stderr')
 print('START '+name,flush=True)
 with output.open('wb') as stdout,errors.open('wb') as stderr:
  try:
   result=subprocess.run(args,cwd=cwd,stdout=stdout,stderr=stderr,timeout=360)
   code=result.returncode
  except subprocess.TimeoutExpired:code=124
 entry={'name':name,'argv':args,'cwd':str(cwd),'started_at_utc':started,'finished_at_utc':utc(),'wall_seconds':round(time.monotonic()-clock,3),'exit_code':code,'stdout':output.name,'stdout_sha256':sha(output),'stderr':errors.name,'stderr_sha256':sha(errors)}
 if json_reporter:
  events=[];bad=[]
  for line in output.read_text(errors='replace').splitlines():
   try:events.append(json.loads(line))
   except json.JSONDecodeError:bad.append(line)
  done=[e for e in events if e.get('type')=='testDone' and not e.get('hidden')]
  entry['tests']={'passed':sum(e['result']=='success' and not e.get('skipped') for e in done),'failed':sum(e['result']!='success' for e in done),'skipped':sum(bool(e.get('skipped')) for e in done),'completion':next((e for e in reversed(events) if e.get('type')=='done'),None),'errors':[e for e in events if e.get('type')=='error'],'non_json_lines':bad}
 print('END '+name+' '+json.dumps({'exit_code':code,'wall_seconds':entry['wall_seconds'],'tests':{k:v for k,v in entry.get('tests',{}).items() if k in ['passed','failed','skipped']}}),flush=True)
 return entry
save()
format_result=run('format',['dart','format','--output=none','--set-exit-if-changed',*ANALYSIS],REPO)
receipt['runs'].append(format_result);save()
jobs=[
 ('analyze',['dart','analyze','--fatal-infos',*ANALYSIS],REPO,False),
 ('engine',['dart','--packages='+str(REPO/'.dart_tool/package_config.json'),str(RUNTIME/'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),'--reporter','json',*ENGINE],REPO/'packages/quds_office_engine',True),
 ('editor',['flutter','test','--no-pub','--reporter','json',*EDITOR],REPO/'packages/quds_office_editor',True),
]
with ThreadPoolExecutor(max_workers=3) as pool:
 futures=[pool.submit(run,*job) for job in jobs]
 for future in as_completed(futures):
  receipt['runs'].append(future.result());save()
after=snapshot('source-after.json');first={r['path']:r for r in before['files']};last={r['path']:r for r in after['files']}
receipt['source_changes']=[{'path':p,'before':first.get(p),'after':last.get(p)} for p in sorted(first.keys()|last.keys()) if first.get(p)!=last.get(p)]
receipt['source_files']=len(before['files']);receipt['source_after']='source-after.json';receipt['finished_at_utc']=utc()
receipt['status']='passed' if not receipt['source_changes'] and all(r['exit_code']==0 for r in receipt['runs']) else 'failed'
save()
print(json.dumps({'status':receipt['status'],'source_files':receipt['source_files'],'source_changes':[x['path'] for x in receipt['source_changes']],'receipt':str(OUT/'receipt.json')}),flush=True)
