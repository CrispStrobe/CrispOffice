# Final Zotero ODT qualification

The final source passed the scoped local gates under verified Flutter 3.47.8 / Dart 3.13.7 and locked official package dependencies. No GitHub Actions were used.

| Gate | Result |
| --- | --- |
| Engine: 18 unique suites | 513 passed; 0 failed; 0 skipped |
| Editor: 4 suites | 93 passed; 0 failed; 0 skipped |
| Fatal-info analysis | No issues |
| Formatting | 8 files; 0 changes |
| Source binding | 534 inputs captured before/after; 0 differences |

`receipt.json` contains exact argument arrays, working directories, timestamps, durations, output hashes, suite paths and completion events. The before/after manifests include all tracked and newly created engine/editor library files, the selected tests, Zotero tooling, workspace dependency manifests/locks and the generated package configuration. Runtime/dependency receipt hashes identify the verified setup.

The Studio UI suite and real LibreOffice consumer gate are owned by the parent task and are not counted here.

## Exact commands

All commands inherit `/workspace/scratch/78195b33b741/zotero-runtime/env.sh`.

### format

Working directory: `/workspace/scratch/78195b33b741/quds_office_suite`. Exit: 0. Wall time: 0.315 seconds.

```bash
dart format --output=none --set-exit-if-changed packages/quds_office_engine/lib/src/word/serial/odt_document_reader.dart packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart packages/quds_office_engine/lib/src/word/serial/odt_writer_zotero.dart packages/quds_office_engine/lib/src/word/model/word_zotero_data.dart packages/quds_office_engine/test/odt_document_reader_test.dart packages/quds_office_engine/test/odt_zotero_writer_test.dart packages/quds_office_engine/test/odt_zotero_export_lifecycle_test.dart packages/quds_office_engine/tool/zotero/odt_export_acceptance.dart
```

### analyze

Working directory: `/workspace/scratch/78195b33b741/quds_office_suite`. Exit: 0. Wall time: 9.231 seconds.

```bash
dart analyze --fatal-infos packages/quds_office_engine/lib/src/word/serial/odt_document_reader.dart packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart packages/quds_office_engine/lib/src/word/serial/odt_writer_zotero.dart packages/quds_office_engine/lib/src/word/model/word_zotero_data.dart packages/quds_office_engine/test/odt_document_reader_test.dart packages/quds_office_engine/test/odt_zotero_writer_test.dart packages/quds_office_engine/test/odt_zotero_export_lifecycle_test.dart packages/quds_office_engine/tool/zotero/odt_export_acceptance.dart
```

### engine

Working directory: `/workspace/scratch/78195b33b741/quds_office_suite/packages/quds_office_engine`. Exit: 0. Wall time: 39.062 seconds.

```bash
dart --packages=/workspace/scratch/78195b33b741/quds_office_suite/.dart_tool/package_config.json /workspace/scratch/78195b33b741/zotero-runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart --reporter json test/odt_document_reader_test.dart test/odt_merged_table_zotero_test.dart test/odt_libreoffice_fixture_test.dart test/odf_zotero_ownership_test.dart test/odf_zotero_resource_test.dart test/word_table_vertical_merge_layout_test.dart test/word_zotero_note_tables_integration_test.dart test/word_zotero_nested_tables_integration_test.dart test/odt_zotero_writer_test.dart test/odt_zotero_export_lifecycle_test.dart test/odt_document_writer_test.dart test/word_zotero_document_data_test.dart test/odt_note_fidelity_test.dart test/odt_section_fidelity_test.dart test/word_note_numbering_test.dart test/word_zotero_transfer_test.dart test/word_zotero_transfer_session_test.dart test/zotero_transfer_protocol_test.dart
```

### editor

Working directory: `/workspace/scratch/78195b33b741/quds_office_suite/packages/quds_office_editor`. Exit: 0. Wall time: 17.023 seconds.

```bash
flutter test --no-pub --reporter json test/word_odt_load_test.dart test/word_odt_merged_table_load_test.dart test/word_zotero_vertical_table_controller_test.dart test/word_zotero_citing_controller_test.dart
```

