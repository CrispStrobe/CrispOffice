#!/usr/bin/env python3
"""Record final committed native ODT converter acceptance without source edits."""
import hashlib
import json
from pathlib import Path
import shlex
import shutil
import subprocess
import time
from datetime import datetime, timezone

REPO = Path('/workspace/scratch/78195b33b741/quds_office_suite')
ROOT = Path('/workspace/scratch/78195b33b741/zotero-converter/final')
ORIGINAL = ROOT / 'original'
ROUNDTRIP = ROOT / 'roundtrip'
PROFILE = ROOT / 'profile'
GENERATOR = REPO / 'packages/quds_office_engine/tool/zotero/odt_export_acceptance.dart'
SOFFICE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/program/soffice')
EXPECTED_COMMIT = '887207af33d3a4d71c1f2405c1be6c4d348d55e6'
EXPECTED_TREE = 'baab4d22be5d462a86ddbe42a3c69c72ce9a1764'
ENV_FILE = Path('/workspace/scratch/78195b33b741/zotero-runtime/env.sh')
RECEIPT = {
    'startedAtUtc': datetime.now(timezone.utc).isoformat(),
    'repository': str(REPO),
    'environmentCommand': f'source {shlex.quote(str(ENV_FILE))}',
    'requestedSourceCommit': EXPECTED_COMMIT,
    'expectedSourceTree': EXPECTED_TREE,
    'commands': [],
    'scope': 'Synthetic ODT export, actual LibreOffice headless open/save, then exact OdfZotero inventory verification.',
    'limitations': [
        'No installed Zotero plugin commands or live desktop integration were exercised.',
        'This is not a visual-layout comparison or proof of arbitrary document compatibility.',
        'The verifier inspects saved ODT inventory; it does not test importing converter output with OdtDocumentReader.',
    ],
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(name, argv):
    started = time.monotonic()
    result = subprocess.run(argv, cwd=REPO, capture_output=True, text=True)
    stdout = ROOT / f'{name}.stdout.log'
    stderr = ROOT / f'{name}.stderr.log'
    stdout.write_text(result.stdout)
    stderr.write_text(result.stderr)
    RECEIPT['commands'].append({
        'name': name,
        'argv': [str(arg) for arg in argv],
        'shellCommand': shlex.join([str(arg) for arg in argv]),
        'cwd': str(REPO),
        'exitCode': result.returncode,
        'durationSeconds': round(time.monotonic() - started, 3),
        'stdout': str(stdout),
        'stderr': str(stderr),
    })
    if result.returncode:
        raise RuntimeError(f'{name} failed with exit code {result.returncode}')
    return result.stdout.strip(), result.stderr.strip()


try:
    ROOT.mkdir(parents=True, exist_ok=True)
    for directory in [ORIGINAL, ROUNDTRIP]:
        directory.mkdir(parents=True, exist_ok=True)
        if any(directory.iterdir()):
            raise RuntimeError(f'Refusing stale fixture directory: {directory}')
    commit, _ = run('source-commit', ['git', 'rev-parse', 'HEAD'])
    tree, _ = run('source-tree', ['git', 'rev-parse', 'HEAD^{tree}'])
    requested_tree, _ = run('requested-source-tree', ['git', 'rev-parse', f'{EXPECTED_COMMIT}^{{tree}}'])
    if tree != EXPECTED_TREE or requested_tree != EXPECTED_TREE:
        raise RuntimeError('Committed source tree differs from the requested source')
    source_changes, _ = run('source-diff', ['git', 'diff', '--name-only', 'HEAD'])
    if source_changes:
        raise RuntimeError(f'Uncommitted tracked source changes: {source_changes}')
    generator_blob, _ = run('generator-blob', ['git', 'rev-parse', f'HEAD:{GENERATOR.relative_to(REPO)}'])
    RECEIPT['actualExecutionCommit'] = commit
    RECEIPT['actualExecutionTree'] = tree
    RECEIPT['generator'] = {'path': str(GENERATOR), 'sha256': digest(GENERATOR), 'gitBlob': generator_blob}
    RECEIPT['environmentSha256'] = digest(ENV_FILE)
    dart = shutil.which('dart')
    if dart is None:
        raise RuntimeError('Configured Dart runtime was not found')
    dart_version_out, dart_version_err = run('dart-version', [dart, '--version'])
    office_version_out, office_version_err = run('libreoffice-version', [str(SOFFICE), '--version'])
    RECEIPT['runtime'] = {
        'dart': dart,
        'dartVersion': dart_version_out or dart_version_err,
        'libreOfficeExecutable': str(SOFFICE),
        'libreOfficeVersion': office_version_out or office_version_err,
        'libreOfficeWrapperSha256': digest(SOFFICE),
        'libreOfficeBinarySha256': digest(SOFFICE.with_name('soffice.bin')),
        'profile': str(PROFILE),
    }
    generator_command = [dart, f'--packages={REPO}/.dart_tool/package_config.json', str(GENERATOR)]
    run('create', generator_command + ['create', str(ORIGINAL)])
    RECEIPT['originalFiles'] = {
        path.name: {'sha256': digest(path), 'bytes': path.stat().st_size}
        for path in sorted(ORIGINAL.iterdir()) if path.is_file()
    }
    expected = {
        name: json.loads((ORIGINAL / f'{name}.expected.json').read_text())
        for name in ['body-bibliography', 'table-notes']
    }
    RECEIPT['fixtures'] = [
        {'name': name,
         'records': len(data['fields']),
         'fieldKinds': [field['kind'] for field in data['fields']],
         'stories': [field['story'] for field in data['fields']],
         'tableOwnerCounts': [field['tableOwners'] for field in data['fields']]}
        for name, data in expected.items()
    ]
    RECEIPT['totalRecords'] = sum(fixture['records'] for fixture in RECEIPT['fixtures'])
    if len(expected) != 2 or RECEIPT['totalRecords'] != 7:
        raise RuntimeError('Unexpected fixture or record count')
    run('libreoffice-convert', [
        str(SOFFICE), f'-env:UserInstallation={PROFILE.as_uri()}',
        '--headless', '--convert-to', 'odt:writer8', '--outdir', str(ROUNDTRIP),
        str(ORIGINAL / 'body-bibliography.odt'), str(ORIGINAL / 'table-notes.odt'),
    ])
    RECEIPT['roundtripFiles'] = {
        path.name: {'sha256': digest(path), 'bytes': path.stat().st_size}
        for path in sorted(ROUNDTRIP.glob('*.odt'))
    }
    run('verify', generator_command + ['verify', str(ROUNDTRIP), str(ORIGINAL)])
    for name, before in RECEIPT['originalFiles'].items():
        if digest(ORIGINAL / name) != before['sha256']:
            raise RuntimeError(f'Original fixture changed during conversion: {name}')
    RECEIPT['originalFilesUnchanged'] = True
    tree_after, _ = run('source-tree-after', ['git', 'rev-parse', 'HEAD^{tree}'])
    source_changes_after, _ = run('source-diff-after', ['git', 'diff', '--name-only', 'HEAD'])
    if tree_after != EXPECTED_TREE or source_changes_after or digest(GENERATOR) != RECEIPT['generator']['sha256']:
        raise RuntimeError('Source changed during acceptance run')
    RECEIPT['sourceTreeAfter'] = tree_after
    RECEIPT['verifiedProperties'] = [
        'No inventory issues; all fields are native import candidates.',
        'ReferenceMark document preferences match exactly, including unknown Unicode metadata.',
        'Field order, full field names, kinds, storage, metadata, cached text, and paragraph text lists match exactly.',
        'Start story and count of table-cell ancestors match exactly.',
    ]
    RECEIPT['result'] = 'PASS'
except Exception as error:
    RECEIPT['result'] = 'FAIL'
    RECEIPT['error'] = str(error)
    raise
finally:
    RECEIPT['finishedAtUtc'] = datetime.now(timezone.utc).isoformat()
    (ROOT / 'receipt.json').write_text(json.dumps(RECEIPT, indent=2, ensure_ascii=False) + '\n')
    (ROOT / 'commands.txt').write_text(
        RECEIPT['environmentCommand'] + '\n' +
        '\n'.join(command['shellCommand'] for command in RECEIPT['commands']) + '\n'
    )
    print(json.dumps({key: RECEIPT.get(key) for key in ['result', 'actualExecutionCommit', 'actualExecutionTree', 'totalRecords', 'error']}))
