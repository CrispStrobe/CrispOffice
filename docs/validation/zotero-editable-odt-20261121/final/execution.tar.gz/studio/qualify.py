from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib,json,subprocess,datetime,time,shlex
ROOT=Path('/workspace/scratch/78195b33b741');REPO=ROOT/'quds_office_suite';OUT=ROOT/'zotero-final-studio-validation';RUNTIME=ROOT/'zotero-runtime'
TESTS=['test/studio_zotero_odt_export_test.dart','test/studio_odt_open_test.dart','test/studio_zotero_shortcuts_test.dart','test/studio_mail_web_test.dart']
UI=['lib/studio_files.dart','lib/suite_workspace.dart','lib/studio_mail_web.dart','lib/studio_saved_mail.dart']
EXPECTED_HEAD='887207af33d3a4d71c1f2405c1be6c4d348d55e6';EXPECTED_TREE='baab4d22be5d462a86ddbe42a3c69c72ce9a1764'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot(name):
 paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard',':(glob)packages/**/lib/**','packages/quds_office_editor/example/test/support',':(glob)**/pubspec.yaml',':(glob)**/pubspec.lock','pubspec.yaml','pubspec.lock'],cwd=REPO,text=True).splitlines()
 paths += ['packages/quds_office_editor/example/'+p for p in TESTS]+['.dart_tool/package_config.json']
 rows=[{'path':p,'sha256':sha(REPO/p),'bytes':(REPO/p).stat().st_size} for p in sorted(set(paths)) if (REPO/p).is_file()]
 refs=subprocess.check_output(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=REPO,text=True).splitlines()
 r={'captured_at_utc':utc(),'head':refs[0],'tree':refs[1],'files':rows}
 (OUT/name).write_text(json.dumps(r,indent=2)+'\n');return r
before=snapshot('source-before.json')
if before['head']!=EXPECTED_HEAD or before['tree']!=EXPECTED_TREE:raise RuntimeError('Unexpected initial source identity')
receipt={'status':'running','started_at_utc':utc(),'initial_source_commit':EXPECTED_HEAD,'initial_source_tree':EXPECTED_TREE,'test_paths':TESTS,'analysis_paths':UI+TESTS,'runtime_receipt':str(RUNTIME/'runtime.json'),'runtime_receipt_sha256':sha(RUNTIME/'runtime.json'),'runs':[]}
def save():(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(name,args,json_reporter=False):
 out=OUT/(name+('.jsonl' if json_reporter else '.log'));err=OUT/(name+'.stderr');started=utc();clock=time.monotonic();cwd=REPO/'packages/quds_office_editor/example'
 print('START '+name,flush=True)
 with out.open('wb') as so,err.open('wb') as se:
  try:code=subprocess.run(args,cwd=cwd,stdout=so,stderr=se,timeout=360).returncode
  except subprocess.TimeoutExpired:code=124
 r={'name':name,'argv':args,'cwd':str(cwd),'started_at_utc':started,'finished_at_utc':utc(),'wall_seconds':round(time.monotonic()-clock,3),'exit_code':code,'stdout':out.name,'stdout_sha256':sha(out),'stderr':err.name,'stderr_sha256':sha(err)}
 if json_reporter:
  events=[];other=[]
  for line in out.read_text(errors='replace').splitlines():
   try:events.append(json.loads(line))
   except json.JSONDecodeError:other.append(line)
  done=[e for e in events if e.get('type')=='testDone' and not e.get('hidden')]
  r['tests']={'passed':sum(e['result']=='success' and not e.get('skipped') for e in done),'failed':sum(e['result']!='success' for e in done),'skipped':sum(bool(e.get('skipped')) for e in done),'completion':next((e for e in reversed(events) if e.get('type')=='done'),None),'errors':[e for e in events if e.get('type')=='error'],'non_json_lines':other}
 print('END '+name+' '+json.dumps({'exit_code':code,'tests':{k:v for k,v in r.get('tests',{}).items() if k in ['passed','failed','skipped']}}),flush=True);return r
save()
with ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,'studio',['flutter','test','--no-pub','--reporter','json',*TESTS],True),pool.submit(run,'analyze',['dart','analyze','--fatal-infos',*UI,*TESTS])]
 for f in as_completed(futures):receipt['runs'].append(f.result());save()
after=snapshot('source-after.json');b={x['path']:x for x in before['files']};a={x['path']:x for x in after['files']}
receipt['source_files']=len(before['files']);receipt['source_changes']=[{'path':p,'before':b.get(p),'after':a.get(p)} for p in sorted(b.keys()|a.keys()) if b.get(p)!=a.get(p)]
receipt['head_after']=after['head'];receipt['tree_after']=after['tree'];receipt['finished_at_utc']=utc()
receipt['status']='passed' if not receipt['source_changes'] and all(x['exit_code']==0 for x in receipt['runs']) else 'failed';save()
print(json.dumps({'status':receipt['status'],'source_files':receipt['source_files'],'source_changes':[x['path'] for x in receipt['source_changes']],'head_after':after['head'],'tree_after':after['tree']}),flush=True)
lines=['# Final committed Studio qualification','','Initial source commit: `'+EXPECTED_HEAD+'`; tree: `'+EXPECTED_TREE+'`.','','`receipt.json` records actual results and exact commands. The source manifests cover all workspace package library sources (including engine, editor, Studio and Mail dependencies), selected tests and support, dependency manifests/locks, and package configuration. There were no source edits in this task.','']
for x in receipt['runs']:
 lines+=['## '+x['name'],'','Exit '+str(x['exit_code'])+'; '+str(x['wall_seconds'])+' seconds.','']
 if 'tests' in x:lines += ['Observed tests: '+json.dumps(x['tests'])+'.','']
 lines+=['```bash','cd '+shlex.quote(x['cwd']),shlex.join(x['argv']),'```','']
lines+=['Captured inputs: '+str(receipt['source_files'])+'; changed inputs: '+str(len(receipt['source_changes']))+'.','']
(OUT/'README.md').write_text('\n'.join(lines))
