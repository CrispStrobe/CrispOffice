# Final committed Studio qualification

Initial source commit: `887207af33d3a4d71c1f2405c1be6c4d348d55e6`; tree: `baab4d22be5d462a86ddbe42a3c69c72ce9a1764`.

`receipt.json` records actual results and exact commands. The source manifests cover all workspace package library sources (including engine, editor, Studio and Mail dependencies), selected tests and support, dependency manifests/locks, and package configuration. There were no source edits in this task.

## analyze

Exit 0; 24.904 seconds.

```bash
cd /workspace/scratch/78195b33b741/quds_office_suite/packages/quds_office_editor/example
dart analyze --fatal-infos lib/studio_files.dart lib/suite_workspace.dart lib/studio_mail_web.dart lib/studio_saved_mail.dart test/studio_zotero_odt_export_test.dart test/studio_odt_open_test.dart test/studio_zotero_shortcuts_test.dart test/studio_mail_web_test.dart
```

## studio

Exit 0; 43.206 seconds.

Observed tests: {"passed": 25, "failed": 0, "skipped": 0, "completion": {"success": true, "type": "done", "time": 41292}, "errors": [], "non_json_lines": []}.

```bash
cd /workspace/scratch/78195b33b741/quds_office_suite/packages/quds_office_editor/example
flutter test --no-pub --reporter json test/studio_zotero_odt_export_test.dart test/studio_odt_open_test.dart test/studio_zotero_shortcuts_test.dart test/studio_mail_web_test.dart
```

Captured inputs: 916; changed inputs: 0.
