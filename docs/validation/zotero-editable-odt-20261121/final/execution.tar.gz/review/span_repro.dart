import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
Future<void> main() async {
 final citation=ZoteroCitation.fromJson({'citationID':'span-three','citationItems':[{'id':'http://zotero.org/users/42/items/ABCD1234','uris':['http://zotero.org/users/42/items/ABCD1234'],'itemData':{'id':1,'type':'book','title':'Book'}}],'properties':{'plainCitation':'(X)','noteIndex':0}});
 final paragraph=WmlParagraph(inlines:[WmlRun(text:'(X)',fieldInstruction:citation.fieldInstruction)]);
 final document=WmlDocument(sections:[WmlSection(blocks:[WmlTable(grid:[60,60,60],rows:[WmlTableRow(cells:[WmlTableCell(gridSpan:3,blocks:[paragraph])])])])],zoteroDocumentData:jsonEncode({'dataVersion':4,'style':{'styleID':'http://www.zotero.org/styles/apa'},'prefs':{'fieldType':'Field','noteType':0}}));
 final bytes=OdtDocumentWriter.writeEditableZoteroBytes(document);
 print('exported ${bytes.length} bytes');
 print(utf8.decode(ZipReader.fromBytes(bytes).read('content.xml')));
 try { final reread=await OdtDocumentReader.readBytes(bytes); print('reopened fields ${WordZotero.fields(reread).length}'); } catch(e) {print('REOPEN ERROR: $e');}
}
