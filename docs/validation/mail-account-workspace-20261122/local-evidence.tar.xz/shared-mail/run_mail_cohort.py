from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

root = Path('/workspace/scratch/7fc035b3e3ba/quds_office_suite')
output = Path(__file__).parent
name, package, *command = sys.argv[1:]
working = root / 'packages' / package


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=root, text=True).strip()


paths = git('ls-files', '--',
    'packages/quds_mail_core',
    'packages/quds_mail_mime',
    'packages/quds_mail_store',
    'packages/quds_mail_transport',
    'packages/quds_mail_ui',
    'third_party/enough_mail',
    'pubspec.yaml', 'pubspec.lock', '.fvmrc', 'analysis_options.yaml',
).splitlines()
paths.append('.dart_tool/package_config.json')


def snapshot():
    return {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in paths}


before = snapshot()
(output / f'{name}-source-before.json').write_text(json.dumps(before, indent=2) + '\n')
stdout = output / f'{name}-tests.jsonl'
stderr = output / f'{name}-stderr.log'
receipt = {
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head_at_start': git('rev-parse', 'HEAD'),
    'source_files': len(before),
    'source_manifest_sha256': hashlib.sha256((output / f'{name}-source-before.json').read_bytes()).hexdigest(),
    'command': command,
    'cwd': str(working),
    'environment': {key: os.environ.get(key) for key in ['CI', 'FLUTTER_ROOT', 'PUB_CACHE', 'TMPDIR', 'DART_SUPPRESS_ANALYTICS', 'FLUTTER_SUPPRESS_ANALYTICS']},
    'stdout': stdout.name,
    'stderr': stderr.name,
}
with stdout.open('w') as out, stderr.open('w') as err:
    result = subprocess.run(command, cwd=working, stdout=out, stderr=err)
receipt['exit_code'] = result.returncode
receipt['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
after = snapshot()
(output / f'{name}-source-after.json').write_text(json.dumps(after, indent=2) + '\n')
receipt['source_unchanged'] = before == after
receipt['changed_inputs'] = [path for path in before if before[path] != after.get(path)]
starts = {}
cases = []
errors = []
done = None
suites = {}
for line in stdout.read_text().splitlines():
    try:
        item = json.loads(line)
    except json.JSONDecodeError:
        continue
    if item['type'] == 'suite':
        suites[item['suite']['id']] = item['suite']
    if item['type'] == 'testStart':
        starts[item['test']['id']] = item['test']
    if item['type'] == 'error':
        errors.append(item)
    if item['type'] == 'testDone':
        test = starts[item['testID']]
        if item.get('hidden') or test['name'].endswith('(setUpAll)') or test['name'].endswith('(tearDownAll)'):
            continue
        cases.append({'id': item['testID'], 'suiteID': test['suiteID'], 'suite': suites[test['suiteID']]['path'], 'name': test['name'], 'result': item['result'], 'skipped': item['skipped']})
    if item['type'] == 'done':
        done = item
receipt['suites'] = list(suites.values())
receipt['results'] = {
    'passed': sum(item['result'] == 'success' and not item['skipped'] for item in cases),
    'failed': sum(item['result'] != 'success' and not item['skipped'] for item in cases),
    'skipped': sum(item['skipped'] for item in cases),
    'reporter_errors': errors,
    'reporter_done': done,
}
(output / f'{name}-test-cases.json').write_text(json.dumps(cases, indent=2) + '\n')
(output / f'{name}-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'name': name, 'source_files': len(before), 'source_unchanged': receipt['source_unchanged'], 'results': receipt['results'], 'exit_code': result.returncode}), flush=True)
