# Main b4f1150b delta audit

Read-only inspection compared exact main `b4f1150b18348f348489c93108158a397c922abe` with integrated main `4cc604810fb2f41ac7ba04cbed65cb76300bff59` and frozen working-source commit `8403ddfd202637e1ebe7c4350d5e765347ef7023`. No source/ref mutations, CI queries or test executions were performed for this audit.

The incoming merge is PR #383, with parents `4cc604810fb2f41ac7ba04cbed65cb76300bff59` and `23a934cf49f64cd61f0df3ad3cdd7d9bd4a069dd`. The delta has **83 files: 70 documentation/evidence files, 5 production Dart files, 6 Dart test/helper files and 2 changelogs**. It changes no dependency manifest, lockfile, SDK pin, Mail core/store/transport/shared-UI file, or VBA compiler source relative to 4cc.

## Exact source overlap

- `studio_mail_account_navigation.dart`: compared with frozen 8403, only its explicit-port explanatory comment differs. The port and last-connected-time validation behavior is already present.
- `studio_mail_account_navigation_strings.dart`: the same release-failure translation getter moves within the file; its text is identical.
- `studio_mail_account_navigation_test.dart`: byte-identical to frozen 8403, Git blob `48cc1306329ee6baefaaaa81c83e87df70684226`.
- `studio_mail_ews.dart` and `studio_mail_native.dart`: incoming lifecycle variants overlap substantial already-integrated work. Taking either whole incoming file would remove the frozen failed-observer latches, observation generations, ordinary-Disconnect draining and retained cleanup behavior. EWS would also lose the 8403 connection-bound toolbar/Refresh/More callback fences. Preserve those newer guards while reviewing candidate-adoption/selection checks individually.
- The incoming native-release test has no unique test declaration relative to frozen 8403; it omits frozen ordinary Disconnect/Refresh observer-release regressions. Native/provider test variants include renamed or revised owner-release cases; preserve the frozen cases and merge any distinct behavioral assertions rather than replace the files wholesale.

## Genuine new engine behavior

`word_zotero.dart` adds `_resultBaseProperties`, which removes instruction-side empty code runs from the temporary view used to select visible result formatting. Citation and bibliography refresh/unlink now use cached-result or surrounding text styles, including a neighboring empty citation, instead of inheriting inert instruction-only formatting. Seven call sites change to the helper. This production file was identical between 4cc and frozen 8403, so this is a new input requiring qualification.

The boundary test adds **nine concrete style-exclusion cases**: four citation update/unlink actions, two bibliography actions, existing-cache styling, following-context fallback and adjacent empty citations. Preserve these together with the five marker/mixed-run revision cases and three-cycle opaque-history checks already added on our branch.

The converter snapshot helper improves its expected-text override: require exactly one golden citation, an explicit distinguishable cache occurring once, and perform simultaneous replacements to avoid cascading a requested replacement into another. It changes the parameter name from `refreshedCitationText` to `refreshedCitations`; the merged tests must use one coherent name. Preserve full independent expected formatting and metadata comparison.

## Qualification impact

The 1,415-input engine capture no longer wholly matches after adopting the new production/helper/test bytes. Preserve the previous 2,585-case result as prior-source evidence until the replacement gate completes. Root approved the same 52-suite engine cohort plus strict changed-file analysis/format and VM/Node portability after the merged source is frozen. The nine added cases imply 2,594 cases if every prior case remains; the reporter, not that prediction, determines the final count.

The retained 2,722 Mail cases remain candidates for exact-input carry-forward because their packages and root manifests are outside this delta; recheck their manifests on the final merged tree. Editor/Studio results must be bound to the next frozen source after Mail conflict resolution and the separately reported modal-cancel fix.

## Evidence

`connector-capture.json` contains the exact commit comparison and per-file patches. All 11 changed Dart files were fetched through the read-only GitHub connector into `incoming/<repository path>`; `blob-audit.json` verifies their bytes against GitHub's Git blob SHAs and records frozen blob/SHA-256 comparisons. `diff-from-frozen.patch` and individual `.diff` files preserve the complete comparison. The verified scratch copy of `word_zotero.dart` provides missing blob `22c3f7489d5ec6f6e07f1bc714c93a44dbfecd74` without changing the source checkout.
