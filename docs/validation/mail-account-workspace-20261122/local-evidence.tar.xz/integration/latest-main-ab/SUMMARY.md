# Latest main intake: ab3457c9

## Scope

Compared exact main `ab3457c98b6d9a0d1da8147db3048dfc50d174d3` (tree `dd3f123d8c362e8a05333bed4295ff4d8f10b10f`) with integrated main `b4f1150b18348f348489c93108158a397c922abe`, then compared engine/controller source directly with frozen branch `7c2f6e744b3489460035bbbb358d46e22e58ce20`.

Main is 16 commits ahead of b4. Its delta contains 121 files: 21 Dart source/test/tool paths, 98 documentation/evidence files, and two package changelogs. There are no dependency manifest, lockfile or SDK pin changes. The actual merge has two common ancestors: b4f1150b and 3e57fda4. No repository worktree or index edits were performed during this audit. The authorized fetch updated origin/main, and verified missing blobs were seeded only into the Git object database.

## Engine union and preservation

Nine engine Dart paths differ from frozen source: four existing production files, one new production helper, the existing converter snapshot helper, two new test files, and one new acceptance tool. The boundary-formatting test is byte-identical to frozen source. The existing editor converter-controller suite gains assertions without observed new test registrations.

- Keep ODT reader/writer border support: a bounded common solid RGB stroke, exact eighth-point widths from 0.25 to 12 pt, independent cell sides, inheritance, explicit off edges and merged ownership. Retain visible separating/mixed stroke/covered-cell ambiguity guards and editable RTL-table refusal.
- Keep Word logical cell border handling: start/end precedence, effective inherited/direct table direction, physical side mapping, inverse RTL save mapping, and namespace/direct-child ownership checks.
- Preserve the raw field-boundary revision repair. Every one of our base-relative changes in word_deserializer is already present identically in incoming source; its remaining diff is table-related.
- Preserve all five marker/mixed-run regressions, all nine instruction-side style cases, and the complete Refresh golden assertions: the entire boundary test is already identical.
- Preserve WordZotero empty-code result styling. Its Git blob is identical on both tips: 22c3f7489d5ec6f6e07f1bc714c93a44dbfecd74.
- Accept the snapshot helper's Object? cast tightening; its matching/replacement/assertion behavior is otherwise unchanged.
- Resolve only changelog ordering if necessary, retaining both new table-border entries and the raw-boundary repair entry. No substantive engine conflict is predicted; review the actual merge result.

Ten missing engine/controller blobs plus the engine changelog were obtained through exact-commit GitHub reads, verified against API hashes and the fetched tree, then seeded. Full copies, hashes and frozen-source diffs are retained beside this summary.

## Mail overlap

The incoming cached-host fixture already implements the missing delete-capability repair: enable it only in the three delete scenarios, assert the enabled action and visible/enabled confirmation, and retain all cache/non-resurrection checks. No duplicate fixture fix is needed. A separate agent owns the overlapping Mail production/test reconciliation.

## Qualification plan

The prior 2,594-case receipt remains valid for its recorded source and will not receive blanket exact-input credit after the serializer changes. Root approved a replacement 65-suite cohort: the existing 52 suites plus 13 direct table/ODT risks, listed in `../validation/final-ab-engine/prepared-plan.json`. Exact comparison from the initial 659b8146 baseline yields 39 changed engine Dart static paths, correcting the preliminary 38 estimate. Pinned read-only format runs first, followed by the two VM cohorts, strict analysis, and the existing Split corpus and Word BAS VM/Node checks. JSONL framing splits LF bytes only, preserving Unicode NEL/line/paragraph separators inside JSON strings.

The editor phase should repeat its three controller suites, including the strengthened converter-controller file. Main changes no Mail core/store/transport/shared-UI input or manifest, so the retained 2,722 passes remain candidates for exact-source rehash after the merge. Source snapshots, reporter counts and any later input equality must be verified against the final union.

The new converter acceptance tool is available for separate qualification. A soffice executable was located in the provided runtime; it has not been executed in this audit. Incoming claims of external converter acceptance are not treated as newly executed results here.

No heavy tests, analyzers or converter processes were started. Await the completed source union, reviewed Mail repair, and root's CPU handoff before executing the prepared engine gate.
