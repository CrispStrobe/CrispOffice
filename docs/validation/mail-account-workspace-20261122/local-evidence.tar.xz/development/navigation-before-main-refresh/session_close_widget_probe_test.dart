import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:quds_mail_core/quds_mail_core.dart';
import 'package:quds_office_studio/studio_mail_mailbox_session.dart';

import 'session_close_probe.dart' as probe;

void main() {
  testWidgets('root-zone cancellation completes after a real microtask turn', (tester) async {
    final store = probe.Store();
    final session = StudioMailMailboxSession(store: store, provider: MailProviderKind.ews);
    final subscription = session.changes.listen((_) {});
    final opening = session.select(probe.mailbox);
    await tester.pump();
    await opening;
    var hostCancelled = false;
    var sessionClosed = false;
    final task = () async {
      final closing = session.close();
      await subscription.cancel();
      hostCancelled = true;
      await closing;
      sessionClosed = true;
    }();
    store.cancelGate.complete();
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 350));
    await tester.pump();
    print('after fake pump: hostCancelled=$hostCancelled, sessionClosed=$sessionClosed');
    expect(hostCancelled, isFalse);
    expect(sessionClosed, isFalse);
    await tester.runAsync(() async => Future<void>.delayed(Duration.zero));
    await tester.pump();
    await task;
    expect(hostCancelled, isTrue);
    expect(sessionClosed, isTrue);
    print('after real microtask turn: hostCancelled=$hostCancelled, sessionClosed=$sessionClosed');
  });
}
