import 'dart:async';

import 'package:quds_mail_core/quds_mail_core.dart';
import 'package:quds_mail_store/quds_mail_store.dart';
import 'package:quds_office_studio/studio_mail_mailbox_session.dart';
import 'package:quds_office_studio/studio_mail_mailbox_store.dart';

final account = MailAccountId('probe', profile: MailProfileId('probe', hostId: 'probe'));
final mailbox = MailMailboxId('inbox', account: account);

final class Store implements StudioMailMailboxStore, StudioMailMailboxWatchStore {
  @override
  MailAccountId get account => mailbox.account;
  final cancelGate = Completer<void>();

  @override
  Stream<MailResult<MailCachedMailboxView?>> watchView(MailMailboxId mailbox) {
    late final StreamController<MailResult<MailCachedMailboxView?>> controller;
    controller = StreamController<MailResult<MailCachedMailboxView?>>(
      onListen: () async {
        await null;
        controller.add(MailSuccess(MailCachedMailboxView(
          mailbox: MailMailbox(id: mailbox, displayName: 'Inbox'),
          revision: 1,
          capturedAt: DateTime.utc(2026),
          headers: [],
          hasMore: false,
        )));
      },
      onCancel: () async {
        print('repository cancellation started');
        await cancelGate.future;
        print('repository cancellation finished');
      },
    );
    return controller.stream;
  }

  @override
  Never noSuchMethod(Invocation invocation) => throw StateError('Unexpected call');
}

Future<void> main() async {
  final store = Store();
  final session = StudioMailMailboxSession(store: store, provider: MailProviderKind.ews);
  final subscription = session.changes.listen((snapshot) => print('snapshot ${snapshot.phase}'));
  await session.select(mailbox);
  print('selected');
  final closing = session.close();
  await subscription.cancel();
  print('host subscription cancelled');
  store.cancelGate.complete();
  await closing.timeout(const Duration(seconds: 3));
  print('session closed');
}
