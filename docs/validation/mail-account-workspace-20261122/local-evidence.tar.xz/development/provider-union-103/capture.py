import hashlib
import json
import pathlib
import re
import subprocess
import sys
from urllib.parse import unquote, urljoin, urlparse

root = pathlib.Path('/workspace/scratch/7fc035b3e3ba/quds_office_suite')
out = pathlib.Path('/workspace/scratch/7fc035b3e3ba/provider-test-merge')
config = root / '.dart_tool/package_config.json'
packages = {}
for entry in json.loads(config.read_text())['packages']:
    base = urljoin(config.as_uri(), entry['rootUri'])
    uri = urljoin(base.rstrip('/') + '/', entry.get('packageUri', 'lib/'))
    packages[entry['name']] = pathlib.Path(unquote(urlparse(uri).path))
pending = [root / 'packages/quds_office_editor/example/test/studio_mail_account_navigation_provider_test.dart']
paths = set()
while pending:
    path = pending.pop().resolve()
    if path in paths or not path.is_relative_to(root) or not path.is_file():
        continue
    paths.add(path)
    source = path.read_text()
    for statement in re.findall(r'\b(?:import|export|part)\s+[^;]+;', source):
        for uri in re.findall(r"['\"]([^'\"]+)['\"]", statement):
            if uri.startswith('dart:'):
                continue
            if uri.startswith('package:'):
                name, relative = uri[8:].split('/', 1)
                if name in packages:
                    pending.append(packages[name] / relative)
            elif ':' not in uri:
                pending.append(path.parent / uri)
tracked = subprocess.check_output(['git', 'ls-files'], cwd=root, text=True).splitlines()
for name in tracked:
    path = pathlib.Path(name)
    if path.name in {'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.fvmrc', 'build.yaml'}:
        paths.add(root / path)
paths.add(config)
manifest = {
    'label': sys.argv[1],
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'capture_kind': 'transitive local Dart imports/exports/parts plus tracked workspace manifests and package configuration',
    'files': {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths) if p.is_file()},
}
(out / f'inputs-{sys.argv[1]}.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'label': sys.argv[1], 'files': len(manifest['files']), 'head': manifest['head']}))
