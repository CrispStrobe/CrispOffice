#!/usr/bin/env python3
"""Bridge one formatter-only test change; retain VM/analysis and finish gates."""
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PRIOR = OUT.parent / 'final-b4-engine'
BASELINE = '128a49df722662c904335f6dbbc2e8990a1266db'
CHANGED = 'packages/quds_office_engine/test/word_zotero_boundary_formatting_test.dart'
spec = importlib.util.spec_from_file_location('engine_gate', OUT / 'qualify_engine.py')
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
engine.BASE = BASELINE


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    original = read(PRIOR / 'qualification.json')
    original_plan = read(PRIOR / 'plan.json')
    original_before = read(PRIOR / 'inputs-before.json')
    original_after = read(PRIOR / 'inputs-after.json')
    original_receipt_sha = sha(PRIOR / 'qualification.json')
    assert original_before == original_after and original['source_unchanged']
    assert all(value['qualified'] for value in original['cohorts'].values())
    retained = [record for record in original['commands']
                if record['name'] in ['word-vm', 'zotero-odt-vm', 'engine-analysis']]
    assert len(retained) == 3
    assert all(record['exit_code'] == 0 and record['source_unchanged'] for record in retained)
    for record in original['commands']:
        for stream in ['stdout', 'stderr']:
            assert sha(PRIOR / record[stream]) == record[stream + '_sha256']
    normalized = engine.snapshot()
    assert engine.difference(original_after, normalized) == [CHANGED]
    assert sha(OUT / 'boundary-before.dart') == original_after[CHANGED]
    assert sha(OUT / 'boundary-after.dart') == normalized[CHANGED]
    proof = read(OUT / 'ast-normalization.json')
    assert proof['qualified'] and proof['diagnostics'] == [[], []]
    assert proof['canonical_ast_equal']
    assert (proof['canonical_token_stream_including_comments_equal'] or
            proof['optional_trailing_comma_difference']['qualified'])
    assert proof['canonical_ast_to_source_equal']
    canonical = {}
    for stem in ['canonical-ast.json', 'canonical-tokens.json', 'canonical-source.dart']:
        before = OUT / ('before-' + stem)
        after = OUT / ('after-' + stem)
        if stem != 'canonical-tokens.json':
            assert before.read_bytes() == after.read_bytes()
        canonical[stem] = {'before_sha256': sha(before), 'after_sha256': sha(after),
                           'bytes_equal': before.read_bytes() == after.read_bytes()}
    bridge = {
        'qualified': True,
        'original_baseline': original['source_baseline'],
        'normalized_baseline': BASELINE,
        'changed_path': CHANGED,
        'before_sha256': original_after[CHANGED],
        'after_sha256': normalized[CHANGED],
        'all_other_scoped_inputs_identical': True,
        'production_source_identical': True,
        'description': 'The pinned formatter folds refreshedCitations map layout from three lines to one and removes its optional trailing comma. The recursive parsed AST and AST-rendered source are identical, with zero parser diagnostics. Every other token and comment is identical.',
        'only_lexical_difference': proof['optional_trailing_comma_difference'],
        'parser_package': 'analyzer 13.3.0 from the unchanged workspace lock',
        'parser_diagnostics': [[], []],
        'proof': 'ast-normalization.json',
        'proof_sha256': sha(OUT / 'ast-normalization.json'),
        'proof_script': 'compare_normalized_ast.dart',
        'proof_script_sha256': sha(OUT / 'compare_normalized_ast.dart'),
        'canonical_outputs': canonical,
        'original_input_manifest_sha256': sha(PRIOR / 'inputs-after.json'),
        'original_reporters_and_manifests_preserved': True,
        'counting': 'Retain the original 2594 VM cases once; no repeat VM or analysis execution and no count from diagnostics.',
    }
    engine.save('normalization-bridge.json', bridge)
    plan = engine.prepare()
    assert plan['static_dart_files'] == original_plan['static_dart_files']
    plan['commands'] = [command for command in plan['commands']
                        if command['kind'] != 'tests' and command['name'] != 'engine-analysis']
    assert len(plan['commands']) == 7
    plan['retained_vm_analysis_receipt'] = '../final-b4-engine/qualification.json'
    plan['normalization_bridge'] = 'normalization-bridge.json'
    plan['counting'] = 'No VM test or analyzer rerun. Complete formatting and the two VM/Node tools; retain 2594 existing cases exactly once via the explicit normalization bridge.'
    engine.save('plan.json', plan)
    print(f'{engine.now()} Normalization proof passed; starting 7 remaining commands.', flush=True)
    engine.run(plan)
    remaining = read(OUT / 'qualification.json')
    assert remaining['qualified'] and remaining['source_unchanged']
    assert remaining['substantive_vm_cases'] == 0 and remaining['vm_suites'] == 0
    engine.save('remaining-qualification.json', remaining)
    assert sha(PRIOR / 'qualification.json') == original_receipt_sha
    assert read(PRIOR / 'inputs-before.json') == original_before
    assert read(PRIOR / 'inputs-after.json') == original_after
    for record in original['commands']:
        for stream in ['stdout', 'stderr']:
            assert sha(PRIOR / record[stream]) == record[stream + '_sha256']
    count = sum(cohort['passed'] for cohort in original['cohorts'].values())
    suites = sum(cohort['suite_count'] for cohort in original['cohorts'].values())
    assert count == 2594 and suites == 52
    accepted = []
    for record in retained:
        copied = dict(record)
        copied['evidence_directory'] = '../final-b4-engine'
        for stream in ['stdout', 'stderr']:
            copied[stream] = '../final-b4-engine/' + record[stream]
        accepted.append(copied)
    accepted.extend(remaining['commands'])
    combined = {
        'schema': 'quds-engine-normalized-qualification/v1',
        'qualified': True,
        'finished_at_utc': engine.now(),
        'source_baseline': BASELINE,
        'test_and_analysis_source_baseline': original['source_baseline'],
        'head_at_end': engine.git('rev-parse', 'HEAD'),
        'source_files': len(normalized),
        'source_unchanged_during_each_gate': True,
        'original_and_normalized_input_bytes_identical': False,
        'normalization_bridge': bridge,
        'substantive_vm_cases': count,
        'vm_suites': suites,
        'cohorts': original['cohorts'],
        'commands': accepted,
        'static_dart_paths': plan['static_dart_files'],
        'portability': remaining['portability'],
        'original_vm_analysis_receipt': '../final-b4-engine/qualification.json',
        'remaining_gates_receipt': 'remaining-qualification.json',
        'original_before_manifest_sha256': sha(PRIOR / 'inputs-before.json'),
        'original_after_manifest_sha256': sha(PRIOR / 'inputs-after.json'),
        'normalized_before_manifest_sha256': sha(OUT / 'inputs-before.json'),
        'normalized_after_manifest_sha256': sha(OUT / 'inputs-after.json'),
        'github_actions_queried': False,
        'github_actions_waited': False,
        'counting': '2594 substantive VM cases counted once from the original successful VM runs. The original format failure, parser-script setup diagnostics, normalization proof and portability executions add no VM cases.',
    }
    engine.save('qualification.json', combined)
    print(json.dumps({key: combined[key] for key in ['qualified', 'substantive_vm_cases', 'vm_suites', 'source_files', 'source_unchanged_during_each_gate']}), flush=True)


if __name__ == '__main__':
    main()
