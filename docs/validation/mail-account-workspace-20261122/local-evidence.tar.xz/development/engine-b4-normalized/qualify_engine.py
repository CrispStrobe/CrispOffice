#!/usr/bin/env python3
"""Serial, unmodified-runtime intake qualification; writes only this directory."""
import argparse
import base64
import collections
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/7fc035b3e3ba/quds_office_suite')
OUT = Path(__file__).resolve().parent
ENGINE = ROOT / 'packages/quds_office_engine'
BASE = '11cfbe239a59ad1fa499e06ea628bc83cc1fe24c'
SCOPES = [
    'packages/quds_office_engine/lib', 'packages/quds_office_engine/test',
    'packages/quds_office_engine/tool', 'packages/quds_office_engine/example/macros',
    'packages/quds_office_engine/pubspec.yaml', 'packages/legacy_doc_parser/lib',
    'packages/legacy_doc_parser/pubspec.yaml', 'pubspec.yaml', 'pubspec.lock',
    '.fvmrc', 'analysis_options.yaml',
]
EXTRA = ['.dart_tool/package_config.json']
ZOTERO = [
    'word_zotero_boundary_formatting', 'word_zotero_field_recovery',
    'odt_outline_compatibility', 'word_field_span', 'word_zotero',
    'word_zotero_rich_edit', 'word_zotero_multiparagraph',
    'word_zotero_formatted_bibliography', 'word_zotero_bibliography_layout',
    'word_zotero_bibliography_style_fidelity', 'word_zotero_simple_field',
    'word_zotero_adjacent_citations', 'word_zotero_field_selection',
    'word_zotero_caret', 'word_zotero_citing', 'word_zotero_preference_flow',
    'odt_reader_styles', 'odt_reader_guards', 'odt_reader_libreoffice_defaults',
    'odt_reader_script_styles', 'odt_paragraph_properties', 'odt_zotero_writer',
    'odt_libreoffice_fixture', 'odt_imported_field_fidelity',
    'odt_zotero_export_lifecycle', 'odf_zotero_reference_marks',
    'word_extended_revision', 'word_revision_story', 'word_revision_validation',
    'inline_field_fidelity', 'wml_run_edit', 'style_cascade',
]

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def snapshot():
    names = git('ls-files', '--', *SCOPES).splitlines() + EXTRA
    return {name: sha(ROOT / name) for name in sorted(set(names))}

def difference(before, after):
    return [name for name in sorted(set(before) | set(after))
            if before.get(name) != after.get(name)]

def parse_tests(path, expected):
    starts, dones, suites, cases, errors, invalid = {}, {}, {}, [], [], []
    done = []
    for number, line in enumerate(path.read_text().splitlines(), 1):
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            invalid.append({'line': number, 'text': line})
            continue
        kind = event.get('type')
        if kind == 'suite':
            item = event['suite']; suites[item['id']] = item
        elif kind == 'testStart':
            item = event['test']
            if item['id'] in starts:
                invalid.append({'duplicate_start': item['id']})
            starts[item['id']] = item
        elif kind == 'testDone':
            ident = event['testID']
            if ident in dones:
                invalid.append({'duplicate_done': ident})
            dones[ident] = event
            item = starts.get(ident)
            if item is None:
                invalid.append({'done_without_start': ident}); continue
            if event.get('hidden') or item['name'].endswith(('(setUpAll)', '(tearDownAll)')):
                continue
            cases.append({'id': ident, 'suiteID': item['suiteID'],
                          'suite': suites[item['suiteID']]['path'],
                          'name': item['name'], 'line': item.get('line'),
                          'column': item.get('column'), 'result': event['result'],
                          'skipped': event.get('skipped', False)})
        elif kind == 'error':
            errors.append(event)
        elif kind == 'done':
            done.append(event)
    observed = [s['path'] for s in suites.values()]
    summary = {
        'passed': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
        'failed': sum(c['result'] != 'success' and not c['skipped'] for c in cases),
        'skipped': sum(c['skipped'] for c in cases),
        'substantive_cases': len(cases), 'suites': sorted(observed),
        'suite_count': len(suites), 'missing_suites': sorted(set(expected) - set(observed)),
        'unexpected_suites': sorted(set(observed) - set(expected)),
        'reporter_errors': errors, 'invalid_events': invalid,
        'unfinished_test_ids': sorted(set(starts) - set(dones)), 'reporter_done': done,
        'per_suite': dict(sorted(collections.Counter(c['suite'] for c in cases).items())),
    }
    summary['qualified'] = (
        summary['passed'] > 0 and not summary['failed'] and not summary['skipped']
        and not errors and not invalid and not summary['unfinished_test_ids']
        and not summary['missing_suites'] and not summary['unexpected_suites']
        and len(done) == 1 and done[0].get('success') is True
        and len(observed) == len(set(observed)) == len(expected)
    )
    return summary, cases

def prepare():
    old = json.loads((OUT.parent / 'word-receipt.json').read_text())
    word = old['changed_test_suites'] + old['additional_regression_suites'] + [
        'test/office_vba_split_test.dart', 'test/office_vba_word_split_cli_test.dart',
        'test/office_vba_word_split_integration_test.dart',
    ]
    zotero = [f'test/{name}_test.dart' for name in ZOTERO]
    assert len(word) == 20 and len(zotero) == 32 and len(set(word + zotero)) == 52
    for name in word + zotero:
        assert (ENGINE / name).is_file(), name
    late = git('diff', '--name-only', '659b81462224a40f50975cfbfca39f636538b836..' + BASE, '--',
               'packages/quds_office_engine').splitlines()
    static = sorted(n for n in late if n.endswith('.dart'))
    fixtures = [
        ('split-conformance', 'VBA_CONFORMANCE_BASE64',
         'test/fixtures/vba_conformance/split_v1.json',
         'tool/macros/web_vba_split_conformance.dart'),
        ('word-split-smoke', 'WORD_SPLIT_BAS_BASE64',
         'example/macros/word_split_report.bas', 'tool/macros/web_vba_word_split_smoke.dart'),
    ]
    commands = []
    for name, selected in [('word-vm', word), ('zotero-odt-vm', zotero)]:
        commands.append({'name': name, 'kind': 'tests', 'cwd': str(ENGINE),
                         'argv': ['dart', 'test', '--reporter=json', '--concurrency=2', *selected],
                         'expected_suites': selected})
    commands += [
        {'name': 'engine-analysis', 'kind': 'static', 'cwd': str(ROOT),
         'argv': ['dart', 'analyze', '--fatal-infos', *static]},
        {'name': 'engine-format', 'kind': 'static', 'cwd': str(ROOT),
         'argv': ['dart', 'format', '--output=none', '--set-exit-if-changed', *static]},
    ]
    portable = []
    for name, define, source, entry in fixtures:
        encoded = base64.b64encode((ENGINE / source).read_bytes()).decode('ascii')
        define_arg = '-D' + define + '=' + encoded
        output_js = str(OUT / (name + '.js'))
        commands += [
            {'name': name + '-vm', 'kind': 'portable-receipt', 'cwd': str(ENGINE),
             'argv': ['dart', '--packages=../../.dart_tool/package_config.json', define_arg, entry]},
            {'name': name + '-compile-js', 'kind': 'compile', 'cwd': str(ENGINE),
             'argv': ['dart', 'compile', 'js', '-O1', '--packages=../../.dart_tool/package_config.json',
                      define_arg, entry, '-o', output_js]},
            {'name': name + '-node', 'kind': 'portable-receipt', 'cwd': str(ENGINE),
             'argv': ['node', '-e', 'globalThis.self = globalThis; require(process.argv[1])', output_js]},
        ]
        portable.append({'name': name, 'fixture': source, 'fixture_sha256': sha(ENGINE / source),
                         'define': define, 'entry': entry})
    return {'prepared_at_utc': now(), 'source_baseline': BASE, 'head_at_plan': git('rev-parse', 'HEAD'),
            'word_suites': word, 'zotero_odt_suites': zotero, 'static_dart_files': static,
            'source_scopes': SCOPES, 'generated_inputs': EXTRA,
            'portable_inputs': portable, 'commands': commands,
            'runtime': json.loads((OUT.parent.parent / 'runtime-provenance.json').read_text()),
            'static_comparison_base': '659b81462224a40f50975cfbfca39f636538b836',
            'portability_comparison': 'Split corpus requires identical canonical bytes. Ordinary-jsonEncode BAS receipts require equal full canonical JSON after integral-number normalization; raw outputs remain recorded.',
            'counting': 'Unique substantive VM tests counted once; portability receipts are separate.'}

def run(plan):
    # Mail-only commits may advance HEAD, while this complete source scope stays frozen.
    assert not git('diff', '--name-only', BASE, '--', *SCOPES), 'Engine input differs from approved baseline'
    assert not git('ls-files', '--others', '--exclude-standard', '--', *SCOPES), 'Untracked engine input'
    before = snapshot()
    save('inputs-before.json', before)
    result = {'started_at_utc': now(), 'head_at_start': git('rev-parse', 'HEAD'),
              'source_baseline': BASE, 'source_files': len(before), 'commands': [],
              'cohorts': {}, 'portability': {}, 'qualified': False,
              'github_actions_queried': False, 'github_actions_waited': False}
    save('qualification.json', result)
    try:
        for spec in plan['commands']:
            name, kind = spec['name'], spec['kind']
            pause = OUT / 'PAUSE'
            if pause.exists():
                print(f'{now()} Paused before {name}; remove {pause} to continue.', flush=True)
            while pause.exists():
                time.sleep(1)
            current = snapshot()
            assert current == before, f'Source drift before {name}: {difference(before, current)}'
            print(f'{now()} Starting {name}', flush=True)
            stdout = OUT / (name + ('.jsonl' if kind == 'tests' else '.log'))
            stderr = OUT / (name + '-stderr.log')
            record = {'name': name, 'kind': kind, 'cwd': spec['cwd'], 'argv': spec['argv'],
                      'started_at_utc': now(), 'stdout': stdout.name, 'stderr': stderr.name}
            with stdout.open('w') as out, stderr.open('w') as err:
                completed = subprocess.run(spec['argv'], cwd=spec['cwd'], stdout=out, stderr=err)
            record.update({'exit_code': completed.returncode, 'finished_at_utc': now(),
                           'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr)})
            after_command = snapshot()
            record['source_unchanged'] = after_command == before
            record['changed_inputs'] = difference(before, after_command)
            if kind == 'tests':
                summary, cases = parse_tests(stdout, spec['expected_suites'])
                result['cohorts'][name] = summary
                save(name + '-cases.json', cases)
                record['test_qualified'] = summary['qualified']
            result['commands'].append(record)
            save('qualification.json', result)
            print(f'{now()} Finished {name}: exit {completed.returncode}' +
                  (f", {summary['passed']} passed, {summary['failed']} failed, {summary['skipped']} skipped"
                   if kind == 'tests' else ''), flush=True)
            assert completed.returncode == 0, f'{name} failed; inspect {stdout} and {stderr}'
            assert record['source_unchanged'], f'Source drift during {name}'
            if kind == 'tests':
                assert summary['qualified'], f'Incomplete or failing reporter lifecycle: {name}'
        for entry in plan['portable_inputs']:
            name = entry['name']
            vm = (OUT / (name + '-vm.log')).read_bytes()
            node = (OUT / (name + '-node.log')).read_bytes()
            vm_json = json.loads(vm)
            node_json = json.loads(node)
            def normalize_numbers(value):
                if type(value) is float and math.isfinite(value) and value.is_integer():
                    return int(value)
                if isinstance(value, list):
                    return [normalize_numbers(item) for item in value]
                if isinstance(value, dict):
                    return {key: normalize_numbers(item) for key, item in value.items()}
                return value
            canonical = []
            for platform, value in [('vm', vm_json), ('node', node_json)]:
                encoded = (json.dumps(normalize_numbers(value), ensure_ascii=False, sort_keys=True,
                                      separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')
                (OUT / (name + '-' + platform + '-canonical.json')).write_bytes(encoded)
                canonical.append(encoded)
            record = {'fixture': entry['fixture'], 'fixture_sha256': entry['fixture_sha256'],
                      'vm_node_bytes_equal': vm == node, 'vm_node_json_equal': vm_json == node_json,
                      'vm_sha256': hashlib.sha256(vm).hexdigest(),
                      'node_sha256': hashlib.sha256(node).hexdigest(),
                      'canonical_json_equal': canonical[0] == canonical[1],
                      'canonical_vm_sha256': hashlib.sha256(canonical[0]).hexdigest(),
                      'canonical_node_sha256': hashlib.sha256(canonical[1]).hexdigest(),
                      'raw_identity_required': name == 'split-conformance',
                      'normalization': 'JSON keys sorted; only finite integral floats are encoded as integers. All values, arrays, strings and booleans remain compared.'}
            if name == 'split-conformance':
                record.update({'adapter_count': vm_json['adapterCount'],
                               'case_count': vm_json['caseCount']})
            else:
                record['formats'] = sorted(vm_json)
            result['portability'][name] = record
            assert canonical[0] == canonical[1], f'{name} VM/Node value mismatch'
            if name == 'split-conformance':
                assert vm == node, f'{name} canonical byte mismatch'
        result['substantive_vm_cases'] = sum(c['passed'] for c in result['cohorts'].values())
        result['vm_suites'] = sum(c['suite_count'] for c in result['cohorts'].values())
        result['qualified'] = True
    except Exception as error:
        result['error'] = str(error)
        raise
    finally:
        after = snapshot()
        save('inputs-after.json', after)
        result.update({'finished_at_utc': now(), 'head_at_end': git('rev-parse', 'HEAD'),
                       'source_unchanged': before == after, 'changed_inputs': difference(before, after)})
        result['qualified'] = result['qualified'] and result['source_unchanged']
        save('qualification.json', result)
        print(json.dumps({k: result.get(k) for k in ['qualified', 'substantive_vm_cases', 'vm_suites',
                                                    'source_files', 'source_unchanged', 'error']}), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--baseline', required=True)
    args = parser.parse_args()
    BASE = git('rev-parse', args.baseline)
    plan = prepare()
    save('plan.json', plan)
    print(f"Prepared {len(plan['word_suites']) + len(plan['zotero_odt_suites'])} suites, "
          f"{len(plan['static_dart_files'])} static Dart paths, 2 portable VM/Node receipts.", flush=True)
    if args.run:
        run(plan)
