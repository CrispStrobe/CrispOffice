import 'dart:convert';
import 'dart:io';

import 'package:analyzer/dart/analysis/utilities.dart';
import 'package:analyzer/dart/ast/ast.dart';
import 'package:analyzer/dart/ast/token.dart';

Map<String, Object?> tokenValue(Token token) => {
  'type': token.type.toString(),
  'lexeme': token.lexeme,
  'synthetic': token.isSynthetic,
};

Map<String, Object?> astValue(AstNode node) => {
  'node': node.runtimeType.toString(),
  'children': [
    for (final child in node.childEntities)
      if (child is AstNode)
        astValue(child)
      else if (child is Token)
        tokenValue(child)
      else
        throw StateError('Unexpected AST child: ${child.runtimeType}'),
  ],
};

List<Object?> tokens(CompilationUnit unit) {
  final result = <Object?>[];
  var token = unit.beginToken;
  while (true) {
    final comments = <Object?>[];
    for (
      Token? comment = token.precedingComments;
      comment != null;
      comment = comment.next
    ) {
      comments.add(tokenValue(comment));
    }
    result.add({'token': tokenValue(token), 'precedingComments': comments});
    if (token.type == TokenType.EOF) break;
    final next = token.next;
    if (next == null || identical(next, token)) {
      throw StateError('Incomplete token stream');
    }
    token = next;
  }
  return result;
}

Map<String, Object?> trailingCommaDifference(
  List<Object?> before,
  List<Object?> after,
) {
  if (before.length != after.length + 1) return {'qualified': false};
  var index = 0;
  while (index < after.length && jsonEncode(before[index]) == jsonEncode(after[index])) {
    index++;
  }
  if (index >= after.length) return {'qualified': false};
  final removed = before[index] as Map<String, Object?>;
  final token = removed['token']! as Map<String, Object?>;
  final following = before[index + 1] as Map<String, Object?>;
  final nextToken = following['token']! as Map<String, Object?>;
  if (token['type'] != 'COMMA' || token['lexeme'] != ',' ||
      token['synthetic'] != false ||
      (removed['precedingComments']! as List<Object?>).isNotEmpty ||
      nextToken['type'] != 'CLOSE_CURLY_BRACKET') {
    return {'qualified': false};
  }
  for (var tail = index; tail < after.length; tail++) {
    if (jsonEncode(before[tail + 1]) != jsonEncode(after[tail])) {
      return {'qualified': false};
    }
  }
  return {
    'qualified': true,
    'removed_token_index': index,
    'removed_token': removed,
    'following_token': following,
    'description': 'The only lexical difference is removal of the optional map trailing comma before its closing brace; all remaining tokens and comments are identical.',
  };
}

void main(List<String> arguments) {
  if (arguments.length != 3) {
    throw ArgumentError('Expected before.dart after.dart output_directory');
  }
  final output = Directory(arguments[2]);
  final parsed = [
    for (final path in arguments.take(2))
      parseString(
        content: File(path).readAsStringSync(),
        path: 'word_zotero_boundary_formatting_test.dart',
        throwIfDiagnostics: false,
      ),
  ];
  final diagnostics = [
    for (final result in parsed)
      [
        for (final error in result.errors)
          {
            'code': error.errorCode.name,
            'message': error.message,
            'offset': error.offset,
            'length': error.length,
          },
      ],
  ];
  final ast = [for (final result in parsed) jsonEncode(astValue(result.unit))];
  final tokenLists = [for (final result in parsed) tokens(result.unit)];
  final lexical = [for (final list in tokenLists) jsonEncode(list)];
  final commaDifference = trailingCommaDifference(tokenLists[0], tokenLists[1]);
  final source = [for (final result in parsed) result.unit.toSource()];
  for (var i = 0; i < 2; i++) {
    final label = i == 0 ? 'before' : 'after';
    File('${output.path}/$label-canonical-ast.json').writeAsStringSync('${ast[i]}\n');
    File('${output.path}/$label-canonical-tokens.json').writeAsStringSync('${lexical[i]}\n');
    File('${output.path}/$label-canonical-source.dart').writeAsStringSync('${source[i]}\n');
  }
  final valid = diagnostics.every((items) => items.isEmpty) &&
      ast[0] == ast[1] && source[0] == source[1] &&
      (lexical[0] == lexical[1] || commaDifference['qualified'] == true);
  stdout.writeln(jsonEncode({
    'qualified': valid,
    'parser': 'Locked package:analyzer parseString with its default language feature set',
    'diagnostics': diagnostics,
    'canonical_ast_equal': ast[0] == ast[1],
    'canonical_token_stream_including_comments_equal': lexical[0] == lexical[1],
    'optional_trailing_comma_difference': commaDifference,
    'canonical_ast_to_source_equal': source[0] == source[1],
    'ast_policy': 'Recursive node types and ordered child AST/token entities; token type, lexeme and synthetic state preserved; source offsets and whitespace omitted',
    'token_policy': 'Complete ordered tokens including preceding comments; token type, lexeme and synthetic state preserved; source offsets and whitespace omitted',
  }));
  if (!valid) exitCode = 1;
}
