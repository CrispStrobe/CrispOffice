#!/usr/bin/env python3
"""Compare historical Mail evidence inputs to the current integrated checkout."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/7fc035b3e3ba/quds_office_suite')
OUT = Path(__file__).resolve().parent
OLD = OUT.parent
STORE = ROOT.parent / 'store-full-validation'
SCOPES = ['packages/quds_mail_core', 'packages/quds_mail_mime',
          'packages/quds_mail_store', 'packages/quds_mail_transport',
          'packages/quds_mail_ui', 'third_party/enough_mail',
          'pubspec.yaml', 'pubspec.lock', '.fvmrc', 'analysis_options.yaml']

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

def compare(before, after):
    return {'historical_before_after_equal': before == after,
            'captured_files': len(before),
            'current_missing_files': [p for p in before if not (ROOT / p).is_file()],
            'current_changed_files': [p for p, h in before.items()
                                      if (ROOT / p).is_file() and sha(ROOT / p) != h]}

current_names = sorted(set(git('ls-files', '--', *SCOPES).splitlines() +
                           ['.dart_tool/package_config.json']))
cohorts = {}
for name in ['mail-core', 'mail-transport-vm', 'mail-shared-ui', 'mail-transport-js']:
    receipt_path = OLD / (name + '-receipt.json')
    receipt = load(receipt_path)
    before = load(OLD / (name + '-source-before.json'))
    after = load(OLD / (name + '-source-after.json'))
    check = compare(before, after)
    check.update({'execution_receipt': str(receipt_path),
                  'execution_receipt_sha256': sha(receipt_path),
                  'execution_head': receipt['head_at_start'],
                  'passed': receipt['results']['passed'],
                  'failed': receipt['results']['failed'],
                  'skipped': receipt['results']['skipped'],
                  'suites': len(receipt['suites']),
                  'added_input_paths': sorted(set(current_names) - set(before)),
                  'removed_input_paths': sorted(set(before) - set(current_names)),
                  'scoped_git_changes': git('diff', '--name-status', receipt['head_at_start'],
                                            '--', *SCOPES).splitlines()})
    check['can_carry_forward'] = (check['historical_before_after_equal'] and
        all(not check[k] for k in ['current_missing_files', 'current_changed_files',
                                  'added_input_paths', 'removed_input_paths', 'scoped_git_changes'])
        and receipt['exit_code'] == 0 and check['failed'] == check['skipped'] == 0)
    cohorts[name] = check

receipt_path = STORE / 'qualification.json'
receipt = load(receipt_path)
before = load(STORE / 'inputs-before.json')['inputs']
after = load(STORE / 'inputs-after.json')['inputs']
check = compare(before, after)
store_scopes = ['packages/quds_mail_core', 'packages/quds_mail_store',
                '.fvmrc', 'pubspec.lock', 'pubspec.yaml']
store_names = set(git('ls-files', '--', *store_scopes).splitlines()) | {'.dart_tool/package_config.json'}
check.update({'execution_receipt': str(receipt_path), 'execution_receipt_sha256': sha(receipt_path),
              'execution_head': receipt['source_head_before'],
              'vm_passed': receipt['cohorts']['vm']['passed'],
              'node_passed': receipt['cohorts']['node']['passed'],
              'passed': receipt['distinct_cases'],
              'failed': sum(c['failed'] for c in receipt['cohorts'].values()),
              'skipped': sum(c['skipped'] for c in receipt['cohorts'].values()),
              'suites': sum(c['suites'] for c in receipt['cohorts'].values()),
              'added_input_paths': sorted(store_names - set(before)),
              'removed_input_paths': sorted(set(before) - store_names),
              'scoped_git_changes': git('diff', '--name-status', receipt['source_head_before'],
                                        '--', *store_scopes).splitlines()})
check['can_carry_forward'] = (check['historical_before_after_equal'] and
    all(not check[k] for k in ['current_missing_files', 'current_changed_files',
                              'added_input_paths', 'removed_input_paths', 'scoped_git_changes'])
    and all(c['exit_code'] == 0 for c in receipt['cohorts'].values())
    and check['failed'] == check['skipped'] == 0)
cohorts['mail-store'] = check
result = {'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'current_head': git('rev-parse', 'HEAD'),
          'meaning': 'Historical local runs carried to byte-identical current inputs; no new test executions.',
          'cohorts': cohorts, 'all_inputs_match': all(c['can_carry_forward'] for c in cohorts.values()),
          'historical_cases': sum(c['passed'] for c in cohorts.values()),
          'historical_suites': sum(c['suites'] for c in cohorts.values()),
          'fresh_test_executions': 0, 'github_actions_used': False}
(OUT / 'mail-carry-forward.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['current_head', 'all_inputs_match', 'historical_cases',
                                      'historical_suites', 'fresh_test_executions']}))
if not result['all_inputs_match']:
    raise SystemExit(1)
