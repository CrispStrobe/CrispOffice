"""Read-only Dart directive closure audit, including conditional URI branches."""
from pathlib import Path
import json
import re
from urllib.parse import unquote, urljoin, urlparse
ROOT = Path('/workspace/scratch/7fc035b3e3ba/quds_office_suite')
read = lambda path: json.loads(path.read_bytes())

def tokens(source):
    """Read directive tokens lazily, including nested comments and Dart strings."""
    i, length = 0, len(source)
    while i < length:
        if source[i].isspace():
            i += 1
            continue
        if source.startswith('//', i):
            end = source.find('\n', i)
            i = length if end < 0 else end + 1
            continue
        if source.startswith('/*', i):
            depth = 1
            i += 2
            while depth and i < length:
                if source.startswith('/*', i):
                    depth += 1
                    i += 2
                elif source.startswith('*/', i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
            assert depth == 0
            continue
        raw = source[i] == 'r' and i + 1 < length and source[i + 1] in "'\""
        if raw or source[i] in "'\"":
            if raw:
                i += 1
            quote = source[i] * (3 if source.startswith(source[i] * 3, i) else 1)
            i += len(quote)
            value = []
            while not source.startswith(quote, i):
                assert i < length
                if not raw and source[i] == '\\':
                    match = re.match(r'\\(?:u\{([0-9a-fA-F]+)\}|u([0-9a-fA-F]{4})|x([0-9a-fA-F]{2})|(.))', source[i:], re.S)
                    assert match
                    groups = match.groups()
                    value.append(chr(int(next(x for x in groups[:3] if x), 16))
                                 if any(groups[:3]) else {'n': '\n', 'r': '\r', 't': '\t'}.get(groups[3], groups[3]))
                    i += len(match.group(0))
                else:
                    value.append(source[i])
                    i += 1
            i += len(quote)
            yield 'string', ''.join(value)
            continue
        match = re.match(r'[A-Za-z_$][A-Za-z0-9_$]*', source[i:])
        if match:
            i += len(match.group(0))
            yield 'word', match.group(0)
        else:
            yield 'punctuation', source[i]
            i += 1


def directives(path):
    stream = iter(tokens(path.read_text()))
    buffered = None
    result = []
    while True:
        item = buffered or next(stream, None)
        buffered = None
        if item is None:
            return result
        if item[1] == '@':
            # Metadata can precede a library directive. Skip its name/arguments.
            item = next(stream, None)
            while item and (item[0] == 'word' or item[1] == '.'):
                item = next(stream, None)
            if item and item[1] == '(':
                depth = 1
                while depth:
                    token = next(stream)
                    if token[0] == 'punctuation':
                        depth += (token[1] == '(') - (token[1] == ')')
                item = next(stream, None)
            buffered = item
            continue
        if item[1] == 'augment':
            item = next(stream, None)
        if item is None or item[1] not in {'library', 'import', 'export', 'part'}:
            return result  # Dart directives precede declarations.
        kind = item[1]
        while True:
            token = next(stream)
            if token == ('punctuation', ';'):
                break
            if token[0] == 'string' and kind != 'library':
                assert '$' not in token[1], 'Interpolated directive URI is unsupported'
                result.append((kind, token[1]))


package_config = ROOT / '.dart_tool/package_config.json'
package_roots = {}
for package in read(package_config)['packages']:
    root_uri = urljoin(package_config.as_uri(), package['rootUri'].rstrip('/') + '/')
    package_roots[package['name']] = Path(unquote(urlparse(urljoin(root_uri, package.get('packageUri', ''))).path))


def resolve(path, uri):
    if uri.startswith('dart:'):
        return None
    if uri.startswith('package:'):
        name, relative = uri[len('package:'):].split('/', 1)
        return (package_roots[name] / unquote(relative)).resolve()
    parsed = urlparse(uri)
    assert parsed.scheme in {'', 'file'}, (path, uri)
    if parsed.scheme == 'file':
        return Path(unquote(parsed.path)).resolve()
    return Path(unquote(urlparse(urljoin(path.as_uri(), uri)).path)).resolve()


