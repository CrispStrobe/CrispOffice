"""Independent read-only recount/hash checks; never executes product tests."""
from pathlib import Path
import collections
import datetime
import hashlib
import json
import math
import re
import subprocess

BASE = Path('/workspace/scratch/7fc035b3e3ba')
ROOT = BASE / 'quds_office_suite'
OUT = ROOT / 'docs/validation/mail-account-workspace-20261122/receipts'
ENGINE = BASE / '.runtime/validation/final-ab-engine'
NOW = datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n')


def read(path):
    return json.loads(path.read_bytes())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def recount(path, expected, allow_build_hook_prefix=False):
    starts, finishes, suites, done, errors = {}, {}, {}, [], []
    duplicate_starts, duplicate_finishes, malformed, unmatched = [], [], [], []
    build_hook_prefixes = []
    for number, raw in enumerate(path.read_bytes().split(b'\n'), 1):
        if not raw.strip():
            continue
        if allow_build_hook_prefix:
            prefix = re.match(rb'^(?:Running build hooks\.\.\.)+', raw)
            if prefix:
                build_hook_prefixes.append({'line': number, 'prefix': prefix[0].decode()})
                raw = raw[prefix.end():]
                if not raw.strip():
                    continue
        try:
            item = json.loads(raw)
        except (ValueError, UnicodeError) as error:
            malformed.append({'line': number, 'error': str(error)})
            continue
        kind = item.get('type')
        if kind == 'suite':
            suites[item['suite']['id']] = item['suite']['path']
        elif kind == 'testStart':
            test = item['test']
            if test['id'] in starts:
                duplicate_starts.append(test['id'])
            starts[test['id']] = test
        elif kind == 'testDone':
            if item['testID'] in finishes:
                duplicate_finishes.append(item['testID'])
            finishes[item['testID']] = item
        elif kind == 'error':
            errors.append(item)
        elif kind == 'done':
            done.append(item)
    cases, excluded = [], 0
    for test_id, finish in finishes.items():
        if finish.get('hidden'):
            excluded += 1
            continue
        test = starts.get(test_id)
        if test is None:
            unmatched.append(test_id)
            continue
        if test['name'].endswith(('(setUpAll)', '(tearDownAll)')):
            excluded += 1
            continue
        cases.append({'id': test_id, 'suite': suites[test['suiteID']],
                      'name': test['name'], 'result': finish['result'],
                      'skipped': finish.get('skipped', False)})
    observed = set(suites.values())
    result = {
        'reporter_sha256': sha(path), 'jsonl_framing': 'ASCII LF bytes only',
        'passed': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
        'failed': sum(c['result'] != 'success' and not c['skipped'] for c in cases),
        'skipped': sum(c['skipped'] for c in cases), 'substantive_cases': len(cases),
        'suites': len(observed), 'suite_paths': sorted(observed),
        'missing_suites': sorted(set(expected) - observed),
        'unexpected_suites': sorted(observed - set(expected)),
        'excluded_loader_or_hook_events': excluded,
        'reporter_error_events': len(errors), 'reporter_done': done,
        'unfinished_test_ids': sorted(set(starts) - set(finishes)),
        'unmatched_visible_completions': unmatched,
        'duplicate_start_ids': duplicate_starts, 'duplicate_completion_ids': duplicate_finishes,
        'malformed_lf_records': malformed,
        'recorded_build_hook_prefixes': build_hook_prefixes,
        'per_suite_cases': dict(sorted(collections.Counter(c['suite'] for c in cases).items())),
    }
    result['qualified'] = (len(done) == 1 and done[0].get('success') is True
                           and not any(result[k] for k in [
                               'failed', 'skipped', 'missing_suites', 'unexpected_suites',
                               'reporter_error_events', 'unfinished_test_ids',
                               'unmatched_visible_completions', 'duplicate_start_ids',
                               'duplicate_completion_ids', 'malformed_lf_records']))
    return result, cases


def manifest_check(before_path, after_path):
    before_raw, after_raw = read(before_path), read(after_path)
    before = before_raw.get('inputs', before_raw)
    after = after_raw.get('inputs', after_raw)
    current = {p: sha(ROOT / p) if (ROOT / p).is_file() else None for p in before}
    return {
        'captured_inputs': len(before), 'before_manifest_sha256': sha(before_path),
        'after_manifest_sha256': sha(after_path), 'before_after_equal': before == after,
        'changed_current_inputs': sorted(p for p in before if before[p] != current[p]),
        'removed_or_added_capture_paths': sorted(set(before) ^ set(after)),
        'all_inputs_before_after_current_equal': before == after == current,
    }


def normalize(value):
    if isinstance(value, dict):
        return {key: normalize(item) for key, item in value.items()}
    if isinstance(value, list):
        return [normalize(item) for item in value]
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    return value


def compare_json(left, right, path='$', numeric=None, other=None):
    if numeric is None:
        numeric, other = [], []
    if isinstance(left, dict) and isinstance(right, dict):
        if set(left) != set(right):
            other.append(path + ': key set')
        for key in sorted(set(left) & set(right)):
            compare_json(left[key], right[key], path + '.' + key, numeric, other)
    elif isinstance(left, list) and isinstance(right, list):
        if len(left) != len(right):
            other.append(path + ': array length')
        for index, (a, b) in enumerate(zip(left, right)):
            compare_json(a, b, f'{path}[{index}]', numeric, other)
    elif type(left) in (int, float) and type(right) in (int, float):
        if left != right or not math.isfinite(left) or not math.isfinite(right):
            other.append(path + ': numeric value')
        elif type(left) is not type(right):
            if (isinstance(left, float) and left.is_integer()
                    or isinstance(right, float) and right.is_integer()):
                numeric.append(path)
            else:
                other.append(path + ': numeric type')
    elif type(left) is not type(right) or left != right:
        other.append(path + ': value or type')
    return numeric, other


if __name__ == '__main__':
    head = git('rev-parse', 'HEAD')
    plan, qualification = read(ENGINE / 'plan.json'), read(ENGINE / 'qualification.json')
    engine_cohorts = []
    for name, key in [('word-vm', 'word_suites'), ('zotero-odt-vm', 'zotero_odt_suites')]:
        summary, cases = recount(ENGINE / (name + '.jsonl'), plan[key])
        recorded = read(ENGINE / (name + '-cases.json'))
        expected = [{k: row[k] for k in ['id', 'suite', 'name', 'result', 'skipped']} for row in recorded]
        assert sorted(cases, key=lambda c: c['id']) == sorted(expected, key=lambda c: c['id'])
        assert summary['qualified']
        summary.update(name=name, reporter='incoming-engine/' + name + '.jsonl',
                       recorded_case_inventory_matches=True)
        engine_cohorts.append(summary)
    invariant = manifest_check(ENGINE / 'inputs-before.json', ENGINE / 'inputs-after.json')
    assert invariant['all_inputs_before_after_current_equal']
    scopes = plan['source_scopes']
    scoped_delta = git('diff', '--name-only', qualification['source_baseline'], head, '--', *scopes).splitlines()
    assert not scoped_delta
    expected_source_paths = set()
    for scope in scopes:
        path = ROOT / scope
        if path.is_dir():
            expected_source_paths.update(p.relative_to(ROOT).as_posix() for p in path.rglob('*') if p.is_file())
        elif path.is_file():
            expected_source_paths.add(scope)
    expected_source_paths.update(plan['generated_inputs'])
    captured = read(ENGINE / 'inputs-before.json')
    assert expected_source_paths == set(captured)
    commands = qualification['commands']
    assert qualification['qualified'] and len(commands) == 10 and all(c['exit_code'] == 0 for c in commands)
    for command in commands:
        for stream in ['stdout', 'stderr']:
            path = Path(command[stream])
            if not path.is_absolute():
                path = ENGINE / path
            assert sha(path) == command[stream + '_sha256']
    raw_audit = {
        'checked_at_utc': NOW, 'qualified': True,
        'execution_source_commit': qualification['source_baseline'],
        'later_host_checkpoint': head, 'repository_trees_identical': False,
        'cohorts': engine_cohorts,
        'passed': sum(c['passed'] for c in engine_cohorts), 'failed': 0, 'skipped': 0,
        'suites': sum(c['suites'] for c in engine_cohorts), 'input_invariance': invariant,
        'scoped_tracked_delta_to_later_host_checkpoint': scoped_delta,
        'complete_declared_scope_matches_capture': True,
        'passing_commands': len(commands), 'command_stdout_stderr_hashes_verified': True,
        'static_paths': len(plan['static_dart_files']), 'normalization_bridge_required': False,
        'qualification_sha256': sha(ENGINE / 'qualification.json'),
        'source_binding_sha256': sha(ENGINE / 'source-binding.json'),
        'no_additional_test_executions_by_this_audit': True,
        'scope_limit': 'Engine/transitive/config input equality; Mail host/editor files excluded.',
    }
    assert raw_audit['passed'] == 2899 and raw_audit['suites'] == 65
    write('final-ab-engine-raw-audit.json', raw_audit)

    split_vm = (ENGINE / 'split-conformance-vm.log').read_bytes()
    split_node = (ENGINE / 'split-conformance-node.log').read_bytes()
    split_value = json.loads(split_vm)
    adapters = split_value['adapters']
    adapter_case_count = sum(len(adapter['cases']) for adapter in adapters)
    assert len(adapters) == split_value['adapterCount'] == 3
    assert adapter_case_count == split_value['caseCount'] == 174
    assert len({adapter['dialect'] for adapter in adapters}) == len(adapters)
    for adapter in adapters:
        assert len(adapter['cases']) == adapter['caseCount'] == 58
        assert len({case['id'] for case in adapter['cases']}) == len(adapter['cases'])
    smoke_vm = (ENGINE / 'word-split-smoke-vm.log').read_bytes()
    smoke_node = (ENGINE / 'word-split-smoke-node.log').read_bytes()
    left, right = json.loads(smoke_vm), json.loads(smoke_node)
    numeric, other = compare_json(left, right)
    canonical = lambda x: (json.dumps(normalize(x), sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n').encode()
    smoke_left, smoke_right = canonical(left), canonical(right)
    assert split_vm == split_node and smoke_left == smoke_right and not other
    write('final-ab-portability-audit.json', {
        'checked_at_utc': NOW, 'execution_source_commit': qualification['source_baseline'],
        'later_host_checkpoint': head, 'split_raw_bytes_equal': True,
        'split_raw_sha256': hashlib.sha256(split_vm).hexdigest(),
        'split_adapter_cases': adapter_case_count, 'split_adapter_count': len(adapters),
        'split_case_inventory_checked_from_raw_output': True,
        'smoke_raw_bytes_equal': smoke_vm == smoke_node,
        'smoke_integral_number_encoding_difference_count': len(numeric),
        'smoke_numeric_encoding_difference_paths': numeric, 'smoke_other_difference_count': len(other),
        'smoke_canonical_bytes_equal': True, 'smoke_canonical_sha256': hashlib.sha256(smoke_left).hexdigest(),
        'normalization': 'Only finite integral numeric representations normalize; all strings, booleans, array ordering/length, object fields and other values are compared.',
        'no_additional_test_executions_by_this_audit': True,
    })

    prior_retained = read(OUT / 'retained-mail-after-b4.json')
    retained = []
    for row in prior_retained['cohorts']:
        if row['cohort'] == 'shared-mail':
            before = BASE / '.runtime/validation/mail-core-source-before.json'
            after = BASE / '.runtime/validation/mail-core-source-after.json'
        else:
            before = BASE / 'store-full-validation/inputs-before.json'
            after = BASE / 'store-full-validation/inputs-after.json'
        checks = manifest_check(before, after)
        changes = git('diff', '--name-only', 'f4516c13937b9ce5cec771bf331dc91d9f37105d', head, '--', *row['scope']).splitlines()
        assert checks['all_inputs_before_after_current_equal'] and not changes
        retained.append({'cohort': row['cohort'], 'passed': row['passed'], 'suites': row['suites'],
                         **checks, 'scoped_tracked_changes_since_execution': changes,
                         'scope': row['scope'], 'fresh_executions': 0})
    write('retained-mail-after-ab.json', {
        'checked_at_utc': NOW, 'canonical_source_commit': head,
        'canonical_tree': git('rev-parse', head + '^{tree}'),
        'integrated_main': 'ab3457c98b6d9a0d1da8147db3048dfc50d174d3',
        'retained_cases': 2722, 'retained_suites': 124, 'cohorts': retained,
        'all_inputs_match': True, 'fresh_executions': 0,
        'meaning': 'Earlier Mail/core/store/transport/shared-UI runs remain applicable by exact captured-input equality; this does not qualify changed Mail host/editor code.',
    })
    print(json.dumps({'engine_passed': raw_audit['passed'], 'engine_suites': raw_audit['suites'],
                      'engine_inputs': invariant['captured_inputs'], 'retained_passed': 2722,
                      'smoke_numeric_encoding_differences': len(numeric), 'source': head}))
