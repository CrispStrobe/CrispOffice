"""Independently bind complete post258 Studio and retained scopes to one total."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import subprocess

BASE = Path('/workspace/scratch/7fc035b3e3ba')
ROOT = BASE / 'quds_office_suite'
VALID = BASE / '.runtime/validation'
OUT = VALID / 'post258-independent-audit'
SOURCE = 'df8571cb70e8677660ce6843c26de017f5524c52'
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('raw_audit', VALID / 'audit_latest_mail_evidence.py')
raw_audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(raw_audit)

studio_dir = BASE / 'studio-mail-post258-validation'
studio = read(studio_dir / 'qualification.json')
assert studio['status'] == 'passed' and studio['exit_code'] == 0
assert studio['head_at_start'] == SOURCE
working = ROOT / 'packages/quds_office_editor/example'
expected = sorted(str(path) for path in (working / 'test').glob('*mail*_test.dart'))
assert len(expected) == 113 and studio['selected_suite_count'] == 113
summary, studio_cases = raw_audit.recount(studio_dir / 'tests.jsonl', expected)
assert summary['qualified'] and summary['suites'] == 113
assert all(summary[key] == studio[key] for key in ['passed', 'failed', 'skipped'])
fields = ['id', 'suite', 'name', 'result', 'skipped']
recorded = [{key: row[key] for key in fields} for row in read(studio_dir / 'cases.json')]
assert sorted(studio_cases, key=lambda row: row['id']) == sorted(recorded, key=lambda row: row['id'])
before, after = read(studio_dir / 'inputs-before.json'), read(studio_dir / 'inputs-after.json')
assert before == after and studio['source_unchanged'] and not studio['changed_inputs']
assert len(before) == studio['captured_input_count']
expected_inputs = set(subprocess.check_output([
    'git', 'ls-files', '--', 'packages', 'third_party', 'pubspec.yaml',
    'pubspec.lock', '.fvmrc', 'analysis_options.yaml'], cwd=ROOT, text=True).splitlines())
expected_inputs.add('.dart_tool/package_config.json')
assert set(before) == expected_inputs
assert all(sha(ROOT / path) == digest for path, digest in before.items())
mail_inputs = read(VALID / 'final-258-mail/mail-core/inputs-before.json')
common_inputs = set(before) & set(mail_inputs['workspace'])
studio_only_inputs = set(before) - set(mail_inputs['workspace'])
assert len(common_inputs) == 6192 and len(studio_only_inputs) == 44
assert all(Path(path).name in {'CHANGELOG.md', 'README.md', 'LICENSE'}
           and len(Path(path).parts) == 3 and Path(path).parts[0] == 'packages'
           for path in studio_only_inputs)
assert all(mail_inputs['workspace'][path]['sha256'] == before[path] for path in common_inputs)

retained_dir = VALID / 'post258-retained-scopes'
retained = read(retained_dir / 'qualification.json')
assert retained['final_source_checkpoint'] == SOURCE
graphs = read(retained_dir / 'dependency-graphs.json')
assert sha(retained_dir / 'dependency-graphs.json') == retained['dependency_graph_sha256']
assert all(sha(Path(path)) == row['sha256'] for path, row in graphs['nodes'].items())
for filename in ['unchanged-resources.json', 'unchanged-configs.json']:
    rows = read(retained_dir / filename)
    assert all(sha(ROOT / path) == digest for path, digest in rows.items())
engine_cases = read(retained_dir / 'retained-engine-cases.json')
editor_cases = read(retained_dir / 'retained-editor-cases.json')
assert len(engine_cases) == 2805 and len(editor_cases) == 51
assert len({row['suite'] for row in engine_cases}) == 64
assert len({row['suite'] for row in editor_cases}) == 3
assert not any(row['suite'].endswith('word_zotero_boundary_formatting_test.dart') for row in engine_cases)

mail = read(OUT / 'completed-cohorts.json')
assert mail['source_checkpoint'] == SOURCE and mail['mail_gate_complete']
assert mail['fresh_mail_cases_so_far'] == 2761 and mail['fresh_mail_suites_so_far'] == 126
assert mail['fresh_boundary_cases'] == 94
static = read(OUT / 'static-union.json')
assert static['qualified'] and static['total_changed_dart_paths'] == 95

accepted = []
def add_cases(rows, scope, disposition, cwd):
    for row in rows:
        assert row['result'] == 'success' and not row['skipped']
        path = Path(row['suite'])
        path = path if path.is_absolute() else cwd / path
        accepted.append({**row, 'suite': path.relative_to(ROOT).as_posix(),
                         'scope': scope, 'disposition': disposition})

add_cases(engine_cases, 'engine-vm', 'retained', ROOT / 'packages/quds_office_engine')
add_cases(editor_cases, 'editor-zotero', 'retained', ROOT / 'packages/quds_office_editor')
for name, cohort in mail['completed_cohorts'].items():
    directory = VALID / 'final-258-mail' / name
    receipt = read(directory / 'qualification.json')
    assert sha(directory / 'qualification.json') == cohort['raw_receipt_sha256']
    assert sha(directory / 'tests.jsonl') == cohort['reporter_sha256']
    rows = [{key: row[key] for key in fields} for row in read(directory / 'test-cases.json')]
    add_cases(rows, 'engine-vm' if name == 'engine-boundary' else name, 'fresh', Path(receipt['cwd']))
add_cases(studio_cases, 'studio-mail', 'fresh', working)
identities = [(row['scope'], row['suite'], row['id']) for row in accepted]
assert len(identities) == len(set(identities))
suite_identities = {(row['scope'], row['suite']) for row in accepted}
assert len(suite_identities) == 307
fresh_count = sum(row['disposition'] == 'fresh' for row in accepted)
retained_count = sum(row['disposition'] == 'retained' for row in accepted)
assert retained_count == 2856
assert fresh_count == 2761 + 94 + summary['passed']

summary.update({
    'source_checkpoint': SOURCE,
    'command_exit_code': 0,
    'recorded_case_inventory_matches': True,
    'captured_workspace_inputs': len(before),
    'before_after_current_workspace_inputs_equal': True,
    'workspace_input_set_exactly_matches_runner_scope': True,
    'all_shared_studio_mail_input_hashes_equal': True,
    'shared_studio_mail_input_count': len(common_inputs),
    'studio_only_package_publication_documents': sorted(studio_only_inputs),
    'studio_only_documents_before_after_current_equal': True,
    'raw_qualification_sha256': sha(studio_dir / 'qualification.json'),
    'inputs_before_sha256': sha(studio_dir / 'inputs-before.json'),
    'inputs_after_sha256': sha(studio_dir / 'inputs-after.json'),
    'cases_sha256': sha(studio_dir / 'cases.json'),
})
(OUT / 'studio-raw-audit.json').write_text(json.dumps(summary, indent=2) + '\n')
(OUT / 'accepted-cases.json').write_text(json.dumps(accepted, indent=2) + '\n')
result = {
    'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_checkpoint': SOURCE,
    'source_tree': '696f6bbb5c6deef20e2939ec477b2767dd56bfc1',
    'integrated_main': '25850fd310910cb6d852f2e3c480dbc8697fe549',
    'qualified': True,
    'passing_cases': len(accepted), 'suite_executions': len(suite_identities),
    'failed': 0, 'skipped': 0,
    'fresh_cases': fresh_count, 'fresh_suites': 240,
    'retained_cases': retained_count, 'retained_suites': 67,
    'fresh_mail_cases': 2761, 'fresh_mail_suites': 126,
    'fresh_engine_boundary_cases': 94, 'fresh_engine_boundary_suites': 1,
    'fresh_studio_cases': summary['passed'], 'fresh_studio_suites': 113,
    'retained_engine_cases': 2805, 'retained_engine_suites': 64,
    'retained_editor_cases': 51, 'retained_editor_suites': 3,
    'engine_combined_cases': 2899, 'engine_combined_suites': 65,
    'case_identity': ['scope/platform', 'repository_suite_path', 'test_id'],
    'unique_case_identities': True,
    'old94_boundary_cases_excluded': True,
    'old2722_mail_cases_excluded': True,
    'all_old2368_studio_cases_excluded_including_old459_subset': True,
    'retained_dependency_graph_all_current_hashes_match': True,
    'retained_resource_config_hashes_all_current_match': True,
    'complete_fresh_studio_inventory': True,
    'studio_input_count': len(before),
    'all_studio_before_after_current_input_hashes_match': True,
    'shared_studio_mail_inputs_identical': True,
    'shared_studio_mail_input_count': len(common_inputs),
    'studio_only_publication_document_count': len(studio_only_inputs),
    'changed_dart_static_paths': 95,
    'portable_adapter_cases_separate_not_added': 174,
    'additional_test_or_analysis_execution': False,
    'accepted_case_inventory_sha256': sha(OUT / 'accepted-cases.json'),
    'studio_raw_audit_sha256': sha(OUT / 'studio-raw-audit.json'),
    'mail_raw_audit_sha256': sha(OUT / 'completed-cohorts.json'),
    'retention_receipt_sha256': sha(retained_dir / 'qualification.json'),
    'static_union_audit_sha256': sha(OUT / 'static-union.json'),
}
(OUT / 'aggregate-qualification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in [
    'qualified', 'passing_cases', 'suite_executions', 'fresh_cases', 'retained_cases',
    'fresh_studio_cases', 'fresh_studio_suites', 'studio_input_count']}))
