"""Provisional engine/editor dependency proof during the main258 union; no tests."""
from pathlib import Path
import collections
import datetime
import hashlib
import importlib.util
import json
import subprocess

BASE = Path('/workspace/scratch/7fc035b3e3ba')
ROOT = BASE / 'quds_office_suite'
OUT = BASE / '.runtime/validation/post258-retained-scopes'
OUT.mkdir(exist_ok=True)


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, BASE / '.runtime/validation' / filename)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


deps = module('dependency_audit', 'dart_dependency_audit.py')
audit = module('reporter_audit', 'audit_latest_mail_evidence.py')
read = lambda path: json.loads(path.read_bytes())
sha = audit.sha
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
excluded_engine = 'packages/quds_office_engine/test/word_zotero_boundary_formatting_test.dart'
cache = {}


def closure(roots):
    todo, reachable = [Path(p).resolve() for p in roots], set()
    while todo:
        path = todo.pop()
        if str(path) in reachable:
            continue
        assert path.is_file(), str(path)
        if str(path) not in cache:
            edges = []
            for kind, uri in deps.directives(path):
                target = deps.resolve(path, uri)
                edges.append({'kind': kind, 'uri': uri, 'target': str(target) if target else None})
            cache[str(path)] = {'sha256': sha(path), 'directives': edges}
        reachable.add(str(path))
        todo.extend(Path(edge['target']) for edge in cache[str(path)]['directives'] if edge['target'])
    return reachable


engine_dir = BASE / '.runtime/validation/final-ab-engine'
engine_plan = read(engine_dir / 'plan.json')
engine_receipt = read(engine_dir / 'qualification.json')
assert engine_receipt['qualified'] and engine_receipt['substantive_vm_cases'] == 2899
engine_before, engine_after = read(engine_dir / 'inputs-before.json'), read(engine_dir / 'inputs-after.json')
assert engine_before == engine_after
engine_cases = []
engine_reporters = []
for name, key in [('word-vm', 'word_suites'), ('zotero-odt-vm', 'zotero_odt_suites')]:
    summary, cases = audit.recount(engine_dir / (name + '.jsonl'), engine_plan[key])
    assert summary['qualified']
    engine_reporters.append({'name': name, 'reporter_sha256': summary['reporter_sha256'],
                             'passed': summary['passed'], 'suites': summary['suites']})
    engine_cases.extend(cases)
selected = [case for case in engine_cases if case['suite'] == 'test/word_zotero_boundary_formatting_test.dart']
retained = [case for case in engine_cases if case not in selected]
assert len(selected) == 94 and len(retained) == 2805
engine_suites = sorted({case['suite'] for case in retained})
assert len(engine_suites) == 64
engine_graph = closure(ROOT / 'packages/quds_office_engine' / path for path in engine_suites)
assert str(ROOT / excluded_engine) not in engine_graph
engine_local = {Path(path).relative_to(ROOT).as_posix(): cache[path]['sha256']
                for path in engine_graph if Path(path).is_relative_to(ROOT)}
assert all(path in engine_before and engine_before[path] == digest for path, digest in engine_local.items())
engine_changed = sorted(path for path, digest in engine_before.items() if not (ROOT / path).is_file() or sha(ROOT / path) != digest)
assert engine_changed == [excluded_engine], engine_changed
engine_delta = git('diff', '--name-only', '9ce2b057ed8fac6bf6746a1700a6b3ca84f7f405', '--',
                   'packages/quds_office_engine').splitlines()
assert set(engine_delta) <= {excluded_engine, 'packages/quds_office_engine/CHANGELOG.md'}, engine_delta

editor_dir = BASE / 'editor-zotero-final-validation'
editor_receipt = read(editor_dir / 'qualification.json')
assert editor_receipt['status'] == 'passed' and editor_receipt['exit_code'] == 0
editor_suites = [value for value in editor_receipt['command'] if value.endswith('_test.dart')]
editor_expected = [str(ROOT / 'packages/quds_office_editor' / value) for value in editor_suites]
editor_summary, editor_cases = audit.recount(editor_dir / 'tests.jsonl', editor_expected)
assert editor_summary['qualified'] and editor_summary['passed'] == 51 and editor_summary['suites'] == 3
editor_before, editor_after = read(editor_dir / 'inputs-before.json'), read(editor_dir / 'inputs-after.json')
assert editor_before == editor_after
editor_graph = closure(editor_expected)
editor_local = {Path(path).relative_to(ROOT).as_posix(): cache[path]['sha256']
                for path in editor_graph if Path(path).is_relative_to(ROOT)}
assert all(path in editor_before and editor_before[path] == digest for path, digest in editor_local.items())
editor_changed = sorted(path for path, digest in editor_before.items() if not (ROOT / path).is_file() or sha(ROOT / path) != digest)
assert not set(editor_changed) & set(editor_local)
assert not any(path.endswith('/CHANGELOG.md') for path in editor_local)
assert excluded_engine not in editor_local

# Record resources separately from Dart code: all engine test fixtures and macro
# inputs and all editor fixture bytes are unchanged, even though Mail's captured
# broad workspace inputs change and need fresh qualification.
resource_roots = ['packages/quds_office_engine/test/fixtures/',
                  'packages/quds_office_engine/example/macros/',
                  'packages/quds_office_editor/test/fixtures/']
resource_paths = [path for path in editor_before if any(path.startswith(prefix) for prefix in resource_roots)]
assert all(sha(ROOT / path) == editor_before[path] for path in resource_paths)
for paths in [engine_graph, editor_graph]:
    for path in paths:
        assert Path(excluded_engine).name not in Path(path).read_text(), path

graph_path = OUT / 'dependency-graphs.json'
graph_path.write_text(json.dumps({'engine_roots': engine_suites, 'editor_roots': editor_suites,
    'engine_reachable': sorted(engine_graph), 'editor_reachable': sorted(editor_graph),
    'nodes': cache}, indent=2) + '\n')
record = {
    'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'provisional_waiting_frozen_union_binding',
    'git_head_during_union': git('rev-parse', 'HEAD'),
    'incoming_main': '25850fd310910cb6d852f2e3c480dbc8697fe549',
    'premerge_qualified_source': '9ce2b057ed8fac6bf6746a1700a6b3ca84f7f405',
    'premerge_evidence_checkpoint': 'b25acd58cb31f1910e96a031b465bfeb5a683e35',
    'engine': {'can_retain_scoped_cases': True, 'cases': 2805, 'suites': 64,
               'replaced_cases': 94, 'replaced_suites': 1, 'replaced_entrypoint': excluded_engine,
               'original_processes_qualified': True, 'reporters': engine_reporters,
               'suite_paths': engine_suites, 'reachable_dart_nodes': len(engine_graph),
               'local_reachable_nodes': len(engine_local),
               'all_local_reachable_bytes_equal': True, 'changed_original_inputs': engine_changed,
               'whole_engine_directory_delta': engine_delta,
               'production_library_delta': [],
               'portability_inputs_unchanged': True},
    'editor': {'can_retain_scoped_cases': True, 'cases': 51, 'suites': 3,
               'original_process_qualified': True, 'suite_paths': editor_suites,
               'reporter_sha256': editor_summary['reporter_sha256'],
               'reachable_dart_nodes': len(editor_graph), 'local_reachable_nodes': len(editor_local),
               'all_local_reachable_bytes_equal': True,
               'changed_broadly_captured_inputs': editor_changed,
               'changed_inputs_in_reachable_closure': [],
               'changed_changelog_or_boundary_entrypoint_reachable': False},
    'resource_files_checked': len(resource_paths), 'resource_bytes_unchanged': True,
    'dependency_graph_sha256': sha(graph_path), 'dependency_graph_file': graph_path.name,
    'same_pinned_runtime_and_locked_dependencies': True,
    'no_fresh_test_or_analysis_execution': True,
    'final_binding_required': 'After union freeze, compare all recorded dependency/resource hashes against the canonical source and confirm package/config/runtime inputs unchanged.',
    'replaced_mail_evidence': {'previous_shared_store_cases': 2722, 'previous_studio_cases': 2368,
                               'final_case_credit_from_these_previous_runs': 0,
                               'reason': 'Archive changes production Mail core/store/host inputs. Fresh shared/store and all113 Studio suites replace the earlier Mail scopes.'},
}
(OUT / 'qualification-plan.json').write_text(json.dumps(record, indent=2) + '\n')
(OUT / 'retained-engine-cases.json').write_text(json.dumps(retained, indent=2) + '\n')
(OUT / 'retained-editor-cases.json').write_text(json.dumps(editor_cases, indent=2) + '\n')
print(json.dumps({'status': record['status'], 'engine_cases': 2805, 'engine_suites': 64,
                  'editor_cases': 51, 'editor_suites': 3,
                  'engine_local_dependencies': len(engine_local),
                  'editor_local_dependencies': len(editor_local),
                  'resources': len(resource_paths)}))
