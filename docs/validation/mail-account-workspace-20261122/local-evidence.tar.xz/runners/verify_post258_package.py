"""Verify every archived byte and readable receipt, then mark packaging complete."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import tarfile

BASE = Path('/workspace/scratch/7fc035b3e3ba')
OUT = BASE / 'quds_office_suite/docs/validation/mail-account-workspace-20261122'
read = lambda path: json.loads(path.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
index = read(OUT / 'evidence-index.json')
archive = OUT / index['archive']
assert archive.stat().st_size == index['archive_bytes']
assert sha(archive.read_bytes()) == index['archive_sha256']
expected = {row['path']: row for row in index['files']}
assert len(expected) == len(index['files'])
with tarfile.open(archive, 'r:xz') as tar:
    members = tar.getmembers()
    assert len(members) == len(expected)
    assert {member.name for member in members} == set(expected)
    for member in members:
        assert member.isfile() and not member.name.startswith('/')
        assert '..' not in Path(member.name).parts
        data = tar.extractfile(member).read()
        recorded = expected[member.name]
        assert len(data) == member.size == recorded['bytes']
        assert sha(data) == recorded['sha256']
    assert json.load(tar.extractfile('post258-audit/aggregate-qualification.json'))['qualified']
    assert json.load(tar.extractfile('post258-studio/qualification.json'))['status'] == 'passed'
    assert 'integration/latest-main-258/root-merge-resolution.json' in expected

qpath = OUT / 'qualification.json'
qualification = read(qpath)
assert qualification['qualified']
assert qualification['source']['canonical_source_commit'] == 'df8571cb70e8677660ce6843c26de017f5524c52'
for name, digest in qualification['receipt_sha256'].items():
    assert sha((OUT / name).read_bytes()) == digest, name
for link in re.findall(r'\]\(([^)]+)\)', (OUT / 'README.md').read_text()):
    if '://' not in link:
        assert (OUT / link.split('#')[0]).exists(), link
audit = {
    'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_checkpoint': qualification['source']['canonical_source_commit'],
    'archive_sha256': index['archive_sha256'],
    'archive_bytes': index['archive_bytes'],
    'archive_member_count': len(expected),
    'all_member_paths_sizes_sha256_verified': True,
    'all_readable_receipt_hashes_verified': True,
    'readable_receipt_count_before_this_audit': len(qualification['receipt_sha256']),
    'all_readme_relative_links_resolve': True,
    'current_aggregate_and_studio_success_preserved': True,
    'root_merge_resolution_preserved': True,
    'no_test_or_analysis_execution': True,
}
receipt = OUT / 'receipts/post258-evidence-member-audit.json'
receipt.write_text(json.dumps(audit, indent=2) + '\n')
qualification['receipt_sha256'][receipt.relative_to(OUT).as_posix()] = sha(receipt.read_bytes())
qualification['evidence_archive']['all_members_verified_by_index'] = True
qualification['evidence_archive']['independent_member_audit'] = receipt.relative_to(OUT).as_posix()
qpath.write_text(json.dumps(qualification, indent=2) + '\n')
print(json.dumps(audit))
