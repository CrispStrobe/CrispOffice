"""Strict checks for all changed Mail and editor-controller Dart paths."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

ROOT = Path('/workspace/scratch/7fc035b3e3ba/quds_office_suite')
OUTPUT = Path('/workspace/scratch/7fc035b3e3ba/studio-mail-static-validation')
OUTPUT.mkdir(exist_ok=True)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


paths = [path for path in git(
    'diff', '--name-only', '659b81462224a40f50975cfbfca39f636538b836', 'HEAD',
    '--', '*.dart').splitlines() if not path.startswith('packages/quds_office_engine/')]


def snapshot():
    return {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
            for path in paths}


before = snapshot()
(OUTPUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
receipt = {'source_commit': git('rev-parse', 'HEAD'), 'paths': paths,
           'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'commands': [], 'status': 'running'}
commands = [
    ('analysis', ['dart', 'analyze', '--fatal-infos', '--fatal-warnings', *paths]),
    ('format', ['dart', 'format', '--output=none', '--set-exit-if-changed', *paths]),
]
for name, command in commands:
    with (OUTPUT / (name + '.log')).open('w') as out, (OUTPUT / (name + '-stderr.log')).open('w') as err:
        result = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err)
    receipt['commands'].append({'name': name, 'argv': command, 'exit_code': result.returncode})
    print(json.dumps({'gate': name, 'exit_code': result.returncode}), flush=True)
    if result.returncode != 0:
        break
after = snapshot()
(OUTPUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
receipt.update({
    'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_unchanged': before == after,
    'changed_inputs': [path for path in before if before[path] != after.get(path)],
    'status': 'passed' if len(receipt['commands']) == 2 and
        all(command['exit_code'] == 0 for command in receipt['commands']) and before == after else 'failed',
})
(OUTPUT / 'qualification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': receipt['status'], 'paths': len(paths),
                  'source_unchanged': before == after}), flush=True)
sys.exit(0 if receipt['status'] == 'passed' else 1)
