"""Preserve local qualification and diagnostic records as a reproducible archive."""
from pathlib import Path
import argparse
import datetime
import hashlib
import io
import json
import tarfile

BASE = Path('/workspace/scratch/7fc035b3e3ba')
OUT = BASE / 'quds_office_suite/docs/validation/mail-account-workspace-20261122'
parser = argparse.ArgumentParser()
parser.add_argument('--engine-dir', required=True)
parser.add_argument('--include-studio', action='store_true')
args = parser.parse_args()
files = {}
suffixes = {
    '.json', '.jsonl', '.log', '.txt', '.sha256', '.stderr', '.py', '.md', '.dart',
    '.patch', '.diff',
}


def add(path, destination):
    if path.is_file():
        files[destination] = path


def folder(path, destination):
    if not path.is_dir():
        return
    for entry in sorted(path.rglob('*')):
        if entry.is_file() and entry.suffix in suffixes:
            add(entry, destination + '/' + entry.relative_to(path).as_posix())


for entry in sorted((BASE / '.runtime/validation').glob('mail-*')):
    add(entry, 'shared-mail/' + entry.name)
for name in ['shared-mail-summary.json', 'carry-forward-audit.json']:
    add(BASE / '.runtime/validation' / name, 'shared-mail/' + name)
add(BASE / '.runtime/validation/run_mail_cohort.py', 'shared-mail/run_mail_cohort.py')
folder(BASE / 'store-full-validation', 'mail-store')
folder(Path(args.engine_dir), 'incoming-engine')
folder(BASE / '.runtime/validation/studio-suite-carry-forward', 'studio-carry-forward')
prior_integrated_engine = BASE / '.runtime/validation/final-integrated-engine'
if Path(args.engine_dir).resolve() != prior_integrated_engine.resolve():
    folder(prior_integrated_engine, 'development/engine-before-b4-main')
original_b4_engine = BASE / '.runtime/validation/final-b4-engine'
if Path(args.engine_dir).resolve() != original_b4_engine.resolve():
    folder(original_b4_engine, 'development/engine-b4-original-vm-analysis')
normalized_b4_engine = BASE / '.runtime/validation/final-b4-engine-formatted'
if Path(args.engine_dir).resolve() != normalized_b4_engine.resolve():
    folder(normalized_b4_engine, 'development/engine-b4-normalized')
folder(BASE / '.runtime/validation/final-engine', 'development/engine-before-repair')
folder(BASE / '.runtime/validation/final-engine-repaired', 'development/engine-before-main-refresh')
folder(BASE / '.runtime/validation/zotero-repair', 'development/engine-focused-repair')
folder(BASE / 'native-navigation-checks', 'development/navigation-before-main-refresh')
folder(BASE / 'native-merge-checks', 'development/native-compiler-attempts')
folder(BASE / 'provider-test-merge', 'development/provider-union-103')
for name in ['session_close_probe.dart', 'session_close_widget_probe_test.dart']:
    add(BASE / 'native-navigation-checks' / name,
        'development/navigation-before-main-refresh/' + name)
for entry in sorted((BASE / '.runtime/validation').glob('word-*')):
    add(entry, 'development/initial-word/' + entry.name)
for name in ['runtime-provenance.json', 'package-archives.json']:
    add(BASE / '.runtime' / name, 'runtime/' + name)
for name in ['final-integration-audit.json', 'final-mail-source-review.json',
             'final-captured-ancestry.json', 'final-remote-main-audit.json',
             'late-intake-audit.json', 'late-mail-source-review.json',
             'main-merge-mail-reconciliation.json']:
    add(BASE / name, 'integration/' + name)
for name in ['frozen-source-ancestry.json', 'final-frozen-source-proof.json',
             'studio-final-cohorts.json']:
    add(BASE / '.runtime/validation' / name, 'integration/' + name)
folder(BASE / '.runtime/latest-main-ab-audit', 'integration/latest-main-ab')
folder(BASE / '.runtime/latest-main-b4-audit', 'integration/latest-main-b4')
folder(BASE / '.runtime/latest-main-258-audit', 'integration/latest-main-258')
folder(BASE / '.runtime/validation/final-258-mail', 'post258-mail')
folder(BASE / '.runtime/validation/final-258-mail-static', 'post258-static')
folder(BASE / '.runtime/validation/post258-retained-scopes', 'post258-retained')
folder(BASE / '.runtime/validation/post258-independent-audit', 'post258-audit')
folder(BASE / '.runtime/validation/pre258-qualified-evidence',
       'development/pre258-qualified-evidence')
for name in ['post258-qualification-plan.json', 'post258-frozen-source-proof.json',
             'mail-union-cohorts.json']:
    add(BASE / '.runtime/validation' / name, 'integration/' + name)
if args.include_studio:
    folder(BASE / 'studio-mail-final-validation', 'studio-mail')
    folder(BASE / 'studio-mail-static-validation', 'studio-mail-static')
    folder(BASE / 'editor-zotero-final-validation', 'editor-zotero')
    folder(BASE / 'studio-mail-post258-validation', 'post258-studio')
for pattern in ['studio-mail-attempt-*', 'editor-zotero-attempt-*',
                'studio-mail-static-attempt-*']:
    for path in sorted(BASE.glob(pattern)):
        folder(path, 'development/' + path.name)
add(Path(__file__), 'runners/package_mail_evidence.py')
add(BASE / '.runtime/validation/run_studio_mail_final.py',
    'runners/run_studio_mail_final.py')
add(BASE / '.runtime/validation/run_mail_static.py',
    'runners/run_mail_static.py')
add(BASE / '.runtime/validation/audit_latest_mail_evidence.py',
    'runners/audit_latest_mail_evidence.py')
add(BASE / '.runtime/validation/aggregate_studio_mail_evidence.py',
    'runners/aggregate_studio_mail_evidence.py')
add(BASE / '.runtime/validation/prove_studio_suite_carry_forward.py',
    'runners/prove_studio_suite_carry_forward.py')
for name in ['run_mail_union_cohort.py', 'audit_post258_evidence.py', 'audit_post258_final.py',
             'audit_post258_static.py', 'prove_post258_retained_scopes.py',
             'dart_dependency_audit.py', 'render_post258_validation.py',
             'verify_post258_package.py']:
    add(BASE / '.runtime/validation' / name, 'runners/' + name)

OUT.mkdir(parents=True, exist_ok=True)
archive = OUT / 'local-evidence.tar.xz'
index = []
with tarfile.open(archive, 'w:xz', preset=6) as output:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        metadata = tarfile.TarInfo(name)
        metadata.size = len(data)
        metadata.mode = 0o644
        metadata.mtime = 0
        output.addfile(metadata, io.BytesIO(data))
        index.append({'path': name, 'bytes': len(data),
                      'sha256': hashlib.sha256(data).hexdigest()})
result = {
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'archive': archive.name,
    'archive_bytes': archive.stat().st_size,
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'includes_final_studio_evidence': args.include_studio,
    'files': index,
}
(OUT / 'evidence-index.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'files'}))
