"""Aggregate14 proved retained suites and two fresh cohorts; no test runs."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import subprocess

BASE = Path('/workspace/scratch/7fc035b3e3ba')
ROOT = BASE / 'quds_office_suite'
WORKING = ROOT / 'packages/quds_office_editor/example'
DIRECTORY = BASE / 'studio-mail-final-validation'
DOCS = ROOT / 'docs/validation/mail-account-workspace-20261122/receipts'
spec = importlib.util.spec_from_file_location(
    'independent_mail_audit', BASE / '.runtime/validation/audit_latest_mail_evidence.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


plan_path = BASE / '.runtime/validation/studio-final-cohorts.json'
plan = read(plan_path)
all_suites = set(plan['all'])
repaired = set(plan['repaired'])
remaining = set(plan['remaining'])
assert len(all_suites) == len(plan['all']) == 110
assert len(repaired) == len(plan['repaired'])
assert len(remaining) == len(plan['remaining'])
assert not repaired & remaining and repaired | remaining == all_suites
discovered = {str(path.relative_to(WORKING))
              for path in (WORKING / 'test').glob('*mail*_test.dart')}
assert discovered == all_suites, 'Plan differs from complete current Mail suite inventory'

carry_dir = BASE / '.runtime/validation/studio-suite-carry-forward'
carry_path = carry_dir / 'qualification.json'
carry = read(carry_path)
assert carry['retained_suite_evidence_qualified'] is True
assert carry['original_process_exit_code'] == 1
assert carry['original_process_reporter_done_success'] is False
assert carry['original_process_qualified'] is False
retained_paths = set(carry['retained_suite_paths'])
fresh_repaired_paths = set(carry['excluded_suite_paths'])
assert len(retained_paths) == 14 and len(fresh_repaired_paths) == 4
assert not retained_paths & fresh_repaired_paths
assert retained_paths | fresh_repaired_paths == repaired
assert not (retained_paths | fresh_repaired_paths) & remaining
old_dir = BASE / 'studio-mail-attempt-06/repaired'
assert sha(old_dir / 'tests.jsonl') == carry['raw_reporter_sha256']
assert sha(old_dir / 'qualification.json') == carry['original_receipt_sha256']
assert sha(carry_dir / 'dependency-graph.json') == carry['graph_sha256']
dependency_graph = read(carry_dir / 'dependency-graph.json')['graph']
for path, entry in dependency_graph.items():
    assert sha(Path(path)) == entry['sha256'], 'A retained dependency changed'
retained_cases = read(carry_dir / 'retained-cases.json')
assert len(retained_cases) == carry['retained_passed_cases'] == 459
assert all(row['result'] == 'success' and not row['skipped'] for row in retained_cases)
assert {str(Path(row['suite']).relative_to(WORKING)) for row in retained_cases} == retained_paths

baseline_manifest = None
cohorts = []
suite_counts = dict(carry['per_suite_cases'])
retained_summary = {
    'cohort': 'retained_successful_suites_from_failed_process',
    'passed': carry['retained_passed_cases'], 'failed': 0, 'skipped': 0,
    'suites': carry['retained_suites'], 'suite_paths': sorted(retained_paths),
    'original_process_exit_code': 1, 'original_process_reporter_done_success': False,
    'original_process_qualified': False, 'retained_suite_evidence_qualified': True,
    'source_commit_at_execution': carry['original_process_source'],
    'source_commit_at_dependency_proof': carry['source_checkpoint'],
    'dependency_proof_sha256': sha(carry_path),
    'dependency_graph_sha256': carry['graph_sha256'],
    'original_reporter_sha256': carry['raw_reporter_sha256'],
    'raw_reporter_archive_path': 'development/studio-mail-attempt-06/repaired/tests.jsonl',
    'proof_archive_path': 'studio-carry-forward/qualification.json',
    'all_four_failed_suite_results_replaced': True,
}
for name in ['repaired', 'remaining']:
    directory = DIRECTORY / name
    receipt_path = directory / 'qualification.json'
    receipt = read(receipt_path)
    assert receipt['status'] == 'passed' and receipt['exit_code'] == 0
    expected = fresh_repaired_paths if name == 'repaired' else remaining
    selected = {argument for argument in receipt['command'] if argument.endswith('_test.dart')}
    assert selected == expected
    absolute = {str(WORKING / path) for path in expected}
    summary, cases = audit.recount(directory / 'tests.jsonl', absolute)
    assert summary['qualified'] and summary['suites'] == len(expected)
    recorded = read(directory / 'cases.json')
    fields = ['id', 'suite', 'name', 'result', 'skipped']
    assert sorted(cases, key=lambda case: case['id']) == sorted(
        [{key: row[key] for key in fields} for row in recorded],
        key=lambda case: case['id'])
    assert all(summary[key] == receipt[key] for key in ['passed', 'failed', 'skipped'])
    before = read(directory / 'inputs-before.json')
    after = read(directory / 'inputs-after.json')
    assert before == after and receipt['source_unchanged'] is True
    assert len(before) == receipt['captured_input_count']
    if baseline_manifest is None:
        baseline_manifest = before
    else:
        assert before == baseline_manifest, 'Cohorts captured different full input manifests'
    for path, count in summary['per_suite_cases'].items():
        relative = Path(path).relative_to(WORKING).as_posix()
        assert relative not in suite_counts, 'Repeated suite would double-count its cases'
        suite_counts[relative] = count
    summary.update(
        cohort=name, command_exit_code=receipt['exit_code'],
        source_commit_at_start=receipt['head_at_start'],
        source_commit_at_finish=receipt['head_at_finish'],
        selected_suite_paths=sorted(expected),
        captured_input_count=len(before),
        input_manifest_sha256=sha(directory / 'inputs-before.json'),
        before_after_manifests_identical=True,
        independently_recounted_case_inventory_matches=True,
        raw_receipt_sha256=sha(receipt_path),
        raw_stderr_sha256=sha(directory / 'stderr.log'),
        raw_reporter_archive_path=f'studio-mail/{name}/tests.jsonl',
        raw_receipt_archive_path=f'studio-mail/{name}/qualification.json',
    )
    cohorts.append(summary)

paths = git('ls-files', '--', 'packages', 'third_party', 'pubspec.yaml',
            'pubspec.lock', '.fvmrc', 'analysis_options.yaml').splitlines()
paths.append('.dart_tool/package_config.json')
assert set(paths) == set(baseline_manifest), 'Current declared input inventory changed'
current = {path: sha(ROOT / path) for path in paths}
assert current == baseline_manifest, 'Current captured inputs differ from accepted cohorts'
old_before = read(old_dir / 'inputs-before.json')
old_after = read(old_dir / 'inputs-after.json')
assert old_before == old_after and set(old_before) == set(baseline_manifest)
old_to_final_delta = {path for path in old_before if old_before[path] != baseline_manifest[path]}
assert old_to_final_delta == set(carry['changed_inputs'])
assert old_to_final_delta == {str((WORKING / path).relative_to(ROOT)) for path in fresh_repaired_paths}
assert set(suite_counts) == all_suites
result = {
    'schema_version': 1,
    'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'qualified': True,
    'aggregate_kind': '14_dependency_proved_retained_suites_plus_4_and_92_fresh_successful_suites',
    'current_source_checkpoint': git('rev-parse', 'HEAD'),
    'retained_cohort': retained_summary,
    'fresh_cohorts': cohorts,
    'passed': retained_summary['passed'] + sum(row['passed'] for row in cohorts),
    'failed': sum(row['failed'] for row in cohorts),
    'skipped': sum(row['skipped'] for row in cohorts),
    'suites': len(all_suites),
    'retained_passing_cases': retained_summary['passed'], 'retained_suites': 14,
    'fresh_passing_cases': sum(row['passed'] for row in cohorts), 'fresh_suites': 96,
    'selected_and_observed_suite_union_exact': True,
    'repeated_suite_paths': [],
    'complete_current_mail_suite_inventory_matches': True,
    'case_identity': 'Distinct test ID within each source process; disjoint retained14/fresh4/fresh92 suite paths. Display names are not deduplicated.',
    'per_suite_cases': dict(sorted(suite_counts.items())),
    'captured_input_count': len(baseline_manifest),
    'fresh_cohort_before_after_current_input_maps_identical': True,
    'retained_prior_to_current_changed_inputs': sorted(old_to_final_delta),
    'retained_reachable_dependency_bytes_identical': True,
    'all_other6220_prior_inputs_identical': True,
    'complete_current_input_inventory_matches': True,
    'input_manifest_sha256': cohorts[0]['input_manifest_sha256'],
    'cohort_plan_sha256': sha(plan_path),
    'reporter_framing': 'ASCII LF bytes only; literal Unicode line separators remain inside JSON strings.',
    'no_fresh_test_executions_by_this_audit': True,
    'failed_process_relabelled_as_successful': False,
    'exception_for_verified_successful_suites_from_failed_process': 'Only14 complete error-free independent suites retained after exact dependency proof. All173 cases from the four failed files replaced by fresh execution, including164 prior passes. Other failed/interrupted runs contribute zero.',
    'github_actions_queried': False,
    'github_actions_waited': False,
}
assert result['failed'] == result['skipped'] == 0
assert result['passed'] == sum(suite_counts.values())
encoded = json.dumps(result, indent=2) + '\n'
(DIRECTORY / 'aggregate-qualification.json').write_text(encoded)
(DOCS / 'studio-final-aggregate.json').write_text(encoded)
print(json.dumps({key: result[key] for key in [
    'qualified', 'passed', 'failed', 'skipped', 'suites', 'captured_input_count',
    'fresh_passing_cases', 'retained_passing_cases',
    'fresh_cohort_before_after_current_input_maps_identical']}))
