"""Independently recount completed post258 cohorts and verify recorded inputs."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os

BASE = Path('/workspace/scratch/7fc035b3e3ba')
ROOT = BASE / 'quds_office_suite'
OUT = BASE / '.runtime/validation/post258-independent-audit'
OUT.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('audit', BASE / '.runtime/validation/audit_latest_mail_evidence.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
read = lambda path: json.loads(path.read_bytes())
sha = audit.sha
accepted = {}
reference_snapshot = None
for directory in sorted((BASE / '.runtime/validation/final-258-mail').iterdir()):
    receipt_path = directory / 'qualification.json'
    if not receipt_path.is_file():
        continue
    receipt = read(receipt_path)
    if not receipt.get('qualified'):
        continue
    assert receipt['exit_code'] == 0 and not receipt['interrupted']
    expected = receipt['expected_suites']
    working = Path(receipt['cwd'])
    first_suite = None
    for raw in (directory / 'tests.jsonl').read_bytes().split(b'\n'):
        try:
            event = json.loads(raw)
        except ValueError:
            continue
        if event.get('type') == 'suite':
            first_suite = event['suite']['path']
            break
    assert first_suite is not None
    if Path(first_suite).is_absolute():
        expected = [str(working / path) for path in expected]
    summary, cases = audit.recount(directory / 'tests.jsonl', expected, allow_build_hook_prefix=True)
    assert summary['qualified']
    assert all(summary[key] == receipt['results'][key] for key in ['passed', 'failed', 'skipped'])
    assert summary['suites'] == receipt['results']['suite_count']
    normalize = lambda path: Path(path).relative_to(working).as_posix() if Path(path).is_absolute() else path
    normalized = [{**row, 'suite': normalize(row['suite'])} for row in cases]
    fields = ['id', 'suite', 'name', 'result', 'skipped']
    recorded = [{key: row[key] for key in fields} for row in read(directory / 'test-cases.json')]
    assert sorted(normalized, key=lambda row: row['id']) == sorted(recorded, key=lambda row: row['id'])
    before, after = read(directory / 'inputs-before.json'), read(directory / 'inputs-after.json')
    assert before == after and receipt['source_unchanged']
    assert all(not values for values in receipt['changed_inputs'].values())
    assert all(row['matches_expected_head'] is not False for row in before['workspace'].values())
    if reference_snapshot is None:
        reference_snapshot = before
    else:
        assert before == reference_snapshot, 'Accepted cohorts captured different frozen input maps'
    summary.update(cohort=directory.name, source_checkpoint=receipt['expected_head'],
                   command_exit_code=0, recorded_case_inventory_matches=True,
                   input_counts={key: len(value) for key, value in before.items()},
                   all_input_sections_before_after_equal=True,
                   all_tracked_workspace_blobs_match_source=True,
                   raw_receipt_sha256=sha(receipt_path),
                   input_manifest_sha256=sha(directory / 'inputs-before.json'),
                   runner_unchanged=receipt['runner_unchanged'], plan_unchanged=receipt['plan_unchanged'])
    for name, expected_hash in receipt['artifact_sha256'].items():
        assert sha(directory / name) == expected_hash, name
    accepted[directory.name] = summary

assert reference_snapshot is not None
for path, record in reference_snapshot['workspace'].items():
    actual_path = ROOT / path
    raw = os.readlink(actual_path).encode() if actual_path.is_symlink() else actual_path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == record['sha256']
    assert len(raw) == record['bytes']
    blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    assert blob == record['git_blob']
for record in reference_snapshot['resolved_packages'].values():
    path = Path(record['path'])
    assert sha(path) == record['sha256'] and path.stat().st_size == record['bytes']
for path, record in reference_snapshot['runtime'].items():
    assert sha(Path(path)) == record['sha256']

mail = {name: summary for name, summary in accepted.items() if name != 'engine-boundary'}
result = {
    'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_checkpoint': 'df8571cb70e8677660ce6843c26de017f5524c52',
    'completed_cohorts': accepted,
    'fresh_mail_cases_so_far': sum(row['passed'] for row in mail.values()),
    'fresh_mail_suites_so_far': sum(row['suites'] for row in mail.values()),
    'mail_gate_complete': len(mail) == 6,
    'fresh_boundary_cases': accepted.get('engine-boundary', {}).get('passed', 0),
    'all_completed_cohort_input_maps_identical': True,
    'all_current_workspace_resolved_package_runtime_hashes_match': True,
    'input_counts': {key: len(value) for key, value in reference_snapshot.items()},
    'no_extra_test_or_analysis_executions': True,
}
(OUT / 'completed-cohorts.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['fresh_mail_cases_so_far', 'fresh_mail_suites_so_far',
       'mail_gate_complete', 'fresh_boundary_cases', 'input_counts']}))
