"""Render source-bound Mail evidence; final status requires the fresh Studio gate."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import shutil

BASE = Path('/workspace/scratch/7fc035b3e3ba')
VALID = BASE / '.runtime/validation'
OUT = BASE / 'quds_office_suite/docs/validation/mail-account-workspace-20261122'
RECEIPTS = OUT / 'receipts'
SOURCE = 'df8571cb70e8677660ce6843c26de017f5524c52'
TREE = '696f6bbb5c6deef20e2939ec477b2767dd56bfc1'
ALIAS = '594a7e502181e6ce2467f1c3163318bfa79a8733'
MAIN = '25850fd310910cb6d852f2e3c480dbc8697fe549'
parser = argparse.ArgumentParser()
parser.add_argument('--final', action='store_true')
args = parser.parse_args()
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
write = lambda path, value: path.write_text(json.dumps(value, indent=2) + '\n')
old = read(VALID / 'pre258-qualified-evidence/qualification.json')
old_readme = (VALID / 'pre258-qualified-evidence/README.md').read_text()
retained = read(VALID / 'post258-retained-scopes/qualification.json')
audit = read(VALID / 'post258-independent-audit/completed-cohorts.json')
static = read(VALID / 'post258-independent-audit/static-union.json')
aggregate = read(VALID / 'post258-independent-audit/aggregate-qualification.json') if args.final else None
if aggregate:
    assert aggregate['qualified'] and aggregate['source_checkpoint'] == SOURCE
assert retained['final_source_checkpoint'] == SOURCE
assert retained['all_recorded_dependency_resource_config_hashes_match_final_source']
assert audit['source_checkpoint'] == SOURCE and audit['mail_gate_complete']
assert audit['fresh_mail_cases_so_far'] == 2761 and audit['fresh_boundary_cases'] == 94
assert static['qualified'] and static['total_changed_dart_paths'] == 95

copies = {
    'post258-retained-engine-editor.json': VALID / 'post258-retained-scopes/qualification.json',
    'post258-frozen-source-proof.json': VALID / 'post258-frozen-source-proof.json',
    'post258-qualification-plan.json': VALID / 'post258-qualification-plan.json',
    'post258-completed-cohorts.json': VALID / 'post258-independent-audit/completed-cohorts.json',
    'post258-static-qualification.json': VALID / 'final-258-mail-static/qualification.json',
    'post258-static-union-audit.json': VALID / 'post258-independent-audit/static-union.json',
    'post258-root-merge-resolution.json': BASE / '.runtime/latest-main-258-audit/root-merge-resolution.json',
    'post258-cas-preservation.json': BASE / '.runtime/latest-main-258-audit/cas-preservation.json',
    'pre258-qualification.json': VALID / 'pre258-qualified-evidence/qualification.json',
    'post258-retention-independent-review.json': VALID / 'post258-independent-audit/retained-scopes-independent-review.json',
}
for name in audit['completed_cohorts']:
    copies['post258-' + name + '-qualification.json'] = VALID / 'final-258-mail' / name / 'qualification.json'
if aggregate:
    copies.update({
        'post258-final-aggregate.json': VALID / 'post258-independent-audit/aggregate-qualification.json',
        'post258-studio-raw-audit.json': VALID / 'post258-independent-audit/studio-raw-audit.json',
        'post258-studio-qualification.json': BASE / 'studio-mail-post258-validation/qualification.json',
    })
for name, path in copies.items():
    shutil.copyfile(path, RECEIPTS / name)
main_audit = read(BASE / '.runtime/latest-main-258-audit/audit.json')
crossreview = {
    'source_checkpoint': SOURCE,
    'incoming_main': MAIN,
    'reviews_are_readonly_not_execution_credit': True,
    'native_union_review': main_audit['native_union_review'],
    'ews_union_review': main_audit['ews_union_review'],
    'source_audit_sha256': sha(BASE / '.runtime/latest-main-258-audit/audit.json'),
    'source_audit_archive_path': 'integration/latest-main-258/audit.json',
}
write(RECEIPTS / 'post258-cross-review-summary.json', crossreview)

mail_cohorts = []
for name, row in sorted(audit['completed_cohorts'].items()):
    if name == 'engine-boundary':
        continue
    mail_cohorts.append({
        'name': name, 'passed': row['passed'], 'failed': row['failed'],
        'skipped': row['skipped'], 'suites': row['suites'],
        'receipt': 'receipts/post258-' + name + '-qualification.json',
        'reporter_sha256': row['reporter_sha256'],
        'complete_successful_reporter_lifecycles': row['qualified'],
    })
index = read(OUT / 'evidence-index.json')
qualification = {
    'schema_version': 2,
    'updated_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'main258_integrated_fresh_mail_and_boundary_passed_studio_pending',
    'qualified': False,
    'source': {
        'canonical_source_commit': SOURCE, 'latest_published_source_commit': SOURCE,
        'local_source_alias': ALIAS, 'identical_tree': TREE,
        'integrated_remote_main': MAIN, 'final_source_freeze_status': 'frozen_pending_full113_studio',
    },
    'integration': {
        'captured_observations': 298, 'captured_unique_commits': 120,
        'all_captured_commits_ancestors': True, 'integrated_main_is_ancestor': True,
        'verified_at_source': SOURCE, 'latest_main_integrated': MAIN,
        'receipt': 'receipts/post258-frozen-source-proof.json',
        'intake_boundary': 'Initial and later recorded snapshots; no claim about refs created after the boundary.',
        'merge_decisions': 'receipts/post258-root-merge-resolution.json',
        'independent_cross_reviews': 'receipts/post258-cross-review-summary.json',
        'atomic_account_cas_preserved': 'receipts/post258-cas-preservation.json',
    },
    'accounting': {
        'retained_passing_cases': 2856, 'retained_suites': 67,
        'fresh_completed_passing_cases': 2855, 'fresh_completed_suites': 127,
        'completed_scope_passing_subtotal': 5711,
        'final_combined_passing_cases': None, 'final_combined_suites': None,
        'failed_in_completed_credited_scopes': 0, 'skipped_in_completed_credited_scopes': 0,
        'pending_fresh_studio_suites': 113, 'pending_fresh_studio_cases': None,
        'portable_corpus_cases_counted_separately': 174,
        'principle': 'Count each suite/platform/test execution once. Retain only 2,805 engine cases from 64 unchanged suites and 51 editor cases from 3 unchanged suites by transitive source/config/resource proof. Replace the 94 changed engine boundary cases, every older Mail shared/store case and every older Studio case with fresh post258 results. Historical receipts never add duplicate credit.',
    },
    'retained': {
        'status': 'bound_to_frozen_union_by_exact_scoped_inputs',
        'cases': 2856, 'suites': 67, 'fresh_executions': 0,
        'engine': {'cases': 2805, 'suites': 64, 'replaced_boundary_cases': 94,
                   'changed_entrypoint_excluded_and_unreachable': True,
                   'local_reachable_dart_files': 494},
        'editor': {'cases': 51, 'suites': 3, 'local_reachable_dart_files': 505},
        'unchanged_resource_files': 207, 'unchanged_scoped_config_files': 11,
        'all_relevant_source_config_resource_inputs_match': True,
        'repository_trees_identical': False,
        'normalization_bridge_required': False,
        'receipt': 'receipts/post258-retained-engine-editor.json',
        'independent_review': 'receipts/post258-retention-independent-review.json',
        'dependency_graph_archive_path': 'post258-retained/dependency-graphs.json',
    },
    'fresh_gates': {
        'mail_shared_store': {
            'status': 'qualified', 'passed': 2761, 'failed': 0, 'skipped': 0,
            'suites': 126, 'cohorts': mail_cohorts,
            'input_counts': audit['input_counts'],
            'all_before_after_current_inputs_equal': True,
            'independent_raw_and_input_audit': 'receipts/post258-completed-cohorts.json',
        },
        'engine_boundary': {
            'status': 'qualified', 'passed': 94, 'failed': 0, 'skipped': 0, 'suites': 1,
            'entrypoint': 'packages/quds_office_engine/test/word_zotero_boundary_formatting_test.dart',
            'replaces_all94_previous_cases_from_same_entrypoint': True,
            'receipt': 'receipts/post258-engine-boundary-qualification.json',
        },
        'studio_mail': {'status': 'pending', 'qualified': False, 'expected_suites': 113,
                        'passed': None, 'failed': None, 'skipped': None,
                        'replaces_all_previous2368_cases': True},
        'static': {'status': 'passed', 'fresh_dart_paths': 57,
                   'retained_engine_dart_paths': 38, 'total_changed_dart_paths': 95,
                   'exact_changed_path_union_verified': True,
                   'fresh_receipt': 'receipts/post258-static-qualification.json',
                   'independent_audit': 'receipts/post258-static-union-audit.json'},
    },
    'superseded_pre258_qualification': {
        'source': '9ce2b057ed8fac6bf6746a1700a6b3ca84f7f405',
        'evidence_checkpoint': 'b25acd58cb31f1910e96a031b465bfeb5a683e35',
        'historically_qualified_cases': 8040, 'historically_qualified_suites': 302,
        'receipt': 'receipts/pre258-qualification.json',
        'old_mail2722_current_credit': 0, 'old_studio2368_current_credit': 0,
        'old_studio14_retained459_current_credit': 0,
        'original_failed18_process_remains_failed': True,
        'only_unchanged_engine2805_and_editor51_are_retained_currently': True,
    },
    'portability': {
        'status': 'retained_by_unchanged_engine_tool_resource_runtime_inputs',
        'corpus_adapter_cases': 174, 'corpus_raw_vm_node_bytes_identical': True,
        'corpus_sha256': '7836c5c824b9585d17b7818f1dc7271e061340ec0202acda8f30121d9ced9e8b',
        'ordinary_bas_json_canonical_equal': True, 'ordinary_bas_raw_bytes_equal': False,
        'finite_integral_number_encoding_differences': 58, 'other_semantic_differences': 0,
        'bas_canonical_sha256': '0bbdfe5579a2604573d57f2c20727b1bd986d5c2c76b190572be633079bc4480',
        'receipt': 'receipts/final-ab-portability-audit.json',
        'source_binding': 'receipts/post258-retained-engine-editor.json',
        'added_to_test_case_total': False,
    },
    'development_history': {
        'receipts_preserved': True,
        'pre258_complete_report_archive': 'development/pre258-qualified-evidence/README.md',
        'previous_engine_normalization_bridge_currently_required': False,
        'all_failed_interrupted_superseded_mail_studio_runs_current_credit': 0,
        'framing': 'ASCII LF byte-delimited JSON records only; Unicode line separators inside strings are not record boundaries.',
    },
    'evidence_archive': {
        'status': 'pre258_archive_preserved_post258_refresh_pending_studio_completion',
        'path': 'local-evidence.tar.xz', 'index': 'evidence-index.json',
        'current_archive_sha256': index['archive_sha256'],
        'current_archive_bytes': index['archive_bytes'],
        'current_archive_files': len(index['files']),
        'archive_current_source_qualification_complete': False,
    },
    'publication': {'work_branch': 'work/mail-account-workspace-20261122',
                    'source_checkpoint_saved_remotely': True,
                    'final_main_merge_confirmed': False},
    'limitations': old['limitations'],
    'github_actions_queried': False, 'github_actions_waited': False,
}
qualification['receipt_sha256'] = {
    p.relative_to(OUT).as_posix(): sha(p) for p in sorted(RECEIPTS.iterdir()) if p.is_file()
}
if aggregate:
    archive_members = {row['path'] for row in index['files']}
    assert 'post258-studio/qualification.json' in archive_members
    assert 'post258-audit/aggregate-qualification.json' in archive_members
    assert index['includes_final_studio_evidence']
    qualification['status'] = 'qualified_at_df8571cb_after_main258_integration'
    qualification['qualified'] = True
    qualification['source']['final_source_freeze_status'] = 'frozen_integrated_candidate_qualified'
    qualification['accounting'].update({
        'fresh_completed_passing_cases': aggregate['fresh_cases'],
        'fresh_completed_suites': aggregate['fresh_suites'],
        'completed_scope_passing_subtotal': aggregate['passing_cases'],
        'final_combined_passing_cases': aggregate['passing_cases'],
        'final_combined_suites': aggregate['suite_executions'],
        'pending_fresh_studio_suites': 0,
        'pending_fresh_studio_cases': 0,
        'final_aggregate_receipt': 'receipts/post258-final-aggregate.json',
    })
    qualification['fresh_gates']['studio_mail'] = {
        'status': 'qualified', 'qualified': True,
        'passed': aggregate['fresh_studio_cases'], 'failed': 0, 'skipped': 0,
        'suites': 113, 'fresh_suites': 113, 'retained_suites': 0,
        'replaces_all_previous2368_cases': True,
        'captured_inputs': aggregate['studio_input_count'],
        'all_before_after_current_inputs_equal': True,
        'receipt': 'receipts/post258-studio-qualification.json',
        'independent_raw_audit': 'receipts/post258-studio-raw-audit.json',
    }
    qualification['evidence_archive'].update({
        'status': 'complete_current_and_historical_evidence',
        'archive_current_source_qualification_complete': True,
        'all_members_verified_by_index': False,
    })
write(OUT / 'qualification.json', qualification)

integration = old_readme[old_readme.index('## Remote intake and incremental preservation'):old_readme.index('## Validation accounting')]
integration = integration.replace('`ab3457c98b6d9a0d1da8147db3048dfc50d174d3`, were integrated before the replacement',
                                  '`ab3457c98b6d9a0d1da8147db3048dfc50d174d3`, were integrated before their replacement')
row_end = '| `9ce2b057ed8fac6bf6746a1700a6b3ca84f7f405` | Four test-entrypoint corrections: typed tooltip lookup, bounded dismissal settlement and serialized replacement-session assertions |'
integration = integration.replace(row_end, row_end + '\n| `b25acd58cb31f1910e96a031b465bfeb5a683e35` | Complete source-bound pre258 evidence: 8,040 passing executions |\n| `df8571cb70e8677660ce6843c26de017f5524c52` | Main `25850fd3`, remembered Archive destinations and preserved account/Outbox ownership |')

intro = '''# Mail account workspace — integration and qualification

## Current status

**Main `25850fd3` is integrated and saved remotely. Fresh Mail and engine-boundary
gates have passed; final qualification remains pending the complete 113-suite
Studio Mail run.** The current frozen source is
`df8571cb70e8677660ce6843c26de017f5524c52`, tree
`696f6bbb5c6deef20e2939ec477b2767dd56bfc1`; local alias
`594a7e502181e6ce2467f1c3163318bfa79a8733` has the same tree.
Its parents are the preserved pre258 evidence checkpoint `b25acd58` and main
`25850fd310910cb6d852f2e3c480dbc8697fe549`.

Completed scopes contain **2,855 fresh passing cases**: 2,761 across six Mail
core/store/transport/UI cohorts, plus 94 changed engine-boundary cases. An
additional **2,856 passing cases are retained**: 2,805 engine cases from 64
unchanged suites and 51 editor cases from three unchanged suites. Their
transitive source, configuration and resource inputs are verified against the
frozen union. All **95 changed Dart paths** are covered by strict analysis and
read-only formatting: 57 fresh paths and 38 unchanged engine paths.

These are completed-scope results, **not a final combined acceptance total**.
All older 2,722 Mail and 2,368 Studio results have zero current credit; the
Archive changes require fresh replacement gates. The full pre258 qualification
of 8,040 cases is preserved as source-bound history at `b25acd58`, including its
explicit 14-suite retention proof. No historical test is counted twice.

See [qualification.json](qualification.json),
[the current source proof](receipts/post258-frozen-source-proof.json),
[fresh raw-reporter/input audit](receipts/post258-completed-cohorts.json), and
[retained engine/editor proof](receipts/post258-retained-engine-editor.json).
The work advances [connected-account navigation](../../roadmaps/mail/connected-account-navigation.md)
and integrates [remembered Archive destinations](../../roadmaps/mail/remembered-archive.md).
Full desktop-client parity remains an open roadmap goal.

'''
body = '''## Current validation accounting

### Fresh gates on the integrated source

| Cohort | Passed | Suites | Status |
| --- | ---: | ---: | --- |
| Mail core, Dart VM | 659 | 29 | Passed |
| Mail SQLite store, Dart VM | 1,187 | 52 | Passed |
| Store browser-error classification, Node | 3 | 1 | Passed |
| Mail transport, Dart VM | 612 | 23 | Passed |
| Mail transport JavaScript boundaries, Node | 6 | 3 | Passed |
| Shared Mail UI, Flutter | 294 | 18 | Passed |
| **Fresh Mail subtotal** | **2,761** | **126** | **Zero failures or skips** |
| Changed engine boundary-formatting entrypoint | 94 | 1 | Passed; replaces its previous 94 cases |
| Complete Studio Mail scope | Pending | 113 | Full replacement run pending |

Every completed fresh process exited zero and produced one successful final
reporter event. Independent LF-byte parsing verifies the full declared suite
inventory, complete per-test lifecycle, exact case inventories and no failures,
skips, orphan completions, duplicate IDs or malformed JSON records. Known
literal `Running build hooks...` prefixes are recorded explicitly rather than
silently accepting arbitrary non-JSON output.

All **6,342 workspace inputs, 6,200 resolved-package inputs and four runtime
inputs** match before, after, between completed cohorts and at independent
verification. Tracked Git blobs match the frozen checkpoint. Commands, stderr,
raw JSONL, case inventories and artifact hashes are retained in the evidence.
The [independent audit](receipts/post258-completed-cohorts.json) links each
completed cohort to its exact reporter and input-manifest hashes.

### Retained engine and editor scopes

| Retained scope | Passing cases | Suites | Evidence boundary |
| --- | ---: | ---: | --- |
| Word/VBA/Zotero/ODT/revision/style/table engine, excluding changed boundary test | 2,805 | 64 | Successful original 65-suite gate, with all 94 changed-entrypoint cases removed |
| Editor Zotero integration | 51 | 3 | Successful original editor gate; reachable source and configuration unchanged |
| **Retained total** | **2,856** | **67** | **No fresh executions claimed** |

The engine production library is unchanged by main 258. Its only executable
delta is one boundary-test entrypoint using independent constant expectations;
that entire 94-case suite is rerun fresh. A CHANGELOG paragraph also moved.
The retained engine graph reaches 494 repository Dart files; the editor graph
reaches 505. Complete import/export/part graphs follow all conditional URI
branches. Neither retained scope can reach the changed test entrypoint.
All 207 captured fixture/macro resources and 11 scoped configuration inputs
are unchanged, as are the pinned runtime and locked dependencies.

The original engine run captured 1,421 inputs. Only the excluded boundary
entrypoint differs. The editor's earlier broad workspace snapshot includes
changed Mail files, but its actual dependency graph reaches none of them;
the proof does not pretend the entire repository tree stayed identical.
Original successful reporter lifecycles, exact retained case lists, graph
hashes and current-source bindings are preserved in
[the retention receipt](receipts/post258-retained-engine-editor.json).
An [independent review](receipts/post258-retention-independent-review.json)
recomputed both closures and exactly matched the retained raw-case multisets.
No AST normalization bridge is required for these retained scopes.

### Static coverage

All 57 fresh paths pass `dart analyze --fatal-infos --fatal-warnings` and
read-only formatting. The other 38 engine paths retain their passing analysis
and format results by exact path, engine-production and configuration equality.
The two sets are disjoint and their union exactly matches all 95 Dart paths
changed from initial main. The pinned formatter also examined the full union
without changes. See [the fresh static receipt](receipts/post258-static-qualification.json)
and [independent path/input audit](receipts/post258-static-union-audit.json).

## Preserved integration behavior

The final main union retains the atomic account compare-and-set implementation
and its regression test byte-for-byte. Selected-account refresh validates the
same identity, revision and connection timestamp in one SQLite write; a stale
request cannot recreate a removed or replaced shortcut or consume metadata on
conflict. See [the exact CAS preservation record](receipts/post258-cas-preservation.json).

Native and EWS admission still serialize draft-store opening, restoration,
cache selection and account refresh. A failed observer or owner close remains
held until explicit cleanup succeeds. Observer retirement starts before waiting
for a pending first snapshot, and generation/identity fences reject stale
callbacks. Full send operations retain their exact owner through the final
durable outcome receipt, including compose, manual/scheduled Outbox and
acknowledged retry paths. A network reply alone does not end ownership.

Remembered Archive destinations add an account-local exact folder preference
for IMAP, EWS and Microsoft 365. The saved folder is validated against a fresh
provider catalog **before confirmation**. After confirmation, the saved
revision and destination are reloaded **before dispatch** into the durable
Move journal. Settings support save, change, clear and missing-folder repair.
Gmail retains its Inbox-label removal behavior. Schema 17 persistence preserves
migration/journal data and account-removal cleanup.

The bounded independent native/EWS reviews found no additional concrete defect
in the union; reviews supply no test-case credit. Their ownership reasoning and
the root's resolution decisions are recorded in
[the cross-review summary](receipts/post258-cross-review-summary.json) and
[merge-resolution receipt](receipts/post258-root-merge-resolution.json).

## Historical qualification and repairs

The complete pre258 source `9ce2b057` qualified **8,040 passing executions
across 302 suite executions**: 2,899 engine, 51 editor, 2,368 Studio and 2,722
earlier Mail cases. Within its Studio total, 459 cases from 14 independent,
fully successful suites were retained from an 18-suite process that failed
in four other files. All 173 cases in those four files were replaced by a
fresh run, and another 92-suite fresh process passed 1,736 cases. The original
18-suite process retains exit 1 and `done.success = false`.

That complete source-bound report is saved at `b25acd58`; its
[qualification JSON](receipts/pre258-qualification.json) and original README
remain in the evidence. Main258 changes Mail production inputs, so **none of
the old 2,722 Mail or 2,368 Studio results—including the 459-case subset—is
credited to the current union**. Only the explicitly proved 2,805 engine and
51 editor cases carry forward. Older failed, interrupted and superseded runs
remain diagnostic evidence, with no current passing credit.

| Preserved diagnostic | Observed result and repair boundary |
| --- | --- |
| Studio attempt 1 | 132 passes/1 error, child exit 1; retained Refresh callback dereferenced a cleared mailbox. Bound mailbox and identity/generation guards fixed it. |
| Studio attempt 2 | 564 passes/1 error by LF recount; child exit unavailable after parser exception. Captured same-session Disconnect was rejected during modal review, so three moves stayed on the previous provider; no new-session dispatch was shown. Cancellation semantics were repaired. |
| Studio attempt 3 | All 110 suites, 2,329 passes/22 errors/0 skips, child exit 1. Lifecycle and setup/capability/fixture corrections were qualified by subsequent source-bound runs. |
| Studio attempt 4 | Deliberately interrupted after 318 passes/0 observed errors and eight started suites; no final reporter event. Session exit 130, Flutter child exit unavailable. Review found Outbox outcome ownership ended before the final local receipt. |
| Static attempt 5 | Nullable retry-fixture variable found before Studio tests started; nonnullable binding preserved assertions. |
| Studio attempt 6 | 623 passes/9 failures across 18 suites, child exit 1. Four typed tooltip captures, four bounded route-settlement waits and the strict replacement-session assertion were corrected in four test entrypoints. |

Raw JSONL must be framed using **ASCII LF bytes only**. Python `str.splitlines()`
incorrectly split U+0085, U+2028 and U+2029 embedded in three real attachment
filename test names. In attempt 2, their successful IDs 569–571 restore the
incomplete 561 subtotal to 564; they are not hooks or hidden loaders. Attempt 3
similarly restores 2,326 to 2,329. Original raw files and superseded parser
receipts remain preserved. The repaired runner saves child exit status before
parsing and rejects genuinely incomplete or unmatched lifecycles. See
[the framing audit](receipts/studio-reporter-lf-framing-audit.json).

The first incoming engine gate found six stale citation-text fixture
expectations and one parser defect losing opaque `rPrChange` history on field
boundaries. Explicit expected-text overrides retain independent formatting and
structure assertions; parser repair preserves complete original boundary run
properties. Original fixture bytes were unchanged, and five regressions were
added. Later incoming empty-code-run provenance and nine instruction-side
style exclusions remain covered. See [the repair notes](receipts/zotero-repair-notes.json).

The earlier 2,594-case engine gate combined passing VM/analysis results with a
one-test formatter normalization and remaining format/portability checks.
Its proof has identical recursive AST and AST-rendered source with zero parser
diagnostics. One optional map trailing comma was removed; other tokens/comments
match, so no whitespace-only or full-token-byte identity is claimed. That
[normalization bridge](receipts/engine-normalization-bridge.json) is valid
historical evidence, superseded by the later 2,899-case engine scope. The older
2,585, 2,544, initial Word 1,458, focused 82 and provider-development 103 counts
add no cases. The provider 103 run also observed three concurrent Word inputs
change, so it remains development evidence only.

## Portability

The unchanged accepted engine tools/resources retain the complete VM/Node
portability receipts. The canonical Split corpus is raw-byte identical for
**174 adapter cases across Word, Excel and PowerPoint**, SHA-256
`7836c5c824b9585d17b7818f1dc7271e061340ec0202acda8f30121d9ced9e8b`.
Those adapter cases are separate from the Dart test totals.

The BAS smoke uses ordinary `jsonEncode`, so VM integral doubles such as `0.0`
and JavaScript `0` differ in raw bytes. Only finite integral numeric
representations are normalized; all strings, booleans, arrays, structure and
values must otherwise agree. DOCX/DOCM output has exactly 58 such encoding
differences and zero other semantic differences. Canonical SHA-256 is
`0bbdfe5579a2604573d57f2c20727b1bd986d5c2c76b190572be633079bc4480`.
The [independent portability audit](receipts/final-ab-portability-audit.json),
raw outputs and earlier overly strict comparison remain available. This is
retained evidence on unchanged inputs, not a fresh portability execution.

## Evidence and reproduction

[Runtime provenance](runtime-provenance.json) records the unchanged official
Flutter 3.47.8 / Dart 3.13.7 SDK and Node 24.22.3. All 204 required hosted package
archives match lockfile hashes; enforced-lockfile restoration left the
repository lockfile unchanged. No SDK, test framework or compiler source was
patched to obtain results.

Small source/qualification receipts are kept under `receipts/`.
**The current [archive](local-evidence.tar.xz) and [index](evidence-index.json)
still preserve the complete pre258 checkpoint; their post258 refresh is
pending the Studio gate.** Fresh post258 receipts above are already available.
The final archive will preserve raw reporters, complete inventories, exact
input manifests, commands, runtime hashes, all diagnostics and reproduction
scripts without duplicating test credit.

| Archive directory after refresh | Evidence role |
| --- | --- |
| `post258-mail/` | Six fresh Mail cohorts plus the separately counted 94-case boundary suite |
| `post258-studio/`, `post258-static/` | Complete 113-suite Studio gate and 57 fresh static paths |
| `post258-retained/`, `post258-audit/` | Retained engine/editor dependency graphs, case lists, source binding and independent recounts |
| `incoming-engine/`, `editor-zotero/` | Original accepted raw results underpinning retained engine/editor cases |
| `shared-mail/`, `mail-store/`, `studio-mail/`, `studio-carry-forward/` | Historical pre258 Mail/Studio results and prior 14-suite proof; no current case credit |
| `development/` | Earlier engine runs, all failed/interrupted Studio runs, parser diagnostics and complete pre258 report |
| `integration/`, `runners/`, `runtime/` | Exact intake, source/merge audits, reproducible scripts and pinned environment hashes |

Original receipt paths and commands retain their workspace locations. In the
archive, `incoming-engine/` maps to `final-ab-engine`; older b4 normalization
labels map to `development/engine-b4-original-vm-analysis/` and
`development/engine-b4-normalized/`. Compiled JavaScript is a reproducible
intermediate; source, commands, hashes and execution receipts are retained.
No GitHub Actions output is used as evidence.

## Scope and remaining acceptance

No real account credentials, user mail, provider mutations or outbound messages
were used. Live-provider and installed-platform acceptance remain open, as do
simultaneous background accounts, unified live folders and full Outlook,
Thunderbird or eM Client parity. Node execution does not establish browser UI
acceptance. A concrete native SQLite owner memoizes a failed close future;
owners that cannot later close successfully may require a host restart.
Custom owners can recover in process only when their explicit retry succeeds.
This report does not claim the final remote-main merge before it is verified.
'''
if aggregate:
    fresh, total, studio_count = (aggregate['fresh_cases'], aggregate['passing_cases'],
                                 aggregate['fresh_studio_cases'])
    intro = intro.replace(
        '**Main `25850fd3` is integrated and saved remotely. Fresh Mail and engine-boundary\n'
        'gates have passed; final qualification remains pending the complete 113-suite\n'
        'Studio Mail run.**',
        f'**The integrated `df8571cb` candidate is qualified: {total:,} passing test executions\n'
        'across 307 suite executions, with zero failures or skips in accepted scopes.**\n'
        f'This comprises **{fresh:,} fresh executions** and **2,856 retained executions**\n'
        'whose relevant inputs are proved unchanged. Main `25850fd3` is integrated\n'
        'and the source is saved remotely.')
    start = intro.index('Completed scopes contain **2,855 fresh passing cases**:')
    end = intro.index('All older 2,722 Mail and 2,368 Studio results', start)
    intro = intro[:start] + (
        f'Fresh gates pass **2,761 Mail core/store/transport/UI cases**, **94 changed\n'
        f'engine-boundary cases**, and **{studio_count:,} cases across all 113 Studio Mail\n'
        'suites**. Retained results are exactly 2,805 engine cases from 64 unchanged\n'
        'suites and 51 editor cases from three unchanged suites. Transitive source,\n'
        'configuration and resource inputs are verified against the frozen union.\n'
        'All **95 changed Dart paths** are covered by strict analysis/read-only\n'
        'formatting: 57 fresh paths and 38 unchanged engine paths.\n\n'
    ) + intro[end:]
    intro = intro.replace('require fresh replacement gates.', 'are covered by the fresh replacement gates.')
    intro = intro.replace('[fresh raw-reporter/input audit](receipts/post258-completed-cohorts.json), and',
                          '[the final aggregate](receipts/post258-final-aggregate.json),\n'
                          '[fresh raw-reporter/input audit](receipts/post258-completed-cohorts.json), and')
    body = body.replace('| Complete Studio Mail scope | Pending | 113 | Full replacement run pending |',
                        f'| Complete Studio Mail scope | {studio_count:,} | 113 | Passed fresh; replaces every earlier Studio case |')
    marker = '### Retained engine and editor scopes'
    addition = (
        f'The full Studio run passes **{studio_count:,} cases across exactly 113 suites**\n'
        'in one normal Flutter process, with exit zero and a successful final\n'
        f'reporter event. All **{aggregate["studio_input_count"]:,} captured workspace inputs**\n'
        'match before, after and at independent verification. The 6,192 inputs\n'
        'shared with the broader Mail snapshot also match; the 44 Studio-only\n'
        'package publication documents are independently unchanged. Every discovered `*mail*_test.dart`\n'
        'entrypoint is observed exactly once, including the saved-Mail and workspace\n'
        'shortcut suites. See [the Studio receipt](receipts/post258-studio-qualification.json)\n'
        'and [independent raw audit](receipts/post258-studio-raw-audit.json).\n\n'
        '| Accepted accounting group | Passing cases | Suite executions |\n'
        '| --- | ---: | ---: |\n'
        f'| Fresh Mail, changed engine boundary and complete Studio scope | {fresh:,} | 240 |\n'
        '| Retained unchanged engine and editor scopes | 2,856 | 67 |\n'
        f'| **Accepted total at `df8571cb`** | **{total:,}** | **307** |\n\n'
        'The [final aggregate](receipts/post258-final-aggregate.json) verifies unique\n'
        'scope/platform, repository suite path and test-ID identities. The previous\n'
        '94 engine-boundary cases, all previous 2,722 Mail cases and all previous\n'
        '2,368 Studio cases are excluded before fresh replacement. Portability\n'
        'adapter checks remain separate. No display-name coincidence adds or\n'
        'removes a real parameterized test execution.\n\n'
    )
    body = body.replace(marker, addition + marker)
    old_archive = (
        '**The current [archive](local-evidence.tar.xz) and [index](evidence-index.json)\n'
        'still preserve the complete pre258 checkpoint; their post258 refresh is\n'
        'pending the Studio gate.** Fresh post258 receipts above are already available.\n'
        'The final archive will preserve raw reporters, complete inventories, exact\n'
        'input manifests, commands, runtime hashes, all diagnostics and reproduction\n'
        'scripts without duplicating test credit.')
    new_archive = (
        f'The [archive](local-evidence.tar.xz) contains **{len(index["files"]):,} files**\n'
        f'({index["archive_bytes"]:,} bytes); [its index](evidence-index.json) records every\n'
        'member size and SHA-256. Archive SHA-256:\n'
        f'`{index["archive_sha256"]}`.\n'
        'It preserves current raw reporters, complete inventories, exact input\n'
        'manifests, commands, runtime hashes, all diagnostics and reproduction\n'
        'scripts, including the complete historical pre258 report. Historical\n'
        'files add no duplicate test credit.')
    assert old_archive in body
    body = body.replace(old_archive, new_archive).replace('Archive directory after refresh', 'Archive directory')
(OUT / 'README.md').write_text(intro + integration + body)
print(json.dumps({'status': qualification['status'], 'retained_cases': 2856,
                  'fresh_completed_cases': qualification['accounting']['fresh_completed_passing_cases'],
                  'total_cases': qualification['accounting']['final_combined_passing_cases'],
                  'receipt_files': len(qualification['receipt_sha256'])}))
