"""Verify static receipt coverage and input equality without rerunning analysis."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

BASE = Path('/workspace/scratch/7fc035b3e3ba')
ROOT = BASE / 'quds_office_suite'
VALID = BASE / '.runtime/validation'
SOURCE = 'df8571cb70e8677660ce6843c26de017f5524c52'
INITIAL = '659b81462224a40f50975cfbfca39f636538b836'
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
fresh_dir = VALID / 'final-258-mail-static'
fresh = read(fresh_dir / 'qualification.json')
retained = read(VALID / 'post258-retained-scopes/retained-static38.json')
assert fresh['source_commit'] == SOURCE and fresh['status'] == 'passed'
assert fresh['source_unchanged'] and fresh['changed_inputs'] == []
assert {row['name']: row['exit_code'] for row in fresh['commands']} == {'analysis': 0, 'format': 0}
before, after = read(fresh_dir / 'inputs-before.json'), read(fresh_dir / 'inputs-after.json')
assert before == after and set(before) == set(fresh['paths'])
assert all(sha(ROOT / path) == digest for path, digest in before.items())
original_inputs = read(VALID / 'final-ab-engine/inputs-before.json')
assert all(sha(ROOT / path) == original_inputs[path] for path in retained['paths'])
proof = read(VALID / 'post258-retained-scopes/qualification.json')
assert proof['final_source_checkpoint'] == SOURCE
assert proof['all_recorded_dependency_resource_config_hashes_match_final_source']
fresh_paths, retained_paths = set(fresh['paths']), set(retained['paths'])
assert not fresh_paths & retained_paths
changed = set(subprocess.check_output(['git', 'diff', '--name-only', INITIAL, SOURCE, '--', '*.dart'], cwd=ROOT, text=True).splitlines())
assert fresh_paths | retained_paths == changed
assert len(fresh_paths) == 57 and len(retained_paths) == 38 and len(changed) == 95
result = {
    'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_checkpoint': SOURCE,
    'initial_main': INITIAL,
    'qualified': True,
    'fresh_paths': sorted(fresh_paths),
    'retained_paths': sorted(retained_paths),
    'fresh_path_count': len(fresh_paths),
    'retained_path_count': len(retained_paths),
    'total_changed_dart_paths': len(changed),
    'no_overlap': True,
    'union_exactly_matches_git_changed_dart_paths': True,
    'fresh_analysis_and_readonly_format_exit_zero': True,
    'fresh_path_hashes_before_after_current_equal': True,
    'retained_path_hashes_equal_original_accepted_engine': True,
    'retained_engine_production_and_config_inputs_equal': True,
    'fresh_qualification_sha256': sha(fresh_dir / 'qualification.json'),
    'retention_proof_sha256': sha(VALID / 'post258-retained-scopes/qualification.json'),
    'fresh_input_manifest_sha256': sha(fresh_dir / 'inputs-before.json'),
    'no_additional_analysis_or_test_execution': True,
}
out = VALID / 'post258-independent-audit/static-union.json'
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['qualified', 'fresh_path_count', 'retained_path_count', 'total_changed_dart_paths']}))
