"""Retain successful independent suites without relabeling their failed process."""
from pathlib import Path
import collections
import datetime
import hashlib
import importlib.util
import json
import re
import subprocess
from urllib.parse import unquote, urljoin, urlparse

BASE = Path('/workspace/scratch/7fc035b3e3ba')
ROOT = BASE / 'quds_office_suite'
WORKING = ROOT / 'packages/quds_office_editor/example'
OLD = BASE / 'studio-mail-attempt-06/repaired'
OUT = BASE / '.runtime/validation/studio-suite-carry-forward'
DOCS = ROOT / 'docs/validation/mail-account-workspace-20261122/receipts'
OUT.mkdir(exist_ok=True)
TARGET = '9ce2b057ed8fac6bf6746a1700a6b3ca84f7f405'
EXCLUDED = {str(WORKING / 'test' / name) for name in [
    'studio_mail_cloud_test.dart', 'studio_mail_ews_test.dart',
    'studio_mail_outbox_host_test.dart', 'studio_mail_session_test.dart']}
spec = importlib.util.spec_from_file_location('audit', BASE / '.runtime/validation/audit_latest_mail_evidence.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
sha = audit.sha
read = lambda path: json.loads(path.read_bytes())
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def tokens(source):
    """Read directive tokens lazily, including nested comments and Dart strings."""
    i, length = 0, len(source)
    while i < length:
        if source[i].isspace():
            i += 1
            continue
        if source.startswith('//', i):
            end = source.find('\n', i)
            i = length if end < 0 else end + 1
            continue
        if source.startswith('/*', i):
            depth = 1
            i += 2
            while depth and i < length:
                if source.startswith('/*', i):
                    depth += 1
                    i += 2
                elif source.startswith('*/', i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
            assert depth == 0
            continue
        raw = source[i] == 'r' and i + 1 < length and source[i + 1] in "'\""
        if raw or source[i] in "'\"":
            if raw:
                i += 1
            quote = source[i] * (3 if source.startswith(source[i] * 3, i) else 1)
            i += len(quote)
            value = []
            while not source.startswith(quote, i):
                assert i < length
                if not raw and source[i] == '\\':
                    match = re.match(r'\\(?:u\{([0-9a-fA-F]+)\}|u([0-9a-fA-F]{4})|x([0-9a-fA-F]{2})|(.))', source[i:], re.S)
                    assert match
                    groups = match.groups()
                    value.append(chr(int(next(x for x in groups[:3] if x), 16))
                                 if any(groups[:3]) else {'n': '\n', 'r': '\r', 't': '\t'}.get(groups[3], groups[3]))
                    i += len(match.group(0))
                else:
                    value.append(source[i])
                    i += 1
            i += len(quote)
            yield 'string', ''.join(value)
            continue
        match = re.match(r'[A-Za-z_$][A-Za-z0-9_$]*', source[i:])
        if match:
            i += len(match.group(0))
            yield 'word', match.group(0)
        else:
            yield 'punctuation', source[i]
            i += 1


def directives(path):
    stream = iter(tokens(path.read_text()))
    buffered = None
    result = []
    while True:
        item = buffered or next(stream, None)
        buffered = None
        if item is None:
            return result
        if item[1] == '@':
            # Metadata can precede a library directive. Skip its name/arguments.
            item = next(stream, None)
            while item and (item[0] == 'word' or item[1] == '.'):
                item = next(stream, None)
            if item and item[1] == '(':
                depth = 1
                while depth:
                    token = next(stream)
                    if token[0] == 'punctuation':
                        depth += (token[1] == '(') - (token[1] == ')')
                item = next(stream, None)
            buffered = item
            continue
        if item[1] == 'augment':
            item = next(stream, None)
        if item is None or item[1] not in {'library', 'import', 'export', 'part'}:
            return result  # Dart directives precede declarations.
        kind = item[1]
        while True:
            token = next(stream)
            if token == ('punctuation', ';'):
                break
            if token[0] == 'string' and kind != 'library':
                assert '$' not in token[1], 'Interpolated directive URI is unsupported'
                result.append((kind, token[1]))


package_config = ROOT / '.dart_tool/package_config.json'
package_roots = {}
for package in read(package_config)['packages']:
    root_uri = urljoin(package_config.as_uri(), package['rootUri'].rstrip('/') + '/')
    package_roots[package['name']] = Path(unquote(urlparse(urljoin(root_uri, package.get('packageUri', ''))).path))


def resolve(path, uri):
    if uri.startswith('dart:'):
        return None
    if uri.startswith('package:'):
        name, relative = uri[len('package:'):].split('/', 1)
        return (package_roots[name] / unquote(relative)).resolve()
    parsed = urlparse(uri)
    assert parsed.scheme in {'', 'file'}, (path, uri)
    if parsed.scheme == 'file':
        return Path(unquote(parsed.path)).resolve()
    return Path(unquote(urlparse(urljoin(path.as_uri(), uri)).path)).resolve()


receipt = read(OLD / 'qualification.json')
assert receipt['exit_code'] == 1 and receipt['status'] == 'failed'
plan = read(BASE / '.runtime/validation/studio-final-cohorts.json')
expected = {str(WORKING / path) for path in plan['repaired']}
assert len(expected) == 18 and EXCLUDED <= expected
summary, cases = audit.recount(OLD / 'tests.jsonl', expected)
assert summary['passed'] == 623 and summary['failed'] == 9 and summary['skipped'] == 0
assert summary['reporter_done'] == [{'success': False, 'type': 'done', 'time': 332843}]
assert not any(summary[k] for k in ['unfinished_test_ids', 'unmatched_visible_completions',
                                  'duplicate_start_ids', 'duplicate_completion_ids', 'malformed_lf_records',
                                  'missing_suites', 'unexpected_suites'])
starts, suite_ids, groups, errors, finishes = {}, {}, {}, [], {}
for raw in (OLD / 'tests.jsonl').read_bytes().split(b'\n'):
    if not raw.strip():
        continue
    event = json.loads(raw)
    kind = event.get('type')
    if kind == 'suite':
        suite_ids[event['suite']['id']] = event['suite']['path']
    elif kind == 'testStart':
        starts[event['test']['id']] = event['test']
    elif kind == 'testDone':
        finishes[event['testID']] = event
    elif kind == 'group' and event['group'].get('parentID') is None:
        groups[event['group']['suiteID']] = event['group']['testCount']
    elif kind == 'error':
        errors.append(event)
assert len(errors) == 9
assert all(suite_ids[starts[e['testID']]['suiteID']] in EXCLUDED for e in errors)
retained_paths = expected - EXCLUDED
retained_cases = [c for c in cases if c['suite'] in retained_paths]
excluded_cases = [c for c in cases if c['suite'] in EXCLUDED]
assert len(retained_paths) == 14 and len(retained_cases) == 459 and len(excluded_cases) == 173
assert all(c['result'] == 'success' and not c['skipped'] for c in retained_cases)
per_suite = collections.Counter(c['suite'] for c in retained_cases)
for suite_id, path in suite_ids.items():
    if path in retained_paths:
        assert groups[suite_id] == per_suite[path]
        assert all(finishes[tid]['result'] == 'success' and not finishes[tid].get('skipped')
                   for tid, test in starts.items() if test['suiteID'] == suite_id)

before, after = read(OLD / 'inputs-before.json'), read(OLD / 'inputs-after.json')
assert before == after and len(before) == 6224
current = {path: sha(ROOT / path) for path in before}
changed = sorted(path for path in before if before[path] != current[path])
excluded_relative = {Path(path).relative_to(ROOT).as_posix() for path in EXCLUDED}
assert set(changed) == excluded_relative
tracked = set(git('ls-files', '--', 'packages', 'third_party', 'pubspec.yaml', 'pubspec.lock', '.fvmrc', 'analysis_options.yaml').splitlines())
tracked.add('.dart_tool/package_config.json')
assert tracked == set(before)
assert not git('diff', '--name-only', TARGET, '--', 'packages', 'third_party',
               'pubspec.yaml', 'pubspec.lock', '.fvmrc', 'analysis_options.yaml')

graph, pending = {}, [Path(path) for path in sorted(retained_paths)]
while pending:
    path = pending.pop().resolve()
    if str(path) in graph:
        continue
    assert path.is_file(), (str(path), [(parent, edge) for parent, node in graph.items()
                                       for edge in node['directives'] if edge['target'] == str(path)])
    links = []
    for kind, uri in directives(path):
        target = resolve(path, uri)
        links.append({'kind': kind, 'uri': uri, 'target': str(target) if target else None})
        if target is not None:
            assert str(target) not in EXCLUDED, (path, uri)
            pending.append(target)
    graph[str(path)] = {'sha256': sha(path), 'directives': links}
local_paths = []
for path, node in graph.items():
    if Path(path).is_relative_to(ROOT):
        relative = Path(path).relative_to(ROOT).as_posix()
        assert relative in before and before[relative] == node['sha256']
        local_paths.append(relative)
assert not EXCLUDED & set(graph)
# A dynamic file/process dependency would need a source reference rather than a
# directive. Check all reachable source literals as well, and inspect the four
# exact test-only diffs separately; they change no shared fixtures/resources.
referenced_excluded_names = []
for path in graph:
    source = Path(path).read_text()
    for excluded in EXCLUDED:
        if Path(excluded).name in source:
            referenced_excluded_names.append({'source': path, 'name': Path(excluded).name})
assert not referenced_excluded_names
full = {'source_checkpoint': TARGET, 'roots': sorted(retained_paths), 'excluded_entrypoints': sorted(EXCLUDED),
        'local_reachable_paths': sorted(local_paths), 'graph': graph}
graph_path = OUT / 'dependency-graph.json'
graph_path.write_text(json.dumps(full, indent=2) + '\n')
result = {
    'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'retained_suite_evidence_qualified': True, 'source_checkpoint': TARGET,
    'original_process_source': receipt['head_at_start'], 'original_process_exit_code': 1,
    'original_process_reporter_done_success': False, 'original_process_qualified': False,
    'original_process_passed': 623, 'original_process_failed': 9,
    'original_process_suites': 18, 'original_process_inputs': 6224,
    'original_process_before_after_inputs_identical': True,
    'retained_passed_cases': 459, 'retained_failed_cases': 0, 'retained_skipped_cases': 0,
    'retained_suites': 14,
    'retained_suite_paths': sorted(Path(path).relative_to(WORKING).as_posix() for path in retained_paths),
    'per_suite_cases': {Path(path).relative_to(WORKING).as_posix(): count for path, count in sorted(per_suite.items())},
    'all_retained_declared_root_group_counts_match_complete_cases': True,
    'all_retained_started_tests_and_hidden_hooks_complete_successfully': True,
    'all_nine_errors_confined_to_four_excluded_suites': True,
    'excluded_suite_paths': sorted(Path(path).relative_to(WORKING).as_posix() for path in EXCLUDED),
    'excluded_case_count': 173, 'excluded_previous_passes': 164, 'excluded_previous_errors': 9,
    'excluded_cases_credited': 0,
    'full_current_input_inventory_matches': True,
    'changed_inputs': changed, 'all_other_6220_captured_inputs_identical': True,
    'directive_graph_nodes': len(graph), 'local_directive_graph_nodes': len(local_paths),
    'includes_conditional_import_export_part_branches': True,
    'excluded_entrypoints_reachable': [], 'excluded_filename_references_in_reachable_sources': [],
    'graph_sha256': sha(graph_path), 'graph_archive_path': 'studio-carry-forward/dependency-graph.json',
    'package_configuration_sha256': sha(package_config),
    'runtime_boundary': 'Same unmodified pinned Flutter/Dart and verified locked package cache as the original run; SDK dart: libraries are stable terminal dependencies.',
    'dependency_scope': 'Transitive local and external Dart import/export/part graph, including conditional branches; complete original/current captured input comparison; literal excluded-filename scan over every reachable source; manual four-entrypoint diff review confirms no shared resource/fixture mutation.',
    'raw_reporter_sha256': sha(OLD / 'tests.jsonl'),
    'original_receipt_sha256': sha(OLD / 'qualification.json'),
    'original_before_manifest_sha256': sha(OLD / 'inputs-before.json'),
    'original_after_manifest_sha256': sha(OLD / 'inputs-after.json'),
    'no_extra_test_executions': True,
    'counting': 'Retain only the14 complete independent successful suites. The18-suite process stays failed. Replace every case from all four excluded suite files with fresh execution; no case from them is carried.',
}
encoded = json.dumps(result, indent=2) + '\n'
(OUT / 'qualification.json').write_text(encoded)
(DOCS / 'studio-fourteen-suite-carry-forward.json').write_text(encoded)
(OUT / 'retained-cases.json').write_text(json.dumps(retained_cases, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['retained_suite_evidence_qualified', 'retained_passed_cases',
      'retained_suites', 'excluded_case_count', 'directive_graph_nodes', 'local_directive_graph_nodes']}))
