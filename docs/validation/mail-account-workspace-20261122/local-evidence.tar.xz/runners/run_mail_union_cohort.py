#!/usr/bin/env python3
"""Run one explicitly planned Mail cohort without reusing earlier output.

Ordinary Dart/Flutter runners are retained. Reporter framing is LF-only; the
known Dart build-hook prefix is recorded separately instead of discarding JSON
events that share its line. Every accepted case has one start and completion.
"""

from __future__ import annotations

import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from urllib.parse import unquote, urljoin, urlparse


ROOT = Path("/workspace/scratch/7fc035b3e3ba/quds_office_suite")
HERE = Path(__file__).resolve().parent
PLAN = HERE / "mail-union-cohorts.json"
GIT_ENV = dict(os.environ, GIT_NO_LAZY_FETCH="1")


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True) + "\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, env=GIT_ENV)


def tracked_paths():
    paths = []
    for raw in git("ls-files", "-z", "--", "packages", "third_party", "tools",
                   "tool", "pubspec.yaml", "pubspec.lock", "pubspec_overrides.yaml",
                   ".fvmrc", "analysis_options.yaml").split(b"\0"):
        if not raw:
            continue
        path = raw.decode()
        parts = Path(path).parts
        # Publication documentation is independent of executable source.
        if len(parts) == 3 and parts[0] == "packages" and parts[2] in {
            "README.md", "CHANGELOG.md", "LICENSE", "LICENSE.md"
        }:
            continue
        if "docs" in parts:
            continue
        paths.append(path)
    paths.append(".dart_tool/package_config.json")
    for extra in [".dart_tool/package_graph.json", "pubspec_overrides.yaml"]:
        if (ROOT / extra).is_file():
            paths.append(extra)
    return sorted(set(paths))


def expected_tree(ref):
    result = {}
    for raw in git("ls-tree", "-r", "-z", ref).split(b"\0"):
        if raw:
            meta, path = raw.split(b"\t", 1)
            mode, kind, sha = meta.decode().split()
            if kind == "blob":
                result[path.decode()] = (mode, sha)
    return result


def file_record(path):
    if path.is_symlink():
        if not path.resolve().is_relative_to(ROOT):
            raise RuntimeError("Source symlink escapes the workspace: " + str(path))
        data = os.readlink(path).encode()
        mode = "120000"
    else:
        data = path.read_bytes()
        mode = "100755" if path.stat().st_mode & 0o111 else "100644"
    return {
        "sha256": digest(data),
        "bytes": len(data),
        "git_blob": hashlib.sha1(
            b"blob " + str(len(data)).encode() + b"\0" + data
        ).hexdigest(),
        "mode": mode,
    }


def capture(ref):
    tree = expected_tree(ref)
    workspace = {}
    for name in tracked_paths():
        record = file_record(ROOT / name)
        expected = tree.get(name)
        record["expected_git_blob"] = None if expected is None else expected[1]
        record["matches_expected_head"] = (
            None if expected is None else record["git_blob"] == expected[1]
        )
        workspace[name] = record
    config = ROOT / ".dart_tool/package_config.json"
    packages = json.loads(config.read_text())["packages"]
    resolved = {}
    for package in packages:
        uri = urlparse(urljoin(config.as_uri(), package["rootUri"]))
        if uri.scheme != "file":
            raise RuntimeError("Unsupported package root: " + uri.scheme)
        package_root = Path(unquote(uri.path)).resolve()
        if package_root.is_relative_to(ROOT):
            continue
        names = set()
        for subtree in ["lib", "bin", "hook"]:
            directory = package_root / subtree
            if directory.is_dir():
                names.update(p for p in directory.rglob("*") if p.is_file())
        manifest = package_root / "pubspec.yaml"
        if manifest.is_file():
            names.add(manifest)
        for path in sorted(names):
            data = path.read_bytes()
            key = package["name"] + "/" + path.relative_to(package_root).as_posix()
            resolved[key] = {
                "path": str(path),
                "bytes": len(data),
                "sha256": digest(data),
            }
    runtime = {}
    flutter = Path(os.environ["FLUTTER_ROOT"])
    runtime_paths = [
        flutter / "bin/cache/dart-sdk/version",
        flutter / "bin/cache/flutter.version.json",
        flutter / "bin/cache/dart-sdk/bin/dart",
        flutter / "bin/cache/dart-sdk/bin/dartaotruntime",
    ]
    for path in runtime_paths:
        if path.is_file():
            data = path.read_bytes()
            runtime[str(path)] = {"bytes": len(data), "sha256": digest(data)}
    return {"workspace": workspace, "resolved_packages": resolved, "runtime": runtime}


def changes(before, after):
    result = {}
    for section in before:
        result[section] = [
            path for path in sorted(set(before[section]) | set(after[section]))
            if before[section].get(path) != after[section].get(path)
        ]
    return result


def parse_reporter(path, working, expected_suites):
    starts, completions, suites = {}, {}, {}
    errors, done, bad_lines, prefixes = [], [], [], []
    duplicate_starts, duplicate_completions = [], []
    with path.open("rb") as stream:
        for number, raw in enumerate(stream, 1):  # Binary iteration splits LF only.
            line = raw[:-1] if raw.endswith(b"\n") else raw
            if not line.strip():
                continue
            prefix = re.match(rb"^(?:Running build hooks\.\.\.)+", line)
            if prefix:
                prefixes.append({"line": number, "prefix": prefix[0].decode()})
                line = line[prefix.end():]
                if not line.strip():
                    continue
            try:
                event = json.loads(line)
            except (ValueError, UnicodeDecodeError):
                bad_lines.append({
                    "line": number, "sha256": digest(raw),
                    "prefix": raw[:180].decode("utf-8", errors="replace"),
                })
                continue
            kind = event.get("type")
            if kind == "suite":
                suite = event["suite"]
                suites[suite["id"]] = suite
            elif kind == "testStart":
                test = event["test"]
                if test["id"] in starts:
                    duplicate_starts.append(test["id"])
                starts[test["id"]] = test
            elif kind == "testDone":
                identifier = event["testID"]
                if identifier in completions:
                    duplicate_completions.append(identifier)
                completions[identifier] = event
            elif kind == "error":
                errors.append(event)
            elif kind == "done":
                done.append(event)
    cases = []
    orphan_completions = sorted(set(completions) - set(starts))
    incomplete = sorted(set(starts) - set(completions))
    unknown_suites = []
    for identifier, completion in completions.items():
        test = starts.get(identifier)
        if test is None:
            continue
        if (completion.get("hidden", False) or
                test["name"].endswith(("(setUpAll)", "(tearDownAll)"))):
            continue
        suite = suites.get(test["suiteID"])
        if suite is None:
            unknown_suites.append(identifier)
            continue
        suite_path = Path(suite["path"])
        if suite_path.is_absolute():
            suite_path = suite_path.relative_to(working)
        cases.append({
            "id": identifier,
            "suiteID": test["suiteID"],
            "suite": suite_path.as_posix(),
            "name": test["name"],
            "result": completion["result"],
            "skipped": completion.get("skipped", False),
        })
    observed = set()
    for suite in suites.values():
        path = Path(suite["path"])
        if path.is_absolute():
            path = path.relative_to(working)
        observed.add(path.as_posix())
    per_suite = {}
    for case in cases:
        counter = per_suite.setdefault(case["suite"], collections.Counter())
        category = ("skipped" if case["skipped"] else
                    "passed" if case["result"] == "success" else "failed")
        counter[category] += 1
    counts = {
        key: sum(values[key] for values in per_suite.values())
        for key in ["passed", "failed", "skipped"]
    }
    report = {
        **counts, "suite_count": len(observed), "observed_suites": sorted(observed),
        "per_suite": {name: dict(count) for name, count in sorted(per_suite.items())},
        "missing_suites": sorted(set(expected_suites) - observed),
        "unexpected_suites": sorted(observed - set(expected_suites)),
        "incomplete_test_ids": incomplete,
        "orphan_completion_ids": orphan_completions,
        "duplicate_start_ids": duplicate_starts,
        "duplicate_completion_ids": duplicate_completions,
        "unknown_suite_ids": unknown_suites,
        "reporter_errors": errors,
        "reporter_done": done,
        "recorded_build_hook_prefixes": prefixes,
        "invalid_json_lines": bad_lines,
    }
    report["protocol_complete"] = (
        len(done) == 1 and done[0].get("success") is True
        and not any(report[key] for key in [
            "missing_suites", "unexpected_suites", "incomplete_test_ids",
            "orphan_completion_ids", "duplicate_start_ids",
            "duplicate_completion_ids", "unknown_suite_ids",
            "reporter_errors", "invalid_json_lines",
        ])
    )
    return report, sorted(cases, key=lambda item: item["id"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    plan = json.loads(PLAN.read_text())
    cohort = plan["cohorts"][args.cohort]
    directory = args.output.resolve()
    directory.mkdir(parents=True, exist_ok=False)
    working = ROOT / "packages" / cohort["package"]
    command = cohort["command"] + cohort["suites"]
    before = capture(args.expected_head)
    write_json(directory / "inputs-before.json", before)
    mismatch = [
        path for path, record in before["workspace"].items()
        if record["matches_expected_head"] is False
    ]
    if mismatch:
        write_json(directory / "qualification.json", {
            "qualified": False, "reason": "Source differs from expected commit",
            "mismatched_inputs": mismatch, "commands_executed": [],
        })
        return 1
    receipt = {
        "cohort": args.cohort, "started_at_utc": now(),
        "expected_head": args.expected_head,
        "head_at_start": git("rev-parse", "HEAD").decode().strip(),
        "command": command, "cwd": str(working),
        "expected_suites": cohort["suites"],
        "expected_passes": cohort["expected_passes"],
        "input_counts": {key: len(value) for key, value in before.items()},
        "capture_scope": plan["capture_scope"],
        "runner_sha256": digest(Path(__file__).read_bytes()),
        "plan_sha256": digest(PLAN.read_bytes()),
        "environment": {key: os.environ.get(key) for key in [
            "CI", "FLUTTER_ROOT", "PUB_CACHE", "TMPDIR",
            "DART_SUPPRESS_ANALYTICS", "FLUTTER_SUPPRESS_ANALYTICS",
        ]},
        "executables": {key: shutil.which(key) for key in ["dart", "flutter", "node"]},
        "github_actions_queried": False, "github_actions_waited": False,
    }
    write_json(directory / "command.json", receipt)
    print(json.dumps({"started": args.cohort, "input_counts": receipt["input_counts"]}), flush=True)
    interrupted = False
    with (directory / "tests.jsonl").open("wb") as stdout, (
        directory / "stderr.log"
    ).open("wb") as stderr:
        process = subprocess.Popen(command, cwd=working, stdout=stdout, stderr=stderr)
        try:
            exit_code = process.wait()
        except KeyboardInterrupt:
            interrupted = True
            process.terminate()
            try:
                exit_code = process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                exit_code = process.wait()
    after = capture(args.expected_head)
    write_json(directory / "inputs-after.json", after)
    report, cases = parse_reporter(directory / "tests.jsonl", working, cohort["suites"])
    write_json(directory / "test-cases.json", cases)
    difference = changes(before, after)
    receipt.update({
        "finished_at_utc": now(),
        "head_at_end": git("rev-parse", "HEAD").decode().strip(),
        "exit_code": exit_code, "interrupted": interrupted,
        "changed_inputs": difference, "source_unchanged": not any(difference.values()),
        "results": report,
        "expected_case_count_matches": report["passed"] == cohort["expected_passes"],
        "runner_unchanged": receipt["runner_sha256"] == digest(Path(__file__).read_bytes()),
        "plan_unchanged": receipt["plan_sha256"] == digest(PLAN.read_bytes()),
        "artifact_sha256": {
            name: digest((directory / name).read_bytes()) for name in [
                "tests.jsonl", "stderr.log", "test-cases.json",
                "inputs-before.json", "inputs-after.json", "command.json",
            ]
        },
    })
    receipt["qualified"] = (
        exit_code == 0 and not interrupted and receipt["source_unchanged"]
        and report["protocol_complete"] and report["failed"] == 0
        and report["skipped"] == 0 and receipt["expected_case_count_matches"]
        and receipt["runner_unchanged"] and receipt["plan_unchanged"]
    )
    write_json(directory / "qualification.json", receipt)
    print(json.dumps({
        "cohort": args.cohort, "qualified": receipt["qualified"],
        "exit_code": exit_code, "source_unchanged": receipt["source_unchanged"],
        **{key: report[key] for key in ["passed", "failed", "skipped", "suite_count"]},
    }), flush=True)
    return 0 if receipt["qualified"] else 1


if __name__ == "__main__":
    sys.exit(main())
