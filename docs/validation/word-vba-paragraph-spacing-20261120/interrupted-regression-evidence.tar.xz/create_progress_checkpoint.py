#!/usr/bin/env python3
"""Save completed evidence and interrupted diagnostics without changing HEAD/index/worktree."""
import datetime,hashlib,io,json,os,subprocess,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent.parent
repo=root/'quds_office_suite';runtime=root/'runtime';out=runtime/'progress-checkpoint-files';out.mkdir(exist_ok=True)
base='docs/validation/word-vba-paragraph-spacing-20261120/'
def sha(b):return hashlib.sha256(b).hexdigest()
def archive(name,files,metadata):
 members={}
 for path,source in files.items():
  data=source.read_bytes();members[path]={'bytes':len(data),'sha256':sha(data),'mode':'0755' if source.stat().st_mode&0o111 else '0644'}
 manifest={'metadata':metadata,'files':members}
 encoded=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
 index=out/(name+'-members.json');index.write_bytes(encoded)
 dest=out/(name+'.tar.xz')
 with tarfile.open(dest,'w:xz',format=tarfile.PAX_FORMAT,preset=6) as tar:
  for path,source in sorted(files.items()):
   data=source.read_bytes();info=tarfile.TarInfo(path);info.size=len(data);info.mode=int(members[path]['mode'],8);info.mtime=0;tar.addfile(info,io.BytesIO(data))
  info=tarfile.TarInfo('members.json');info.size=len(encoded);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(encoded))
 with tarfile.open(dest,'r:xz') as tar:
  assert set(tar.getnames())==set(members)|{'members.json'}
  for path,entry in members.items():
   data=tar.extractfile(path).read();assert len(data)==entry['bytes'] and sha(data)==entry['sha256']
  assert tar.extractfile('members.json').read()==encoded
 receipt={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'member_count':len(members)+1,'member_index_sha256':sha(encoded),'all_members_verified':True,**metadata}
 (out/(name+'-packaging.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 return [(dest,dest.name),(index,index.name),(out/(name+'-packaging.json'),name+'-packaging.json')]
files={str(p.relative_to(runtime)):p for p in (runtime/'word-spacing-final-0201b549').rglob('*') if p.is_file()}
for observation in (runtime/'word-spacing-interrupted-observation').rglob('*'):
 if observation.is_file():files[str(observation.relative_to(runtime))]=observation
for name in ['create_progress_checkpoint.py','run_word_spacing_full_gate.py','word-spacing-final-launch.stdout','word-spacing-final-launch.stderr']:
 p=runtime/name
 if p.is_file():files[name]=p
publish=archive('interrupted-regression-evidence',files,{'publication_acceptance':False,'regression_total_contribution':0,'source_commit':'0201b549d0dc3f601c50e36255d557034cb01699','completed_visible_cases':2679,'observed_suites':64,'terminal_done_present':False,'process_exit_receipt_present':False,'reason':'Coordinator process no longer existed; no observed test failure. Complete bounded-batch rerun required.'})
mac=root/'macos-build-correction-20261120'
files={}
for p in mac.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(mac)
 if rel.parts[0]=='bash-3.2' or p.name=='bash-3.2.tar.gz':continue
 files['candidate/'+str(rel)]=p
for p in (root/'intake-review').rglob('*'):
 if p.is_file() and (p.name.startswith('late-') or p.name in ['review_macos_correction.py','apple-vtool-source-reference.json'] or 'late-macos-independent' in p.parts):
  files['independent-review/'+str(p.relative_to(root/'intake-review'))]=p
publish+=archive('late-intake-evidence',files,{'word_regression_total_contribution':0,'candidate_sha256':'8592dd41fb59da7fa3ead05287005cfa06d90c02bb5de495e9f985062ffff904','producer_isolated_checks':61,'independent_expectations':36,'actual_macos_build':False,'actual_bash3_execution':False,'excluded_recreatable_third_party_setup':['bash-3.2/','bash-3.2.tar.gz']})
for src,name in [
 (runtime/'line-spacing-portable-static-final.tar.xz','portable-static-evidence.tar.xz'),
 (runtime/'line-spacing-portable-static-members.json','portable-static-members.json'),
 (runtime/'line-spacing-portable-static-packaging.json','portable-static-packaging.json'),
 (runtime/'line-spacing-development-review.tar.xz','development-review-evidence.tar.xz'),
 (runtime/'line-spacing-development-review/members.json','development-review-members.json'),
 (runtime/'line-spacing-development-review/packaging.json','development-review-packaging.json'),
 (root/'intake-review/source-review.json','source-review.json'),
 (root/'intake-review/source-review.md','source-review.md'),
 (root/'intake-review/late-intake-review.json','late-intake-review.json'),
 (root/'intake-review/late-intake-review.md','late-intake-review.md'),
 (runtime/'publication-intake-before-reconciliation.json','publication-intake-before-reconciliation.json'),
 (runtime/'publication-fork-refs.txt','late-captured-fork-refs.txt'),
 (runtime/'publication-upstream-refs.txt','late-captured-upstream-refs.txt'),
]:publish.append((src,name))
note=out/'progress-checkpoint.md'
note.write_text('''# Historical progress checkpoint — 20 November 2026

This checkpoint preserves completed evidence while qualification remains in progress.
It is not a final regression acceptance or a statement that incoming heads were merged.

The Word source remains frozen at `0201b549d0dc3f601c50e36255d557034cb01699`.
Portable VM/compiled-JavaScript and strict analysis/format gates passed with their
1,131 source inputs unchanged. The independent source review passed 56 separate
expectations. Their raw archives and all member manifests are retained here.

The first full regression coordinator disappeared after 2,679 visible completions
and 64 observed suites, with empty stderr and no reported failure. It produced no
terminal done, execution receipt or after-snapshot and is **unaccepted**. Its full
partial record remains diagnostic only and contributes zero to the final total.
Every one of the 75 modules is being rerun in bounded independent batches; only
completed batches with before/after bindings and terminal success can qualify.

The three late incoming heads remain separately recorded at this checkpoint.
The macOS guard correction and its 61 producer / 36 independent isolated checks
are preserved for later integration. No actual macOS build or Bash 3 execution
is claimed. Optional interrupted Bash interpreter setup is diagnostic only;
recreatable third-party source/build trees are excluded from the archive.

All archives were checked against their member hashes before publication.
GitHub Actions, workflows and status checks were neither queried nor awaited.
The final README and qualification records supersede this historical status.
''')
publish.append((note,note.name))
parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
assert parent=='0201b549d0dc3f601c50e36255d557034cb01699'
idx=runtime/'progress-publication.index'
if idx.exists():idx.unlink()
env=os.environ.copy();env['GIT_INDEX_FILE']=str(idx)
def git(*args,input=None):return subprocess.check_output(['git',*args],cwd=repo,env=env,input=input)
git('read-tree',parent)
entries=[]
for path,name in publish:
 data=path.read_bytes();oid=git('hash-object','-w','--stdin',input=data).decode().strip();target=base+name
 git('update-index','--add','--cacheinfo','100644',oid,target)
 item={'path':target,'mode':'100644','type':'blob','expected_sha':oid,'bytes':len(data)}
 try:item['content']=data.decode()
 except UnicodeDecodeError:item['binary_path']=str(path.resolve())
 entries.append(item)
manifest={'parent':parent,'base_tree':git('rev-parse',parent+'^{tree}').decode().strip(),'tree':git('write-tree').decode().strip(),'entries':entries}
(runtime/'checkpoint-04-metadata.json').write_text(json.dumps(manifest))
assert subprocess.check_output(['git','status','--porcelain'],cwd=repo)==b''
print(json.dumps({'parent':parent,'tree':manifest['tree'],'files':len(entries),'binary_files':sum('binary_path' in e for e in entries),'manifest_bytes':(runtime/'checkpoint-04-metadata.json').stat().st_size,'tracked_checkout_unchanged':True},indent=2))
