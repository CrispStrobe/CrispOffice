export QUDS_VALIDATION_ROOT=/workspace/scratch/16bd38fb2cfb/quds_office_suite
export QUDS_DART_ROOT=/workspace/scratch/16bd38fb2cfb/runtime/toolchain/dart-sdk
export PUB_CACHE=/workspace/scratch/16bd38fb2cfb/runtime/toolchain/pub-cache
export TMPDIR=/workspace/scratch/16bd38fb2cfb/runtime/toolchain/tmp
export XDG_CONFIG_HOME=/workspace/scratch/16bd38fb2cfb/runtime/toolchain/config
export XDG_CACHE_HOME=/workspace/scratch/16bd38fb2cfb/runtime/toolchain/cache
export DART_SUPPRESS_ANALYTICS=true
export PATH="$QUDS_DART_ROOT/bin:$PATH"
