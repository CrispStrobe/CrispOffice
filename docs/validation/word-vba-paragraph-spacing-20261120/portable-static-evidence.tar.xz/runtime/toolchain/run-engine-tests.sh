#!/usr/bin/env bash
set -euo pipefail
source /workspace/scratch/16bd38fb2cfb/runtime/toolchain/env.sh
cd "$QUDS_VALIDATION_ROOT/packages/quds_office_engine"
exec "$QUDS_DART_ROOT/bin/dart" --old_gen_heap_size=768 --packages="$QUDS_VALIDATION_ROOT/.dart_tool/package_config.json" /workspace/scratch/16bd38fb2cfb/runtime/toolchain/test-runner/test-runner.dill --compiler source --concurrency=1 --timeout=4x --fail-fast "$@"
