# Word custom line-spacing portable and static qualification

Accepted source commit: `0201b549d0dc3f601c50e36255d557034cb01699`.
Accepted tree: `86531c002a6b1d6e748849f7370a87072a5fa768`.

The portable gate runs the exact committed six-step BAS on the pinned Dart VM
and compiled JavaScript under Node. It also exercises ordinary 1.15-line
conversions, four source preset guards, policy refusals, rollback, native
recording/replay and 15 source refusals. Both raw outputs are identical:
1,393 bytes, SHA-256
`2c5c1131842f09451d4334bbb7c3f97ae39f52db560c2847e8fbdd7c045e8f59`.

The subsequent whole-engine strict analysis found no issues. Nonmutating
format verification passed all eight changed Dart files with zero changes.
Both phases bind the same 1,131 source inputs, including two font fixtures.
Portable execution binds 20 selected runtime inputs; analysis/format binds
19 selected runtime inputs. These counts are not a complete SDK/dependency
file census. Each phase retains before/after manifests, exact commands,
stdout/stderr, timings, runner source, helper source and acceptance results.

## Reproduce in a fresh location

1. Clone the repository with its history to `<fresh>/quds_office_suite` and
   check out the accepted source commit above. The archive's nine tested
   source files are snapshots for review; the full repository is required.
2. Copy `runtime/prior/runtime/reproduce_runtime.py` from the archive to a
   convenient scratch location. Run it with `--repo` pointing at that fresh
   checkout, `--runtime <fresh>/runtime/toolchain`, and `--record` pointing at
   this archive's `runtime/toolchain/environment.json`. The destination
   toolchain directory must not exist before reproduction. The script
   downloads the exact recorded SDK, checks its SHA-256, resolves all 56 exact
   hosted version pins, and creates package configuration against the clone.
3. Copy this archive's `runtime/line_spacing_gate_helper.py`,
   `runtime/run_line_spacing_portable.py` and
   `runtime/run_line_spacing_checks.py` into `<fresh>/runtime`.
4. From `<fresh>`, run:

```bash
python3 runtime/run_line_spacing_portable.py --out runtime/portable-reproduction
python3 runtime/run_line_spacing_checks.py --out runtime/checks-reproduction --expected-commit 0201b549d0dc3f601c50e36255d557034cb01699
```

The runners refuse an existing output directory and bind their newly created
runtime paths. Successful reproduction produces new manifests and timings;
those environmental records need not match the original host's paths.
No GitHub Actions were queried or awaited for these gates.
