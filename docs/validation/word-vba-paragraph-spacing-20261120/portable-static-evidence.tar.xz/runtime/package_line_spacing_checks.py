#!/usr/bin/env python3
"""Archive the accepted portable/static gates without changing repository files."""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path
import tarfile

import line_spacing_gate_helper as gate

ROOT = Path(__file__).resolve().parent.parent
RUNTIME = ROOT / 'runtime'
DESTINATION = RUNTIME / 'line-spacing-portable-static-final.tar.xz'
EXPECTED = '0201b549d0dc3f601c50e36255d557034cb01699'


def identity(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def canonical_metadata(info: tarfile.TarInfo) -> tarfile.TarInfo:
    info.mtime = 0
    info.uid = info.gid = 0
    info.uname = info.gname = ''
    return info


assert not DESTINATION.exists(), 'Do not overwrite existing evidence'
assert gate.git('rev-parse', 'HEAD') == EXPECTED
portable = json.loads((RUNTIME / 'line-spacing-portable-final/summary.json').read_text())
checks = json.loads((RUNTIME / 'line-spacing-checks-final/summary.json').read_text())
assert portable['qualified'] and checks['qualified']
assert portable['source_commit_before'] == checks['source_commit_before'] == EXPECTED
inputs = json.loads(gzip.decompress((RUNTIME / 'line-spacing-portable-final/inputs-after.json.gz').read_bytes()))
current = gate.source_manifest()
assert current['head_matches_worktree'] and current['entries'] == inputs['entries']
check_inputs = json.loads(gzip.decompress((RUNTIME / 'line-spacing-checks-final/inputs-after.json.gz').read_bytes()))
assert current['entries'] == check_inputs['entries']
readme = RUNTIME / 'line-spacing-portable-static-reproduction.md'
readme.write_text('''# Word custom line-spacing portable and static qualification

Accepted source commit: `0201b549d0dc3f601c50e36255d557034cb01699`.
Accepted tree: `86531c002a6b1d6e748849f7370a87072a5fa768`.

The portable gate runs the exact committed six-step BAS on the pinned Dart VM
and compiled JavaScript under Node. It also exercises ordinary 1.15-line
conversions, four source preset guards, policy refusals, rollback, native
recording/replay and 15 source refusals. Both raw outputs are identical:
1,393 bytes, SHA-256
`2c5c1131842f09451d4334bbb7c3f97ae39f52db560c2847e8fbdd7c045e8f59`.

The subsequent whole-engine strict analysis found no issues. Nonmutating
format verification passed all eight changed Dart files with zero changes.
Both phases bind the same 1,131 source inputs, including two font fixtures.
Portable execution binds 20 selected runtime inputs; analysis/format binds
19 selected runtime inputs. These counts are not a complete SDK/dependency
file census. Each phase retains before/after manifests, exact commands,
stdout/stderr, timings, runner source, helper source and acceptance results.

## Reproduce in a fresh location

1. Clone the repository with its history to `<fresh>/quds_office_suite` and
   check out the accepted source commit above. The archive's nine tested
   source files are snapshots for review; the full repository is required.
2. Copy `runtime/prior/runtime/reproduce_runtime.py` from the archive to a
   convenient scratch location. Run it with `--repo` pointing at that fresh
   checkout, `--runtime <fresh>/runtime/toolchain`, and `--record` pointing at
   this archive's `runtime/toolchain/environment.json`. The destination
   toolchain directory must not exist before reproduction. The script
   downloads the exact recorded SDK, checks its SHA-256, resolves all 56 exact
   hosted version pins, and creates package configuration against the clone.
3. Copy this archive's `runtime/line_spacing_gate_helper.py`,
   `runtime/run_line_spacing_portable.py` and
   `runtime/run_line_spacing_checks.py` into `<fresh>/runtime`.
4. From `<fresh>`, run:

```bash
python3 runtime/run_line_spacing_portable.py --out runtime/portable-reproduction
python3 runtime/run_line_spacing_checks.py --out runtime/checks-reproduction --expected-commit 0201b549d0dc3f601c50e36255d557034cb01699
```

The runners refuse an existing output directory and bind their newly created
runtime paths. Successful reproduction produces new manifests and timings;
those environmental records need not match the original host's paths.
No GitHub Actions were queried or awaited for these gates.
''')

files: set[Path] = set()
for name in ['line-spacing-portable-final', 'line-spacing-checks-final']:
    files.update(path for path in (RUNTIME / name).rglob('*') if path.is_file())
for name in [
    'run_line_spacing_portable.py', 'run_line_spacing_checks.py',
    'line_spacing_gate_helper.py', 'package_line_spacing_checks.py',
    'line-spacing-portable-final.stdout', 'line-spacing-portable-final.stderr',
    'line-spacing-checks-final.stdout', 'line-spacing-checks-final.stderr',
    'line-spacing-portable-static-reproduction.md',
    'setup-receipt.json', 'setup.stdout', 'setup.stderr',
    'prior/runtime/reproduce_runtime.py',
    'toolchain/environment.json', 'toolchain/reproduction-command.json',
    'toolchain/env.sh', 'toolchain/run-engine-tests.sh',
    'toolchain/engine-validation/packages/quds_office_engine/pubspec.yaml',
    'toolchain/engine-validation/packages/quds_office_engine/pubspec.lock',
    'toolchain/engine-validation/packages/legacy_doc_parser/pubspec.yaml',
]:
    files.add(RUNTIME / name)
files.add(gate.REPO / '.dart_tool/package_config.json')
files.add(gate.REPO / '.dart_tool/package_graph.json')
plan = json.loads((RUNTIME / 'line-spacing-checks-final/plan.json').read_text())
files.update(gate.REPO / name for name in plan['format_paths'])
files.add(gate.ENGINE / 'example/macros/word_line_spacing.bas')
for path in files:
    assert path.is_file() and not path.is_symlink(), path
index = {str(path.relative_to(ROOT)): identity(path) for path in sorted(files)}
index_path = RUNTIME / 'line-spacing-portable-static-members.json'
index_path.write_text(json.dumps(index, indent=2, sort_keys=True) + '\n')
files.add(index_path)
with tarfile.open(DESTINATION, 'w:xz', preset=6) as archive:
    for path in sorted(files):
        archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False,
                    filter=canonical_metadata)
with tarfile.open(DESTINATION, 'r:xz') as archive:
    members = {member.name: member for member in archive.getmembers()}
    assert len(members) == len(files)
    for name, expected in index.items():
        payload = archive.extractfile(name).read()
        assert len(payload) == expected['bytes']
        assert hashlib.sha256(payload).hexdigest() == expected['sha256']
assert gate.git('rev-parse', 'HEAD') == EXPECTED
assert gate.source_manifest()['entries'] == current['entries']
receipt = {
    'accepted': True,
    'source_commit': EXPECTED,
    'source_tree': current['source_tree'],
    'portable_qualified': portable['qualified'],
    'analysis_format_qualified': checks['qualified'],
    'source_inputs_unchanged_through_packaging': True,
    'source_input_count': len(current['entries']),
    'member_count': len(files),
    'all_archived_member_hashes_verified': True,
    'archive': str(DESTINATION),
    **identity(DESTINATION),
    'members_manifest': str(index_path),
}
(RUNTIME / 'line-spacing-portable-static-packaging.json').write_text(
    json.dumps(receipt, indent=2, sort_keys=True) + '\n'
)
print(json.dumps(receipt, indent=2))
