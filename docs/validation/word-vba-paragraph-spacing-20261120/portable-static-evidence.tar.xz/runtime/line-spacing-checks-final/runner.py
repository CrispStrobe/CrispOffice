#!/usr/bin/env python3
"""Qualify whole-engine analysis and the eight changed Dart files without edits."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

import line_spacing_gate_helper as gate


def identity(path: Path) -> dict[str, object]:
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return {'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def runtime_manifest() -> dict[str, object]:
    result = gate.runtime_manifest(Path(__file__).resolve())
    sdk = gate.RUNTIME / 'dart-sdk/bin'
    paths = [sdk / 'dart', sdk / 'dartaotruntime']
    paths.extend(sdk / 'snapshots' / name for name in [
        'analysis_server_aot.dart.snapshot',
        'analysis_server.dart.snapshot',
        'dartdev_aot.dart.snapshot',
        'frontend_server_aot.dart.snapshot',
        'gen_kernel_aot.dart.snapshot',
        'kernel-service.dart.snapshot',
    ])
    for path in paths:
        assert path.is_file(), path
        result[str(path.resolve())] = identity(path)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--expected-commit', required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    assert not out.exists(), 'Use a fresh output directory'
    out.mkdir(parents=True)
    assert gate.git('rev-parse', 'HEAD') == args.expected_commit
    names = gate.git(
        'diff', '--name-only', 'c7e721b7703766491fd4459b69de30bf68d9010d',
        'HEAD', '--', 'packages/quds_office_engine',
    ).splitlines()
    dart_files = sorted(name for name in names if name.endswith('.dart'))
    assert len(dart_files) == 8, dart_files
    assert all((gate.REPO / name).is_file() for name in dart_files)
    before = gate.source_manifest()
    before['runtime_inputs'] = runtime_manifest()
    assert before['head_matches_worktree']
    gate.save(out / 'inputs-before.json.gz', before)
    shutil.copyfile(Path(__file__), out / 'runner.py')
    shutil.copyfile(Path(gate.__file__), out / 'gate-helper.py')
    gate.save(out / 'plan.json', {
        'expected_commit': args.expected_commit,
        'source_tree': before['source_tree'],
        'analysis_scope': 'Entire packages/quds_office_engine directory',
        'format_paths': dart_files,
        'format_is_non_mutating': True,
        'sequential': True,
    })
    environment = os.environ.copy()
    environment.update({
        'PUB_CACHE': str(gate.RUNTIME / 'pub-cache'),
        'TMPDIR': str(gate.RUNTIME / 'tmp'),
        'XDG_CONFIG_HOME': str(gate.RUNTIME / 'config'),
        'XDG_CACHE_HOME': str(gate.RUNTIME / 'cache'),
        'DART_SUPPRESS_ANALYTICS': 'true',
        'PATH': str(gate.RUNTIME / 'dart-sdk/bin') + os.pathsep + environment['PATH'],
    })
    dart = gate.RUNTIME / 'dart-sdk/bin/dart'
    commands = [
        ('analysis', [str(dart), 'analyze', '--fatal-infos', '--fatal-warnings']),
        ('format', [str(dart), 'format', '--output=none', '--set-exit-if-changed',
                    *[str(gate.REPO / path) for path in dart_files]]),
    ]
    receipts = []
    for name, command in commands:
        started = dt.datetime.now(dt.timezone.utc).isoformat()
        began = time.monotonic()
        with (out / f'{name}.stdout').open('wb') as stdout, (out / f'{name}.stderr').open('wb') as stderr:
            result = subprocess.run(command, cwd=gate.ENGINE, env=environment, stdout=stdout, stderr=stderr)
        receipt = {'name': name, 'argv': command, 'cwd': str(gate.ENGINE),
                   'started_utc': started, 'seconds': round(time.monotonic() - began, 3),
                   'exit_code': result.returncode}
        receipts.append(receipt)
        gate.save(out / 'commands.json', receipts)
        print(json.dumps({key: receipt[key] for key in ['name', 'seconds', 'exit_code']}), flush=True)
        if result.returncode:
            break
    after = gate.source_manifest()
    after['runtime_inputs'] = runtime_manifest()
    gate.save(out / 'inputs-after.json.gz', after)
    summary = {
        'commands_succeeded': len(receipts) == 2 and all(row['exit_code'] == 0 for row in receipts),
        'source_commit_before': before['source_commit'],
        'source_commit_after': after['source_commit'],
        'source_tree': before['source_tree'],
        'head_matches_worktree_before': before['head_matches_worktree'],
        'head_matches_worktree_after': after['head_matches_worktree'],
        'source_inputs_unchanged': before['entries'] == after['entries'],
        'runtime_inputs_unchanged': before['runtime_inputs'] == after['runtime_inputs'],
        'source_input_count': len(before['entries']),
        'runtime_input_count': len(before['runtime_inputs']),
        'analysis_scope': 'Entire engine package',
        'format_path_count': len(dart_files),
        'format_is_non_mutating': True,
        'commands': receipts,
    }
    summary['qualified'] = bool(
        summary['commands_succeeded'] and
        summary['head_matches_worktree_before'] and summary['head_matches_worktree_after'] and
        summary['source_inputs_unchanged'] and summary['runtime_inputs_unchanged'] and
        summary['source_commit_before'] == summary['source_commit_after'] == args.expected_commit
    )
    summary['artifacts'] = {path.name: identity(path) for path in sorted(out.iterdir()) if path.is_file()}
    gate.save(out / 'summary.json', summary)
    print(json.dumps({key: summary[key] for key in [
        'qualified', 'commands_succeeded', 'source_input_count', 'runtime_input_count',
        'source_inputs_unchanged', 'runtime_inputs_unchanged', 'format_path_count',
    ]}), flush=True)
    return 0 if summary['qualified'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
