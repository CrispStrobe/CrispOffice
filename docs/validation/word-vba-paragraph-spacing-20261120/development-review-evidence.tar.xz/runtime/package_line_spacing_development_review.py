#!/usr/bin/env python3
"""Preserve diagnostic attempts and separately accepted independent review."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent.parent
RUNTIME = ROOT / 'runtime'
REVIEW = ROOT / 'intake-review'
REPO = ROOT / 'quds_office_suite'
OUTPUT = RUNTIME / 'line-spacing-development-review'
ARCHIVE = RUNTIME / 'line-spacing-development-review.tar.xz'
EXPECTED_COMMIT = '0201b549d0dc3f601c50e36255d557034cb01699'


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def save(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def reporter_summary(path: Path) -> dict[str, object]:
    events = []
    problems = []
    for number, line in enumerate(path.read_text().splitlines(), 1):
        if not line.strip():
            continue
        try:
            events.append(json.loads(line))
        except ValueError as error:
            problems.append(f'line {number}: {error}')
    completions = [event for event in events if event.get('type') == 'testDone']
    cases = [event for event in completions if not event.get('hidden')]
    ends = [event for event in events if event.get('type') == 'done']
    return {
        'scope': 'development_only',
        'publication_acceptance': False,
        'last_reporter_success': ends[-1].get('success') if ends else None,
        'visible_completed_cases': len(cases),
        'visible_passed': sum(event.get('result') == 'success' and not event.get('skipped') for event in cases),
        'visible_failed': sum(event.get('result') != 'success' for event in cases),
        'visible_skipped': sum(bool(event.get('skipped')) for event in cases),
        'failed_completions_including_hidden_loads': sum(event.get('result') != 'success' for event in completions),
        'reporter_error_events': sum(event.get('type') == 'error' for event in events),
        'parse_problems': problems,
    }


def classification(name: str) -> str:
    if name.startswith('intake-review/'):
        if name in {
            'intake-review/source-review.json',
            'intake-review/source-review.md',
            'intake-review/source-review-probes-final.json',
            'intake-review/run_final_source_review.py',
            'intake-review/word-spacing-all-probes-final.jsonl',
            'intake-review/word-spacing-all-probes-final.stderr',
        }:
            return 'independent_source_review_final_separate_from_regression'
        if name.endswith('.dart'):
            return 'independent_probe_source'
        return 'independent_review_development_diagnostics'
    if name.startswith('runtime/setup'):
        return 'runtime_setup_diagnostics'
    if 'line-spacing-development-review/' in name or name.endswith('package_line_spacing_development_review.py'):
        return 'archive_metadata'
    return 'development_diagnostics_not_publication_acceptance'


assert not OUTPUT.exists() and not ARCHIVE.exists(), 'Preserve existing evidence'
assert git('rev-parse', 'HEAD') == EXPECTED_COMMIT
OUTPUT.mkdir(parents=True)
review = json.loads((REVIEW / 'source-review.json').read_text())
probe_receipt = json.loads((REVIEW / 'source-review-probes-final.json').read_text())
assert review['status'] == 'ACCEPTED'
assert review['reviewed_source_commit'] == EXPECTED_COMMIT
assert review['accepted_supplemental_expectations'] == 56
assert review['regression_total_contribution'] == 0
assert probe_receipt['status'] == 'PASS'
assert probe_receipt['passed_supplemental_expectations'] == 56
assert probe_receipt['source_unchanged'] and probe_receipt['recorded_runtime_unchanged']
for name, expected in review['source_files'].items():
    source = (REPO / name).read_bytes()
    assert len(source) == expected['bytes'] and digest(source) == expected['sha256']

paths: set[Path] = set()
for index in range(1, 6):
    for extension in ['jsonl', 'stderr']:
        path = RUNTIME / f'compiler-development-{index:02d}.{extension}'
        assert path.is_file(), path
        paths.add(path)
for pattern in [
    'line-spacing-native-*',
    'line-spacing-existing-regression.*',
    'line-spacing-integration-development*',
    'line-spacing-integration-analysis.*',
    'line-spacing-preset-guard-*',
    'line-spacing-property-packet-guard.*',
    'line-spacing-portable-development*.stdout',
    'line-spacing-portable-development*.stderr',
    'word-spacing-concurrency-probe.*',
    'word-spacing-gate-runner-help.*',
    'setup*',
]:
    matches = {path for path in RUNTIME.glob(pattern) if path.is_file()}
    assert matches, pattern
    paths.update(matches)
for name in ['line-spacing-portable-development', 'line-spacing-portable-development-2']:
    paths.update(path for path in (RUNTIME / name).rglob('*') if path.is_file())
paths.update(path for path in REVIEW.glob('word-spacing-*') if path.is_file())
for name in ['source-review.json', 'source-review.md', 'source-review-probes-final.json', 'run_final_source_review.py']:
    paths.add(REVIEW / name)
paths.add(Path(__file__).resolve())
for path in paths:
    assert path.is_file() and not path.is_symlink(), path

summaries = {
    str(path.relative_to(ROOT)): reporter_summary(path)
    for path in sorted(paths)
    if path.parent == RUNTIME and path.suffix == '.jsonl'
}
portable_runs = {}
for name in ['line-spacing-portable-development', 'line-spacing-portable-development-2']:
    source = json.loads((RUNTIME / name / 'summary.json').read_text())
    portable_runs[name] = {
        key: source.get(key) for key in [
            'development_only', 'qualified', 'commands_succeeded',
            'source_inputs_unchanged', 'runtime_inputs_unchanged',
            'head_matches_worktree', 'raw_outputs_equal',
            'canonical_results_equal', 'raw_output_bytes',
        ]
    }
    assert source['qualified'] is False
attempts = OUTPUT / 'attempts.json'
save(attempts, {
    'development_publication_acceptance': False,
    'sum_of_attempt_counts_is_not_an_acceptance_total': True,
    'reporter_streams': summaries,
    'portable_development_runs': portable_runs,
    'separate_independent_review': {
        'status': review['status'],
        'source_commit': review['reviewed_source_commit'],
        'accepted_supplemental_expectations': 56,
        'regression_total_contribution': 0,
        'receipt': 'intake-review/source-review-probes-final.json',
    },
})
paths.add(attempts)
omitted = OUTPUT / 'omitted-artifacts.json'
save(omitted, {
    'omitted_reproducible_generated_artifacts': [],
    'note': 'Both development JavaScript files, source maps and dependency manifests are included; no requested reproducible output is omitted.',
    'intentionally_outside_this_archive': [
        'The live complete regression gate and its current outputs.',
        'The separately packaged final portable and static qualification.',
        'Repository intake/reconciliation evidence unrelated to the Word source review.',
        'Downloaded SDK and hosted dependency payloads; setup receipts and their pins/hashes remain available in the final portable/static archive.',
    ],
})
paths.add(omitted)
readme = OUTPUT / 'README.md'
readme.write_text('''# Word line-spacing development diagnostics and independent source review

This archive preserves development history. Its development streams provide
**no publication acceptance**. Do not sum their case counts, reuse an older
`accepted` flag as final-source qualification, or add these attempts to the
complete regression total. Initial failures, partially completed fail-fast
runs, corrected attempts and subsequent smoke results remain separate files.

The one accepted body of evidence included alongside those diagnostics is the
independent source review of commit
`0201b549d0dc3f601c50e36255d557034cb01699`, tree
`86531c002a6b1d6e748849f7370a87072a5fa768`.
Its final VM replay passed **56 supplemental expectations** against ten reviewed
source inputs and 38 explicitly recorded runtime/probe inputs. These are
separate from the parent regression and contribute **zero** cases to that
regression total. The authoritative review report and before/after receipt
are retained at `intake-review/source-review.json`, `source-review.md`, and
`source-review-probes-final.json`; the exact runner and probe sources are also
included. The initial and intermediate probe logs remain diagnostic evidence.

## Contents and interpretation

- All five compiler development attempts, including raw stdout reporter
  streams and stderr, retain their original filenames.
- Native initial/corrected/final development runs, the early related regression
  slice, preset-guard regression/review, and property-packet guard runs are
  retained independently. A filename containing `final` does not promote a
  development run into the final complete regression gate.
- All three integration development attempts and their summaries are retained.
  The first exposed a reserved identifier in the example; the later streams
  contain the corrected example and subsequent review-driven scenarios.
- Both portable development directories include commands, exact BAS bytes,
  manifests, summaries, raw VM/compiler/Node output, runner/helper snapshots,
  compiled JavaScript, source maps, and dependency manifests. The first had
  semantically equal JSON with different integral-number spelling; the second
  achieved byte equality. Both explicitly remain unqualified development runs.
- The setup smoke and source/runtime receipts establish how local verification
  became available. They are not additional feature-acceptance cases.
- Concurrency and runner-help diagnostics record environment investigation and
  carry no product-compatibility acceptance claim.

`attempts.json` summarizes each original Dart reporter stream independently,
including hidden loading failures, visible completions, skipped cases and the
terminal reporter status. It deliberately has no combined passing total.
Historical diagnostic streams without a complete before/after receipt are not
silently assigned the final review's source binding. The retained probe source
is the source independently bound by the final supplemental replay; initial
diagnostic runs may predate later probe additions.

The complete 75-file regression gate and the accepted final portable/static
archive are separate deliverables. They are not copied while running and no
current gate helper, runner, runtime input or tracked repository file is edited
by this packaging operation. No GitHub Actions, workflow or status endpoints
were queried or awaited for these activities.

Every included file has an exact size and SHA-256 in the member index. Both
portable JavaScript artifacts and source maps fit in this compact archive, so
no requested generated output was omitted. Tar metadata is normalized for
deterministic reconstruction; extraction does not run any script.
''')
paths.add(readme)

# Read once into immutable packaging payloads, then verify that original files
# remained unchanged. Never modify a log, review record or gate input.
payloads = {str(path.relative_to(ROOT)): path.read_bytes() for path in sorted(paths)}
index = {
    name: {'bytes': len(payload), 'sha256': digest(payload),
           'classification': classification(name),
           'mode': '0755' if (ROOT / name).stat().st_mode & 0o111 else '0644'}
    for name, payload in payloads.items()
}
index_path = OUTPUT / 'members.json'
save(index_path, index)
index_name = str(index_path.relative_to(ROOT))
payloads[index_name] = index_path.read_bytes()

with tarfile.open(ARCHIVE, 'w:xz', preset=6) as archive:
    for name, payload in sorted(payloads.items()):
        info = tarfile.TarInfo(name)
        info.size = len(payload)
        info.mode = int(index.get(name, {}).get('mode', '0644'), 8)
        info.mtime = 0
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        archive.addfile(info, io.BytesIO(payload))

with tarfile.open(ARCHIVE, 'r:xz') as archive:
    members = archive.getmembers()
    assert len(members) == len(payloads)
    assert {member.name for member in members} == set(payloads)
    for name, original in payloads.items():
        retained = archive.extractfile(name).read()
        assert len(retained) == len(original) and digest(retained) == digest(original)
        assert (ROOT / name).read_bytes() == original, name
assert git('rev-parse', 'HEAD') == EXPECTED_COMMIT
for name, expected in review['source_files'].items():
    assert digest((REPO / name).read_bytes()) == expected['sha256']

archive_payload = ARCHIVE.read_bytes()
receipt = {
    'packaging_verified': True,
    'development_publication_acceptance': False,
    'accepted_independent_supplemental_expectations': 56,
    'regression_total_contribution': 0,
    'review_source_commit': EXPECTED_COMMIT,
    'reviewed_sources_unchanged_through_packaging': True,
    'original_diagnostic_and_review_files_unchanged': True,
    'archive': str(ARCHIVE),
    'bytes': len(archive_payload),
    'sha256': digest(archive_payload),
    'member_count': len(payloads),
    'all_member_sizes_and_hashes_verified': True,
    'member_index': str(index_path),
    'member_index_sha256': digest(payloads[index_name]),
    'omitted_artifact_index': str(omitted),
    'omitted_generated_artifact_count': 0,
    'included_compiled_javascript_and_maps': True,
    'github_actions': 'NOT QUERIED OR AWAITED',
}
save(OUTPUT / 'packaging.json', receipt)
print(json.dumps(receipt, indent=2, sort_keys=True))
