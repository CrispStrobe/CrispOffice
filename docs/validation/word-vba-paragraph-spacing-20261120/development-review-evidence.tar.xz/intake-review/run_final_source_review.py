#!/usr/bin/env python3
"""Record independent supplemental probes against frozen Word spacing inputs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

BASE = Path('/workspace/scratch/16bd38fb2cfb')
REPO = BASE / 'quds_office_suite'
OUT = BASE / 'intake-review'
DART = BASE / 'runtime/toolchain/dart-sdk/bin/dart'
SOURCE = [
    'packages/quds_office_engine/lib/src/automation/office_vba_language.dart',
    'packages/quds_office_engine/lib/src/automation/operations/word_spacing_steps.dart',
    'packages/quds_office_engine/lib/src/automation/operations/word_steps.dart',
    'packages/quds_office_engine/lib/src/word/serial/word_style_cascade.dart',
    'packages/quds_office_engine/test/office_macro_word_line_spacing_test.dart',
    'packages/quds_office_engine/test/office_vba_word_line_spacing_test.dart',
    'packages/quds_office_engine/test/office_vba_word_line_spacing_integration_test.dart',
    'packages/quds_office_engine/tool/macros/web_vba_word_line_spacing_smoke.dart',
    'packages/quds_office_engine/example/macros/word_line_spacing.bas',
    'docs/VBA_WORD_MACROS.md',
]
PROBES = sorted(OUT.glob('word-spacing-*probe*.dart'))
RUNTIME = [DART, BASE/'runtime/toolchain/env.sh', REPO/'.dart_tool/package_config.json']
RUNTIME += sorted((BASE/'runtime/toolchain/dart-sdk/bin/snapshots').glob('*.snapshot'))
RUNTIME += sorted((BASE/'runtime/toolchain/dart-sdk/lib/_internal').glob('*.dill'))

def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args]).decode().strip()

def digest(path):
    data = path.read_bytes()
    return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest())

def source_manifest():
    return {path:{**digest(REPO/path),'git_mode':git('ls-files','--stage','--',path).split()[0]} for path in SOURCE}

def runtime_manifest():
    return {str(path):digest(path) for path in [*RUNTIME,*PROBES]}

def main():
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    source_before=source_manifest()
    runtime_before=runtime_manifest()
    head=git('rev-parse','HEAD')
    command=[str(DART),'--old_gen_heap_size=768',f'--packages={REPO}/.dart_tool/package_config.json',str(OUT/'word-spacing-all-probes.dart')]
    env=os.environ.copy()
    env['DART_SUPPRESS_ANALYTICS']='true'
    stdout=OUT/'word-spacing-all-probes-final.jsonl'
    stderr=OUT/'word-spacing-all-probes-final.stderr'
    with stdout.open('wb') as output, stderr.open('wb') as error:
        result=subprocess.run(command,cwd=BASE,env=env,stdout=output,stderr=error,timeout=180)
    source_after=source_manifest()
    runtime_after=runtime_manifest()
    rows=[json.loads(line) for line in stdout.read_text().splitlines()]
    assert result.returncode == 0
    assert stderr.stat().st_size == 0
    assert source_before == source_after
    assert runtime_before == runtime_after
    assert len(rows)==56
    assert all(row['status']=='accepted' for row in rows[:32])
    assert all(row['status']=='rejected' for row in rows[32:38])
    assert all(row['matched'] is True for row in rows[38:54])
    assert all(row['status']=='rejected' for row in rows[54:])
    receipt=dict(status='PASS',started_at_utc=started,finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 source_head_at_start=head,source_head_at_finish=git('rev-parse','HEAD'),
                 source_before=source_before,source_after=source_after,source_unchanged=True,
                 recorded_runtime_before=runtime_before,recorded_runtime_after=runtime_after,recorded_runtime_unchanged=True,
                 command=command,cwd=str(BASE),exit_code=result.returncode,
                 stdout={'path':stdout.name,**digest(stdout)},stderr={'path':stderr.name,**digest(stderr)},
                 passed_supplemental_expectations=56,failed=0,groups={'method_forms_and_helpers':14,'unit_conversions':18,'native_refusal_regressions':6,'boundary_and_alias_checks':16,'unrelated_property_alternatives':2},
                 qualification_scope='Independent supplemental VM diagnostic expectations; separate from regression case totals and not a compiled JavaScript replay.',
                 github_actions='NOT QUERIED OR AWAITED')
    (OUT/'source-review-probes-final.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'status':'PASS','expectations':56,'source_files':len(source_before),'recorded_runtime_inputs':len(runtime_before),'source_unchanged':True,'runtime_unchanged':True,'head':head}))

if __name__=='__main__':main()
