import 'dart:convert';
import 'package:quds_office_engine/quds_office_automation.dart';

OfficeMacro compile(String source) => OfficeMacroLanguages().compile(
  OfficeMacroSource(language: 'vba-word', format: OfficeMacroFormat.docx,
    moduleName: 'IndependentSpacingProbe', source: source));

void main() {
  final cases = <String, String>{
    for (final method in ['Space1', 'Space15', 'Space2'])
      for (final suffix in ['', '()'])
        for (final prefix in ['', 'Call '])
          '$prefix$method$suffix': 'Sub Main()\n${prefix}ActiveDocument.Paragraphs(1).Format.$method$suffix\nEnd Sub',
    'cross-helper pending completion': '''
Sub BeginSpacing(ByVal p As ParagraphFormat)
  p.LineSpacingRule = wdLineSpaceExactly
End Sub
Sub Main()
  Dim p As ParagraphFormat
  Set p = ActiveDocument.Paragraphs(1).Format
  BeginSpacing p
  p.LineSpacing = 18
End Sub
''',
    'conversion nested With Application': '''
Sub Main()
  Dim a As Double
  With Application
    a = .LinesToPoints(.PointsToLines(18))
  End With
  ActiveDocument.Paragraphs(1).Format.LineSpacingRule = wdLineSpaceExactly
  ActiveDocument.Paragraphs(1).Format.LineSpacing = a
End Sub
''',
  };
  for (final entry in cases.entries) {
    try {
      final plan = compile(entry.value);
      print(jsonEncode({'case': entry.key, 'status': 'accepted', 'steps': [for (final step in plan.steps) {'tool': step.tool, 'arguments': step.arguments}]}));
    } catch (e) {
      print(jsonEncode({'case': entry.key, 'status': 'rejected', 'error': e.toString()}));
    }
  }
}
