import 'dart:convert';
import 'package:quds_office_engine/quds_office_automation.dart';

void main() {
  for (final expression in [
    'LinesToPoints(1)', 'LinesToPoints(1.1)', 'LinesToPoints(1.15)',
    'LinesToPoints(1.2)', 'LinesToPoints(1.3)', 'LinesToPoints(1.4)',
    'LinesToPoints(1.5)', 'LinesToPoints(1.6)', 'LinesToPoints(1.7)',
    'LinesToPoints(2)', '13.2', '13.8', '14.4', '15.6', '16.8',
    '19.2', 'LinesToPoints(PointsToLines(13.8))',
    'LinesToPoints(0.004166666666666667)',
  ]) {
    try {
      final result = OfficeMacroLanguages().compile(OfficeMacroSource(
        language: 'vba-word', format: OfficeMacroFormat.docx,
        moduleName: 'IndependentConversionProbe', source: '''
Sub Main()
  ActiveDocument.Paragraphs(1).Format.LineSpacingRule = wdLineSpaceMultiple
  ActiveDocument.Paragraphs(1).Format.LineSpacing = $expression
End Sub
'''));
      print(jsonEncode({'expression': expression, 'status':'accepted', 'arguments':result.steps.single.arguments}));
    } catch (error) {
      print(jsonEncode({'expression':expression,'status':'rejected','error':error.toString()}));
    }
  }
}
