import 'dart:convert';
import 'package:quds_office_engine/quds_office_automation.dart';

const target = 'ActiveDocument.Paragraphs(1).Format';
String pair(String amount) => '$target.LineSpacingRule = wdLineSpaceMultiple\n$target.LineSpacing = $amount';

void main() {
  final cases = <(String, String, bool)>[
    ('raw adjacent lower point', 'Sub Main()\n${pair('13.799999999999999')}\nEnd Sub', false),
    ('raw adjacent upper point', 'Sub Main()\n${pair('13.800000000000002')}\nEnd Sub', false),
    ('conversion adjacent lower line', 'Sub Main()\n${pair('LinesToPoints(1.1499999999999997)')}\nEnd Sub', false),
    ('conversion adjacent upper line ordinary rounding', 'Sub Main()\n${pair('LinesToPoints(1.1500000000000001)')}\nEnd Sub', true),
    ('conversion far adjacent line', 'Sub Main()\n${pair('LinesToPoints(1.1000000000000003)')}\nEnd Sub', false),
    ('large conversion refuses', 'Sub Main()\nDim x As Double\nx = LinesToPoints(9007199254740991)\n$target.Space1\nEnd Sub', false),
    ('conversion numeric variant', 'Sub Main()\n${pair('LinesToPoints(CVar(1.15))')}\nEnd Sub', true),
    ('conversion string variant', 'Sub Main()\n${pair('LinesToPoints(CVar("1.15"))')}\nEnd Sub', false),
    ('conversion boolean variant', 'Sub Main()\n${pair('LinesToPoints(CVar(True))')}\nEnd Sub', false),
    ('dead conversion named argument', 'Sub Main()\nIf False Then\nDim x As Double\nx = LinesToPoints(Lines:=1)\nEnd If\n$target.Space1\nEnd Sub', false),
    ('dead invalid method receiver', 'Sub Main()\nIf False Then\nActiveDocument.Paragraphs(1).Range.Font.Space1\nEnd If\n$target.Space1\nEnd Sub', false),
    ('ByVal amount helper rebinding cannot redirect caller', '''
Function Amount(ByVal p As ParagraphFormat) As Double
  Set p = ActiveDocument.Paragraphs(2).Format
  Amount = 18
End Function
Sub Main()
  Dim p As ParagraphFormat
  Set p = ActiveDocument.Paragraphs(1).Format
  p.LineSpacingRule = wdLineSpaceExactly
  p.LineSpacing = Amount(p)
End Sub
''', true),
    ('retained alias completes pending original paragraph', '''
Sub Main()
  Dim p As ParagraphFormat
  Dim saved As ParagraphFormat
  Set p = ActiveDocument.Paragraphs(1).Format
  Set saved = p
  p.LineSpacingRule = wdLineSpaceExactly
  Set p = ActiveDocument.Paragraphs(2).Format
  saved.LineSpacing = 18
End Sub
''', true),
    ('rebound alias cannot complete other paragraph', '''
Sub Main()
  Dim p As ParagraphFormat
  Set p = ActiveDocument.Paragraphs(1).Format
  p.LineSpacingRule = wdLineSpaceExactly
  Set p = ActiveDocument.Paragraphs(2).Format
  p.LineSpacing = 18
End Sub
''', false),
    ('mutation in amount target selector refuses', '''
Function TargetIndex() As Long
  ActiveDocument.Paragraphs(2).Format.Space1
  TargetIndex = 1
End Function
Sub Main()
  ActiveDocument.Paragraphs(1).Format.LineSpacingRule = wdLineSpaceExactly
  ActiveDocument.Paragraphs(TargetIndex()).Format.LineSpacing = 18
End Sub
''', false),
    ('complete helper before outer rule retains order', '''
Function RuleValue() As Long
  ActiveDocument.Paragraphs(2).Format.LineSpacingRule = wdLineSpaceAtLeast
  ActiveDocument.Paragraphs(2).Format.LineSpacing = 20
  RuleValue = wdLineSpaceExactly
End Function
Sub Main()
  ActiveDocument.Paragraphs(1).Format.LineSpacingRule = RuleValue()
  ActiveDocument.Paragraphs(1).Format.LineSpacing = 18
End Sub
''', true),
  ];
  var failed = 0;
  for (final (name, source, expected) in cases) {
    try {
      final plan = OfficeMacroLanguages().compile(OfficeMacroSource(language: 'vba-word', format: OfficeMacroFormat.docx, moduleName: 'IndependentBoundaryProbe', source: source));
      print(jsonEncode({'case':name,'status':'accepted','expected_accept':expected,'matched':expected,'steps':[for(final step in plan.steps) {'tool':step.tool,'arguments':step.arguments}]}));
      if (!expected) failed++;
    } catch (error) {
      print(jsonEncode({'case':name,'status':'rejected','expected_accept':expected,'matched':!expected,'error':error.toString()}));
      if (expected) failed++;
    }
  }
  if (failed != 0) throw StateError('$failed independent boundary expectations failed');
}
