import 'word-spacing-review-probe.dart' as methods;
import 'word-spacing-conversion-probe.dart' as conversion;
import 'word-spacing-native-review-probe.dart' as native;
import 'word-spacing-boundary-probe.dart' as boundaries;
import 'word-spacing-unrelated-metadata-probe.dart' as metadata;
void main() {
  methods.main();
  conversion.main();
  native.main();
  boundaries.main();
  metadata.main();
}
