import 'dart:convert';
import 'package:quds_office_engine/quds_office_automation.dart';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;

void main() {
  for (final scenario in ['duplicate spacing', 'spacing alternative', 'duplicate line attribute']) {
    final package = OpcPackage.openBytes((DocxDocumentBuilder()..paragraph('Original')).build());
    final properties = switch(scenario) {
      'duplicate spacing' => '<w:spacing w:line="240" w:lineRule="auto"/><w:spacing w:line="480" w:lineRule="auto"/>',
      'spacing alternative' => '<mc:AlternateContent><mc:Choice Requires="x"><w:spacing w:line="480"/></mc:Choice><mc:Fallback><w:spacing w:line="240"/></mc:Fallback></mc:AlternateContent>',
      _ => '<w:spacing xmlns:q="${OfficeNamespaces.w}" w:line="240" q:line="480"/>',
    };
    package.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="${OfficeNamespaces.w}" xmlns:x="urn:probe" xmlns:mc="${OfficeNamespaces.mc}"><w:body><w:p><w:pPr>$properties</w:pPr><w:r><w:t>Original</w:t></w:r></w:p><w:sectPr/></w:body></w:document>');
    final input = package.save();
    for(final op in [
      {'op':'lineSpacing','paragraph':0,'rule':'exact','points':12},
      {'op':'paragraphFormat','paragraph':0,'lineSpacing':1.0,'lineSpacingRule':'auto'},
    ]) {
      try {
        final document = WordDeserializer().readBytes(input);
        native.applyStep(document,op);
        final beforeSave = document.paragraphs.single.properties.lineSpacing;
        final saved = WordSerializer().writeBytes(document);
        final reopened = WordDeserializer().readBytes(saved);
        print(jsonEncode({'scenario':scenario,'operation':op['op'],'status':'accepted','beforeSave':beforeSave,'afterReopen':reopened.paragraphs.single.properties.lineSpacing,'xml':OpcPackage.openBytes(saved).getPart('/word/document.xml')!.readText()}));
      } catch(error) {
        print(jsonEncode({'scenario':scenario,'operation':op['op'],'status':'rejected','error':error.toString()}));
      }
    }
  }
}
