import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;

void main() {
  final package = OpcPackage.openBytes((DocxDocumentBuilder()..paragraph('Original')).build());
  package.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="${OfficeNamespaces.w}" xmlns:x="urn:probe" xmlns:mc="${OfficeNamespaces.mc}"><w:body><w:p><w:pPr><mc:AlternateContent><mc:Choice Requires="x"><x:metadata x:val="retain-choice"/></mc:Choice><mc:Fallback><x:metadata x:val="retain-fallback"/></mc:Fallback></mc:AlternateContent></w:pPr><w:r><w:t>Original</w:t></w:r></w:p><w:sectPr/></w:body></w:document>');
  final input = package.save();
  for(final op in [
    {'op':'lineSpacing','paragraph':0,'rule':'exact','points':12},
    {'op':'paragraphFormat','paragraph':0,'lineSpacing':1.0,'lineSpacingRule':'auto'},
  ]) {
    try {
      final document = WordDeserializer().readBytes(input);
      native.applyStep(document,op);
      final saved = WordSerializer().writeBytes(document);
      final xml = OpcPackage.openBytes(saved).getPart('/word/document.xml')!.readText();
      print(jsonEncode({'operation':op['op'],'status':'accepted','choice_preserved':xml.contains('retain-choice'),'fallback_preserved':xml.contains('retain-fallback'),'xml':xml}));
    } catch(error) {
      print(jsonEncode({'operation':op['op'],'status':'rejected','error':error.toString()}));
    }
  }
}
