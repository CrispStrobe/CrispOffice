#!/usr/bin/env python3
"""Checkpoint completed bounded batches and diagnostics with the source frozen."""
import hashlib,io,json,os,subprocess,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent.parent;repo=root/'quds_office_suite';rt=root/'runtime';review=root/'intake-review'
out=rt/'bounded-progress-checkpoint-files';out.mkdir(exist_ok=True)
gate=rt/'word-spacing-batched-final-0201b549';files={};accepted=[]
for directory in sorted(gate.glob('batch-[0-9][0-9]')):
 summary=directory/'summary.json'
 if not summary.exists():continue
 result=json.loads(summary.read_text())
 if not result.get('accepted'):continue
 accepted.append({'batch':directory.name,'passing_cases':result['passing_cases'],'exit_code':result['exit_code']})
 for path in directory.rglob('*'):
  if path.is_file():files['accepted/'+str(path.relative_to(gate))]=path
for path in (gate/'diagnostics').rglob('*'):
 if path.is_file():files['diagnostics/'+str(path.relative_to(gate/'diagnostics'))]=path
for name in ['plan.json','batch-selection.json']:
 path=gate/name
 if path.exists():files['gate/'+name]=path
for name in ['run_word_spacing_batched_gate.py','package_word_spacing_batched_regression.py','create_bounded_progress_checkpoint.py']:
 path=rt/name
 if path.is_file():files['runners/'+name]=path
for name in ['verify_final_evidence.py','audit_batched_regression.py','audit_checkpoint_archives.py','checkpoint-archives-review.json','bounded-timeout-diagnostics-review.json','audit_publication_scope.py','publication-scope-review-preintegration.json','publication-scope-review-preintegration.md','recovery-scope-fork-refs.txt','recovery-scope-upstream-refs.txt']:
 path=review/name
 if path.is_file():files['independent-review/'+name]=path
payloads={k:v.read_bytes() for k,v in files.items()}
entries={k:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':'0755' if files[k].stat().st_mode&0o111 else '0644'} for k,data in payloads.items()}
meta={'source_commit':'0201b549d0dc3f601c50e36255d557034cb01699','final_gate_complete':False,'publication_acceptance':False,'accepted_batches':accepted,'accepted_subset_cases':sum(x['passing_cases'] for x in accepted),'additional_regression_cases':0,'failed_attempts_contribution':0,'github_actions':'not queried or awaited'}
index=(json.dumps({'metadata':meta,'files':entries},indent=2,sort_keys=True)+'\n').encode();(out/'bounded-progress-members.json').write_bytes(index)
arc=out/'bounded-progress-evidence.tar.xz'
with tarfile.open(arc,'w:xz',format=tarfile.PAX_FORMAT,preset=6) as tar:
 for name,data in sorted(payloads.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=int(entries[name]['mode'],8);info.mtime=0;tar.addfile(info,io.BytesIO(data))
 info=tarfile.TarInfo('members.json');info.size=len(index);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(index))
with tarfile.open(arc,'r:xz') as tar:
 assert set(tar.getnames())==set(entries)|{'members.json'}
 for name,entry in entries.items():
  data=tar.extractfile(name).read();assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
 assert tar.extractfile('members.json').read()==index
receipt={**meta,'archive':arc.name,'bytes':arc.stat().st_size,'sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'member_count':len(entries)+1,'member_index_sha256':hashlib.sha256(index).hexdigest(),'all_member_hashes_verified':True}
(out/'bounded-progress-packaging.json').write_text(json.dumps(receipt,indent=2)+'\n')
(out/'bounded-progress-checkpoint.md').write_text(f'''# Historical bounded-regression progress checkpoint

The source remains frozen at `0201b549`. This is a preserved intermediate record,
not complete regression acceptance. Its {len(accepted)} completed batches contain
{meta['accepted_subset_cases']:,} passing cases with successful terminal/exit records
and unchanged source/runtime bindings. They will be counted once in a complete
final gate; this archive adds zero extra cases.

The initial interrupted long invocation and the two timed-out concurrent batch
attempts remain diagnostic only. Both serial retry and remaining invocations use
the existing per-process concurrency and timeout settings. Later source/ancestry
reconciliation and final publication acceptance remain pending. See the final
README and qualification files for the superseding completed result.
''')
parent='07860e6b5dbad983523d857bd9de4e13eadced7b';idx=rt/'bounded-progress-publication.index'
if idx.exists():idx.unlink()
env=os.environ.copy();env['GIT_INDEX_FILE']=str(idx)
def git(*args,input=None):return subprocess.check_output(['git',*args],cwd=repo,env=env,input=input)
assert git('rev-parse','HEAD').decode().strip()=='0201b549d0dc3f601c50e36255d557034cb01699'
git('read-tree',parent);items=[]
for path in sorted(out.iterdir()):
 if not path.is_file():continue
 data=path.read_bytes();oid=git('hash-object','-w','--stdin',input=data).decode().strip();name='docs/validation/word-vba-paragraph-spacing-20261120/'+path.name
 git('update-index','--add','--cacheinfo','100644',oid,name)
 item={'path':name,'mode':'100644','type':'blob','expected_sha':oid,'bytes':len(data)}
 try:item['content']=data.decode()
 except UnicodeDecodeError:item['binary_path']=str(path.resolve())
 items.append(item)
manifest={'parent':parent,'base_tree':git('rev-parse',parent+'^{tree}').decode().strip(),'tree':git('write-tree').decode().strip(),'entries':items}
(rt/'checkpoint-05-metadata.json').write_text(json.dumps(manifest))
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=repo)==b''
print(json.dumps({'parent':parent,'tree':manifest['tree'],'files':len(items),'archive_bytes':arc.stat().st_size,'members':len(entries)+1,'accepted_batches':accepted,'tracked_checkout_unchanged':True},indent=2))
