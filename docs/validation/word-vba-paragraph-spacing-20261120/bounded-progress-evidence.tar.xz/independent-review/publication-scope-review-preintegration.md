# Independent publication-scope review

Status: **CLASSIFIED_PENDING_SELECTED_INTEGRATION** against `07860e6b5dbad983523d857bd9de4e13eadced7b`.

Every reference from the original intake is included or historically equivalent. The three selected original late heads are tracked separately from their newer continuations. Later moving work is explicitly deferred; all captured entries are classified.

| Captured source | Total | Incorporated or equivalent | Selected pending | Deferred | Unclassified |
| --- | ---: | ---: | ---: | ---: | ---: |
| fork_branches | 33 | 24 | 1 | 8 | 0 |
| fork_pull_requests | 269 | 263 | 1 | 5 | 0 |
| upstream_branches | 4 | 4 | 0 | 0 | 0 |
| upstream_pull_requests | 4 | 4 | 0 | 0 | 0 |

## Explicitly deferred captured heads

- `7c64246b5bb7c441206ae0bca99948f33b091f13` — Later paragraph-controls implementation; draft PR268 qualification in progress. Captured refs: `refs/heads/codex/word-vba-paragraph-controls-20261120`, `refs/pull/268/head`.
- `f4c3d582711b923b41a8ab37f917bc1564ab1a55` — Later App Store submission documentation. Captured refs: `refs/heads/docs/app-store-submission-20261120`, `refs/pull/266/head`.
- `3c6637b6e5585de5fb4b8d27a0ceda6f96edb95f` — Later App Store screenshot feature. Captured refs: `refs/heads/feat/app-store-screenshots-20261120`.
- `be47bed22a88382f016d823e526bae49590bd0eb` — Later Arabic web context feature. Captured refs: `refs/heads/feat/arabic-web-context-20261120`, `refs/pull/267/head`.
- `6117d3bd193d79ecc9e14530378bf3af614c3c33` — Later Arabic web settings feature. Captured refs: `refs/heads/feat/settings-arweb-20261120`, `refs/pull/269/head`.
- `f4de5f4f1f3793c0aee5e654113c7220701dc30e` — Later bookmark typing fix. Captured refs: `refs/heads/fix/bookmark-typing-20261120`.
- `01224376ee0e86703b6b4723e40c72de7629e50b` — Later main-green continuation; distinct from selected original PR264 head. Captured refs: `refs/heads/fix/main-green-20261120`, `refs/pull/264/head`.
- `d219465a581d8082efa6909b4005c64d7a7624a2` — Later Mail parity continuation. Captured refs: `refs/heads/work/mail-parity-20261120`.

The raw inclusion audit intentionally retains all uncovered references and exit code 1. A fully classified publication scope does not turn deferred work into incorporated work. This review uses immutable captured SHAs and retains the 13 full-tree proofs plus the exact 37-path continuation proof. No GitHub Actions were queried or awaited.

The current report is an ancestry/source-inclusion review, not new runtime qualification of the deferred features.
