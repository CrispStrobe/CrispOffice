#!/usr/bin/env python3
"""Build an isolated Linux Bash 3.2 interpreter solely for compatibility probes."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import time

HERE = Path(__file__).resolve().parent
archive = HERE / 'bash-3.2.tar.gz'
receipt = {
    'source_url': 'https://ftp.gnu.org/gnu/bash/bash-3.2.tar.gz',
    'archive_bytes': archive.stat().st_size,
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'scope': 'Linux interpreter compatibility only; no macOS build/sign verification',
    'commands': [],
}
with tarfile.open(archive) as tf:
    for member in tf.getmembers():
        assert member.name == 'bash-3.2' or member.name.startswith('bash-3.2/')
        assert not member.name.startswith('/') and '..' not in Path(member.name).parts
    tf.extractall(HERE, filter='data')
for label, command in [
    ('configure', ['./configure', '--without-bash-malloc', '--disable-nls']),
    ('make', ['make', '-j1']),
]:
    start = time.monotonic()
    with (HERE / f'bash3-{label}.stdout').open('wb') as out, (HERE / f'bash3-{label}.stderr').open('wb') as err:
        process = subprocess.run(command, cwd=HERE / 'bash-3.2', stdout=out, stderr=err)
    entry = {'command': command, 'cwd': str(HERE / 'bash-3.2'),
             'elapsed_seconds': round(time.monotonic() - start, 6),
             'exit': process.returncode,
             'stdout': f'bash3-{label}.stdout', 'stderr': f'bash3-{label}.stderr'}
    receipt['commands'].append(entry)
    (HERE / 'bash3-build-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(entry), flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)
receipt['binary_sha256'] = hashlib.sha256((HERE / 'bash-3.2/bash').read_bytes()).hexdigest()
receipt['binary_version'] = subprocess.check_output([str(HERE / 'bash-3.2/bash'), '--version'], text=True)
(HERE / 'bash3-build-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
