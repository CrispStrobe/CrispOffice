#!/usr/bin/env python3
"""Produce the narrowly scoped PR265 correction without touching the checkout."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'quds_office_suite'
SOURCE_COMMIT = 'a51c20737b1932d9c6475ea6dddc33fbd50b2c17'
SOURCE_PATH = 'packages/quds_office_editor/example/tool/build_macos_app.sh'
original = subprocess.check_output(
    ['git', 'show', f'{SOURCE_COMMIT}:{SOURCE_PATH}'], cwd=REPO
)
old = original.decode()
old_comparator = '''# true when version $1 <= version $2 (dotted, numeric)
version_le() { [[ "$(printf '%s\\n%s\\n' "$1" "$2" | sort -t. -k1,1n -k2,2n -k3,3n | head -1)" == "$1" ]]; }
'''
new_functions = r'''# Return 0 when version $1 <= version $2, 1 when greater, and 2 for an
# invalid version. Missing minor/patch components and leading zeros are
# numeric zeros. Compare decimal strings to avoid octal or integer overflow.
version_le() {
  local pattern='^[0-9]+([.][0-9]+){0,2}$'
  [[ "${1:-}" =~ $pattern && "${2:-}" =~ $pattern ]] || return 2
  LC_ALL=C awk -v left="$1" -v right="$2" '
    BEGIN {
      split(left, lhs, /[.]/)
      split(right, rhs, /[.]/)
      for (i = 1; i <= 3; i++) {
        a = lhs[i]; b = rhs[i]
        sub(/^0+/, "", a); sub(/^0+/, "", b)
        if (length(a) < length(b)) exit 0
        if (length(a) > length(b)) exit 1
        if (("x" a) < ("x" b)) exit 0
        if (("x" a) > ("x" b)) exit 1
      }
      exit 0
    }'
}

# Validate every architecture and every macOS deployment load command.
# Modern commands use platform MACOS/minos; legacy commands use version.
# A build command's nested tool version is not a deployment target.
verify_library_minimum_os() {
  local path="$1" app_minimum="$2" output minimums minimum slice status
  if ! version_le "$app_minimum" "$app_minimum"; then
    echo "app declares malformed minimum macOS: $app_minimum" >&2
    return 1
  fi
  if ! output="$(vtool -show-build "$path")"; then
    echo "$path: could not read macOS deployment commands" >&2
    return 1
  fi
  if ! minimums="$(LC_ALL=C awk '
    function fail(message) {
      print "invalid macOS deployment commands: " message > "/dev/stderr"
      failed = 1
      exit 1
    }
    function finish_command() {
      if (!in_command) return
      if (kind != "LC_BUILD_VERSION" && kind != "LC_VERSION_MIN_MACOSX")
        fail(slice ": unsupported deployment command " kind)
      if (kind == "LC_BUILD_VERSION" && platform != "MACOS")
        fail(slice ": missing or non-macOS platform")
      if (!have_minimum) fail(slice ": missing minimum macOS")
      print minimum "\t" slice
      slice_minimums++
      in_command = 0
    }
    function finish_slice() {
      finish_command()
      if (slice != "" && !slice_minimums)
        fail(slice ": no macOS deployment command")
    }
    /^[^[:space:]].*:$/ {
      finish_slice()
      slice = $0
      sub(/:$/, "", slice)
      slice_minimums = 0
      next
    }
    $1 == "Load" && $2 == "command" {
      if (slice == "" || NF != 3 || $3 !~ /^[0-9]+$/)
        fail("missing architecture header or malformed load command")
      finish_command()
      in_command = 1
      kind = ""; platform = ""; minimum = ""; have_minimum = 0
      next
    }
    $1 == "cmd" {
      if (!in_command || NF != 2 || kind != "")
        fail(slice ": malformed deployment command")
      kind = $2
      next
    }
    $1 == "platform" {
      if (!in_command || kind != "LC_BUILD_VERSION" || NF != 2 || platform != "")
        fail(slice ": malformed platform")
      platform = $2
      next
    }
    $1 == "minos" || ($1 == "version" && kind == "LC_VERSION_MIN_MACOSX") {
      if (!in_command || NF != 2 || have_minimum ||
          ($1 == "minos" && kind != "LC_BUILD_VERSION"))
        fail(slice ": malformed minimum macOS")
      minimum = $2
      have_minimum = 1
      next
    }
    END {
      if (failed) exit 1
      if (slice == "") fail("no architecture header")
      finish_slice()
    }' <<<"$output")"; then
    echo "$path: cannot verify minimum macOS for every architecture" >&2
    return 1
  fi
  while IFS=$'\t' read -r minimum slice; do
    if version_le "$minimum" "$app_minimum"; then
      continue
    else
      status=$?
      if [[ "$status" == 2 ]]; then
        echo "$slice declares malformed minimum macOS: $minimum" >&2
      else
        echo "$slice needs macOS $minimum, app declares $app_minimum" >&2
      fi
      return 1
    fi
  done <<<"$minimums"
}
'''
old_check = '''  library_minimum="$(vtool -show-build "$path" | awk '/minos/{print $2}' | sort -t. -k1,1n -k2,2n | tail -1)"
  [[ -n "$library_minimum" ]] || { echo "$library declares no minimum macOS" >&2; exit 1; }
  version_le "$library_minimum" "$APP_MINIMUM_OS" \\
    || { echo "$library needs macOS $library_minimum, app declares $APP_MINIMUM_OS" >&2; exit 1; }
'''
new_check = '''  verify_library_minimum_os "$path" "$APP_MINIMUM_OS" || exit 1
'''
assert old.count(old_comparator) == 1
assert old.count(old_check) == 1
corrected = old.replace(old_comparator, new_functions).replace(old_check, new_check)
assert corrected.replace(new_functions, old_comparator).replace(new_check, old_check) == old
for name, data in [('build_macos_app.original.sh', original),
                   ('build_macos_app.corrected.sh', corrected.encode())]:
    (HERE / name).write_bytes(data)
    (HERE / name).chmod(0o755)
patch = ''.join(difflib.unified_diff(
    old.splitlines(keepends=True), corrected.splitlines(keepends=True),
    fromfile=f'a/{SOURCE_PATH}', tofile=f'b/{SOURCE_PATH}'
))
(HERE / 'macos-minimum-version.patch').write_text(patch)
start = corrected.index('version_le() {')
end = corrected.index('for library in "${LIBRARIES[@]}"; do', start)
extracted = corrected[start:end]
assert extracted.endswith('}\n')
(HERE / 'extracted-functions.sh').write_text(extracted)
reference = HERE.parent / 'intake-review/apple-vtool-source-reference.json'
if reference.exists():
    (HERE / reference.name).write_bytes(reference.read_bytes())
source_blob = subprocess.check_output(
    ['git', 'rev-parse', f'{SOURCE_COMMIT}:{SOURCE_PATH}'], cwd=REPO, text=True
).strip()
receipt = {
    'source_commit': SOURCE_COMMIT,
    'source_path': SOURCE_PATH,
    'source_git_blob': source_blob,
    'source_sha256': hashlib.sha256(original).hexdigest(),
    'corrected_sha256': hashlib.sha256(corrected.encode()).hexdigest(),
    'extracted_functions_sha256': hashlib.sha256(extracted.encode()).hexdigest(),
    'patch_sha256': hashlib.sha256(patch.encode()).hexdigest(),
    'only_two_target_replacements': True,
    'source_command': ['git', 'show', f'{SOURCE_COMMIT}:{SOURCE_PATH}'],
    'source_command_cwd': str(REPO),
    'repository_modified': False,
}
(HERE / 'source-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
