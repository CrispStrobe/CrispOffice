#!/usr/bin/env bash
# Source only the exact helper definitions; never run the build/sign entrypoint.
set -euo pipefail
source "$1"
shift
case "$1" in
  compare)
    shift
    version_le "$1" "$2"
    ;;
  library)
    shift
    probe_library="$1"
    probe_minimum="$2"
    probe_fixture="$3"
    probe_vtool_exit="$4"
    probe_call_log="$5"
    vtool() {
      printf '%s\n' "$*" >>"$probe_call_log"
      [[ "$#" == 2 && "$1" == -show-build && "$2" == "$probe_library" ]] || return 97
      cat "$probe_fixture"
      return "$probe_vtool_exit"
    }
    verify_library_minimum_os "$probe_library" "$probe_minimum"
    ;;
  *) exit 98 ;;
esac
