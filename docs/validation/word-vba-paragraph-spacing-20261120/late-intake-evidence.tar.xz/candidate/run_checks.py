#!/usr/bin/env python3
"""Isolated checks of exact script functions; no macOS build/sign operations."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--bash', default='/usr/bin/bash')
parser.add_argument('--out', default='checks-bash5')
args = parser.parse_args()
OUT = HERE / args.out
OUT.mkdir(exist_ok=False)
FIXTURES = OUT / 'fixtures'
FIXTURES.mkdir()
RAW = OUT / 'raw'
RAW.mkdir()
script = (HERE / 'build_macos_app.corrected.sh').read_text()
start = script.index('version_le() {')
end = script.index('for library in "${LIBRARIES[@]}"; do', start)
assert (HERE / 'extracted-functions.sh').read_text() == script[start:end]
entries = []

def execute(name, command, expected, diagnostic=None, no_vtool=False):
    begin = time.monotonic()
    result = subprocess.run(command, cwd=HERE, capture_output=True)
    elapsed = time.monotonic() - begin
    stdout = RAW / f'{name}.stdout'
    stderr = RAW / f'{name}.stderr'
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    accepted = result.returncode == expected
    if diagnostic is not None:
        accepted = accepted and diagnostic.encode() in result.stderr
    if no_vtool:
        accepted = accepted and not (RAW / f'{name}.vtool-calls').exists()
    entry = {
        'name': name, 'command': command, 'cwd': str(HERE),
        'expected_exit': expected, 'actual_exit': result.returncode,
        'expected_diagnostic': diagnostic,
        'vtool_must_not_run': no_vtool, 'accepted': accepted,
        'elapsed_seconds': round(elapsed, 6),
        'stdout': str(stdout.relative_to(OUT)),
        'stderr': str(stderr.relative_to(OUT)),
        'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
        'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(),
    }
    entries.append(entry)
    print(json.dumps(entry), flush=True)

execute('whole-script-syntax', [args.bash, '-n', str(HERE / 'build_macos_app.corrected.sh')], 0)
comparisons = [
    ('equal-short', '13.0', '13.0', 0),
    ('equal-long-left', '13.0.0', '13.0', 0),
    ('equal-long-right', '13.0', '13.0.0', 0),
    ('equal-major-only', '13', '13.0.0', 0),
    ('equal-leading-zero', '00013.000.0000', '13.0', 0),
    ('equal-all-zero', '0.00.000', '0', 0),
    ('patch-two-digits-lower', '13.0.9', '13.0.10', 0),
    ('patch-two-digits-higher', '13.0.10', '13.0.9', 1),
    ('patch-leading-zero-lower', '13.0.009', '13.0.10', 0),
    ('minor-order-lower', '13.9.999', '13.10', 0),
    ('minor-order-higher', '13.10', '13.9.999', 1),
    ('major-order-lower', '9.99.99', '10.0', 0),
    ('major-order-higher', '14.0', '13.99.99', 1),
    ('wide-component-lower', '13.0.99999999999999999999999999999999', '13.0.100000000000000000000000000000000', 0),
    ('wide-component-higher', '13.0.100000000000000000000000000000000', '13.0.99999999999999999999999999999999', 1),
    ('invalid-empty-left', '', '13.0', 2),
    ('invalid-empty-right', '13.0', '', 2),
    ('invalid-suffix', '13.0beta', '13.0', 2),
    ('invalid-negative', '-13.0', '13.0', 2),
    ('invalid-plus', '+13.0', '13.0', 2),
    ('invalid-extra-component', '13.0.0.0', '13.0', 2),
    ('invalid-empty-component', '13..0', '13.0', 2),
    ('invalid-trailing-dot', '13.0.', '13.0', 2),
    ('invalid-leading-space', ' 13.0', '13.0', 2),
    ('invalid-exponent', '13e0', '13.0', 2),
    ('invalid-newline', '13.0\n14.0', '13.0', 2),
]
for name, left, right, code in comparisons:
    execute(name, [args.bash, str(HERE / 'isolated-entrypoint.sh'),
                   str(HERE / 'extracted-functions.sh'), 'compare', left, right], code)

def modern(minimum='13.0', *, platform='MACOS', index=9, tool=True):
    out = f'''Load command {index}
      cmd LC_BUILD_VERSION
  cmdsize 32
 platform {platform}
    minos {minimum}
      sdk 26.0
   ntools {1 if tool else 0}
'''
    if tool:
        out += '     tool LD\n  version 1200.999.3\n'
    return out

def legacy(minimum='10.15', *, kind='LC_VERSION_MIN_MACOSX', index=9):
    return f'''Load command {index}
      cmd {kind}
  cmdsize 16
  version {minimum}
      sdk 26.0
'''

def thin(body):
    return '/fixture/libproof.dylib:\n' + body

def universal(first, second):
    return ('/fixture/libproof.dylib (architecture x86_64):\n' + first + '\n' +
            '/fixture/libproof.dylib (architecture arm64):\n' + second)

cases = [
    ('thin-modern-equal', thin(modern()), '13.0', 0, None, 0),
    ('thin-modern-trailing-zero', thin(modern('13.0.0')), '13.0', 0, None, 0),
    ('thin-modern-leading-zero', thin(modern('013.00.000')), '13.0.0', 0, None, 0),
    ('thin-modern-tool-version-ignored', thin(modern('12.3')), '12.3', 0, None, 0),
    ('thin-legacy', thin(legacy()), '10.15', 0, None, 0),
    ('thin-legacy-too-new', thin(legacy('10.15.1')), '10.15', 1, 'needs macOS 10.15.1', 0),
    ('universal-legacy-modern', universal(legacy(), modern()), '13.0', 0, None, 0),
    ('universal-patch-max-forward', universal(modern('13.0.9'), modern('13.0.10')), '13.0.9', 1, '(architecture arm64) needs macOS 13.0.10', 0),
    ('universal-patch-max-reverse', universal(modern('13.0.10'), modern('13.0.9')), '13.0.9', 1, '(architecture x86_64) needs macOS 13.0.10', 0),
    ('universal-both-compatible', universal(modern('13.0.9'), modern('13.0.10')), '13.0.10', 0, None, 0),
    ('universal-later-major', universal(modern('12.9'), modern('14.0')), '13.0', 1, '(architecture arm64) needs macOS 14.0', 0),
    ('universal-earlier-major', universal(modern('14.0'), modern('12.9')), '13.0', 1, '(architecture x86_64) needs macOS 14.0', 0),
    ('universal-missing-first', universal('', modern()), '13.0', 1, '(architecture x86_64): no macOS deployment command', 0),
    ('universal-missing-last', universal(modern(), ''), '13.0', 1, '(architecture arm64): no macOS deployment command', 0),
    ('universal-malformed-first', universal(modern('13.bad'), modern()), '13.0', 1, '(architecture x86_64) declares malformed minimum macOS', 0),
    ('universal-malformed-last', universal(modern(), modern('13.bad')), '13.0', 1, '(architecture arm64) declares malformed minimum macOS', 0),
    ('multiple-commands-compatible', thin(modern('12.0') + modern('13.0', index=10)), '13.0', 0, None, 0),
    ('multiple-commands-later-too-new', thin(modern('12.0') + modern('13.0.10', index=10)), '13.0.9', 1, 'needs macOS 13.0.10', 0),
    ('empty-output', '', '13.0', 1, 'no architecture header', 0),
    ('missing-header', modern(), '13.0', 1, 'missing architecture header', 0),
    ('missing-minos', thin(modern().replace('    minos 13.0\n', '')), '13.0', 1, 'missing minimum macOS', 0),
    ('missing-platform', thin(modern().replace(' platform MACOS\n', '')), '13.0', 1, 'missing or non-macOS platform', 0),
    ('wrong-platform', thin(modern(platform='IOS')), '13.0', 1, 'missing or non-macOS platform', 0),
    ('malformed-minos-empty', thin(modern('')), '13.0', 1, 'malformed minimum macOS', 0),
    ('malformed-minos-extra-field', thin(modern('13.0 stray')), '13.0', 1, 'malformed minimum macOS', 0),
    ('malformed-minos-negative', thin(modern('-13.0')), '13.0', 1, 'declares malformed minimum macOS', 0),
    ('malformed-minos-dot', thin(modern('13..0')), '13.0', 1, 'declares malformed minimum macOS', 0),
    ('duplicate-minos', thin(modern().replace('    minos 13.0\n', '    minos 13.0\n    minos 14.0\n')), '13.0', 1, 'malformed minimum macOS', 0),
    ('minos-before-command', thin('    minos 13.0\n' + modern()), '13.0', 1, 'malformed minimum macOS', 0),
    ('legacy-missing-version', thin(legacy().replace('  version 10.15\n', '')), '13.0', 1, 'missing minimum macOS', 0),
    ('legacy-malformed-version', thin(legacy('10.bad')), '13.0', 1, 'declares malformed minimum macOS', 0),
    ('legacy-wrong-platform', thin(legacy(kind='LC_VERSION_MIN_IPHONEOS')), '13.0', 1, 'unsupported deployment command', 0),
    ('vtool-failed-with-plausible-output', thin(modern()), '13.0', 1, 'could not read macOS deployment commands', 7),
    ('invalid-app-minimum', thin(modern()), '13.bad', 1, 'app declares malformed minimum macOS', 0),
]
for name, fixture, app_minimum, code, diagnostic, vtool_exit in cases:
    path = FIXTURES / f'{name}.txt'
    path.write_text(fixture)
    execute(name, [args.bash, str(HERE / 'isolated-entrypoint.sh'),
                   str(HERE / 'extracted-functions.sh'), 'library',
                   '/fixture/libproof.dylib', app_minimum, str(path),
                   str(vtool_exit), str(RAW / f'{name}.vtool-calls')],
            code, diagnostic, name == 'invalid-app-minimum')

version = subprocess.check_output([args.bash, '--version'], text=True)
(OUT / 'bash-version.txt').write_text(version)
summary = {
    'accepted': all(entry['accepted'] for entry in entries),
    'checks': len(entries),
    'syntax_checks': 1,
    'comparison_checks': len(comparisons),
    'vtool_fixture_checks': len(cases),
    'failures': [entry['name'] for entry in entries if not entry['accepted']],
    'bash': args.bash,
    'bash_version': version.splitlines()[0],
    'host': os.uname().sysname,
    'real_macos_build_or_sign': False,
    'source_binding': json.loads((HERE / 'source-receipt.json').read_text()),
    'checks_manifest': entries,
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k:v for k,v in summary.items() if k != 'checks_manifest'}, indent=2))
raise SystemExit(0 if summary['accepted'] else 1)
