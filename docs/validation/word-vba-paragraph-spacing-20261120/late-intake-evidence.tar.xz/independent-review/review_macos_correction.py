#!/usr/bin/env python3
"""Independent scratch-only checks for the incoming macOS floor correction."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent / 'late-macos-independent'
SOURCE = BASE / 'macos-build-correction-20261120'
FUNCTIONS = SOURCE / 'extracted-functions.sh'
SCRIPT = SOURCE / 'build_macos_app.corrected.sh'


def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def modern(minimum, tool_version=None):
    text = f'Load command 0\n      cmd LC_BUILD_VERSION\n  cmdsize 32\n platform MACOS\n    minos {minimum}\n      sdk 26.0\n   ntools 1\n'
    if tool_version is not None:
        text += f'     tool CLANG\n  version {tool_version}\n'
    return text


def legacy(minimum):
    return f'Load command 1\n      cmd LC_VERSION_MIN_MACOSX\n  cmdsize 16\n  version {minimum}\n      sdk 10.15\n'


def main():
    OUT.mkdir(exist_ok=True)
    before = {p.name: identity(p) for p in [FUNCTIONS, SCRIPT, SOURCE / 'macos-minimum-version.patch', SOURCE / 'source-receipt.json']}
    receipt = json.loads((SOURCE / 'source-receipt.json').read_text())
    assert before[SCRIPT.name]['sha256'] == receipt['corrected_sha256']
    assert before[FUNCTIONS.name]['sha256'] == receipt['extracted_functions_sha256']
    corrected = SCRIPT.read_bytes()
    extracted = FUNCTIONS.read_bytes()
    assert extracted in corrected
    env = os.environ.copy()
    env['BASH_COMPAT'] = '3.2'
    cases = []
    comparisons = [
        ('13.0.0', '13', 0), ('00013.00.000', '13.0', 0),
        ('13', '13.0.0', 0), ('13.0.10', '13.0.9', 1),
        ('13.0.9', '13.0.10', 0), ('12.255.255', '13.0', 0),
        ('13.1', '13.0.255', 1), ('13.0.00000000000000000000001', '13.0', 1),
        ('0.0.0', '00', 0), ('9' * 200, '1' + '0' * 200, 0),
        ('1' + '0' * 200, '9' * 200, 1), ('13.0.0.0', '13', 2),
        ('13.', '13.0', 2), ('+13.0', '13', 2), ('13.0 ', '13', 2),
        ('13.0', '13\n', 2), ('13.0', '', 2), ('13.0', '13.0rc1', 2),
    ]
    for i, (left, right, expected) in enumerate(comparisons):
        command = ['bash', '-c', 'source "$1"; version_le "$2" "$3"', 'independent-version', str(FUNCTIONS), left, right]
        result = subprocess.run(command, env=env, capture_output=True, text=True)
        cases.append({'case': f'comparison-{i+1}', 'left': left, 'right': right, 'expected_exit': expected, 'actual_exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr, 'pass': result.returncode == expected})
    thin = '/tmp/Test App.app/Contents/Frameworks/libtest.dylib:\n'
    arm = '/tmp/libtest.dylib (architecture arm64):\n'
    intel = '/tmp/libtest.dylib (architecture x86_64):\n'
    fixtures = [
        ('thin-modern-equal', thin + modern('13.0.0'), '13', 0, 0),
        ('thin-legacy', thin + legacy('10.15'), '13.0', 0, 0),
        ('ignore-modern-tool-version', thin + modern('13', '999999.99.99'), '13', 0, 0),
        ('universal-modern-and-legacy', arm + modern('13') + intel + legacy('10.15'), '13', 0, 0),
        ('patch-higher-last', arm + modern('13.0.9') + intel + modern('13.0.10'), '13.0.9', 1, 0),
        ('patch-higher-first', arm + modern('13.0.10') + intel + modern('13.0.9'), '13.0.9', 1, 0),
        ('second-command-higher', thin + modern('12.0') + legacy('14.0'), '13', 1, 0),
        ('first-architecture-empty', arm + intel + legacy('10.15'), '13', 1, 0),
        ('last-architecture-empty', arm + modern('12') + intel, '13', 1, 0),
        ('modern-tool-only', thin + modern('12', '1').replace('    minos 12\n', ''), '13', 1, 0),
        ('legacy-malformed-version', thin + legacy('10.15.0.0'), '13', 1, 0),
        ('duplicate-modern-minimum', thin + modern('12') + 'minos 13\n', '13', 1, 0),
        ('duplicate-legacy-minimum', thin + legacy('10.15') + 'version 11\n', '13', 1, 0),
        ('wrong-modern-platform', thin + modern('12').replace('platform MACOS', 'platform IOS'), '13', 1, 0),
        ('wrong-legacy-platform', thin + legacy('10').replace('LC_VERSION_MIN_MACOSX', 'LC_VERSION_MIN_IPHONEOS'), '13', 1, 0),
        ('absent-header', modern('12'), '13', 1, 0),
        ('vtool-failure', thin + modern('12'), '13', 1, 2),
        ('malformed-app', thin + modern('12'), '13.0beta', 1, 0),
    ]
    command_text = 'source "$1"; vtool() { cat "$VTOOL_FIXTURE"; return "$VTOOL_EXIT"; }; verify_library_minimum_os "/tmp/Test App.app/libtest.dylib" "$2"'
    for name, text, app, expected, exit_code in fixtures:
        fixture = OUT / (name + '.txt')
        fixture.write_text(text)
        case_env = {**env, 'VTOOL_FIXTURE': str(fixture), 'VTOOL_EXIT': str(exit_code)}
        result = subprocess.run(['bash', '-c', command_text, 'independent-library', str(FUNCTIONS), app], env=case_env, capture_output=True, text=True)
        cases.append({'case': name, 'fixture': fixture.name, 'fixture_identity': identity(fixture), 'app_minimum': app, 'mock_vtool_exit': exit_code, 'expected_exit': expected, 'actual_exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr, 'pass': result.returncode == expected})
    after = {p.name: identity(p) for p in [FUNCTIONS, SCRIPT, SOURCE / 'macos-minimum-version.patch', SOURCE / 'source-receipt.json']}
    assert before == after
    report = {
        'status': 'PASS' if all(c['pass'] for c in cases) else 'FAIL',
        'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_before': before, 'source_after': after,
        'passed': sum(c['pass'] for c in cases), 'failed': sum(not c['pass'] for c in cases),
        'comparison_cases': len(comparisons), 'parser_fixture_cases': len(fixtures),
        'cases': cases, 'bash_version': subprocess.check_output(['bash', '--version'], text=True).splitlines()[0],
        'bash_compatibility_option': 'BASH_COMPAT=3.2 under installed Bash 5; not an actual Bash 3/macOS execution',
        'source_format_reference': '../apple-vtool-source-reference.json',
        'scope': 'Independent isolated comparator and Apple-format fixture checks only; no native macOS build, signing, packaging, or actual vtool run.',
        'word_regression_total_contribution': 0,
        'repository_modified': False,
    }
    (OUT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['status', 'passed', 'failed', 'comparison_cases', 'parser_fixture_cases']}))
    assert report['status'] == 'PASS'


if __name__ == '__main__':
    main()
