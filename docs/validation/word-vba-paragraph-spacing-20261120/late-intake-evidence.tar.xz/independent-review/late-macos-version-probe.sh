version_le() { [[ "$(printf '%s\n%s\n' "$1" "$2" | sort -t. -k1,1n -k2,2n -k3,3n | head -1)" == "$1" ]]; }
for pair in "13.0 13.0" "12.3 13.0" "14.0 13.0" "13.0.0 13.0" "13.0.10 13.0.9"; do read -r left right <<< "$pair"; if version_le "$left" "$right"; then printf "%s <= %s true\n" "$left" "$right"; else printf "%s <= %s false\n" "$left" "$right"; fi; done
printf "13.0.9\n13.0.10\n" | sort -t. -k1,1n -k2,2n | tail -1
