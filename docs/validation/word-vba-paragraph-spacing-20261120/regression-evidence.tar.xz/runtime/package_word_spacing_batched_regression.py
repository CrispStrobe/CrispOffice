#!/usr/bin/env python3
"""Package accepted original-suite regression evidence without repository edits."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import tarfile

import run_word_spacing_full_gate as gate
import run_word_spacing_batched_gate as batched

BASE = Path(__file__).resolve().parent.parent
RUNTIME = BASE / 'runtime'
OUT = RUNTIME / 'word-spacing-batched-final-0201b549'
DEST = RUNTIME / 'word-spacing-regression-final.tar.xz'
INDEX = RUNTIME / 'word-spacing-regression-members.json'
RECEIPT = RUNTIME / 'word-spacing-regression-packaging.json'
README = RUNTIME / 'word-spacing-regression-reproduction.md'
EXPECTED = '0201b549d0dc3f601c50e36255d557034cb01699'


def identity(path: Path) -> dict:
    return {'bytes': path.stat().st_size, 'sha256': gate.file_sha(path),
            'mode': '100755' if path.stat().st_mode & 0o111 else '100644'}


def normalize(info: tarfile.TarInfo) -> tarfile.TarInfo:
    info.mtime = 0
    info.uid = info.gid = 0
    info.uname = info.gname = ''
    info.pax_headers = {}
    return info


def write_archive(destination: Path, files: set[Path]) -> None:
    with tarfile.open(destination, 'w:xz', preset=6) as archive:
        for path in sorted(files):
            archive.add(path, arcname=str(path.relative_to(BASE)), recursive=False, filter=normalize)


assert not DEST.exists(), 'Do not overwrite accepted evidence'
assert gate.git('rev-parse', 'HEAD') == EXPECTED
summary = gate.load(OUT / 'summary.json')
assert summary['accepted'] and summary['complete']
assert summary['source_commit'] == EXPECTED
assert summary['file_count'] == 75 and summary['passing_cases'] == 2799
assert summary['previous_case_identities']['exact_match']
assert all(row['source_unchanged'] for row in summary['previous_case_identities']['per_file'].values())
inputs = gate.load(OUT / 'inputs-final.json.gz')
current = gate.source_manifest()
assert current['head_matches_worktree'] and current['entries'] == inputs['entries']
assert batched.runtime(OUT) == inputs['runtime_inputs']
assert (RUNTIME / 'word-spacing-concurrency-probe.stdout').read_text().strip() == '2'
assert not (RUNTIME / 'word-spacing-concurrency-probe.stderr').read_text().strip()

# These aliases and diagnostic annotations preserve the frozen gate's counts
# and verdict; all original per-invocation evidence remains untouched.
earliest = min(summary['batches'], key=lambda row: row['started_utc'])['batch_id']
before_source = OUT / f'batch-{earliest:02d}' / 'inputs-before.json.gz'
for destination, source in [(OUT / 'inputs-before.json.gz', before_source),
                            (OUT / 'inputs-after.json.gz', OUT / 'inputs-final.json.gz')]:
    if destination.exists():
        assert destination.read_bytes() == source.read_bytes()
    else:
        destination.write_bytes(source.read_bytes())
gate.save(OUT / 'root-binding-aliases.json', {
    'inputs-before.json.gz': {'byte_copy_of': str(before_source.relative_to(OUT)),
                              'sha256': gate.file_sha(before_source)},
    'inputs-after.json.gz': {'byte_copy_of': 'inputs-final.json.gz',
                             'sha256': gate.file_sha(OUT / 'inputs-final.json.gz')},
})
diagnostics = gate.load(OUT / 'diagnostics/attempts.json')
summary['diagnostic_attempts'] = [{
    key: row[key] for key in ['batch_id', 'accepted', 'count_contribution',
                              'preserved_directory', 'tool_process_exit_code',
                              'terminal_done_present', 'execution_receipt_present',
                              'automatic_after_snapshot_present', 'errors',
                              'resource_contention_cause']
} for row in diagnostics]
summary['accepted_selection_excludes_diagnostics'] = True
summary['hashes'] = {str(p.relative_to(OUT)): gate.file_sha(p)
                     for p in sorted(OUT.rglob('*')) if p.is_file() and p != OUT / 'summary.json'}
gate.save(OUT / 'summary.json', summary)

README.write_text(f'''# Word paragraph-spacing original-suite regression evidence

Accepted source commit: `{EXPECTED}`.
Accepted source tree: `{summary['source_tree']}`.

The local gate passed all **2,799 cases across 75 original test modules**, with
zero failures, skips, or reporter errors. Each original Dart file ran as its own
normal package:test VM suite/isolate. All 75 files occur exactly once across eight
accepted bounded invocations (seven groups of ten modules and one group of five). Each
invocation has its own successful terminal reporter event, zero process exit,
and before/after source and runtime bindings. At most two invocations ran at
once, each with concurrency two, for a maximum of four original suites. No
aggregate harness or shared test isolate was introduced.
The frozen launcher still defaults to one suite, but the gate passes a later
`--concurrency=2` option. The included package:test configuration-parser probe
confirms that its effective value is two.

All 70 previous modules remain byte-identical to their accepted source. Their
2,569 exact `(file, name, occurrence)` case identities match the prior raw
reporter and case inventory. The new modules contribute 99 compiler, 96 native,
and 23 integration cases. Two additional existing line-layout modules contribute
12 cases. These categories are disjoint and total 2,799.

Every before/after snapshot across all eight invocations binds {summary['input_entries']:,} repository inputs by
path, Git mode/blob, byte size, and SHA-256. The two Liberation Sans/Mono font
fixtures used by actual line-box tests are included. The run also fingerprints
{summary['runtime_input_entries']:,} runtime files, including the launcher, env,
test runner kernel, SDK executables/snapshots/libraries, configured hosted
package lib/bin sources and manifests, package configurations, and coordinator
interpreter. Source and recorded runtime inputs remain identical across all 16 phase snapshots
and the final audit snapshot. This runtime file set does not claim to census every shared
operating-system dependency.

The evidence retains the full raw JSON reporter, stderr, exact invocation,
timestamps, declared/per-file counts, complete case IDs, before/after manifests,
prior raw-event proof, and frozen gate/audit source. The earlier long invocation was interrupted without a process exit receipt,
automatic after snapshot, or terminal done event. Its 2,679 partial completions
are diagnostic only and excluded from the accepted 2,799-case total. Its raw
files and a separate post-interruption observation are retained in this archive
under runtime/word-spacing-final-0201b549 and
runtime/word-spacing-interrupted-observation. The post-interruption observation
is not represented as a normal completion snapshot.

Two overlapping CLI-heavy attempts also hit the unchanged two-minute per-test
timeout: two reporter errors in batch 2 and one in batch 3. Batch 3 ended with
exit 1 and complete before/after bindings. Batch 2 had stalled cleanup and was
interrupted only after its observed timeout failures; its owned session returned
exit 130, with no automatic completion/after receipt. Their original files and
launcher logs are retained with byte-for-byte relocation proofs under the
accepted output directory's diagnostics folder. A separately labeled observation
captures the interrupted batch's unchanged inputs. Resource contention is an
inference from overlapping CLI processes and reduced available memory; the
errors themselves are precisely recorded timeout exceptions. Serial replacements
passed using the same per-invocation concurrency 2 and unchanged timeout 4x.
These failed attempts contribute zero cases to the accepted total. Remaining
CLI-heavy invocations ran serially. Other development attempts remain separate.

Root inputs-before/after files are exact aliases of the earliest accepted
batch's before snapshot and final audit snapshot; root-binding-aliases.json
records their provenance. Individual batch snapshots remain authoritative.
No GitHub Actions were queried or awaited.

## Reproduce in a fresh location

1. Clone the repository with history into `<fresh>/quds_office_suite`, then
   check out the accepted source commit above. All source and font inputs are
   supplied by that Git commit; the archive does not duplicate the repository.
2. Run the included `runtime/prior/runtime/reproduce_runtime.py` with
   `--repo <fresh>/quds_office_suite`, `--runtime <fresh>/runtime/toolchain`,
   and `--record` pointing to this archive's `runtime/toolchain/environment.json`.
   The destination toolchain and fresh checkout's `.dart_tool/package_config.json`
   must not exist. The script verifies the recorded Dart 3.14.1 SDK archive digest,
   resolves all 56 exact hosted version pins, creates package configuration
   against the clone, and compiles the normal package:test runner kernel.
3. Copy `runtime/run_word_spacing_full_gate.py` and
   `runtime/run_word_spacing_batched_gate.py` into `<fresh>/runtime`, preserving
   that relative layout. The script retrieves the
   previous evidence from the checked-out repository and refuses to overwrite
   an existing gate invocation.
4. From `<fresh>`, run:

```bash
python3 runtime/run_word_spacing_batched_gate.py prepare --out runtime/regression-reproduction --source-commit {EXPECTED}
for batch in 1 2 3 4 5 6 7 8; do
  python3 runtime/run_word_spacing_batched_gate.py run-batch --out runtime/regression-reproduction --batch "$batch" || exit 1
done
python3 runtime/run_word_spacing_batched_gate.py audit --out runtime/regression-reproduction
```

The runner produces new host-path/runtime manifests and timings; those metadata
need not byte-match the original host. It must still pass the complete case,
source-stability, original-suite, and exact-prior-identity audits. Serial bounded invocations reproduce the same file/case selection; up
to two disjoint invocations may run simultaneously as in this recorded gate.
Inspect each batch-NN raw reporter for active progress.

## Archive integrity

Archive members have sorted paths, zero timestamps/UID/GID, and empty owner/group
names. The packaging script builds the archive twice and verifies identical
SHA-256 digests, then verifies every indexed member after reopening it. The
included member index covers every other archive member; the external packaging
receipt binds that index and the whole archive. SDK/hosted dependency binaries
are not vendored here; the recorded pins, archive digest and runtime manifest
retain their provenance.
''')

files = {path for path in OUT.rglob('*') if path.is_file()}
for directory in [RUNTIME / 'word-spacing-final-0201b549', RUNTIME / 'word-spacing-interrupted-observation']:
    files.update(path for path in directory.rglob('*') if path.is_file())
for batch in range(1, 9):
    for suffix in ['stdout', 'stderr']:
        files.add(RUNTIME / f'word-spacing-batch-{batch:02d}-launch.{suffix}')
for batch in [2, 3]:
    for suffix in ['stdout', 'stderr']:
        files.add(RUNTIME / f'word-spacing-batch-{batch:02d}-timeout-launch.{suffix}')
for name in [
    'run_word_spacing_full_gate.py', 'run_word_spacing_batched_gate.py',
    'package_word_spacing_batched_regression.py',
    'word-spacing-regression-reproduction.md',
    'word-spacing-concurrency-probe.dart', 'word-spacing-concurrency-probe.stdout',
    'word-spacing-concurrency-probe.stderr', 'word-spacing-gate-runner-help.txt',
    'word-spacing-gate-runner-help.stderr',
    'word-spacing-batched-audit-command.json',
    'word-spacing-batched-audit.stdout', 'word-spacing-batched-audit.stderr',
    'word-spacing-final-launch.stdout', 'word-spacing-final-launch.stderr',
    'setup-receipt.json', 'setup.stdout', 'setup.stderr',
    'prior/runtime/reproduce_runtime.py',
    'toolchain/environment.json', 'toolchain/reproduction-command.json',
    'toolchain/env.sh', 'toolchain/run-engine-tests.sh',
    'toolchain/engine-validation/packages/quds_office_engine/pubspec.yaml',
    'toolchain/engine-validation/packages/quds_office_engine/pubspec.lock',
    'toolchain/engine-validation/packages/legacy_doc_parser/pubspec.yaml',
]:
    files.add(RUNTIME / name)
files.add(gate.REPO / '.dart_tool/package_config.json')
files.add(gate.REPO / '.dart_tool/package_graph.json')
for path in files:
    assert path.is_file() and not path.is_symlink(), path
    recorded = inputs['runtime_inputs'].get(str(path))
    if recorded:
        assert identity(path)['sha256'] == recorded['sha256'], path
index = {str(path.relative_to(BASE)): identity(path) for path in sorted(files)}
gate.save(INDEX, index)
files.add(INDEX)
write_archive(DEST, files)
repeat = RUNTIME / 'word-spacing-regression-determinism-check.tar.xz'
assert not repeat.exists()
write_archive(repeat, files)
deterministic = gate.file_sha(DEST) == gate.file_sha(repeat)
repeat.unlink()
assert deterministic
with tarfile.open(DEST, 'r:xz') as archive:
    members = archive.getmembers()
    assert len(members) == len(files)
    assert {m.name for m in members} == set(index) | {str(INDEX.relative_to(BASE))}
    assert all(m.isfile() and m.mtime == 0 and m.uid == 0 and m.gid == 0 for m in members)
    for name, expected in index.items():
        payload = archive.extractfile(name).read()
        assert len(payload) == expected['bytes']
        assert hashlib.sha256(payload).hexdigest() == expected['sha256']
assert gate.git('rev-parse', 'HEAD') == EXPECTED
assert gate.source_manifest()['entries'] == current['entries']
assert batched.runtime(OUT) == inputs['runtime_inputs']
receipt = {
    'accepted': True, 'source_commit': EXPECTED, 'source_tree': current['source_tree'],
    'source_inputs': len(current['entries']), 'runtime_inputs': len(inputs['runtime_inputs']),
    'qualified_source_unchanged_through_packaging': True,
    'recorded_runtime_unchanged_through_packaging': True,
    'regression_cases': summary['passing_cases'], 'regression_modules': summary['file_count'],
    'accepted_batch_count': summary['batch_count'],
    'interrupted_attempt_included_as_diagnostic_only': True,
    'two_timeout_attempts_included_as_diagnostic_only': True,
    'member_count': len(files), 'all_indexed_member_hashes_verified': True,
    'deterministic_archive_second_build_matches': deterministic,
    'archive': str(DEST), **identity(DEST),
    'member_index': str(INDEX), 'member_index_sha256': gate.file_sha(INDEX),
}
gate.save(RECEIPT, receipt)
print(json.dumps(receipt, indent=2))
