#!/usr/bin/env python3
"""Run original Word/Office VM suites and audit source-bound local evidence."""
from __future__ import annotations

import argparse
import collections
import datetime as dt
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time
from urllib.parse import unquote, urljoin, urlparse

BASE = Path(__file__).resolve().parent.parent
REPO = BASE / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
TOOLCHAIN = BASE / 'runtime/toolchain'
PRIOR_DIR = REPO / 'docs/validation/word-vba-list-levels-20261120'
PRIOR_REPORT = PRIOR_DIR / 'regression.json'
PRIOR_ARCHIVE = PRIOR_DIR / 'regression-evidence.tar.xz'
PREFIXES = [
    'packages/quds_office_engine/lib',
    'packages/quds_office_engine/test',
    'packages/quds_office_engine/tool',
    'packages/quds_office_engine/example',
    'packages/legacy_doc_parser/lib',
]
CONFIGS = [
    'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
    'packages/quds_office_engine/pubspec.yaml',
    'packages/quds_office_engine/analysis_options.yaml',
    'packages/legacy_doc_parser/pubspec.yaml',
    'packages/legacy_doc_parser/analysis_options.yaml',
    'packages/quds_office_editor/fonts/LiberationSans-Regular.ttf',
    'packages/quds_office_editor/fonts/LiberationMono-Regular.ttf',
]
ADDITIONS = {
    'office_vba_word_line_spacing_test.dart': 99,
    'office_macro_word_line_spacing_test.dart': 96,
    'office_vba_word_line_spacing_integration_test.dart': 23,
    'word_font_line_metrics_test.dart': 5,
    'word_line_box_fidelity_test.dart': 7,
}


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def save(path: Path, value: object) -> None:
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(gzip.compress(data, mtime=0) if path.suffix == '.gz' else data)


def load(path: Path) -> object:
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


def source_manifest() -> dict:
    names = {name for name in CONFIGS if (REPO / name).is_file()}
    for prefix in PREFIXES:
        names.update(str(p.relative_to(REPO)) for p in (REPO / prefix).rglob('*') if p.is_file())
    tree = {}
    raw = subprocess.check_output(['git', 'ls-tree', '-rz', 'HEAD', '--', *PREFIXES, *CONFIGS], cwd=REPO)
    for record in raw.split(b'\0'):
        if not record:
            continue
        metadata, path = record.split(b'\t', 1)
        mode, kind, blob = metadata.decode().split()
        tree[path.decode()] = {'mode': mode, 'type': kind, 'blob': blob}
    names.update(tree)
    entries = {}
    for name in sorted(names):
        path = REPO / name
        if path.is_symlink() or not path.is_file():
            entries[name] = {'missing_or_symlink': True, 'head': tree.get(name)}
            continue
        data = path.read_bytes()
        entries[name] = {
            'bytes': len(data), 'sha256': sha(data),
            'worktree_mode': '100755' if path.stat().st_mode & 0o111 else '100644',
            'worktree_blob': hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest(),
            'head': tree.get(name),
        }
    matches = all(not e.get('missing_or_symlink') and e['head'] == {
        'mode': e['worktree_mode'], 'type': 'blob', 'blob': e['worktree_blob'],
    } for e in entries.values())
    return {
        'source_commit': git('rev-parse', 'HEAD'),
        'source_tree': git('rev-parse', 'HEAD^{tree}'),
        'selection': {'directories': PREFIXES, 'configuration_files': CONFIGS},
        'head_matches_worktree': matches, 'entries': entries,
    }


def runtime_manifest(out: Path) -> dict:
    paths = {
        Path(__file__).resolve(), out / 'plan.json', out / 'prior-cases.json.gz',
        out / 'prior-inputs-before.json.gz', out / 'prior-report.json',
        TOOLCHAIN / 'env.sh', TOOLCHAIN / 'run-engine-tests.sh',
        TOOLCHAIN / 'test-runner/test-runner.dill', TOOLCHAIN / 'environment.json',
        REPO / '.dart_tool/package_config.json', REPO / '.dart_tool/package_graph.json',
        TOOLCHAIN / 'engine-validation/packages/quds_office_engine/pubspec.yaml',
        TOOLCHAIN / 'engine-validation/packages/quds_office_engine/pubspec.lock',
        TOOLCHAIN / 'engine-validation/packages/legacy_doc_parser/pubspec.yaml',
        Path(sys.executable).resolve(), Path(shutil.which('bash')).resolve(),
        Path(shutil.which('git')).resolve(),
    }
    sdk = TOOLCHAIN / 'dart-sdk'
    for prefix in [sdk / 'bin', sdk / 'lib']:
        paths.update(p for p in prefix.rglob('*') if p.is_file() and p.suffix != '.sym')
    for name in ['version', 'revision', 'sdk_packages.yaml']:
        if (sdk / name).is_file():
            paths.add(sdk / name)
    config_path = REPO / '.dart_tool/package_config.json'
    config = load(config_path)
    for package in config['packages']:
        uri = urlparse(urljoin(config_path.as_uri(), package['rootUri']))
        if uri.scheme != 'file':
            raise ValueError(f'Non-file runtime package: {package["name"]}')
        root = Path(unquote(uri.path)).resolve()
        if root.is_relative_to(REPO):
            continue
        if not root.is_relative_to(TOOLCHAIN):
            raise ValueError(f'Unexpected runtime package root: {root}')
        for prefix in [root / 'lib', root / 'bin']:
            if prefix.is_dir():
                paths.update(p for p in prefix.rglob('*') if p.is_file())
        paths.add(root / 'pubspec.yaml')
    entries = {}
    for path in sorted(paths):
        if not path.is_file():
            raise ValueError(f'Missing runtime input: {path}')
        entries[str(path)] = {
            'bytes': path.stat().st_size, 'sha256': file_sha(path),
            'mode': oct(path.stat().st_mode & 0o777),
            **({'link_target': os.readlink(path)} if path.is_symlink() else {}),
        }
    return entries


def parse_events(raw: bytes, files: list[str], *, legacy: bool = False) -> dict:
    problems, errors, events = [], [], []
    for number, line in enumerate(raw.splitlines(), 1):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
            if not isinstance(event, dict):
                raise ValueError('Event is not an object')
            events.append(event)
        except (ValueError, TypeError) as error:
            problems.append(f'Malformed reporter line {number}: {error}')
    starts, dones, groups, suites = {}, {}, {}, {}
    for event in events:
        kind = event.get('type')
        if kind in {'testStart', 'testDone', 'group', 'suite'}:
            value = event['test'] if kind == 'testStart' else event['group'] if kind == 'group' else event['suite'] if kind == 'suite' else event
            target = starts if kind == 'testStart' else dones if kind == 'testDone' else groups if kind == 'group' else suites
            key = value['testID'] if kind == 'testDone' else value['id']
            if key in target:
                problems.append(f'Duplicate {kind} identity {key}')
            target[key] = value
        elif kind == 'error':
            errors.append(event)
    if set(starts) != set(dones):
        problems.append('Complete test start/end identities differ')
    suite_files = {}
    if legacy:
        if len(suites) != 1:
            problems.append('Prior aggregate expected exactly one VM suite')
    else:
        for sid, suite in suites.items():
            candidate = Path(suite['path'])
            candidate = candidate if candidate.is_absolute() else ENGINE / candidate
            try:
                name = str(candidate.relative_to(ENGINE / 'test'))
            except ValueError:
                name = str(candidate)
            if name not in files:
                problems.append(f'Unexpected original suite path: {suite["path"]}')
            suite_files[sid] = name
        if len(suites) != len(files) or set(suite_files.values()) != set(files):
            problems.append('Observed original suites differ from the complete selected file set')
        if len(set(suite_files.values())) != len(suite_files):
            problems.append('Original file loaded in more than one suite')
    if any(suite.get('platform') != 'vm' for suite in suites.values()):
        problems.append('Non-VM suite observed')
    all_suites = [e for e in events if e.get('type') == 'allSuites']
    if len(all_suites) != 1 or all_suites[0].get('count') != (1 if legacy else len(files)):
        problems.append('allSuites declaration does not cover expected suites')
    terminal = [e for e in events if e.get('type') == 'done']
    if len(terminal) != 1 or not events or events[-1].get('type') != 'done' or terminal[0].get('success') is not True:
        problems.append('Missing unique successful final done event')
    roots = [g for g in groups.values() if g.get('parentID') is None]
    root_by_suite = collections.defaultdict(list)
    for root in roots:
        root_by_suite[root['suiteID']].append(root)
    declared, per_file = {}, {name: 0 for name in files}
    if legacy:
        for group in groups.values():
            if group.get('name') in files:
                if group['name'] in declared:
                    problems.append(f'Duplicate prior filename group: {group["name"]}')
                declared[group['name']] = group['testCount']
    else:
        for sid, name in suite_files.items():
            if len(root_by_suite[sid]) != 1:
                problems.append(f'Expected one root group for original suite {name}')
            else:
                declared[name] = root_by_suite[sid][0]['testCount']
    occurrences = collections.Counter()
    cases, hidden, skipped, failed = [], 0, 0, 0
    for tid, test in starts.items():
        result = dones.get(tid)
        if result is None:
            continue
        failed += result.get('result') != 'success'
        is_skipped = bool(result.get('skipped') or test.get('metadata', {}).get('skip'))
        skipped += is_skipped
        if result.get('hidden'):
            hidden += 1
            continue
        sid = test['suiteID']
        if any(gid not in groups or groups[gid]['suiteID'] != sid for gid in test['groupIDs']):
            problems.append(f'Invalid group identity for test {tid}')
        if legacy:
            candidates = [groups[g]['name'] for g in test['groupIDs'] if g in groups and groups[g]['name'] in files]
            if len(candidates) != 1:
                problems.append(f'No unique prior file group for test {tid}')
                continue
            name = candidates[0]
            prefix = name + ' '
            if not test['name'].startswith(prefix):
                problems.append(f'Missing prior filename prefix for test {tid}')
            original_name = test['name'][len(prefix):]
        else:
            name = suite_files.get(sid)
            original_name = test['name']
        if name not in per_file:
            problems.append(f'Unclassified test {tid}: {test["name"]}')
            continue
        occurrences[name, original_name] += 1
        cases.append({
            'file': name, 'name': original_name,
            'occurrence': occurrences[name, original_name], 'test_id': tid,
            'suite_id': sid, 'group_ids': test['groupIDs'],
            'result': result['result'], 'skipped': is_skipped,
            'line': test.get('line'), 'column': test.get('column'), 'url': test.get('url'),
        })
        per_file[name] += 1
    if set(declared) != set(files):
        problems.append('Declared file case counts do not cover every selected module')
    for name in files:
        if per_file[name] < 1 or per_file[name] != declared.get(name):
            problems.append(f'{name}: completed {per_file[name]}, declared {declared.get(name)}')
    if legacy and (len(roots) != 1 or roots[0]['testCount'] != len(cases)):
        problems.append('Prior root suite count differs from complete cases')
    if errors:
        problems.append(f'{len(errors)} reporter errors')
    if failed or skipped:
        problems.append(f'Failed={failed}; skipped={skipped}')
    return {
        'accepted': not problems, 'problems': problems, 'errors': errors,
        'case_identity': ['file', 'name', 'occurrence'], 'cases': cases,
        'passing_cases': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
        'failed_cases': failed, 'skipped_cases': skipped, 'hidden_completions': hidden,
        'suite_count': len(suites), 'per_file_cases': per_file,
        'declared_per_file_cases': declared,
        'start_ids': sorted(starts), 'completion_ids': sorted(dones),
    }


def identities(cases: list[dict]) -> set[tuple]:
    return {(c['file'], c['name'], c['occurrence']) for c in cases}


def prepare(out: Path) -> dict:
    if out.exists():
        raise ValueError(f'Use a new evidence directory: {out}')
    out.mkdir(parents=True)
    prior = load(PRIOR_REPORT)
    files = sorted(set(prior['per_file_cases']) | set(ADDITIONS))
    if prior['file_count'] != 70 or len(files) != 75:
        raise ValueError('Expected prior70 +5 module selection')
    if not {p.name for p in (ENGINE / 'test').glob('office_vba_*_test.dart')} <= set(files):
        raise ValueError('A current office_vba module is missing from the selection')
    for name in files:
        if not (ENGINE / 'test' / name).is_file():
            raise ValueError(f'Missing selected source module: {name}')
    with tarfile.open(PRIOR_ARCHIVE) as archive:
        raw_cases = archive.extractfile('runtime/word-office-final/cases.json.gz').read()
        raw_inputs = archive.extractfile('runtime/word-office-final/inputs-before.json.gz').read()
        raw_events = archive.extractfile('runtime/word-office-final/stdout.jsonl').read()
    for name, data in [('cases.json.gz', raw_cases), ('inputs-before.json.gz', raw_inputs), ('stdout.jsonl', raw_events)]:
        if sha(data) != prior['hashes'][name]:
            raise ValueError(f'Prior evidence digest mismatch: {name}')
    prior_cases = json.loads(gzip.decompress(raw_cases))
    prior_audit = parse_events(raw_events, sorted(prior['per_file_cases']), legacy=True)
    if not prior_audit['accepted'] or identities(prior_audit['cases']) != identities(prior_cases):
        raise ValueError(f'Prior raw reporter/case inventory mismatch: {prior_audit["problems"]}')
    if len(prior_cases) != 2569 or len(identities(prior_cases)) != len(prior_cases):
        raise ValueError('Expected2569 unique complete prior case identities')
    (out / 'prior-cases.json.gz').write_bytes(raw_cases)
    (out / 'prior-inputs-before.json.gz').write_bytes(raw_inputs)
    (out / 'prior-stdout.jsonl.gz').write_bytes(gzip.compress(raw_events, mtime=0))
    save(out / 'prior-report.json', prior)
    save(out / 'prior-evidence-audit.json', {k: v for k, v in prior_audit.items() if k != 'cases'})
    plan = {
        'schema': 'quds-word-spacing-original-suite-gate/v1',
        'prepared_utc': now(), 'files': files, 'file_count': len(files),
        'previous_files': sorted(prior['per_file_cases']),
        'expected_per_file_cases': {**prior['per_file_cases'], **ADDITIONS},
        'expected_total_cases': sum(prior['per_file_cases'].values()) + sum(ADDITIONS.values()),
        'prior_source_commit': prior['source_commit'],
        'prior_archive_sha256': file_sha(PRIOR_ARCHIVE),
        'prior_report_sha256': file_sha(PRIOR_REPORT),
        'prior_raw_case_sha256': sha(raw_cases), 'prior_raw_events_sha256': sha(raw_events),
        'execution': 'Original test files passed directly to package:test as75 separate VM suites; source compiler; at most2 suites concurrently; each suite keeps normal test sequencing and isolation.',
        'concurrency': 2,
        'concurrency_review': {
            'cli_override': 'wrapper concurrency1 followed by explicit concurrency2; package:test config parser probe confirms2',
            'temp_directories': 'CLI tests use createTempSync with unique suffixes; no selected test assigns Directory.current.',
            'fixed_output_directories': ['build/fidelity-styles', 'build/fidelity-style-toggles', 'build/fidelity-word-compatibility', 'build/fidelity-word-edits'],
            'fixed_output_scope': 'Each fixed output directory belongs to one selected module; no cross-module overlap found.',
        },
        'github_actions_queried_or_awaited': False,
    }
    save(out / 'plan.json', plan)
    return plan


def audit(out: Path) -> dict:
    plan = load(out / 'plan.json')
    command = load(out / 'command.json')
    result = load(out / 'execution.json')
    before = load(out / 'inputs-before.json.gz')
    after = load(out / 'inputs-after.json.gz')
    summary = parse_events((out / 'stdout.jsonl').read_bytes(), plan['files'])
    cases = summary.pop('cases')
    problems = summary['problems']
    previous_cases = load(out / 'prior-cases.json.gz')
    previous_inputs = load(out / 'prior-inputs-before.json.gz')
    current_previous = [c for c in cases if c['file'] in plan['previous_files']]
    previous_identity_set = identities(previous_cases)
    current_identity_set = identities(current_previous)
    missing = sorted(previous_identity_set - current_identity_set)
    extra = sorted(current_identity_set - previous_identity_set)
    per_file_identity = {}
    for name in plan['previous_files']:
        path = 'packages/quds_office_engine/test/' + name
        old = {i for i in previous_identity_set if i[0] == name}
        new = {i for i in current_identity_set if i[0] == name}
        per_file_identity[name] = {
            'source_unchanged': previous_inputs['entries'][path]['sha256'] == before['entries'][path]['sha256'],
            'previous_cases': len(old), 'current_cases': len(new),
            'exact_case_identities_match': old == new,
        }
    if missing or extra:
        problems.append('Previous70 module exact case identities changed')
    if summary['per_file_cases'] != plan['expected_per_file_cases']:
        problems.append('Completed per-file case counts differ from declared gate expectations')
    if result['exit_code'] != 0:
        problems.append(f'Runner exit code {result["exit_code"]}')
    unchanged = before['entries'] == after['entries']
    runtime_unchanged = before['runtime_inputs'] == after['runtime_inputs']
    if not unchanged:
        problems.append('Qualified source changed during gate')
    if not runtime_unchanged:
        problems.append('Recorded runtime inputs changed during gate')
    if before['source_commit'] != after['source_commit'] or before['source_tree'] != after['source_tree']:
        problems.append('HEAD/tree changed during gate')
    if not before['head_matches_worktree'] or not after['head_matches_worktree']:
        problems.append('Qualified source does not exactly match HEAD Git modes/blobs')
    summary.update({
        'schema': plan['schema'], 'complete': True, 'accepted': not problems,
        'source_commit': before['source_commit'], 'source_tree': before['source_tree'],
        'execution': plan['execution'], 'file_count': len(plan['files']),
        'input_entries': len(before['entries']), 'inputs_unchanged': unchanged,
        'runtime_input_entries': len(before['runtime_inputs']), 'runtime_inputs_unchanged': runtime_unchanged,
        'head_matches_worktree': before['head_matches_worktree'] and after['head_matches_worktree'],
        'previous_case_identities': {
            'exact_match': not missing and not extra, 'previous_cases': len(previous_identity_set),
            'current_cases': len(current_identity_set), 'missing': missing, 'extra': extra,
            'per_file': per_file_identity,
        },
        'started_utc': command['started_utc'], 'finished_utc': result['finished_utc'],
        'exit_code': result['exit_code'], 'seconds': result['seconds'],
        'github_actions_queried_or_awaited': False,
    })
    save(out / 'cases.json.gz', cases)
    save(out / 'case-identity-comparison.json', summary['previous_case_identities'])
    hashes = {p.name: file_sha(p) for p in sorted(out.iterdir()) if p.is_file() and p.name not in {'summary.json', 'archive-index.json'}}
    summary['hashes'] = hashes
    save(out / 'summary.json', summary)
    return summary


def run(out: Path, expected_commit: str) -> int:
    plan = load(out / 'plan.json') if out.exists() else prepare(out)
    if (out / 'stdout.jsonl').exists() or (out / 'command.json').exists():
        raise ValueError('Refusing to overwrite a previous gate invocation')
    if git('rev-parse', 'HEAD') != expected_commit:
        raise ValueError('HEAD differs from the authorized final source checkpoint')
    before = source_manifest()
    if not before['head_matches_worktree']:
        raise ValueError('Qualified source is dirty or missing from HEAD')
    before['runtime_inputs'] = runtime_manifest(out)
    save(out / 'inputs-before.json.gz', before)
    command = [str(TOOLCHAIN / 'run-engine-tests.sh'), '--concurrency=2', '--reporter=json', *['test/' + name for name in plan['files']]]
    save(out / 'command.json', {'argv': command, 'cwd': str(ENGINE), 'started_utc': now(),
        'expected_source_commit': expected_commit, 'collector_sha256': file_sha(Path(__file__))})
    print(json.dumps({'event': 'started', 'source': expected_commit, 'files': len(plan['files']),
        'expected_cases': plan['expected_total_cases'], 'source_inputs': len(before['entries']),
        'runtime_inputs': len(before['runtime_inputs']), 'output': str(out)}), flush=True)
    started = time.monotonic()
    with (out / 'stdout.jsonl').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        process = subprocess.run(command, cwd=ENGINE, stdout=stdout, stderr=stderr)
    save(out / 'execution.json', {'exit_code': process.returncode, 'seconds': round(time.monotonic() - started, 3), 'finished_utc': now()})
    after = source_manifest()
    after['runtime_inputs'] = runtime_manifest(out)
    save(out / 'inputs-after.json.gz', after)
    summary = audit(out)
    print(json.dumps({k: summary[k] for k in ['accepted', 'source_commit', 'file_count', 'passing_cases', 'failed_cases', 'skipped_cases', 'input_entries', 'runtime_input_entries', 'seconds', 'problems']}), flush=True)
    return 0 if summary['accepted'] else 1


def status(out: Path) -> None:
    path = out / 'stdout.jsonl'
    if not path.exists():
        print(json.dumps({'started': False, 'output': str(out)}))
        return
    events = []
    for line in path.read_text().splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    done = {e['testID']: e for e in events if e.get('type') == 'testDone'}
    suites = {e['suite']['id']: e['suite']['path'] for e in events if e.get('type') == 'suite'}
    counts = collections.Counter(suites[starts[tid]['suiteID']] for tid, d in done.items() if not d.get('hidden'))
    current = [t['name'] for tid, t in starts.items() if tid not in done]
    print(json.dumps({'suites_seen': len(suites), 'completed_visible_cases': sum(counts.values()), 'current': current,
        'errors': [e for e in events if e.get('type') == 'error'], 'per_file_completed': counts,
        'last_event': events[-1] if events else None, 'stderr_bytes': (out / 'stderr.log').stat().st_size}, indent=2))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'run', 'audit', 'status'])
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--source-commit')
    args = parser.parse_args()
    out = args.out.resolve()
    if args.action == 'prepare':
        result = prepare(out)
        print(json.dumps({'prepared': str(out), 'files': result['file_count'], 'expected_cases': result['expected_total_cases']}))
    elif args.action == 'run':
        if not args.source_commit:
            parser.error('run requires --source-commit')
        return run(out, args.source_commit)
    elif args.action == 'audit':
        result = audit(out)
        print(json.dumps({k: result[k] for k in ['accepted', 'passing_cases', 'failed_cases', 'skipped_cases', 'problems']}))
        return 0 if result['accepted'] else 1
    else:
        status(out)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
