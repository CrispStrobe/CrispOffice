#!/usr/bin/env python3
"""Collect bounded original-suite invocations with complete per-batch evidence."""
from __future__ import annotations

import argparse
import collections
import json
from pathlib import Path
import subprocess
import time

import run_word_spacing_full_gate as base


def runtime(out: Path) -> dict:
    result = base.runtime_manifest(out)
    for path in [Path(__file__).resolve(), out / 'batches.json']:
        result[str(path)] = {
            'bytes': path.stat().st_size,
            'sha256': base.file_sha(path),
            'mode': oct(path.stat().st_mode & 0o777),
        }
    return dict(sorted(result.items()))


def snapshot(out: Path) -> dict:
    result = base.source_manifest()
    result['runtime_inputs'] = runtime(out)
    return result


def prepare(out: Path, commit: str) -> None:
    assert base.git('rev-parse', 'HEAD') == commit
    plan = base.prepare(out)
    plan['schema'] = 'quds-word-spacing-bounded-original-suite-gate/v1'
    plan['source_commit'] = commit
    plan['execution'] = (
        'All75 original Dart test modules, each passed directly to package:test '
        'exactly once across8 bounded invocations (10 modules each; final5); '
        'normal separate VM suites, source compiler, at most2 suites per invocation '
        'and at most2 independent invocations concurrently (at most4 suites overall).'
    )
    plan['interrupted_attempt'] = {
        'directory': 'runtime/word-spacing-final-0201b549',
        'accepted': False,
        'reason': 'Coordinator session disappeared before execution receipt, after snapshot, and terminal done. The2679 visible completions are diagnostic only and excluded from this accepted gate.',
    }
    plan['bounded_batch_scheduler'] = {
        'maximum_parallel_invocations': 2, 'maximum_suites_per_invocation': 2,
        'maximum_suites_overall': 4,
        'memory_available_before_launch_kib': 7312592,
        'fixed_output_directory_review': 'Each selected module owns its fixed output directory; CLI temporary directories use unique suffixes. Original modules occur in exactly one batch.',
    }
    base.save(out / 'plan.json', plan)
    batches = []
    for offset in range(0, len(plan['files']), 10):
        files = plan['files'][offset:offset + 10]
        batches.append({
            'id': len(batches) + 1, 'files': files,
            'expected_cases': sum(plan['expected_per_file_cases'][name] for name in files),
        })
    base.save(out / 'batches.json', batches)
    print(json.dumps({'prepared': str(out), 'source_commit': commit,
                      'batches': len(batches), 'files': len(plan['files']),
                      'expected_cases': plan['expected_total_cases']}))


def batch_directory(out: Path, batch_id: int) -> Path:
    return out / f'batch-{batch_id:02d}'


def binding_problems(before: dict, after: dict) -> list[str]:
    problems = []
    for field in ['entries', 'runtime_inputs', 'source_commit', 'source_tree']:
        if before[field] != after[field]:
            problems.append(f'Before/after mismatch: {field}')
    if not before['head_matches_worktree'] or not after['head_matches_worktree']:
        problems.append('Source does not match HEAD Git modes/blobs')
    return problems


def audit_batch(out: Path, batch_id: int) -> dict:
    plan = base.load(out / 'plan.json')
    selection = next(b for b in base.load(out / 'batches.json') if b['id'] == batch_id)
    directory = batch_directory(out, batch_id)
    before = base.load(directory / 'inputs-before.json.gz')
    after = base.load(directory / 'inputs-after.json.gz')
    execution = base.load(directory / 'execution.json')
    command = base.load(directory / 'command.json')
    result = base.parse_events((directory / 'stdout.jsonl').read_bytes(), selection['files'])
    cases = result.pop('cases')
    for case in cases:
        case['batch_id'] = batch_id
    result['problems'].extend(binding_problems(before, after))
    if execution['exit_code'] != 0:
        result['problems'].append(f'Runner exit code {execution["exit_code"]}')
    expected = {name: plan['expected_per_file_cases'][name] for name in selection['files']}
    if result['per_file_cases'] != expected:
        result['problems'].append('Completed cases differ from selected expected cases')
    if before['source_commit'] != plan['source_commit']:
        result['problems'].append('Unexpected source checkpoint')
    result.update({
        'accepted': not result['problems'], 'complete': True, 'batch_id': batch_id,
        'source_commit': before['source_commit'], 'source_tree': before['source_tree'],
        'input_entries': len(before['entries']),
        'runtime_input_entries': len(before['runtime_inputs']),
        'source_inputs_unchanged': before['entries'] == after['entries'],
        'runtime_inputs_unchanged': before['runtime_inputs'] == after['runtime_inputs'],
        'started_utc': command['started_utc'], 'finished_utc': execution['finished_utc'],
        'seconds': execution['seconds'], 'exit_code': execution['exit_code'],
        'reporter_id_namespace': ['batch_id', 'test_id'],
    })
    base.save(directory / 'cases.json.gz', cases)
    result['hashes'] = {p.name: base.file_sha(p) for p in sorted(directory.iterdir())
                        if p.is_file() and p.name != 'summary.json'}
    base.save(directory / 'summary.json', result)
    return result


def run_batch(out: Path, batch_id: int) -> int:
    plan = base.load(out / 'plan.json')
    selection = next(b for b in base.load(out / 'batches.json') if b['id'] == batch_id)
    assert base.git('rev-parse', 'HEAD') == plan['source_commit']
    directory = batch_directory(out, batch_id)
    if directory.exists():
        raise ValueError(f'Refusing to overwrite batch evidence: {directory}')
    directory.mkdir()
    before = snapshot(out)
    assert before['head_matches_worktree']
    previous = sorted(out.glob('batch-*/inputs-before.json.gz'))
    if previous:
        initial = base.load(previous[0])
        assert not binding_problems(initial, before), 'Inputs changed between batches'
    base.save(directory / 'inputs-before.json.gz', before)
    argv = [str(base.TOOLCHAIN / 'run-engine-tests.sh'), '--concurrency=2',
            '--reporter=json', *['test/' + name for name in selection['files']]]
    base.save(directory / 'command.json', {
        'argv': argv, 'cwd': str(base.ENGINE), 'started_utc': base.now(),
        'source_commit': plan['source_commit'], 'batch_id': batch_id,
        'collector_sha256': base.file_sha(Path(__file__)),
    })
    print(json.dumps({'event': 'started', 'batch': batch_id,
                      'files': len(selection['files']), 'expected_cases': selection['expected_cases'],
                      'source_inputs': len(before['entries']),
                      'runtime_inputs': len(before['runtime_inputs'])}), flush=True)
    started = time.monotonic()
    with (directory / 'stdout.jsonl').open('wb') as stdout, (directory / 'stderr.log').open('wb') as stderr:
        process = subprocess.run(argv, cwd=base.ENGINE, stdout=stdout, stderr=stderr)
    base.save(directory / 'execution.json', {
        'exit_code': process.returncode, 'seconds': round(time.monotonic() - started, 3),
        'finished_utc': base.now(),
    })
    base.save(directory / 'inputs-after.json.gz', snapshot(out))
    result = audit_batch(out, batch_id)
    print(json.dumps({k: result[k] for k in ['accepted', 'batch_id', 'passing_cases',
                                           'failed_cases', 'skipped_cases', 'seconds', 'problems']}), flush=True)
    return 0 if result['accepted'] else 1


def audit(out: Path) -> dict:
    plan = base.load(out / 'plan.json')
    batches = base.load(out / 'batches.json')
    problems, cases, results = [], [], []
    observed_files = []
    reference = None
    namespaced_starts, namespaced_dones = [], []
    for batch in batches:
        directory = batch_directory(out, batch['id'])
        result = audit_batch(out, batch['id'])
        results.append(result)
        if not result['accepted']:
            problems.append(f'Batch{batch["id"]} not accepted: {result["problems"]}')
        observed_files.extend(batch['files'])
        batch_cases = base.load(directory / 'cases.json.gz')
        cases.extend(batch_cases)
        namespaced_starts.extend((batch['id'], value) for value in result['start_ids'])
        namespaced_dones.extend((batch['id'], value) for value in result['completion_ids'])
        before = base.load(directory / 'inputs-before.json.gz')
        after = base.load(directory / 'inputs-after.json.gz')
        if reference is None:
            reference = before
        if binding_problems(reference, before) or binding_problems(reference, after):
            problems.append(f'Input drift across batch{batch["id"]}')
    if len(observed_files) != len(set(observed_files)) or set(observed_files) != set(plan['files']):
        problems.append('Each original file must occur exactly once')
    if len(namespaced_starts) != len(set(namespaced_starts)) or set(namespaced_starts) != set(namespaced_dones):
        problems.append('Global namespaced test start/end identities differ')
    if len(cases) != len(base.identities(cases)):
        problems.append('Global file/name/occurrence identities not unique')
    counts = dict(collections.Counter(case['file'] for case in cases))
    if counts != plan['expected_per_file_cases']:
        problems.append('Global completed per-file counts differ from expected')
    prior_cases = base.load(out / 'prior-cases.json.gz')
    prior_inputs = base.load(out / 'prior-inputs-before.json.gz')
    previous = base.identities(prior_cases)
    current = base.identities([c for c in cases if c['file'] in plan['previous_files']])
    missing, extra = sorted(previous - current), sorted(current - previous)
    if missing or extra:
        problems.append('Previous70 exact case identities differ')
    per_file = {}
    for name in plan['previous_files']:
        path = 'packages/quds_office_engine/test/' + name
        old = {identity for identity in previous if identity[0] == name}
        new = {identity for identity in current if identity[0] == name}
        per_file[name] = {
            'source_unchanged': prior_inputs['entries'][path]['sha256'] == reference['entries'][path]['sha256'],
            'previous_cases': len(old), 'current_cases': len(new),
            'exact_case_identities_match': old == new,
        }
    if not all(row['source_unchanged'] for row in per_file.values()):
        problems.append('A previous test module source changed')
    fresh = snapshot(out)
    if binding_problems(reference, fresh):
        problems.append('Source/runtime drift at final audit')
    base.save(out / 'inputs-final.json.gz', fresh)
    summary = {
        'schema': plan['schema'], 'accepted': not problems, 'complete': True,
        'problems': problems, 'execution': plan['execution'],
        'source_commit': reference['source_commit'], 'source_tree': reference['source_tree'],
        'file_count': len(observed_files), 'suite_count': sum(r['suite_count'] for r in results),
        'batch_count': len(results), 'passing_cases': sum(r['passing_cases'] for r in results),
        'failed_cases': sum(r['failed_cases'] for r in results),
        'skipped_cases': sum(r['skipped_cases'] for r in results),
        'reporter_errors': sum(len(r['errors']) for r in results),
        'input_entries': len(reference['entries']),
        'runtime_input_entries': len(reference['runtime_inputs']),
        'inputs_unchanged': not any(binding_problems(reference, base.load(batch_directory(out,b['id']) / side))
                                    for b in batches for side in ['inputs-before.json.gz','inputs-after.json.gz']),
        'runtime_inputs_unchanged': all(reference['runtime_inputs'] == base.load(batch_directory(out,b['id']) / side)['runtime_inputs']
                                        for b in batches for side in ['inputs-before.json.gz','inputs-after.json.gz']),
        'head_matches_worktree': reference['head_matches_worktree'] and fresh['head_matches_worktree'],
        'per_file_cases': counts, 'namespaced_start_ids': namespaced_starts,
        'namespaced_completion_ids': namespaced_dones,
        'previous_case_identities': {
            'exact_match': not missing and not extra, 'previous_cases': len(previous),
            'current_cases': len(current), 'missing': missing, 'extra': extra, 'per_file': per_file,
        },
        'started_utc': min(r['started_utc'] for r in results),
        'finished_utc': max(r['finished_utc'] for r in results),
        'invocation_seconds': sum(r['seconds'] for r in results),
        'batches': [{k: r[k] for k in ['batch_id','accepted','passing_cases','suite_count','seconds','started_utc','finished_utc']}
                    for r in results],
        'interrupted_attempt': plan['interrupted_attempt'],
        'github_actions_queried_or_awaited': False,
    }
    base.save(out / 'cases.json.gz', cases)
    base.save(out / 'case-identity-comparison.json', summary['previous_case_identities'])
    summary['hashes'] = {str(p.relative_to(out)): base.file_sha(p) for p in sorted(out.rglob('*'))
                         if p.is_file() and p != out / 'summary.json'}
    base.save(out / 'summary.json', summary)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare','run-batch','audit'])
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--source-commit')
    parser.add_argument('--batch', type=int)
    args = parser.parse_args()
    out = args.out.resolve()
    if args.action == 'prepare':
        if not args.source_commit:
            parser.error('prepare requires --source-commit')
        prepare(out, args.source_commit)
    elif args.action == 'run-batch':
        if args.batch is None:
            parser.error('run-batch requires --batch')
        return run_batch(out, args.batch)
    else:
        result = audit(out)
        print(json.dumps({k: result[k] for k in ['accepted','file_count','batch_count','passing_cases',
                                               'failed_cases','skipped_cases','problems']}))
        return 0 if result['accepted'] else 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
