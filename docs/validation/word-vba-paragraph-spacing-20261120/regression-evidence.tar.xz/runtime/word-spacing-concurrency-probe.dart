import 'package:test_core/src/runner/configuration/args.dart' as runner;
void main() {
  final value = runner.parse(['--compiler=source', '--concurrency=1', '--timeout=4x', '--fail-fast', '--concurrency=2']);
  print(value.concurrency);
}
