#!/usr/bin/env python3
"""Preserve the completed 778/78 baseline without Git or product-test commands."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def collect(root):
    return sorted(path for path in root.rglob('*') if path.is_file()
                  and not any(part in {'__pycache__', 'tmp'} for part in path.relative_to(root).parts))


def package(workspace, output, name, paths, scope):
    archive_path = output / (name + '.tar.xz')
    index_path = output / (name + '.index.json')
    if archive_path.exists() or index_path.exists():
        raise RuntimeError('Preserve previous evidence: ' + str(archive_path))
    records = []
    started = datetime.now(timezone.utc).isoformat()
    with tarfile.open(archive_path, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
        for path in sorted(set(paths)):
            if path.is_symlink() or not path.is_file():
                raise RuntimeError('Expected stable regular source file: ' + str(path))
            data = path.read_bytes()
            relative = path.relative_to(workspace).as_posix()
            info = tarfile.TarInfo(relative)
            info.size = len(data)
            info.mode = path.stat().st_mode & 0o777
            info.mtime = info.uid = info.gid = 0
            info.uname = info.gname = ''
            archive.addfile(info, io.BytesIO(data))
            records.append({'path': relative, 'bytes': len(data), 'sha256': digest(data), 'source_path': str(path)})
    expected = {row['path']: row for row in records}
    with tarfile.open(archive_path, 'r:xz') as archive:
        members = archive.getmembers()
        if len(members) != len(expected) or {member.name for member in members} != set(expected):
            raise RuntimeError('Archive member inventory mismatch')
        for member in members:
            row = expected[member.name]
            data = archive.extractfile(member).read()
            original = Path(row['source_path']).read_bytes()
            if len(data) != row['bytes'] or digest(data) != row['sha256'] or data != original:
                raise RuntimeError('Original source changed or archive bytes differ: ' + member.name)
            if not member.isfile() or any(getattr(member, key) != value for key, value in
                                         {'mtime': 0, 'uid': 0, 'gid': 0, 'uname': '', 'gname': ''}.items()):
                raise RuntimeError('Unexpected archive member type/metadata: ' + member.name)
    raw = archive_path.read_bytes()
    result = {'archive': archive_path.name, 'archive_bytes': len(raw), 'archive_sha256': digest(raw),
              'capture_started_at_utc': started, 'verified_at_utc': datetime.now(timezone.utc).isoformat(),
              'scope': scope, 'member_count': len(records), 'members_verified_against_original_bytes': True,
              'deterministic_tar_metadata': {'mtime': 0, 'uid': 0, 'gid': 0, 'uname': '', 'gname': ''},
              'members': records}
    index_path.write_text(json.dumps(result, indent=2) + '\n')
    return {key: result[key] for key in ('archive', 'archive_bytes', 'archive_sha256', 'member_count', 'members_verified_against_original_bytes')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    workspace, output = args.workspace.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    native = json.loads((workspace / 'qualification-native/verification.json').read_text())
    node = json.loads((workspace / 'qualification-node/verification.json').read_text())
    support = json.loads((workspace / 'qualification-support/receipt.json').read_text())
    audited = json.loads((workspace / 'reconciliation-audit/final/independent-summary.json').read_text())
    source = '57c24597d324426305e12eabd2bdfaea9afac6d3'
    store_source = '6be7677993715556cf1704d157dff61a428da5a7'
    if not (native['success'] and node['success'] and support['success'] and audited['passed']):
        raise RuntimeError('Only the completed passing baseline may be archived here')
    if any(record['source_commit'] != source for record in [native, node, support, audited]):
        raise RuntimeError('Baseline source identity mismatch')
    if audited['application_case_executions'] != 778 or audited['combined_separate_python_controls'] != 78 or audited['store_execution_source_commit'] != store_source:
        raise RuntimeError('Baseline counts or store identity mismatch')
    baseline_manifest = {
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Completed historical baseline preserved before newer concurrent parser and TLS work. These results do not qualify later incoming code.',
        'native_node_source_commit': source, 'store_execution_source_commit': store_source,
        'store_transfer': 'The independent audit proves all 53 store-bound inputs identical in the baseline source and excludes native transport/enough_mail from its 60-package dependency closure.',
        'application_case_executions': 778, 'suite_platform_executions': 81, 'distinct_test_files': 69,
        'separate_python_controls': 78, 'earlier_diagnostics_counted': 0, 'historical_office_cases_counted': 0,
        'counts_added_to_later_final_qualification': 0,
        'runtime_store_evidence': 'Already preserved separately in publication-runtime-store and remote checkpoint 30e9efce3747ea38bb8e5507c8c8d36931f9b049.',
        'independent_summary_sha256': digest((workspace / 'reconciliation-audit/final/independent-summary.json').read_bytes()),
        'github_actions': 'NOT QUERIED OR AWAITED',
    }
    manifest_path = output / 'baseline-manifest.json'
    manifest_path.write_text(json.dumps(baseline_manifest, indent=2) + '\n')
    accepted = [manifest_path]
    for directory in ['qualification-native', 'qualification-node', 'qualification-support', 'reconciliation-audit']:
        accepted.extend(collect(workspace / directory))
    for filename in ['native-driver.log', 'node-driver.log']:
        accepted.append(workspace / filename)
    baseline = package(workspace, output, 'native-node-support', accepted, baseline_manifest['scope'])
    diagnostics = []
    for directory in ['qualification-native-attempt-1', 'qualification-node-attempt-1', 'qualification-node-attempt-2', 'review']:
        diagnostics.extend(collect(workspace / directory))
    names = ['native-driver.log-attempt-1', 'node-driver.log-attempt-1', 'node-driver.log-attempt-2',
             'analysis-development.log', 'format-development.log', 'runner-controls-development.log', 'transport-analysis-development.log']
    for filename in names:
        path = workspace / filename
        if path.is_file():
            diagnostics.append(path)
    diagnostic_manifest = {
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Earlier development/review/qualification observations retained without acceptance credit. Source identities remain in original reports; this is not a qualification of newer incoming code.',
        'attempts': [
            {'directory': 'qualification-native-attempt-1', 'source_commit': 'edf2fe7f74a575dfb02f95ed6213b38844e16df8', 'result': 'failed protocol regression and strict analysis; superseded'},
            {'directory': 'qualification-node-attempt-1', 'source_commit': 'edf2fe7f74a575dfb02f95ed6213b38844e16df8', 'result': 'passing earlier source, superseded and excluded'},
            {'directory': 'qualification-node-attempt-2', 'source_commit': source, 'result': 'index-lock preflight failure before product test commands; excluded'},
        ],
        'application_cases_added_to_baseline_or_later_final': 0,
        'python_cases_added_to_baseline_or_later_final': 0,
    }
    diagnostic_path = output / 'diagnostics-manifest.json'
    diagnostic_path.write_text(json.dumps(diagnostic_manifest, indent=2) + '\n')
    diagnostics.append(diagnostic_path)
    diagnostic = package(workspace, output, 'diagnostics', diagnostics, diagnostic_manifest['scope'])
    report = {'created_at_utc': datetime.now(timezone.utc).isoformat(), 'baseline': baseline, 'diagnostics': diagnostic,
              'file_only_operations': True, 'git_commands_executed': False, 'tests_executed': False,
              'package_script_sha256': digest(Path(__file__).read_bytes())}
    (output / 'publication-receipt.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
