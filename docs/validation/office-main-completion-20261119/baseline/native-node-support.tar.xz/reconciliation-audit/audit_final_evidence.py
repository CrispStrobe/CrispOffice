#!/usr/bin/env python3
"""Run independent read-only audits and combine distinct files/platform executions."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--runtime', required=True, type=Path)
    parser.add_argument('--source', required=True)
    parser.add_argument('--store-source', help='Actual recorded store execution commit when different from the final native/Node source.')
    parser.add_argument('--native', required=True, type=Path)
    parser.add_argument('--node', required=True, type=Path)
    parser.add_argument('--store', required=True, type=Path)
    parser.add_argument('--support', type=Path, help='Separate 20-runner/16-replay Python control evidence.')
    parser.add_argument('--native-plan', default='docs/validation/office-main-completion-20261119/native-plan.json')
    parser.add_argument('--node-plan', default='docs/validation/office-main-completion-20261119/node-plan.json')
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    repo = args.repo.resolve()
    source = subprocess.check_output(['git', '--no-replace-objects', 'rev-parse', args.source + '^{commit}'], cwd=repo, text=True).strip()
    runs, suites, reports, issues = [], [], [], []
    for label, directory, plan_path in [('native', args.native, args.native_plan), ('node', args.node, args.node_plan)]:
        plan = json.loads(subprocess.check_output(['git', '--no-replace-objects', 'show', source + ':' + plan_path], cwd=repo))
        targets = [(str(Path(g['cwd']) / test), g.get('platform', 'vm')) for g in plan['groups'] for test in g['tests']]
        path = output / (label + '-audit.json')
        command = [sys.executable, str(here / 'audit_local_gate.py'), '--repo', str(repo), '--gate', str(directory.resolve()),
                   '--runtime', str(args.runtime.resolve()), '--source', source, '--plan', plan_path,
                   '--expected-suites', str(len(targets)), '--output', str(path)]
        with (output / (label + '-audit.log')).open('wb') as stream:
            process = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=False)
        result = json.loads(path.read_text())
        runs.append({'name': label, 'exit_code': process.returncode, 'audit_file': path.name, 'audit_sha256': sha(path),
                     'log_sha256': sha(output / (label + '-audit.log'))})
        if process.returncode != 0 or result.get('passed') is not True:
            issues.append(label + ': independent gate audit failed')
        reports.append((label, result))
        suites.extend({'path': path, 'platform': platform, 'gate': label} for path, platform in targets)
    path = output / 'store-audit.json'
    command = [sys.executable, str(here / 'audit_store_gate.py'), '--repo', str(repo), '--gate', str(args.store.resolve()),
               '--runtime', str(args.runtime.resolve()), '--source', args.store_source or source,
               '--target-source', source, '--output', str(path)]
    with (output / 'store-audit.log').open('wb') as stream:
        process = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=False)
    result = json.loads(path.read_text())
    runs.append({'name': 'store', 'exit_code': process.returncode, 'audit_file': path.name, 'audit_sha256': sha(path),
                 'log_sha256': sha(output / 'store-audit.log')})
    if process.returncode != 0 or result.get('passed') is not True:
        issues.append('store: independent gate audit failed')
    reports.append(('store', result))
    for group in result.get('groups', []):
        suites.extend({'path': path, 'platform': group['platform'], 'gate': 'store'} for path in group['suite_paths'])
    duplicate_executions = [{'path': path, 'platform': platform, 'count': count}
                            for (path, platform), count in Counter((r['path'], r['platform']) for r in suites).items() if count != 1]
    if duplicate_executions:
        issues.append('One or more identical suite/platform executions were counted repeatedly')
    receipt_hashes = set()
    for label, result in reports:
        if label == 'store':
            value = result.get('runtime_receipt_sha256')
        else:
            value = result.get('verified_runtime_recovery', {}).get('receipt_sha256')
        if value is not None:
            receipt_hashes.add(value)
        if label == 'store':
            if result.get('target_source_commit') != source or result.get('source_equivalence', {}).get('all_bound_inputs_identical_in_target') is not True:
                issues.append('store: final source equivalence not established')
        elif result.get('source_commit') != source:
            issues.append(label + ': source identity differs')
    if receipt_hashes != {sha(args.runtime / 'runtime.json')}:
        issues.append('Audited runtime recovery receipt identities differ')
    groups = []
    for label, result in reports:
        for group in result.get('groups', []):
            groups.append({'gate': label, 'name': group['name'], 'suites': group['suites'],
                           'passed': group['passed'], 'failed': group['failed'], 'skipped': group['skipped']})
    support = None
    if args.support:
        path = output / 'support-audit.json'
        command = [sys.executable, str(here / 'audit_python_gate.py'), '--repo', str(repo), '--gate', str(args.support.resolve()),
                   '--source', source, '--output', str(path)]
        with (output / 'support-audit.log').open('wb') as stream:
            process = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=False)
        support = json.loads(path.read_text())
        runs.append({'name': 'support', 'exit_code': process.returncode, 'audit_file': path.name, 'audit_sha256': sha(path),
                     'log_sha256': sha(output / 'support-audit.log')})
        if process.returncode != 0 or support.get('passed') is not True:
            issues.append('support: independent Python control audit failed')
    final = {'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': source,
             'method': 'Independent source/runtime and raw reporter audits, with exact suite/platform identities combined once. No product tests executed; no CI queried.',
             'audit_script_sha256': sha(Path(__file__)),
             'helper_sha256': {name: sha(here / name) for name in ['audit_local_gate.py', 'audit_store_gate.py', 'audit_python_gate.py']},
             'runs': runs, 'groups': groups, 'application_case_executions': sum(g['passed'] for g in groups),
             'suite_platform_executions': len(suites), 'distinct_test_files': len({r['path'] for r in suites}),
             'suite_platform_inventory': suites, 'duplicate_suite_platform_executions': duplicate_executions,
             'failed': sum(g['failed'] for g in groups), 'skipped': sum(g['skipped'] for g in groups),
             'runtime_receipt_sha256': sha(args.runtime / 'runtime.json'),
             'runtime_binding_scope': 'Native and Node gates bind complete retained-runtime before/after inventories. The store driver binds twenty runtime/config inputs including the recovery receipt and retained manifest, plus a partly overlapping seven-input launcher/native gate inventory, before and after execution.',
             'separate_store_runner_python_controls': reports[-1][1].get('separate_python_controls'),
             'store_execution_source_commit': reports[-1][1].get('source_commit'),
             'store_source_equivalence': reports[-1][1].get('source_equivalence'),
             'separate_final_helper_python_controls': support,
             'combined_separate_python_controls': reports[-1][1].get('separate_python_controls', {}).get('cases', 0) + (support.get('passed_python_controls', 0) if support else 0),
             'historical_office_cases_added': 0, 'development_cases_added': 0, 'issues': issues, 'passed': not issues}
    (output / 'independent-summary.json').write_text(json.dumps(final, indent=2) + '\n')
    print(json.dumps({k: final[k] for k in ['source_commit', 'application_case_executions', 'suite_platform_executions', 'distinct_test_files', 'failed', 'skipped', 'passed', 'issues']}, indent=2))
    raise SystemExit(bool(issues))


if __name__ == '__main__':
    main()
