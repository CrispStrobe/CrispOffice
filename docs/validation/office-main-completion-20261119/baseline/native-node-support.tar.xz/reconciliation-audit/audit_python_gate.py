#!/usr/bin/env python3
"""Independently recount final qualification/replay helper controls."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--gate', type=Path, required=True)
    parser.add_argument('--source', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    issues, groups, sources = [], [], []
    def check(ok, message):
        if not ok:
            issues.append(message)
    def git(*argv):
        return subprocess.check_output(['git', '--no-replace-objects', *argv], cwd=args.repo)
    receipt = json.loads((args.gate / 'receipt.json').read_text())
    source = git('rev-parse', args.source + '^{commit}').decode().strip()
    check(receipt['source_commit'] == source and receipt['source_tree'] == git('rev-parse', source + '^{tree}').decode().strip(), 'exact helper control source identity')
    for key in ['source_unchanged', 'head_unchanged', 'tracked_clean_after', 'success']:
        check(receipt[key] is True, 'accepted stable control flag: ' + key)
    check(receipt['source_before'] == receipt['source_after'], 'helper control source before/after equality')
    expected = {'docs/validation/document-review-notes-20261118/test_run_checks.py',
                'docs/validation/document-review-notes-20261118/run_checks.py',
                'docs/validation/document-review-notes-20261118/runtime/test_restore_runtime.py',
                'docs/validation/document-review-notes-20261118/runtime/restore_runtime.py'}
    check(set(receipt['source_before']) == expected, 'exact four helper/test source inputs')
    for path, value in receipt['source_before'].items():
        frozen = git('show', source + ':' + path)
        check(digest(frozen) == value == digest((args.repo / path).read_bytes()), 'frozen/current helper bytes: ' + path)
        sources.append({'path': path, 'sha256': value, 'git_blob': git('rev-parse', source + ':' + path).decode().strip()})
    expected_groups = {'qualification-runner': ('docs/validation/document-review-notes-20261118', 'test_run_checks.py', 20),
                       'runtime-replay': ('docs/validation/document-review-notes-20261118/runtime', 'test_restore_runtime.py', 16)}
    check([r['name'] for r in receipt['checks']] == list(expected_groups), 'exact two helper control groups')
    identities = []
    for item in receipt['checks']:
        name = item['name']
        directory, test_file, expected_count = expected_groups[name]
        check(item['command'][1:] == ['-B', '-m', 'unittest', 'discover', '-s', directory, '-p', test_file, '-v'], name + ': exact isolated test command')
        raw = (args.gate / item['log']).read_bytes()
        check(digest(raw) == item['log_sha256'], name + ': raw log hash')
        matches = re.findall(rb'Ran (\d+) tests? in [^\n]+\n\s*\nOK\s*$', raw)
        rows = re.findall(r'^(test\S+) \(([^)]+)\) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$', raw.decode(), flags=re.MULTILINE)
        cases = [{'id': cls + '.' + method, 'result': outcome} for method, cls, outcome in rows]
        check(len(matches) == 1 and int(matches[0]) == len(cases) == item['passed'] == expected_count, name + ': independent actual count')
        check(len({c['id'] for c in cases}) == len(cases) and all(c['result'] == 'ok' for c in cases), name + ': distinct successful cases without skip')
        check(item['exit_code'] == 0 and item['accepted'] is True, name + ': accepted process completion')
        identities.extend(name + '::' + c['id'] for c in cases)
        groups.append({'name': name, 'passed': len(cases), 'cases': cases, 'log_sha256': digest(raw),
                       'python_executable_sha256': digest(Path(item['command'][0]).read_bytes())})
    check(len(set(identities)) == len(identities) == receipt['passed'] == 36, '36 distinct support controls')
    report = {'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': source,
              'receipt_sha256': digest((args.gate / 'receipt.json').read_bytes()), 'source_inputs': sources,
              'groups': groups, 'passed_python_controls': sum(g['passed'] for g in groups),
              'included_in_application_total': False, 'audit_script_sha256': digest(Path(__file__).read_bytes()),
              'method': 'Independent original unittest log terminal/case recount and immutable Git blob/current source hash comparison. No product or control tests executed.',
              'issues': issues, 'passed': not issues}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['source_commit', 'passed_python_controls', 'passed', 'issues']}, indent=2))
    raise SystemExit(bool(issues))


if __name__ == '__main__':
    main()
