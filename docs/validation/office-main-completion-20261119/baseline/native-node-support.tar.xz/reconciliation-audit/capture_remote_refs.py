#!/usr/bin/env python3
"""Capture bounded branch/PR advertisements without changing Git refs or CI."""
import argparse
import collections
import datetime
import hashlib
import json
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    rows, advertisements = [], []
    for remote, patterns in [('origin', ['refs/heads/*', 'refs/pull/*/head']), ('upstream', ['refs/heads/*'])]:
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        data = subprocess.check_output(['git', 'ls-remote', remote, *patterns], cwd=args.repo)
        finished = datetime.datetime.now(datetime.timezone.utc).isoformat()
        filename = remote + '-advertisement.tsv'
        (output / filename).write_bytes(data)
        advertisements.append({'remote': remote, 'started_at_utc': started, 'finished_at_utc': finished,
                               'raw_file': filename, 'raw_sha256': hashlib.sha256(data).hexdigest()})
        for line in data.decode().splitlines():
            sha, ref = line.split('\t')
            if ref.startswith('refs/heads/'):
                normalized = 'refs/remotes/' + remote + '/' + ref.removeprefix('refs/heads/')
            elif remote == 'origin' and ref.startswith('refs/pull/') and ref.endswith('/head'):
                normalized = 'refs/remotes/pull/' + ref.split('/')[2]
            else:
                raise ValueError('Unexpected advertised ref: ' + ref)
            rows.append({'ref': normalized, 'sha': sha, 'remote': remote, 'advertised_ref': ref})
    rows.sort(key=lambda row: row['ref'])
    if len({row['ref'] for row in rows}) != len(rows):
        raise ValueError('Duplicate normalized remote ref')
    result = {'captured_at_utc': advertisements[-1]['finished_at_utc'],
              'source': 'One git ls-remote advertisement per remote: fork branches and PR heads together, upstream branches separately. No Git refs modified and no CI queried.',
              'advertisements': advertisements,
              'counts': dict(collections.Counter(row['ref'].split('/')[2] for row in rows)), 'refs': rows}
    (output / 'remote-refs.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'captured_at_utc': result['captured_at_utc'], 'counts': result['counts'], 'total_refs': len(rows)}, indent=2))


if __name__ == '__main__':
    main()
