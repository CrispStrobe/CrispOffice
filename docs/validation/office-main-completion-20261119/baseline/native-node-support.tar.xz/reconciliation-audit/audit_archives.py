#!/usr/bin/env python3
"""Verify published archive bytes, exact inventories and original member bytes."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True, type=Path)
    parser.add_argument('--index', action='append', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    results, issues = [], []
    def check(condition, message):
        if not condition:
            issues.append(message)
    for index_path in args.index:
        index = json.loads(index_path.read_text())
        archive_path = index_path.parent / index['archive']
        data = archive_path.read_bytes()
        check(len(data) == index['archive_bytes'] and digest(data) == index['archive_sha256'], index['archive'] + ': exact archive bytes/hash')
        expected = {row['path']: row for row in index['members']}
        check(len(expected) == len(index['members']) == index['member_count'], index['archive'] + ': unique indexed members')
        checked = []
        with tarfile.open(archive_path, mode='r:*') as archive:
            members = archive.getmembers()
            check(len(members) == len({m.name for m in members}) == len(expected)
                  and {m.name for m in members} == set(expected), index['archive'] + ': exact complete tar member inventory')
            for member in members:
                check(member.isfile(), member.name + ': regular file only')
                parts = PurePosixPath(member.name)
                check(not parts.is_absolute() and '..' not in parts.parts, member.name + ': safe member name')
                row = expected[member.name]
                raw = archive.extractfile(member).read()
                check(len(raw) == row['bytes'] == member.size and digest(raw) == row['sha256'], member.name + ': exact member bytes/hash')
                original = Path(row['source_path']) if row.get('source_path') else args.workspace / member.name
                original_bytes = original.read_bytes()
                check(raw == original_bytes, member.name + ': byte-identical original source file')
                for key, value in index.get('deterministic_tar_metadata', {}).items():
                    check(getattr(member, key) == value, member.name + ': deterministic metadata ' + key)
                checked.append({'path': member.name, 'bytes': len(raw), 'sha256': digest(raw), 'original': str(original), 'matches_original': raw == original_bytes})
        source_count = None
        if 'source_index_path' in index:
            source_index = Path(index['source_index_path'])
            original_index_bytes = source_index.read_bytes()
            check(digest(original_index_bytes) == index['source_index_sha256'], index['archive'] + ': original input index hash')
            original_rows = json.loads(original_index_bytes)['files']
            source_count = len(original_rows)
            check(source_count == index['indexed_source_file_count'], index['archive'] + ': original source index count')
            for row in original_rows:
                original = str(source_index.parent / row['path'])
                candidates = [item for item in checked if item['original'] == original]
                check(len(candidates) == 1 and candidates[0]['sha256'] == row['sha256']
                      and candidates[0]['bytes'] == row['bytes'], original + ': complete original index membership')
        results.append({'archive': index['archive'], 'archive_sha256': digest(data), 'archive_bytes': len(data),
                        'index_sha256': digest(index_path.read_bytes()), 'member_count': len(checked),
                        'original_index_member_count': source_count, 'members': checked})
    report = {'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'archives': results,
              'archive_count': len(results), 'member_count': sum(r['member_count'] for r in results),
              'audit_script_sha256': digest(Path(__file__).read_bytes()),
              'method': 'Independent compressed-archive SHA-256, exact tar inventories and every member compared to its original source bytes. No extraction, product tests or CI queries.',
              'issues': issues, 'passed': not issues}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['archive_count', 'member_count', 'passed', 'issues']}, indent=2))
    raise SystemExit(bool(issues))


if __name__ == '__main__':
    main()
