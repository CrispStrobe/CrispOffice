import 'dart:convert';
import 'dart:typed_data';

import '../util/ascii_runes.dart';
import '../util/stack_list.dart';
import 'imap_response_line.dart';

/// Contains an IMAP response in a generic form
class ImapResponse {
  /// The lines in the response
  List<ImapResponseLine> lines = <ImapResponseLine>[];

  /// Is this a simple response ie only containing a single response line?
  bool get isSimple => lines.length == 1;

  /// Retrieves the first line
  ImapResponseLine get first => lines.first;
  String? _parseText;

  /// Retrieves the text of the response ready for parsing
  String get parseText {
    var text = _parseText;
    if (text == null) {
      if (isSimple) {
        text = first.line ?? '';
      } else {
        final buffer = StringBuffer();
        for (final line in lines) {
          if (line.rawData != null && buffer.isNotEmpty) {
            // the space before the `{n}` literal marker was removed from the
            // preceding line, restore the token separation
            buffer.write(' ');
          }
          buffer.write(line.line);
        }
        text = buffer.toString();
      }
      _parseText = text;
    }

    return text;
  }

  set parseText(String? text) => _parseText = text;
  static final _quotedPair = RegExp(r'\\(.)', dotAll: true);
  static const List<String> _knownParenthesesDataItems = [
    'BODY',
    'BODYSTRUCTURE',
    'ENVELOPE',
    'FETCH',
    'FLAGS',
  ];

  /// Adds a line to this response
  void add(ImapResponseLine line) {
    lines.add(line);
  }

  /// Iterates through the value of this response
  ImapValueIterator iterate({bool strict = false}) {
    final root = ImapValue(null, hasChildren: true);
    var current = root;
    var nextLineIsValueOnly = false;
    final parentheses = StackList<ParenthesizedListType>();

    for (final line in lines) {
      if (nextLineIsValueOnly) {
        if (strict && line.rawData == null) {
          throw const FormatException('Missing IMAP literal bytes');
        }
        final child = ImapValue(null)..data = line.rawData;
        current.addChild(child);
      } else {
        // iterate through each value:
        var isInValue = false;
        int? separatorChar;
        final text = line.line ?? '';
        late int startIndex;
        final textCodeUnits = text.codeUnits;

        var detectedEscapeSequence = false;
        var isEscaped = false;
        for (var charIndex = 0; charIndex < textCodeUnits.length; charIndex++) {
          final char = textCodeUnits[charIndex];
          if (isInValue) {
            if (separatorChar == AsciiRunes.runeDoubleQuote) {
              // quoted-pairs such as \" and \\ within a quoted string:
              if (isEscaped) {
                isEscaped = false;
                continue;
              }
              if (char == AsciiRunes.runeBackslash) {
                isEscaped = true;
                detectedEscapeSequence = true;
                continue;
              }
            }
            if (char == AsciiRunes.runeOpeningBracket &&
                separatorChar == AsciiRunes.runeSpace) {
              // this can be for example:
              // BODY[]
              // BODY[HEADER]
              // but also:
              // BODY[HEADER.FIELDS (REFERENCES)]
              // BODY[HEADER.FIELDS.NOT (REFERENCES)]
              // --> read on until closing "]"
              separatorChar = AsciiRunes.runeClosingBracket;
            } else if (char == separatorChar) {
              // end of current word:
              if (separatorChar == AsciiRunes.runeClosingBracket) {
                // also include the closing ']' into the value:
                charIndex++;
                // and the partial range of a partial fetch: BODY[1]<0>
                if (charIndex < textCodeUnits.length &&
                    textCodeUnits[charIndex] == AsciiRunes.runeSmallerThan) {
                  final closingIndex = text.indexOf('>', charIndex);
                  if (closingIndex != -1) {
                    charIndex = closingIndex + 1;
                  }
                }
              }
              var valueText = text.substring(startIndex, charIndex);
              if (detectedEscapeSequence) {
                valueText = valueText.replaceAllMapped(
                  _quotedPair,
                  (match) => match[1]!,
                );
                detectedEscapeSequence = false;
              }
              current.addChild(ImapValue(valueText));
              isInValue = false;
            } else if (parentheses.isNotEmpty &&
                separatorChar == AsciiRunes.runeSpace &&
                char == AsciiRunes.runeClosingParentheses) {
              final valueText = text.substring(startIndex, charIndex);
              current.addChild(ImapValue(valueText));
              isInValue = false;
              parentheses.pop();
              final currentParent = current.parent;
              if (currentParent != null) {
                current = currentParent;
              }
            }
          } else if (char == AsciiRunes.runeDoubleQuote) {
            separatorChar = char;
            startIndex = charIndex + 1;
            isInValue = true;
          } else if (char == AsciiRunes.runeOpeningParentheses) {
            final lastSibling = current.hasChildren
                ? current.children?.last
                : null;
            ImapValue next;
            if (lastSibling != null &&
                _knownParenthesesDataItems.contains(
                  lastSibling.value?.toUpperCase(),
                )) {
              if (strict && lastSibling.children != null) {
                throw const FormatException('Repeated IMAP field list');
              }
              lastSibling.children ??= <ImapValue>[];
              next = lastSibling;
              parentheses.put(ParenthesizedListType.sibling);
            } else {
              next = ImapValue(null, hasChildren: true);
              current.addChild(next);
              parentheses.put(ParenthesizedListType.child);
            }
            current = next;
          } else if (char == AsciiRunes.runeClosingParentheses) {
            if (strict && parentheses.isEmpty) {
              throw const FormatException(
                'Unexpected IMAP closing parenthesis',
              );
            }
            final lastType = parentheses.pop();
            final currentParent = current.parent;
            if (currentParent != null) {
              current = currentParent;
            } else {
              print(
                'Warning: no parent for closing parentheses, '
                'last parentheses type $lastType',
              );
            }
          } else if (char != AsciiRunes.runeSpace) {
            isInValue = true;
            separatorChar = AsciiRunes.runeSpace;
            startIndex = charIndex;
          }
        } // for each char
        if (isInValue) {
          if (strict &&
              (separatorChar == AsciiRunes.runeDoubleQuote ||
                  separatorChar == AsciiRunes.runeClosingBracket)) {
            throw const FormatException('Unterminated IMAP value');
          }
          isInValue = false;
          final valueText = text.substring(startIndex);
          current.addChild(ImapValue(valueText));
        }
      }
      nextLineIsValueOnly = line.isWithLiteral;
    }
    if (parentheses.isNotEmpty) {
      if (strict) {
        throw const FormatException('Unclosed IMAP parentheses');
      }
      // Diagnostics never print literal bytes or protocol field contents.
      print('Warning - IMAP parentheses have not been closed');
    }

    return ImapValueIterator(root.children ?? []);
  }

  @override
  String toString() {
    final buffer = StringBuffer();
    for (final line in lines) {
      buffer
        ..write(line.rawLine ?? '<${line.rawData?.length} bytes data>')
        ..write('\n');
    }

    return buffer.toString();
  }
}

/// Iterator through parenthesized values in an IMAP response
class ImapValueIterator {
  /// Creates a new iterator
  ImapValueIterator(this.values);

  /// All values
  final List<ImapValue> values;
  int _currentIndex = 0;

  /// The current value
  ImapValue get current => values[_currentIndex];

  /// Moves to the next value
  ///
  /// Returns `true` if there is a next value
  bool next() {
    if (_currentIndex < values.length - 1) {
      _currentIndex++;

      return true;
    }

    return false;
  }
}

/// The type of a value list element
enum ParenthesizedListType {
  /// A child of another element
  child,

  /// A sibling of another element
  sibling,
}

/// Contains a single IMAP value in a parenthesized list
class ImapValue {
  /// Creates a new value
  ImapValue(this.value, {bool hasChildren = false}) {
    if (hasChildren) {
      children = <ImapValue>[];
    }
  }

  /// The parent of this value
  ImapValue? parent;

  /// The text data
  String? value;

  /// The binary data
  Uint8List? data;

  /// The children, if any
  List<ImapValue>? children;

  /// Does this value have children?
  bool get hasChildren => children?.isNotEmpty ?? false;

  /// Retrieves the value as text
  String? get valueOrDataText {
    final data = this.data;

    return value ??
        (data == null ? null : utf8.decode(data, allowMalformed: true));
  }

  /// Adds a child to this value
  void addChild(ImapValue child) {
    children ??= <ImapValue>[];
    child.parent = this;
    children?.add(child);
  }

  @override
  String toString() {
    final data = this.data;

    return (value ?? (data != null ? '<${data.length} bytes>' : '<null>')) +
        (children != null ? children.toString() : '');
  }
}
