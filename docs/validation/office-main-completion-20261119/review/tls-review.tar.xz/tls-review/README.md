# Independent native TLS and raw FETCH review

This archive binds the reviewed implementation to published source commit
`5569c055a021c893e941fc54d40499ad9d96a5db`, tree
`9d2c815eda61378fbc4b234124e8e7c9cfeacb5b`. It records the selected review,
original failures, development verification, and replay inputs used while
reconciling the bounded remote snapshot at **07:15:06 UTC on 19 November 2026**.

**Every test count in this archive is excluded from final qualification totals.**
The parent's frozen-source store, native, and Node gates are published separately.
This review archive makes no claim about their completion or outcome.

## Resolved findings

| Finding | Observed failure | Selected resolution |
| --- | --- | --- |
| Stalled TLS ownership | Four real implicit TLS/STARTTLS cancellation and timeout cases returned provider errors while the peer TCP connection stayed open. | Keep a public raw TCP owner through the TLS handshake and close it on cancellation. |
| Established TLS hard abort | The pinned SDK may defer secure-wrapper closure while encrypted output remains queued. | Keep the original TCP owner after successful TLS too; close it before the secure wrapper. A deterministic distinct-owner regression checks the close ordering. |
| Direct API completion | Two direct connection/upgrade operations remained pending after `abort()` had closed TCP. | Race public connection/upgrade waits against a per-connection abort signal, while retaining late-result disposal on the original futures. |
| Malformed FETCH delimiters | Fifteen finite parser/provider assertions failed against the exact incoming canonical-UID parser; malformed FETCH records could become successful tombstone pages. | Recognize FETCH at the untagged response position with IMAP atom delimiters, then enforce strict prefix, root/list, UID and literal validation. |

The selected implementation preserves existing Socket-returning seams and manual
Socket upgrade compatibility. It incorporates incoming secure-connection metadata,
original TCP ownership and explicit abort completion. Unique incoming authentication,
hostname, retry, partial-write and cancellation assertions are retained.

The FETCH matrix covers a missing list separator, tabs replacing required spaces,
attached quoted/closing-list syntax, an attached literal marker, and negative
controls for `FETCHX`, unrelated FLAGS data and known status text. The canonical
UID grammar and its six incoming body/notification regressions are retained.
The grammar reference is [RFC 3501, section 9](https://www.rfc-editor.org/rfc/rfc3501.html#section-9).

## Source and evidence map

- `review/final-source-review.json` binds 28 exact Git blobs, matches 17 captured
  development-manifest hashes, records the finite review decisions, and identifies
  the replay test paths and pinned SDK hashes.
- `review/TLS/committed-source-verification.json` preserves the earlier exact
  eight-file verification at `54c36e40`; it is a historical checkpoint.
- `review/TLS/tls-lifecycle-review.json`, `tls-test-review.json` and
  `incoming-tls-review.json` preserve reviews as written at their respective stages.
  Their references to pending publication or qualification are historical.
- `review/TLS/baseline-stalled-handshake.jsonl` contains the four original failures.
- `review/TLS/development-direct-abort-baseline.jsonl` contains the two direct
  operation failures before the abort signal was added.
- `review/FETCH-delimiter/baseline.jsonl` contains 15 expected failures and three
  passing controls against the exact `99dd7307` parser.
- `review/TLS/final-development-tls-nine.jsonl` preserves the original nine-case
  passing TLS development run.
- `review/TLS/final-union-focused-development.jsonl` records 119 passing cases
  across ten files: the complete parser/provider suites, original TLS tests, and
  inherited real protocol loopbacks.
- `review/TLS/development-incoming-tls-adapted-final.jsonl` records 17 additional
  passing cases in the adapted incoming TLS suite.
- `source/fixed/` contains the exact reviewed source snapshots. `source/baseline/`
  contains only the three replacement source files needed for isolated reproductions.
- `replay/` contains the replay and deterministic packing scripts, the original
  four-case baseline test, and small original external test configuration records.

The final 119 and 17 development runs cover 136 distinct cases across eleven files.
Earlier repeated eight/nine-case runs are not added to that figure. The initial
external test launch that failed before loading tests because its temporary-directory
environment was missing is retained as `development-tls-tests.jsonl`; it is setup
evidence, not a product test outcome.

## Replaying selected regressions

Use a clean checkout of the exact published source commit above, the already
prepared locked package configuration, and the pinned Flutter 3.47.8 / Dart 3.13.7
runtime with `package:test` 1.31.1 available. Source the prepared runtime environment
so its writable temporary-directory and cache settings are active.

The replay script checks source and SDK hashes, creates isolated library overlays
outside the checkout, runs the resolved kernel test launcher directly, and checks
expected outcomes. It never invokes dependency resolution or changes Git/source.
The original package-config records retain their historical absolute paths for
provenance; the script normalizes the supplied checkout's package configuration
and generates fresh overlay configurations for the actual replay location.

```bash
python3 tls-review/replay/replay.py \
  --repo /path/to/quds_office_suite \
  --dart /path/to/dart-sdk/bin/dart \
  --sdk-root /path/to/dart-sdk \
  --test-runner /path/to/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart \
  --output /path/to/new-tls-replay
```

Optional `--mode` values are `baseline-handshake`, `baseline-direct-abort`,
`baseline-fetch`, and `fixed`; the default is `all`. Baseline runs intentionally
fail their product assertions, and the replay script succeeds only when their
expected failure counts and terminal status match. The fixed selection expects
136 passing cases. These selected replays remain development evidence and do not
replace the full qualification plans.

The supplied replay script was syntax-reviewed during the final source freeze;
it was not executed during that freeze. Recorded raw outputs are original bytes,
not synthesized replay output. Replays reproduce the selected behaviors, not
identical wall times, process IDs, or JSONL hashes.

## Archive verification

The adjacent `tls-review.index.json` lists every archive member's byte length,
mode and SHA-256, plus the whole archive hash. Packaging sorts members, normalizes
owner/group and timestamps, reopens the compressed archive to verify every member,
and builds a second archive independently to require byte-identical output.
To recreate the package from the extracted directory:

```bash
python3 tls-review/replay/build_archive.py \
  --input tls-review \
  --output /path/to/rebuilt-tls-review.tar.xz
```

Full copied libraries, runtime binaries, package caches and Git databases are
excluded. No GitHub Actions or status results were queried or included.

## Scope limits

Physical hard-close guarantees apply to the default owned native transport.
Arbitrary externally supplied SDK Socket upgrades retain their previous TLS
handoff ownership limitation, although the explicit abort signal now settles the
direct caller. The tests use Linux and the pinned SDK; they do not establish other
OS, installed application or external mail-service acceptance.

Both certificate sets and their private keys are intentionally public loopback
fixtures. Trusted tests use isolated contexts, refusal tests use default trust,
and no production certificate acceptance callback or global trust installation is
introduced. The deterministic distinct-owner test proves close invocation/order,
not delivery of a network close to a remote host under arbitrary congestion.
