#!/usr/bin/env python3
"""Replay selected development regressions without changing the checkout."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
from urllib.parse import urljoin


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo)


def package_config(original, destination, enough_mail=None):
    data = json.loads(original.read_text())
    for package in data['packages']:
        package['rootUri'] = urljoin(original.as_uri(), package['rootUri'])
        if package['name'] == 'enough_mail' and enough_mail is not None:
            package['rootUri'] = enough_mail.as_uri()
    destination.write_text(json.dumps(data, indent=2) + '\n')


def overlay(repo, commit, destination, replacements):
    prefix = 'third_party/enough_mail/'
    archive = git(repo, 'archive', commit, prefix + 'lib')
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:') as source:
        for member in source:
            if member.isdir():
                continue
            if not member.isfile() or not member.name.startswith(prefix):
                raise RuntimeError('Unexpected archived library member')
            relative = Path(member.name[len(prefix):])
            if relative.is_absolute() or '..' in relative.parts:
                raise RuntimeError('Unsafe archived library member')
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.extractfile(member).read())
    for relative, source in replacements.items():
        shutil.copyfile(source, destination / relative)


def run_cases(args, output, name, config, tests, expected, selection=None):
    command = [str(args.dart), '--packages=' + str(config), str(args.test_runner),
               '--compiler=kernel', '--reporter=json']
    if selection is not None:
        command += ['--name', selection]
    command += [str(path) for path in tests]
    stdout = output / (name + '.jsonl')
    stderr = output / (name + '.stderr')
    with stdout.open('wb') as out, stderr.open('wb') as err:
        process = subprocess.run(command, cwd=args.repo, stdout=out, stderr=err,
                                 timeout=180, check=False)
    events = [json.loads(line) for line in stdout.read_text().splitlines() if line]
    ends = [event for event in events if event['type'] == 'testDone']
    if len({event['testID'] for event in ends}) != len(ends):
        raise RuntimeError(name + ': duplicate test completion')
    started = {event['test']['id'] for event in events if event['type'] == 'testStart'}
    if started != {event['testID'] for event in ends}:
        raise RuntimeError(name + ': unfinished or unmatched test')
    visible = [event for event in ends if not event.get('hidden')]
    actual = {key: sum(event.get('result') == key for event in visible)
              for key in ('success', 'failure', 'error')}
    actual['skipped'] = sum(bool(event.get('skipped')) for event in visible)
    actual['reporter_errors'] = sum(event['type'] == 'error' for event in events)
    terminal = [event for event in events if event['type'] == 'done']
    expected_success = expected['failure'] == 0 and expected['error'] == 0
    if actual != expected or len(terminal) != 1 or terminal[0]['success'] != expected_success:
        raise RuntimeError(name + ': unexpected outcomes ' + json.dumps(actual))
    if process.returncode != (0 if expected_success else 1) or stderr.stat().st_size:
        raise RuntimeError(name + ': unexpected process status/stderr')
    return {'name': name, 'command': command, 'results': actual,
            'exit_code': process.returncode,
            'jsonl_sha256': sha(stdout.read_bytes()),
            'stderr_sha256': sha(stderr.read_bytes())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--dart', required=True, type=Path)
    parser.add_argument('--sdk-root', required=True, type=Path)
    parser.add_argument('--test-runner', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--package-config', type=Path)
    parser.add_argument('--mode', choices=['all', 'baseline-handshake',
                        'baseline-direct-abort', 'baseline-fetch', 'fixed'], default='all')
    args = parser.parse_args()
    args.repo = args.repo.resolve()
    args.dart = args.dart.resolve()
    args.sdk_root = args.sdk_root.resolve()
    args.test_runner = args.test_runner.resolve()
    output = args.output.resolve()
    archive_root = Path(__file__).resolve().parents[1]
    report = json.loads((archive_root / 'review/final-source-review.json').read_text())
    commit = report['source_commit']
    for name, expected in report['sdk_sha256'].items():
        if sha((args.sdk_root / name).read_bytes()) != expected:
            raise RuntimeError('Pinned SDK source mismatch: ' + name)
    for name, expected in report['baseline_source_sha256'].items():
        if sha((archive_root / name).read_bytes()) != expected:
            raise RuntimeError('Baseline source mismatch: ' + name)
    if git(args.repo, 'rev-parse', 'HEAD').decode().strip() != commit:
        raise RuntimeError('Use an exact checkout of ' + commit)
    if git(args.repo, 'status', '--porcelain', '--untracked-files=no').strip():
        raise RuntimeError('Tracked checkout changes are not allowed')
    if output == args.repo or args.repo in output.parents or output.exists():
        raise RuntimeError('Output must be a new directory outside the checkout')
    for name, expected in report['source_sha256'].items():
        if sha(git(args.repo, 'show', commit + ':' + name)) != expected:
            raise RuntimeError('Source blob mismatch: ' + name)
    original = (args.package_config or args.repo / '.dart_tool/package_config.json').resolve()
    if not original.is_file() or not args.dart.is_file() or not args.test_runner.is_file():
        raise RuntimeError('Prepare pinned runtime/dependencies first; this script never runs pub')
    output.mkdir(parents=True)
    current_config = output / 'fixed-package-config.json'
    package_config(original, current_config)
    result = []
    choices = ['baseline-handshake', 'baseline-direct-abort', 'baseline-fetch', 'fixed']
    for mode in choices if args.mode == 'all' else [args.mode]:
        selection = None
        config = current_config
        if mode != 'fixed':
            directory = output / mode / 'enough_mail'
            directory.mkdir(parents=True)
            if mode == 'baseline-handshake':
                replacements = {'lib/src/private/util/client_base.dart':
                                archive_root / 'source/baseline/client_base-c634f494.dart'}
                tests = [archive_root / 'replay/native_tls_cancellation_baseline_test.dart']
                expected = dict(success=0, failure=0, error=4, skipped=0, reporter_errors=4)
            elif mode == 'baseline-direct-abort':
                replacements = {'lib/src/private/util/client_base.dart':
                                archive_root / 'source/baseline/client_base-before-abort-signal.dart'}
                tests = [args.repo / 'packages/quds_mail_transport/test/native_tls_test.dart']
                selection = 'direct pending TLS operation'
                expected = dict(success=0, failure=2, error=0, skipped=0, reporter_errors=2)
            else:
                replacements = {'lib/src/private/imap/raw_fetch_parser.dart':
                                archive_root / 'source/baseline/raw_fetch_parser-99dd7307.dart'}
                tests = [args.repo / 'third_party/enough_mail/test/src/imap/raw_fetch_parser_test.dart',
                         args.repo / 'packages/quds_mail_transport/test/native_provider_test.dart']
                selection = 'FETCH with|FETCH-like atoms'
                expected = dict(success=3, failure=15, error=0, skipped=0, reporter_errors=15)
            overlay(args.repo, commit, directory, replacements)
            config = output / mode / 'package_config.json'
            package_config(original, config, directory)
        else:
            tests = [args.repo / name for name in report['fixed_replay_test_paths']]
            expected = dict(success=136, failure=0, error=0, skipped=0, reporter_errors=0)
        result.append(run_cases(args, output, mode, config, tests, expected, selection))
    (output / 'replay-results.json').write_text(json.dumps({
        'source_commit': commit,
        'scope': 'Selected development replay only; counts excluded from official qualification',
        'results': result}, indent=2) + '\n')
    print(json.dumps({'source_commit': commit, 'replayed': len(result),
                      'output': str(output)}))


if __name__ == '__main__':
    main()
