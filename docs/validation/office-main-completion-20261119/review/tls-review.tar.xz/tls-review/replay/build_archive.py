#!/usr/bin/env python3
"""Build a deterministic evidence tar.xz plus independently verified member index."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pack(root, destination):
    files = sorted(path for path in root.rglob('*') if path.is_file())
    members = []
    with tarfile.open(fileobj=destination, mode='w:xz', format=tarfile.USTAR_FORMAT,
                      preset=6) as archive:
        for path in files:
            if path.is_symlink():
                raise RuntimeError('Symlink evidence member is not allowed')
            relative = path.relative_to(root).as_posix()
            data = path.read_bytes()
            name = 'tls-review/' + relative
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o755 if relative.endswith('.py') else 0o644
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            archive.addfile(info, io.BytesIO(data))
            members.append({'path': name, 'bytes': len(data), 'sha256': digest(data),
                            'mode': oct(info.mode)})
    return members


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    root = args.input.resolve()
    output = args.output.resolve()
    if root == output or root in output.parents:
        raise RuntimeError('Archive must be outside its input tree')
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('wb') as stream:
        members = pack(root, stream)
    expected = {member['path']: member for member in members}
    observed = []
    with tarfile.open(output, 'r:xz') as archive:
        for entry in archive:
            if not entry.isfile() or entry.name not in expected:
                raise RuntimeError('Unexpected archived member')
            row = expected[entry.name]
            content = archive.extractfile(entry).read()
            if (entry.size != row['bytes'] or digest(content) != row['sha256'] or
                    entry.uid != 0 or entry.gid != 0 or entry.mtime != 0 or
                    entry.uname or entry.gname or oct(entry.mode) != row['mode']):
                raise RuntimeError('Reopened member verification failed: ' + entry.name)
            observed.append(entry.name)
    if observed != list(expected):
        raise RuntimeError('Member ordering/coverage mismatch')
    second = io.BytesIO()
    pack(root, second)
    data = output.read_bytes()
    if data != second.getvalue():
        raise RuntimeError('Independent deterministic rebuild differs')
    source = json.loads((root / 'review/final-source-review.json').read_text())
    index = {
        'schema': 'quds-tls-review-evidence-v1',
        'archive': output.name,
        'archive_sha256': digest(data),
        'archive_bytes': len(data),
        'source_commit': source['source_commit'],
        'source_tree': source['source_tree'],
        'scope': 'Independent review and development evidence; excluded from final qualification counts',
        'reopened_all_members_verified': True,
        'independent_rebuild_byte_identical': True,
        'member_count': len(members),
        'members': members,
    }
    index_path = output.with_name(output.name.removesuffix('.tar.xz') + '.index.json')
    index_path.write_text(json.dumps(index, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in index.items() if key != 'members'}))


if __name__ == '__main__':
    main()
