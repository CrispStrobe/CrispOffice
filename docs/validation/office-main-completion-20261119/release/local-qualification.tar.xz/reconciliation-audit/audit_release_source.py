#!/usr/bin/env python3
"""Read immutable release Git objects and audit plan coverage/source continuity."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--source', required=True)
    parser.add_argument('--baseline', default='39843ed4874c7b56572c7aa8195716e5892aeca2')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()

    def git(*words):
        return subprocess.check_output(['git', '--no-replace-objects', *words], cwd=args.repo)

    def text(*words):
        return git(*words).decode()

    def sha(data):
        return hashlib.sha256(data).hexdigest()

    source = text('rev-parse', args.source + '^{commit}').strip()
    tree = {}
    for line in text('ls-tree', '-r', source).splitlines():
        metadata, path = line.split('\t', 1)
        mode, kind, blob = metadata.split(' ')
        tree[path] = {'mode': mode, 'type': kind, 'blob': blob}
    issues = []

    def check(condition, message):
        if not condition:
            issues.append(message)

    plan_root = 'docs/validation/office-main-completion-20261119/'
    plans = {}
    executions = []
    for name in ['native', 'node']:
        path = plan_root + name + '-plan.json'
        raw = git('show', source + ':' + path)
        plan = json.loads(raw)
        suites = []
        for group in plan['groups']:
            platform = group.get('platform', 'vm')
            for relative in group['tests']:
                suite = (Path(group['cwd']) / relative).as_posix()
                check(suite in tree, 'Missing suite in release tree: ' + suite)
                row = {'path': suite, 'platform': platform, 'group': group['name'], 'plan': name}
                suites.append(row)
                executions.append(row)
        plans[name] = {
            'path': path, 'git_entry': tree[path], 'sha256': sha(raw),
            'suite_count': len(suites), 'groups': plan['groups'],
            'analysis': plan['analysis'], 'format': plan['format'],
            'extra_inputs': plan['extra_inputs'], 'suites': suites,
        }
        for role in ['analysis', 'format', 'extra_inputs']:
            check(len(set(plan[role])) == len(plan[role]), name + ': duplicate ' + role + ' input')
            for selected in plan[role]:
                check(selected in tree, name + ': missing ' + role + ' input ' + selected)
    identities = [(row['path'], row['platform']) for row in executions]
    check(len(set(identities)) == len(identities), 'Duplicate suite/platform across native/Node plans')
    check(plans['native']['suite_count'] == 60, 'Expected sixty native suites')
    check(plans['node']['suite_count'] == 7, 'Expected seven Node suites')

    changed_dart = text('diff', '--name-only', args.baseline, source, '--', '*.dart').splitlines()
    analysis = plans['native']['analysis']
    formatted = plans['native']['format']
    check(len(changed_dart) == 35, 'Expected thirty-five changed Dart files')
    check(set(changed_dart) == set(analysis), 'Native analysis must cover exactly all changed Dart paths')
    check(set(changed_dart) == set(formatted), 'Native format must cover exactly all changed Dart paths')
    check(not plans['node']['analysis'] and not plans['node']['format'], 'Node should not duplicate native static checks')
    store_source_path = 'tools/mail/check_store.py'
    store_source = git('show', source + ':' + store_source_path)
    core_tests = sorted(path for path in tree if path.startswith('packages/quds_mail_core/test/') and path.endswith('_test.dart'))
    store_tests = sorted(path for path in tree if path.startswith('packages/quds_mail_store/test/') and path.endswith('_test.dart'))
    changed_tests = [path for path in changed_dart if path.endswith('_test.dart')]
    tested_paths = {row['path'] for row in executions} | set(core_tests) | set(store_tests)
    check(set(changed_tests).issubset(tested_paths), 'Changed Dart regression suite omitted from native/Node or store qualification')
    check(len(core_tests) == 4 and len(store_tests) == 8, 'Unexpected core/store suite inventory')

    office_scope = ['packages/quds_office_engine', 'packages/quds_office_editor', 'apps/quds_report_studio']
    office_current = git('ls-tree', '-r', source, '--', *office_scope)
    office_prior = git('ls-tree', '-r', args.baseline, '--', *office_scope)
    office_paths = [path for path in tree if any(path.startswith(prefix + '/') for prefix in office_scope)]
    check(office_current == office_prior, 'Office/Editor/Studio source continuity failed')
    check(len(office_paths) == 2622, 'Unexpected Office/Editor/Studio entry count')
    continuity = {
        'scope': office_scope, 'comparison_commit': args.baseline,
        'entries': len(office_paths), 'identical_tree_entries': office_current == office_prior,
        'source_tree_listing_sha256': sha(office_current), 'comparison_tree_listing_sha256': sha(office_prior),
        'changed_paths': text('diff', '--name-only', args.baseline, source, '--', *office_scope).splitlines(),
        'paths': [{'path': path, **tree[path]} for path in office_paths],
        'historical_office_test_cases_added_to_fresh_totals': 0,
    }
    report = {
        'audited_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_commit': source, 'source_tree': text('rev-parse', source + '^{tree}').strip(),
        'baseline_commit': args.baseline, 'audit_script_sha256': sha(Path(__file__).read_bytes()),
        'method': 'Immutable Git-object comparison only. No index, worktree, ref writes, product tests, or CI queries.',
        'plans': plans, 'changed_dart_paths': changed_dart,
        'static_coverage_exact': set(changed_dart) == set(analysis) == set(formatted),
        'changed_test_paths': changed_tests,
        'separate_store_plan': {'source_path': store_source_path, 'source_git_entry': tree[store_source_path],
                                'source_sha256': sha(store_source), 'core_tests': core_tests, 'store_tests': store_tests,
                                'interpretation': 'The unchanged checker selection logic runs core on VM+Node, seven store suites on VM and three portable store suites on Node; actual commands and raw suite inventories are audited independently after execution.'},
        'office_continuity': continuity,
        'issues': issues, 'passed': not issues,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'source_commit': source, 'changed_dart_files': len(changed_dart),
                      'native_suites': plans['native']['suite_count'], 'node_suites': plans['node']['suite_count'],
                      'office_entries': len(office_paths), 'passed': not issues, 'issues': issues}, indent=2))
    raise SystemExit(0 if not issues else 1)


if __name__ == '__main__':
    main()
