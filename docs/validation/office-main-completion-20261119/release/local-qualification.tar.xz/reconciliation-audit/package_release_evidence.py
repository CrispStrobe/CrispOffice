#!/usr/bin/env python3
"""Seal complete release evidence and small summaries without Git/test commands."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path

from package_baseline_evidence import collect, digest, package


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--source', required=True)
    parser.add_argument('--audit-dir', type=Path, required=True)
    parser.add_argument('--cutoff-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    audit_dir = args.audit_dir.resolve()
    cutoff_dir = args.cutoff_dir.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)

    def read(path):
        return json.loads(path.read_text())

    def write(name, value):
        path = output / name
        path.write_text(json.dumps(value, indent=2) + '\n')
        return path

    full_summary_path = audit_dir / 'independent-summary.json'
    full_summary = read(full_summary_path)
    source_audit_path = audit_dir / 'source-plan-continuity-audit.json'
    source_audit = read(source_audit_path)
    ref_audit_path = cutoff_dir / ('release-source-audit-' + args.source[:8] + '.json')
    ref_audit = read(ref_audit_path)
    gate_reports = {name: read(audit_dir / (name + '-audit.json'))
                    for name in ['native', 'node', 'store', 'support']}
    if not all(row['passed'] for row in [full_summary, source_audit, ref_audit, *gate_reports.values()]):
        raise RuntimeError('All independent release audits must pass before sealing')
    if any(row['source_commit'] != args.source for row in [full_summary, source_audit, *gate_reports.values()]):
        raise RuntimeError('Every final execution/audit must use the exact release source')
    if ref_audit['checked_head'] != args.source or full_summary['store_execution_source_commit'] != args.source:
        raise RuntimeError('Reconciliation and store execution source must match release')
    if not ref_audit['all_captured_refs_accounted_for'] or not ref_audit['all_historical_equivalences_verified']:
        raise RuntimeError('Bounded reconciliation is incomplete')
    source_tree = source_audit['source_tree']
    if source_tree != ref_audit['checked_tree']:
        raise RuntimeError('Source-tree identity mismatch')

    summaries = []
    small = {key: full_summary[key] for key in [
        'audited_at_utc', 'source_commit', 'application_case_executions',
        'suite_platform_executions', 'distinct_test_files', 'groups',
        'failed', 'skipped', 'combined_separate_python_controls',
        'store_execution_source_commit', 'historical_office_cases_added',
        'development_cases_added', 'runtime_receipt_sha256', 'issues', 'passed',
    ]}
    small.update({
        'source_tree': source_tree,
        'all_execution_sources_identical': True,
        'historical_completed_gate_cases_added': 0,
        'complete_audit_member': full_summary_path.relative_to(workspace).as_posix(),
        'complete_audit_sha256': digest(full_summary_path.read_bytes()),
        'native_source_inputs_reverified': gate_reports['native']['source_inputs_reverified'],
        'node_source_inputs_reverified': gate_reports['node']['source_inputs_reverified'],
        'native_runtime_inputs_reverified': gate_reports['native']['runtime_inputs_reverified'],
        'node_runtime_inputs_reverified': gate_reports['node']['runtime_inputs_reverified'],
        'store_source_inputs_reverified': gate_reports['store']['source_inputs_reverified'],
        'store_driver_runtime_config_inputs_reverified': gate_reports['store']['driver_runtime_config_inputs_reverified'],
        'store_launcher_inputs_reverified': gate_reports['store']['launcher_inputs_reverified'],
        'source_and_runtime_unchanged': all(gate_reports[label]['source_manifests_equal']
                                           and gate_reports[label]['environment_manifests_equal'] for label in ['native', 'node']),
        'github_actions': 'NOT QUERIED OR AWAITED',
    })
    summaries.append(write('independent-summary.json', small))
    reconciliation = {
        'source_commit': args.source, 'source_tree': source_tree,
        'cutoff_utc': ref_audit['snapshot_captured_at_utc'],
        'captured_refs': ref_audit['total_refs'], 'unique_heads': ref_audit['unique_heads'],
        'snapshot_counts': ref_audit['snapshot_counts'],
        'ancestor_refs': ref_audit['classification'].get('ancestor', 0),
        'historical_equivalent_refs': ref_audit['classification'].get('historical_equivalent', 0),
        'unaccounted_refs': ref_audit['classification'].get('unaccounted', 0),
        'historical_equivalence_proofs_recomputed': len(ref_audit['historical_equivalence_checks']),
        'all_historical_equivalences_verified': ref_audit['all_historical_equivalences_verified'],
        'historical_refs_remain_non_ancestors': ref_audit['historical_refs_remain_non_ancestors'],
        'local_exact_tree_equivalence': ref_audit['local_integration_equivalence'],
        'complete_audit_member': ref_audit_path.relative_to(workspace).as_posix(),
        'complete_audit_sha256': digest(ref_audit_path.read_bytes()),
        'snapshot_sha256': ref_audit['snapshot_sha256'],
        'passed': ref_audit['passed'],
    }
    summaries.append(write('reconciliation-summary.json', reconciliation))
    office = source_audit['office_continuity']
    coverage = {
        'source_commit': args.source, 'source_tree': source_tree,
        'baseline_commit': source_audit['baseline_commit'],
        'changed_dart_files': len(source_audit['changed_dart_paths']),
        'changed_dart_paths': source_audit['changed_dart_paths'],
        'analysis_targets': len(source_audit['plans']['native']['analysis']),
        'format_targets': len(source_audit['plans']['native']['format']),
        'static_coverage_exact': source_audit['static_coverage_exact'],
        'native_suites': source_audit['plans']['native']['suite_count'],
        'node_suites': source_audit['plans']['node']['suite_count'],
        'plan_hashes': {label: {'path': value['path'], 'sha256': value['sha256']} for label, value in source_audit['plans'].items()},
        'office_continuity': {key: office[key] for key in ['scope', 'comparison_commit', 'entries',
                                                          'identical_tree_entries', 'source_tree_listing_sha256',
                                                          'comparison_tree_listing_sha256', 'changed_paths',
                                                          'historical_office_test_cases_added_to_fresh_totals']},
        'complete_audit_member': source_audit_path.relative_to(workspace).as_posix(),
        'complete_audit_sha256': digest(source_audit_path.read_bytes()),
        'passed': source_audit['passed'],
    }
    summaries.append(write('coverage-summary.json', coverage))

    evidence_root = workspace / 'quds_office_suite/docs/validation/office-main-completion-20261119/evidence'
    runtime_references = []
    for filename in ['runtime-evidence.index.json', 'runtime-replay-fix.index.json']:
        path = evidence_root / filename
        index = read(path)
        archive = evidence_root / index['archive']
        if digest(archive.read_bytes()) != index['archive_sha256'] or archive.stat().st_size != index['archive_bytes']:
            raise RuntimeError('Published runtime archive hash mismatch: ' + str(archive))
        runtime_references.append({
            'index_repository_path': path.relative_to(workspace / 'quds_office_suite').as_posix(),
            'index_sha256': digest(path.read_bytes()),
            'archive_repository_path': archive.relative_to(workspace / 'quds_office_suite').as_posix(),
            'archive_sha256': index['archive_sha256'], 'archive_bytes': index['archive_bytes'],
        })
    manifest = {
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Complete fresh release Store/native/Node/support execution and independent source/runtime/ref audits at one published source. Earlier completed gates and development attempts are excluded.',
        'source_commit': args.source, 'source_tree': source_tree,
        'application_case_executions': small['application_case_executions'],
        'suite_platform_executions': small['suite_platform_executions'],
        'distinct_test_files': small['distinct_test_files'],
        'separate_python_controls': small['combined_separate_python_controls'],
        'historical_or_development_cases_added': 0,
        'summary_sha256': {path.name: digest(path.read_bytes()) for path in summaries},
        'runtime_evidence_references': runtime_references,
        'runtime_binaries_included': False,
        'github_actions': 'NOT QUERIED OR AWAITED',
    }
    manifest_path = write('manifest.json', manifest)
    selected = [manifest_path, *summaries]
    for relative in ['qualification-release-native', 'qualification-release-node',
                     'qualification-release-store', 'qualification-release-support']:
        selected.extend(collect(workspace / relative))
    for relative in ['release-native-driver.log', 'release-node-driver.log',
                     'release-store-driver.log', 'run-release-support.py']:
        path = workspace / relative
        if not path.is_file():
            raise RuntimeError('Missing final driver evidence: ' + str(path))
        selected.append(path)
    selected.extend(collect(audit_dir))
    selected.extend(collect(cutoff_dir))
    helpers = ['audit_final_evidence.py', 'audit_local_gate.py', 'audit_store_gate.py',
               'audit_python_gate.py', 'audit_release_source.py', 'audit_published_refs.py',
               'audit_archives.py', 'capture_remote_refs.py', 'package_baseline_evidence.py',
               'package_release_evidence.py']
    selected.extend(Path(__file__).parent / filename for filename in helpers)
    archived = package(workspace, output, 'local-qualification', selected, manifest['scope'])
    receipt = {
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_commit': args.source, 'archive': archived,
        'file_only_operations': True, 'git_commands_executed': False, 'tests_executed': False,
        'package_script_sha256': digest(Path(__file__).read_bytes()),
        'archive_implementation_sha256': digest((Path(__file__).parent / 'package_baseline_evidence.py').read_bytes()),
    }
    write('publication-receipt.json', receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
