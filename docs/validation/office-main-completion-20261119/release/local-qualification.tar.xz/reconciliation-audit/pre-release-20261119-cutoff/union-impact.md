# Cutoff integration impact beyond known input heads

Bounded cutoff: **2026-11-19 07:15:06 UTC**. Incoming `4624218f9468eeeac07f1f100ac0e4bb6b050a17` includes Mail `71edec2d` by ancestry and also merges qualified `54c36e40`. Comparisons below use existing `99dd7307`, `e734e3bd` and `54c36e40` Git blobs.

## Executable changes and required resolutions

| Full path | Additional behavior / resolution |
|---|---|
| `tools/mail/test_check_store.py` | Catch FileNotFoundError and ProcessLookupError while reading an exiting child process stat in the existing timeout regression. No additional test case; resolves a test observation race. Retain this change and freshly run the complete store gate/Python controls. |
| `packages/quds_mail_core/test/models_test.dart` | Combines the qualified54 set-add expression with incoming explicit equal-hash assertion. Production core implementation unchanged. Retain equality/hash assertions; freshly run the complete core/store gate. |
| `third_party/enough_mail/lib/src/private/util/client_base.dart` | Relative to e734, retains a cancellation callback during STARTTLS and makes disconnect abort a pending connection. Preserve the reviewed Socket API implementation. Its pending RawSocket/ConnectionTask ownership and disconnect-to-abort path already provide these safeguards. |
| `third_party/enough_mail/lib/src/private/util/client_connection.dart` | Relative to e734, adds ordered stream writes, a single active producer guard, abort cancellation of an idle StreamIterator and a post-EOF open check so abort remains a failed write. Preserve the Socket-compatible IOSink/_RawSocketConsumer implementation, whose cancellation and post-stream write check already provide these safeguards. Do not add a competing ClientConnection API. |
| `packages/quds_mail_transport/test/native_tls_round_trip_test.dart` | Only import/type/signature adaptation from Socket to ClientConnection; no new case or behavior beyond qualified54. Retain the original Socket-compatible test shape. |
| `packages/quds_mail_transport/test/support/imap_fixture.dart` | Combines already included fixture notification behavior with incoming ClientConnection factory adaptation. Retain the equivalent Socket-returning seam and existing notification controls. |

The TLS reviewer independently confirmed that the462 changes add no uncovered safeguard to the reviewed Socket-compatible union. The required original TCP ownership, secure metadata and explicit abort-signal ports are already in the pending review fix. The new incoming stream producer cancellation corresponds to the existing IOSink/_RawSocketConsumer controls, including abort of an idle producer.

## Complete product path inventory changed from99dd

| Full path | Incoming entry relationship |
|---|---|
| `packages/quds_mail_core/test/models_test.dart` | Merged/new entry; detailed above or combined documentation |
| `packages/quds_mail_transport/CHANGELOG.md` | mail_e734 |
| `packages/quds_mail_transport/README.md` | Merged/new entry; detailed above or combined documentation |
| `packages/quds_mail_transport/test/fixtures/tls/README.md` | mail_e734 |
| `packages/quds_mail_transport/test/fixtures/tls/loopback-cert.pem` | mail_e734 |
| `packages/quds_mail_transport/test/fixtures/tls/loopback-key.pem` | mail_e734 |
| `packages/quds_mail_transport/test/native_tls_cancellation_test.dart` | qualified_54 |
| `packages/quds_mail_transport/test/native_tls_round_trip_test.dart` | Merged/new entry; detailed above or combined documentation |
| `packages/quds_mail_transport/test/native_tls_test.dart` | mail_e734 |
| `packages/quds_mail_transport/test/support/imap_fixture.dart` | Merged/new entry; detailed above or combined documentation |
| `packages/quds_mail_transport/test/support/tls/README.md` | qualified_54 |
| `packages/quds_mail_transport/test/support/tls/public-test-ca.pem` | qualified_54 |
| `packages/quds_mail_transport/test/support/tls/public-test-server-key.pem` | qualified_54 |
| `packages/quds_mail_transport/test/support/tls/public-test-server.pem` | qualified_54 |
| `packages/quds_mail_transport/test/support/tls_server.dart` | mail_e734 |
| `third_party/enough_mail/QUDS_PATCHES.md` | Merged/new entry; detailed above or combined documentation |
| `third_party/enough_mail/lib/src/private/util/client_base.dart` | Merged/new entry; detailed above or combined documentation |
| `third_party/enough_mail/lib/src/private/util/client_connection.dart` | Merged/new entry; detailed above or combined documentation |
| `tools/mail/test_check_store.py` | Merged/new entry; detailed above or combined documentation |

`third_party/enough_mail/lib/src/private/util/cancellable_socket.dart` is absent in the incoming architecture and must remain in the reviewed Socket-compatible resolution. The original cancellation test is byte-identical to54; the round-trip test changes only API types/imports. The incoming native TLS test and tls_server support were already introduced in e734.

## Documentation and evidence

Retain incoming readme, roadmap, validation and TLS review evidence as history. Reconcile transport README and QUDS_PATCHES to describe the selected Socket-compatible API; incoming prose describes an external-socket upgrade rejection that is not the selected implementation. Native plan selection and final acceptance statements must describe the new frozen source and actual fresh executions.

The full JSON contains every changed path and all four tree-entry identities, including documentation/evidence. The parser and UID tests have no additional462 delta beyond99dd. Mail71ed adds only the Python process-reaping guard.

All392 captured refs remain the fixed release cutoff. An intermediate audit on292f9b97 recomputed all14 historical proofs successfully and has only the3 expected refs at the two incoming heads unaccounted. Final zero-unaccounted acceptance is deferred until the reviewed merge commit exists. No further advertisements are needed before that final consistency read.
