#!/usr/bin/env python3
"""Execute separately counted helper controls against the frozen source."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

repo = Path('/workspace/scratch/f0520e768bc8/quds_office_suite')
output = Path('/workspace/scratch/f0520e768bc8/qualification-release-support')
source = '5569c055a021c893e941fc54d40499ad9d96a5db'
output.mkdir(parents=True, exist_ok=False)

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=repo).decode().strip()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

inputs = [
    'docs/validation/document-review-notes-20261118/test_run_checks.py',
    'docs/validation/document-review-notes-20261118/run_checks.py',
    'docs/validation/document-review-notes-20261118/runtime/test_restore_runtime.py',
    'docs/validation/document-review-notes-20261118/runtime/restore_runtime.py',
]
assert git('rev-parse', 'HEAD') == source
assert not git('status', '--porcelain=v1', '--untracked-files=no')
before = {path: sha(repo / path) for path in inputs}
for path, digest in before.items():
    blob = subprocess.check_output(['git', 'show', source + ':' + path], cwd=repo)
    assert hashlib.sha256(blob).hexdigest() == digest, path
checks = []
for name, directory, pattern, expected in [
    ('qualification-runner', 'docs/validation/document-review-notes-20261118', 'test_run_checks.py', 20),
    ('runtime-replay', 'docs/validation/document-review-notes-20261118/runtime', 'test_restore_runtime.py', 16),
]:
    command = [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', directory, '-p', pattern, '-v']
    log = output / (name + '.log')
    with log.open('wb') as stream:
        process = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT, timeout=120)
    data = log.read_text()
    counts = re.findall(r'^Ran (\d+) tests? in ', data, flags=re.MULTILINE)
    accepted = process.returncode == 0 and counts == [str(expected)] and bool(re.search(r'^OK\s*$', data, flags=re.MULTILINE))
    checks.append({'name': name, 'command': command, 'exit_code': process.returncode,
                   'passed': expected if accepted else 0, 'accepted': accepted,
                   'log': log.name, 'log_sha256': sha(log)})
after = {path: sha(repo / path) for path in inputs}
receipt = {'source_commit': source, 'source_tree': git('rev-parse', source + '^{tree}'),
           'checks': checks, 'source_before': before, 'source_after': after,
           'source_unchanged': before == after, 'head_unchanged': git('rev-parse', 'HEAD') == source,
           'tracked_clean_after': not git('status', '--porcelain=v1', '--untracked-files=no'),
           'passed': sum(row['passed'] for row in checks), 'github_actions_queried_or_awaited': False}
receipt['success'] = (all(row['accepted'] for row in checks) and receipt['source_unchanged']
                      and receipt['head_unchanged'] and receipt['tracked_clean_after'])
(output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['source_commit', 'passed', 'success']}, indent=2))
raise SystemExit(0 if receipt['success'] else 1)
