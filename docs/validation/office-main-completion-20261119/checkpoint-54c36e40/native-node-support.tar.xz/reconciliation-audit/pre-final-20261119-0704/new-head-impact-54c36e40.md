# New remote-head impact against frozen 54c36e40

Frozen source: `54c36e40daa7b17d73801dac1fd12f110b24017f`. This audit reads Git objects only and preserves the active qualification worktree.

## Office integration 99dd7307

Common ancestor with frozen source is `c634f494b85f7b2118781300a322ad0d9c216a17`. New ancestry includes f9104833, d1dda005, 2890a0f2, 7d279e08 and 99dd7307. The last merge also has c634 as its second parent.

Its complete product delta from this common ancestor is:

- `third_party/enough_mail/lib/src/private/imap/raw_fetch_parser.dart`: canonical decimal UID grammar before integer parsing; signed, hexadecimal and leading-zero forms fail and latch failure.
- `third_party/enough_mail/test/src/imap/raw_fetch_parser_test.dart`: six cases across 0x1, +1 and 01 for body and FLAGS-only records.
- `third_party/enough_mail/QUDS_PATCHES.md`: corresponding parser and resource-error wording.

The parser fix and tests are additional to 54. The remaining application files are the common-base versions; direct full-tree comparison to 54 would misleadingly show removal of later TLS files. Merge ancestry normally and retain 54 TLS changes.

## Mail e734e3bd / PR 172

Common ancestor is `7d1adf1636450b3f6040b79856ea62045d03f23d`. Two unique commits are da78c0bb (independent TLS ownership implementation) and e734e3bd (test repair).

| Incoming changed path | Relation to frozen source |
|---|---|
| `packages/quds_mail_core/test/models_test.dart` | Current also differs from common base; deliberate resolution |
| `packages/quds_mail_store/test/migration_test.dart` | Already byte-identical |
| `packages/quds_mail_transport/CHANGELOG.md` | Current still equals common base; incoming addition/change |
| `packages/quds_mail_transport/README.md` | Current also differs from common base; deliberate resolution |
| `packages/quds_mail_transport/test/fixtures/tls/README.md` | Current still equals common base; incoming addition/change |
| `packages/quds_mail_transport/test/fixtures/tls/loopback-cert.pem` | Current still equals common base; incoming addition/change |
| `packages/quds_mail_transport/test/fixtures/tls/loopback-key.pem` | Current still equals common base; incoming addition/change |
| `packages/quds_mail_transport/test/native_tls_test.dart` | Current still equals common base; incoming addition/change |
| `packages/quds_mail_transport/test/support/imap_fixture.dart` | Current also differs from common base; deliberate resolution |
| `packages/quds_mail_transport/test/support/tls_server.dart` | Current still equals common base; incoming addition/change |
| `third_party/enough_mail/QUDS_PATCHES.md` | Current also differs from common base; deliberate resolution |
| `third_party/enough_mail/lib/src/private/util/client_base.dart` | Current also differs from common base; deliberate resolution |
| `third_party/enough_mail/lib/src/private/util/client_connection.dart` | Current still equals common base; incoming addition/change |

da78 introduces a new ClientConnection interface and changes both overridable socket factories from Socket to ClientConnection. RawClientConnection owns raw TCP/TLS lifecycle; the ordinary Socket wrapper rejects default external-socket STARTTLS. The incoming upgrade path also updates connectionInfo and aborts on upgrade failures. Frozen 54 instead preserves Socket factory types through a private _CancellableSocket adapter. These are competing implementations requiring coherent source, fixture and test resolution. An independent reviewer is comparing behavioral and test coverage differences.

e734 already shares the repaired migration import. Its core flags test differs from frozen 54 by an explicit equal-hash assertion and an equivalent set literal; it is a real source-input change even though production core code is unchanged.

## Merge and qualification decision

1. Preserve the completed 54 source qualification as its own baseline and archive it before the final replay.
2. Merge integration 99dd after current gates; adopt the UID decimal grammar and six tests while preserving current TLS source.
3. Merge Mail e734 deliberately: retain current verified Socket-compatible TLS implementation unless independent comparison establishes stronger required behavior. Preserve incoming history and all documentation/evidence; resolve competing ClientConnection API/fixtures/tests coherently rather than mixing architectures.
4. The incoming migration test already matches frozen source. The flags test has one new explicit equal-hash assertion plus an equivalent set expression; retaining it changes store/core gate input identity and requires replay of the core/store gate or exact-scope supplemental verification.
5. Do not transfer the 54 application pass to any changed parser or TLS input. Rerun the affected complete native union and Node gate on the final frozen source, plus support controls and store if its input changes.

The full JSON contains every incoming path and base/incoming/frozen Git object identity, all relevant ancestry assertions, and exact unique commits. No tests or GitHub CI were queried or run by this audit.
