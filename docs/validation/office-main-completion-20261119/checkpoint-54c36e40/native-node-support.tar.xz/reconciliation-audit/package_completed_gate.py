#!/usr/bin/env python3
"""Archive a completed, independently audited gate using file-only operations."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path

from package_baseline_evidence import collect, digest, package


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--source', required=True)
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--node', type=Path, required=True)
    parser.add_argument('--support', type=Path, required=True)
    parser.add_argument('--audit', type=Path, required=True)
    parser.add_argument('--include', type=Path, action='append', default=[])
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--scope', required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    gates = [
        json.loads((args.native / 'verification.json').read_text()),
        json.loads((args.node / 'verification.json').read_text()),
        json.loads((args.support / 'receipt.json').read_text()),
    ]
    summary_path = args.audit / 'independent-summary.json'
    audited = json.loads(summary_path.read_text())
    if not all(row['success'] for row in gates) or not audited['passed']:
        raise RuntimeError('Only completed passing, independently audited gates may be archived')
    if any(row['source_commit'] != args.source for row in [*gates, audited]):
        raise RuntimeError('Source identity mismatch')
    manifest = {
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'scope': args.scope,
        'native_node_source_commit': args.source,
        'store_execution_source_commit': audited['store_execution_source_commit'],
        'store_transfer': 'Actual execution source is preserved. The included independent store audit records exact scoped input equality and dependency closure.',
        'application_case_executions': audited['application_case_executions'],
        'suite_platform_executions': audited['suite_platform_executions'],
        'distinct_test_files': audited['distinct_test_files'],
        'separate_python_controls': audited['combined_separate_python_controls'],
        'counts_added_to_later_qualification': 0,
        'historical_office_cases_counted': 0,
        'independent_summary_sha256': digest(summary_path.read_bytes()),
        'github_actions': 'NOT QUERIED OR AWAITED',
    }
    manifest_path = output / 'completed-gate-manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    paths = [manifest_path]
    for directory in [args.native, args.node, args.support, args.audit]:
        paths.extend(collect(directory.resolve()))
    for path in args.include:
        path = path.resolve()
        paths.extend(collect(path) if path.is_dir() else [path])
    paths.extend(Path(__file__).parent.glob('*.py'))
    result = package(workspace, output, 'native-node-support', paths, args.scope)
    receipt = {
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_commit': args.source,
        'archive': result,
        'file_only_operations': True,
        'git_commands_executed': False,
        'tests_executed': False,
        'package_script_sha256': digest(Path(__file__).read_bytes()),
        'archive_implementation_sha256': digest((Path(__file__).parent / 'package_baseline_evidence.py').read_bytes()),
    }
    (output / 'publication-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
