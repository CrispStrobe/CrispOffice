#!/usr/bin/env python3
"""Bind the frozen integration source around the full Mail Store gate."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
from datetime import datetime, timezone

REPO = Path('/workspace/scratch/f0520e768bc8/quds_office_suite')
RUNTIME = Path('/workspace/scratch/f0520e768bc8/runtime')
OUT = Path('/workspace/scratch/f0520e768bc8/qualification-store')
HEAD = '6be7677993715556cf1704d157dff61a428da5a7'
TREE = 'b519052993754c46ce7f655b71c27c9877683f12'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def snapshot():
    runtime = json.loads((RUNTIME / 'runtime.json').read_text())
    paths = {
        REPO / '.dart_tool/package_config.json', REPO / 'pubspec.lock',
        REPO / 'pubspec.yaml', RUNTIME / 'runtime.json',
        RUNTIME / 'workspace-runtime-ready.json', RUNTIME / 'retained-inputs.json',
        RUNTIME / 'pub-cache-receipt.json', RUNTIME / 'evidence-index.json',
        RUNTIME / 'flutter/packages/flutter_tools/.dart_tool/package_config.json',
        RUNTIME / 'flutter/bin/cache/flutter_tools.snapshot',
        RUNTIME / 'env.sh', RUNTIME / 'bin/dart', RUNTIME / 'bin/flutter',
    }
    paths.update(map(Path, runtime['executables_sha256']))
    paths.update(map(Path, runtime['additional_inputs']))
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain', '--untracked-files=no'),
            'inputs': {str(path): digest(path) for path in sorted(paths)}}


assert not OUT.exists(), 'Preserve previous qualification output'
OUT.mkdir()
before = snapshot()
assert before['head'] == HEAD and before['tree'] == TREE and not before['status'], before
untracked = git('ls-files', '--others', '--exclude-standard').splitlines()
assert not any(path.startswith(('packages/', 'apps/', 'third_party/')) for path in untracked)
command = [os.sys.executable, 'tools/mail/check_store.py', '--flutter-sdk',
           str(RUNTIME / 'flutter'), '--offline', '--direct-tests',
           '--command-timeout', '300', '--output', str(OUT)]
record = {'status': 'RUNNING', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
          'before': before, 'command': command, 'github_actions': 'NOT USED'}
write('driver-receipt.json', record)
with (OUT / 'driver.log').open('w') as log:
    process = subprocess.Popen(command, cwd=REPO, env=os.environ, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True, bufsize=1)
    for line in process.stdout:
        log.write(line)
        log.flush()
        print(line, end='', flush=True)
        if line.strip() == 'core-analysis':
            config = str(REPO / '.dart_tool/package_config.json')
            ready = {'phase': 'locked-resolution-complete',
                     'head': git('rev-parse', 'HEAD'),
                     'before_sha256': before['inputs'][config],
                     'after_sha256': digest(config)}
            ready['unchanged'] = ready['before_sha256'] == ready['after_sha256']
            write('locked-resolution-ready.json', ready)
    code = process.wait()
after = snapshot()
record.update(status='PASS' if code == 0 and before == after else 'FAIL',
              exit_code=code, after=after, source_runtime_unchanged=before == after,
              finished_at_utc=datetime.now(timezone.utc).isoformat(),
              receipt_sha256=digest(OUT / 'receipt.json'),
              driver_log_sha256=digest(OUT / 'driver.log'),
              driver_sha256=digest(Path(__file__)))
write('driver-receipt.json', record)
print('Bound store gate: ' + record['status'], flush=True)
raise SystemExit(0 if record['status'] == 'PASS' else code or 1)
