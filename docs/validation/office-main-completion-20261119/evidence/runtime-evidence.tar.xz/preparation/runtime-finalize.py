#!/usr/bin/env python3
"""Finish the verified historical runtime restoration for the new workspace."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote, urlparse

import yaml


ROOT = Path('/workspace/scratch/f0520e768bc8/runtime')
REPO = Path('/workspace/scratch/f0520e768bc8/quds_office_suite')


def digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + '\n')


original_path = ROOT / 'runtime.json'
original = json.loads(original_path.read_text())
assert original['status'] == 'failed'
assert original['error'].startswith('RuntimeError("native-assets-smoke: '), original.get('error')
assert [row['name'] for row in original['runs']] == [
    'flutter-tools-pub-get', 'workspace-pub-get', 'native-assets-smoke',
]
assert [row['exit_code'] for row in original['runs'][:2]] == [0, 0]
assert original['runs'][2]['exit_code'] != 0
assert original['hosted_archives_verified'] == 176
assert original['archive']['verified'] is True
assert original['archive']['sha256'] == 'baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2'
for path, expected in original['executables_sha256'].items():
    assert digest(Path(path)) == expected, path

# The process began before root integrated the existing native-smoke fix.
# Reuse the incoming corrected helper; preserve the original failed receipt.
helper_path = REPO / 'docs/validation/document-review-notes-20261118/runtime/restore_runtime.py'
spec = importlib.util.spec_from_file_location('runtime_restore_helper', helper_path)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
env = dict(os.environ,
           PUB_CACHE=str(ROOT / 'pub-cache'), FLUTTER_ROOT=str(ROOT / 'flutter'),
           CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true',
           DASH__SUPPRESS_ANALYTICS='true', XDG_CONFIG_HOME=str(ROOT / 'config'),
           XDG_CACHE_HOME=str(ROOT / 'cache'), XDG_DATA_HOME=str(ROOT / 'data'),
           TMPDIR=str(ROOT / 'tmp'))
env['PATH'] = str(ROOT / 'bin') + os.pathsep + env.get('PATH', '')
supplement = {'runs': []}


def run(name, command, cwd):
    log = ROOT / 'logs' / (name + '.log')
    print('START ' + name, flush=True)
    with log.open('wb') as stream:
        completed = subprocess.run([str(x) for x in command], cwd=cwd, env=env,
                                   stdout=stream, stderr=subprocess.STDOUT, timeout=300)
    supplement['runs'].append({
        'name': name, 'command': [str(x) for x in command], 'cwd': str(cwd),
        'exit_code': completed.returncode, 'log': str(log), 'log_sha256': digest(log),
    })
    write(ROOT / 'runtime-supplement-progress.json', supplement)
    assert completed.returncode == 0, log.read_text(errors='replace')
    return log


dart = ROOT / 'flutter/bin/cache/dart-sdk/bin/dart'
smoke = REPO / 'docs/validation/document-review-notes-20261118/runtime/native_asset_smoke.dart'
with helper.native_smoke_entrypoint(REPO) as entrypoint:
    supplement['native_smoke'] = {
        'source': str(smoke), 'source_sha256': digest(smoke),
        'entrypoint': str(entrypoint), 'entrypoint_sha256': digest(entrypoint),
        'owning_package': 'quds_mail_store',
        'helper_sha256': digest(helper_path),
    }
    run('native-assets-smoke-owned', [dart, 'run', entrypoint], REPO / 'packages/quds_mail_store')
helper.bind_test_inputs(REPO, ROOT, supplement, node_tests=True)
version = run('flutter-version', [ROOT / 'bin/flutter', '--version', '--machine'], REPO)
runtime = json.loads(version.read_text())
assert runtime['frameworkRevision'] == '737ba8f885dc774b53b442759999a312c9461e4e'
assert runtime['dartSdkVersion'] == '3.13.7'

before = json.loads((ROOT / 'manifests-before.json').read_text())
after = {path: digest(REPO / path) for path in before['inputs']}
assert before['inputs'] == after, 'A tracked manifest/lock changed during restore'
manifest = yaml.safe_load((REPO / 'pubspec.yaml').read_text())
lock = yaml.safe_load((REPO / 'pubspec.lock').read_text())
workspace = {manifest['name']: str(REPO)}
for relative in manifest['workspace']:
    package_path = REPO / relative
    spec = yaml.safe_load((package_path / 'pubspec.yaml').read_text())
    workspace[spec['name']] = str(package_path)
assert len(workspace) == len(manifest['workspace']) + 1

config_path = REPO / '.dart_tool/package_config.json'
config = json.loads(config_path.read_text())
packages = {row['name']: row for row in config['packages']}
expected_names = set(lock['packages']) | set(workspace)
assert set(packages) == expected_names, (set(packages) ^ expected_names)
assert len(packages) == 131
for name, expected_root in workspace.items():
    uri = packages[name]['rootUri']
    parsed = urlparse(uri)
    actual_root = Path(unquote(parsed.path)) if parsed.scheme == 'file' else config_path.parent / unquote(uri)
    assert actual_root.resolve() == Path(expected_root).resolve(), (name, actual_root)
assert 'quds_mail_transport' in workspace

retained = {}
for prefix in ['flutter', 'pub-cache/hosted/pub.dev']:
    for path in sorted((ROOT / prefix).rglob('*')):
        if path.is_file() and '.dart_tool' not in path.parts:
            retained[str(path.relative_to(ROOT))] = {
                'bytes': path.stat().st_size,
                'sha256': digest(path),
            }
write(ROOT / 'retained-inputs.json', retained)
receipt = {
    'status': 'ready',
    'completed_at_utc': datetime.now(timezone.utc).isoformat(),
    'source_head_at_resolution': before['head'],
    'source_head_at_verification': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    'runtime_root': str(ROOT),
    'environment_script': str(ROOT / 'env.sh'),
    'original_restore_receipt': {
        'path': str(original_path), 'sha256': digest(original_path),
        'status': original['status'], 'error': original['error'],
        'explanation': 'Initial process used the historical probe owned by the '
                       'dependency-free workspace root and skipped the native hook. '
                       'The integrated Notes helper stages the exact probe under '
                       'the declaring Mail Store package; its genuine hook and FTS5 '
                       'probe succeeded. New Mail transport adds one workspace '
                       'member, resulting in 131 locked resolved packages.',
    },
    'runtime': runtime,
    'archive': original['archive'],
    'executables_sha256': original['executables_sha256'],
    'additional_inputs': supplement['additional_inputs'],
    'native_assets': supplement['native_assets'],
    'native_smoke': supplement['native_smoke'],
    'node_runtime': supplement['node_runtime'],
    'successful_setup_runs': original['runs'][:2] + supplement['runs'],
    'hosted_archives_verified': 176,
    'workspace_package_count': len(packages),
    'resolved_names_match_lock_and_workspace': True,
    'workspace_members': workspace,
    'resolved_package_names': sorted(packages),
    'package_config_sha256': digest(config_path),
    'tracked_manifest_and_lock_inputs': after,
    'tracked_manifest_and_lock_inputs_unchanged': True,
    'retained_runtime_input_count': len(retained),
    'retained_inputs_sha256': digest(ROOT / 'retained-inputs.json'),
    'finalizer_sha256': digest(Path(__file__)),
    'github_actions_queried_or_awaited': False,
}
write(ROOT / 'workspace-runtime-ready.json', receipt)
(ROOT / 'runtime-ready').touch()
print(json.dumps({
    'status': receipt['status'],
    'workspace_package_count': len(packages),
    'hosted_archives_verified': 176,
    'tracked_manifest_and_lock_inputs_unchanged': True,
    'retained_runtime_input_count': len(retained),
    'receipt': str(ROOT / 'workspace-runtime-ready.json'),
}, indent=2))
