# Exact workspace package verification for runtime replay

## Scope and application

`runtime-replay.patch` changes only these recovery-tooling files:

- `docs/validation/document-review-notes-20261118/runtime/restore_runtime.py`
- `docs/validation/document-review-notes-20261118/runtime/test_restore_runtime.py`

The candidate was prepared outside the checkout while application qualification
remained frozen at `edf2fe7f74a575dfb02f95ed6213b38844e16df8`. It does not change
product code, dependency declarations, the lockfile, the live runtime, or current
qualification results. Apply it only after the frozen application run completes:

```bash
git apply --check /workspace/scratch/f0520e768bc8/runtime-replay-fix/runtime-replay.patch
git apply /workspace/scratch/f0520e768bc8/runtime-replay-fix/runtime-replay.patch
python3 docs/validation/document-review-notes-20261118/runtime/test_restore_runtime.py
```

The current helper's fixed expectation of 130 packages rejects the newly added
Mail transport workspace member even though enforced locked resolution correctly
produces 131. The repair derives expected package names from the lockfile and all
root/workspace manifests, checks the resolved package configuration against that
exact set, and records the verified sets and derived count in the runtime receipt.

Validation rejects missing and unexpected names, substitutions that preserve the
total count, duplicate resolved names, duplicate workspace package names,
duplicate normalized workspace directories, lock/workspace name collisions,
missing or malformed package names, malformed resolved entries, and member paths
outside the repository. It uses the existing PyYAML dependency.

## Verification performed

- All 16 focused Python tests pass: the four existing native-smoke ownership and
  cleanup controls plus 12 package-verification tests.
- `git apply --check` passes on the unchanged frozen checkout.
- The candidate validator reads the actual package configuration successfully:
  114 locked package names + 17 root/workspace package names = 131 resolved names.
- Configuration bytes and tracked source remain unchanged after verification.
- No product tests were rerun for this helper-only candidate. A new full SDK
  download was not repeated; the new validator was exercised against the current
  independently verified runtime's resolved configuration.

`verification.json`, `source.json`, and `tests.log` preserve the exact source,
candidate, patch, package-configuration and test-output identities.

## Prepare a fresh runtime for replay

Use a Python environment with PyYAML, network access to the pinned official SDK,
Pub archives and SQLite release asset, and at least 2 GiB of free space. Choose a
new empty runtime directory outside the source checkout. Keep the published
helper separate from the qualified application checkout when their Git commits
differ:

```bash
QUDS_PUBLICATION_REPO=/absolute/path/to/publication-checkout
QUDS_QUALIFIED_REPO=/absolute/path/to/qualified-application-checkout
QUDS_REPLAY_RUNTIME=/absolute/path/to/new-empty-runtime

python3 "$QUDS_PUBLICATION_REPO/docs/validation/document-review-notes-20261118/runtime/restore_runtime.py" \
  --repo "$QUDS_QUALIFIED_REPO" \
  --runtime-root "$QUDS_REPLAY_RUNTIME" \
  --node-tests

source "$QUDS_REPLAY_RUNTIME/env.sh"
```

The published helper must include this repair. The qualified application checkout
should be clean at the exact commit recorded in its qualification plan/report.
The helper downloads and verifies the full pinned SDK stream and locked archive
hashes, performs enforced offline resolution, runs the unchanged SQLite probe
under the declaring Mail Store package, binds native/Node inputs, validates the
exact package-name set, and publishes a `status: ready` runtime receipt. It never
contacts GitHub Actions.

Then invoke the report's committed local qualification runner and plan against
the qualified application checkout, using this new runtime and a fresh output
directory. Preserve the recorded application source identity; applying a later
replay-tooling patch does not retroactively change the source tested earlier.
