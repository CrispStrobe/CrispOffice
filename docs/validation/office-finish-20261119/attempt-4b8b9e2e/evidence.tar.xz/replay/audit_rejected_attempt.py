#!/usr/bin/env python3
"""Preserve an independently recounted rejected attempt without accepting it."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import gzip
import json
from pathlib import Path
import re
import sys

from audit_outer_validation import (
    Readback, PLAN_ROOT, PYTHON_GROUPS, audit_python_log, expected_python_cases,
    file_hash, read, relative, require, sha,
)


def recount(raw, repo, cwd, requested, label):
    events, malformed = [], []
    for number, line in enumerate(raw.decode("utf-8").splitlines(), 1):
        line = line.strip()
        for prefix in ("Running build hooks...", "Running link hooks..."):
            if line.startswith(prefix):
                line = line[len(prefix):].lstrip()
        if not line:
            continue
        try:
            event = json.loads(line)
            require(isinstance(event, dict) and isinstance(event.get("type"), str), "Invalid event")
            events.append(event)
        except Exception as error:
            malformed.append({"line": number, "text": line, "error": repr(error)})
    suites, starts, completions, errors, diagnostics, anomalies = {}, {}, {}, [], [], []
    kinds = Counter(event["type"] for event in events)
    rows, excluded = [], 0
    for event in events:
        kind = event["type"]
        if kind == "suite":
            suite = event["suite"]
            p = Path(suite["path"])
            if not p.is_absolute():
                p = repo / cwd / p
            path = p.resolve().relative_to(repo).as_posix()
            if suite["id"] in suites:
                anomalies.append("duplicate suite id")
            suites[suite["id"]] = path
        elif kind == "testStart":
            item = event["test"]
            if item["id"] in starts:
                anomalies.append("duplicate test start")
            starts[item["id"]] = item
        elif kind == "testDone":
            ident = event["testID"]
            if ident not in starts:
                anomalies.append("completion without start")
                continue
            if ident in completions:
                anomalies.append("duplicate completion")
            completions[ident] = event
            item = starts[ident]
            if event.get("hidden") or item["name"].startswith("loading ") or re.search(r"(?:^| )\((?:setUpAll|tearDownAll)\)$", item["name"]):
                excluded += 1
                if event.get("result") != "success" or event.get("skipped"):
                    anomalies.append({"unsuccessful_hidden_or_lifecycle": item["name"], "completion": event})
                continue
            rows.append({"suite": suites.get(item["suiteID"]), "name": item["name"],
                         "result": event.get("result"), "skipped": event.get("skipped"), "id": ident})
        elif kind == "error":
            ident = event.get("testID")
            errors.append({**event, "test_name": starts.get(ident, {}).get("name")})
        elif kind == "print" and re.search(r"warning|Render\w+ overflowed|Exception|setState\(\) called after dispose", event.get("message", ""), re.I):
            diagnostics.append(event)
    identities = [(row["suite"], row["name"]) for row in rows]
    counts = Counter("skipped" if row["skipped"] else row["result"] for row in rows)
    return {"name": label, "successful_case_events": counts["success"],
            "failed_case_events": counts["failure"] + counts["error"],
            "skipped_case_events": counts["skipped"], "case_result_events": dict(counts),
            "case_events": len(rows), "unique_case_identities": len(set(identities)),
            "duplicate_case_identities": len(rows) - len(set(identities)),
            "suite_count": len(suites), "requested_suite_count": len(requested),
            "missing_suites": sorted(set(requested) - set(suites.values())),
            "unexpected_suites": sorted(set(suites.values()) - set(requested)),
            "unfinished_test_ids": sorted(set(starts) - set(completions)),
            "boundary_events": {key: kinds[key] for key in ("start", "done", "allSuites")},
            "terminal_success": events[-1].get("success") if events and events[-1]["type"] == "done" else None,
            "malformed_records": malformed, "protocol_anomalies": anomalies,
            "excluded_hidden_or_lifecycle_events": excluded,
            "failed_cases": [row for row in rows if row["result"] != "success" or row["skipped"]],
            "errors": errors, "diagnostics": diagnostics,
            "all_case_rows": rows, "accepted_case_credit": 0}


def audit(args):
    repo, results = args.repo.resolve(), args.results.resolve()
    git = Readback(repo, args.head)
    outer = read(results / "verification.json")
    require(outer.get("success") is False and outer.get("finished_at_utc") and outer.get("error"),
            "Rejected attempt must have a complete terminal outer receipt")
    require(outer["source_commit"] == git.head and outer["source_tree"] == git.tree_id, "Wrong rejected source")
    for filename, expected in outer["input_manifest_sha256"].items():
        require(file_hash(results / filename) == expected, "Outer input manifest differs")
    before, after = read(results / "inputs-before.json"), read(results / "inputs-after.json")
    tree = git.tree()
    git.prefetch(tree[name]["git_blob"] for name in before["source"])
    frozen_mismatches = [name for name, expected in before["source"].items()
                         if sha(git.blob(name)) != expected]
    phases, cases, totals, files = [], [], Counter(), []
    for phase in ("native", "node"):
        path = results / phase / "verification.json"
        if not path.exists():
            continue
        record = read(path)
        require(record.get("finished_at_utc"), "Do not recount an incomplete phase as terminal")
        require(record["source_commit"] == git.head, "Inner source identity mismatch")
        plan = json.loads(git.blob(f"{PLAN_ROOT}/{phase}-plan.json"))
        groups = {group["name"]: group for group in plan["groups"]}
        for filename, expected in record["manifest_sha256"].items():
            require(file_hash(path.parent / filename) == expected, "Inner manifest hash mismatch")
        runs = []
        for run in record["runs"]:
            raw = (path.parent / relative(run["log"])).read_bytes()
            compressed = (path.parent / relative(run["compressed_log"])).read_bytes()
            require(sha(raw) == run["log_sha256"] and sha(compressed) == run["compressed_log_sha256"]
                    and gzip.decompress(compressed) == raw, "Raw/compressed log mismatch")
            row = {"name": run["name"], "exit_code": run["exit_code"], "accepted_by_runner": run["accepted"],
                   "stdout_sha256": sha(raw), "stdout_gzip_sha256": sha(compressed)}
            if run["name"] in groups:
                group = groups[run["name"]]
                requested = [(Path(group["cwd"]) / p).as_posix() for p in group["tests"]]
                counted = recount(raw, repo, group["cwd"], requested, phase + "/" + run["name"])
                require(counted["successful_case_events"] == run["passed"]
                        and counted["failed_case_events"] == run["failed"]
                        and counted["skipped_case_events"] == run["skipped"], "Diagnostic recount differs from runner")
                stderr = (path.parent / relative(run["stderr_log"])).read_bytes()
                stderr_gzip = (path.parent / relative(run["stderr_compressed_log"])).read_bytes()
                require(sha(stderr) == run["stderr_log_sha256"] and sha(stderr_gzip) == run["stderr_compressed_log_sha256"]
                        and gzip.decompress(stderr_gzip) == stderr, "Raw/compressed stderr differs")
                row.update(stderr_sha256=sha(stderr), stderr_gzip_sha256=sha(stderr_gzip),
                           stderr_bytes=len(stderr), stderr=stderr.decode("utf-8"))
                cases.extend({"phase": phase, "group": run["name"], **case} for case in counted.pop("all_case_rows"))
                for key in ("successful_case_events", "failed_case_events", "skipped_case_events", "suite_count"):
                    totals[key] += counted[key]
                row.update(counted)
            runs.append(row)
        phases.append({"name": phase, "accepted_by_runner": record["success"],
                       "verification_sha256": file_hash(path), "runs": runs,
                       "source_unchanged": record["source_unchanged"], "environment_unchanged": record["environment_unchanged"],
                       "source_mismatches": record["source_mismatches"], "environment_mismatches": record["environment_mismatches"]})
    python = []
    for run in outer["runs"]:
        require(file_hash(results / run["log"]) == run["log_sha256"], "Outer log changed")
        if run["name"] in PYTHON_GROUPS:
            directory, pattern = PYTHON_GROUPS[run["name"]]
            sources, expected = expected_python_cases(git, directory, pattern)
            named = audit_python_log((results / run["log"]).read_bytes(), expected)
            python.append({"name": run["name"], "successful_control_events": len(named), "cases": named,
                           "source_files": sources, "accepted_final_control_credit": 0})
    for path in sorted(results.rglob("*")):
        if path.is_file():
            files.append({"path": path.relative_to(results).as_posix(), "bytes": path.stat().st_size, "sha256": file_hash(path)})
    case_output = args.output.with_name(args.output.stem + "-cases.json")
    require(not case_output.exists(), "Do not overwrite diagnostic cases")
    case_output.write_text(json.dumps(cases, indent=2) + "\n")
    return {"outcome": "REJECTED", "qualification_accepted": False, "recount_complete": True,
            "audited_at_utc": datetime.now(timezone.utc).isoformat(), "source_commit": git.head, "source_tree": git.tree_id,
            "outer_error": outer["error"], "outer_verification_sha256": file_hash(results / "verification.json"),
            "diagnostic_counts": dict(totals), "phases": phases, "python_controls": python,
            "outer_inputs_unchanged": before == after, "outer_recorded_inputs_unchanged": outer["inputs_unchanged"],
            "outer_source_inputs": len(before["source"]), "outer_runtime_inputs": len(before["environment"]),
            "source_matches_frozen_git": not frozen_mismatches, "frozen_git_mismatches": frozen_mismatches,
            "accepted_final_application_credit": 0, "accepted_final_python_credit": 0,
            "scope": "Successful events describe this rejected attempt only. Node/browser stages absent from terminal receipts did not run. No event here contributes to a later accepted qualification.",
            "full_output_inventory": files, "case_inventory": {"path": str(case_output), "sha256": file_hash(case_output)},
            "auditor": {"path": str(Path(__file__).resolve()), "sha256": file_hash(__file__)},
            "github_actions_queried_or_awaited": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--head", required=True)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output = args.output.resolve()
    require(not args.output.exists() and not args.output.is_relative_to(args.repo.resolve()), "Use new external output")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result = audit(args)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"outcome": result["outcome"], "diagnostic_counts": result["diagnostic_counts"],
                      "accepted_final_application_credit": 0, "output": str(args.output)}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
