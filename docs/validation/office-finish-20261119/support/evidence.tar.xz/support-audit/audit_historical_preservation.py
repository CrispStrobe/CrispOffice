#!/usr/bin/env python3
"""Compare historical document and archive identities using immutable Git trees."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess


SOURCES = {
    'main': 'b070e228a749e22cc8ce2098029a76ab5fb8eccb',
    'sync': '1b6d280b6ed41a1e01736a88f6d02431057c8611',
    'host': 'c63558c0b3bc713361771cc29b0d89ecf2fa09a7',
    'continuation': '10bd0cc4aa720acda4f52d0da882c57b05446435',
    'resume': '004b2ad6342cae7b2fe2750dbba5a9fdcebd3413',
}


def catalog_digest(entries: dict) -> str:
    return hashlib.sha256(json.dumps(entries, sort_keys=True).encode()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--source', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    if repo in args.output.resolve().parents:
        raise ValueError('Output must remain outside the frozen checkout')
    environment = dict(os.environ, GIT_OPTIONAL_LOCKS='0')

    def git(*argv: str) -> bytes:
        return subprocess.check_output(
            ['git', '--no-lazy-fetch', '-C', str(repo), *argv], env=environment,
        )

    def tree(ref: str) -> dict:
        result = {}
        for record in git('ls-tree', '-rz', ref, '--', 'docs', 'README.md').split(b'\0'):
            if record:
                metadata, path = record.decode().split('\t', 1)
                mode, kind, oid = metadata.split()
                result[path] = {'mode': mode, 'type': kind, 'object': oid}
        return result

    current = tree(args.source)
    sources = {label: tree(ref) for label, ref in SOURCES.items()}
    report = {
        'source': args.source,
        'checked_at_utc': datetime.now(timezone.utc).isoformat(),
        'sources': [],
    }
    for label, packet in [
        ('sync', 'docs/validation/office-main-sync-20261119/'),
        ('host', 'docs/validation/office-main-integration-20261119/'),
    ]:
        old = sources[label]
        changed, missing = [], []
        for path, entry in old.items():
            if path not in current:
                missing.append({'path': path, 'original': entry})
            elif current[path] != entry:
                changed.append({
                    'path': path, 'original': entry, 'current': current[path],
                    'identical_to_captured_source': [
                        {'label': key, 'commit': SOURCES[key]}
                        for key, entries in sources.items()
                        if entries.get(path) == current[path]
                    ],
                })
        historical = {p: e for p, e in old.items() if p.startswith('docs/validation/')}
        historical_changed = [e for e in changed if e['path'] in historical]
        historical_missing = [e for e in missing if e['path'] in historical]
        members = {p: e for p, e in old.items() if p.startswith(packet)}
        archives = {p: e for p, e in historical.items()
                    if p.endswith(('.xz', '.gz', '.zip', '.bundle', '.tgz', '.zst', '.tar'))}

        def identity(entries: dict) -> dict:
            return {
                'members': len(entries),
                'identical': sum(current.get(p) == e for p, e in entries.items()),
                'changed': [p for p, e in entries.items() if current.get(p) != e],
                'original_catalog_sha256': catalog_digest(entries),
                'current_projected_catalog_sha256': catalog_digest(
                    {p: current.get(p) for p in entries}),
            }

        report['sources'].append({
            'commit': SOURCES[label],
            'docs_and_root_readme_count': len(old),
            'unchanged': len(old) - len(changed) - len(missing),
            'changed_paths': changed, 'missing_paths': missing,
            'historical_validation_count': len(historical),
            'historical_unchanged': len(historical) - len(historical_changed) - len(historical_missing),
            'historical_changed': historical_changed,
            'historical_missing': historical_missing,
            'all_existing_historical_validation_preserved': not historical_changed and not historical_missing,
            'source_packet': {'prefix': packet, **identity(members)},
            'all_historical_archives': identity(archives),
            'all_historical_changes_match_captured_sources': all(
                e['identical_to_captured_source'] for e in historical_changed),
        })
    report['conclusion'] = {
        'both_source_packets_exact': all(not e['source_packet']['changed'] for e in report['sources']),
        'all_prior_archives_exact': all(not e['all_historical_archives']['changed'] for e in report['sources']),
        'all_history_paths_retained': all(not e['historical_missing'] for e in report['sources']),
        'historical_doc_and_runner_updates_from_captured_sources_only': all(
            e['all_historical_changes_match_captured_sources'] for e in report['sources']),
    }
    report['scope'] = (
        'Exact Git mode/type/blob identity for every pre-existing docs/** and root '
        'README.md path at each named source. Current guides may change; all '
        'historical validation differences and their captured provenance are '
        'listed explicitly. The archive inventories overlap and must not be summed.'
    )
    report.update(network_calls=0, repository_mutations=0, passed=all(report['conclusion'].values()))
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'source': args.source, **report['conclusion'], 'passed': report['passed']}, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
