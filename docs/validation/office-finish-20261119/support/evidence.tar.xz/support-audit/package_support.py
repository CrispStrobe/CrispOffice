#!/usr/bin/env python3
"""Package stable support evidence, retaining exact original-byte mappings."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import tarfile


SOURCE = '4b8b9e2ecec349542bd34bc7f983e1cf500e8cbf'


def digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    repo = workspace / 'quds_office_suite'
    output = args.output.resolve()
    if repo == output or repo in output.parents:
        raise ValueError('Package output must remain outside the frozen checkout')
    output.mkdir(parents=True, exist_ok=True)
    archive = output / 'evidence.tar.xz'
    if archive.exists():
        raise ValueError('Preserve the existing support archive; choose a new output')
    frozen = json.loads((workspace / 'final-results/inputs-before.json').read_text())
    runtime = json.loads((workspace / 'runtime/runtime.json').read_text())
    assert frozen['head'] == SOURCE
    omitted = []
    for relative in [
        'fixtures/hunspell/dictionary/ar.aff',
        'fixtures/hunspell/dictionary/ar.dic',
        'fixtures/arabic-morph/bundle/camel_morph_msa_v1.0.noprob.db',
    ]:
        path = workspace / relative
        actual = digest(path)
        runtime_expected = runtime['additional_inputs'].get(str(path))
        frozen_expected = frozen['environment'].get(str(path))
        assert actual == runtime_expected == frozen_expected, relative
        catalog = ('packages/quds_arabic_morph/lib/src/morph_catalog.dart'
                   if 'arabic-morph/' in relative else
                   'packages/quds_proofing_hunspell/lib/src/hunspell_catalog.dart')
        omitted.append({
            'original': str(path), 'workspace_relative': relative,
            'bytes': path.stat().st_size, 'sha256': actual,
            'runtime_receipt_sha256': runtime_expected,
            'frozen_envelope_sha256': frozen_expected,
            'catalog_at_source': catalog,
            'source_commit': SOURCE,
            'matched_both_bindings': True,
        })
    omission_report = {
        'source_commit': SOURCE,
        'scope': 'These reproducible dictionary payloads are excluded from this '
                 'support archive. Their bytes were freshly hashed and match '
                 'both runtime/runtime.json additional_inputs and the frozen '
                 'qualification envelope. Download URLs, revisions and hashes '
                 'remain in the frozen source catalogs; manifests, notices '
                 'and original download receipts are included.',
        'payloads': omitted,
        'omitted_payload_bytes': sum(e['bytes'] for e in omitted),
        'other_excluded_directories': [
            'runtime/flutter', 'runtime/pub-cache', 'runtime/cache',
            'runtime/config', 'runtime/data', 'runtime/tmp',
            'fixtures/build-tools', 'fixtures/arabic-morph/cmake-native',
        ],
        'runtime_coverage': 'SDK/dependency files and installed toolchain inputs '
                            'remain pinned by the included runtime receipts '
                            'and independently checked frozen envelope.',
    }
    (workspace / 'support-audit/omitted-payloads.json').write_text(
        json.dumps(omission_report, indent=2) + '\n')

    selected: dict[str, Path] = {}

    def add(path: Path, member: str | None = None) -> None:
        if not path.is_file():
            raise ValueError('Selected support input is not a file: ' + str(path))
        member = member or path.relative_to(workspace).as_posix()
        if member.startswith('/') or '..' in Path(member).parts or member in selected:
            raise ValueError('Unsafe or duplicate archive member: ' + member)
        selected[member] = path

    for directory in ['reconciliation', 'support-audit', 'development',
                      'review-proofing', 'audit-preparation']:
        for path in sorted((workspace / directory).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                add(path)
    for path in sorted((workspace / 'runtime').iterdir()):
        if path.is_file() and (path.suffix == '.json' or path.name == 'env.sh'):
            add(path)
    for directory in ['runtime/bin', 'runtime/logs']:
        for path in sorted((workspace / directory).rglob('*')):
            if path.is_file():
                add(path)
    for relative in ['fixtures/env.sh', 'fixtures/bind_runtime_fixtures.py']:
        add(workspace / relative)
    for directory in ['fixtures/hunspell', 'fixtures/arabic-morph']:
        for path in sorted((workspace / directory).iterdir()):
            if path.is_file() and path.suffix in ('.json', '.log'):
                add(path)
    for directory in ['fixtures/hunspell/native', 'fixtures/arabic-morph/native',
                      'fixtures/arabic-morph/source']:
        for path in sorted((workspace / directory).rglob('*')):
            if path.is_file():
                add(path)
    for directory in ['fixtures/hunspell/dictionary', 'fixtures/arabic-morph/bundle']:
        for path in sorted((workspace / directory).iterdir()):
            if path.is_file() and path.suffix not in ('.aff', '.dic', '.db', '.dat', '.idx'):
                add(path)
    add(workspace / 'final-results/inputs-before.json', 'source/inputs-before.json')
    for relative in [
        'docs/validation/office-finish-20261119/README.md',
        'docs/validation/office-finish-20261119/source-review.json',
        'docs/validation/office-finish-20261119/native-plan.json',
        'docs/validation/office-finish-20261119/node-plan.json',
        'docs/validation/office-finish-20261119/run_validation.py',
        'docs/validation/office-finish-20261119/audit_qualification.py',
        'docs/validation/document-review-notes-20261118/run_checks.py',
        'docs/validation/document-review-notes-20261118/test_run_checks.py',
        'packages/quds_proofing_hunspell/lib/src/hunspell_catalog.dart',
        'packages/quds_arabic_morph/lib/src/morph_catalog.dart',
    ]:
        add(repo / relative, 'source/' + relative)

    entries = []
    for member, path in sorted(selected.items()):
        actual = digest(path)
        binding = frozen['environment'].get(str(path))
        kind = 'environment' if binding else None
        if repo in path.parents:
            binding = frozen['source'].get(path.relative_to(repo).as_posix())
            kind = 'source' if binding else None
        if binding is not None:
            assert actual == binding, str(path)
        entries.append({
            'path': member, 'original': str(path), 'bytes': path.stat().st_size,
            'sha256': actual, 'mode': path.stat().st_mode & 0o777,
            'frozen_binding_kind': kind, 'frozen_binding_sha256': binding,
        })
    with tarfile.open(archive, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as bundle:
        for entry in entries:
            data = Path(entry['original']).read_bytes()
            assert len(data) == entry['bytes']
            assert hashlib.sha256(data).hexdigest() == entry['sha256']
            info = tarfile.TarInfo(entry['path'])
            info.size = len(data)
            info.mode = entry['mode']
            info.mtime = 0
            bundle.addfile(info, io.BytesIO(data))
    with tarfile.open(archive, 'r:xz') as bundle:
        members = bundle.getmembers()
        assert len(members) == len(entries)
        assert len({member.name for member in members}) == len(members)
        assert [member.name for member in members] == [e['path'] for e in entries]
        for member, entry in zip(members, entries):
            assert member.isfile() and member.size == entry['bytes']
            assert member.mode == entry['mode']
            stream = bundle.extractfile(member)
            assert stream is not None
            actual = hashlib.file_digest(stream, 'sha256').hexdigest()
            assert actual == entry['sha256']
            assert digest(Path(entry['original'])) == entry['sha256']
    index = {
        'schema': 1, 'source_commit': SOURCE,
        'source_tree': frozen['index_tree'],
        'verified_at_utc': datetime.now(timezone.utc).isoformat(),
        'archive': archive.name, 'archive_bytes': archive.stat().st_size,
        'archive_sha256': digest(archive), 'member_count': len(entries),
        'uncompressed_bytes': sum(e['bytes'] for e in entries),
        'categories': dict(Counter(e['path'].split('/')[0] for e in entries)),
        'frozen_bound_members': sum(e['frozen_binding_kind'] is not None for e in entries),
        'all_members_reopened_and_hash_verified': True,
        'all_originals_rechecked_unchanged': True,
        'repository_or_runtime_mutations': 0, 'network_calls': 0,
        'scope': 'Stable reconciliation, source/runtime/fixture preparation, '
                 'independent input preservation, and development evidence. '
                 'Development and earlier executions do not count toward the '
                 'separately frozen final qualification. Archive members '
                 'are not test executions.',
        'excluded_payloads_manifest': 'support-audit/omitted-payloads.json',
        'files': entries,
    }
    (output / 'evidence.index.json').write_text(json.dumps(index, indent=2) + '\n')
    print(json.dumps({k: index[k] for k in (
        'archive', 'archive_bytes', 'archive_sha256', 'member_count',
        'uncompressed_bytes', 'categories', 'frozen_bound_members',
        'all_members_reopened_and_hash_verified', 'all_originals_rechecked_unchanged',
    )}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
