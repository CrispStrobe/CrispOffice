#!/usr/bin/env python3
"""Independently read a frozen source/runtime envelope without changing it."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess


def digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--source', required=True)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    output = args.output.resolve()
    if output == repo or repo in output.parents:
        raise ValueError('The audit output must be outside the frozen checkout')
    environment = dict(os.environ, GIT_OPTIONAL_LOCKS='0')

    def git(*argv: str) -> bytes:
        return subprocess.check_output(
            ['git', '--no-lazy-fetch', '-C', str(repo), *argv],
            env=environment,
        )

    def state() -> dict:
        return {
            'head': git('rev-parse', 'HEAD').decode().strip(),
            'index_sha256': hashlib.sha256(git('ls-files', '--stage', '-z')).hexdigest(),
            'tracked_status': git('status', '--porcelain', '--untracked-files=no').decode(),
        }

    started = datetime.now(timezone.utc).isoformat()
    before = state()
    manifest_bytes = args.inputs.read_bytes()
    manifest = json.loads(manifest_bytes)
    source = git('rev-parse', args.source + '^{commit}').decode().strip()
    tree = git('rev-parse', source + '^{tree}').decode().strip()
    entries = {}
    for raw in git('ls-tree', '-rz', source).split(b'\0'):
        if raw:
            metadata, path = raw.decode().split('\t', 1)
            mode, kind, oid = metadata.split()
            entries[path] = {'mode': mode, 'type': kind, 'object': oid}
    source_mismatches = []
    source_blob_mismatches = []
    source_mode_mismatches = []
    for path, expected in manifest['source'].items():
        filename = repo / path
        actual = digest(filename)
        if actual != expected:
            source_mismatches.append({'path': path, 'expected': expected, 'actual': actual})
        entry = entries.get(path)
        if entry is None or entry['type'] != 'blob':
            source_blob_mismatches.append({'path': path, 'entry': entry})
            continue
        data = (os.readlink(filename).encode() if entry['mode'] == '120000'
                else filename.read_bytes())
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if blob != entry['object']:
            source_blob_mismatches.append({
                'path': path, 'expected': entry['object'], 'actual': blob,
            })
        if entry['mode'] in ('100644', '100755'):
            executable = bool(filename.stat().st_mode & 0o111)
            if executable != (entry['mode'] == '100755'):
                source_mode_mismatches.append({'path': path, 'entry': entry})
    runtime_mismatches = []
    for path, expected in manifest['environment'].items():
        actual = digest(Path(path))
        if actual != expected:
            runtime_mismatches.append({'path': path, 'expected': expected, 'actual': actual})
    after = state()
    manifest_unchanged = args.inputs.read_bytes() == manifest_bytes
    passed = (
        source == manifest['head'] == before['head'] == after['head']
        and tree == manifest['index_tree']
        and not source_mismatches and not source_blob_mismatches
        and not source_mode_mismatches and not runtime_mismatches
        and not before['tracked_status'] and before == after and manifest_unchanged
    )
    report = {
        'started_at_utc': started,
        'finished_at_utc': datetime.now(timezone.utc).isoformat(),
        'source': source, 'source_tree': tree,
        'source_inputs': len(manifest['source']),
        'source_git_blob_checks': len(manifest['source']),
        'runtime_inputs': len(manifest['environment']),
        'input_manifest': str(args.inputs.resolve()),
        'input_manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
        'input_manifest_unchanged': manifest_unchanged,
        'source_mismatches': source_mismatches,
        'source_blob_mismatches': source_blob_mismatches,
        'source_mode_mismatches': source_mode_mismatches,
        'runtime_mismatches': runtime_mismatches,
        'working_copy_before': before, 'working_copy_after': after,
        'working_copy_unchanged': before == after,
        'github_actions_calls': 0, 'network_calls': 0,
        'repository_or_runtime_mutations': 0,
        'scope': 'Independent in-flight immutable input check. This is neither a '
                 'completed-run audit nor an application execution count.',
        'passed': passed,
    }
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in (
        'source', 'source_tree', 'source_inputs', 'source_git_blob_checks',
        'runtime_inputs', 'working_copy_unchanged', 'passed',
    )}, indent=2))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
