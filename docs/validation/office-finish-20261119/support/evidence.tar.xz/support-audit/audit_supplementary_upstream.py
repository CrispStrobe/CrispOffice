#!/usr/bin/env python3
"""Audit earlier saved upstream PR/tag references without refreshing the capture."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess


SOURCE = '4b8b9e2ecec349542bd34bc7f983e1cf500e8cbf'
MAIN = 'b070e228a749e22cc8ce2098029a76ab5fb8eccb'
CAPTURE_PATH = ('docs/validation/office-resume-main-20261119/reconciliation/'
                'captured-upstream-refs-current.txt')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True, type=Path)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    repo = workspace / 'quds_office_suite'
    output = workspace / 'reconciliation'
    environment = dict(os.environ, GIT_OPTIONAL_LOCKS='0')

    def git(*argv: str, allow_false: bool = False) -> subprocess.CompletedProcess:
        result = subprocess.run(
            ['git', '--no-lazy-fetch', '-C', str(repo), *argv],
            env=environment, capture_output=True,
        )
        if result.returncode and not (allow_false and result.returncode == 1):
            raise RuntimeError(result.stderr.decode())
        return result

    raw = git('show', SOURCE + ':' + CAPTURE_PATH).stdout
    (output / 'supplementary-upstream-source.txt').write_bytes(raw)
    direct_path = output / 'upstream-refs.txt'
    direct_bytes = direct_path.read_bytes()
    direct = {line.split()[1]: line.split()[0]
              for line in direct_bytes.decode().splitlines() if line.strip()}
    original = [line.split() for line in raw.decode().splitlines() if line.strip()]
    overlaps, aliases, extra = [], [], []
    extra_lines = []
    for sha, ref in original:
        if ref.endswith('^{}'):
            aliases.append({'ref': ref, 'peeled_commit': sha})
            continue
        if ref in direct:
            overlaps.append({'ref': ref, 'saved_sha': sha,
                             'direct_sha': direct[ref], 'identical': sha == direct[ref]})
            continue
        commit = git('rev-parse', '--verify', sha + '^{commit}').stdout.decode().strip()
        ancestor = git('merge-base', '--is-ancestor', commit, SOURCE, allow_false=True).returncode == 0
        prior_main = git('merge-base', '--is-ancestor', commit, MAIN, allow_false=True).returncode == 0
        kind = ('upstream_pull_request_head' if ref.startswith('refs/pull/')
                else 'upstream_tag' if ref.startswith('refs/tags/') else 'unknown')
        extra.append({'ref': ref, 'object': sha, 'commit': commit, 'kind': kind,
                      'ancestor_of_frozen_source': ancestor,
                      'ancestor_of_captured_main': prior_main})
        extra_lines.append(sha + '\t' + ref)
    extra_bytes = ('\n'.join(extra_lines) + '\n').encode()
    (output / 'supplementary-upstream-extra-refs.txt').write_bytes(extra_bytes)
    by_ref = {ref: sha for sha, ref in original}
    for alias in aliases:
        tag = by_ref[alias['ref'][:-3]]
        actual = git('rev-parse', '--verify', tag + '^{commit}').stdout.decode().strip()
        alias['actual_peeled_commit'] = actual
        alias['identical'] = actual == alias['peeled_commit']
    counts = dict(Counter(row['kind'] for row in extra))
    passed = (
        counts == {'upstream_pull_request_head': 4, 'upstream_tag': 16}
        and len(overlaps) == 4 and all(row['identical'] for row in overlaps)
        and len(aliases) == 3 and all(row['identical'] for row in aliases)
        and all(row['ancestor_of_frozen_source'] and row['ancestor_of_captured_main']
                for row in extra)
    )
    report = {
        'source': SOURCE, 'captured_main': MAIN,
        'checked_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_capture_path': CAPTURE_PATH,
        'source_capture_blob': git('rev-parse', SOURCE + ':' + CAPTURE_PATH).stdout.decode().strip(),
        'source_capture_sha256': hashlib.sha256(raw).hexdigest(),
        'direct_upstream_capture_sha256': hashlib.sha256(direct_bytes).hexdigest(),
        'extra_ref_capture_sha256': hashlib.sha256(extra_bytes).hexdigest(),
        'original_saved_rows': len(original),
        'overlapping_direct_heads': overlaps,
        'peeled_aliases_excluded': aliases,
        'supplementary_counts': counts, 'supplementary_reference_count': len(extra),
        'refs': extra, 'all_ancestors_of_frozen_source': all(
            row['ancestor_of_frozen_source'] for row in extra),
        'all_ancestors_of_captured_main': all(row['ancestor_of_captured_main'] for row in extra),
        'direct_capture_reference_total_unchanged': 440,
        'scope': 'Separate read-only check of twenty additional upstream PR/tag '
                 'references recovered from an earlier committed capture. '
                 'This is not a new remote observation and does not rewrite '
                 'the direct 440-reference capture, its timestamp, or its total.',
        'network_calls': 0, 'github_actions_calls': 0,
        'repository_or_runtime_mutations': 0, 'passed': passed,
    }
    (output / 'supplementary-upstream-audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in (
        'source', 'supplementary_counts', 'supplementary_reference_count',
        'all_ancestors_of_frozen_source', 'all_ancestors_of_captured_main',
        'direct_capture_reference_total_unchanged', 'passed',
    )}, indent=2))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
