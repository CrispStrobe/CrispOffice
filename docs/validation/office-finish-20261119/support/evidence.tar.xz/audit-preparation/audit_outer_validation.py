#!/usr/bin/env python3
"""Read-only supplemental audit of the saved continuation outer driver.

This auditor is intentionally separate from the frozen application checkout.
It validates completed evidence only. It neither executes tests nor contacts
GitHub/Actions. Historical applicability is reported without adding old passes.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter
from datetime import datetime, timezone
import fnmatch
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tarfile
from urllib.parse import unquote, urljoin, urlparse

import yaml


PLAN_ROOT = "docs/validation/office-finish-20261119"
RUNNER = "docs/validation/document-review-notes-20261118/run_checks.py"
MAIL_PRIOR = "5c18db77505f876bf70bf7e89c49e8c3b617e0d4"
MAIL_BROAD = "0669ac119da05f5eb777c8cfdbce32e0261df647"
MAIN_BASE = "b070e228a749e22cc8ce2098029a76ab5fb8eccb"
MAIL_PREFIXES = (
    "packages/quds_mail_core/", "packages/quds_mail_mime/",
    "packages/quds_mail_store/", "packages/quds_mail_transport/",
    "packages/quds_mail_ui/", "third_party/enough_mail/",
)
PYTHON_GROUPS = {
    "bundle-controls": ("tools/proofing/ayaspell", "test_*.py"),
    "packaging-controls": ("packages/quds_proofing_hunspell/tool", "test_build.py"),
}
COMPILERS = {
    "hunspell-browser": "packages/quds_proofing_hunspell/tool/web_compile_check.dart",
    "arabic-morph-browser": "packages/quds_arabic_morph/tool/web_compile_check.dart",
}


def require(value, message):
    if not value:
        raise AssertionError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_hash(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def relative(name):
    require(isinstance(name, str) and bool(name), "Missing relative path")
    p = PurePosixPath(name)
    require(not p.is_absolute() and ".." not in p.parts and p.as_posix() == name,
            "Unsafe relative path: " + name)
    return name


class Readback:
    def __init__(self, repo, head):
        self.repo = repo.resolve()
        self.head = self.git("rev-parse", head + "^{commit}").decode().strip()
        self.tree_id = self.git("rev-parse", self.head + "^{tree}").decode().strip()
        self.trees = {}
        self.contents = {}

    def git(self, *args, data=None):
        return subprocess.check_output(
            ["git", "-C", str(self.repo), *args], input=data,
            env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"},
        )

    def tree(self, head=None):
        head = head or self.head
        if head not in self.trees:
            result = {}
            for entry in self.git("ls-tree", "-rz", "--full-tree", head).split(b"\0"):
                if entry:
                    meta, name = entry.split(b"\t", 1)
                    mode, kind, blob = meta.decode().split()
                    result[name.decode()] = {"mode": mode, "kind": kind, "git_blob": blob}
            self.trees[head] = result
        return self.trees[head]

    def prefetch(self, blob_ids):
        missing = sorted(set(blob_ids) - set(self.contents))
        for offset in range(0, len(missing), 96):
            group = missing[offset:offset + 96]
            raw = self.git("cat-file", "--batch", data=("\n".join(group) + "\n").encode())
            at = 0
            for expected in group:
                end = raw.index(b"\n", at)
                actual, kind, size = raw[at:end].decode().split()
                require(actual == expected and kind == "blob", "Unexpected Git object")
                size = int(size)
                at = end + 1
                self.contents[expected] = raw[at:at + size]
                at += size
                require(raw[at:at + 1] == b"\n", "Broken Git blob boundary")
                at += 1
            require(at == len(raw), "Unconsumed Git data")

    def blob(self, path, head=None):
        entry = self.tree(head)[relative(path)]
        require(entry["kind"] == "blob", "Source input is not a blob")
        self.prefetch([entry["git_blob"]])
        return self.contents[entry["git_blob"]]

    def state(self):
        return {
            "head": self.git("rev-parse", "HEAD").decode().strip(),
            "index_sha256": sha(self.git("ls-files", "--stage", "-z")),
            "status": self.git("status", "--porcelain=v1", "--untracked-files=no").decode(),
        }

    def verify_source(self, values):
        tree = self.tree()
        require(set(values) <= set(tree), "Source inventory contains an untracked path")
        self.prefetch(tree[p]["git_blob"] for p in values)
        inventory = []
        for name, expected in sorted(values.items()):
            entry = tree[name]
            data = self.contents[entry["git_blob"]]
            path = self.repo / name
            require(entry["kind"] == "blob" and entry["mode"] in {"100644", "100755"},
                    "Unexpected source type: " + name)
            require(path.is_file() and not path.is_symlink(), "Source missing/redirected: " + name)
            require(sha(data) == expected == file_hash(path), "Frozen/live source mismatch: " + name)
            mode = "100755" if path.stat().st_mode & 0o111 else "100644"
            require(mode == entry["mode"], "Source executable mode mismatch: " + name)
            inventory.append({"path": name, **entry, "sha256": expected, "bytes": len(data)})
        return inventory


def expected_python_cases(git, directory, pattern):
    files = sorted(p for p in git.tree() if str(PurePosixPath(p).parent) == directory
                   and fnmatch.fnmatch(PurePosixPath(p).name, pattern))
    require(files, "No committed Python control files")
    cases = set()
    for name in files:
        module = PurePosixPath(name).stem
        parsed = ast.parse(git.blob(name), filename=name)
        for node in parsed.body:
            if not isinstance(node, ast.ClassDef):
                continue
            methods = [x.name for x in node.body if isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef))
                       and x.name.startswith("test_")]
            if not methods:
                continue
            require(any(isinstance(base, ast.Attribute) and base.attr == "TestCase" for base in node.bases),
                    "Review inherited/dynamic Python test class: " + name)
            require(len(methods) == len(set(methods)), "Duplicate Python test definition")
            for method in methods:
                case = f"{method} ({module}.{node.name}.{method})"
                require(case not in cases, "Duplicate Python case identity")
                cases.add(case)
    return files, cases


def audit_python_log(raw, expected):
    cases, summaries, ok_count = [], [], 0
    for line in raw.decode("utf-8").splitlines():
        match = re.fullmatch(r"(test_\S+ \([^\n]+\)) \.\.\. ok", line)
        if match:
            cases.append(match[1])
        elif re.fullmatch(r"Ran (\d+) tests? in \d+(?:\.\d+)?s", line):
            summaries.append(int(re.fullmatch(r"Ran (\d+) tests? in .*", line)[1]))
        elif line == "OK":
            ok_count += 1
        else:
            require(not line or re.fullmatch(r"-{20,}", line), "Unexpected Python diagnostic: " + line)
    require(len(cases) == len(set(cases)) and set(cases) == expected,
            "Python named cases differ from committed AST")
    require(summaries == [len(expected)] and ok_count == 1, "Python summary boundary differs")
    return sorted(cases)


def forwarding_review(git):
    driver = ast.parse(git.blob(PLAN_ROOT + "/run_validation.py"))
    assignments = [n for n in ast.walk(driver) if isinstance(n, ast.Assign)
                   and any(isinstance(t, ast.Name) and t.id == "env" for t in n.targets)]
    require(len(assignments) == 1 and ast.unparse(assignments[0].value) == "dict(os.environ)",
            "Outer environment capture changed")
    calls = [n for n in ast.walk(driver) if isinstance(n, ast.Call)
             and isinstance(n.func, ast.Name) and n.func.id == "execute"]
    require(len(calls) == 1 and any(k.arg == "env" and isinstance(k.value, ast.Name)
                                  and k.value.id == "env" for k in calls[0].keywords),
            "Outer executor does not forward captured environment")
    mutations = [n for n in ast.walk(driver) if isinstance(n, ast.Subscript)
                 and isinstance(n.value, ast.Name) and n.value.id == "env"
                 and isinstance(n.ctx, (ast.Store, ast.Del))]
    mutations += [n for n in ast.walk(driver) if isinstance(n, ast.Call)
                  and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)
                  and n.func.value.id == "env" and n.func.attr in {"update", "pop", "clear", "setdefault"}]
    require(not mutations, "Outer environment mutates after capture")
    shared = ast.parse(git.blob(RUNNER))
    overrides = [n for n in ast.walk(shared) if isinstance(n, ast.Call)
                 and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)
                 and n.func.value.id == "env" and n.func.attr == "update"]
    require(len(overrides) == 1 and not overrides[0].args, "Unexpected shared environment overlay")
    keys = [k.arg for k in overrides[0].keywords]
    require(None not in keys and not any(k.startswith("QUDS_") for k in keys),
            "Shared runner overrides fixture variables")
    helper = ast.parse(git.blob("tools/mail/check_store.py"))
    execute = next(n for n in helper.body if isinstance(n, ast.FunctionDef) and n.name == "execute")
    popen = [n for n in ast.walk(execute) if isinstance(n, ast.Call)
             and isinstance(n.func, ast.Attribute) and n.func.attr == "Popen"]
    require(len(popen) == 1 and any(k.arg == "env" and isinstance(k.value, ast.Name)
                                  and k.value.id == "env" for k in popen[0].keywords),
            "Shared subprocess helper does not forward its environment")
    return {"outer_environment_captured_once_and_forwarded_unchanged": True,
            "shared_runner_overlay_keys": keys, "fixture_keys_overridden": [],
            "subprocess_popen_receives_forwarded_map": True}


def mail_continuity(git, runtime, outer_source):
    old, now, broad = git.tree(MAIL_PRIOR), git.tree(), git.tree(MAIL_BROAD)
    paths = {p for p in old if p.startswith(MAIL_PREFIXES)}
    require(paths == {p for p in now if p.startswith(MAIL_PREFIXES)}, "Mail package paths changed")
    expected_deltas = {"packages/quds_mail_store/README.md", "packages/quds_mail_ui/analysis_options.yaml"}
    actual = {p for p in paths if old[p] != now[p]}
    require(actual == expected_deltas, "Mail changes exceed reviewed documentation/analyzer scope")
    require(git.blob("packages/quds_mail_ui/analysis_options.yaml") ==
            b"analyzer:\n  exclude:\n    - build/**\ninclude: ../../analysis_options.yaml\n",
            "Mail analyzer exclusion differs")
    root_before = yaml.safe_load(git.blob("pubspec.yaml", MAIL_PRIOR))
    root_now = yaml.safe_load(git.blob("pubspec.yaml"))
    old_workspace, new_workspace = root_before.pop("workspace"), root_now.pop("workspace")
    require(root_before == root_now and set(new_workspace) - set(old_workspace) == {"packages/quds_arabic_morph"}
            and not set(old_workspace) - set(new_workspace), "Unexpected root workspace change")
    require(git.blob("pubspec.lock", MAIL_PRIOR) == git.blob("pubspec.lock", MAIL_BROAD)
            == git.blob("pubspec.lock"), "Historical dependency lock changed")
    config_path = "packages/quds_mail_transport/lib/src/configuration.dart"
    before_comment = b"  /// Optional legacy numeric UID ceiling. Null (the default) admits the full\n  /// protocol UID space. An explicitly supplied old setting retains its numeric\n"
    after_comment = b"  /// Optional legacy numeric UID ceiling. Null (the default) imposes no extra\n  /// numeric ceiling beyond SELECT's UIDNEXT. An old setting retains its numeric\n"
    require(git.blob(config_path, MAIL_BROAD).count(before_comment) == 1
            and git.blob(config_path, MAIL_BROAD).replace(before_comment, after_comment) == git.blob(config_path),
            "Broad Mail configuration delta is no longer the reviewed comment change")
    broad_dart_changes = {p for p in paths if p.endswith(".dart") and broad.get(p) != now[p]}
    require(broad_dart_changes == {config_path}, "Additional broad Mail Dart changes")
    graph = read(git.repo / ".dart_tool/package_graph.json")
    nodes = {p["name"]: p for p in graph["packages"]}
    require(len(nodes) == len(graph["packages"]), "Duplicate dependency graph node")
    roots = {"quds_mail_core", "quds_mail_mime", "quds_mail_store", "quds_mail_transport",
             "quds_mail_ui", "quds_mail_reader_example"}
    pending, closure = list(roots), set()
    while pending:
        name = pending.pop()
        if name in closure:
            continue
        require(name in nodes, "Missing dependency graph node: " + name)
        closure.add(name)
        pending.extend(nodes[name].get("dependencies", []))
        if name in roots:
            pending.extend(nodes[name].get("devDependencies", []))
    require(not {"quds_office_engine", "quds_arabic_morph", "quds_proofing_hunspell"} & closure,
            "Mail dependency closure reaches changed proofing code")
    config = read(git.repo / ".dart_tool/package_config.json")
    mapping = {p["name"]: p for p in config["packages"]}
    lock = yaml.safe_load(git.blob("pubspec.lock"))["packages"]
    hosted = read(runtime / "pub-cache-receipt.json")
    hosts = {(p["name"], p["version"]): p for p in hosted}
    dependencies = []
    for name in sorted(closure):
        item = mapping[name]
        url = urlparse(urljoin((git.repo / ".dart_tool/package_config.json").as_uri(), item["rootUri"]))
        require(url.scheme == "file" and not url.netloc, "Nonlocal dependency mapping")
        directory = Path(unquote(url.path)).resolve()
        manifest = directory / "pubspec.yaml"
        metadata = yaml.safe_load(manifest.read_text())
        require(metadata["name"] == name, "Dependency manifest name mismatch")
        if directory.is_relative_to(git.repo):
            repo_manifest = manifest.relative_to(git.repo).as_posix()
            require(old[repo_manifest] == now[repo_manifest], "Mail path dependency manifest changed")
            require(repo_manifest in outer_source, "Mail dependency manifest outside envelope")
            kind = "unchanged repository package"
        elif directory.is_relative_to(runtime / "pub-cache/hosted/pub.dev"):
            entry = lock[name]
            version = entry["version"]
            pinned = hosts[(name, version)]
            require(entry["source"] == "hosted" and pinned["verified"] is True
                    and pinned["sha256"] == entry["description"]["sha256"]
                    and directory.name == name + "-" + version,
                    "Hosted dependency differs from unchanged lock")
            kind = "same locked and verified hosted archive"
        else:
            require(directory.is_relative_to(runtime / "flutter"), "Unexpected dependency location")
            kind = "same pinned Flutter SDK"
        dependencies.append({"name": name, "kind": kind, "directory": str(directory),
                             "version": nodes[name]["version"], "manifest_sha256": file_hash(manifest)})
    archive_path = "docs/validation/office-main-sync-20261119/runtime/evidence.tar.xz"
    with tarfile.open(git.repo / archive_path, "r:xz") as archive:
        historical_runtime = json.load(archive.extractfile("runtime.json"))
        historical_hosts = json.load(archive.extractfile("pub-cache-receipt.json"))
    current_runtime = read(runtime / "runtime.json")
    require(historical_runtime["archive"] == current_runtime["archive"], "SDK stream identity changed")
    old_versions = {k: v for k, v in historical_runtime["runtime"].items() if k != "flutterRoot"}
    new_versions = {k: v for k, v in current_runtime["runtime"].items() if k != "flutterRoot"}
    require(old_versions == new_versions, "Pinned SDK runtime identity changed")
    archive_pins = lambda values: {(v["name"], v["version"]): v["sha256"] for v in values}
    require(archive_pins(historical_hosts) == archive_pins(hosted), "Hosted archive pins changed")
    summaries = {}
    for name in ["docs/validation/office-main-sync-20261119/final/independent-summary.json",
                 "docs/validation/office-main-sync-20261119/main-delta-v4/final/independent-summary.json"]:
        data = git.blob(name)
        value = json.loads(data)
        require(value["passed"] is True and value["failed"] == value["skipped"] == 0 and not value["issues"],
                "Historical acceptance record is not accepted")
        summaries[value["source_commit"]] = {"path": name, "sha256": sha(data),
                                             "historical_application_executions": value["application_case_executions"]}
    require(set(summaries) == {MAIL_PRIOR, MAIL_BROAD}, "Wrong historical source identities")
    inventory = [{"path": p, **now[p], "sha256": sha(git.blob(p)),
                  "identical_to_5c18db77": p not in actual} for p in sorted(paths)]
    return {"scope": "Source/dependency applicability only; historical executions are not rerun or added to current totals.",
            "prior_source": MAIL_PRIOR, "broad_historical_source": MAIL_BROAD,
            "current_source": git.head, "package_entries": len(paths),
            "unchanged_entries": len(paths) - len(actual),
            "all_mail_dart_sources_tests_and_fixtures_identical_to_5c18db77": True,
            "reviewed_nonruntime_changes": sorted(actual),
            "broad_dart_comment_only_delta": {"path": config_path,
                "before_sha256": sha(git.blob(config_path, MAIL_BROAD)),
                "after_sha256": sha(git.blob(config_path)),
                "exact_comment_replacement_verified": True,
                "fresh_configuration_suite_selected": True},
            "root_workspace_addition_outside_mail_closure": "quds_arabic_morph",
            "unchanged_lock_sha256": sha(git.blob("pubspec.lock")),
            "dependency_closure": dependencies,
            "historical_runtime_archive": {"path": archive_path, "sha256": file_hash(git.repo / archive_path)},
            "same_official_sdk_stream_and_runtime": True,
            "same_hosted_archive_pins": len(hosted), "historical_acceptance_records": summaries,
            "historical_executions_added": 0, "inventory": inventory,
            "excluded_from_unchanged_claim": ["Studio network/saved Mail host code is freshly tested, outside these Mail package prefixes.",
                "The shared Python process helper gained an optional stderr parameter; current frozen command/stream provenance is checked separately."]}


def audit(args):
    git = Readback(args.repo, args.head)
    runtime, results = args.runtime.resolve(), args.results.resolve()
    initial = git.state()
    require(initial["head"] == git.head and not initial["status"], "Audit requires the clean frozen checkout")
    record = read(results / "verification.json")
    require(record.get("success") is True and record.get("inputs_unchanged") is True
            and not record.get("error"), "Outer execution is incomplete or rejected")
    require(record["source_commit"] == git.head and record["source_tree"] == git.tree_id
            and record["source_base"] == MAIN_BASE, "Outer source differs")
    require(record["github_actions_queried_or_awaited"] is False, "Unexpected CI claim")
    require(set(record["input_manifest_sha256"]) == {"inputs-before.json", "inputs-after.json"}, "Outer manifests missing")
    for name, expected in record["input_manifest_sha256"].items():
        require(file_hash(results / name) == expected, "Outer manifest hash mismatch")
    before, after = read(results / "inputs-before.json"), read(results / "inputs-after.json")
    require(before == after and before["head"] == git.head and before["index_tree"] == git.tree_id
            and before["tracked_status"] == "", "Outer source/runtime interval changed")
    plans = {name: json.loads(git.blob(f"{PLAN_ROOT}/{name}-plan.json")) for name in ("native", "node")}
    expected_sources = {p for p in git.tree() if p.startswith(("packages/", "apps/", "third_party/"))}
    expected_sources.update(p for p in git.tree() if "/" not in p and Path(p).suffix in {".yaml", ".lock"})
    for plan in plans.values():
        expected_sources.update(plan["extra_inputs"])
    expected_sources.update([RUNNER, "tools/mail/check_store.py", "tools/mail/check_reader.py"])
    require(set(before["source"]) == expected_sources, "Outer source selection incomplete")
    source_inventory = git.verify_source(before["source"])
    runtime_receipt = read(runtime / "runtime.json")
    require(record["runtime_receipt_sha256"] == file_hash(runtime / "runtime.json"), "Runtime receipt differs")
    retained = read(runtime / "retained-inputs.json")
    expected_environment = {str(runtime / name) for name in retained}
    expected_environment.update(runtime_receipt["additional_inputs"])
    expected_environment.update(str(runtime / name) for name in [
        "runtime.json", "retained-inputs.json", "pub-cache-receipt.json", "env.sh",
        "fixture-environment.json", "runtime-fixture-addendum.json"])
    expected_environment.update(str(git.repo / ".dart_tool" / name)
                                for name in ["package_config.json", "package_graph.json", "native_assets.yaml"])
    require(set(before["environment"]) == expected_environment, "Outer declared environment selection differs")
    for name, expected in before["environment"].items():
        require(file_hash(name) == expected, "Outer runtime live bytes differ: " + name)
    fixture_path = Path(record["fixture_environment_receipt"])
    require(fixture_path == runtime / "fixture-environment.json"
            and file_hash(fixture_path) == record["fixture_environment_receipt_sha256"], "Fixture receipt differs")
    fixture = read(fixture_path)
    require(record["fixture_environment"] == before["fixture_environment"] == fixture["environment"], "Forwarded fixture values differ")
    require(file_hash(fixture["script"]) == record["fixture_environment_script_sha256"] == fixture["script_sha256"], "Fixture script differs")
    forwarding = forwarding_review(git)
    names = ["bundle-controls", "packaging-controls", "native", "node", *COMPILERS]
    require([r["name"] for r in record["runs"]] == names, "Outer run coverage/order differs")
    python_rows, compiler_rows, inner_only = [], [], {}
    for run in record["runs"]:
        name = run["name"]
        require(run["exit_code"] == 0, "Nonzero outer subprocess")
        log = results / relative(run["log"])
        require(file_hash(log) == run["log_sha256"], "Outer raw log hash differs: " + name)
        command = run["command"]
        if name in PYTHON_GROUPS:
            directory, pattern = PYTHON_GROUPS[name]
            require(Path(command[0]).is_absolute(), "Python interpreter path not absolute")
            require(command[1:] == ["-B", "-m", "unittest", "discover", "-s", directory, "-p", pattern, "-v"],
                    "Python command differs")
            files, expected = expected_python_cases(git, directory, pattern)
            cases = audit_python_log(log.read_bytes(), expected)
            require(run["passed"] == len(cases) and sorted(run["cases"]) == cases, "Python receipt count or cases differs")
            python_rows.append({"name": name, "source_files": files, "passed": len(cases), "cases": cases,
                                "log_sha256": run["log_sha256"], "interpreter_path": command[0],
                                "interpreter_current_sha256": file_hash(command[0]),
                                "interpreter_hash_bound_before_run": False})
        elif name in {"native", "node"}:
            expected_prefix = ["-B", str(git.repo / RUNNER), "--head", git.head, "--base", MAIN_BASE,
                               "--plan", str(git.repo / PLAN_ROOT / (name + "-plan.json")),
                               "--runtime", str(runtime), "--output", str(results / name), "--command-timeout"]
            require(command[1:-1] == expected_prefix and int(command[-1]) > 0, "Shared-runner command differs")
            receipt = read(results / name / "verification.json")
            require(receipt["success"] is True and receipt["source_commit"] == git.head, "Inner receipt rejected")
            for filename in ("source-before.json", "source-after.json"):
                source = read(results / name / filename)
                require({p: v["sha256"] for p, v in source.items()} == before["source"], "Inner/outer source sets differ")
            for filename in ("environment-before.json", "environment-after.json"):
                environment = read(results / name / filename)
                for key, expected in environment.items():
                    if key.startswith("runtime/"):
                        path = runtime / key.removeprefix("runtime/")
                    elif key.startswith("additional/"):
                        path = Path(key.removeprefix("additional/"))
                    elif key == "sdk/flutter_tools/package_config.json":
                        path = runtime / "flutter/packages/flutter_tools/.dart_tool/package_config.json"
                    elif key == "workspace/pubspec.lock":
                        path = git.repo / "pubspec.lock"
                    elif key == "workspace/package_config.json":
                        path = git.repo / ".dart_tool/package_config.json"
                    elif key == "workspace/native_assets.yaml":
                        path = git.repo / ".dart_tool/native_assets.yaml"
                    elif key.startswith("workspace/"):
                        path = git.repo / key.removeprefix("workspace/")
                    else:
                        raise AssertionError("Unknown inner runtime key: " + key)
                    if expected is None:
                        require(not path.exists() and not path.is_symlink(), "Unexpected optional mapping")
                        continue
                    require(file_hash(path) == expected, "Inner runtime live mismatch")
                    if str(path) in before["environment"]:
                        require(before["environment"][str(path)] == expected, "Outer/inner runtime boundary mismatch")
                    else:
                        row = inner_only.setdefault(str(path), {"sha256": expected, "phases": []})
                        require(row["sha256"] == expected, "Inner-only runtime values differ between phases")
                        row["phases"].append(name + "/" + filename)
        else:
            output_js = results / "browser" / (name + ".js")
            expected = [str(runtime / "bin/dart"), "compile", "js",
                        "--packages=" + str(git.repo / ".dart_tool/package_config.json"),
                        str(git.repo / COMPILERS[name]), "-o", str(output_js)]
            require(command == expected, "Browser compile command differs")
            require(output_js.is_file() and output_js.stat().st_size > 0, "Missing/empty compiled JavaScript")
            text = log.read_text()
            require("Compiled" in text and "JavaScript" in text and not re.search(r"(?m)^(Error:|Unhandled exception|.*: Error:)", text),
                    "Browser compilation log lacks clean completion")
            compiler_rows.append({"name": name, "input": COMPILERS[name], "input_sha256": before["source"][COMPILERS[name]],
                                  "output": str(output_js), "bytes": output_js.stat().st_size, "sha256": file_hash(output_js),
                                  "log_sha256": run["log_sha256"]})
    files = {p.relative_to(results).as_posix() for p in (results / "browser").iterdir() if p.is_file()}
    require(files == set(record["browser_outputs"]), "Compiler artifact inventory differs")
    allowed = {"browser/" + name + suffix for name in COMPILERS for suffix in (".js", ".js.deps", ".js.map")}
    require(files <= allowed and {"browser/" + name + ".js" for name in COMPILERS} <= files, "Unexpected/missing compiler artifacts")
    for name, item in record["browser_outputs"].items():
        path = results / relative(name)
        require(path.stat().st_size == item["bytes"] and item["bytes"] > 0 and file_hash(path) == item["sha256"],
                "Compiled artifact changed or empty")
    mail = mail_continuity(git, runtime, before["source"])
    require(git.state() == initial, "Checkout changed during independent outer audit")
    return {
        "accepted": True, "audited_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_commit": git.head, "source_tree": git.tree_id,
        "outer_verification_sha256": file_hash(results / "verification.json"),
        "outer_driver_sha256": sha(git.blob(PLAN_ROOT + "/run_validation.py")),
        "python_controls": {"passed": sum(r["passed"] for r in python_rows), "failed": 0, "skipped": 0,
                            "groups": python_rows, "case_identity_source": "Independent committed Python AST versus every named unittest log line"},
        "browser_compilation": {"compilers": compiler_rows, "all_recorded_artifacts_exact_nonempty": True,
                                "artifacts": record["browser_outputs"], "actual_browser_execution": False},
        "fixture_environment": {"forwarded": record["fixture_environment"], "declaration_and_script_hashes_match": True,
                                "source_dispatch_review": forwarding},
        "outer_boundaries": {"all_recorded_before_after_and_live_inputs_identical": True,
                             "source_records": len(source_inventory), "runtime_records": len(before["environment"]),
                             "source_selection_reconstructed_from_frozen_git_and_plans": True,
                             "runtime_selection_reconstructed_from_frozen_driver_and_receipts": True,
                             "inner_source_selection_exactly_matches_outer": True,
                             "inner_only_runtime_inputs": inner_only,
                             "inner_only_scope": "These paths were bound by native/Node before/after snapshots and match final live readback. They were not recorded in the outer-start snapshot.",
                             "python_interpreter_scope": "Absolute interpreter path is recorded. Its current hash is reported; the interpreter binary was not hash-bound by the outer-start snapshot."},
        "mail_continuity": mail,
        "auditor": {"path": str(Path(__file__).resolve()), "sha256": file_hash(__file__)},
        "github_actions_queried_or_awaited": False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--head", required=True)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output = args.output.resolve()
    require(not args.output.exists(), "Use a new audit output; preserve earlier audits")
    require(not args.output.is_relative_to(args.repo.resolve()), "Audit output must be outside repo")
    try:
        result = audit(args)
    except Exception as error:
        result = {"accepted": False, "audited_at_utc": datetime.now(timezone.utc).isoformat(),
                  "source_commit": args.head, "error": repr(error),
                  "auditor": {"path": str(Path(__file__).resolve()), "sha256": file_hash(__file__)}}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"accepted": result["accepted"], "error": result.get("error"), "output": str(args.output)}, indent=2))
    return 0 if result["accepted"] else 1


if __name__ == "__main__":
    sys.exit(main())
