---
license: other
license_name: mpl-1.1
license_link: https://www.mozilla.org/en-US/MPL/1.1/
language:
- ar
tags:
- hunspell
- spellchecking
- arabic
---

# AyaSpell Arabic dictionary for Hunspell

The AyaSpell Arabic spelling dictionary (`ar.aff`, `ar.dic`) and Arabic
thesaurus (`th_ar.dat`, MyThes format), byte-identical to the
[LibreOffice dictionaries packaging](https://github.com/LibreOffice/dictionaries/tree/951bb429a4d846699b02e7adb4fc6fca128c6bae/ar)
at commit `951bb429a4d846699b02e7adb4fc6fca128c6bae` (AyaSpell 3.5 package). Upstream project:
[AyaSpell](http://ayaspell.sourceforge.net/) /
[linuxscout/ayaspell](https://github.com/linuxscout/ayaspell).

Authors: Mohamed Kebdani (dictionary, 2006–2008), Taha Zerrouki (thesaurus
and project, 2006–2009); OpenOffice packaging by Ahmad Farghal. See
`AUTHORS.txt` and `README_ar.txt`.

## Licence

The original files are offered under a GPL 2.0 / LGPL 2.1 / MPL 1.1
tri-licence, each "or later" (`COPYING.txt`). This distribution is provided
under the **Mozilla Public License 1.1** (`MPL-1.1.txt`); the other two
options remain available to recipients as stated in `COPYING.txt`. The files
are unmodified; their source form is this repository.

## Use

Load with any Hunspell-compatible engine, e.g. `hunspell -d ar`. Quds Office
downloads this bundle on the user's request; it is not part of the
application. `manifest.json` lists the SHA-256 of every file.
