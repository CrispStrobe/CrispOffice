#!/usr/bin/env python3
"""Bind fresh continuation fixtures without changing original restore provenance."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess

BASE = Path(__file__).resolve().parents[1]
REPO = BASE / "quds_office_suite"
RUNTIME = BASE / "runtime"
FIXTURES = BASE / "fixtures"


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main():
    original = RUNTIME / "runtime-restore-original.json"
    receipt_path = RUNTIME / "runtime.json"
    if original.exists():
        raise RuntimeError("Original restore receipt already preserved; do not rebind silently.")
    original.write_bytes(receipt_path.read_bytes())
    receipt = json.loads(original.read_text())
    assert receipt["status"] == "ready"
    fixture_plan = json.loads((REPO / "docs/validation/office-main-sync-20261119/main-delta-v4/fixture-plan.json").read_text())
    bound = {}

    def add(path):
        path = Path(path).absolute()
        if not path.is_file():
            raise RuntimeError("Missing fixture input: " + str(path))
        bound[str(path)] = digest(path)

    for name, expected in fixture_plan["files"].items():
        path = FIXTURES / "hunspell" / name
        assert path.stat().st_size == expected["bytes"]
        assert digest(path) == expected["sha256"]
        add(path)
    for name, expected in fixture_plan["source_bindings"].items():
        path = REPO / name
        assert digest(path) == expected, name
        add(path)
    for path in (FIXTURES / "hunspell").glob("*.json"):
        add(path)
    for path in (FIXTURES / "hunspell/native").glob("*.so"):
        add(path)
    for name in ("test/fixtures/lifecycle_hunspell.cpp", "test/support/lifecycle_library.cpp"):
        add(REPO / "packages/quds_proofing_hunspell" / name)

    morph = FIXTURES / "arabic-morph"
    download = json.loads((morph / "fixture-download-receipt.json").read_text())
    for entry in download["files"]:
        path = morph / "bundle" / entry["file"]
        assert path.stat().st_size == entry["bytes"]
        assert digest(path) == entry["sha256"]
        add(path)
    build = json.loads((morph / "build-receipt.json").read_text())
    for name, expected in build["files"].items():
        path = morph / name
        assert digest(path) == expected
        add(path)
    for path in (morph / "source").rglob("*"):
        if path.is_file():
            add(path)
    for path in morph.glob("*.json"):
        add(path)
    add(morph / "build.log")
    for name in ("tool/build.py", "native/CMakeLists.txt", "native/src/quds_arabic_morph.cpp", "lib/src/morph_catalog.dart", "licenses/manifest.json"):
        add(REPO / "packages/quds_arabic_morph" / name)
    for path in (REPO / "packages/quds_arabic_morph/licenses").rglob("*"):
        if path.is_file():
            add(path)

    environment = {}
    for line in (FIXTURES / "env.sh").read_text().splitlines():
        assert line.startswith("export ")
        key, value = line[7:].split("=", 1)
        words = shlex.split(value)
        assert len(words) == 1
        environment[key] = words[0]
    environment_receipt = {
        "at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Exact inherited test environment; path inputs and literal live-download flags. No application tests claimed.",
        "environment": environment,
        "script": str(FIXTURES / "env.sh"),
        "script_sha256": digest(FIXTURES / "env.sh"),
    }
    write(RUNTIME / "fixture-environment.json", environment_receipt)
    add(FIXTURES / "env.sh")
    add(RUNTIME / "fixture-environment.json")
    add(original)
    add(Path(__file__))

    tools = {}
    for name, executable in {
        "cmake": FIXTURES / "build-tools/cmake/data/bin/cmake",
        "c++": Path(shutil.which("g++")),
        "cc": Path(shutil.which("gcc")),
        "make": Path(shutil.which("make")),
    }.items():
        tools[name] = {"path": str(executable), "resolved_path": str(executable.resolve()), "sha256": digest(executable), "version": subprocess.check_output([str(executable), "--version"], text=True).splitlines()[0]}
        add(executable)
        add(executable.resolve())

    addendum = {
        "at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Fresh continuation fixture/build-source binding. Original successful SDK restore receipt retained unchanged; historical fixture provenance retains its original paths and timestamps. No baseline test result is relabeled.",
        "original_restore_receipt": str(original),
        "original_restore_sha256": digest(original),
        "environment_receipt": str(RUNTIME / "fixture-environment.json"),
        "toolchain": tools,
        "morph_build_command": ["python3", "packages/quds_arabic_morph/tool/build.py", "--native", "--jobs", "2", "--output", str(morph)],
        "morph_cmake_path_prefix": str(FIXTURES / "build-tools/cmake/data/bin"),
        "morph_build_exit_code": 0,
        "morph_build_note": "The retained original build log includes nonfatal make warnings that default /tmp is absent; compilation and output hash validation completed successfully.",
        "fixture_inputs": bound,
    }
    addendum_path = RUNTIME / "runtime-fixture-addendum.json"
    write(addendum_path, addendum)
    add(addendum_path)
    receipt.setdefault("additional_inputs", {}).update(bound)
    receipt["fixture_input_binding"] = {
        "at_utc": datetime.now(timezone.utc).isoformat(),
        "implementation": str(Path(__file__).resolve()),
        "implementation_sha256": digest(__file__),
        "addendum": str(addendum_path),
        "addendum_sha256": digest(addendum_path),
        "added_inputs": len(bound),
        "original_restore_receipt": str(original),
        "original_restore_sha256": digest(original),
        "environment": environment,
    }
    write(receipt_path, receipt)
    for name, expected in receipt["additional_inputs"].items():
        assert digest(name) == expected, name
    print(json.dumps({"status": "ready", "runtime_receipt": str(receipt_path), "additional_input_count": len(receipt["additional_inputs"]), "new_fixture_bindings": len(bound), "environment": environment}, indent=2))


if __name__ == "__main__":
    main()
