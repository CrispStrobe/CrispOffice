#!/usr/bin/env python3
"""Map the final broad-run positives to earlier paired controls and new suites."""
from pathlib import Path
import gzip
import hashlib
import json
from urllib.parse import unquote, urlparse


BASE = Path(__file__).resolve().parent.parent
RUN = BASE / 'runtime-work/qualification/run-4c49b043-1'
REPO = BASE / 'quds'
ENGINE = REPO / 'packages/quds_office_engine'
SOURCE = '4c49b0435bc6611221bc49b58b15e735059467ff'


def events(raw):
    result = []
    for line in raw.decode().splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if isinstance(event, dict) and 'type' in event:
            result.append(event)
    return result


def outcomes(raw):
    parsed = events(raw)
    starts = {event['test']['id']: event['test'] for event in parsed if event['type'] == 'testStart'}
    suites = {event['suite']['id']: event['suite'] for event in parsed if event['type'] == 'suite'}
    rows = []
    for event in parsed:
        if event['type'] != 'testDone' or event.get('hidden'):
            continue
        test = starts[event['testID']]
        rows.append({'name': test['name'], 'suite': suites[test['suiteID']]['path'], 'result': event['result'], 'skipped': event.get('skipped', False)})
    return rows


def main():
    receipt = json.loads((RUN / 'receipt.json').read_text())
    assert receipt['all_passed'] and receipt['source_commit'] == SOURCE
    raw = gzip.decompress((RUN / 'engine-integration/stdout.gz').read_bytes())
    final_rows = outcomes(raw)
    suites = {}
    for row in final_rows:
        parsed = urlparse(row['suite'])
        path = Path(unquote(parsed.path) if parsed.scheme == 'file' else row['suite']).resolve()
        relative = str(path.relative_to(ENGINE))
        suites.setdefault(relative, []).append(row)
    source_map = json.loads((RUN / 'source-before.json').read_text())['files']
    control_specs = [
        ('annotation', 'test/odf_annotation_extraction_test.dart', BASE / 'canonical-controls/evidence/annotation-positive/stdout.log', 11),
        ('comment-note', 'test/odt_note_fidelity_test.dart', BASE / 'canonical-controls/evidence/note-positive/stdout.log', 2),
        ('paragraph-decoration', 'test/odt_paragraph_decoration_test.dart', BASE / 'canonical-amendment-control/evidence/positive/stdout.log', 2),
    ]
    controls = []
    for name, path, old_log, expected_count in control_specs:
        old = outcomes(old_log.read_bytes())
        assert len(old) == expected_count and all(row['result'] == 'success' and not row['skipped'] for row in old)
        names = {row['name'] for row in old}
        matched = [row for row in suites[path] if row['name'] in names]
        assert len(matched) == len(names) == expected_count
        assert all(row['result'] == 'success' and not row['skipped'] for row in matched)
        controls.append({'control': name, 'final_suite': path, 'matched_successful_cases': sorted(names), 'matched_case_count': expected_count, 'source_input': source_map['packages/quds_office_engine/' + path], 'original_positive_log_sha256': hashlib.sha256(old_log.read_bytes()).hexdigest()})
    selected = [
        'test/odf_frame_extraction_test.dart',
        'test/odt_section_integration_test.dart',
        'test/proofing/german_lexical_gap_test.dart',
        'test/proofing/german_spelling_quotes_test.dart',
        'test/odt_section_fidelity_test.dart',
        'test/odt_section_continuation_test.dart',
        'test/odt_paragraph_decoration_test.dart',
        'test/odt_document_writer_test.dart',
    ]
    plan = json.loads((RUN / 'plan.json').read_text())
    plan_paths = set(plan['cohorts']['engine-integration']['tests'])
    suite_rows = []
    for path in selected:
        assert path in plan_paths
        observed = suites[path]
        assert observed and all(row['result'] == 'success' and not row['skipped'] for row in observed)
        suite_rows.append({'path': path, 'substantive_successes': len(observed), 'source_input': source_map['packages/quds_office_engine/' + path], 'case_names': [row['name'] for row in observed]})
    identity = json.loads((BASE / 'canonical-review/control-test-identity.json').read_text())
    table = json.loads((BASE / 'canonical-review/table-test-identity.json').read_text())
    assert identity['final_source'] == table['final_source'] == SOURCE
    for row in identity['files']:
        assert row['final_blob'] == source_map[row['path']]['git_blob']
        assert row['final_sha256'] == source_map[row['path']]['sha256']
    assert table['final_test_blob'] == source_map[table['source_file']]['git_blob']
    result = {'accepted': True, 'source_commit': SOURCE, 'final_engine_stdout_sha256': hashlib.sha256(raw).hexdigest(), 'controls': controls, 'new_and_preserved_suites': suite_rows, 'control_test_identity': identity, 'table_test_identity': table, 'test_execution_performed': False, 'method': 'Independent completed-log recount and exact recorded source-input comparison. No new tests were run.'}
    output = BASE / 'canonical-review/final-positive-coverage.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'accepted': True, 'paired_control_cases_passed_on_final_source': sum(row['matched_case_count'] for row in controls), 'suite_successes': {row['path']: row['substantive_successes'] for row in suite_rows}, 'output': str(output)}, indent=2))


if __name__ == '__main__':
    main()
