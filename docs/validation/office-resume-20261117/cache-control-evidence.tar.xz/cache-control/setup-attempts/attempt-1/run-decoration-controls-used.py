#!/usr/bin/env python3
"""Paired regression for ODT paragraph decoration style-cache identity."""
from pathlib import Path
import collections,datetime,gzip,hashlib,json,os,shutil,subprocess,time
BASE=Path(__file__).resolve().parent
REPO=BASE.parent/'quds'
PREVIOUS=BASE.parent/'canonical-controls'
DART=Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/flutter-sdk/bin/cache/dart-sdk/bin/dart')
ENGINE='packages/quds_office_engine'
WRITER=ENGINE+'/lib/src/word/serial/odt_document_writer.dart'
TEST=ENGINE+'/test/odt_paragraph_decoration_test.dart'
INCOMING='7cf48a2f7b73aafb8bd2019bda4e0ddc6698f9ad'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def snapshot(ws):
 return {str(p.relative_to(ws)):{'sha256':sha(p),'git_blob':blob(p.read_bytes())}for p in sorted(ws.rglob('*'))if p.is_file()and'.dart_tool'not in p.parts and'build'not in p.parts}
def parse(path):
 starts={};ends={};errors=[];done=[]
 for line in path.read_text().splitlines():
  try:e=json.loads(line)
  except json.JSONDecodeError:continue
  if e.get('type')=='testStart':starts[e['test']['id']]=e['test']
  elif e.get('type')=='testDone'and not e.get('hidden'):ends[e['testID']]=e
  elif e.get('type')=='error':errors.append(e)
  elif e.get('type')=='done':done.append(e)
 tests=[{'name':starts[k]['name'],'result':v['result'],'skipped':v.get('skipped',False)}for k,v in ends.items()]
 return {'tests':tests,'counts':dict(collections.Counter(t['result']for t in tests)),'errors':errors,'done':done}
def main():
 ev=BASE/'evidence';ev.mkdir(exist_ok=True)
 paths={}
 source_tests=(REPO/TEST).read_bytes();positive_writer=(REPO/WRITER).read_bytes()
 negative_writer=subprocess.check_output(['git','-C',str(REPO),'show',INCOMING+':'+WRITER])
 assert negative_writer==(BASE/'incoming-odt-writer.dart').read_bytes()
 dep_inputs=json.loads(gzip.decompress((PREVIOUS/'evidence/dependency-inputs.json.gz').read_bytes()))
 assert all(sha(Path(p))==expected for p,expected in dep_inputs.items())
 runtime=json.loads((PREVIOUS/'evidence/summary.json').read_text())['runtime']
 assert all(sha(Path(p))==expected for p,expected in runtime.items())
 maps={};graphs={}
 for label,writer in [('positive',positive_writer),('negative',negative_writer)]:
  ws=BASE/'workspaces'/label;assert not ws.exists();shutil.copytree(PREVIOUS/'workspaces/positive',ws)
  (ws/WRITER).write_bytes(writer);(ws/TEST).write_bytes(source_tests)
  maps[label]=snapshot(ws);graphs[label]=sha(ws/'.dart_tool/package_config.json');paths[label]=ws
  (ev/(label+'-writer.dart')).write_bytes(writer)
 (ev/'odt_paragraph_decoration_test.dart').write_bytes(source_tests)
 changed=[p for p in maps['positive']if maps['positive'][p]!=maps['negative'][p]];assert changed==[WRITER],changed
 assert all(maps[x]['pubspec.lock']['sha256']=='344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130'for x in maps)
 with gzip.open(ev/'source-bindings.json.gz','wt')as f:json.dump(maps,f,indent=2,sort_keys=True)
 shutil.copy2(PREVIOUS/'evidence/dependency-inputs.json.gz',ev/'dependency-inputs.json.gz')
 records={}
 for label,ws in paths.items():
  out=ev/label;out.mkdir()
  command=[str(DART),'test','--reporter','json','--concurrency=1','test/odt_paragraph_decoration_test.dart']
  start=time.monotonic();began=datetime.datetime.now(datetime.timezone.utc).isoformat()
  env=dict(os.environ,FLUTTER_ROOT=str(DART.parents[3]),PUB_CACHE=str(DART.parents[4]/'pub-cache'),CI='true',DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true')
  with(out/'stdout.log').open('wb')as stdout,(out/'stderr.log').open('wb')as stderr:
   p=subprocess.run(command,cwd=ws/ENGINE,env=env,stdout=stdout,stderr=stderr,timeout=120)
  rec={'command':command,'cwd':str(ws/ENGINE),'exit_code':p.returncode,'started_at':began,'duration_seconds':round(time.monotonic()-start,3),'stdout_sha256':sha(out/'stdout.log'),'stderr_sha256':sha(out/'stderr.log'),'summary':parse(out/'stdout.log')}
  save(out/'receipt.json',rec);records[label]=rec
  print(json.dumps({'case':label,'exit_code':p.returncode,'counts':rec['summary']['counts']}),flush=True)
 stable=all(snapshot(paths[x])==maps[x]and sha(paths[x]/'.dart_tool/package_config.json')==graphs[x]for x in maps)
 dep_stable=all(sha(Path(p))==expected for p,expected in dep_inputs.items())
 runtime_stable=all(sha(Path(p))==expected for p,expected in runtime.items())
 assert records['positive']['exit_code']==0 and records['positive']['summary']['counts']=={'success':2}
 assert records['negative']['exit_code']==1 and records['negative']['summary']['counts']=={'failure':2}
 assert all(e['isFailure']and'Expected:'in e['error']for e in records['negative']['summary']['errors'])
 assert {t['name']for t in records['positive']['summary']['tests']}=={t['name']for t in records['negative']['summary']['tests']}
 assert all(not t['skipped']for r in records.values()for t in r['summary']['tests'])
 assert stable and dep_stable and runtime_stable
 report={'accepted':True,'supporting_source':'b32dee6f1fb6993c928a466b553226209cf27fb8','incoming_writer_ref':INCOMING,'incoming_writer_blob':blob(negative_writer),'corrected_writer_blob':blob(positive_writer),'test_blob':blob(source_tests),'test_sha256':hashlib.sha256(source_tests).hexdigest(),'changed_variant_inputs':changed,'source_inputs_per_variant':len(maps['positive']),'inputs_unchanged':stable,'external_dependency_files':len(dep_inputs),'dependencies_unchanged':dep_stable,'runtime':runtime,'runtime_unchanged':runtime_stable,'package_count':108,'results':records,'assertions':'Every paragraph retains its own shading/border color and no unintended other decoration; absent colors stay absent; equivalent case-normalized colors and null/empty absence reuse styles; text and model property values are unchanged.','runner_sha256':sha(Path(__file__)),'test_execution_finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 save(ev/'summary.json',report);shutil.copy2(__file__,ev/'run-decoration-controls.py')
 print(json.dumps({'accepted':True,'summary':str(ev/'summary.json'),'source_inputs_per_variant':len(maps['positive'])}),flush=True)
if __name__=='__main__':main()
