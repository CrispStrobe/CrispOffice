# ODT paragraph decoration cache paired control

The same final regression file runs against two otherwise identical isolated
399-file workspaces. Supporting engine/parser source comes from immutable
b32dee6f1fb6993c928a466b553226209cf27fb8; workspace manifests, inherited test
fixtures and the unchanged 108-package lock come from the earlier control
workspace described by its complete input map. The only between-variant source
difference is the ODT writer: exact destination-main
7cf48a2f7b73aafb8bd2019bda4e0ddc6698f9ad versus the cache correction in this
amendment. Full source bindings, package graphs, source snapshots, commands,
stdout/stderr, runtime hashes and 5,099 dependency hashes are retained.

The corrected writer passes both tests. The incoming writer fails both by
matcher assertion: the neutral leading paragraph populates the old shared style
with no decoration, so the next paragraph emits no red border/fill. The expected
red values are `0.5pt solid #ff0000` and `#ff0000`; actual values are null. Positive
execution continues through red, green, equivalent lower-case red, null and empty
colors, verifying independent serialized colors, equivalent-style reuse, no
unintended other decoration, unchanged paragraph text and unchanged model values.
The leading paragraph is checked and omitted from color assertions so the reuse
oracle does not depend on section-start activation behavior.

The accepted execution contains two substantive passes and two expected matcher
failures, zero skips and zero load errors. All source, package-graph, runtime and
dependency bytes were unchanged after execution. The runner uses explicit SDK,
pub-cache and writable scratch TMPDIR paths with analytics disabled; its exact
code is included. The final regression was formatted at Dart language version
3.12, then byte-checked against the evidence snapshot before packaging.

Two earlier setup attempts are preserved under `setup-attempts`, including their
used scripts and full test-command logs. Attempt 1 used incorrect SDK/cache
parent paths and exited 65 before test loading. Attempt 2 fixed those paths but
omitted a scratch TMPDIR; this container has no /tmp, so both loaders exited255.
Neither preparation attempt is counted as a negative control or substantive test.
No tests were altered to accept those setup failures.
