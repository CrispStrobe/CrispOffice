# Paired annotation and note ownership controls

These fresh local controls bind final production source
`b32dee6f1fb6993c928a466b553226209cf27fb8` to the exact historical test files
from `555eb728ce3ea872cb5ceb3e5fd2104b21f932aa`. They use isolated copies of
the engine/parser libraries and the unchanged original 108-package workspace
lock. They do not modify the main checkout or its validation workspace.

| Experiment | Result |
| --- | --- |
| Final source, original annotation tests | 11 passed |
| Old annotation readers over final supporting source | 6 assertion failures, 1 content-limit exception, 4 passed |
| Final source, original note/comment ownership tests | 2 passed |
| Old note writer over final supporting source | 2 assertion failures |

No test was skipped and no suite failed to compile or load. Each positive and
negative pair uses identical test names and test bytes. The counts overlap
the broad regression suites and are not an additional unique-test total.

The annotation negative variant replaces only `odf_text.dart`,
`office_text_extractor.dart` and `office_search_text.dart` with their versions
from `3458c8977cef969a86a07b39734c761ba62e4b40`. The note negative variant
replaces only `odt_document_writer.dart` with its version from
`c21a1549a612bb04fcd071a50d12c28f31343d11`. Every other copied source input is
identical to the positive workspace. `source-bindings.json.gz` records all
398 source, test and manifest inputs per variant, including Git blob IDs,
modes and SHA-256 hashes. `dependency-inputs.json.gz` records 5,099 external
dependency files. Their bytes and all recorded runtime inputs remained
unchanged.

## Retained initial wrapper failure

`summary.json` is the unmodified first runner summary. Its generic acceptance
gate assumed that every negative failure would be a matcher assertion and
therefore exited with status 1. The hidden-text budget regression instead
raises `FormatException: ODF text exceeds the content limit.` on the old
reader. That fixture places an enormous space-count run inside an annotation
and expects the visible text `A`; expanding or charging the hidden run is
precisely the behavior the regression rejects.

`verification.json` is the accepted, narrowly reviewed result. The verifier
recounted the original JSON logs, required the exact exception, test name and
source stack, kept that exception separate from the six matcher failures,
checked identical paired test names, and read back every live input. No
test was changed or rerun to obtain this result. Both scripts and all original
command receipts, stdout and stderr remain included.

The source checkout's dirty flag in the original summary is also retained.
The separate broad runner was applying four test-only formatter corrections
at that time. These controls use immutable Git blobs copied into independent
workspaces; their source and tests did not depend on those live files.

## Reproduction

`run-controls.py` is the exact runner used. Place it in a new control directory
beside a `quds` checkout at the recorded source commit and restore the pinned
Flutter 3.47.8 / Dart 3.13.7 installation and package cache indicated by the
runner. It creates the three isolated workspaces and runs locked offline
dependency resolution and all four commands. Its original blanket assertion
gate exits 1 for the documented negative budget exception. Retain that exit,
then validate the original logs with:

```sh
python3 verify-control-logs.py --evidence evidence --workspaces workspaces
```

The optional `--workspaces` argument enables live source/dependency/runtime
readback. The log verifier itself needs only the retained evidence directory.
No GitHub Actions, workflow, check-run or CI-status endpoint is used.
