#!/usr/bin/env python3
"""Verify the retained control logs, including the exact expected budget exception."""
from pathlib import Path
import argparse,collections,datetime,gzip,hashlib,json,subprocess
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def parse(path):
 tests={};terminal=[];errors=[];ends={}
 for line in path.read_text().splitlines():
  try:e=json.loads(line)
  except json.JSONDecodeError:continue
  if e.get('type')=='testStart':tests[e['test']['id']]=e['test']
  elif e.get('type')=='testDone'and not e.get('hidden'):ends[e['testID']]=e
  elif e.get('type')=='error':errors.append(e)
  elif e.get('type')=='done':terminal.append(e)
 rows=[{'id':k,'name':tests[k]['name'],'result':v['result'],'skipped':v.get('skipped',False)}for k,v in ends.items()]
 return {'tests':rows,'counts':dict(collections.Counter(r['result']for r in rows)),'terminal':terminal,'errors':errors}
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--evidence',type=Path,required=True);parser.add_argument('--workspaces',type=Path);args=parser.parse_args()
 base=args.evidence.resolve();initial=json.loads((base/'summary.json').read_text());results={}
 expected={'annotation-positive':{'success':11},'annotation-negative':{'success':4,'failure':6,'error':1},'note-positive':{'success':2},'note-negative':{'failure':2}}
 for name,counts in expected.items():
  record=json.loads((base/name/'command.json').read_text());data=parse(base/name/'stdout.log')
  assert sha(base/name/'stdout.log')==record['stdout_sha256']
  assert sha(base/name/'stderr.log')==record['stderr_sha256']
  assert data['counts']==counts,(name,data['counts'])
  assert len(data['terminal'])==1
  assert data['terminal'][0]['success']==name.endswith('positive')
  assert record['exit_code']==(0 if name.endswith('positive')else 1)
  assert not any(t['skipped']for t in data['tests'])
  assert not any('loading 'in t['name']for t in data['tests'])
  results[name]=data
 for prefix in ['annotation','note']:
  a={t['name']for t in results[prefix+'-positive']['tests']};b={t['name']for t in results[prefix+'-negative']['tests']};assert a==b
 known_name='hidden annotation text is neither expanded nor charged to output'
 known_message='FormatException: ODF text exceeds the content limit.'
 annotation=results['annotation-negative'];by_id={t['id']:t for t in annotation['tests']}
 runtime_errors=[e for e in annotation['errors']if not e['isFailure']]
 assert len(runtime_errors)==1
 event=runtime_errors[0]
 assert by_id[event['testID']]['name']==known_name
 assert event['error']==known_message
 assert 'OfficeTextExtractor._odf'in event['stackTrace']and'test/odf_annotation_extraction_test.dart 190:29'in event['stackTrace']
 assertion_errors=[e for e in annotation['errors']if e['isFailure']]
 assert len(assertion_errors)==6 and all('Expected:'in e['error']for e in assertion_errors)
 assert all(e['isFailure']and'Expected: empty'in e['error']and'test/odt_note_fidelity_test.dart 490:7'in e['stackTrace']for e in results['note-negative']['errors'])
 assert len(results['note-negative']['errors'])==2
 assert not results['annotation-positive']['errors']and not results['note-positive']['errors']
 assert all(initial[k]for k in ['inputs_unchanged','dependencies_unchanged','runtime_unchanged','source_checkout_head_unchanged','no_load_failures'])
 assert initial['accepted']is False and initial['negative_errors_are_assertion_failures']is False
 assert all(initial['expected_outcomes'].values())
 bindings=json.loads(gzip.decompress((base/'source-bindings.json.gz').read_bytes()))
 deps=json.loads(gzip.decompress((base/'dependency-inputs.json.gz').read_bytes()))
 assert len(deps)==initial['dependency_file_count']==5099
 source_sets={k:set(v['files'])for k,v in bindings.items()};assert len({tuple(sorted(x))for x in source_sets.values()})==1
 current_inputs=None
 if args.workspaces:
  current_inputs=[]
  for label,binding in bindings.items():
   root=args.workspaces.resolve()/label
   for path,identity in binding['files'].items():
    assert sha(root/path)==identity['sha256'],(label,path)
   assert sha(root/'pubspec.lock')==initial['lock_sha256']
   assert sha(root/'.dart_tool/package_config.json')==binding['package_config_sha256']
   current_inputs.append({'variant':label,'files':len(binding['files']),'unchanged':True})
  assert all(sha(Path(path))==value for path,value in deps.items())
  assert all(sha(Path(path))==value for path,value in initial['runtime'].items())
 report={'schema_version':1,'accepted':True,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'test_execution_repeated':False,'source_commit':initial['source_commit'],'source_tree':initial['source_tree'],'test_commit':initial['test_commit'],'scope':initial['scope'],'initial_wrapper_summary':'summary.json','initial_wrapper_summary_sha256':sha(base/'summary.json'),'original_wrapper_failure':'The generic verifier required every negative test error to be an assertion. The historical hidden-annotation budget case instead raises the exact ODF output-limit FormatException; raw logs and the failed summary remain unchanged.','negative_exception_review':{'test':known_name,'message':known_message,'reason':'The fixture places a huge space-count run inside an ODF annotation and expects only visible A. The baseline expands/charges that hidden run and raises its content limit. The identical case passes against final source. This is recorded as one production exception, separately from the six assertion failures.','stack_trace':event['stackTrace']},'results':{k:{'counts':v['counts'],'tests':v['tests'],'terminal_success':v['terminal'][0]['success']}for k,v in results.items()},'paired_test_names_identical':True,'no_skips_or_load_failures':True,'source_test_and_manifest_files_per_variant':len(bindings['positive']['files']),'dependency_files':len(deps),'inputs_and_runtime_unchanged':True,'live_readback':current_inputs,'source_checkout_note':'The independent broad runner was applying four test-only formatter repairs when this controls run ended. Controls use copied immutable git blobs, not the live checkout. The observed dirty-checkout field is retained and is not treated as a control-input change.','verifier_sha256':sha(Path(__file__)),'evidence_hashes':{str(p.relative_to(base)):sha(p)for p in sorted(base.rglob('*'))if p.is_file()and p.name not in ['verification.json']}}
 (base/'verification.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'accepted':report['accepted'],'tests':report['results'],'input_files_per_variant':report['source_test_and_manifest_files_per_variant'],'dependency_files':report['dependency_files']},indent=2))
if __name__=='__main__':main()
