#!/usr/bin/env python3
"""Run paired historical annotation/note controls in fully isolated workspaces."""
from pathlib import Path
import collections,datetime,gzip,hashlib,io,json,os,shutil,subprocess,tarfile,time
from urllib.parse import urljoin,urlparse,unquote
import yaml

BASE=Path(__file__).resolve().parent
REPO=BASE.parent/'quds'
SDK=Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/flutter-sdk')
CACHE=SDK.parent/'pub-cache'
DART=SDK/'bin/cache/dart-sdk/bin/dart'
SOURCE='b32dee6f1fb6993c928a466b553226209cf27fb8'
TEST_REF='555eb728ce3ea872cb5ceb3e5fd2104b21f932aa'
LOCK_PATH='docs/validation/proofing-20261116/integration-resume/workspace-pubspec.lock'
LOCK_SHA='344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130'
ENGINE='packages/quds_office_engine'
TESTS=['odf_annotation_extraction_test.dart','odt_note_fidelity_test.dart']
NOTE_FILTER='(footnote|endnote) references in comments cannot consume visible note bodies'
OVERLAYS={
 'annotation-negative':{'ref':'3458c8977cef969a86a07b39734c761ba62e4b40','paths':[ENGINE+'/lib/src/odf/odf_text.dart',ENGINE+'/lib/src/extract/office_text_extractor.dart',ENGINE+'/lib/src/extract/office_search_text.dart']},
 'note-negative':{'ref':'c21a1549a612bb04fcd071a50d12c28f31343d11','paths':[ENGINE+'/lib/src/word/serial/odt_document_writer.dart']}
}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(data):return hashlib.sha256(data).hexdigest()
def sha(path):return digest(path.read_bytes())
def save(path,obj):path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def get(ref,path):return git('show',ref+':'+path)
def git_blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def entries(ref):
 d={}
 for row in git('ls-tree','-rz',ref).split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);mode,kind,blob=meta.decode().split()
  if kind=='blob':d[path.decode()]={'mode':mode,'blob':blob}
 return d
def capture(paths,workspace):
 return {str(p.relative_to(workspace)):{'sha256':sha(p),'git_blob':git_blob(p.read_bytes()),'mode':'100755'if p.stat().st_mode&0o111 else'100644'}for p in sorted(paths)}
def write_blob(workspace,ref,relative):
 p=workspace/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(get(ref,relative));return p
def run(label,command,cwd,env):
 out=BASE/'evidence'/label;out.mkdir(parents=True,exist_ok=False)
 begin=now();start=time.monotonic()
 with (out/'stdout.log').open('wb')as stdout,(out/'stderr.log').open('wb')as stderr:
  proc=subprocess.Popen(command,cwd=cwd,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  while proc.poll()is None:
   try:proc.wait(timeout=15)
   except subprocess.TimeoutExpired:print(json.dumps({'running':label,'elapsed_seconds':round(time.monotonic()-start)}),flush=True)
   if time.monotonic()-start>300:
    proc.terminate();proc.wait(timeout=10);raise RuntimeError('Control timeout: '+label)
 record={'label':label,'command':list(map(str,command)),'cwd':str(cwd),'started_at':begin,'finished_at':now(),'exit_code':proc.returncode,'duration_seconds':round(time.monotonic()-start,3),'stdout_sha256':sha(out/'stdout.log'),'stderr_sha256':sha(out/'stderr.log')}
 save(out/'command.json',record)
 print(json.dumps({'completed':label,'exit_code':proc.returncode}),flush=True)
 return record
def local_graph_check(workspace):
 p=workspace/'.dart_tool/package_config.json';graph=json.loads(p.read_text());local=[]
 for package in graph['packages']:
  root=Path(unquote(urlparse(urljoin(p.as_uri(),package['rootUri'])).path)).resolve()
  if package['name'].startswith('quds_')or package['name']=='legacy_doc_parser':
   assert root.is_relative_to(workspace), (package['name'],str(root),str(workspace))
   local.append(package['name'])
 assert len(graph['packages'])==108,len(graph['packages'])
 return graph,local
def snapshot_dependencies(graph,config,workspace):
 result={}
 for package in graph['packages']:
  root=Path(unquote(urlparse(urljoin(config.as_uri(),package['rootUri'])).path)).resolve()
  if root.is_relative_to(workspace):continue
  paths={root/n for n in ('pubspec.yaml','pubspec.lock','analysis_options.yaml')}
  for directory in ('lib','bin','assets'):paths.update(p for p in (root/directory).rglob('*')if p.is_file())
  for p in sorted(paths):
   if p.is_file():result[str(p)]=sha(p)
 return result
def parse(label):
 path=BASE/'evidence'/label/'stdout.log';tests={};done={};errors=[];terminal=[]
 for line in path.read_text().splitlines():
  try:event=json.loads(line)
  except json.JSONDecodeError:continue
  kind=event.get('type')
  if kind=='testStart':tests[event['test']['id']]=event['test']
  if kind=='testDone':done[event['testID']]=event
  if kind=='error':errors.append(event)
  if kind=='done':terminal.append(event)
 rows=[]
 for tid,event in done.items():
  if event.get('hidden'):continue
  rows.append({'id':tid,'name':tests.get(tid,{}).get('name'),'result':event['result'],'skipped':event.get('skipped',False)})
 summary={'tests':rows,'counts':dict(collections.Counter(r['result'] for r in rows)),'skips':sum(bool(r['skipped'])for r in rows),'terminal':terminal,'errors':errors}
 save(BASE/'evidence'/label/'test-summary.json',summary);return summary

def main():
 assert git('rev-parse','HEAD').decode().strip()==SOURCE
 assert not git('status','--porcelain').decode().strip()
 assert sha(DART)=='01e869e4af277734b02ab8898b870c6b00c9bec61bbcf9c923cd14de7ed85fbb'
 (BASE/'evidence').mkdir(exist_ok=True)
 workspace=BASE/'workspaces'/'positive'
 assert not workspace.exists()
 workspace.mkdir(parents=True)
 manifest=get(TEST_REF,'pubspec.yaml');members=yaml.safe_load(manifest)['workspace']
 manifests=['pubspec.yaml','analysis_options.yaml']+[p+'/pubspec.yaml'for p in members]
 for p in manifests:write_blob(workspace,TEST_REF,p)
 archive=git('archive',SOURCE,ENGINE+'/lib','packages/legacy_doc_parser/lib')
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:')as tar:tar.extractall(workspace,filter='data')
 for test in TESTS:write_blob(workspace,TEST_REF,ENGINE+'/test/'+test)
 lock=get(TEST_REF,LOCK_PATH);assert digest(lock)==LOCK_SHA;(workspace/'pubspec.lock').write_bytes(lock)
 env=dict(os.environ,FLUTTER_ROOT=str(SDK),PUB_CACHE=str(CACHE),TMPDIR=str(BASE/'tmp'),XDG_CONFIG_HOME=str(BASE/'config'),CI='true',DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true')
 for p in ['tmp','config']:(BASE/p).mkdir(exist_ok=True)
 setup=run('setup',[str(DART),str(SDK/'bin/cache/flutter_tools.snapshot'),'pub','get','--offline','--enforce-lockfile'],workspace,env)
 assert setup['exit_code']==0
 assert sha(workspace/'pubspec.lock')==LOCK_SHA
 graph,locals_=local_graph_check(workspace)
 input_paths=[p for p in workspace.rglob('*')if p.is_file()and '.dart_tool'not in p.parts and 'build'not in p.parts]
 before=capture(input_paths,workspace)
 source_entries=entries(SOURCE);test_entries=entries(TEST_REF)
 for path,row in before.items():
  if path=='pubspec.lock':continue
  expected=test_entries[path]if path in manifests or path.startswith(ENGINE+'/test/')else source_entries[path]
  assert row['git_blob']==expected['blob']and row['mode']==expected['mode'],path
 deps=snapshot_dependencies(graph,workspace/'.dart_tool/package_config.json',workspace)
 with gzip.open(BASE/'evidence/dependency-inputs.json.gz','wt')as f:json.dump(deps,f,sort_keys=True)
 runtime_paths=[DART,SDK/'bin/cache/dart-sdk/bin/dartaotruntime',SDK/'bin/cache/dart-sdk/bin/snapshots/dartdev_aot.dart.snapshot',SDK/'bin/cache/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot',SDK/'bin/cache/dart-sdk/bin/snapshots/kernel-service.dart.snapshot',SDK/'bin/cache/flutter_tools.snapshot',SDK/'bin/cache/flutter.version.json',SDK/'packages/flutter_tools/pubspec.lock']
 runtime={str(p):sha(p)for p in runtime_paths}
 variants={'positive':workspace};bindings={}
 bindings['positive']={'supporting_source':SOURCE,'test_source':TEST_REF,'manifest_source':TEST_REF,'files':before,'package_config_sha256':sha(workspace/'.dart_tool/package_config.json'),'lock_sha256':LOCK_SHA}
 for label,spec in OVERLAYS.items():
  variant=workspace.parent/label;shutil.copytree(workspace,variant);variants[label]=variant
  for path in spec['paths']:write_blob(variant,spec['ref'],path)
  local_graph_check(variant)
  after=capture([variant/p for p in before],variant)
  changed=[p for p in before if before[p]!=after[p]];assert sorted(changed)==sorted(spec['paths'])
  expected=entries(spec['ref'])
  for path in changed:assert after[path]['git_blob']==expected[path]['blob']
  bindings[label]={'supporting_source':SOURCE,'test_source':TEST_REF,'manifest_source':TEST_REF,'overlay_source':spec['ref'],'overlay_paths':spec['paths'],'files':after,'package_config_sha256':sha(variant/'.dart_tool/package_config.json'),'lock_sha256':LOCK_SHA}
 with gzip.open(BASE/'evidence/source-bindings.json.gz','wt')as f:json.dump(bindings,f,indent=2,sort_keys=True)
 results={}
 commands=[('annotation-positive','positive',TESTS[0],None),('annotation-negative','annotation-negative',TESTS[0],None),('note-positive','positive',TESTS[1],NOTE_FILTER),('note-negative','note-negative',TESTS[1],NOTE_FILTER)]
 for label,variant,test,selection in commands:
  command=[str(DART),'test','--reporter','json','--concurrency=1','test/'+test]
  if selection:command+=['--name',selection]
  record=run(label,command,variants[variant]/ENGINE,env);record['summary']=parse(label);results[label]=record
 changed_inputs=[]
 for label,binding in bindings.items():
  workspace=variants[label]
  for path,identity in binding['files'].items():
   if sha(workspace/path)!=identity['sha256']:changed_inputs.append(label+':'+path)
  assert sha(workspace/'pubspec.lock')==LOCK_SHA
 deps_after={p:sha(Path(p))for p in deps}
 runtime_after={p:sha(Path(p))for p in runtime}
 expected={
  'annotation-positive':results['annotation-positive']['exit_code']==0 and results['annotation-positive']['summary']['counts']=={'success':11},
  'annotation-negative':results['annotation-negative']['exit_code']!=0 and results['annotation-negative']['summary']['counts'].get('failure',0)>0,
  'note-positive':results['note-positive']['exit_code']==0 and results['note-positive']['summary']['counts']=={'success':2},
  'note-negative':results['note-negative']['exit_code']!=0 and results['note-negative']['summary']['counts'].get('failure',0)==2
 }
 no_load_failures=all(all('loading 'not in(r['name']or'')for r in record['summary']['tests']if r['result']!='success')for record in results.values())
 all_assertions=all(all('Expected:'in e.get('error','')for e in results[label]['summary']['errors'])for label in ['annotation-negative','note-negative'])
 summary={'schema_version':1,'source_commit':SOURCE,'source_tree':git('rev-parse',SOURCE+'^{tree}').decode().strip(),'test_commit':TEST_REF,'manifest_commit':TEST_REF,'scope':'Paired controls with exact historical tests on final supporting engine/parser source; negative variants replace only the explicitly named baseline source files.','package_count':len(graph['packages']),'local_packages':locals_,'lock_sha256':LOCK_SHA,'results':results,'expected_outcomes':expected,'no_load_failures':no_load_failures,'negative_errors_are_assertion_failures':all_assertions,'inputs_unchanged':not changed_inputs,'changed_inputs':changed_inputs,'dependencies_unchanged':deps==deps_after,'dependency_file_count':len(deps),'runtime_unchanged':runtime==runtime_after,'runtime':runtime,'source_checkout_head_unchanged':git('rev-parse','HEAD').decode().strip()==SOURCE,'source_checkout_clean':not git('status','--porcelain').decode().strip(),'finished_at':now(),'runner_sha256':sha(Path(__file__)),'accepted':all(expected.values())and no_load_failures and all_assertions and not changed_inputs and deps==deps_after and runtime==runtime_after}
 save(BASE/'evidence/summary.json',summary)
 shutil.copy2(__file__,BASE/'evidence/run-controls.py')
 print(json.dumps({'summary':str(BASE/'evidence/summary.json'),'accepted':summary['accepted'],'results':{k:v['summary']['counts']for k,v in results.items()}},indent=2),flush=True)
 if not summary['accepted']:raise SystemExit(1)
if __name__=='__main__':main()
