#!/usr/bin/env python3
"""Independent readback of the completed canonical qualification evidence."""
from pathlib import Path
import argparse
import collections
import gzip
import hashlib
import json
from urllib.parse import unquote, urlparse


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('--source', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = args.directory.resolve()
    receipt = read_json(root / 'receipt.json')
    plan = read_json(root / 'plan.json')
    assert receipt['source_commit'] == args.source == plan['source_commit']
    assert receipt['working_head_after'] == args.source
    assert receipt['all_passed'] and receipt['status'] == 'passed'
    assert receipt['plan_sha256'] == sha((root / 'plan.json').read_bytes())
    assert receipt['runner_sha256'] == sha((root / 'run-used.py').read_bytes())
    assert receipt['analysis_config_restored']
    assert receipt['source_matches_frozen_commit']
    assert not receipt['historical_qualifications_counted']
    assert not receipt['github_actions_queried_awaited_or_rerun']

    integrity = {}
    for name in ['source', 'dependencies', 'runtime', 'workspace', 'system', 'harness']:
        before = read_json(root / (name + '-before.json'))
        after = read_json(root / (name + '-after.json'))
        assert before == after, name
        assert receipt['input_integrity'][name + '_unchanged'], name
        integrity[name] = True
    source = read_json(root / 'source-before.json')
    assert not source['commit_mismatches']
    assert not source['untracked_non_evidence_paths']
    assert source['count'] == len(source['files'])

    cohorts = plan['cohorts']
    selected = [(cohort['kind'], path) for cohort in cohorts.values() for path in cohort['tests']]
    assert len(selected) == len(set(selected)) == plan['unique_test_files']
    assert ('engine', 'test/odt_paragraph_decoration_test.dart') in selected
    fixture = read_json(root / 'fixture-audit.json')
    assert all(row['present'] for row in fixture['required_font_inputs'].values())
    missing_native = not all(fixture['optional_native_fixture_environment_present'].values())
    private_names = {
        'TrueType subsets without cmap get ToUnicode cmap for the host',
        'JPEG with DCT SMask attaches softMaskJpeg for the host',
    }
    review = {}
    commands = receipt['commands']
    assert len({row['name'] for row in commands}) == len(commands)
    assert len(commands) == len(plan['analysis_targets']) + len(cohorts) + 2
    expected_commands = {kind + '-strict-analysis' for kind in plan['analysis_targets']} | set(cohorts) | {'format', 'python-controls'}
    assert {row['name'] for row in commands} == expected_commands
    for command in commands:
        assert command['status'] == 'passed' and command['exit_code'] == 0
        assert not command['timed_out']
        logs = {}
        for stream in ['stdout', 'stderr']:
            compressed = (root / command[stream]).read_bytes()
            assert sha(compressed) == command[stream + '_gzip_sha256']
            raw = gzip.decompress(compressed)
            assert sha(raw) == command[stream + '_sha256']
            logs[stream] = raw.decode(errors='replace')
        if command['name'] not in cohorts:
            continue
        events = []
        for line in logs['stdout'].splitlines():
            try:
                event = json.loads(line)
            except ValueError:
                continue
            if isinstance(event, dict) and 'type' in event:
                events.append(event)
        starts_list = [event['test'] for event in events if event['type'] == 'testStart']
        starts = {test['id']: test for test in starts_list}
        assert len(starts_list) == len(starts)
        suites = {event['suite']['id']: event['suite'] for event in events if event['type'] == 'suite'}
        observed_paths = set()
        for suite in suites.values():
            raw_path = suite['path']
            path = Path(unquote(urlparse(raw_path).path) if raw_path.startswith('file:') else raw_path)
            observed_paths.add((path if path.is_absolute() else Path(command['cwd']) / path).resolve())
        selected_paths = {(Path(command['cwd']) / path).resolve() for path in cohorts[command['name']]['tests']}
        assert observed_paths == selected_paths
        ends = [event for event in events if event['type'] == 'testDone']
        assert len(ends) == len({event['testID'] for event in ends})
        assert set(starts) == {event['testID'] for event in ends}
        assert not [event for event in events if event['type'] == 'error']
        done = [event for event in events if event['type'] == 'done']
        assert len(done) == 1 and done[0]['success']
        visible = [event for event in ends if not event.get('hidden')]
        successes = [event for event in visible if event['result'] == 'success' and not event.get('skipped')]
        skips = [event for event in visible if event.get('skipped')]
        assert len(visible) == len(successes) + len(skips)
        for event in skips:
            test = starts[event['testID']]
            suite = suites[test['suiteID']]
            assert command['name'] == 'gector-contract' and missing_native
            assert test['name'] == 'real native dual heads own their output and reject use after dispose'
            assert suite['path'].endswith('/native_backend_test.dart')
        assert len(skips) <= 1
        excluded = []
        if not fixture['private_pdf_present']:
            for event in successes:
                test = starts[event['testID']]
                suite = suites[test['suiteID']]
                if suite['path'].endswith('/pdf_file_test.dart'):
                    for name in private_names:
                        if test['name'] == name or test['name'].endswith(' ' + name):
                            excluded.append(name)
        expected_private = private_names if not fixture['private_pdf_present'] and 'test/pdf_file_test.dart' in cohorts[command['name']]['tests'] else set()
        assert len(excluded) == len(expected_private) and set(excluded) == expected_private
        recounted = {'raw_successes': len(successes), 'qualified_successes': len(successes) - len(excluded), 'skipped': len(skips), 'excluded_private_pdf_successes': excluded}
        recorded = command['test_summary']
        assert recounted['raw_successes'] == recorded['raw_success_count']
        assert recounted['qualified_successes'] == recorded['substantive_success_count']
        assert not recorded['missing_selected_suites'] and not recorded['unexpected_suites']
        if command['name'] == 'engine-zotero':
            assert len(successes) == 390
        if command['name'] == 'editor-zotero':
            assert len(successes) == 186
        review[command['name']] = recounted
    assert set(review) == set(cohorts)
    assert sum(row['raw_successes'] for row in review.values()) == receipt['raw_runner_success_total']
    assert sum(row['qualified_successes'] for row in review.values()) == receipt['substantive_success_total']
    python = read_json(root / 'python-controls-summary.json')
    py_command = next(row for row in commands if row['name'] == 'python-controls')
    assert py_command['python_summary_sha256'] == sha((root / 'python-controls-summary.json').read_bytes())
    assert python == py_command['python_summary'] == receipt['python_controls_summary']
    assert python['passed'] and python['runtime_before'] == python['runtime_after']
    assert not any(python[name] for name in ['unexpected_skipped_cases', 'missing_selected_tests', 'failures', 'errors', 'expected_failures', 'unexpected_successes'])
    assert len(set(python['selected_test_ids'])) == len(python['selected_test_ids']) == python['tests_run']
    assert set(python['successful_test_ids']) | {row['test'] for row in python['skipped_cases']} == set(python['selected_test_ids'])
    assert len(python['successful_test_ids']) + len(python['skipped_cases']) == python['tests_run']
    assert len(python['successful_test_ids']) == python['substantive_success_count']
    for skipped in python['skipped_cases']:
        assert skipped['test'] == 'test_qualification.TinyConverterTests.test_real_quantizer_preserves_both_head_matrices'
        assert not python['runtime_before']['onnx_available'] or not python['runtime_before']['onnxruntime_available']
    assert len(python['skipped_cases']) <= 1
    result = {'accepted': True, 'source_commit': args.source, 'source_tree': receipt['source_tree'], 'receipt_sha256': sha((root / 'receipt.json').read_bytes()), 'independent_reviewer_script_sha256': sha(Path(__file__).read_bytes()), 'unique_test_files': len(selected), 'cohorts': review, 'substantive_success_total': sum(row['qualified_successes'] for row in review.values()), 'python_substantive_successes': python['substantive_success_count'], 'python_skipped_cases': python['skipped_cases'], 'input_integrity': integrity, 'all_raw_and_compressed_log_hashes_readback_verified': True}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
