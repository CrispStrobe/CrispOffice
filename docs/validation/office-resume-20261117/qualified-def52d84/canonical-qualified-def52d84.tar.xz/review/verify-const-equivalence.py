#!/usr/bin/env python3
"""Verify the final source delta and unchanged requalification selection."""
from pathlib import Path
import hashlib
import json
import subprocess


BASE = Path(__file__).resolve().parent.parent
OLD = '4c49b0435bc6611221bc49b58b15e735059467ff'
NEW = 'def52d84f3c3c5ce22c44d2620ecfa08d77780a7'
WRITER = 'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart'


def load(path):
    return json.loads(path.read_text())


def main():
    earlier = BASE / 'runtime-work/qualification/run-4c49b043-1'
    current = BASE / 'runtime-work/qualification/run-def52d84-1'
    old_map = load(earlier / 'source-before.json')['files']
    new_map = load(current / 'source-before.json')['files']
    assert set(old_map) == set(new_map)
    changed = [path for path in old_map if old_map[path] != new_map[path]]
    assert changed == [WRITER]
    get = lambda ref: subprocess.check_output(['git', '-C', str(BASE / 'quds'), 'show', ref + ':' + WRITER])
    old = get(OLD)
    new = get(NEW)
    old_call = "return _OdtListMarker.bullet('•');".encode()
    new_call = "return const _OdtListMarker.bullet('•');".encode()
    assert old.count(old_call) == 1 and old.replace(old_call, new_call) == new
    old_plan = load(earlier / 'plan.json')
    new_plan = load(current / 'plan.json')
    assert old_plan.pop('source_commit') == OLD
    assert new_plan.pop('source_commit') == NEW
    assert old_plan == new_plan
    old_receipt = load(earlier / 'receipt.json')
    new_receipt = load(current / 'receipt.json')
    assert old_receipt['all_passed'] and new_receipt['all_passed']
    assert old_receipt['runner_sha256'] == new_receipt['runner_sha256']
    assert old_receipt['raw_runner_success_total'] == new_receipt['raw_runner_success_total'] == 3282
    assert old_receipt['substantive_success_total'] == new_receipt['substantive_success_total'] == 3280
    assert old_receipt['python_controls_summary']['substantive_success_count'] == new_receipt['python_controls_summary']['substantive_success_count'] == 107
    result = {'accepted': True, 'source_before': OLD, 'source_after': NEW, 'all_non_evidence_input_path_sets_equal': True, 'non_evidence_input_count': len(old_map), 'changed_input_paths': changed, 'exact_single_const_keyword_delta_verified': True, 'writer_before_sha256': hashlib.sha256(old).hexdigest(), 'writer_after_sha256': hashlib.sha256(new).hexdigest(), 'entire_plan_equal_except_source_commit': True, 'selected_test_files': new_plan['unique_test_files'], 'all_test_inputs_byte_identical': True, 'runner_byte_identical': True, 'fresh_product_passes': 3280, 'fresh_python_passes': 107, 'historical_test_totals_used_for_acceptance': False, 'test_execution_performed_by_reviewer': False}
    output = BASE / 'canonical-final-review/post-const-source-equivalence.json'
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
