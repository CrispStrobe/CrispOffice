export FLUTTER_ROOT=/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/flutter-sdk
export PUB_CACHE=/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/pub-cache
export TMPDIR=/workspace/scratch/18384bc07dad/runtime-work/tmp
export XDG_CONFIG_HOME=/workspace/scratch/18384bc07dad/runtime-work/config
export CI=true
export DART_SUPPRESS_ANALYTICS=true
export FLUTTER_SUPPRESS_ANALYTICS=true
export PATH=/workspace/scratch/18384bc07dad/runtime-work/bin:"$PATH"
