from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/workspace/scratch/4d323337693a/quds_office_suite')
OUT = Path(__file__).resolve().parent
TARGET = 'ca726cd687a64a89cdd2b8e5df3f61dc57f4ca25'
TREE = '8011024075bed83b30388d8deec72de2149886ad'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(path.read_text())

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

plan = load(OUT / 'plan.json')
entries = subprocess.check_output(['git', 'ls-tree', '-r', TARGET], cwd=ROOT, text=True).splitlines()
blobs = {}
for line in entries:
    header, path = line.split('\t', 1)
    mode, kind, object_id = header.split()
    if kind == 'blob':
        blobs[path] = object_id
libraries = {path for path in blobs if path.startswith('packages/') and '/lib/' in path and path.endswith('.dart')}
union = {}
checks = {}
audit = {}
receipts = {}
for scope in ['engine', 'editor', 'static']:
    directory = OUT / scope
    receipt = load(directory / 'receipt.json')
    before = load(directory / 'inputs-before.json')
    after = load(directory / 'inputs-after.json')
    assert before == after and receipt['inputs_unchanged']
    assert receipt['source_checkpoint_before_run'] == receipt['source_checkpoint_after_run'] == TARGET
    assert not (libraries - before.keys())
    for name, expected in before.items():
        if name in union:
            assert union[name] == expected
        union[name] = expected
    receipts[scope] = receipt
    checks[scope] = {'inputs': len(before), 'package_library_files': len(libraries), 'inputs_unchanged': True, 'qualified_checkpoint': TARGET}
    if scope == 'static':
        assert receipt['passed'] and all(check['exit_code'] == 0 for check in receipt['checks'])
        continue
    events = [json.loads(line) for line in (directory / 'events.jsonl').read_text().splitlines()]
    suite_events = [event['suite'] for event in events if event.get('type') == 'suite']
    cwd = Path(receipt['cwd'])
    seen = [str(Path(suite['path']).relative_to(cwd)) if Path(suite['path']).is_absolute() else suite['path'] for suite in suite_events]
    assert len(seen) == len(set(seen)) == len(plan[scope]) and set(seen) == set(plan[scope])
    starts = {event['test']['id']: event['test'] for event in events if event.get('type') == 'testStart'}
    done_cases = [event for event in events if event.get('type') == 'testDone' and not event.get('hidden')]
    assert all(event['testID'] in starts for event in done_cases)
    assert all(event.get('result') == 'success' and not event.get('skipped') for event in done_cases)
    assert len(done_cases) == receipt['passed'] and receipt['failed'] == receipt['skipped'] == 0
    assert events[-1].get('type') == 'done' and events[-1].get('success') is True
    assert not any(event.get('type') == 'error' for event in events)
    run_file = directory / 'runner.py' if scope == 'engine' else OUT / 'run_followup_qualification.py'
    plan_file = directory / 'plan.json' if scope == 'engine' else OUT / 'plan.json'
    assert sha(run_file.read_bytes()) == receipt['runner_sha256']
    assert sha(plan_file.read_bytes()) == receipt['plan_sha256']
    audit[scope] = {'selected_suite_count': len(seen), 'selected_suites_match_events': True, 'successful_cases': len(done_cases), 'errors': 0, 'skipped': 0, 'terminal_success': True, 'events_sha256': sha((directory / 'events.jsonl').read_bytes()), 'executed_runner': str(run_file.relative_to(OUT)), 'executed_plan': str(plan_file.relative_to(OUT))}

runtime_inputs = []
for name, expected in union.items():
    data = (ROOT / name).read_bytes()
    assert sha(data) == expected, name
    if name in blobs:
        git_hash = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert git_hash == blobs[name], name
    else:
        assert name == '.dart_tool/package_config.json', name
        runtime_inputs.append(name)
assert subprocess.check_output(['git', 'rev-parse', TARGET + '^{tree}'], cwd=ROOT, text=True).strip() == TREE
save('test-event-audit.json', {'schema': 'quds-zotero-followup-event-audit-v1', 'all_checks_passed': True, 'runs': audit})
save('input-union.json', dict(sorted(union.items())))
summary = {
    'schema': 'quds-zotero-publication-followup-v1',
    'qualified_checkpoint': TARGET, 'qualified_tree': TREE,
    'prior_qualified_checkpoint': '4b33109aa85e077e2798265efa045d640e6ead4e',
    'scope': 'Bounded follow-up for merged numeric intrinsics and renderer paragraph/frame caches. The previous 2363-case qualification is retained separately; overlapping cases are not added to a new cumulative total.',
    'test_cases_passed': sum(receipts[x]['passed'] for x in ['engine', 'editor']),
    'test_suites': sum(receipts[x]['test_file_count'] for x in ['engine', 'editor']),
    'failed': 0, 'skipped': 0,
    'runs': {x: {'passed': receipts[x]['passed'], 'suites': receipts[x]['test_file_count']} for x in ['engine', 'editor']},
    'static': {'passed': True, 'changed_package_dart_targets': receipts['static']['target_file_count'], 'excluded_archived_dart_paths': receipts['static']['excluded_archived_dart_paths']},
    'input_checks': checks,
    'captured_input_union': len(union),
    'captured_inputs_match_current_and_target_git': True,
    'outside_git_runtime_inputs': runtime_inputs,
    'input_union_sha256': sha((OUT / 'input-union.json').read_bytes()),
    'test_event_audit_sha256': sha((OUT / 'test-event-audit.json').read_bytes()),
    'preserved_preflight_attempt': {'path': 'static-preparation-attempt/receipt.json', 'checks_executed': 0, 'qualification_credit': 0},
    'original_position_integration_blocker': 'Unchanged disclosure: the four cases blocked at the 4b CLI setup were not retried and receive no fresh qualification credit.',
    'converters_rerun': False, 'github_actions_used': False,
}
save('qualification-summary.json', summary)
print(json.dumps(summary, indent=2))
