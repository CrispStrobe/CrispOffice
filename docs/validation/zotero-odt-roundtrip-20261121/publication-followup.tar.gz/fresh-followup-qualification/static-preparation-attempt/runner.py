import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/4d323337693a/quds_office_suite')
OUT = Path(__file__).resolve().parent
BASELINE = '4b33109aa85e077e2798265efa045d640e6ead4e'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', required=True)
    args = parser.parse_args()
    assert git('rev-parse', 'HEAD') == args.checkpoint
    dest = OUT / 'static'
    dest.mkdir(exist_ok=False)
    spec = importlib.util.spec_from_file_location('qualification', OUT / 'run_followup_qualification.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    paths = git('diff', '--name-only', BASELINE, args.checkpoint, '--', '*.dart').splitlines()
    targets = [ROOT / path for path in paths]
    assert targets and all(path.is_file() for path in targets)
    before = module.snapshot(targets)
    head_before = git('rev-parse', 'HEAD')
    save(dest / 'inputs-before.json', before)
    commands = [('format', ROOT, ['dart', 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed', *paths])]
    grouped = {}
    for path in targets:
        relative = path.relative_to(ROOT)
        assert relative.parts[0] == 'packages'
        package = ROOT / 'packages' / relative.parts[1]
        grouped.setdefault(package, []).append(str(path.relative_to(package)))
    for package, files in sorted(grouped.items()):
        commands.append(('analysis-' + package.name, package, ['dart', 'analyze', '--fatal-infos', *files]))
    commands.extend([
        ('diff-check', ROOT, ['git', 'diff', '--check', BASELINE, args.checkpoint, '--', *paths]),
        ('worktree-check', ROOT, ['git', 'diff', '--check']),
    ])
    checks = []
    for name, cwd, argv in commands:
        print(json.dumps({'check': name, 'started': True}), flush=True)
        started = time.monotonic()
        with (dest / (name + '.stdout')).open('w') as stdout, (dest / (name + '.stderr')).open('w') as stderr:
            result = subprocess.run(argv, cwd=cwd, stdout=stdout, stderr=stderr)
        check = {'name': name, 'cwd': str(cwd), 'argv': argv, 'exit_code': result.returncode,
                 'elapsed_seconds': time.monotonic() - started,
                 'stdout_sha256': hashlib.sha256((dest / (name + '.stdout')).read_bytes()).hexdigest(),
                 'stderr_sha256': hashlib.sha256((dest / (name + '.stderr')).read_bytes()).hexdigest()}
        checks.append(check)
        print(json.dumps({'check': name, 'exit_code': result.returncode}), flush=True)
    after = module.snapshot(targets)
    save(dest / 'inputs-after.json', after)
    ok = all(check['exit_code'] == 0 for check in checks) and before == after and git('rev-parse', 'HEAD') == args.checkpoint
    receipt = {'scope': 'static', 'qualified_checkpoint': args.checkpoint, 'baseline_checkpoint': BASELINE,
               'source_checkpoint_before_run': head_before, 'source_checkpoint_after_run': git('rev-parse', 'HEAD'),
               'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'snapshot_scope': 'All Dart targets changed since qualified4b, all workspace package library Dart files, SDK/dependency inputs, numeric corpus and support helpers, Zotero fixtures, review helpers and Linux selection goldens.',
               'targets': paths, 'target_file_count': len(paths), 'checks': checks,
               'source_inputs': len(before), 'inputs_unchanged': before == after,
               'changed_inputs': sorted(key for key in before.keys() | after.keys() if before.get(key) != after.get(key)),
               'passed': ok, 'status': 'PASS' if ok else 'FAIL', 'github_actions_used': False}
    save(dest / 'receipt.json', receipt)
    print(json.dumps({key: value for key, value in receipt.items() if key not in ['checks', 'targets']}, indent=2), flush=True)
    raise SystemExit(0 if ok else 1)


if __name__ == '__main__':
    main()
