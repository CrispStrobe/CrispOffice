#!/usr/bin/env python3
"""Read-only source continuity audit after the bounded publication follow-up.

No tests, compiler or office host are executed. Existing reports are read
unchanged; only the explicitly named output report is written.
"""
import argparse
import collections
import hashlib
import json
import posixpath
import re
import subprocess
from pathlib import Path
from urllib.parse import unquote, urljoin, urlparse


def digest(value):
    return hashlib.sha256(value).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--proof', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    workspace = args.plan.resolve().parent
    plan = json.loads(args.plan.read_text())
    followup = json.loads(args.proof.read_text())
    repository = Path(plan['repository'])
    target = plan['target_commit']
    previous = '4b33109aa85e077e2798265efa045d640e6ead4e'
    publication = 'f1f8a8e368b392b3a65330c03b27806fe4179f40'
    automation = 'packages/quds_office_engine/lib/src/automation/office_vba_language.dart'
    renderer = 'packages/quds_office_editor/lib/src/editor_word/render_word_canvas.dart'
    runtime = '.dart_tool/package_config.json'
    require(followup['target_commit'] == target and followup['all_binding_checks_passed'],
            'Fresh follow-up binding must pass at the target')
    require(followup['plan']['sha256'] == digest(args.plan.read_bytes()), 'Follow-up plan changed')

    def git(*arguments, data=None):
        return subprocess.check_output(['git', *arguments], cwd=repository, input=data)

    def artifact(path):
        path = Path(path)
        if not path.is_absolute():
            path = workspace / path
        data = path.read_bytes()
        return {'path': str(path), 'sha256': digest(data), 'bytes': len(data)}

    def tree(ref):
        entries = {}
        for row in git('ls-tree', '-r', '-z', ref).split(b'\0'):
            if row:
                metadata, name = row.split(b'\t', 1)
                mode, kind, oid = metadata.decode().split()
                entries[name.decode()] = {'mode': mode, 'kind': kind, 'blob': oid}
        return entries

    require(git('rev-parse', 'HEAD').decode().strip() == target, 'Target HEAD changed')
    old_tree, new_tree, publication_tree = tree(previous), tree(target), tree(publication)
    blobs = {}

    def load_blobs(ids):
        ids = sorted(set(ids) - blobs.keys())
        if not ids:
            return
        output = git('cat-file', '--batch', data=('\n'.join(ids) + '\n').encode())
        offset = 0
        for expected in ids:
            end = output.index(b'\n', offset)
            oid, kind, size = output[offset:end].decode().split()
            require(oid == expected and kind == 'blob', 'Unexpected Git object')
            offset = end + 1
            size = int(size)
            blobs[oid] = output[offset:offset + size]
            offset += size
            require(output[offset:offset + 1] == b'\n', 'Invalid Git object framing')
            offset += 1
        require(offset == len(output), 'Unexpected trailing Git object bytes')

    load_blobs(entry['blob'] for entries in [old_tree, new_tree] for path, entry in entries.items()
               if path.endswith('.dart') and entry['kind'] == 'blob')
    config_path = repository / runtime
    config = json.loads(config_path.read_text())
    package_roots = {}
    external_packages = set()
    for package in config['packages']:
        root_uri = urljoin(config_path.as_uri(), package['rootUri'])
        lib_uri = urljoin(root_uri.rstrip('/') + '/', package.get('packageUri', 'lib/'))
        local = Path(unquote(urlparse(lib_uri).path)).resolve()
        if local.is_relative_to(repository):
            package_roots[package['name']] = local.relative_to(repository).as_posix().rstrip('/') + '/'
        else:
            external_packages.add(package['name'])

    # Conditional import/export alternatives are included, so this is a
    # conservative tracked-workspace directive closure rather than a compiler
    # trace. Sources of external packages are outside this graph's scope.
    directive = re.compile(r'^\s*(?:import|export|part)\s+([\'\"])([^\'\"]+)\1([^;]*);', re.M)

    def closure(entrypoint, entries):
        queue = collections.deque([entrypoint])
        seen, external, missing, unparsed = set(), set(), set(), []
        while queue:
            path = queue.popleft()
            if path in seen:
                continue
            seen.add(path)
            source = blobs[entries[path]['blob']].decode('utf-8')
            for line in source.splitlines():
                if (re.match(r'^\s*(?:import|export|part)\b', line)
                        and not re.match(r'^\s*part\s+of\b', line)
                        and not re.match(r'^\s*(?:import|export|part)\s+[\'\"]', line)):
                    unparsed.append({'path': path, 'line': line})
            for match in directive.finditer(source):
                uris = [match.group(2)] + re.findall(r'[\'\"]([^\'\"]+\.dart)[\'\"]', match.group(3))
                for uri in uris:
                    if uri.startswith('dart:'):
                        continue
                    if uri.startswith('package:'):
                        package, relative = uri[8:].split('/', 1)
                        if package not in package_roots:
                            require(package in external_packages, 'Unknown package: ' + package)
                            external.add(uri)
                            continue
                        child = package_roots[package] + relative
                    else:
                        child = posixpath.normpath(posixpath.join(posixpath.dirname(path), uri))
                    if child not in entries:
                        missing.add(child)
                    else:
                        queue.append(child)
        return {'files': sorted(seen), 'external_package_uris': sorted(external),
                'missing_workspace_targets': sorted(missing), 'unparsed_directive_lines': unparsed}

    historic_path = workspace / 'zotero-final-passing-scopes-source-binding.json'
    historic = json.loads(historic_path.read_text())
    completeness_path = workspace / 'zotero-final-qualification-completeness.json'
    completeness = json.loads(completeness_path.read_text())
    require(historic['target_commit'] == previous and historic['all_binding_checks_passed'],
            'Historical proof is not the frozen 4b milestone')
    require(completeness['successful_fresh_case_count'] == 2363
            and completeness['checks']['all_original_requested_tests_passed'] is False,
            'Historical qualification scope changed')
    runs = {}
    all_closure_paths = set()
    for name in ['converter_two_saves', 'converter_mixed_note_export', 'converter_native_images']:
        old_run = historic['runs'][name]
        entrypoint = old_run['compiled_tool']['path']
        before = old_run['before_sha256_by_path']
        after = old_run['after_sha256_by_path']
        old_closure = closure(entrypoint, old_tree)
        new_closure = closure(entrypoint, new_tree)
        all_closure_paths.update(new_closure['files'])
        load_blobs(new_tree[path]['blob'] for path in before if path in new_tree)
        mismatches = sorted(path for path in before if path in new_tree
                            and before[path] != digest(blobs[new_tree[path]['blob']]))
        changed_closure = sorted(path for path in old_closure['files']
                                 if old_tree[path] != new_tree.get(path))
        missing_snapshot = sorted(set(new_closure['files']) - before.keys())
        reachable_automation = [path for path in new_closure['files']
                                if '/automation/' in path or path.endswith('/quds_office_automation.dart')]
        checks = {
            'historical_execution_was_successful': all(old_run['checks'].values()),
            'historical_before_after_snapshots_identical': before == after,
            'only_changed_snapshot_observer_is_automation': mismatches == [automation],
            'workspace_directive_closures_identical': old_closure == new_closure,
            'all_reachable_workspace_file_modes_and_blobs_unchanged': not changed_closure,
            'all_reachable_workspace_files_were_captured': not missing_snapshot,
            'no_unresolved_workspace_directives': not new_closure['missing_workspace_targets']
                and not new_closure['unparsed_directive_lines'],
            'automation_is_not_reachable_from_converter': not reachable_automation,
            'runtime_configuration_unchanged': before[runtime] == after[runtime] == digest(config_path.read_bytes()),
        }
        runs[name] = {
            'executed_checkpoint': previous,
            'execution_is_historical_not_repeated': True,
            'entrypoint': entrypoint,
            'historical_evidence': old_run['evidence'],
            'captured_input_count': len(before),
            'changed_tracked_snapshot_paths': mismatches,
            'changed_observer_explanation': 'The original runner captured every engine library, including automation/office_vba_language.dart. This file is outside the converters\' tracked-workspace import/export/part closure; it is not an unchanged snapshot input and is not treated as one.',
            'workspace_closure_count': len(new_closure['files']),
            'workspace_closure': new_closure,
            'changed_workspace_closure_paths': changed_closure,
            'missing_snapshot_paths': missing_snapshot,
            'checks': checks,
        }

    closure_manifest = {path: {'before': old_tree[path], 'target': new_tree[path],
                               'sha256': digest(blobs[new_tree[path]['blob']])}
                        for path in sorted(all_closure_paths)}
    package_libraries = lambda path: path.startswith('packages/') and '/lib/' in path and path.endswith('.dart')
    production_delta = sorted(path for path in old_tree.keys() | new_tree.keys()
                              if package_libraries(path) and old_tree.get(path) != new_tree.get(path))
    record = 'docs/validation/zotero-odt-roundtrip-20261121/'
    preserved = {}
    for path, entry in publication_tree.items():
        if path.startswith(record) and path != record + 'README.md':
            load_blobs([entry['blob']])
            preserved[path] = {'baseline': entry, 'target': new_tree.get(path),
                               'baseline_sha256': digest(blobs[entry['blob']]),
                               'current_sha256': digest((repository / path).read_bytes()),
                               'mode_type_blob_unchanged': entry == new_tree.get(path),
                               'current_bytes_unchanged': (repository / path).read_bytes() == blobs[entry['blob']]}
    kernel_path = workspace / 'zotero-publication-followup-kernel-inspection.json'
    require(kernel_path.is_file(), 'Kernel corroboration receipt is required')
    checks = {
        'fresh_followup_source_binding_passed': followup['all_binding_checks_passed'],
        'net_production_changes_limited_to_two_reviewed_files': production_delta == sorted([automation, renderer]),
        'all_converter_continuity_checks_pass': all(all(run['checks'].values()) for run in runs.values()),
        'all_25_previous_validation_records_preserved': len(preserved) == 25 and all(
            item['mode_type_blob_unchanged'] and item['current_bytes_unchanged'] for item in preserved.values()),
        'prior_qualification_remains_explicitly_incomplete': completeness['checks']['all_original_requested_tests_passed'] is False,
        'target_head_stable': git('rev-parse', 'HEAD').decode().strip() == target,
    }
    report = {
        'schema': 'quds-zotero-publication-followup-continuity-v1',
        'target_commit': target, 'target_tree': followup['target_tree'],
        'previous_execution_checkpoint': previous, 'previous_publication_checkpoint': publication,
        'scope': 'Fresh focused checks at the new checkpoint plus independently verified continuity of the earlier actual Zotero converters. Broader earlier tests are historical, not relabeled as new-checkpoint executions.',
        'directive_closure_method': 'Conservative import/export/part traversal of tracked workspace Dart files, including conditional URI alternatives. Package names resolve through the unchanged runtime package configuration. External package sources are not scanned; all captured manifest/config inputs remain unchanged. This is not a compiler dependency trace.',
        'generator': artifact(Path(__file__).resolve()),
        'fresh_binding_plan': artifact(args.plan.resolve()),
        'fresh_binding_proof': artifact(args.proof.resolve()),
        'frozen_historical_binding': artifact(historic_path),
        'frozen_historical_completeness': artifact(completeness_path),
        'kernel_byte_inspection_corroboration': artifact(kernel_path),
        'production_delta': production_delta,
        'source_review': {
            'numeric_intrinsics': 'Abs/Int/Fix/Sgn add explicit source-language checking and evaluation using the existing finite numeric envelope. They are unreachable from all three Zotero converter entrypoints.',
            'renderer': 'Caches retain the prior paragraph-index and frame-owner map construction, reset with existing body-picture invalidation and disposal, and are exercised by fresh cache suites plus the existing absolute-frame-inside-table pixel/golden case.',
            'retained_guard_and_oracle': 'The editable ODT absolute-position refusal and the converter positionHalfPoints oracle remain byte-identical to 4b.',
        },
        'fresh_followup_runs': {name: {key: run[key] for key in
                                ['recorded_checkpoint', 'recorded_result', 'input_count', 'checks']}
                              for name, run in followup['runs'].items()},
        'historical_tests': {'checkpoint': previous, 'passed_cases': 2363, 'passed_suites': 109,
                             'blocked_position_cases': 4,
                             'relabelled_as_fresh_target_runs': False,
                             'fresh_studio_rerun': False,
                             'original_plan_fully_passed': False},
        'converter_continuity': runs,
        'shared_workspace_closure_manifest': closure_manifest,
        'preserved_validation_records': preserved,
        'excluded_from_frozen_record_set': record + 'README.md',
        'checks': checks, 'all_continuity_checks_passed': all(checks.values()),
    }
    output = args.output.resolve()
    require(not output.is_relative_to(repository), 'Report output must remain outside Git')
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'output': str(output), 'sha256': digest(output.read_bytes()),
                      'bytes': output.stat().st_size, 'checks': checks,
                      'closures': {name: value['workspace_closure_count'] for name, value in runs.items()},
                      'preserved_records': len(preserved)}, indent=2))
    return 0 if report['all_continuity_checks_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
