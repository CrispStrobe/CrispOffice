#!/usr/bin/env python3
"""Inspect retained converter kernels as bytes; never execute a compiler or host.

This is corroborating evidence only. Exact Dart dependency closure and source
continuity are established independently by the follow-up continuity report.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess

WORKSPACE = Path(__file__).resolve().parent
REPOSITORY = WORKSPACE / 'quds_office_suite'
BASELINE = '4b33109aa85e077e2798265efa045d640e6ead4e'
AUTOMATION = 'packages/quds_office_engine/lib/src/automation/office_vba_language.dart'
BARREL = 'packages/quds_office_engine/lib/quds_office_engine.dart'
RUNS = {
    'core': ('core-4b33109a-retry1', 'odt_roundtrip_acceptance.dart'),
    'mixed': ('mixed-4b33109a-retry1', 'odt_export_acceptance.dart'),
    'images': ('images-4b33109a', 'odt_image_acceptance.dart'),
}


def sha(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def git_blob(commit: str, path: str) -> bytes:
    return subprocess.check_output(['git', 'show', commit + ':' + path], cwd=REPOSITORY)


def identity(payload: bytes) -> dict[str, object]:
    return {'bytes': len(payload), 'sha256': sha(payload)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    old_automation = git_blob(BASELINE, AUTOMATION)
    new_automation = git_blob(args.target, AUTOMATION)
    old_barrel = git_blob(BASELINE, BARREL)
    assert git_blob(args.target, BARREL) == old_barrel
    runs = {}
    for name, (directory, filename) in RUNS.items():
        root = WORKSPACE / 'zotero-final-integration-converter' / directory
        receipt_path = root / 'receipt.json'
        receipt_bytes = receipt_path.read_bytes()
        receipt = json.loads(receipt_bytes)
        assert receipt['status'] == 'passed'
        assert receipt['source_commit'] == BASELINE
        compile_command = next(command for command in receipt['commands'] if command['name'] == 'compile')
        assert compile_command['exit_code'] == 0
        tool_path = 'packages/quds_office_engine/tool/zotero/' + filename
        original_tool = git_blob(BASELINE, tool_path)
        assert original_tool == git_blob(args.target, tool_path)
        assert original_tool == (root / 'acceptance-source.dart').read_bytes()
        assert sha(original_tool) == receipt['artifacts']['acceptance-source.dart']['sha256']
        kernel_path = root / 'acceptance.dill'
        assert str(kernel_path) in compile_command['argv']
        kernel = kernel_path.read_bytes()
        present = {
            'exact_entrypoint_source_bytes': kernel.find(original_tool),
            'entrypoint_filename': kernel.find(filename.encode()),
            'exact_engine_barrel_source_bytes': kernel.find(old_barrel),
        }
        absent = {
            'automation_filename': kernel.find(b'office_vba_language.dart'),
            'automation_package_uri': kernel.find(b'package:quds_office_engine/src/automation/office_vba_language.dart'),
            'exact_baseline_automation_source_bytes': kernel.find(old_automation),
        }
        assert all(offset >= 0 for offset in present.values()), present
        assert all(offset == -1 for offset in absent.values()), absent
        assert sha(kernel_path.read_bytes()) == sha(kernel)
        runs[name] = {
            'original_receipt': {'path': str(receipt_path.relative_to(WORKSPACE)), **identity(receipt_bytes)},
            'retained_kernel': {'path': str(kernel_path.relative_to(WORKSPACE)), **identity(kernel)},
            'original_compile_command': compile_command,
            'entrypoint': {'path': tool_path, **identity(original_tool), 'unchanged_at_target': True},
            'positive_byte_search_offsets': present,
            'negative_byte_search_offsets': absent,
            'kernel_bytes_unchanged_during_read': True,
        }
    report = {
        'schema': 'quds-zotero-retained-kernel-byte-inspection-v1',
        'baseline_commit': BASELINE,
        'target_commit': args.target,
        'generator': {'path': Path(__file__).name, **identity(Path(__file__).read_bytes())},
        'method': 'Read retained kernel bytes and exact Git source blobs; use byte substring searches with positive entrypoint and engine-barrel source controls. No Dart program, compiler, test, probe or office host is executed.',
        'limitations': 'A negative byte substring search is supporting evidence, not a complete Dart dependency parser or semantic proof. The independent static import/export/part closure determines which workspace files are compiler inputs. Kernel derivatives stay outside the compact archive.',
        'automation_observer': {'path': AUTOMATION, 'baseline': identity(old_automation), 'target': identity(new_automation), 'changed': old_automation != new_automation},
        'engine_barrel': {'path': BARREL, **identity(old_barrel), 'unchanged_at_target': True},
        'runs': runs,
        'all_positive_controls_present': True,
        'all_automation_byte_searches_absent': True,
        'new_program_execution_performed': False,
    }
    payload = (json.dumps(report, indent=2, sort_keys=True) + '\n').encode()
    if args.output.exists():
        assert args.output.read_bytes() == payload, 'Existing inspection receipt differs; refusing overwrite.'
    else:
        with args.output.open('xb') as stream:
            stream.write(payload)
    print(json.dumps({'output': str(args.output), **identity(payload), 'runs': len(runs)}))


if __name__ == '__main__':
    main()
