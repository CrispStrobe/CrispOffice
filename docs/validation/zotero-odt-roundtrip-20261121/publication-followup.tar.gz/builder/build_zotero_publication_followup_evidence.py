#!/usr/bin/env python3
"""Package frozen bounded follow-up evidence without rerunning any application.

Default invocation only describes the collection. --build requires passed fresh
source binding, the independent continuity report, and unchanged prior records.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

WORKSPACE = Path(__file__).resolve().parent
REPOSITORY = WORKSPACE / 'quds_office_suite'
RECORD = REPOSITORY / 'docs/validation/zotero-odt-roundtrip-20261121'
BASELINE = '4b33109aa85e077e2798265efa045d640e6ead4e'
ARCHIVE_NAME = 'publication-followup.tar.gz'
MANIFEST_NAME = 'publication-followup-archive-contents.json'
PRESERVATION_NAME = 'zotero-publication-followup-preservation.json'
PRESERVATION_SHA256 = '3c7c4b63e656f08a6f7e9b82f9711d53883441a92fc29fcc9b4425383a085348'
EXCLUDED = {'.git', '.dart_tool', '.pub-cache', '__pycache__', 'node_modules', 'profile', 'profiles', 'flutter', 'pub-cache', 'build', 'cache', 'test-runner', 'sdk', 'dependencies'}
SUFFIXES = {'.json', '.jsonl', '.log', '.stdout', '.stderr', '.txt', '.md', '.py', '.dart', '.sh', '.xml', '.png', '.rgba', '.bas'}


def sha(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()


@dataclass(frozen=True)
class Entry:
    name: str
    payload: bytes
    source: str


class Collection:
    def __init__(self) -> None:
        self.entries: dict[str, Entry] = {}
        self.inputs: dict[Path, str] = {}
        self.pending: list[str] = []

    def read(self, path: Path) -> bytes:
        if path.is_symlink() or not path.is_file():
            raise ValueError('Expected a regular evidence file: ' + str(path))
        path = path.resolve()
        path.relative_to(WORKSPACE)
        payload = path.read_bytes()
        checksum = sha(payload)
        if path in self.inputs and self.inputs[path] != checksum:
            raise RuntimeError('Evidence changed during collection: ' + str(path))
        self.inputs[path] = checksum
        return payload

    def add(self, name: str, payload: bytes, source: str) -> None:
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or not path.parts or name in self.entries:
            raise ValueError('Unsafe or duplicate archive member: ' + name)
        self.entries[name] = Entry(name, payload, source)

    def file(self, path: Path, name: str) -> None:
        if not path.exists():
            self.pending.append(str(path.relative_to(WORKSPACE)))
            return
        self.add(name, self.read(path), str(path.relative_to(WORKSPACE)))

    def tree(self, directory: Path, prefix: str) -> None:
        if not directory.is_dir():
            self.pending.append(str(directory.relative_to(WORKSPACE)))
            return
        for parent, directories, files in os.walk(directory, followlinks=False):
            current = Path(parent)
            directories[:] = sorted(name for name in directories if name not in EXCLUDED and not name.startswith('.') and not (current / name).is_symlink())
            for name in sorted(files):
                path = current / name
                if path.suffix.lower() in SUFFIXES:
                    self.file(path, prefix + '/' + path.relative_to(directory).as_posix())

    def report(self, path: Path) -> dict[str, object] | None:
        if not path.is_file():
            self.pending.append(str(path.relative_to(WORKSPACE)))
            return None
        return json.loads(self.read(path))

    def unchanged(self) -> None:
        changed = [str(path.relative_to(WORKSPACE)) for path, expected in self.inputs.items() if path.is_symlink() or not path.is_file() or sha(path.read_bytes()) != expected]
        if changed:
            raise RuntimeError('Evidence changed while packaging: ' + ', '.join(changed))


def collect(args: argparse.Namespace) -> tuple[Collection, dict[str, object] | None]:
    result = Collection()
    qualification = WORKSPACE / 'zotero-qualification-post-main-e594'
    result.tree(qualification, 'fresh-followup-qualification')
    result.tree(WORKSPACE / 'zotero-publication-followup-development', 'independent-review/development')
    for name in [
        'build_zotero_source_binding_v2.py',
        'build_zotero_publication_followup.py',
        'inspect_zotero_converter_kernel_inputs.py',
        'zotero-publication-followup-kernel-inspection.json',
        PRESERVATION_NAME,
    ]:
        result.file(WORKSPACE / name, 'independent-review/' + name)
    result.file(args.binding_plan, 'independent-review/' + args.binding_plan.name)
    result.file(args.continuity, 'independent-review/' + args.continuity.name)
    proof = result.report(args.source_proof)
    continuity = result.report(args.continuity)
    preservation_payload = result.read(WORKSPACE / PRESERVATION_NAME)
    if sha(preservation_payload) != PRESERVATION_SHA256:
        raise RuntimeError('Historical preservation map differs from its frozen checksum.')
    preservation = json.loads(preservation_payload)
    if preservation['followup_target'] != args.expected_source:
        raise RuntimeError('Preservation map was not prepared for this checkpoint.')
    for name, identity in preservation['protected_artifacts'].items():
        payload = result.read(RECORD / name)
        if sha(payload) != identity['sha256'] or len(payload) != identity['bytes']:
            raise RuntimeError('Historical record changed: ' + name)
    if proof is not None:
        if proof.get('schema') != 'quds-zotero-source-binding-v2' or proof.get('all_binding_checks_passed') is not True or not proof.get('checks') or not all(proof['checks'].values()):
            result.pending.append('Fresh follow-up source binding has not passed.')
        if proof.get('target_commit') != args.expected_source:
            result.pending.append('Source proof is for a different checkpoint.')
        if proof['plan']['sha256'] != sha(result.read(args.binding_plan)):
            raise RuntimeError('Source proof binds a different plan.')
        if proof['generator']['sha256'] != sha(result.read(WORKSPACE / 'build_zotero_source_binding_v2.py')):
            raise RuntimeError('Source proof generator checksum differs.')
        if set(proof['runs']) != {'engine', 'editor', 'static'}:
            raise RuntimeError('Follow-up source proof has unexpected execution scopes.')
        for name, run in proof['runs'].items():
            if run.get('recorded_checkpoint') != args.expected_source or run.get('tracked_target_mismatches') or run.get('allowed_target_mismatch_paths'):
                result.pending.append('Run does not bind exact follow-up source: ' + name)
        changed = subprocess.check_output(['git', 'diff', '--name-only', BASELINE, args.expected_source, '--', 'packages'], cwd=REPOSITORY, text=True).splitlines()
        plan = json.loads(result.read(qualification / 'plan.json'))
        selected = {'packages/quds_office_engine/' + path for path in plan['engine']}
        selected.update('packages/quds_office_editor/' + path for path in plan['editor'])
        selected.add('packages/quds_office_engine/test/fixtures/vba_conformance/word_numeric_intrinsics_v1.json')
        for path in sorted(set(changed) & selected):
            payload = subprocess.check_output(['git', 'show', args.expected_source + ':' + path], cwd=REPOSITORY)
            if payload != result.read(REPOSITORY / path):
                raise RuntimeError('Follow-up test or corpus differs from its qualified source: ' + path)
            result.add('changed-test-inputs/' + path, payload, 'git:' + args.expected_source + ':' + path)
        summary = {
            'schema': 'quds-zotero-publication-followup-archive-source-summary-v1',
            'baseline_commit': BASELINE,
            'target_commit': proof['target_commit'],
            'target_tree': proof['target_tree'],
            'external_full_source_binding': {'source': str(args.source_proof.relative_to(WORKSPACE)), 'sha256': sha(result.read(args.source_proof)), 'bytes': args.source_proof.stat().st_size, 'archived': False},
            'checks': proof['checks'],
            'all_binding_checks_passed': proof['all_binding_checks_passed'],
            'runs': {name: {key: run.get(key) for key in ['kind', 'recorded_checkpoint', 'recorded_result', 'input_count', 'tracked_target_match_count', 'tracked_target_mismatches', 'allowed_target_mismatch_paths', 'checks']} for name, run in proof['runs'].items()},
            'scope_limit': 'Only the selected engine/editor/static follow-up runs are fresh at this checkpoint. Historical 4b test totals stay historical, its four Position CLI cases remain blocked, and there is no new office-host execution. Retained converter results apply only through the independently documented exact dependency and input continuity.',
        }
        result.add('independent-review/source-binding-summary.json', json_bytes(summary), 'generated exact subset of external fresh follow-up source binding')
    if continuity is None:
        result.pending.append('Independent follow-up continuity report is not yet frozen.')
    else:
        if continuity.get('schema') != 'quds-zotero-publication-followup-continuity-v1':
            result.pending.append('Unexpected continuity report schema.')
        if continuity.get('target_commit') != args.expected_source:
            result.pending.append('Continuity report does not bind the expected checkpoint.')
        if continuity.get('all_continuity_checks_passed') is not True or not continuity.get('checks') or not all(continuity['checks'].values()):
            result.pending.append('Independent continuity checks have not passed.')
        if continuity.get('previous_execution_checkpoint') != BASELINE or (proof is not None and continuity.get('target_tree') != proof['target_tree']):
            raise RuntimeError('Continuity and fresh binding identify different source trees.')
        for key, path in [
            ('generator', WORKSPACE / 'build_zotero_publication_followup.py'),
            ('fresh_binding_plan', args.binding_plan),
            ('fresh_binding_proof', args.source_proof),
            ('kernel_byte_inspection_corroboration', WORKSPACE / 'zotero-publication-followup-kernel-inspection.json'),
        ]:
            payload = result.read(path)
            if continuity[key]['sha256'] != sha(payload) or continuity[key]['bytes'] != len(payload):
                raise RuntimeError('Continuity report input differs: ' + key)
        if len(continuity.get('preserved_validation_records', {})) != 25:
            raise RuntimeError('Continuity report does not preserve all previous validation records.')
    result.file(Path(__file__).resolve(), 'builder/' + Path(__file__).name)
    result.add('builder/collection-policy.json', json_bytes({
        'schema': 1,
        'scope': 'Bounded fresh qualification after the numeric-intrinsics and renderer merge, with independent unchanged-converter-input continuity and retained-kernel byte inspection.',
        'all_25_previous_records_preserved': True,
        'preservation_map_sha256': PRESERVATION_SHA256,
        'existing_archives_proofs_and_summaries_not_rewritten': True,
        'full_fresh_source_binding_remains_external': True,
        'new_converter_test_probe_or_application_execution_performed_by_packaging': False,
        'historical_blocked_cases_not_reclassified': True,
        'initial_audit_parser_false_positive_retained_without_qualification_credit': True,
        'excluded_directory_names': sorted(EXCLUDED),
        'allowed_file_suffixes': sorted(SUFFIXES),
        'sdk_dependencies_profiles_kernels_and_caches_excluded': True,
    }), 'generated collection policy')
    result.pending = sorted(set(result.pending))
    return result, proof


def pack(entries: list[Entry]) -> bytes:
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for entry in entries:
                metadata = tarfile.TarInfo(entry.name)
                metadata.size = len(entry.payload)
                metadata.mode = 0o644
                metadata.uid = metadata.gid = metadata.mtime = 0
                metadata.uname = metadata.gname = ''
                metadata.pax_headers = {}
                archive.addfile(metadata, io.BytesIO(entry.payload))
    return output.getvalue()


def verify(payload: bytes, entries: list[Entry]) -> None:
    expected = {entry.name: entry for entry in entries}
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
        members = archive.getmembers()
        if [member.name for member in members] != sorted(expected):
            raise RuntimeError('Archive membership or order differs.')
        for member in members:
            entry = expected[member.name]
            if not member.isfile() or member.size != len(entry.payload) or member.mode != 0o644 or member.uid or member.gid or member.mtime or member.uname or member.gname:
                raise RuntimeError('Archive metadata differs: ' + member.name)
            extracted = archive.extractfile(member)
            if extracted is None or sha(extracted.read()) != sha(entry.payload):
                raise RuntimeError('Archive payload differs: ' + member.name)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--output-dir', type=Path, default=RECORD)
    parser.add_argument('--expected-source', required=True)
    parser.add_argument('--binding-plan', type=Path, default=WORKSPACE / 'zotero-publication-followup-binding-plan.json')
    parser.add_argument('--source-proof', type=Path, default=WORKSPACE / 'zotero-publication-followup-source-binding.json')
    parser.add_argument('--continuity', type=Path, default=WORKSPACE / 'zotero-publication-followup-continuity.json')
    args = parser.parse_args()
    for key in ['binding_plan', 'source_proof', 'continuity', 'output_dir']:
        setattr(args, key, getattr(args, key).resolve())
    collection, proof = collect(args)
    entries = sorted(collection.entries.values(), key=lambda entry: entry.name)
    summary = {'mode': 'build' if args.build else 'plan-only', 'members': len(entries), 'uncompressed_bytes': sum(len(entry.payload) for entry in entries), 'pending': collection.pending}
    if args.build:
        if collection.pending or proof is None:
            raise RuntimeError('Frozen follow-up evidence is incomplete: ' + '; '.join(collection.pending))
        archive = pack(entries)
        if archive != pack(entries):
            raise RuntimeError('Deterministic rebuild differs.')
        verify(archive, entries)
        collection.unchanged()
        manifest = json_bytes({
            'schema': 1,
            'baseline_commit': BASELINE,
            'target_commit': proof['target_commit'],
            'target_tree': proof['target_tree'],
            'archive_file': ARCHIVE_NAME,
            'archive_sha256': sha(archive),
            'archive_size_bytes': len(archive),
            'entries_count': len(entries),
            'uncompressed_bytes': summary['uncompressed_bytes'],
            'deterministic_rebuild_matched': True,
            'all_archive_members_verified': True,
            'all_inputs_unchanged_during_packaging': True,
            'historical_artifacts_preserved_count': 25,
            'entries': [{'path': entry.name, 'size_bytes': len(entry.payload), 'sha256': sha(entry.payload), 'source': entry.source} for entry in entries],
        })
        outputs = [(args.output_dir / ARCHIVE_NAME, archive), (args.output_dir / MANIFEST_NAME, manifest)]
        if any(path.exists() for path, _ in outputs):
            if not all(path.is_file() and path.read_bytes() == data for path, data in outputs):
                raise FileExistsError('Different follow-up output exists; refusing to overwrite it.')
            written = False
        else:
            args.output_dir.mkdir(parents=True, exist_ok=True)
            staged = []
            try:
                for path, data in outputs:
                    temporary = path.with_name('.' + path.name + '.pending')
                    with temporary.open('xb') as stream:
                        stream.write(data)
                        stream.flush()
                        os.fsync(stream.fileno())
                    staged.append((temporary, path))
                for temporary, path in staged:
                    os.replace(temporary, path)
            finally:
                for temporary, _ in staged:
                    temporary.unlink(missing_ok=True)
            written = True
        summary.update({'archive': str(outputs[0][0]), 'archive_sha256': sha(archive), 'archive_size_bytes': len(archive), 'manifest': str(outputs[1][0]), 'manifest_sha256': sha(manifest), 'written': written, 'all_members_verified': True, 'deterministic_rebuild_matched': True, 'historical_artifacts_preserved_count': 25})
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
