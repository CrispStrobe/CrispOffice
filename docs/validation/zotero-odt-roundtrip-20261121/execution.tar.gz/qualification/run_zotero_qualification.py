import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path('/workspace/scratch/4d323337693a/quds_office_suite')
RUNTIME = Path('/workspace/scratch/4d323337693a/zotero-runtime')
OUT = Path('/workspace/scratch/4d323337693a/zotero-qualification')
OUT.mkdir(exist_ok=True)

def plan(scope):
    if scope == 'engine':
        cwd = ROOT / 'packages/quds_office_engine'
        tests = sorted(set(
            list(cwd.glob('test/odt_*_test.dart')) +
            list(cwd.glob('test/odf_zotero_*_test.dart')) +
            [cwd / ('test/' + name) for name in [
                'word_zotero_citing_test.dart',
                'word_zotero_document_data_test.dart',
                'word_zotero_preference_flow_test.dart',
                'word_zotero_bibliography_style_fidelity_test.dart',
                'word_zotero_bibliography_layout_test.dart',
                'word_zotero_formatted_bibliography_test.dart',
                'word_zotero_style_preferences_review_test.dart',
                'word_zotero_transfer_test.dart',
                'word_zotero_transfer_session_test.dart',
                'word_zotero_simple_field_test.dart',
                'word_zotero_rich_edit_test.dart',
                'word_table_cell_margin_test.dart',
                'word_table_style_precedence_test.dart',
                'word_table_style_import_regression_test.dart',
                'table_border_fidelity_test.dart',
                'office_macro_word_shading_test.dart',
                'office_vba_text_construction_test.dart',
                'office_vba_word_shading_integration_test.dart',
                'office_vba_word_shading_test.dart',
            ]]))
        prefix = ['dart', '--packages=' + str(ROOT / '.dart_tool/package_config.json'),
                  str(RUNTIME / 'test-runner/test-runner.dill'), '--concurrency=4', '--reporter=json']
    elif scope == 'editor':
        cwd = ROOT / 'packages/quds_office_editor'
        tests = [cwd / ('test/' + name) for name in [
            'word_odt_load_test.dart', 'word_odt_merged_table_load_test.dart',
            'word_zotero_citing_controller_test.dart',
            'word_zotero_bibliography_controller_test.dart',
            'word_zotero_transfer_controller_test.dart',
            'word_zotero_note_target_test.dart',
            'word_selection_paint_test.dart',
            'word_proofing_geometry_test.dart',
            'word_live_review_selection_test.dart',
        ]]
        prefix = ['flutter', 'test', '--no-pub', '--concurrency=2', '--reporter=json']
    elif scope == 'studio':
        cwd = ROOT / 'packages/quds_office_editor/example'
        tests = [cwd / ('test/' + name) for name in [
            'studio_odt_open_test.dart', 'studio_zotero_odt_export_test.dart',
            'studio_zotero_citing_transport_test.dart',
        ]]
        prefix = ['flutter', 'test', '--no-pub', '--concurrency=1', '--reporter=json']
    else:
        raise ValueError(scope)
    assert all(path.is_file() for path in tests)
    return cwd, tests, prefix + [str(path.relative_to(cwd)) for path in tests]

def snapshot(tests):
    inputs = set(tests)
    for directory in [
        'packages/quds_office_engine/lib',
        'packages/legacy_doc_parser/lib',
        'packages/quds_office_editor/lib',
        'packages/quds_office_editor/example/lib',
    ]:
        inputs.update((ROOT / directory).rglob('*.dart'))
    inputs.update(ROOT.glob('pubspec.*'))
    inputs.add(ROOT / '.fvmrc')
    inputs.add(ROOT / '.dart_tool/package_config.json')
    for path in ROOT.glob('packages/*/pubspec.yaml'):
        inputs.add(path)
    inputs.add(ROOT / 'packages/quds_office_editor/example/pubspec.yaml')
    for path in (ROOT / 'packages/quds_office_engine/test/fixtures/zotero').rglob('*'):
        if path.is_file():
            inputs.add(path)
    return {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(inputs)}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('scope', choices=['engine', 'editor', 'studio'])
    args = parser.parse_args()
    cwd, tests, command = plan(args.scope)
    dest = OUT / args.scope
    dest.mkdir(exist_ok=True)
    checkpoint = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    before = snapshot(tests)
    (dest / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
    (dest / 'command.json').write_text(json.dumps({'cwd': str(cwd), 'argv': command}, indent=2) + '\n')
    print(json.dumps({'scope': args.scope, 'files': len(tests), 'source_inputs': len(before), 'started': True}), flush=True)
    start = time.monotonic()
    with (dest / 'events.jsonl').open('w') as out, (dest / 'stderr.log').open('w') as err:
        process = subprocess.run(command, cwd=cwd, stdout=out, stderr=err)
    elapsed = time.monotonic() - start
    after = snapshot(tests)
    (dest / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
    events = []
    unknown_lines = []
    for line in (dest / 'events.jsonl').read_text().splitlines():
        try: events.append(json.loads(line))
        except json.JSONDecodeError: unknown_lines.append(line)
    names = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    cases = []
    for e in events:
        if e.get('type') != 'testDone' or e.get('hidden'):
            continue
        info = names.get(e['testID'], {})
        cases.append({'name': info.get('name'), 'suite': info.get('suiteID'),
                      'url': info.get('root_url') or info.get('url'),
                      'result': e.get('result'), 'skipped': e.get('skipped', False)})
    done = [e for e in events if e.get('type') == 'done']
    errors = [e for e in events if e.get('type') == 'error']
    receipt = {
        'scope': args.scope, 'source_checkpoint_before_run': checkpoint,
        'argv': command, 'cwd': str(cwd), 'exit_code': process.returncode,
        'elapsed_seconds': elapsed, 'test_file_count': len(tests),
        'passed': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
        'failed': sum(c['result'] != 'success' and not c['skipped'] for c in cases),
        'skipped': sum(c['skipped'] for c in cases),
        'errors': errors, 'reporter_done': done,
        'source_inputs': len(before), 'inputs_unchanged': before == after,
        'changed_inputs': sorted(k for k in before.keys() | after.keys() if before.get(k) != after.get(k)),
        'non_json_lines': unknown_lines,
    }
    (dest / 'cases.json').write_text(json.dumps(cases, indent=2) + '\n')
    (dest / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k: v for k, v in receipt.items() if k not in ['argv', 'non_json_lines', 'reporter_done']}, ensure_ascii=False), flush=True)
    if process.returncode or not done or not done[-1].get('success') or errors or before != after:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
