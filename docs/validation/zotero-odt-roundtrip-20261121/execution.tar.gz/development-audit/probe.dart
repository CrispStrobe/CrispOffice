import 'dart:io';
import 'package:quds_office_engine/quds_office_engine.dart';
Future<void> main(List<String> args) async {
 for(final path in args) {
  try {
   final document = await OdtDocumentReader.readBytes(File(path).readAsBytesSync());
   stdout.writeln('$path: imported ${WordZotero.fields(document).length} fields');
  } catch(e,st) {stdout.writeln('$path: $e\n$st');}
 }
}
