import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:quds_office_engine/quds_office_engine.dart';

const s = 'urn:oasis:names:tc:opendocument:xmlns:style:1.0';
const t = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0';
const o = 'urn:oasis:names:tc:opendocument:xmlns:office:1.0';
const f = 'urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0';
Iterable<XmlElement> elements(XmlElement root) sync* {
  yield root;
  for (final c in root.childElements) yield* elements(c);
}
XmlElement named(XmlElement root, String local, String name) => elements(root).singleWhere((e) => e.namespaceUri == s && e.localName == local && e.getAttribute('name', namespaceUri: s) == name);
XmlElement container(XmlElement root, String local) => elements(root).singleWhere((e) => e.namespaceUri == o && e.localName == local);
XmlElement config(XmlElement root) => elements(root).singleWhere((e) => e.namespaceUri == t && e.localName == 'notes-configuration' && e.getAttribute('note-class', namespaceUri: t) == 'endnote');
XmlElement fragment(String text) => XmlDocument.parse('<root xmlns:style="$s" xmlns:text="$t" xmlns:fo="$f">$text</root>').root!.childElements.single;
XmlElement markerProps(XmlElement root) => named(root, 'style', 'QudsNoteSymbol').childElements.single;
void position(XmlElement root, String value) => markerProps(root).setAttribute('text-position', value, prefix:'style', namespaceUri:s);
Uint8List rewrite(Uint8List source, void Function(XmlElement) change) {
  final zip = ZipReader.fromBytes(source);
  final writer = ZipWriter();
  for (final entry in zip.entries) {
    var data = zip.read(entry.fileName);
    if (entry.fileName == 'styles.xml') {
      final doc = XmlDocument.parse(utf8.decode(data));
      change(doc.root!);
      data = utf8.encode(doc.toXmlString());
    }
    writer.addFile(entry.fileName, data, store:entry.compressionMethod == zipMethodStore);
  }
  return writer.close();
}
Object snapshot(WmlDocument doc) => {
  'fields': [for(final field in WordZotero.fields(doc)) {'metadata':field.metadata,'cache':field.cachedText,'canEdit':field.canEdit}],
  'page': [doc.sections.single.pageSize.width,doc.sections.single.pageSize.height,doc.sections.single.margins.left,doc.sections.single.margins.right,doc.sections.single.margins.top,doc.sections.single.margins.bottom,doc.sections.single.columnCount,doc.sections.single.columnSpace].map((n)=>(n*20).round()).toList(),
  'markers': [for(final note in doc.endnotes) for(final p in note.allParagraphs) for(final m in p.inlines.whereType<WmlNoteMarker>()) m.properties.vertAlign.name],
};
Future<void> main() async {
  final original = File('/workspace/scratch/4d323337693a/zotero-roundtrip-development/attempt-8/saved-first/endnote-only.odt').readAsBytesSync();
  final expected = jsonEncode(snapshot(await OdtDocumentReader.readBytes(original)));
  final tests = <({String name,bool accept,void Function(XmlElement) change})>[];
  void add(String name,bool accept,void Function(XmlElement) fn) => tests.add((name:name,accept:accept,change:fn));
  add('native retained fixture',true,(_){ });
  add('XML whitespace canonical65',true,(r)=>position(r,'\tsuper\n65%\r'));
  add('inherited canonical65',true,(r){
    final symbol=named(r,'style','QudsNoteSymbol');
    symbol.children.clear();
    symbol.setAttribute('parent-style-name','Parent',prefix:'style',namespaceUri:s);
    container(r,'styles').addChild(fragment('<style:style style:name="Parent" style:family="text"><style:text-properties style:text-position="super 65%"/></style:style>'));
  });
  add('parent58 overridden by child65',true,(r){
    named(r,'style','QudsNoteSymbol').setAttribute('parent-style-name','Parent',prefix:'style',namespaceUri:s);
    container(r,'styles').addChild(fragment('<style:style style:name="Parent" style:family="text"><style:text-properties style:text-position="super 58%"/></style:style>'));
  });
  add('bare super refused',false,(r)=>position(r,'super'));
  add('super58 refused',false,(r)=>position(r,'super 58%'));
  add('baseline refused',false,(r)=>position(r,'0% 100%'));
  add('subscript refused',false,(r)=>position(r,'sub 65%'));
  add('NBSP token whitespace refused',false,(r)=>position(r,'super\u00a065%'));
  add('absent effective position refused',false,(r)=>named(r,'style','QudsNoteSymbol').children.clear());
  add('direct font color refused',false,(r)=>markerProps(r).setAttribute('color','#000000',prefix:'fo',namespaceUri:f));
  add('default font color refused',false,(r)=>container(r,'styles').addChild(fragment('<style:default-style style:family="text"><style:text-properties fo:color="#ff0000"/></style:default-style>')));
  add('inherited bold refused',false,(r){
    named(r,'style','QudsNoteSymbol').setAttribute('parent-style-name','Parent',prefix:'style',namespaceUri:s);
    container(r,'styles').addChild(fragment('<style:style style:name="Parent" style:family="text"><style:text-properties fo:font-weight="bold"/></style:style>'));
  });
  add('missing configured style refused',false,(r)=>config(r).setAttribute('citation-style-name','Missing',prefix:'text',namespaceUri:t));
  add('cyclic marker style refused',false,(r)=>named(r,'style','QudsNoteSymbol').setAttribute('parent-style-name','QudsNoteSymbol',prefix:'style',namespaceUri:s));
  add('duplicate text properties refused',false,(r)=>named(r,'style','QudsNoteSymbol').addChild(fragment('<style:text-properties style:text-position="super 65%"/>')));
  add('authored marker XML text refused',false,(r)=>markerProps(r).addText('authored'));
  add('nested marker property refused',false,(r)=>markerProps(r).addChild(fragment('<text:p>authored</text:p>')));
  add('different named equivalent master',true,(r){
    named(r,'master-page','Endnote').setAttribute('page-layout-name','Mpm1',prefix:'style',namespaceUri:s);
    config(r).setAttribute('master-page-name','Endnote',prefix:'text',namespaceUri:t);
  });
  add('different20mm master refused',false,(r)=>config(r).setAttribute('master-page-name','Endnote',prefix:'text',namespaceUri:t));
  add('missing master refused',false,(r)=>config(r).setAttribute('master-page-name','Missing',prefix:'text',namespaceUri:t));
  add('master stories refused',false,(r)=>named(r,'master-page','Standard').addChild(fragment('<style:header><text:p>Header</text:p></style:header>')));
  add('alternating master refused',false,(r)=>named(r,'master-page','Standard').setAttribute('next-style-name','Endnote',prefix:'style',namespaceUri:s));
  add('default note paragraph style refused',false,(r)=>config(r).setAttribute('default-style-name','Endnote',prefix:'text',namespaceUri:t));
  add('empty configured marker reference refused',false,(r)=>config(r).setAttribute('citation-style-name','',prefix:'text',namespaceUri:t));
  add('empty configured master reference refused',false,(r)=>config(r).setAttribute('master-page-name','',prefix:'text',namespaceUri:t));
  add('authored master XML text refused',false,(r)=>named(r,'master-page','Standard').addText('authored'));
  add('authored configuration XML text refused',false,(r)=>config(r).addText('authored'));
  final results=<Map<String,Object?>>[];
  for(final test in tests){
    try {
      final bytes=rewrite(original,test.change);
      final doc=await OdtDocumentReader.readBytes(bytes);
      results.add({'name':test.name,'expected':test.accept?'accept':'refuse','actual':'accept','passed':test.accept && jsonEncode(snapshot(doc)) == expected});
    } catch(e) {
      results.add({'name':test.name,'expected':test.accept?'accept':'refuse','actual':'refuse','passed':!test.accept && (e is FormatException || e is UnsupportedError),'error':e.toString()});
    }
  }
  final failures=results.where((r)=>r['passed']!=true).toList();
  File('/workspace/scratch/4d323337693a/note-marker-independent-results.json').writeAsStringSync('${const JsonEncoder.withIndent('  ').convert({'cases':results.length,'passed':results.length-failures.length,'failures':failures,'results':results})}\n');
  print(jsonEncode({'cases':results.length,'passed':results.length-failures.length,'failures':failures}));
  if(failures.isNotEmpty) exitCode=1;
}
