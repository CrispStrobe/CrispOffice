import 'dart:convert';
import 'dart:io';

import 'package:quds_office_engine/quds_office_engine.dart';

const w = OfficeNamespaces.w;

String margin(String value) => '<w:tblCellMar>'
    '${["top", "left", "bottom", "right"].map((edge) => '<w:$edge w:w="$value" w:type="dxa"/>').join()}'
    '</w:tblCellMar>';

WmlDocument document(String properties, {String styles = ''}) {
  final package = OpcPackage.create(OpcPackageKind.word);
  package.getPart('/word/document.xml')!.writeText(
    '<w:document xmlns:w="$w" xmlns:x="urn:review-extension">'
    '<w:body><w:tbl><w:tblPr>$properties</w:tblPr>'
    '<w:tblGrid><w:gridCol w:w="1440"/></w:tblGrid>'
    '<w:tr><w:tc><w:tcPr><w:tcW w:w="1440" w:type="dxa"/></w:tcPr>'
    '<w:p><w:r><w:t>Cell</w:t></w:r></w:p></w:tc></w:tr>'
    '</w:tbl></w:body></w:document>',
  );
  if (styles.isNotEmpty) {
    final xml = '<w:styles xmlns:w="$w" xmlns:x="urn:review-extension">$styles</w:styles>';
    final existing = package.getPart('/word/styles.xml');
    if (existing != null) {
      existing.writeText(xml);
    } else {
      package.createPart('/word/styles.xml', OfficeContentTypes.wordStyles, utf8.encode(xml));
    }
  }
  return WordDeserializer().read(package);
}

WmlTable table(WmlDocument document) => document.sections.single.blocks.whereType<WmlTable>().single;

void main() {
  final output = <Map<String, Object?>>[];
  final zero = '<w:style w:type="table" w:styleId="Zero"><w:tblPr>${margin("0")}</w:tblPr></w:style>';
  final cases = <({String name, String properties, String styles, double expected})>[
    (name: 'direct_zero', properties: margin('0'), styles: '', expected: 0),
    (name: 'direct_uniform_146_twips', properties: margin('146'), styles: '', expected: 7.3),
    (name: 'direct_maximum', properties: margin('32767'), styles: '', expected: 1638.35),
    (name: 'direct_overflow_stays_opaque', properties: margin('32768'), styles: '', expected: 4),
    (name: 'duplicate_containers_stay_opaque', properties: '${margin("0")}${margin("0")}', styles: '', expected: 4),
    (name: 'uniform_aliases', properties: margin(' +0000 '), styles: '', expected: 0),
    (name: 'foreign_edge_stays_opaque', properties: margin('0').replaceAll('<w:left ', '<x:left '), styles: '', expected: 4),
    (name: 'uniform_named_inheritance', properties: '<w:tblStyle w:val="Child"/>', styles: '$zero<w:style w:type="table" w:styleId="Child"><w:basedOn w:val="Zero"/></w:style>', expected: 0),
    (name: 'foreign_basedon_does_not_inherit', properties: '<w:tblStyle w:val="Child"/>', styles: '$zero<w:style w:type="table" w:styleId="Child"><x:basedOn w:val="Zero"/></w:style>', expected: 4),
    (name: 'nested_basedon_does_not_inherit', properties: '<w:tblStyle w:val="Child"/>', styles: '$zero<w:style w:type="table" w:styleId="Child"><x:extension><w:basedOn w:val="Zero"/></x:extension></w:style>', expected: 4),
    (name: 'foreign_style_does_not_inherit', properties: '<w:tblStyle w:val="Child"/>', styles: '$zero<x:style w:type="table" w:styleId="Child"><w:basedOn w:val="Zero"/></x:style>', expected: 4),
    (name: 'nested_style_does_not_inherit', properties: '<w:tblStyle w:val="Child"/>', styles: '$zero<x:extension><w:style w:type="table" w:styleId="Child"><w:basedOn w:val="Zero"/></w:style></x:extension>', expected: 4),
    (name: 'history_not_global_margin', properties: '<w:tblStyle w:val="Child"/>', styles: '<w:style w:type="table" w:styleId="Child"><w:tblPr><w:tblPrChange><w:tblPr>${margin("0")}</w:tblPr></w:tblPrChange></w:tblPr></w:style>', expected: 4),
    (name: 'sibling_extension_not_global_margin', properties: '<w:tblStyle w:val="Child"/>', styles: '<w:style w:type="table" w:styleId="Child"><w:tblPr><w:jc w:val="left"/></w:tblPr><x:extension>${margin("0")}</x:extension></w:style>', expected: 4),
    (name: 'conditional_not_global_margin', properties: '<w:tblStyle w:val="Child"/>', styles: '<w:style w:type="table" w:styleId="Child"><w:tblStylePr w:type="firstRow"><w:tblPr>${margin("0")}</w:tblPr></w:tblStylePr></w:style>', expected: 4),
    (name: 'partial_direct_blocks_parent', properties: '<w:tblStyle w:val="Zero"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/></w:tblCellMar>', styles: zero, expected: 4),
  ];
  for (final test in cases) {
    final doc = document(test.properties, styles: test.styles);
    final value = table(doc).properties.cellMargin;
    final before = table(doc).properties.sourcePropertiesXml;
    table(doc).properties.alignment = WmlJustification.center;
    final reopened = WordDeserializer().readBytes(WordSerializer().writeBytes(doc));
    final afterValue = table(reopened).properties.cellMargin;
    final beforeMargins = RegExp(r'<(?:w:)?tblCellMar[\s\S]*?</(?:w:)?tblCellMar>').allMatches(before ?? '').map((m) => m.group(0)).toList();
    final afterMargins = RegExp(r'<(?:w:)?tblCellMar[\s\S]*?</(?:w:)?tblCellMar>').allMatches(table(reopened).properties.sourcePropertiesXml ?? '').map((m) => m.group(0)).toList();
    output.add({'name': test.name, 'expected': test.expected, 'actual': value, 'afterSave': afterValue, 'opaqueSourceRetained': jsonEncode(beforeMargins) == jsonEncode(afterMargins), 'pass': value == test.expected && afterValue == test.expected && jsonEncode(beforeMargins) == jsonEncode(afterMargins)});
  }
  File('/workspace/scratch/4d323337693a/table-margin-independent-results.json').writeAsStringSync('${const JsonEncoder.withIndent('  ').convert(output)}\n');
  for (final result in output) print(jsonEncode(result));
  if (output.any((row) => row['pass'] != true)) exitCode = 1;
}
