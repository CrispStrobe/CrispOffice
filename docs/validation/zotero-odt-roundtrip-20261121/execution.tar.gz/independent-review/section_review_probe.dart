import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:quds_office_engine/quds_office_engine.dart';

const fixture = '/workspace/scratch/4d323337693a/zotero-audit-fixtures/body-bibliography.odt';
const propertyOpen = '<style:section-properties style:editable="false">';
const column = '<style:columns fo:column-count="1" fo:column-gap="0in"/>';
const styleOpen = '<style:style style:name="Sect1" style:family="section">';
const sectionOpen = '<text:section text:style-name="Sect1"';
const firstDecl = '<text:sequence-decl text:display-outline-level="0" text:name="Illustration"/>';
String once(String xml, String from, String to) {
  if (from.allMatches(xml).length != 1) throw StateError('Expected one occurrence: $from');
  return xml.replaceFirst(from, to);
}
Uint8List rewrite(Uint8List source, String Function(String) transform) {
  final zip = ZipReader.fromBytes(source);
  final writer = ZipWriter();
  for (final entry in zip.entries) {
    var data = zip.read(entry.fileName);
    if (entry.fileName == 'content.xml') data = utf8.encode(transform(utf8.decode(data)));
    writer.addFile(entry.fileName, data, store: entry.compressionMethod == zipMethodStore);
  }
  return writer.close();
}
Future<void> main() async {
  final original = File(fixture).readAsBytesSync();
  final baseline = await OdtDocumentReader.readBytes(original);
  final expectedFields = WordZotero.fields(baseline).map((f) => f.cachedText).toList();
  final cases = <({String name, bool accept, String Function(String) change})>[];
  void c(String name, bool accept, String from, String to) => cases.add((name:name,accept:accept,change:(xml)=>once(xml,from,to)));
  c('editable false numeric alias',true,propertyOpen,'<style:section-properties style:editable="0">');
  c('readonly exception refused',false,propertyOpen,'<style:section-properties style:editable="true">');
  c('style protection refused',false,propertyOpen,'<style:section-properties style:editable="false" style:protect="true">');
  c('element protection refused',false,sectionOpen,'$sectionOpen text:protected="true"');
  c('element protection false accepted',true,sectionOpen,'$sectionOpen text:protected="0"');
  c('zero section margins accepted',true,propertyOpen,'<style:section-properties style:editable="false" fo:margin-left="0pt" fo:margin-right="-0in">');
  c('active margin refused',false,propertyOpen,'<style:section-properties style:editable="false" fo:margin-left="1pt">');
  c('transparent background accepted',true,propertyOpen,'<style:section-properties style:editable="false" fo:background-color="transparent">');
  c('active background refused',false,propertyOpen,'<style:section-properties style:editable="false" fo:background-color="#000000">');
  c('positive integer aliases accepted',true,column,'<style:columns fo:column-count="+0001" fo:column-gap="0cm"/>');
  c('XML count whitespace accepted',true,column,'<style:columns fo:column-count="&#x9;+001&#xA;"/>');
  c('NBSP count whitespace refused',false,column,'<style:columns fo:column-count="&#xA0;1&#xA0;"/>');
  c('zero count refused',false,column,'<style:columns fo:column-count="0"/>');
  c('two columns refused',false,column,'<style:columns fo:column-count="2"/>');
  c('missing count refused',false,column,'<style:columns fo:column-gap="0pt"/>');
  c('active gap refused',false,column,'<style:columns fo:column-count="1" fo:column-gap="0.01in"/>');
  c('column separator refused',false,column,'<style:columns fo:column-count="1"><style:column-sep/></style:columns>');
  c('authored properties text refused',false,propertyOpen,'$propertyOpen accidental text');
  c('missing parent style refused',false,styleOpen,'<style:style style:name="Sect1" style:family="section" style:parent-style-name="Missing">');
  c('cyclic parent style refused',false,styleOpen,'<style:style style:name="Sect1" style:family="section" style:parent-style-name="Sect1">');
  c('inherited protection refused',false,styleOpen,'<style:style style:name="Base" style:family="section"><style:section-properties style:protect="true"/></style:style><style:style style:name="Sect1" style:family="section" style:parent-style-name="Base">');
  c('default active margins refused',false,styleOpen,'<style:default-style style:family="section"><style:section-properties fo:margin-left="1in"/></style:default-style>$styleOpen');
  c('unused level ten accepted',true,firstDecl,'<text:sequence-decl text:display-outline-level="10" text:name="Illustration"/>');
  c('unused large outline integer accepted',true,firstDecl,'<text:sequence-decl text:display-outline-level="123456789012345678901234567890" text:name="Illustration"/>');
  c('missing outline level refused',false,firstDecl,'<text:sequence-decl text:name="Illustration"/>');
  c('negative outline level refused',false,firstDecl,'<text:sequence-decl text:display-outline-level="-1" text:name="Illustration"/>');
  c('astral separator accepted',true,firstDecl,'<text:sequence-decl text:display-outline-level="0" text:name="Illustration" text:separation-character="😀"/>');
  c('multiple separator scalars refused',false,firstDecl,'<text:sequence-decl text:display-outline-level="0" text:name="Illustration" text:separation-character="ab"/>');
  c('empty separator refused',false,firstDecl,'<text:sequence-decl text:display-outline-level="0" text:name="Illustration" text:separation-character=""/>');
  c('authored declaration text refused',false,firstDecl,'<text:sequence-decl text:display-outline-level="0" text:name="Illustration">authored</text:sequence-decl>');
  c('NBSP declaration text refused',false,firstDecl,'<text:sequence-decl text:display-outline-level="0" text:name="Illustration">&#xA0;</text:sequence-decl>');
  final results = <Map<String,Object?>>[];
  for (final test in cases) {
    try {
      final data = rewrite(original,test.change);
      final document = await OdtDocumentReader.readBytes(data);
      final fields = WordZotero.fields(document).map((f)=>f.cachedText).toList();
      results.add({'name':test.name,'expected':test.accept?'accept':'refuse','actual':'accept','passed':test.accept && jsonEncode(fields)==jsonEncode(expectedFields),'fields':fields});
    } catch(e) {
      results.add({'name':test.name,'expected':test.accept?'accept':'refuse','actual':'refuse','passed':!test.accept && (e is UnsupportedError || e is FormatException),'error':e.toString()});
    }
  }
  final failures=results.where((r)=>r['passed']!=true).toList();
  final output={'cases':results.length,'passed':results.length-failures.length,'failures':failures,'results':results};
  File('/workspace/scratch/4d323337693a/section-review-results.json').writeAsStringSync('${const JsonEncoder.withIndent('  ').convert(output)}\n');
  print(jsonEncode({'cases':results.length,'passed':results.length-failures.length,'failures':failures}));
  if(failures.isNotEmpty)exitCode=1;
}
