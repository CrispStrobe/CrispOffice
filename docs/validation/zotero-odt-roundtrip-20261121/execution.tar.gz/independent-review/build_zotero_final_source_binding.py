#!/usr/bin/env python3
"""Read-only Git/source audit; writes only this task's scratch proof JSON."""

import hashlib
import json
import re
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

SCRATCH = Path('/workspace/scratch/4d323337693a')
ROOT = SCRATCH / 'quds_office_suite'
TARGET = 'd743c1b3e0791f7e73e5bd87638f8cd43a10fba2'
ALIAS_LOCAL = '2287f1e504fe1e9aead36e04304438057719e728'
ALIAS_CANONICAL = '9b4323500d476558a13af8194a65cec165d45da6'
CHANGED_OBSERVER = 'packages/quds_office_editor/lib/src/editor_word/render_word_canvas.dart'
OUTPUT = SCRATCH / 'zotero-final-source-binding.json'
RUNTIME_PATH = '.dart_tool/package_config.json'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_evidence(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(SCRATCH)), 'sha256': sha(data), 'bytes': len(data)}


def read_json(path):
    return json.loads(path.read_text())


def tree(commit):
    result = {}
    for item in git('ls-tree', '-r', '-z', commit).split(b'\0'):
        if not item:
            continue
        meta, path = item.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        result[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
    return result


def blob_hashes(oids):
    oids = sorted(set(oids))
    data = subprocess.check_output(
        ['git', 'cat-file', '--batch'], cwd=ROOT,
        input=('\n'.join(oids) + '\n').encode(),
    )
    at = 0
    result = {}
    for expected in oids:
        end = data.index(b'\n', at)
        oid, kind, size = data[at:end].decode().split()
        if oid != expected or kind != 'blob':
            raise RuntimeError('Unexpected git cat-file response')
        at = end + 1
        count = int(size)
        result[oid] = sha(data[at:at + count])
        at += count
        if data[at:at + 1] != b'\n':
            raise RuntimeError('Invalid git cat-file payload framing')
        at += 1
    if at != len(data):
        raise RuntimeError('Trailing git cat-file output')
    return result


def group(path, selected):
    if path == RUNTIME_PATH:
        return 'runtime_package_configuration_outside_git'
    if path.startswith('packages/quds_office_engine/lib/'):
        return 'engine_library_source_superset'
    if path.startswith('packages/legacy_doc_parser/lib/'):
        return 'legacy_library_source_superset'
    if path in selected:
        return 'selected_test_entrypoint'
    if path.startswith('packages/quds_office_engine/test/fixtures/'):
        return 'engine_fixture_artifact'
    if path.startswith('packages/quds_office_engine/test/'):
        return 'engine_test_source'
    if path.startswith('packages/quds_office_engine/tool/'):
        return 'engine_tool_source'
    if path.startswith('packages/quds_office_editor/example/lib/'):
        return 'studio_library_observed_by_broad_snapshot'
    if path.startswith('packages/quds_office_editor/lib/'):
        return 'editor_library_observed_by_broad_snapshot'
    if Path(path).name in {'.fvmrc', 'pubspec.yaml', 'pubspec.lock'}:
        return 'captured_manifest_or_sdk_pin'
    return 'other_captured_input'


head_before = git('rev-parse', 'HEAD').decode().strip()
trees = {name: tree(name) for name in [TARGET, ALIAS_CANONICAL]}
runs = {}
for name, rel, before_name, after_name in [
    ('engine_1913', 'zotero-qualification/engine', 'inputs-before.json', 'inputs-after.json'),
    ('static_engine', 'zotero-qualification/static', 'inputs-before.json', 'inputs-after.json'),
    ('converter_two_saves', 'zotero-roundtrip-development/post-merge', 'source-before.json', 'source-after.json'),
    ('converter_mixed_note_export', 'zotero-roundtrip-development/mixed-post-merge', 'source-before.json', 'source-after.json'),
]:
    directory = SCRATCH / rel
    runs[name] = {
        'directory': directory,
        'receipt': read_json(directory / 'receipt.json'),
        'before': read_json(directory / before_name),
        'after': read_json(directory / after_name),
        'evidence': [file_evidence(directory / p) for p in ['receipt.json', before_name, after_name]],
    }

pending_final_gates = []
for name in ['editor', 'studio']:
    directory = SCRATCH / f'zotero-qualification/{name}'
    paths = [directory / p for p in ['receipt.json', 'inputs-before.json', 'inputs-after.json']]
    if all(p.is_file() for p in paths):
        receipt = read_json(paths[0])
        if receipt.get('source_checkpoint_before_run') == TARGET:
            runs[f'final_{name}'] = {
                'directory': directory, 'receipt': receipt,
                'before': read_json(paths[1]), 'after': read_json(paths[2]),
                'evidence': [file_evidence(p) for p in paths],
            }
            continue
    pending_final_gates.append(name)

performance_directory = SCRATCH / 'zotero-qualification/static-performance'
performance_receipt = read_json(performance_directory / 'receipt.json')
if performance_receipt['checkpoint'] != TARGET:
    raise RuntimeError('Canvas static checks are not labeled with the target source')
runs['static_final_editor_canvas'] = {
    'directory': performance_directory,
    'receipt': performance_receipt,
    'before': {performance_receipt['file']: performance_receipt['sha256_before']},
    'after': {performance_receipt['file']: performance_receipt['sha256_after']},
    'evidence': [file_evidence(performance_directory / 'receipt.json')],
}

paths = sorted(set().union(*(set(r['before']) | set(r['after']) for r in runs.values())))
oids = [mapping[p]['oid'] for mapping in trees.values() for p in paths
        if p in mapping and mapping[p]['kind'] == 'blob']
hashes = blob_hashes(oids)
final_files = {}
for path in paths:
    entry = trees[TARGET].get(path)
    current_path = ROOT / path
    final_files[path] = {
        'git_tracked_at_target': entry is not None,
        'git_blob': entry['oid'] if entry else None,
        'git_mode': entry['mode'] if entry else None,
        'target_sha256': hashes[entry['oid']] if entry and entry['kind'] == 'blob' else None,
        'current_worktree_sha256': sha(current_path.read_bytes()) if current_path.is_file() else None,
    }

bindings = {}
for name, run in runs.items():
    before, after, receipt = run['before'], run['after'], run['receipt']
    selected = set()
    if 'argv' in receipt and 'cwd' in receipt:
        cwd = Path(receipt['cwd'])
        selected = {str((cwd / p).relative_to(ROOT)) for p in receipt['argv']
                    if p.startswith('test/') and p.endswith('.dart')}
    rows = []
    for path in sorted(set(before) | set(after)):
        final = final_files[path]
        tracked = final['git_tracked_at_target']
        rows.append({
            'path': path,
            'group': group(path, selected),
            'before_sha256': before.get(path),
            'after_sha256': after.get(path),
            'unchanged_during_run': before.get(path) == after.get(path),
            'matches_target_git_blob': before.get(path) == final['target_sha256'] if tracked else None,
            'matches_current_worktree': before.get(path) == final['current_worktree_sha256'],
        })
    mismatches = [r['path'] for r in rows if r['matches_target_git_blob'] is False]
    untracked = [r['path'] for r in rows if r['matches_target_git_blob'] is None]
    groups = {}
    for label in sorted({r['group'] for r in rows}):
        cohort = [r for r in rows if r['group'] == label]
        groups[label] = {
            'count': len(cohort),
            'unchanged_during_run': all(r['unchanged_during_run'] for r in cohort),
            'matches_target_count': sum(r['matches_target_git_blob'] is True for r in cohort),
            'matches_current_worktree_count': sum(r['matches_current_worktree'] for r in cohort),
            'target_mismatches': [r['path'] for r in cohort if r['matches_target_git_blob'] is False],
        }
    checkpoint = receipt.get('source_checkpoint_before_run', receipt.get('source_commit', receipt.get('checkpoint')))
    comparison = {
        'evidence': run['evidence'],
        'checkpoint_label_recorded_by_run': checkpoint,
        'captured_path_count': len(rows),
        'before_after_maps_identical': before == after,
        'tracked_target_match_count': sum(r['matches_target_git_blob'] is True for r in rows),
        'tracked_target_mismatches': mismatches,
        'untracked_runtime_paths': untracked,
        'groups': groups,
        'path_bindings': rows,
    }
    if 'passed' in receipt:
        comparison['reported_test_result'] = {k: receipt[k] for k in ['test_file_count', 'passed', 'failed', 'skipped', 'exit_code', 'inputs_unchanged']}
        comparison['selected_test_entrypoints'] = sorted(selected)
    if 'commands' in receipt:
        comparison['recorded_commands'] = [{k: c[k] for k in ['name', 'argv', 'exit_code'] if k in c} for c in receipt['commands']]
    if 'status' in receipt:
        comparison['reported_status'] = receipt['status']
    if name.startswith('converter_'):
        tool = next(p for p in before if p.startswith('packages/quds_office_engine/tool/'))
        captured_tool = run['directory'] / 'acceptance-source.dart'
        comparison['compiled_tool'] = {
            'repository_path': tool,
            'archived_source': file_evidence(captured_tool),
            'archived_source_matches_target': sha(captured_tool.read_bytes()) == final_files[tool]['target_sha256'],
        }
    bindings[name] = comparison

engine_run = runs['engine_1913']
engine_selected = bindings['engine_1913']['selected_test_entrypoints']
coverage = {}
for label, prefix in [('engine_libraries', 'packages/quds_office_engine/lib/'),
                      ('legacy_libraries', 'packages/legacy_doc_parser/lib/')]:
    git_paths = {p for p in trees[TARGET] if p.startswith(prefix) and p.endswith('.dart')}
    observed = {p for p in engine_run['before'] if p.startswith(prefix) and p.endswith('.dart')}
    coverage[label] = {
        'scope': prefix + '**/*.dart',
        'scope_is_complete_library_superset_not_claim_that_every_library_was_compiled': True,
        'git_path_count': len(git_paths), 'captured_path_count': len(observed),
        'missing_from_snapshot': sorted(git_paths - observed),
        'extra_snapshot_paths': sorted(observed - git_paths),
        'all_match_target': all(engine_run['before'][p] == final_files[p]['target_sha256'] for p in observed),
    }

checkpoint_differences = []
for path, captured_hash in engine_run['before'].items():
    entry = trees[ALIAS_CANONICAL].get(path)
    if entry is not None and hashes[entry['oid']] != captured_hash:
        checkpoint_differences.append({
            'path': path, 'checkpoint_sha256': hashes[entry['oid']],
            'captured_run_sha256': captured_hash,
            'target_sha256': final_files[path]['target_sha256'],
        })

# Conservative source-level dependency scan, including conditional directive
# strings. This is not represented as a compiler-emitted dependency trace.
scan_paths = sorted({p for p in final_files if p.startswith((
    'packages/quds_office_engine/lib/', 'packages/legacy_doc_parser/lib/')) and p.endswith('.dart')}
    | set(engine_selected)
    | {'packages/quds_office_engine/tool/zotero/odt_roundtrip_acceptance.dart',
       'packages/quds_office_engine/tool/zotero/odt_export_acceptance.dart'})
directive_pattern = re.compile(r'''(?m)^\s*(import|export|part)\s+(r?["'][^;]+);''')
string_pattern = re.compile(r'''["']([^"'\r\n]+)["']''')
package_names = set()
local_outside_engine = []
editor_directives = []
directives = []
for path in scan_paths:
    for match in directive_pattern.finditer((ROOT / path).read_text()):
        for uri in string_pattern.findall(match.group(2)):
            item = {'source': path, 'kind': match.group(1), 'uri': uri}
            directives.append(item)
            if uri.startswith('package:'):
                package_names.add(uri[8:].split('/')[0])
            if 'quds_office_editor' in uri or 'quds_office_studio' in uri or 'render_word_canvas' in uri:
                editor_directives.append(item)
            if not re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', uri):
                resolved = (ROOT / path).parent.joinpath(uri).resolve()
                if not any(resolved.is_relative_to(ROOT / p) for p in [
                    'packages/quds_office_engine', 'packages/legacy_doc_parser']):
                    local_outside_engine.append({**item, 'resolved': str(resolved)})

observer_before = engine_run['before'][CHANGED_OBSERVER]
observer_final = final_files[CHANGED_OBSERVER]
manifest_dependencies = {}
for manifest in ['packages/quds_office_engine/pubspec.yaml', 'packages/legacy_doc_parser/pubspec.yaml']:
    source = (ROOT / manifest).read_text()
    section = re.search(r'(?ms)^dependencies:[ \t]*\n(.*?)(?=^\S|\Z)', source)
    if section is None:
        raise RuntimeError('Missing dependency section: ' + manifest)
    manifest_dependencies[manifest] = re.findall(r'(?m)^  ([A-Za-z0-9_]+):', section.group(1))
proof = {
    'schema': 'quds-zotero-final-source-binding-v1',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'scope_statement': 'Bind recorded test and converter input bytes to the explicit final source Git tree. This proof does not assert that all 810 engine-observer paths are unchanged, does not rerun the engine suite, and does not infer a fresh full-repository test run.',
    'hash_algorithm': 'SHA-256 of exact file bytes; Git blob IDs and modes independently obtained from git ls-tree and git cat-file',
    'target': {
        'commit': TARGET,
        'tree': git('rev-parse', TARGET + '^{tree}').decode().strip(),
        'local_head_before_audit': head_before,
        'local_head_after_audit': git('rev-parse', 'HEAD').decode().strip(),
        'tracked_diff_at_audit': git('diff', '--name-only', TARGET).decode().splitlines(),
    },
    'source_alias_equivalence': {
        'local_commit': ALIAS_LOCAL,
        'canonical_commit': ALIAS_CANONICAL,
        'local_tree': git('rev-parse', ALIAS_LOCAL + '^{tree}').decode().strip(),
        'canonical_tree': git('rev-parse', ALIAS_CANONICAL + '^{tree}').decode().strip(),
        'trees_identical': git('rev-parse', ALIAS_LOCAL + '^{tree}') == git('rev-parse', ALIAS_CANONICAL + '^{tree}'),
        'git_tree_diff_paths': git('diff', '--name-only', ALIAS_LOCAL, ALIAS_CANONICAL).decode().splitlines(),
    },
    'incoming_editor_integration': {
        'main_checkpoint': git('rev-parse', '3440c90b').decode().strip(),
        'integration_parent': git('rev-parse', TARGET + '^1').decode().strip(),
        'integrated_diff_paths': git('diff', '--name-only', TARGET + '^1', TARGET).decode().splitlines(),
        'scope': 'Editor canvas cache and its roadmap only; engine/test/converter sources did not change in this merge.',
    },
    'engine_checkpoint_vs_actual_run_snapshot': {
        'explanation': 'The run checkpoint is a label, not a substitute for exact input snapshots. The observed odt_reader_styles_test.dart correction already existed during the 1913-pass run and matches the final tree.',
        'differences': checkpoint_differences,
    },
    'engine_library_coverage': coverage,
    'incidental_observer_exception': {
        'path': CHANGED_OBSERVER,
        'observed_engine_run_sha256': observer_before,
        'final_git_blob': observer_final['git_blob'],
        'final_sha256': observer_final['target_sha256'],
        'was_not_unchanged_since_engine_run': observer_before != observer_final['target_sha256'],
        'why_captured': 'run_zotero_qualification.py snapshot(tests) unconditionally hashes editor/lib and editor/example/lib for every scope, including the pure Dart engine scope.',
        'runner_source': file_evidence(SCRATCH / 'run_zotero_qualification.py'),
        'engine_dependency_evidence': {
            'method': 'Source-level scan of every engine/legacy library, all 81 engine test entrypoints, and both converter tools for import/export/part URI directives, plus package manifests. Not a compiler-emitted dependency trace.',
            'scanned_path_count': len(scan_paths),
            'scanned_paths': scan_paths,
            'directive_count': len(directives),
            'package_uri_names': sorted(package_names),
            'editor_or_studio_directives': editor_directives,
            'relative_directives_outside_engine_or_legacy': local_outside_engine,
            'manifest_runtime_dependencies': manifest_dependencies,
            'conclusion': 'The editor canvas is an incidental observed source, not a compiled engine or converter dependency; final editor and Studio reruns bind that changed source independently.',
        },
    },
    'runtime_package_configuration': {
        'repository_relative_path': RUNTIME_PATH,
        'tracked_in_final_git_tree': RUNTIME_PATH in trees[TARGET],
        'current_sha256': final_files[RUNTIME_PATH]['current_worktree_sha256'],
        'run_hashes': {name: {'before': r['before'][RUNTIME_PATH], 'after': r['after'][RUNTIME_PATH]}
                       for name, r in runs.items() if RUNTIME_PATH in r['before']},
        'interpretation': 'Exact runtime input outside Git; compared by SHA-256 to each recorded before/after snapshot, never represented as a Git blob.',
    },
    'runs': bindings,
    'final_file_bindings': final_files,
    'pending_final_gate_receipts': pending_final_gates,
}

checks = {
    'local_head_matches_target_before_and_after': proof['target']['local_head_before_audit'] == TARGET == proof['target']['local_head_after_audit'],
    'source_alias_trees_identical': proof['source_alias_equivalence']['trees_identical'],
    'all_snapshots_unchanged_during_their_runs': all(b['before_after_maps_identical'] for b in bindings.values()),
    'engine_only_target_difference_is_incidental_editor_canvas': bindings['engine_1913']['tracked_target_mismatches'] == [CHANGED_OBSERVER],
    'all_other_run_tracked_inputs_match_target': all(not b['tracked_target_mismatches'] for n, b in bindings.items() if n != 'engine_1913'),
    'all_compiled_library_supersets_complete_and_identical': all(c['all_match_target'] and not c['missing_from_snapshot'] and not c['extra_snapshot_paths'] for c in coverage.values()),
    'only_runtime_package_config_is_outside_git': all(set(b['untracked_runtime_paths']) <= {RUNTIME_PATH} for b in bindings.values()),
    'runtime_package_config_hash_unchanged': all(v['before'] == v['after'] == proof['runtime_package_configuration']['current_sha256'] for v in proof['runtime_package_configuration']['run_hashes'].values()),
    'no_editor_studio_source_dependency_directives': not editor_directives and not local_outside_engine,
    'all_captured_converter_tool_copies_match_final': all(b['compiled_tool']['archived_source_matches_target'] for b in bindings.values() if 'compiled_tool' in b),
    'current_tracked_inputs_match_target': all(v['target_sha256'] == v['current_worktree_sha256'] for v in final_files.values() if v['git_tracked_at_target']),
    'all_recorded_gate_exit_codes_successful': all(
        r['receipt'].get('exit_code', 0) == 0
        and r['receipt'].get('failed', 0) == 0
        and r['receipt'].get('status', 'passed') == 'passed'
        and all(c.get('exit_code', 0) == 0 for c in r['receipt'].get('commands', []))
        for r in runs.values()),
}
proof['checks'] = checks
proof['all_binding_checks_passed'] = all(checks.values())
OUTPUT.write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({
    'proof': str(OUTPUT), 'sha256': sha(OUTPUT.read_bytes()),
    'all_binding_checks_passed': proof['all_binding_checks_passed'],
    'checks': checks,
    'runs': {n: {k: b[k] for k in ['captured_path_count', 'tracked_target_match_count', 'tracked_target_mismatches', 'untracked_runtime_paths']} for n, b in bindings.items()},
    'pending_final_gate_receipts': pending_final_gates,
}, indent=2))
if not proof['all_binding_checks_passed']:
    raise SystemExit(1)
