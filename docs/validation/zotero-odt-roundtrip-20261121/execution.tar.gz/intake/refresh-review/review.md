# Refreshed Zotero integration audit

Captured latest main: `5c59a062e86e24d043ba06cfe8f0a69074c44f62`.
Our saved checkpoint: `bf54a8e7d976670af87dd3d36f3afc26c1821d3b`.
Initial baseline: `4970f71f983535d045ce263e86835b499db4fda9`.

This is a read-only review of refs fetched by the parent. No fetch, merge,
commit, ref/index mutation, API lookup, or GitHub Actions interaction occurred.
Source files, including the padding implementation, remain unchanged.

## Accounting

379 fetched refs (41 origin branch tips, 334 PR heads, 4 upstream branch tips;
symbolic origin/HEAD excluded) have explicit dispositions:

- 361 are ancestors of captured latest main.
- 14 historical PR heads are independently reverified equivalents: 13 complete
  Git tree identities and PR140 all37 changed paths matching mode/type/blob.
- 2 refs are our current saved checkpoint (branch and PR333).
- 1 ref is concurrent Zotero inline-image implementation WIP.
- 1 ref is concurrent Mail scheduling implementation WIP.

There are no unexplained refs. The four nonancestor, nonequivalent refs above
are explicitly pending implementation/integration, not claimed as merged.
Relative to the initial375-ref snapshot, four refs are new, three existing tips
changed, and none disappeared. Full identities and proofs are in refresh-audit.json.

## Latest main since baseline

Nine reachable commits were added, including one main first-parent merge.
The feature payload is Word VBA paragraph shading plus bounded Unicode/text
construction. Intake/validation records also preserve the concurrent planning
commits. PR334's tip26748a56 is a true ancestor of latest main.

The current Zotero checkpoint and latest main share merge base98a4d0cb.
Only two paths overlap our branch plus uncommitted source changes:

| Path | Review |
| --- | --- |
| packages/quds_office_engine/lib/src/word/serial/word_deserializer.dart | Incoming direct paragraph shading guards and automatic-fill handling touch baseline1582/1678/1681. Our margin and style reader changes start at112/129/2656+/4434+. Changed hunks are disjoint; retain both. |
| packages/quds_office_engine/CHANGELOG.md | Both insert Unreleased entries at the same position. Preserve the independent Word and Zotero entries together. |

This conclusion uses path and hunk comparison, not a merge simulation.

## Outstanding concurrent branches

### codex/zotero-roundtrip-20261121 at81e478ca

Two implementation commits are beyond main: fac61ecd (inline embedded PNG/JPEG
through editable ODT) and81e478ca (duplicate drawing names and LibreOffice inline
image styles). Its retained README still marks implementation and qualification
in progress, with no new runtime/interoperability result claimed there.

It overlaps our ODT reader, writer, reader styles and four Zotero docs. The
constructor/call change is a concrete integration collision: images add
ZipReader zip, while our reader adds qualified producer metadata. Both inputs
must survive. Image-order and atomic U+FFFC reconstruction must coexist with
note and Zotero range ownership. The table geometry writer changes and image
writer name/alt-text/span changes are separate functions. hasTextStyle and the
graphic style family are distinct from our note/section validation.

Minimum image qualification on any combined source includes its three engine
suites odt_reader_images_test.dart, odt_zotero_image_lifecycle_test.dart,
odt_image_style_review_test.dart and editor word_odt_image_load_test.dart, plus
the current ODT roundtrip and real-converter acceptance gates. The previous
source qualification cannot establish the combined implementation.

### work/mail-scheduled-send-20261121 atcb56910d

This is no longer merely the planning/intake commit71dc9cc0. It contains unique
implementation commits a4ff3da2 (durable Outbox scheduling/revision guards) and
cb56910d (foreground Send later and ten-second Undo, with the prior Word shading
continuation merged). It changes Mail core/store and six Studio source files.
Its README explicitly leaves Studio/final combined-source verification pending;
core482 and selected store107 passes are recorded. Preserve this branch as WIP
until its owner qualifies or the integration deliberately runs its required gates.

The Mail branch has multiple merge bases with latest main. A single three-dot
diff prints a warning and may include already integrated Word/docs differences;
use explicit unique commits and tree/path checks when reconciling it.

## Minimal additional final engine gate for the margin change

The existing71-suite plan already includes odt_zotero_table_geometry_test.dart.
Add these four files, each addressing a distinct affected behavior:

- word_table_cell_margin_test.dart:48 new direct/inherited/opaque ownership cases.
- word_table_style_precedence_test.dart:existing named-style border, shading and
  conditional formatting precedence through the changed table-style reader.
- word_table_style_import_regression_test.dart:legacy imported style behaviors.
- table_border_fidelity_test.dart:source-backed sparse table-property preservation,
  explicit border edits, notes, and clone/isolate saves through the same serializer.

For the incoming Word feature, include its four newly added engine suites:
office_macro_word_shading_test.dart, office_vba_text_construction_test.dart,
office_vba_word_shading_integration_test.dart, office_vba_word_shading_test.dart.
These are integration checks for incoming code, separate from padding breadth.

## Existing execution evidence

The padding change already passed103 cases across its48 new tests, ODT table
geometry, and two Word style suites; fatal-info analysis passed. Independent
reviewer probes16/16 passed. The runtime agent reports that all three table
alignments and six active citation fields now pass TWO actual LibreOffice saves
with an intervening native reopen, DOCX save/reopen and editable ODT export,
including exact margin0, geometry, field metadata/cache/editability and offsets.
That receipt is under zotero-roundtrip-development/attempt-5. Endnote qualification
remains the parent's separate ongoing scope.
