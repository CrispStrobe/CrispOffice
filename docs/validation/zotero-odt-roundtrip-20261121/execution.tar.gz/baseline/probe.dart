import 'dart:convert';
import 'dart:io';
import 'package:quds_office_engine/quds_office_engine.dart';

Future<void> main(List<String> args) async {
  var failed = false;
  for (final path in args) {
    try {
      final document = await OdtDocumentReader.readBytes(File(path).readAsBytesSync());
      stdout.writeln(jsonEncode({'file': path, 'imported': true,
        'fields': WordZotero.fields(document).length}));
    } catch (error, stack) {
      failed = true;
      stdout.writeln(jsonEncode({'file': path, 'imported': false,
        'error': error.toString(), 'stack': stack.toString()}));
    }
  }
  if (failed) exitCode = 1;
}
