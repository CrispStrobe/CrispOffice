#!/usr/bin/env python3
"""Freeze the observed main source and exercise actual LibreOffice ODT saves."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import os
import shutil
import subprocess
import tarfile
import time
import urllib.parse

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'quds_office_suite'
RUNTIME = ROOT.parent / 'zotero-runtime'
SOURCE = ROOT / 'source'
PIN = '4970f71f983535d045ce263e86835b499db4fda9'
DART = RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'
SOFFICE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/program/soffice')
SELECTED = [
    'packages/quds_office_engine/lib',
    'packages/quds_office_engine/tool/zotero/odt_export_acceptance.dart',
    'packages/quds_office_engine/pubspec.yaml',
    'packages/legacy_doc_parser/lib',
    'packages/legacy_doc_parser/pubspec.yaml',
    'pubspec.yaml',
    'pubspec.lock',
    '.fvmrc',
]
env = dict(os.environ, PUB_CACHE=str(RUNTIME / 'pub-cache'),
           FLUTTER_ROOT=str(RUNTIME / 'flutter'), CI='true',
           DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true',
           DASH__SUPPRESS_ANALYTICS='true', XDG_CONFIG_HOME=str(RUNTIME / 'config'),
           XDG_CACHE_HOME=str(RUNTIME / 'cache'), XDG_DATA_HOME=str(RUNTIME / 'data'),
           TMPDIR=str(RUNTIME / 'tmp'))
receipt = {'started_at_utc': datetime.now(timezone.utc).isoformat(),
           'status': 'running', 'source_commit': PIN, 'commands': []}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    (ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

def manifest(directory):
    return {str(p.relative_to(directory)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
            for p in sorted(directory.rglob('*')) if p.is_file()}

def run(name, argv, cwd=ROOT, expected=0):
    argv = [str(x) for x in argv]
    out = ROOT / (name + '.stdout.log')
    err = ROOT / (name + '.stderr.log')
    start = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    with out.open('wb') as stream, err.open('wb') as errors:
        result = subprocess.run(argv, cwd=cwd, env=env, stdout=stream,
                                stderr=errors, timeout=180)
    entry = {'name': name, 'argv': argv, 'cwd': str(cwd),
             'started_at_utc': started, 'seconds': round(time.monotonic() - start, 3),
             'exit_code': result.returncode,
             'stdout': out.name, 'stdout_sha256': sha(out),
             'stderr': err.name, 'stderr_sha256': sha(err)}
    receipt['commands'].append(entry)
    save()
    print(name, 'exit', result.returncode, flush=True)
    if expected is not None and result.returncode != expected:
        raise RuntimeError(name + ' exited unexpectedly: ' + err.read_text(errors='replace'))
    return entry

try:
    SOURCE.mkdir(exist_ok=True)
    archive = subprocess.check_output(['git', 'archive', PIN, '--', *SELECTED], cwd=REPO)
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:') as bundle:
        bundle.extractall(SOURCE, filter='data')
    receipt['source_tree'] = subprocess.check_output(['git', 'rev-parse', PIN + '^{tree}'], cwd=REPO, text=True).strip()
    before = manifest(SOURCE)
    (ROOT / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
    for relative in before:
        actual = subprocess.check_output(['git', 'hash-object', str(SOURCE / relative)], cwd=REPO, text=True).strip()
        expected = subprocess.check_output(['git', 'rev-parse', PIN + ':' + relative], cwd=REPO, text=True).strip()
        if actual != expected:
            raise RuntimeError('Frozen source differs: ' + relative)
    receipt['source_binding'] = {'files': len(before), 'all_match_pinned_git_blobs': True}

    original_config = REPO / '.dart_tool/package_config.json'
    package_config = json.loads(original_config.read_text())
    for package in package_config['packages']:
        package['rootUri'] = urllib.parse.urljoin(original_config.as_uri(), package['rootUri'])
        if package['name'] in ('quds_office_engine', 'legacy_doc_parser'):
            package['rootUri'] = (SOURCE / 'packages' / package['name']).as_uri() + '/'
    config = ROOT / 'package_config.json'
    config.write_text(json.dumps(package_config, indent=2) + '\n')
    receipt['package_configuration_sha256'] = sha(config)
    receipt['runtime_receipt_sha256'] = sha(RUNTIME / 'runtime.json')
    receipt['dart_binary_sha256'] = sha(DART)
    receipt['soffice_wrapper_sha256'] = sha(SOFFICE)
    receipt['soffice_binary_sha256'] = sha(SOFFICE.with_name('soffice.bin'))
    save()

    run('dart-version', [DART, '--version'])
    run('libreoffice-version', [SOFFICE, '--version'])
    tool = SOURCE / 'packages/quds_office_engine/tool/zotero/odt_export_acceptance.dart'
    prefix = [DART, '--packages=' + str(config)]
    run('create', [*prefix, tool, 'create', ROOT / 'original'])
    originals = manifest(ROOT / 'original')
    (ROOT / 'saved').mkdir(exist_ok=True)
    run('libreoffice-save', [SOFFICE,
        '-env:UserInstallation=' + (ROOT / 'profile').as_uri(),
        '--headless', '--convert-to', 'odt:writer8', '--outdir', ROOT / 'saved',
        ROOT / 'original/body-bibliography.odt', ROOT / 'original/table-notes.odt'])
    run('verify-inventory-and-note-labels', [*prefix, tool, 'verify', ROOT / 'saved', ROOT / 'original'])
    probe = ROOT / 'probe.dart'
    probe.write_text('''import 'dart:convert';
import 'dart:io';
import 'package:quds_office_engine/quds_office_engine.dart';

Future<void> main(List<String> args) async {
  var failed = false;
  for (final path in args) {
    try {
      final document = await OdtDocumentReader.readBytes(File(path).readAsBytesSync());
      stdout.writeln(jsonEncode({'file': path, 'imported': true,
        'fields': WordZotero.fields(document).length}));
    } catch (error, stack) {
      failed = true;
      stdout.writeln(jsonEncode({'file': path, 'imported': false,
        'error': error.toString(), 'stack': stack.toString()}));
    }
  }
  if (failed) exitCode = 1;
}
''')
    run('native-reopen-original', [*prefix, probe, ROOT / 'original/body-bibliography.odt', ROOT / 'original/table-notes.odt'])
    reopen = run('native-reopen-saved', [*prefix, probe, ROOT / 'saved/body-bibliography.odt', ROOT / 'saved/table-notes.odt'], expected=None)
    receipt['native_reopen_succeeded'] = reopen['exit_code'] == 0
    receipt['native_reopen_results'] = [json.loads(line) for line in (ROOT / 'native-reopen-saved.stdout.log').read_text().splitlines() if line]
    receipt['original_files'] = originals
    receipt['saved_files'] = manifest(ROOT / 'saved')
    receipt['originals_unchanged'] = originals == manifest(ROOT / 'original')
    after = manifest(SOURCE)
    (ROOT / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    receipt['source_unchanged'] = before == after
    receipt['status'] = 'baseline-recorded'
except BaseException as error:
    receipt['status'] = 'failed'
    receipt['error'] = repr(error)
    raise
finally:
    receipt['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    save()
