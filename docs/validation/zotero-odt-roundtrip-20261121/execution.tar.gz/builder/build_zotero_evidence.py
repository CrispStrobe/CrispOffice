#!/usr/bin/env python3
"""Collect this task's reproducible evidence without SDKs or build caches.

No archive is written unless --build is supplied after the final gates finish.
The default invocation reports the selected inputs only. An existing identical
archive is a no-op; replacing different output requires --replace.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

WORKSPACE = Path(__file__).resolve().parent
REPOSITORY = WORKSPACE / 'quds_office_suite'
RECORD = REPOSITORY / 'docs/validation/zotero-odt-roundtrip-20261121'
ARCHIVE_NAME = 'execution.tar.gz'
MANIFEST_NAME = 'archive-contents.json'
TOOL_PATH = 'packages/quds_office_engine/tool/zotero/odt_roundtrip_acceptance.dart'
TOOL_PREFIX = b'// Reproducible synthetic acceptance for actual LibreOffice file saves.'

EXCLUDED_DIRECTORIES = {
    '.git', '.dart_tool', '.pub-cache', '__pycache__', 'node_modules',
    'profile', 'profiles', 'flutter', 'pub-cache', 'build', 'cache',
    'test-runner', 'sdk', 'dependencies',
}
ALLOWED_SUFFIXES = {
    '.json', '.jsonl', '.log', '.stderr', '.txt', '.md', '.py', '.dart',
    '.sh', '.xml', '.odt', '.docx', '.bas', '.js', '.csv', '.tsv', '.gz',
}
RUNTIME_FILES = [
    'runtime.json', 'pub-cache-receipt.json', 'archive-members.json',
    'bootstrap_runtime.py', 'bootstrap.log', 'env.sh', 'smoke.json',
]


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()


@dataclass(frozen=True)
class Entry:
    name: str
    data: bytes
    source: str


class Collection:
    def __init__(self) -> None:
        self.entries: dict[str, Entry] = {}
        self.inputs: dict[Path, str] = {}
        self.git_inputs: dict[str, str] = {}
        self.recovered: list[dict[str, object]] = []

    def read(self, source: Path) -> bytes:
        if source.is_symlink() or not source.is_file():
            raise ValueError(f'Expected a regular evidence input: {source}')
        source = source.resolve()
        source.relative_to(WORKSPACE)
        payload = source.read_bytes()
        checksum = digest(payload)
        if source in self.inputs and self.inputs[source] != checksum:
            raise RuntimeError(f'Input changed during collection: {source}')
        self.inputs[source] = checksum
        return payload

    def add(self, name: str, payload: bytes, source: str) -> None:
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or not path.parts:
            raise ValueError(f'Unsafe archive name: {name}')
        if name in self.entries:
            raise ValueError(f'Duplicate archive name: {name}')
        self.entries[name] = Entry(name, payload, source)

    def file(self, source: Path, name: str) -> None:
        self.add(name, self.read(source), str(source.relative_to(WORKSPACE)))

    def git_file(self, revision: str, path: str, name: str) -> None:
        """Read an immutable sparse-excluded task record without a checkout."""
        reference = revision + ':' + path
        payload = subprocess.check_output(['git', 'show', reference], cwd=REPOSITORY)
        self.git_inputs[reference] = digest(payload)
        self.add(name, payload, 'git:' + reference)

    def tree(self, directory: Path, prefix: str, *, exclude_top: set[str] | None = None) -> None:
        if not directory.is_dir():
            raise FileNotFoundError(directory)
        for parent, directories, files in os.walk(directory, followlinks=False):
            parent_path = Path(parent)
            directories[:] = sorted(
                name for name in directories
                if name not in EXCLUDED_DIRECTORIES
                and not name.startswith('.')
                and not (parent_path == directory and name in (exclude_top or set()))
                and not (parent_path / name).is_symlink()
            )
            for name in sorted(files):
                source = parent_path / name
                if source.suffix.lower() not in ALLOWED_SUFFIXES:
                    continue
                if name.endswith(('.tar.gz', '.tar.xz', '.tar.zst')):
                    continue
                self.file(source, str(PurePosixPath(prefix) / source.relative_to(directory).as_posix()))

    def check_unchanged(self) -> None:
        changed = [
            str(path.relative_to(WORKSPACE))
            for path, checksum in self.inputs.items()
            if not path.is_file() or path.is_symlink() or digest(path.read_bytes()) != checksum
        ]
        if changed:
            raise RuntimeError('Evidence inputs changed during packaging: ' + ', '.join(changed))
        for reference, checksum in self.git_inputs.items():
            payload = subprocess.check_output(['git', 'show', reference], cwd=REPOSITORY)
            if digest(payload) != checksum:
                raise RuntimeError('Immutable Git input changed: ' + reference)


def recover_early_tool_sources(collection: Collection, converters: Path) -> None:
    """Recover byte-exact compiler-embedded text, never archive kernel binaries.

    The earliest three development runs recorded the tool SHA but predate the
    runner's explicit source copy. Dart kernels retain that original UTF-8
    source. A recovery is admitted only if its complete SHA matches the original
    before-manifest, preserving independently checkable evidence.
    """
    for attempt in sorted(converters.glob('attempt-*')):
        if not attempt.is_dir() or (attempt / 'acceptance-source.dart').exists():
            continue
        manifest_path = attempt / 'source-before.json'
        if not manifest_path.is_file():
            raise RuntimeError(f'Missing early attempt source manifest: {attempt}')
        manifest = json.loads(collection.read(manifest_path))
        expected = manifest[TOOL_PATH]
        kernel_path = attempt / 'acceptance.dill'
        kernel = collection.read(kernel_path)
        offset = kernel.find(TOOL_PREFIX)
        recovered: bytes | None = None
        if offset >= 0:
            candidates = kernel[offset:offset + 100_000]
            end = candidates.find(b'\n}\n')
            while end >= 0:
                payload = candidates[:end + 3]
                if digest(payload) == expected:
                    recovered = payload
                    break
                end = candidates.find(b'\n}\n', end + 1)
        if recovered is None:
            raise RuntimeError(f'Could not recover exact tool source for {attempt.name}')
        recovered.decode('utf-8')
        prefix = f'converters/{attempt.name}'
        collection.add(
            prefix + '/acceptance-source.dart', recovered,
            str(kernel_path.relative_to(WORKSPACE)) + ' (compiler-embedded source)',
        )
        receipt = {
            'method': 'Compiler-embedded UTF-8 source, matched to original input-manifest SHA-256',
            'source_manifest': str(manifest_path.relative_to(WORKSPACE)),
            'source_key': TOOL_PATH,
            'expected_sha256': expected,
            'recovered_sha256': digest(recovered),
            'recovered_bytes': len(recovered),
            'kernel_sha256': digest(kernel),
            'source_offset_in_kernel': offset,
            'kernel_archived': False,
        }
        collection.add(prefix + '/tool-source-recovery.json', json_bytes(receipt), 'generated verified recovery receipt')
        collection.recovered.append({'attempt': attempt.name, **receipt})


def collect() -> Collection:
    result = Collection()
    result.tree(WORKSPACE / 'zotero-current-converter', 'baseline', exclude_top={'source'})
    result.tree(WORKSPACE / 'zotero-roundtrip-development', 'converters')
    recover_early_tool_sources(result, WORKSPACE / 'zotero-roundtrip-development')
    result.tree(WORKSPACE / 'zotero-qualification', 'qualification')
    result.tree(WORKSPACE / 'zotero-audit-fixtures', 'development-audit')
    result.tree(WORKSPACE / 'zotero-intake-refresh-audit', 'intake/refresh-review')
    result.file(WORKSPACE / 'run_zotero_qualification.py', 'qualification/run_zotero_qualification.py')

    runtime = WORKSPACE / 'zotero-runtime'
    for name in RUNTIME_FILES:
        result.file(runtime / name, 'runtime/' + name)
    result.tree(runtime / 'logs', 'runtime/logs')

    review_paths: set[Path] = set()
    for pattern in ['*probe*.dart', '*-results.json', '*independent*.json', '*review*.md']:
        review_paths.update(path for path in WORKSPACE.glob(pattern) if path.is_file())
    for path in sorted(review_paths):
        result.file(path, 'independent-review/' + path.name)
    result.file(
        WORKSPACE / 'build_zotero_final_source_binding.py',
        'independent-review/build_zotero_final_source_binding.py',
    )

    # Initial and final intake snapshots are small task records. README,
    # final.json and source-binding documents remain owned by the root agent
    # and are deliberately excluded to avoid circular archive descriptions.
    intake_paths: set[Path] = set()
    for pattern in ['*intake*.json', '*intake*.md']:
        intake_paths.update(path for path in RECORD.glob(pattern) if path.is_file())
    # Sparse checkouts may omit previously committed intake files. Read those
    # exact immutable blobs instead of changing the index or worktree. Present
    # worktree records take precedence so the final refresh is included.
    revision = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=REPOSITORY, text=True,
    ).strip()
    record_relative = RECORD.relative_to(REPOSITORY).as_posix()
    tracked = subprocess.check_output(
        ['git', 'ls-tree', '-r', '--name-only', revision, '--', record_relative],
        cwd=REPOSITORY, text=True,
    ).splitlines()
    materialized_names = {path.name for path in intake_paths}
    for path in tracked:
        relative = PurePosixPath(path)
        if relative.parent.as_posix() != record_relative:
            continue
        if 'intake' not in relative.name or relative.suffix not in {'.json', '.md'}:
            continue
        if relative.name not in materialized_names:
            result.git_file(revision, path, 'intake/' + relative.name)
            materialized_names.add(relative.name)
    if 'initial-intake.json' not in materialized_names:
        raise RuntimeError('Initial remote-ref intake is missing from the worktree and Git.')
    for path in sorted(intake_paths):
        result.file(path, 'intake/' + path.name)
    result.file(RECORD / 'final-refs.txt', 'intake/final-refs.txt')

    result.file(Path(__file__).resolve(), 'builder/build_zotero_evidence.py')
    result.add('builder/collection-policy.json', json_bytes({
        'schema': 1,
        'baseline_source_commit': '4970f71f983535d045ce263e86835b499db4fda9',
        'baseline_source_copy_excluded': True,
        'baseline_source_reconstruction': 'Use the pinned Git commit and baseline/source-before.json; all 436 files were verified against their Git blobs.',
        'excluded_directory_names': sorted(EXCLUDED_DIRECTORIES),
        'allowed_file_suffixes': sorted(ALLOWED_SUFFIXES),
        'compiled_kernels_excluded': True,
        'nested_archives_excluded': True,
        'sdk_and_dependencies_excluded': True,
        'profiles_and_build_caches_excluded': True,
        'early_tool_source_recovery': result.recovered,
        'scope': 'Exact task fixtures, command logs, raw test events/cases, source manifests, runtime/package receipts, independent probes, incoming-ref accounting and failed developmental attempts.',
    }), 'generated collection policy')
    return result


def pack(entries: list[Entry]) -> bytes:
    destination = io.BytesIO()
    with gzip.GzipFile(fileobj=destination, mode='wb', filename='', mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for entry in sorted(entries, key=lambda item: item.name):
                metadata = tarfile.TarInfo(entry.name)
                metadata.size = len(entry.data)
                metadata.mode = 0o644
                metadata.uid = metadata.gid = 0
                metadata.uname = metadata.gname = ''
                metadata.mtime = 0
                metadata.pax_headers = {}
                archive.addfile(metadata, io.BytesIO(entry.data))
    return destination.getvalue()


def verify_archive(payload: bytes, entries: list[Entry]) -> None:
    expected = {entry.name: entry for entry in entries}
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
        members = archive.getmembers()
        if [member.name for member in members] != sorted(expected):
            raise RuntimeError('Archive membership/order differs from the input manifest.')
        for member in members:
            if not member.isfile() or member.size != len(expected[member.name].data):
                raise RuntimeError('Archive member type/size mismatch: ' + member.name)
            stream = archive.extractfile(member)
            if stream is None or digest(stream.read()) != digest(expected[member.name].data):
                raise RuntimeError('Archive member checksum mismatch: ' + member.name)


def write_outputs(directory: Path, archive: bytes, manifest: bytes, *, replace: bool) -> bool:
    archive_path = directory / ARCHIVE_NAME
    manifest_path = directory / MANIFEST_NAME
    if archive_path.is_file() and manifest_path.is_file():
        if archive_path.read_bytes() == archive and manifest_path.read_bytes() == manifest:
            return False
    if not replace and (archive_path.exists() or manifest_path.exists()):
        raise FileExistsError('Evidence output exists with different bytes; select a new directory or use --replace.')
    directory.mkdir(parents=True, exist_ok=True)
    staged = [(archive_path, archive), (manifest_path, manifest)]
    temporary: list[tuple[Path, Path]] = []
    try:
        for target, payload in staged:
            path = target.with_name('.' + target.name + '.pending')
            with path.open('xb') as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            temporary.append((path, target))
        for path, target in temporary:
            os.replace(path, target)
    finally:
        for path, _ in temporary:
            path.unlink(missing_ok=True)
    return True


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true', help='Write archive after final gates are complete; omission is a read-only plan.')
    parser.add_argument('--output-dir', type=Path, default=RECORD)
    parser.add_argument('--replace', action='store_true', help='Replace different previous output explicitly.')
    args = parser.parse_args()
    collection = collect()
    entries = sorted(collection.entries.values(), key=lambda item: item.name)
    counts: dict[str, dict[str, int]] = {}
    for entry in entries:
        group = entry.name.split('/', 1)[0]
        summary = counts.setdefault(group, {'files': 0, 'bytes': 0})
        summary['files'] += 1
        summary['bytes'] += len(entry.data)
    result: dict[str, object] = {
        'mode': 'build' if args.build else 'plan-only',
        'files': len(entries),
        'uncompressed_bytes': sum(len(entry.data) for entry in entries),
        'groups': counts,
        'recovered_tool_sources': [entry['attempt'] for entry in collection.recovered],
    }
    if args.build:
        payload = pack(entries)
        if payload != pack(entries):
            raise RuntimeError('Repeated deterministic builds differ.')
        verify_archive(payload, entries)
        collection.check_unchanged()
        manifest = {
            'schema': 1,
            'archive_file': ARCHIVE_NAME,
            'archive_size_bytes': len(payload),
            'archive_sha256': digest(payload),
            'entries_count': len(entries),
            'uncompressed_bytes': result['uncompressed_bytes'],
            'deterministic_rebuild_matched': True,
            'all_archive_members_verified': True,
            'all_inputs_unchanged_during_packaging': True,
            'entries': [
                {'path': entry.name, 'size_bytes': len(entry.data), 'sha256': digest(entry.data), 'source': entry.source}
                for entry in entries
            ],
        }
        manifest_payload = json_bytes(manifest)
        changed = write_outputs(args.output_dir, payload, manifest_payload, replace=args.replace)
        result.update({
            'written': changed,
            'archive': str(args.output_dir / ARCHIVE_NAME),
            'manifest': str(args.output_dir / MANIFEST_NAME),
            'archive_size_bytes': len(payload),
            'archive_sha256': digest(payload),
            'manifest_sha256': digest(manifest_payload),
        })
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
