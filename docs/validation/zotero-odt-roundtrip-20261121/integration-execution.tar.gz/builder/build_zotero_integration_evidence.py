#!/usr/bin/env python3
"""Package only fresh combined-source evidence, preserving the prior milestone.

The default invocation is read-only planning. --build is permitted only after
all required test, converter, static, binding and intake records are complete.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import tarfile

WORKSPACE = Path(__file__).resolve().parent
REPOSITORY = WORKSPACE / 'quds_office_suite'
RECORD = REPOSITORY / 'docs/validation/zotero-odt-roundtrip-20261121'
TARGET = 'bb2dfd5272ff8de27ed2ec7f68b71801a2e41886'
TREE = '5fadc8755a09f06cd1ba3c47a147e05c333258e0'
ARCHIVE_NAME = 'integration-execution.tar.gz'
MANIFEST_NAME = 'integration-archive-contents.json'
RUNS = ['integrated-bb2dfd52', 'mixed-integrated-bb2dfd52', 'images-integrated-bb2dfd52']
PROTECTED = {
    'execution.tar.gz': '0cda5b93c032ca4a0dc539e31733cff4cf6162e1c0dc08a380094e401ed4ab0a',
    'archive-contents.json': 'c878e2e371339730345fe8d9efa095a0e55a8ec983a22817f31a0786c3cb7300',
    'source-binding.json': 'ba02035589ddd6566a6479bd40aaf1f9c46abe26e7d595da3748e03f8fc36ea0',
}
EXCLUDED = {'.git', '.dart_tool', '.pub-cache', '__pycache__', 'node_modules', 'profile', 'profiles', 'flutter', 'pub-cache', 'build', 'cache', 'test-runner', 'sdk', 'dependencies'}
SUFFIXES = {'.json', '.jsonl', '.log', '.stdout', '.stderr', '.txt', '.md', '.py', '.dart', '.sh', '.xml', '.odt', '.docx'}


def digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()


@dataclass(frozen=True)
class Entry:
    name: str
    payload: bytes
    source: str


class Collection:
    def __init__(self) -> None:
        self.entries: dict[str, Entry] = {}
        self.inputs: dict[Path, str] = {}
        self.pending: list[str] = []

    def read(self, path: Path) -> bytes:
        if path.is_symlink() or not path.is_file():
            raise ValueError(f'Expected regular evidence file: {path}')
        path = path.resolve()
        path.relative_to(WORKSPACE)
        payload = path.read_bytes()
        checksum = digest(payload)
        if path in self.inputs and self.inputs[path] != checksum:
            raise RuntimeError(f'Evidence changed while collecting: {path}')
        self.inputs[path] = checksum
        return payload

    def add(self, name: str, payload: bytes, source: str) -> None:
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or not path.parts or name in self.entries:
            raise ValueError(f'Unsafe or duplicate member: {name}')
        self.entries[name] = Entry(name, payload, source)

    def file(self, path: Path, name: str, *, required: bool = True) -> None:
        if not path.exists():
            if required:
                self.pending.append(str(path.relative_to(WORKSPACE)))
            return
        self.add(name, self.read(path), str(path.relative_to(WORKSPACE)))

    def tree(self, directory: Path, prefix: str) -> None:
        if not directory.is_dir():
            self.pending.append(str(directory.relative_to(WORKSPACE)))
            return
        for parent, directories, files in os.walk(directory, followlinks=False):
            current = Path(parent)
            directories[:] = sorted(name for name in directories if name not in EXCLUDED and not name.startswith('.') and not (current/name).is_symlink())
            for name in sorted(files):
                path = current/name
                if path.suffix.lower() in SUFFIXES:
                    self.file(path, prefix + '/' + path.relative_to(directory).as_posix())

    def unchanged(self) -> None:
        changed = [str(path.relative_to(WORKSPACE)) for path, expected in self.inputs.items() if not path.is_file() or path.is_symlink() or digest(path.read_bytes()) != expected]
        if changed:
            raise RuntimeError('Evidence changed during packaging: ' + ', '.join(changed))

    def receipt(self, path: Path) -> dict[str, object] | None:
        if not path.is_file():
            self.pending.append(str(path.relative_to(WORKSPACE)))
            return None
        return json.loads(self.read(path))


def collect(args: argparse.Namespace) -> Collection:
    result = Collection()
    qualification = WORKSPACE/'zotero-qualification-main2058'
    result.tree(qualification, 'qualification')
    for name in ['run_zotero_qualification_main2058.py', 'run_zotero_static_main2058.py']:
        member = 'qualification/' + name
        if member in result.entries:
            if result.entries[member].payload != result.read(WORKSPACE/name):
                raise RuntimeError('Captured qualification runner differs from its source: ' + name)
        else:
            result.file(WORKSPACE/name, member)
    for name in RUNS:
        result.tree(WORKSPACE/'zotero-roundtrip-development'/name, 'converters/' + name)
    result.file(WORKSPACE/'build_zotero_source_binding_v2.py', 'independent-review/build_zotero_source_binding_v2.py')
    result.file(args.binding_plan, 'independent-review/' + args.binding_plan.name)
    for path in sorted(RECORD.glob('integration-intake*')):
        if path.is_file() and path.suffix in {'.json', '.md', '.txt'}:
            result.file(path, 'intake/' + path.name)
    result.file(RECORD/'integration-refs.txt', 'intake/integration-refs.txt', required=False)
    if 'intake/integration-intake.json' not in result.entries:
        result.pending.append('Integration intake JSON is not yet present in the validation record.')

    for name, expected in PROTECTED.items():
        if digest(result.read(RECORD/name)) != expected:
            raise RuntimeError('Historical artifact changed: ' + name)

    for scope in ['engine', 'editor', 'studio']:
        receipt = result.receipt(qualification/scope/'receipt.json')
        if receipt is not None:
            valid = receipt.get('source_checkpoint_before_run') == TARGET and receipt.get('exit_code') == 0 and receipt.get('passed', 0) > 0 and receipt.get('failed') == 0 and receipt.get('skipped') == 0 and not receipt.get('errors') and receipt.get('inputs_unchanged') is True and not receipt.get('changed_inputs')
            if not valid:
                result.pending.append('Incomplete or failing ' + scope + ' test gate.')
    static = result.receipt(qualification/'static/receipt.json')
    if static is not None:
        if static.get('source_checkpoint_before_run') != TARGET or static.get('passed') is not True or static.get('inputs_unchanged') is not True or not static.get('checks') or not all(check.get('exit_code') == 0 for check in static['checks']):
            result.pending.append('Incomplete or failing static gate.')
    for name in RUNS:
        receipt = result.receipt(WORKSPACE/'zotero-roundtrip-development'/name/'receipt.json')
        if receipt is None:
            continue
        valid = receipt.get('source_commit') == TARGET and receipt.get('status') == 'passed' and receipt.get('source_unchanged') is True and not receipt.get('source_changes') and receipt.get('commands') and all(command.get('exit_code') == 0 for command in receipt['commands'])
        if name.startswith('images-'):
            valid = valid and bool(receipt.get('inputs_unchanged')) and all(receipt['inputs_unchanged'].values())
        elif name.startswith('mixed-'):
            valid = valid and receipt.get('originals_unchanged') is True
        else:
            valid = valid and receipt.get('original_fixtures_unchanged') is True and receipt.get('reexported_fixtures_unchanged') is True
        if not valid:
            result.pending.append('Incomplete or failing converter ' + name)

    proof = result.receipt(args.binding_proof)
    proof_summary = None
    if proof is not None:
        valid = proof.get('schema') == 'quds-zotero-source-binding-v2' and proof.get('target_commit') == TARGET and proof.get('target_tree') == TREE and proof.get('all_binding_checks_passed') is True and bool(proof.get('checks')) and all(proof['checks'].values())
        if not valid:
            result.pending.append('Final integration source binding has not passed.')
        proof_summary = {'path': str(args.binding_proof.relative_to(WORKSPACE)), 'sha256': digest(result.read(args.binding_proof)), 'bytes': args.binding_proof.stat().st_size, 'full_proof_archived': False, 'all_binding_checks_passed': proof.get('all_binding_checks_passed')}
    result.file(Path(__file__).resolve(), 'builder/build_zotero_integration_evidence.py')
    result.add('builder/collection-policy.json', json_bytes({
        'schema': 1, 'target_commit': TARGET, 'target_tree': TREE,
        'scope': 'Fresh combined-source qualification and three actual converter runs only; prior milestone evidence remains unchanged in its separate archive.',
        'historical_artifacts_preserved': PROTECTED,
        'external_binding_proof': proof_summary,
        'excluded_directory_names': sorted(EXCLUDED), 'allowed_file_suffixes': sorted(SUFFIXES),
        'sdk_dependencies_profiles_kernels_and_caches_excluded': True,
        'old_evidence_not_duplicated': True,
    }), 'generated collection policy')
    result.pending = sorted(set(result.pending))
    return result


def pack(entries: list[Entry]) -> bytes:
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for entry in entries:
                metadata = tarfile.TarInfo(entry.name)
                metadata.size = len(entry.payload)
                metadata.mode = 0o644
                metadata.uid = metadata.gid = metadata.mtime = 0
                metadata.uname = metadata.gname = ''
                metadata.pax_headers = {}
                archive.addfile(metadata, io.BytesIO(entry.payload))
    return output.getvalue()


def verify(payload: bytes, entries: list[Entry]) -> None:
    expected = {entry.name: entry for entry in entries}
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
        members = archive.getmembers()
        if [member.name for member in members] != sorted(expected):
            raise RuntimeError('Archive member order or membership mismatch.')
        for member in members:
            entry = expected[member.name]
            if not member.isfile() or member.size != len(entry.payload) or member.mode != 0o644 or member.uid != 0 or member.gid != 0 or member.mtime != 0 or member.uname or member.gname:
                raise RuntimeError('Archive metadata mismatch: ' + member.name)
            extracted = archive.extractfile(member)
            if extracted is None or digest(extracted.read()) != digest(entry.payload):
                raise RuntimeError('Archive member checksum mismatch: ' + member.name)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--output-dir', type=Path, default=RECORD)
    parser.add_argument('--binding-plan', type=Path, default=WORKSPACE/'zotero-source-binding-bb2dfd52-plan.json')
    parser.add_argument('--binding-proof', type=Path, default=WORKSPACE/'zotero-source-binding-bb2dfd52.json')
    args = parser.parse_args()
    args.binding_plan = args.binding_plan.resolve()
    args.binding_proof = args.binding_proof.resolve()
    collection = collect(args)
    entries = sorted(collection.entries.values(), key=lambda entry: entry.name)
    summary = {'mode': 'build' if args.build else 'plan-only', 'members': len(entries), 'uncompressed_bytes': sum(len(entry.payload) for entry in entries), 'pending': collection.pending}
    if args.build:
        if collection.pending:
            raise RuntimeError('Required final evidence is incomplete: ' + '; '.join(collection.pending))
        archive = pack(entries)
        if archive != pack(entries):
            raise RuntimeError('Deterministic rebuild produced different bytes.')
        verify(archive, entries)
        collection.unchanged()
        manifest = json_bytes({
            'schema': 1, 'target_commit': TARGET, 'target_tree': TREE,
            'archive_file': ARCHIVE_NAME, 'archive_sha256': digest(archive), 'archive_size_bytes': len(archive),
            'entries_count': len(entries), 'uncompressed_bytes': summary['uncompressed_bytes'],
            'deterministic_rebuild_matched': True, 'all_archive_members_verified': True,
            'all_inputs_unchanged_during_packaging': True, 'historical_artifacts_unchanged': True,
            'entries': [{'path': entry.name, 'size_bytes': len(entry.payload), 'sha256': digest(entry.payload), 'source': entry.source} for entry in entries],
        })
        args.output_dir.mkdir(parents=True, exist_ok=True)
        outputs = [(args.output_dir/ARCHIVE_NAME, archive), (args.output_dir/MANIFEST_NAME, manifest)]
        if any(path.exists() for path, _ in outputs):
            if not all(path.is_file() and path.read_bytes() == data for path, data in outputs):
                raise FileExistsError('Different integration output exists; it will not be overwritten.')
            written = False
        else:
            staged = []
            try:
                for path, data in outputs:
                    temporary = path.with_name('.' + path.name + '.pending')
                    with temporary.open('xb') as stream:
                        stream.write(data)
                        stream.flush()
                        os.fsync(stream.fileno())
                    staged.append((temporary, path))
                for temporary, path in staged:
                    os.replace(temporary, path)
            finally:
                for temporary, _ in staged:
                    temporary.unlink(missing_ok=True)
            written = True
        collection.unchanged()
        summary.update({'written': written, 'archive': str(args.output_dir/ARCHIVE_NAME), 'manifest': str(args.output_dir/MANIFEST_NAME), 'archive_sha256': digest(archive), 'archive_size_bytes': len(archive), 'manifest_sha256': digest(manifest)})
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
