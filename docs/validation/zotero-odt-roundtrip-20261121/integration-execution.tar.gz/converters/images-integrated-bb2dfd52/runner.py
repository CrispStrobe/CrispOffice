#!/usr/bin/env python3
"""Qualify the repository's native PNG/JPEG Zotero tool through real saves."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / sys.argv[1]
REPO = ROOT.parent / 'quds_office_suite'
RUNTIME = ROOT.parent / 'zotero-runtime'
DART = RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'
SOFFICE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/program/soffice')
TOOL = REPO / 'packages/quds_office_engine/tool/zotero/odt_image_acceptance.dart'
CONFIG = REPO / '.dart_tool/package_config.json'
NAMES = ['png-citations', 'jpeg-citations']
EXPECTED_SOURCE = sys.argv[2] if len(sys.argv) > 2 else None
COMMIT = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
if EXPECTED_SOURCE is not None and COMMIT != EXPECTED_SOURCE:
    raise RuntimeError('Source checkpoint differs from requested immutable checkpoint.')
if not TOOL.is_file():
    raise FileNotFoundError(TOOL)
OUT.mkdir(exist_ok=False)
env = dict(os.environ, PUB_CACHE=str(RUNTIME/'pub-cache'), FLUTTER_ROOT=str(RUNTIME/'flutter'), CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true', DASH__SUPPRESS_ANALYTICS='true', XDG_CONFIG_HOME=str(RUNTIME/'config'), XDG_CACHE_HOME=str(RUNTIME/'cache'), XDG_DATA_HOME=str(RUNTIME/'data'), TMPDIR=str(RUNTIME/'tmp'))
receipt = {
    'started_at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'running',
    'scope': 'Two synthetic PNG/JPEG fixtures, each with two native pictures and two active citations. First actual LibreOffice save, three native DOCX/ODT cycles, byte-identical copies of final reexports into a second actual save, then three further native DOCX/ODT cycles against the original authored model. No installed Zotero plugin or live CSL session is exercised.',
    'source_commit': COMMIT,
    'commands': [],
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(directory):
    return {p.name: sha(p) for p in sorted(directory.glob('*')) if p.is_file()}


def source():
    paths = [TOOL, CONFIG, REPO/'pubspec.lock', REPO/'pubspec.yaml']
    for package in ['quds_office_engine', 'legacy_doc_parser']:
        paths += list((REPO/'packages'/package/'lib').rglob('*.dart'))
        paths.append(REPO/'packages'/package/'pubspec.yaml')
    return {str(p.relative_to(REPO)): sha(p) for p in sorted(set(paths))}


def save():
    (OUT/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')


def run(name, args):
    args = list(map(str, args))
    started = time.monotonic()
    output = OUT/(name+'.stdout.log')
    errors = OUT/(name+'.stderr.log')
    with output.open('wb') as stdout, errors.open('wb') as stderr:
        result = subprocess.run(args, cwd=REPO, env=env, stdout=stdout, stderr=stderr, timeout=180)
    receipt['commands'].append({
        'name': name, 'argv': args, 'cwd': str(REPO),
        'exit_code': result.returncode, 'seconds': round(time.monotonic()-started, 3),
        'stdout': output.name, 'stdout_sha256': sha(output),
        'stderr': errors.name, 'stderr_sha256': sha(errors),
    })
    save()
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise RuntimeError(name+': '+errors.read_text(errors='replace')[-10000:])


def convert(name, source_directory, destination):
    destination.mkdir(exist_ok=False)
    run(name, [SOFFICE, '-env:UserInstallation='+(OUT/'profile').as_uri(), '--headless', '--convert-to', 'odt:writer8', '--outdir', destination, *[source_directory/(n+'.odt') for n in NAMES]])


before = source()
(OUT/'source-before.json').write_text(json.dumps(before, indent=2)+'\n')
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
(OUT/'acceptance-source.dart').write_bytes(TOOL.read_bytes())
receipt['runtime_receipt_sha256'] = sha(RUNTIME/'runtime.json')
receipt['soffice_binary_sha256'] = sha(SOFFICE.with_name('soffice.bin'))
observed_inputs = {}
try:
    run('dart-version', [DART, '--version'])
    run('libreoffice-version', [SOFFICE, '--version'])
    run('compile', [DART, 'compile', 'kernel', '--packages='+str(CONFIG), TOOL, '-o', OUT/'acceptance.dill'])
    prefix = [DART, '--packages='+str(CONFIG), OUT/'acceptance.dill']
    run('create', [*prefix, 'create', OUT/'original'])
    observed_inputs['original'] = inventory(OUT/'original')
    convert('libreoffice-first-save', OUT/'original', OUT/'saved-first')
    observed_inputs['saved-first'] = inventory(OUT/'saved-first')
    run('verify-first-and-three-native-cycles', [*prefix, 'verify', OUT/'saved-first', OUT/'original', OUT/'reexported-first'])
    observed_inputs['reexported-first'] = inventory(OUT/'reexported-first')
    second_input = OUT/'second-save-input'
    second_input.mkdir(exist_ok=False)
    copies = []
    for name in NAMES:
        original = OUT/'reexported-first'/(name+'-cycle-2.odt')
        target = second_input/(name+'.odt')
        target.write_bytes(original.read_bytes())
        assert sha(target) == sha(original)
        copies.append({'source': str(original.relative_to(OUT)), 'target': str(target.relative_to(OUT)), 'sha256': sha(target), 'byte_identical': True})
    receipt['second_save_input_copies'] = copies
    observed_inputs['second-save-input'] = inventory(second_input)
    convert('libreoffice-second-save', second_input, OUT/'saved-second')
    observed_inputs['saved-second'] = inventory(OUT/'saved-second')
    run('verify-second-and-three-native-cycles', [*prefix, 'verify', OUT/'saved-second', OUT/'original', OUT/'reexported-second'])
    receipt['status'] = 'passed'
except BaseException as error:
    receipt['status'] = 'failed'
    receipt['error'] = repr(error)
    raise
finally:
    after = source()
    (OUT/'source-after.json').write_text(json.dumps(after, indent=2)+'\n')
    receipt['source_unchanged'] = before == after
    receipt['source_changes'] = [p for p in sorted(before.keys() | after.keys()) if before.get(p) != after.get(p)]
    receipt['input_hashes_before'] = observed_inputs
    receipt['inputs_unchanged'] = {name: expected == inventory(OUT/name) for name, expected in observed_inputs.items()}
    if receipt['status'] == 'passed' and (not receipt['source_unchanged'] or not all(receipt['inputs_unchanged'].values())):
        receipt['status'] = 'failed'
        receipt['error'] = 'Observed source or fixture input changed during qualification.'
    receipt['artifacts'] = {str(p.relative_to(OUT)): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file() and p.suffix in ['.odt', '.docx', '.json', '.dart', '.log', '.py'] and 'profile' not in p.parts and p.name != 'receipt.json'}
    receipt['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    save()
if receipt['status'] != 'passed':
    raise RuntimeError(receipt.get('error', 'Qualification did not pass.'))
