#!/usr/bin/env python3
"""Mixed notes: actual export/save inventories; no native footnote import."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, sys, time, xml.etree.ElementTree as ET, zipfile

ROOT=Path(__file__).resolve().parent
OUT=ROOT/sys.argv[1]
REPO=ROOT.parent/'quds_office_suite'
RUNTIME=ROOT.parent/'zotero-runtime'
DART=RUNTIME/'flutter/bin/cache/dart-sdk/bin/dart'
SOFFICE=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/program/soffice')
TOOL=REPO/'packages/quds_office_engine/tool/zotero/odt_export_acceptance.dart'
CONFIG=REPO/'.dart_tool/package_config.json'
OUT.mkdir(exist_ok=False)
env=dict(os.environ,PUB_CACHE=str(RUNTIME/'pub-cache'),FLUTTER_ROOT=str(RUNTIME/'flutter'),CI='true',DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true',DASH__SUPPRESS_ANALYTICS='true',XDG_CONFIG_HOME=str(RUNTIME/'config'),XDG_CACHE_HOME=str(RUNTIME/'cache'),XDG_DATA_HOME=str(RUNTIME/'data'),TMPDIR=str(RUNTIME/'tmp'))
receipt={'started_at_utc':datetime.now(timezone.utc).isoformat(),'status':'running','scope':'Synthetic mixed footnote/endnote export and actual LibreOffice save, complete native inventories and all four note character-style references; native footnote reopening is not exercised or claimed.','commands':[]}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source():
    paths=[TOOL,CONFIG,REPO/'pubspec.lock',REPO/'pubspec.yaml']
    for package in ['quds_office_engine','legacy_doc_parser']:
        paths+=list((REPO/'packages'/package/'lib').rglob('*.dart'))
        paths.append(REPO/'packages'/package/'pubspec.yaml')
    return {str(p.relative_to(REPO)):sha(p) for p in sorted(set(paths))}
def save():(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(name,args):
    args=list(map(str,args)); start=time.monotonic(); out=OUT/(name+'.stdout.log');err=OUT/(name+'.stderr.log')
    with out.open('wb') as stdout,err.open('wb') as stderr:
        result=subprocess.run(args,cwd=REPO,env=env,stdout=stdout,stderr=stderr,timeout=180)
    receipt['commands'].append({'name':name,'argv':args,'cwd':str(REPO),'exit_code':result.returncode,'seconds':round(time.monotonic()-start,3),'stdout':out.name,'stdout_sha256':sha(out),'stderr':err.name,'stderr_sha256':sha(err)})
    save();print(name,result.returncode,flush=True)
    if result.returncode:raise RuntimeError(name+': '+err.read_text(errors='replace')[-10000:])
def note_styles(path):
    text='urn:oasis:names:tc:opendocument:xmlns:text:1.0';style='urn:oasis:names:tc:opendocument:xmlns:style:1.0'
    with zipfile.ZipFile(path) as z:
        root=ET.fromstring(z.read('styles.xml'))
        result={};names=[]
        for c in root.iter('{'+text+'}notes-configuration'):
            kind=c.attrib.get('{'+text+'}note-class')
            if kind not in ['footnote','endnote']:raise ValueError('Unknown note configuration')
            if kind in result:raise ValueError('Duplicate configuration')
            result[kind]={}
            for role in ['citation-style-name','citation-body-style-name']:
                name=c.attrib.get('{'+text+'}'+role)
                if not name:raise ValueError('Missing '+kind+' '+role)
                matches=[s for s in root.iter('{'+style+'}style') if s.attrib.get('{'+style+'}family')=='text' and s.attrib.get('{'+style+'}name')==name]
                if len(matches)!=1:raise ValueError('Ambiguous note style '+name)
                props=list(matches[0].iter('{'+style+'}text-properties'))
                if len(props)!=1:raise ValueError('Missing note text properties '+name)
                position=props[0].attrib.get('{'+style+'}text-position')
                if position!='super 65%':raise ValueError('Changed note position '+name+': '+str(position))
                result[kind][role]={'name':name,'text-position':position};names.append(name)
        if set(result)!=set(['footnote','endnote']) or len(set(names))!=4:
            raise ValueError('Mixed notes require four independent role/class styles')
        return result
before=source();(OUT/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes());(OUT/'acceptance-source.dart').write_bytes(TOOL.read_bytes())
receipt['source_commit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
receipt['runtime_receipt_sha256']=sha(RUNTIME/'runtime.json');receipt['soffice_binary_sha256']=sha(SOFFICE.with_name('soffice.bin'))
try:
    run('dart-version',[DART,'--version']);run('libreoffice-version',[SOFFICE,'--version'])
    run('compile',[DART,'compile','kernel','--packages='+str(CONFIG),TOOL,'-o',OUT/'acceptance.dill'])
    prefix=[DART,'--packages='+str(CONFIG),OUT/'acceptance.dill']
    run('create',[*prefix,'create',OUT/'original'])
    receipt['original_hashes_before']={p.name:sha(p) for p in (OUT/'original').glob('*')}
    receipt['original_note_styles']=note_styles(OUT/'original/table-notes.odt')
    (OUT/'saved').mkdir()
    run('libreoffice-save',[SOFFICE,'-env:UserInstallation='+(OUT/'profile').as_uri(),'--headless','--convert-to','odt:writer8','--outdir',OUT/'saved',OUT/'original/body-bibliography.odt',OUT/'original/table-notes.odt'])
    run('verify-inventories-and-labels',[*prefix,'verify',OUT/'saved',OUT/'original'])
    receipt['saved_note_styles']=note_styles(OUT/'saved/table-notes.odt')
    if receipt['saved_note_styles']!=receipt['original_note_styles']:raise ValueError('Four note style references changed')
    receipt['status']='passed'
except BaseException as error:
    receipt['status']='failed';receipt['error']=repr(error);raise
finally:
    after=source();(OUT/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
    receipt['source_unchanged']=before==after
    receipt['source_changes']=[p for p in sorted(before.keys()|after.keys()) if before.get(p)!=after.get(p)]
    if 'original_hashes_before' in receipt:receipt['originals_unchanged']=receipt['original_hashes_before']=={p.name:sha(p) for p in (OUT/'original').glob('*')}
    receipt['artifacts']={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file() and p.suffix in ['.odt','.json','.dart','.log'] and 'profile' not in p.parts and p.name!='receipt.json'}
    receipt['finished_at_utc']=datetime.now(timezone.utc).isoformat();save()
