import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import time

BASE = Path('/workspace/scratch/4d323337693a')
ROOT = BASE / 'quds_office_suite'
CHECKPOINT = 'bb2dfd5272ff8de27ed2ec7f68b71801a2e41886'
MAIN = '2058a434b2bcc76e7fc7e8a449ff6ce31488eb25'
OUT = BASE / 'zotero-qualification-main2058/static'


def main():
    OUT.mkdir(exist_ok=False)
    spec = importlib.util.spec_from_file_location('qualification', BASE / 'run_zotero_qualification_main2058.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    paths = subprocess.check_output(['git', 'diff', '--name-only', MAIN, CHECKPOINT, '--', '*.dart'], cwd=ROOT, text=True).splitlines()
    targets = [ROOT / path for path in paths]
    assert targets and all(path.is_file() for path in targets)
    cwd = ROOT / 'packages/quds_office_engine'
    relative = [str(path.relative_to(cwd)) for path in targets]
    before = module.snapshot(targets)
    head_before = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    (OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
    checks = []
    commands = [
        ('format', cwd, ['dart', 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed', *relative]),
        ('analysis', cwd, ['dart', 'analyze', '--fatal-infos', *relative]),
        ('diff-check', ROOT, ['git', 'diff', '--check', MAIN, CHECKPOINT, '--', *paths]),
        ('worktree-check', ROOT, ['git', 'diff', '--check']),
    ]
    for name, directory, argv in commands:
        print(json.dumps({'check': name, 'started': True}), flush=True)
        started = time.monotonic()
        with (OUT / (name + '.stdout')).open('w') as stdout, (OUT / (name + '.stderr')).open('w') as stderr:
            result = subprocess.run(argv, cwd=directory, stdout=stdout, stderr=stderr)
        check = {'name': name, 'cwd': str(directory), 'argv': argv, 'exit_code': result.returncode,
                 'elapsed_seconds': time.monotonic() - started,
                 'stdout_sha256': hashlib.sha256((OUT / (name + '.stdout')).read_bytes()).hexdigest(),
                 'stderr_sha256': hashlib.sha256((OUT / (name + '.stderr')).read_bytes()).hexdigest()}
        checks.append(check)
        print(json.dumps(check), flush=True)
    after = module.snapshot(targets)
    head_after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    (OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
    receipt = {'scope': 'static', 'source_checkpoint_before_run': head_before,
               'source_checkpoint_after_run': head_after,
               'qualified_checkpoint': CHECKPOINT, 'compared_main': MAIN,
               'snapshot_scope': 'Selected changed Dart targets and all workspace package libraries/manifests/Zotero fixtures, using the integration gate snapshot function.',
               'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'targets': paths, 'target_file_count': len(paths), 'source_inputs': len(before),
               'inputs_unchanged': before == after,
               'changed_inputs': sorted(key for key in before.keys() | after.keys() if before.get(key) != after.get(key)),
               'checks': checks, 'passed': all(c['exit_code'] == 0 for c in checks) and before == after}
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: value for key, value in receipt.items() if key not in ['checks', 'targets']}, indent=2), flush=True)
    raise SystemExit(0 if receipt['passed'] else 1)


if __name__ == '__main__':
    main()
