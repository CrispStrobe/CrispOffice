import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_editor/quds_office_editor.dart';

const _boundary = ValueKey<String>('body-overlay-review');

Future<int> _redPixels(WidgetTester tester) async {
  final boundary = tester.renderObject<RenderRepaintBoundary>(find.byKey(_boundary));
  final image = (await tester.runAsync(() => boundary.toImage(pixelRatio: 1)))!;
  final data = (await tester.runAsync(() => image.toByteData(format: ui.ImageByteFormat.rawRgba)))!;
  final Uint8List bytes = data.buffer.asUint8List();
  var red = 0;
  for (var i = 0; i < bytes.length; i += 4) {
    if (bytes[i] > 150 && bytes[i + 1] < 145 && bytes[i + 2] < 145) red++;
  }
  image.dispose();
  return red;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(OfficeHostFonts.ensureRegistered);
  testWidgets('authored body overlay proofing refresh matches a fresh canvas', (tester) async {
    final paragraph = WmlParagraph(inlines: [WmlRun(text: 'Fehler')]);
    final document = WmlDocument(sections: [WmlSection(
      pageSize: WmlPageSize(width: 300, height: 320),
      blocks: [paragraph],
    )]);
    // Public renderer input: a glyphless authored body overlay with an exact
    // source paragraph. Normal engine TOC suffixes are generated and ordinary
    // WordProofingSession providers intentionally do not supply findings there.
    final line = LaidOutLine(
      glyphs: [], x: 50, y: 100, width: 100, height: 20,
      pageIndex: 0, paragraphIndex: 0, justification: WmlJustification.left,
      sourceParagraph: paragraph, sourceText: paragraph.text,
      overlayText: paragraph.text,
    );
    final layout = LaidOutDocument(
      pages: [LaidOutPage(index: 0, width: 300, height: 320, lines: [line])],
      pageSize: WmlPageSize(width: 300, height: 320),
    );
    final finding = OfficeProofingFinding.forRequest(
      OfficeProofingRequest(documentId: 'review', blockId: 'paragraph', revision: 0, text: paragraph.text),
      providerId: 'review', start: 0, end: 6, ruleId: 'review.spelling',
      message: 'Review finding', category: OfficeProofingCategory.spelling,
    );
    Future<RenderWordCanvas> mount(bool findings, String identity) async {
      await tester.pumpWidget(Directionality(
        textDirection: TextDirection.ltr,
        child: RepaintBoundary(key: _boundary, child: WordCanvas(
          key: ValueKey<String>(identity), document: document, laidOut: layout,
          caret: CaretEngine(), config: const OfficeSurfaceConfig(showRulers: false),
          proofingFindings: findings ? {paragraph: [finding]} : const {},
        )),
      ));
      await tester.pump();
      expect(tester.takeException(), isNull);
      return tester.renderObject<RenderWordCanvas>(find.byType(WordCanvas));
    }
    final first = await mount(true, 'retained');
    final marked = await _redPixels(tester);
    final second = await mount(false, 'retained');
    final retained = await _redPixels(tester);
    await mount(false, 'fresh');
    final fresh = await _redPixels(tester);
    print(jsonEncode({'case': 'public authored body overlay', 'sameRenderObject': identical(first, second), 'markedRedPixels': marked, 'retainedAfterClearRedPixels': retained, 'freshWithoutFindingsRedPixels': fresh}));
    expect(identical(first, second), isTrue);
    expect(marked, greaterThan(4));
    expect(fresh, 0);
    expect(retained, fresh, reason: 'A retained body text picture must not retain cleared proofing waves.');
  });
}
