import collections
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/4d323337693a/quds_office_suite')
CHECKPOINT = '4b33109aa85e077e2798265efa045d640e6ead4e'


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def main():
    reports = {}
    receipts = {}
    union = {}
    conflicts = []
    for scope in ['engine', 'engine-cli-shading', 'editor', 'studio', 'static']:
        folder = OUT / scope
        receipt = json.loads((folder / 'receipt.json').read_text())
        receipts[scope] = receipt
        assert receipt['source_checkpoint_before_run'] == CHECKPOINT
        assert receipt['source_checkpoint_after_run'] == CHECKPOINT
        assert receipt['inputs_unchanged']
        for moment in ['before', 'after']:
            data = json.loads((folder / ('inputs-' + moment + '.json')).read_text())
            for path, value in data.items():
                if path in union and union[path] != value:
                    conflicts.append({'scope': scope, 'moment': moment, 'path': path})
                union[path] = value
        if scope == 'static':
            assert receipt['passed'] and all(check['exit_code'] == 0 for check in receipt['checks'])
            continue
        raw = (folder / 'events.jsonl').read_bytes()
        events = []
        non_json = []
        for line in raw.decode().splitlines():
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                non_json.append(line)
        cwd = Path(receipt['cwd'])
        selected = {(cwd / arg).resolve().as_posix() for arg in receipt['argv'] if arg.endswith('_test.dart')}
        suites = [e['suite'] for e in events if e.get('type') == 'suite']
        observed = {(cwd / suite['path']).resolve().as_posix() for suite in suites}
        starts = [e['test'] for e in events if e.get('type') == 'testStart']
        dones = [e for e in events if e.get('type') == 'testDone']
        start_ids = collections.Counter(e['id'] for e in starts)
        done_ids = collections.Counter(e['testID'] for e in dones)
        start_map = {e['id']: e for e in starts}
        suite_map = {e['id']: (cwd / e['path']).resolve().as_posix() for e in suites}
        by_suite = collections.Counter(suite_map[start_map[e['testID']]['suiteID']]
                                       for e in dones if not e.get('hidden') and e.get('result') == 'success' and not e.get('skipped'))
        terminal = [e for e in events if e.get('type') == 'done']
        report = {'raw_sha256': hashlib.sha256(raw).hexdigest(),
                  'suite_count': len(suites), 'selected_test_paths': sorted(selected), 'selected_suites_match': selected == observed,
                  'missing_suites': sorted(selected - observed), 'unexpected_suites': sorted(observed - selected),
                  'duplicate_test_starts': [key for key, value in start_ids.items() if value != 1],
                  'duplicate_test_completions': [key for key, value in done_ids.items() if value != 1],
                  'incomplete_test_ids': sorted(start_ids.keys() - done_ids.keys()),
                  'unexpected_completion_ids': sorted(done_ids.keys() - start_ids.keys()),
                  'all_failed_count': sum(e.get('result') != 'success' for e in dones),
                  'all_skipped_count': sum(bool(e.get('skipped')) for e in dones),
                  'start_event_count': sum(e.get('type') == 'start' for e in events),
                  'terminal_events': terminal, 'passed': sum(by_suite.values()),
                  'passed_by_suite': dict(sorted(by_suite.items())), 'non_json_line_count': len(non_json)}
        report['valid'] = all([
            report['selected_suites_match'], len(suites) == receipt['test_file_count'],
            not report['duplicate_test_starts'], not report['duplicate_test_completions'],
            not report['incomplete_test_ids'], not report['unexpected_completion_ids'],
            report['all_failed_count'] == 0, report['all_skipped_count'] == 0,
            report['start_event_count'] == 1, len(terminal) == 1 and terminal[0].get('success'),
            report['passed'] == receipt['passed'], not non_json, not receipt['errors'], receipt['exit_code'] == 0,
        ])
        reports[scope] = report
    original = json.loads((OUT / 'plan-original91.json').read_text())
    expected_engine = {(ROOT / 'packages/quds_office_engine' / name).resolve().as_posix() for name in original['engine']}
    engine_scopes = ['engine', 'engine-cli-shading']
    actual_engine = {scope: set(reports[scope]['selected_test_paths']) for scope in engine_scopes}
    engine_union = set().union(*actual_engine.values())
    overlaps = set()
    for index, scope in enumerate(engine_scopes):
        for other in engine_scopes[index + 1:]:
            overlaps.update(actual_engine[scope] & actual_engine[other])
    blocked = json.loads((OUT / 'engine-cli-position/blocked-scope.json').read_text())
    blocked_paths = {(ROOT / 'packages/quds_office_engine' / blocked['suite']).resolve().as_posix()}
    partition = {'qualified_checkpoint': CHECKPOINT, 'scope_suite_counts': {scope: len(paths) for scope, paths in actual_engine.items()},
                 'passing_suite_count': len(engine_union), 'passing_and_blocked_union_equals_original91': engine_union | blocked_paths == expected_engine,
                 'blocked_suite_paths': sorted(blocked_paths), 'blocked_case_count': blocked['declared_cases_not_executed'],
                 'passing_blocked_overlap': sorted(engine_union & blocked_paths),
                 'overlap': sorted(overlaps), 'engine_total_passed': sum(reports[scope]['passed'] for scope in engine_scopes),
                 'all_passing_invocations_successful': all(reports[scope]['valid'] for scope in engine_scopes)}
    save('engine-partition-audit.json', partition)
    assert partition['passing_and_blocked_union_equals_original91'] and not overlaps and not partition['passing_blocked_overlap'] and partition['all_passing_invocations_successful']
    tracked = subprocess.check_output(['git', 'ls-files'], cwd=ROOT, text=True).splitlines()
    libraries = [path for path in tracked if path.startswith('packages/') and '/lib/' in path and path.endswith('.dart')]
    library_audit = {'qualified_checkpoint': CHECKPOINT, 'selection': 'packages/**/lib/**/*.dart',
                     'tracked_package_library_count': len(libraries),
                     'captured_tracked_package_library_count': sum(path in union for path in libraries),
                     'missing_package_library_inputs': [path for path in libraries if path not in union],
                     'includes_nested_package_examples': True, 'scope_excludes_apps_directory': True}
    summary = {'qualified_checkpoint': CHECKPOINT,
               'qualified_tree': subprocess.check_output(['git', 'rev-parse', CHECKPOINT + '^{tree}'], cwd=ROOT, text=True).strip(),
               'cohorts': {scope: {key: receipts[scope][key] for key in ['passed', 'failed', 'skipped', 'test_file_count', 'source_inputs', 'inputs_unchanged']} for scope in reports},
               'engine_total_passed': partition['engine_total_passed'],
               'engine_suite_count': partition['passing_suite_count'],
               'blocked_engine_suite_count': len(blocked_paths), 'blocked_engine_case_count': blocked['declared_cases_not_executed'],
               'blocked_scope': blocked, 'complete_original91_engine_scope': False,
               'engine_disjoint_partition_verified': True,
               'total_passed': sum(receipts[scope]['passed'] for scope in reports),
               'total_failed': sum(receipts[scope]['failed'] for scope in reports),
               'total_skipped': sum(receipts[scope]['skipped'] for scope in reports),
               'static_passed': receipts['static']['passed'],
               'static_target_file_count': receipts['static']['target_file_count'],
               'all_test_event_audits_valid': all(report['valid'] for report in reports.values()),
               'input_union_count': len(union), 'input_union_conflicts': conflicts,
               'input_union_sha256': hashlib.sha256(json.dumps(union, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
               'earlier_milestones_not_overwritten': True,
               'failed_environment_attempts': sorted(path.name for path in OUT.glob('engine-enospc*') if path.is_dir()),
               'failed_attempts_qualification_credit': False,
               'github_actions_used': False}
    save('test-event-audit.json', reports)
    save('library-input-coverage.json', library_audit)
    save('input-union.json', dict(sorted(union.items())))
    save('qualification-summary.json', summary)
    print(json.dumps(summary, indent=2))
    assert summary['all_test_event_audits_valid'] and not conflicts and not library_audit['missing_package_library_inputs']


if __name__ == '__main__':
    main()
