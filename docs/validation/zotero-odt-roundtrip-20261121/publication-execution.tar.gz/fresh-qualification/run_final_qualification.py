import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path('/workspace/scratch/4d323337693a/quds_office_suite')
RUNTIME = Path('/workspace/scratch/4d323337693a/zotero-runtime')
OUT = Path(__file__).resolve().parent
OUT.mkdir(exist_ok=True)

def plan(scope):
    declared = json.loads((OUT / 'plan.json').read_text())
    package = {'engine': 'packages/quds_office_engine',
               'engine-cli-shading': 'packages/quds_office_engine',
               'engine-cli-position': 'packages/quds_office_engine',
               'editor': 'packages/quds_office_editor',
               'studio': 'packages/quds_office_editor/example'}[scope]
    cwd = ROOT / package
    tests = [cwd / name for name in declared[scope]]
    if scope.startswith('engine'):
        prefix = ['dart', '--packages=' + str(ROOT / '.dart_tool/package_config.json'),
                  str(RUNTIME / 'test-runner/test-runner.dill'), '--concurrency=1', '--reporter=json']
    else:
        prefix = ['flutter', 'test', '--no-pub', '--concurrency=' + ('2' if scope == 'editor' else '1'), '--reporter=json']
    assert all(path.is_file() for path in tests)
    return cwd, tests, prefix + [str(path.relative_to(cwd)) for path in tests]

def snapshot(tests):
    inputs = set(tests)
    # Bind every workspace package's library source, including incoming Mail
    # and nested Studio packages, rather than only the original Zotero subset.
    inputs.update(ROOT.glob('packages/**/lib/**/*.dart'))
    for name in [
        'test/support/office_macro_cli.dart',
        'tool/macros/office_macro.dart',
        'tool/macros/web_vba_word_shading_smoke.dart',
        'tool/macros/web_vba_word_position_smoke.dart',
        'example/macros/word_shading.bas',
        'example/macros/word_font_position.bas',
    ]:
        inputs.add(ROOT / 'packages/quds_office_engine' / name)

    inputs.update(ROOT.glob('pubspec.*'))
    inputs.add(ROOT / '.fvmrc')
    inputs.add(ROOT / '.dart_tool/package_config.json')
    for path in ROOT.glob('packages/*/pubspec.yaml'):
        inputs.add(path)
    inputs.add(ROOT / 'packages/quds_office_editor/example/pubspec.yaml')
    for path in (ROOT / 'packages/quds_office_engine/test/fixtures/zotero').rglob('*'):
        if path.is_file():
            inputs.add(path)
    for name in ['support/office_golden.dart', 'support/review_fonts.dart',
                 'goldens/linux/word_selection_macOS.png', 'goldens/linux/word_selection_windows.png',
                 'flutter_test_config.dart']:
        path = ROOT / 'packages/quds_office_editor/test' / name
        if path.is_file():
            inputs.add(path)
    return {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(inputs)}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('scope', choices=['engine', 'engine-cli-shading', 'engine-cli-position', 'editor', 'studio'])
    parser.add_argument('--checkpoint', required=True)
    args = parser.parse_args()
    cwd, tests, command = plan(args.scope)
    dest = OUT / args.scope
    dest.mkdir(exist_ok=False)
    checkpoint = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert checkpoint == args.checkpoint
    before = snapshot(tests)
    (dest / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
    (dest / 'command.json').write_text(json.dumps({'cwd': str(cwd), 'argv': command}, indent=2) + '\n')
    print(json.dumps({'scope': args.scope, 'files': len(tests), 'source_inputs': len(before), 'started': True}), flush=True)
    start = time.monotonic()
    with (dest / 'events.jsonl').open('w') as out, (dest / 'stderr.log').open('w') as err:
        process = subprocess.run(command, cwd=cwd, stdout=out, stderr=err)
    elapsed = time.monotonic() - start
    after = snapshot(tests)
    checkpoint_after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    (dest / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
    events = []
    unknown_lines = []
    for line in (dest / 'events.jsonl').read_text().splitlines():
        try: events.append(json.loads(line))
        except json.JSONDecodeError: unknown_lines.append(line)
    names = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    cases = []
    for e in events:
        if e.get('type') != 'testDone' or e.get('hidden'):
            continue
        info = names.get(e['testID'], {})
        cases.append({'name': info.get('name'), 'suite': info.get('suiteID'),
                      'url': info.get('root_url') or info.get('url'),
                      'result': e.get('result'), 'skipped': e.get('skipped', False)})
    done = [e for e in events if e.get('type') == 'done']
    errors = [e for e in events if e.get('type') == 'error']
    receipt = {
        'scope': args.scope, 'qualified_checkpoint': args.checkpoint,
        'source_checkpoint_before_run': checkpoint,
        'source_checkpoint_after_run': checkpoint_after,
        'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'snapshot_scope': 'Selected test files, all workspace packages/**/lib/**/*.dart, SDK/dependency inputs, Zotero fixtures, six CLI/smoke/example inputs, consumed review helpers and Linux selection goldens.',
        'plan_sha256': hashlib.sha256((OUT / 'plan.json').read_bytes()).hexdigest(),
        'github_actions_used': False,
        'temporary_directory': os.environ.get('TMPDIR'),
        'argv': command, 'cwd': str(cwd), 'exit_code': process.returncode,
        'elapsed_seconds': elapsed, 'test_file_count': len(tests),
        'passed': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
        'failed': sum(c['result'] != 'success' and not c['skipped'] for c in cases),
        'skipped': sum(c['skipped'] for c in cases),
        'errors': errors, 'reporter_done': done,
        'source_inputs': len(before), 'inputs_unchanged': before == after,
        'changed_inputs': sorted(k for k in before.keys() | after.keys() if before.get(k) != after.get(k)),
        'non_json_lines': unknown_lines,
    }
    (dest / 'cases.json').write_text(json.dumps(cases, indent=2) + '\n')
    (dest / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k: v for k, v in receipt.items() if k not in ['argv', 'non_json_lines', 'reporter_done']}, ensure_ascii=False), flush=True)
    if process.returncode or not done or not done[-1].get('success') or errors or before != after:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
