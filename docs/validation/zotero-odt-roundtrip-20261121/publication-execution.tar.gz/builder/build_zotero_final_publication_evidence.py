#!/usr/bin/env python3
"""Package fresh final integration and distinctly labeled intermediate paint evidence.

Default invocation is a read-only plan. --build requires the explicit final
checkpoint and a passing fresh v2 input-binding proof. No probes are executed.
"""
from __future__ import annotations
import argparse
from dataclasses import dataclass
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

WORKSPACE = Path(__file__).resolve().parent
REPOSITORY = WORKSPACE/'quds_office_suite'
RECORD = REPOSITORY/'docs/validation/zotero-odt-roundtrip-20261121'
BASELINE = 'bb2dfd5272ff8de27ed2ec7f68b71801a2e41886'
ARCHIVE_NAME = 'publication-execution.tar.gz'
MANIFEST_NAME = 'publication-archive-contents.json'
EXCLUDED = {'.git', '.dart_tool', '.pub-cache', '__pycache__', 'node_modules', 'profile', 'profiles', 'flutter', 'pub-cache', 'build', 'cache', 'test-runner', 'sdk', 'dependencies'}
SUFFIXES = {'.json', '.jsonl', '.log', '.stdout', '.stderr', '.txt', '.md', '.py', '.dart', '.sh', '.xml', '.png', '.rgba', '.odt', '.docx'}
PROTECTED = {'archive-contents.json': 'c878e2e371339730345fe8d9efa095a0e55a8ec983a22817f31a0786c3cb7300', 'execution.tar.gz': '0cda5b93c032ca4a0dc539e31733cff4cf6162e1c0dc08a380094e401ed4ab0a', 'final-intake.json': 'e3b05f146739ab8d2caa3f941f19fe5e6984b43ad880bea93b17b5be965bc18b', 'final-intake.md': '1597467d722711c980ba12514a7cbff270c07bbcd892af116e17ed155727878e', 'final-refs.txt': '0d47cd286bff5229a4deeb66023cac42de7b7e6619a1426931c8553984e5c25d', 'final.json': '755e0be18048b1d71aa8d7c3892479eb8ca709a491d23829f440a76a189efb12', 'initial-intake.json': '1f6f0443d4658a29cfbdf8a1f7810a63b266fe5adb6805b4151a378ad2f856b0', 'intake-equivalence.json': 'f640983262ce942fd62528ade890f935f924c0a32cfd3896c8938201e55c2265', 'intake-equivalence.md': 'a649dbcd2dacccbd9aafe179560ffc32b896519fa7ad13a2dee5daf202db38fd', 'integration-archive-contents.json': 'f6d7123429c7c9d275efbf4bb4dee2d0db25b95d83bd179b8d986b8cacb5d3c4', 'integration-execution.tar.gz': '33c754e181be83d85ba391330a01898747c96db3f03f3af91ef501385e38b3b1', 'integration-intake.json': '42be1229b87a371124ef2e6b53341c9a95955bcdf19e4ba9084a5929fc2afbbf', 'integration-intake.md': 'a643c572d699b2e7b98d4c99c865ab1a4af71bc6ae11524c4641b3a0e7fff594', 'integration-refs.txt': '97c2874157d33854daba43fed44fca4cfcafacba0674e96fb3c8b54d7d4e39ca', 'integration-source-binding.json': '2498b4875a2bd1d4758369984c3d216d5108d49705019614b13df3934384c190', 'integration.json': '1e9a4ccf1d0f58904be0cdc3b32cba7e109b1503ff90aacdd8d18e1cd9c08135', 'source-binding.json': 'ba02035589ddd6566a6479bd40aaf1f9c46abe26e7d595da3748e03f8fc36ea0'}

def digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()


@dataclass(frozen=True)
class Entry:
    name: str
    payload: bytes
    source: str


class Collection:
    def __init__(self) -> None:
        self.entries: dict[str, Entry] = {}
        self.inputs: dict[Path, str] = {}
        self.pending: list[str] = []

    def read(self, path: Path) -> bytes:
        if path.is_symlink() or not path.is_file():
            raise ValueError(f'Expected regular evidence file: {path}')
        path = path.resolve()
        path.relative_to(WORKSPACE)
        payload = path.read_bytes()
        checksum = digest(payload)
        if path in self.inputs and self.inputs[path] != checksum:
            raise RuntimeError(f'Evidence changed while collecting: {path}')
        self.inputs[path] = checksum
        return payload

    def add(self, name: str, payload: bytes, source: str) -> None:
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or not path.parts or name in self.entries:
            raise ValueError(f'Unsafe or duplicate member: {name}')
        self.entries[name] = Entry(name, payload, source)

    def file(self, path: Path, name: str, *, required: bool = True) -> None:
        if not path.exists():
            if required:
                self.pending.append(str(path.relative_to(WORKSPACE)))
            return
        self.add(name, self.read(path), str(path.relative_to(WORKSPACE)))

    def tree(self, directory: Path, prefix: str) -> None:
        if not directory.is_dir():
            self.pending.append(str(directory.relative_to(WORKSPACE)))
            return
        for parent, directories, files in os.walk(directory, followlinks=False):
            current = Path(parent)
            directories[:] = sorted(name for name in directories if name not in EXCLUDED and not name.startswith('.') and not (current/name).is_symlink())
            for name in sorted(files):
                path = current/name
                if path.suffix.lower() in SUFFIXES:
                    self.file(path, prefix + '/' + path.relative_to(directory).as_posix())

    def unchanged(self) -> None:
        changed = [str(path.relative_to(WORKSPACE)) for path, expected in self.inputs.items() if not path.is_file() or path.is_symlink() or digest(path.read_bytes()) != expected]
        if changed:
            raise RuntimeError('Evidence changed during packaging: ' + ', '.join(changed))

    def receipt(self, path: Path) -> dict[str, object] | None:
        if not path.is_file():
            self.pending.append(str(path.relative_to(WORKSPACE)))
            return None
        return json.loads(self.read(path))


def collect(args: argparse.Namespace) -> tuple[Collection, dict[str, object] | None]:
    result = Collection()
    result.tree(WORKSPACE/'zotero-qualification-final-merged', 'fresh-qualification')
    result.tree(WORKSPACE/'zotero-final-integration-converter', 'fresh-converters')
    result.tree(WORKSPACE/'zotero-qualification-publication-paint', 'intermediate-a4/qualification')
    result.tree(WORKSPACE/'zotero-page-text-cache-development', 'intermediate-a4/development')
    result.tree(WORKSPACE/'zotero-filesystem-diagnostic-20261121', 'environment-diagnostics/filesystem')
    for name in ['body-overlay-cache-probe-blocked.json', 'body_overlay_cache_probe_test.dart', 'body-overlay-cache-probe.events.jsonl', 'body-overlay-cache-probe.stderr.log']:
        result.file(WORKSPACE/name, 'blocked-development/overlay/' + name)
    result.file(WORKSPACE/'build_zotero_source_binding_v2.py', 'independent-review/build_zotero_source_binding_v2.py')
    result.file(WORKSPACE/'build_zotero_final_qualification_completeness.py', 'independent-review/build_zotero_final_qualification_completeness.py')
    if args.binding_plan is None:
        result.pending.append('Explicit fresh binding plan is required.')
    else:
        result.file(args.binding_plan, 'independent-review/' + args.binding_plan.name)
    for path in sorted(WORKSPACE.glob('zotero-final-integration-binding-plan-*.json')):
        result.file(path, 'independent-review/' + path.name)
    earlier_plan = WORKSPACE/'zotero-final-integration-binding-plan.json'
    earlier_member = 'independent-review/' + earlier_plan.name
    if earlier_member not in result.entries:
        result.file(earlier_plan, earlier_member)
    completeness_path = WORKSPACE/'zotero-final-qualification-completeness.json'
    result.file(completeness_path, 'independent-review/' + completeness_path.name)
    completeness = result.receipt(completeness_path)
    position_review = WORKSPACE/'zotero-final-incoming-position-review.json'
    result.file(position_review, 'independent-review/' + position_review.name)
    proof = None
    if args.source_proof is None:
        result.pending.append('Explicit fresh source proof is required.')
    else:
        proof = result.receipt(args.source_proof)
    if args.expected_source is None:
        result.pending.append('Explicit final source checkpoint is required.')
    for name, expected in PROTECTED.items():
        if digest(result.read(RECORD/name)) != expected:
            raise RuntimeError('Historical milestone changed: ' + name)
    if proof is not None:
        if proof.get('schema') != 'quds-zotero-source-binding-v2' or proof.get('all_binding_checks_passed') is not True or not proof.get('checks') or not all(proof['checks'].values()):
            result.pending.append('Fresh final source binding has not passed.')
        if proof.get('target_commit') != args.expected_source:
            result.pending.append('Source proof does not bind the explicitly requested final checkpoint.')
        if args.binding_plan is not None and proof['plan']['sha256'] != digest(result.read(args.binding_plan)):
            raise RuntimeError('Source proof refers to a different binding plan.')
        if proof['generator']['sha256'] != digest(result.read(WORKSPACE/'build_zotero_source_binding_v2.py')):
            raise RuntimeError('Source proof generator differs from its reported source.')
        for name, run in proof['runs'].items():
            if run.get('recorded_checkpoint') != args.expected_source or run.get('tracked_target_mismatches') or run.get('allowed_target_mismatch_paths'):
                result.pending.append('Run is not a fresh exact final-source qualification: ' + name)
        target = proof['target_commit']
        changed = subprocess.check_output(['git','diff','--name-only',BASELINE,target,'--','*.dart'],cwd=REPOSITORY,text=True).splitlines()
        tests = sorted(path for path in changed if '/test/' in path)
        for path in tests:
            payload = subprocess.check_output(['git','show',target+':'+path],cwd=REPOSITORY)
            if payload != result.read(REPOSITORY/path):
                raise RuntimeError('Regression test differs from qualified source: ' + path)
            result.add('changed-tests/' + path, payload, 'git:' + target + ':' + path)
        summary = {
            'schema': 'quds-zotero-final-publication-archive-source-summary-v1',
            'target_commit': target, 'target_tree': proof['target_tree'],
            'full_source_proof': {'source': str(args.source_proof.relative_to(WORKSPACE)), 'sha256': digest(result.read(args.source_proof)), 'bytes': args.source_proof.stat().st_size, 'full_report_archived': False},
            'checks': proof['checks'], 'all_binding_checks_passed': proof['all_binding_checks_passed'],
            'qualification_completeness': completeness,
            'binding_scope_limit': 'A successful byte binding qualifies only the selected passing runs. The original 91-suite engine plan has a separately disclosed blocked Position CLI suite; failed or blocked cases receive no pass credit.',
            'runs': {name: {key: run.get(key) for key in ['kind','recorded_checkpoint','recorded_result','input_count','tracked_target_match_count','tracked_target_mismatches','allowed_target_mismatch_paths','checks']} for name,run in proof['runs'].items()},
            'intermediate_a4_status': 'Historical completed paint milestone only; not counted as fresh final-source qualification.',
            'blocked_probe_status': 'Blocked without observed completion; never counted as a pass or reproduced regression and not executed by packaging.',
        }
        result.add('independent-review/source-summary.json',json_bytes(summary),'generated exact subset of the external fresh source proof')
    for name in ['publication-intake.json','publication-intake.md','publication-refs.txt']:
        result.file(RECORD/name,'intake/' + name)
    result.file(WORKSPACE/'zotero-publication-ref-accounting.py','intake/reproducer/zotero-publication-ref-accounting.py')
    result.file(Path(__file__).resolve(),'builder/build_zotero_final_publication_evidence.py')
    result.add('builder/collection-policy.json',json_bytes({
        'schema':1,
        'scope':'Fresh final merged qualification and actual four-core-fixture/mixed/image saves, with intermediate a4 paint diagnostics separately labeled. Prior milestone archives/proofs remain untouched.',
        'historical_artifacts_preserved':PROTECTED,
        'excluded_directory_names':sorted(EXCLUDED),
        'allowed_file_suffixes':sorted(SUFFIXES),
        'blocked_probe_archived_without_execution_or_qualification_credit':True,
        'full_source_binding_remains_external':True,
        'sdk_dependencies_profiles_kernels_and_caches_excluded':True,
    }),'generated collection policy')
    result.pending=sorted(set(result.pending))
    return result,proof


def pack(entries: list[Entry]) -> bytes:
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for entry in entries:
                metadata = tarfile.TarInfo(entry.name)
                metadata.size = len(entry.payload)
                metadata.mode = 0o644
                metadata.uid = metadata.gid = metadata.mtime = 0
                metadata.uname = metadata.gname = ''
                metadata.pax_headers = {}
                archive.addfile(metadata, io.BytesIO(entry.payload))
    return output.getvalue()


def verify(payload: bytes, entries: list[Entry]) -> None:
    expected = {entry.name: entry for entry in entries}
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
        members = archive.getmembers()
        if [member.name for member in members] != sorted(expected):
            raise RuntimeError('Archive member order or membership mismatch.')
        for member in members:
            entry = expected[member.name]
            if not member.isfile() or member.size != len(entry.payload) or member.mode != 0o644 or member.uid != 0 or member.gid != 0 or member.mtime != 0 or member.uname or member.gname:
                raise RuntimeError('Archive metadata mismatch: ' + member.name)
            extracted = archive.extractfile(member)
            if extracted is None or digest(extracted.read()) != digest(entry.payload):
                raise RuntimeError('Archive member checksum mismatch: ' + member.name)


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build',action='store_true')
    parser.add_argument('--output-dir',type=Path,default=RECORD)
    parser.add_argument('--expected-source')
    parser.add_argument('--binding-plan',type=Path)
    parser.add_argument('--source-proof',type=Path)
    args=parser.parse_args()
    if args.binding_plan is not None:args.binding_plan=args.binding_plan.resolve()
    if args.source_proof is not None:args.source_proof=args.source_proof.resolve()
    collection,proof=collect(args)
    entries=sorted(collection.entries.values(),key=lambda item:item.name)
    summary={'mode':'build' if args.build else 'plan-only','members':len(entries),'uncompressed_bytes':sum(len(item.payload) for item in entries),'pending':collection.pending}
    if args.build:
        if collection.pending or proof is None:
            raise RuntimeError('Required frozen final evidence is incomplete: '+'; '.join(collection.pending))
        archive=pack(entries)
        if archive!=pack(entries):raise RuntimeError('Deterministic rebuild produced different bytes.')
        verify(archive,entries)
        collection.unchanged()
        manifest=json_bytes({
            'schema':1,'target_commit':proof['target_commit'],'target_tree':proof['target_tree'],
            'archive_file':ARCHIVE_NAME,'archive_sha256':digest(archive),'archive_size_bytes':len(archive),
            'entries_count':len(entries),'uncompressed_bytes':summary['uncompressed_bytes'],
            'deterministic_rebuild_matched':True,'all_archive_members_verified':True,
            'all_inputs_unchanged_during_packaging':True,'historical_milestones_unchanged':True,
            'entries':[{'path':item.name,'size_bytes':len(item.payload),'sha256':digest(item.payload),'source':item.source} for item in entries],
        })
        args.output_dir.mkdir(parents=True,exist_ok=True)
        outputs=[(args.output_dir/ARCHIVE_NAME,archive),(args.output_dir/MANIFEST_NAME,manifest)]
        if any(path.exists() for path,_ in outputs):
            if not all(path.is_file() and path.read_bytes()==data for path,data in outputs):
                raise FileExistsError('Different publication output exists; it will not be overwritten.')
            written=False
        else:
            staged=[]
            try:
                for path,data in outputs:
                    temporary=path.with_name('.'+path.name+'.pending')
                    with temporary.open('xb') as stream:
                        stream.write(data);stream.flush();os.fsync(stream.fileno())
                    staged.append((temporary,path))
                for temporary,path in staged:os.replace(temporary,path)
            finally:
                for temporary,_ in staged:temporary.unlink(missing_ok=True)
            written=True
        collection.unchanged()
        summary.update({'written':written,'archive':str(args.output_dir/ARCHIVE_NAME),'manifest':str(args.output_dir/MANIFEST_NAME),'archive_sha256':digest(archive),'archive_size_bytes':len(archive),'manifest_sha256':digest(manifest)})
    print(json.dumps(summary,indent=2,sort_keys=True))


if __name__=='__main__':main()
