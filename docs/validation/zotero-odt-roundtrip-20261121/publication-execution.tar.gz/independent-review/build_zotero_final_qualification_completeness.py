#!/usr/bin/env python3
"""Account for the original test selection without relabeling blocked runs.

Reads the explicitly scoped v2 source proof and retained run evidence. Writes
only --output. It does not execute tests, modify receipts, or mutate Git.
"""

import argparse
import hashlib
import json
import subprocess
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--proof', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    plan_path = args.plan.resolve()
    workspace = plan_path.parent
    plan = json.loads(plan_path.read_text())
    proof = json.loads(args.proof.read_text())
    repository = Path(plan['repository'])
    target = plan['target_commit']
    require(proof['target_commit'] == target, 'Proof targets another source')
    require(proof['plan']['sha256'] == sha(plan_path.read_bytes()), 'Plan hash mismatch')
    require(proof['all_binding_checks_passed'], 'Scoped source binding has not passed')
    require(all(proof['checks'].values()), 'Scoped binding contains failed checks')
    require(len(proof['runs']) == 8, 'Expected eight explicitly scoped passing runs')

    def path(value):
        value = Path(value)
        return value if value.is_absolute() else workspace / value

    def artifact(value):
        value = path(value)
        data = value.read_bytes()
        return {'path': str(value), 'sha256': sha(data), 'bytes': len(data)}

    def git(*arguments, data=None):
        return subprocess.check_output(['git', *arguments], cwd=repository, input=data)

    require(git('rev-parse', 'HEAD').decode().strip() == target,
            'Repository is not at the explicit source checkpoint')
    tree = {}
    for row in git('ls-tree', '-r', '-z', target).split(b'\0'):
        if row:
            metadata, name = row.split(b'\t', 1)
            mode, kind, oid = metadata.decode().split()
            tree[name.decode()] = {'mode': mode, 'kind': kind, 'blob': oid}

    provenance = plan['qualification_completeness']
    original_path = path(provenance['original_test_plan'])
    original = json.loads(original_path.read_text())
    groups = {
        'engine': ('packages/quds_office_engine', ['engine', 'engine_cli_shading']),
        'editor': ('packages/quds_office_editor', ['editor']),
        'studio': ('packages/quds_office_editor/example', ['studio']),
    }
    expected = {}
    observed = {}
    overlaps = {}
    accepted = {}
    for group, (prefix, names) in groups.items():
        expected[group] = {prefix + '/' + name for name in original[group]}
        require(len(expected[group]) == len(original[group]),
                'Original selection contains duplicates: ' + group)
        listed = [entry for name in names
                  for entry in proof['runs'][name]['selected_test_entrypoints']]
        observed[group] = set(listed)
        overlaps[group] = sorted(entry for entry in set(listed) if listed.count(entry) > 1)
        accepted[group] = {
            'runs': names,
            'passed_cases': sum(proof['runs'][name]['recorded_result']['passed'] for name in names),
            'selected_suites': len(listed),
            'selected_test_entrypoints': sorted(observed[group]),
            'duplicate_entrypoints': overlaps[group],
        }
    require({group: len(entries) for group, entries in expected.items()} ==
            {'engine': 91, 'editor': 16, 'studio': 3}, 'Original selection changed')

    rejected = []
    snapshots = {}
    for spec in provenance['unaccepted_attempts']:
        directory = path(spec['directory'])
        receipt_path = directory / 'receipt.json'
        receipt = json.loads(receipt_path.read_text())
        before_name = 'source-before.json' if spec['kind'] == 'converter' else 'inputs-before.json'
        after_name = 'source-after.json' if spec['kind'] == 'converter' else 'inputs-after.json'
        before_path = directory / before_name
        after_path = directory / after_name
        before = json.loads(before_path.read_text())
        after = json.loads(after_path.read_text())
        key = str(directory)
        snapshots[key] = (before, after)
        checkpoint = receipt.get('source_commit', receipt.get('source_checkpoint_before_run'))
        require(checkpoint == target, 'Unaccepted attempt used another source: ' + key)
        require(receipt.get('status') == 'failed' or receipt.get('exit_code', 0) != 0,
                'Attempt declared unsuccessful has a successful receipt: ' + key)
        rejected.append({
            **spec,
            'receipt': artifact(receipt_path),
            'before_snapshot': artifact(before_path),
            'after_snapshot': artifact(after_path),
            'recorded_checkpoint': checkpoint,
            'recorded_result': {name: receipt[name] for name in
                                ['status', 'passed', 'failed', 'skipped', 'exit_code', 'test_file_count']
                                if name in receipt},
            'errors': receipt.get('errors', []),
            'failed_commands': [command for command in receipt.get('commands', [])
                                if command.get('exit_code', 0) != 0],
            'qualification_credit': 0,
        })

    # Bind failed-attempt inputs too, while keeping execution status failed.
    paths = set().union(*(set(before) | set(after) for before, after in snapshots.values()))
    ids = sorted({tree[name]['blob'] for name in paths if name in tree})
    payload = git('cat-file', '--batch', data=('\n'.join(ids) + '\n').encode())
    at = 0
    hashes = {}
    for expected_id in ids:
        end = payload.index(b'\n', at)
        oid, kind, size = payload[at:end].decode().split()
        require(oid == expected_id and kind == 'blob', 'Unexpected Git object')
        at = end + 1
        size = int(size)
        hashes[oid] = sha(payload[at:at + size])
        at += size
        require(payload[at:at + 1] == b'\n', 'Invalid Git object framing')
        at += 1
    require(at == len(payload), 'Unexpected Git object bytes')
    runtime_path = '.dart_tool/package_config.json'
    runtime_sha = sha((repository / runtime_path).read_bytes())
    for item in rejected:
        before, after = snapshots[str(path(item['directory']))]
        missing = sorted(name for name in before if name not in tree and name != runtime_path)
        changed = sorted(name for name in before.keys() | after.keys()
                         if before.get(name) != after.get(name))
        mismatches = sorted(name for name in before if name in tree
                            and before[name] != hashes[tree[name]['blob']])
        item['source_binding'] = {
            'input_count': len(before), 'changed_during_attempt': changed,
            'tracked_target_mismatches': mismatches, 'unexpected_untracked_inputs': missing,
            'runtime_config_before_after_current_match':
                before.get(runtime_path) == after.get(runtime_path) == runtime_sha,
            'all_captured_inputs_match_target': not changed and not mismatches and not missing
                and before.get(runtime_path) == after.get(runtime_path) == runtime_sha,
        }

    blocked = provenance['blocked_test_scope']
    blocked_entry = blocked['test_entrypoint']
    blocked_directory = path(blocked['directory'])
    blocked_receipt = json.loads((blocked_directory / 'receipt.json').read_text())
    require(blocked_receipt['passed'] == 0 and blocked_receipt['failed'] == 1,
            'Unexpected blocked-suite result')
    require(any('No space left on device' in row['error']
                for row in blocked_receipt['errors']), 'Expected environment error missing')
    blocked_source = git('show', target + ':' + blocked_entry).decode()
    require(all(title in blocked_source for title in blocked['declared_case_titles']),
            'Blocked case title not present in final source')
    require(len(blocked['declared_case_titles']) == 4, 'Expected four blocked cases')
    require(expected['engine'] - observed['engine'] == {blocked_entry},
            'Unaccounted engine-suite gap')
    require(not observed['engine'] - expected['engine'], 'Unexpected engine suite')
    require(all(observed[group] == expected[group] for group in ['editor', 'studio']),
            'Editor/Studio selection differs from the original plan')
    require(not any(overlaps.values()), 'Successful cohorts overlap')

    historical_path = path(provenance['historical_position_review'])
    historical = json.loads(historical_path.read_text())
    require(historical['target_commit'] == target, 'Historical review targets another source')
    require(historical['qualification_credit']['fresh_final_cases_added'] == 0,
            'Historical results must not add fresh qualification credit')
    report = {
        'schema': 'quds-zotero-final-qualification-completeness-v1',
        'target_commit': target, 'target_tree': proof['target_tree'],
        'status': 'PARTIALLY_QUALIFIED_WITH_ENVIRONMENT_BLOCKER',
        'scope': 'Complete accounting of the original selection, with exact source binding of accepted scopes and explicitly separate failed attempts. This report does not declare the original plan fully passing.',
        'original_test_plan': artifact(original_path),
        'passing_scope_plan': artifact(plan_path),
        'passing_scope_source_proof': artifact(args.proof.resolve()),
        'generator': artifact(Path(__file__).resolve()),
        'original_requested_suites': {group: len(values) for group, values in expected.items()},
        'successful_fresh_test_scopes': accepted,
        'successful_fresh_case_count': sum(group['passed_cases'] for group in accepted.values()),
        'successful_fresh_suite_count': sum(group['selected_suites'] for group in accepted.values()),
        'blocked_scope': {
            **blocked, 'executed_cases': 0, 'declared_cases_not_executed': 4,
            'receipt': artifact(blocked_directory / 'receipt.json'),
            'events': artifact(blocked_directory / 'events.jsonl'),
            'qualification_credit': 0,
            'reason': 'The suite setUpAll could not create its macro CLI temporary directory (errno 28); its four test bodies did not execute. Retrying this suite was stopped.',
        },
        'unaccepted_attempts': rejected,
        'historical_support': {
            'review': artifact(historical_path),
            'four_cases_passed_upstream': historical['upstream_four_cases'],
            'fresh_qualification_credit': 0,
            'limitations': historical['qualification_credit']['reason'],
            'missing_legacy_library_snapshot_count': len(historical['final_engine_legacy_libraries']['missing']),
        },
        'checks': {
            'scoped_passing_source_binding_valid': True,
            'successful_test_cohorts_disjoint': not any(overlaps.values()),
            'original_selection_equals_successful_plus_explicit_blocked':
                observed['engine'] | {blocked_entry} == expected['engine']
                and observed['editor'] == expected['editor'] and observed['studio'] == expected['studio'],
            'all_unaccepted_attempt_sources_stable_and_match_target':
                all(row['source_binding']['all_captured_inputs_match_target'] for row in rejected),
            'historical_results_receive_no_fresh_credit': True,
            'all_original_requested_tests_passed': False,
        },
    }
    report['accounting_checks_passed'] = all(value for name, value in report['checks'].items()
                                              if name != 'all_original_requested_tests_passed')
    output = args.output.resolve()
    require(not output.is_relative_to(repository), 'Output must remain outside Git')
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'output': str(output), 'sha256': sha(output.read_bytes()),
                      'bytes': output.stat().st_size, 'status': report['status'],
                      'successful_fresh_cases': report['successful_fresh_case_count'],
                      'successful_fresh_suites': report['successful_fresh_suite_count'],
                      'blocked_cases': 4, 'accounting_checks_passed': report['accounting_checks_passed'],
                      'all_original_requested_tests_passed': False}, indent=2))
    return 0 if report['accounting_checks_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
