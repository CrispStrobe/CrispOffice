#!/usr/bin/env python3
"""Bind explicitly selected qualification snapshots to one explicit Git commit.

Usage: python build_zotero_source_binding_v2.py --plan PLAN.json

This script reads repository and receipt files and writes only plan.output.
It does not run tests, edit source, edit receipts, or mutate Git. Every run in
the plan is required; absent or incomplete evidence is a failed binding.
"""

import argparse
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    args = parser.parse_args()
    plan_path = args.plan.resolve()
    plan = json.loads(plan_path.read_text())
    require(plan.get('schema') == 'quds-zotero-source-binding-plan-v2', 'Unsupported plan schema')

    def path(value):
        value = Path(value)
        return value.resolve() if value.is_absolute() else (plan_path.parent / value).resolve()

    root = path(plan['repository'])
    output = path(plan['output'])
    target = plan['target_commit']
    require(re.fullmatch(r'[0-9a-f]{40}', target) is not None, 'target_commit must be an explicit full Git SHA')
    require(output != plan_path, 'Output must not replace the plan')
    require(not output.is_relative_to(root), 'Proof output must remain outside the Git repository')
    runtime_paths = set(plan.get('runtime_inputs_outside_git', ['.dart_tool/package_config.json']))
    require(isinstance(plan['runs'], list) and plan['runs'], 'At least one required run is necessary')
    require(len({r['name'] for r in plan['runs']}) == len(plan['runs']), 'Run names must be unique')

    def git(*argv):
        return subprocess.check_output(['git', *argv], cwd=root)

    def git_text(*argv):
        return git(*argv).decode().strip()

    def artifact(p):
        data = p.read_bytes()
        return {'path': str(p), 'sha256': digest(data), 'bytes': len(data)}

    def get_tree(ref):
        result = {}
        for row in git('ls-tree', '-r', '-z', ref).split(b'\0'):
            if row:
                meta, p = row.split(b'\t', 1)
                mode, kind, oid = meta.decode().split()
                result[p.decode()] = {'mode': mode, 'kind': kind, 'blob': oid}
        return result

    def hash_blobs(ids):
        ids = sorted(set(ids))
        if not ids:
            return {}
        data = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=root,
                                       input=('\n'.join(ids) + '\n').encode())
        at = 0
        result = {}
        for expected in ids:
            end = data.index(b'\n', at)
            oid, kind, size = data[at:end].decode().split()
            require(oid == expected and kind == 'blob', 'Unexpected Git blob response')
            at = end + 1
            size = int(size)
            result[oid] = digest(data[at:at + size])
            at += size
            require(data[at:at + 1] == b'\n', 'Invalid Git payload framing')
            at += 1
        require(at == len(data), 'Unexpected trailing Git bytes')
        return result

    head_before = git_text('rev-parse', 'HEAD')
    require(git_text('rev-parse', target + '^{commit}') == target, 'Target commit cannot be resolved')
    final_tree = get_tree(target)
    preserved = []
    for item in plan.get('preserve_artifacts', []):
        item_path = path(item['path'])
        require(output != item_path, 'Output would overwrite a preserved artifact')
        actual = artifact(item_path)
        preserved.append({**actual, 'expected_sha256': item['sha256'],
                          'matches_expected': actual['sha256'] == item['sha256']})

    loaded = {}
    errors = []
    for spec in plan['runs']:
        name = spec['name']
        directory = path(spec['directory'])
        try:
            receipt_path = directory / spec.get('receipt', 'receipt.json')
            receipt = json.loads(receipt_path.read_text())
            evidence = [artifact(receipt_path)]
            if spec['kind'] == 'single_file_static':
                before = {receipt['file']: receipt['sha256_before']}
                after = {receipt['file']: receipt['sha256_after']}
            else:
                before_path = directory / spec['before']
                after_path = directory / spec['after']
                before = json.loads(before_path.read_text())
                after = json.loads(after_path.read_text())
                evidence += [artifact(before_path), artifact(after_path)]
            require(isinstance(before, dict) and bool(before), name + ': empty/invalid before snapshot')
            require(isinstance(after, dict) and bool(after), name + ': empty/invalid after snapshot')
            for snapshot in [before, after]:
                for p, sha in snapshot.items():
                    require(not Path(p).is_absolute() and '..' not in Path(p).parts,
                            name + ': snapshot path must be repository-relative: ' + p)
                    require(re.fullmatch(r'[0-9a-f]{64}', sha) is not None,
                            name + ': invalid SHA-256: ' + p)
            checkpoint_key = spec.get('checkpoint_key', {
                'tests': 'source_checkpoint_before_run',
                'converter': 'source_commit',
                'static': 'checkpoint',
                'single_file_static': 'checkpoint',
            }[spec['kind']])
            checkpoint = receipt.get(checkpoint_key)
            expected_checkpoint = spec.get('expected_receipt_checkpoint', target)
            require(re.fullmatch(r'[0-9a-f]{40}', expected_checkpoint) is not None,
                    name + ': expected receipt checkpoint must be explicit full SHA')
            selected = []
            if spec['kind'] == 'tests':
                cwd = Path(receipt['cwd'])
                require(cwd.is_relative_to(root), name + ': test cwd lies outside repository')
                selected = [str((cwd / arg).relative_to(root)) for arg in receipt['argv']
                            if arg.startswith('test/') and arg.endswith('.dart')]
                require(len(selected) == receipt['test_file_count'], name + ': selected-test count mismatch')
                require(all(p in before for p in selected), name + ': selected test missing from snapshot')
            loaded[name] = {'spec': spec, 'directory': directory, 'receipt': receipt,
                            'before': before, 'after': after, 'evidence': evidence,
                            'checkpoint': checkpoint, 'expected_checkpoint': expected_checkpoint,
                            'selected_tests': selected}
        except (OSError, ValueError, KeyError, TypeError) as error:
            errors.append({'run': name, 'error': str(error)})

    all_paths = sorted(set().union(*(set(r['before']) | set(r['after']) for r in loaded.values())))
    hashes = hash_blobs(final_tree[p]['blob'] for p in all_paths
                        if p in final_tree and final_tree[p]['kind'] == 'blob')
    files = {}
    for p in all_paths:
        entry = final_tree.get(p)
        actual = root / p
        files[p] = {
            'git_blob': entry['blob'] if entry else None,
            'git_mode': entry['mode'] if entry else None,
            'target_sha256': hashes.get(entry['blob']) if entry else None,
            'current_sha256': digest(actual.read_bytes()) if actual.is_file() else None,
            'declared_runtime_input_outside_git': p in runtime_paths,
        }

    bindings = {}
    for name, run in loaded.items():
        spec, before, after, receipt = run['spec'], run['before'], run['after'], run['receipt']
        changed = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
        mismatches = sorted(p for p in before if p in final_tree and before[p] != files[p]['target_sha256'])
        untracked = sorted(p for p in before if p not in final_tree)
        allowed_mismatches = sorted(spec.get('allowed_target_mismatch_paths', []))
        for p in allowed_mismatches:
            require(p in before, name + ': allowed mismatch is not a captured input: ' + p)
            require(bool(spec.get('mismatch_explanation')), name + ': allowed mismatch needs an explanation')
        successful = receipt.get('exit_code', 0) == 0 and receipt.get('failed', 0) == 0
        if spec['kind'] == 'tests':
            successful = successful and receipt['passed'] > 0 and not receipt.get('errors')
            successful = successful and bool(receipt.get('reporter_done')) and receipt['reporter_done'][-1].get('success') is True
        elif spec['kind'] == 'converter':
            successful = successful and receipt.get('status') == 'passed'
        commands = receipt.get(spec.get('commands_key', 'commands'), [])
        if spec['kind'] in {'converter', 'static', 'single_file_static'}:
            successful = successful and bool(commands) and all(c.get('exit_code') == 0 for c in commands)
        if spec['kind'] in {'static', 'single_file_static'} and isinstance(receipt.get('passed'), bool):
            successful = successful and receipt['passed']
        runtime_bindings = {p: {'before_sha256': before.get(p), 'after_sha256': after.get(p),
                                'current_sha256': files[p]['current_sha256'],
                                'tracked_in_target': p in final_tree}
                            for p in sorted(runtime_paths & before.keys())}
        checks = {
            'expected_checkpoint_recorded': run['checkpoint'] == run['expected_checkpoint'],
            'after_checkpoint_matches_when_recorded': receipt.get('source_checkpoint_after_run', run['checkpoint']) == run['checkpoint'],
            'before_after_identical': before == after,
            'no_unexpected_tracked_target_mismatches': set(mismatches) <= set(allowed_mismatches),
            'only_declared_runtime_inputs_outside_git': set(untracked) <= runtime_paths,
            'runtime_inputs_identical_and_outside_git': all(
                v['before_sha256'] == v['after_sha256'] == v['current_sha256'] and not v['tracked_in_target']
                for v in runtime_bindings.values()),
            'required_runtime_inputs_captured': set(spec.get('required_runtime_inputs',
                sorted(runtime_paths) if spec['kind'] in {'tests', 'converter'} else [])) <= before.keys(),
            'recorded_execution_successful': successful,
            'selected_test_entrypoints_captured': all(p in before for p in run['selected_tests']),
        }
        result = {
            'kind': spec['kind'], 'directory': str(run['directory']),
            'evidence': run['evidence'],
            'recorded_checkpoint': run['checkpoint'], 'expected_recorded_checkpoint': run['expected_checkpoint'],
            'input_count': len(before), 'tracked_target_match_count': sum(p in final_tree and before[p] == files[p]['target_sha256'] for p in before),
            'changed_during_run': changed, 'tracked_target_mismatches': mismatches,
            'allowed_target_mismatch_paths': allowed_mismatches,
            'mismatch_explanation': spec.get('mismatch_explanation'),
            'runtime_inputs': runtime_bindings,
            'before_sha256_by_path': before, 'after_sha256_by_path': after,
            'selected_test_entrypoints': run['selected_tests'],
            'recorded_result': {k: receipt[k] for k in ['passed', 'failed', 'skipped', 'test_file_count', 'exit_code', 'status', 'scope', 'snapshot_scope', 'runner_sha256', 'source_checkpoint_after_run'] if k in receipt},
            'recorded_commands': [{k: c[k] for k in ['name', 'argv', 'cwd', 'exit_code'] if k in c} for c in commands],
            'checks': checks,
        }
        if spec['kind'] == 'converter':
            tool = spec['tool']
            archived = run['directory'] / spec.get('archived_tool', 'acceptance-source.dart')
            archived_evidence = artifact(archived)
            compile_commands = [c for c in commands if c.get('name') == spec.get('compile_command_name', 'compile')]
            compiled_from_tool = len(compile_commands) == 1 and str(root / tool) in compile_commands[0].get('argv', [])
            checks['compiled_tool_matches_recorded_and_final_source'] = (
                tool in before and tool in files and archived_evidence['sha256'] == before[tool] == files[tool]['target_sha256']
                and compiled_from_tool)
            result['compiled_tool'] = {'path': tool, 'archive': archived_evidence,
                                       'compile_command_targets_tool': compiled_from_tool}
        bindings[name] = result

    coverage = {}
    for requirement in plan.get('library_coverage', []):
        run_name = requirement['run']
        prefix = requirement.get('prefix', '').rstrip('/') + '/'
        extension = requirement.get('suffix', '.dart')
        pattern = requirement.get('path_regex')
        selector = re.compile(pattern).fullmatch if pattern else lambda p: p.startswith(prefix) and p.endswith(extension)
        expected = {p for p in final_tree if selector(p)}
        captured = {p for p in loaded.get(run_name, {}).get('before', {}) if selector(p)}
        coverage[run_name + ':' + (pattern or prefix)] = {
            'run': run_name, 'prefix': None if pattern else prefix, 'suffix': extension,
            'path_regex': pattern,
            'scope': 'Complete library source superset, without claiming every library was compiled.',
            'target_count': len(expected), 'captured_count': len(captured),
            'missing': sorted(expected - captured), 'extra': sorted(captured - expected),
            'all_match_target': bool(expected) and all(
                loaded[run_name]['before'][p] == files[p]['target_sha256'] for p in expected & captured),
        }

    aliases = []
    for pair in plan.get('source_aliases', []):
        left, right = pair['left'], pair['right']
        require(all(re.fullmatch(r'[0-9a-f]{40}', x) for x in [left, right]), 'Source aliases must use full SHAs')
        lt, rt = git_text('rev-parse', left + '^{tree}'), git_text('rev-parse', right + '^{tree}')
        aliases.append({'left': left, 'right': right, 'left_tree': lt, 'right_tree': rt,
                        'trees_identical': lt == rt,
                        'changed_paths': git_text('diff', '--name-only', left, right).splitlines()})

    preserved_git_scopes = []
    for scope in plan.get('preserve_git_scopes', []):
        baseline = scope['commit']
        require(re.fullmatch(r'[0-9a-f]{40}', baseline) is not None, 'Preservation baseline must use a full SHA')
        prefix = scope['prefix'].rstrip('/') + '/'
        baseline_entries = {p: v for p, v in get_tree(baseline).items() if p.startswith(prefix)}
        final_entries = {p: v for p, v in final_tree.items() if p.startswith(prefix)}
        preserved_git_scopes.append({
            'baseline_commit': baseline, 'prefix': prefix,
            'baseline_entries': baseline_entries, 'target_entries': final_entries,
            'identical_path_mode_type_blob_maps': bool(baseline_entries) and baseline_entries == final_entries,
        })

    head_after = git_text('rev-parse', 'HEAD')
    current_mismatches = sorted(p for p, v in files.items() if p in final_tree and v['target_sha256'] != v['current_sha256'])
    checks = {
        'all_required_runs_loaded': not errors and len(loaded) == len(plan['runs']),
        'all_run_checks_pass': all(all(r['checks'].values()) for r in bindings.values()),
        'target_head_stable_during_audit': head_before == head_after == target,
        'current_tracked_inputs_match_target': not current_mismatches,
        'all_library_coverage_complete': bool(coverage) and all(
            c['all_match_target'] and not c['missing'] and not c['extra'] for c in coverage.values()),
        'all_declared_source_aliases_identical': all(a['trees_identical'] for a in aliases),
        'historical_artifacts_preserved': all(p['matches_expected'] for p in preserved),
        'historical_git_scopes_preserved': all(p['identical_path_mode_type_blob_maps'] for p in preserved_git_scopes),
    }
    proof = {
        'schema': 'quds-zotero-source-binding-v2',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'description': plan.get('description'),
        'scope': 'Exact byte binding of the explicitly required run snapshots to the explicit target Git tree. This is not a new test execution, compiler dependency trace, or claim that all repository files were tested.',
        'hash_algorithm': 'SHA-256 of exact bytes; Git blob IDs/modes read independently with git ls-tree and git cat-file.',
        'plan': artifact(plan_path), 'generator': artifact(Path(__file__).resolve()),
        'repository': str(root),
        'target_commit': target, 'target_tree': git_text('rev-parse', target + '^{tree}'),
        'local_head_before': head_before, 'local_head_after': head_after,
        'tracked_diff_at_audit': git_text('diff', '--name-only', target).splitlines(),
        'preserved_historical_artifacts': preserved,
        'preserved_historical_git_scopes': preserved_git_scopes,
        'source_aliases': aliases, 'library_coverage': coverage,
        'files': files, 'runs': bindings,
        'missing_or_invalid_evidence': errors,
        'current_tracked_input_mismatches': current_mismatches,
        'checks': checks, 'all_binding_checks_passed': all(checks.values()),
    }
    require(not any(output == path(p['path']) for p in preserved), 'Output would replace historical evidence')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(proof, indent=2) + '\n')
    print(json.dumps({'output': str(output), 'sha256': digest(output.read_bytes()),
                      'checks': checks, 'all_binding_checks_passed': proof['all_binding_checks_passed'],
                      'runs': {n: {'inputs': r['input_count'], 'tracked_matches': r['tracked_target_match_count'],
                                    'target_mismatches': r['tracked_target_mismatches'], 'checks': r['checks']}
                               for n, r in bindings.items()}, 'errors': errors}, indent=2))
    return 0 if proof['all_binding_checks_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
