import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/4d323337693a/quds_office_suite')
OUT = Path(__file__).resolve().parent
EDITOR = ROOT / 'packages/quds_office_editor'
BASELINE = '0174014db7524ec3656736adfe06e920b1588326'
SUITES = [
    'word_odt_load_test.dart',
    'word_odt_merged_table_load_test.dart',
    'word_zotero_citing_controller_test.dart',
    'word_zotero_bibliography_controller_test.dart',
    'word_zotero_transfer_controller_test.dart',
    'word_zotero_note_target_test.dart',
    'word_selection_paint_test.dart',
    'word_proofing_geometry_test.dart',
    'word_live_review_selection_test.dart',
    'word_odt_image_load_test.dart',
    'word_selection_path_cache_test.dart',
    'word_header_footer_navigation_test.dart',
    'word_page_text_cache_test.dart',
]
STATIC = [
    'lib/src/editor_word/render_word_canvas.dart',
    'test/word_page_text_cache_test.dart',
]


def snapshot():
    inputs = {EDITOR / 'test' / name for name in SUITES}
    inputs.update(ROOT.glob('packages/**/lib/**/*.dart'))
    inputs.update(ROOT.glob('pubspec.*'))
    inputs.update(ROOT.glob('packages/*/pubspec.yaml'))
    inputs.update([ROOT / '.fvmrc', ROOT / '.dart_tool/package_config.json',
                   EDITOR / 'example/pubspec.yaml'])
    inputs.update(path for path in (ROOT / 'packages/quds_office_engine/test/fixtures/zotero').rglob('*') if path.is_file())
    for name in ['support/office_golden.dart', 'support/review_fonts.dart',
                 'goldens/linux/word_selection_macOS.png', 'goldens/linux/word_selection_windows.png',
                 'flutter_test_config.dart']:
        path = EDITOR / 'test' / name
        if path.is_file():
            inputs.add(path)
    assert all(path.is_file() for path in inputs)
    return {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(inputs)}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('scope', choices=['editor', 'static'])
    parser.add_argument('--checkpoint', required=True)
    args = parser.parse_args()
    assert git('rev-parse', 'HEAD') == args.checkpoint
    dest = OUT / args.scope
    dest.mkdir(exist_ok=False)
    before = snapshot()
    write(dest / 'inputs-before.json', before)
    common = {'scope': args.scope, 'qualified_checkpoint': args.checkpoint,
              'source_checkpoint_before_run': git('rev-parse', 'HEAD'),
              'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'snapshot_scope': 'Selected editor suites, package library Dart sources, SDK/dependency manifests, Zotero fixtures, consumed review helpers and Linux selection goldens.',
              'source_inputs': len(before), 'github_actions_used': False}
    print(json.dumps({'scope': args.scope, 'started': True, 'source_inputs': len(before)}), flush=True)
    if args.scope == 'editor':
        argv = ['flutter', 'test', '--no-pub', '--concurrency=2', '--reporter=json',
                *['test/' + name for name in SUITES]]
        write(dest / 'command.json', {'cwd': str(EDITOR), 'argv': argv})
        started = time.monotonic()
        with (dest / 'events.jsonl').open('w') as stdout, (dest / 'stderr.log').open('w') as stderr:
            result = subprocess.run(argv, cwd=EDITOR, stdout=stdout, stderr=stderr)
        elapsed = time.monotonic() - started
        events = []
        non_json = []
        for line in (dest / 'events.jsonl').read_text().splitlines():
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                non_json.append(line)
        names = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
        cases = []
        for event in events:
            if event.get('type') != 'testDone' or event.get('hidden'):
                continue
            info = names.get(event['testID'], {})
            cases.append({'name': info.get('name'), 'suite': info.get('suiteID'),
                          'result': event.get('result'), 'skipped': event.get('skipped', False)})
        done = [e for e in events if e.get('type') == 'done']
        errors = [e for e in events if e.get('type') == 'error']
        receipt = {**common, 'cwd': str(EDITOR), 'argv': argv, 'exit_code': result.returncode,
                   'elapsed_seconds': elapsed, 'test_file_count': len(SUITES),
                   'passed': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
                   'failed': sum(c['result'] != 'success' and not c['skipped'] for c in cases),
                   'skipped': sum(c['skipped'] for c in cases), 'errors': errors,
                   'reporter_done': done, 'non_json_lines': non_json}
        write(dest / 'cases.json', cases)
        ok = result.returncode == 0 and len(done) == 1 and done[0].get('success') and not errors
    else:
        root_paths = [str((EDITOR / path).relative_to(ROOT)) for path in STATIC]
        commands = [
            ('format', EDITOR, ['dart', 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed', *STATIC]),
            ('analysis', EDITOR, ['dart', 'analyze', '--fatal-infos', *STATIC]),
            ('diff-check', ROOT, ['git', 'diff', '--check', BASELINE, args.checkpoint, '--', *root_paths]),
            ('worktree-check', ROOT, ['git', 'diff', '--check']),
        ]
        checks = []
        for name, cwd, argv in commands:
            print(json.dumps({'check': name, 'started': True}), flush=True)
            started = time.monotonic()
            with (dest / (name + '.stdout')).open('w') as stdout, (dest / (name + '.stderr')).open('w') as stderr:
                result = subprocess.run(argv, cwd=cwd, stdout=stdout, stderr=stderr)
            checks.append({'name': name, 'cwd': str(cwd), 'argv': argv,
                           'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - started})
        ok = all(check['exit_code'] == 0 for check in checks)
        receipt = {**common, 'targets': root_paths, 'target_file_count': len(STATIC),
                   'baseline_checkpoint': BASELINE, 'checks': checks, 'passed': ok}
    after = snapshot()
    write(dest / 'inputs-after.json', after)
    receipt.update(source_checkpoint_after_run=git('rev-parse', 'HEAD'),
                   inputs_unchanged=before == after,
                   changed_inputs=sorted(key for key in before.keys() | after.keys() if before.get(key) != after.get(key)))
    receipt['status'] = 'PASS' if ok and before == after else 'FAIL'
    write(dest / 'receipt.json', receipt)
    print(json.dumps({key: value for key, value in receipt.items()
                      if key not in ['argv', 'non_json_lines', 'reporter_done', 'checks']}, indent=2), flush=True)
    raise SystemExit(0 if receipt['status'] == 'PASS' else 1)


if __name__ == '__main__':
    main()
