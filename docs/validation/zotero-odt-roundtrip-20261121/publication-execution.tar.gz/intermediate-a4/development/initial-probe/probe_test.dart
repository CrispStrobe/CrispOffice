import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_editor/quds_office_editor.dart';

WmlParagraph _paragraph(String text) => WmlParagraph(
  inlines: [
    WmlRun(
      text: text,
      properties: WmlRunProps(color: '0563C1', fontSizeHalfPoints: 32),
    ),
  ],
);

void main() {
  for (final scenario in ['table band', 'header exit']) {
    testWidgets('$scenario repaint matches a fresh dark text layer', (tester) async {
      tester.view.devicePixelRatio = 1;
      tester.view.physicalSize = const Size(500, 400);
      addTearDown(tester.view.resetDevicePixelRatio);
      addTearDown(tester.view.resetPhysicalSize);
      final table = WmlTable(
        grid: [120, 120],
        rows: [
          WmlTableRow(cells: [
            WmlTableCell(width: 120, blocks: [_paragraph('First cell')]),
            WmlTableCell(width: 120, blocks: [_paragraph('Second cell')]),
          ]),
        ],
      );
      final section = WmlSection(
        pageSize: const WmlPageSize(width: 300, height: 250),
        margins: const WmlPageMargins(
          top: 60, bottom: 40, left: 20, right: 20, header: 15, footer: 15,
        ),
        header: [_paragraph('Header text')],
        blocks: [table],
      );
      final document = WmlDocument(sections: [section]);
      final layout = WordLayoutEngine(font: null).layout(document);
      final caret = CaretEngine();
      const boundaryKey = ValueKey('page-text-cache-image');
      const retainedKey = ValueKey('retained-page-text-canvas');
      final band = (table: table, column: false, from: 0, to: 0);
      const config = OfficeSurfaceConfig(
        mode: OfficeInteractionMode.selecting,
        theme: OfficeTheme.dark,
        showRulers: false,
      );

      Future<void> mount(Key key, {required bool finalState}) async {
        final editing = scenario == 'header exit' && !finalState;
        await tester.pumpWidget(Directionality(
          textDirection: TextDirection.ltr,
          child: RepaintBoundary(
            key: boundaryKey,
            child: WordCanvas(
              key: key,
              document: document,
              laidOut: layout,
              caret: caret,
              selectedTableBand: scenario == 'table band' && finalState ? band : null,
              editingHeader: editing,
              storyParagraphs: editing ? section.header : null,
              config: config,
            ),
          ),
        ));
        await tester.pump();
        expect(tester.takeException(), isNull);
      }

      Future<Uint8List> pixels() async {
        final boundary = tester.renderObject<RenderRepaintBoundary>(find.byKey(boundaryKey));
        final image = (await tester.runAsync(() => boundary.toImage(pixelRatio: 1)))!;
        final bytes = (await tester.runAsync(() => image.toByteData(format: ui.ImageByteFormat.rawRgba)))!;
        final result = Uint8List.fromList(bytes.buffer.asUint8List());
        image.dispose();
        return result;
      }

      await mount(retainedKey, finalState: false);
      final retained = tester.renderObject<RenderWordCanvas>(find.byType(WordCanvas));
      await mount(retainedKey, finalState: true);
      expect(tester.renderObject<RenderWordCanvas>(find.byType(WordCanvas)), same(retained));
      final cached = await pixels();
      await mount(UniqueKey(), finalState: true);
      final fresh = await pixels();
      expect(cached.length, fresh.length);
      var differentBytes = 0;
      for (var i = 0; i < cached.length; i++) {
        if (cached[i] != fresh[i]) differentBytes++;
      }
      expect(differentBytes, 0, reason: '$scenario changed $differentBytes cached color bytes against the fresh canvas.');
    });
  }
}
