#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, sys, time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / sys.argv[1]
REPO = ROOT.parent / 'quds_office_suite'
RUNTIME = ROOT.parent / 'zotero-runtime'
DART = RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'
SOFFICE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/program/soffice')
TOOL = REPO / 'packages/quds_office_engine/tool/zotero/odt_roundtrip_acceptance.dart'
CONFIG = REPO / '.dart_tool/package_config.json'
NAMES = ['body-bibliography', 'table-only', 'endnote-only', 'uppercase-citations']
EXPECTED_SOURCE = sys.argv[2]
CURRENT_SOURCE = subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
if CURRENT_SOURCE != EXPECTED_SOURCE: raise RuntimeError('Source checkpoint differs from requested immutable checkpoint.')
fixture = next((arg[10:] for arg in sys.argv[2:] if arg.startswith('--fixture=')), None)
if fixture is not None:
    if fixture not in NAMES: raise ValueError(fixture)
    NAMES = [fixture]
SELECTOR = [] if fixture is None else ['--fixture='+fixture]
OUT.mkdir(exist_ok=False)
env = dict(os.environ, PUB_CACHE=str(RUNTIME/'pub-cache'), FLUTTER_ROOT=str(RUNTIME/'flutter'), CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true', DASH__SUPPRESS_ANALYTICS='true', XDG_CONFIG_HOME=str(RUNTIME/'config'), XDG_CACHE_HOME=str(RUNTIME/'cache'), XDG_DATA_HOME=str(RUNTIME/'data'), TMPDIR=str(RUNTIME/'tmp'))
receipt = {'started_at_utc':datetime.now(timezone.utc).isoformat(),'status':'running','commands':[]}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def fixtures(directory):
    return {p.name:sha(p) for p in sorted(directory.glob('*')) if p.is_file() and p.suffix in ['.odt','.docx','.json']}
def source():
    paths = [TOOL, CONFIG, REPO/'pubspec.lock', REPO/'pubspec.yaml']
    for package in ['quds_office_engine','legacy_doc_parser']:
        paths += list((REPO/'packages'/package/'lib').rglob('*.dart'))
        paths.append(REPO/'packages'/package/'pubspec.yaml')
    return {str(p.relative_to(REPO)):sha(p) for p in sorted(set(paths))}
def save(): (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(name,args):
    args=list(map(str,args)); start=time.monotonic(); out=OUT/(name+'.stdout.log'); err=OUT/(name+'.stderr.log')
    with out.open('wb') as stdout, err.open('wb') as stderr:
        result=subprocess.run(args,cwd=REPO,env=env,stdout=stdout,stderr=stderr,timeout=180)
    receipt['commands'].append({'name':name,'argv':args,'cwd':str(REPO),'exit_code':result.returncode,'seconds':round(time.monotonic()-start,3),'stdout':out.name,'stdout_sha256':sha(out),'stderr':err.name,'stderr_sha256':sha(err)})
    save();print(name,result.returncode,flush=True)
    if result.returncode: raise RuntimeError(name+': '+err.read_text(errors='replace')[-10000:])
def convert(name,source,dest):
    dest.mkdir(exist_ok=False)
    run(name,[SOFFICE,'-env:UserInstallation='+(OUT/'profile').as_uri(),'--headless','--convert-to','odt:writer8','--outdir',dest,*[source/(n+'.odt') for n in NAMES]])
before=source(); (OUT/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
(OUT/'acceptance-source.dart').write_bytes(TOOL.read_bytes())
receipt['source_commit']=CURRENT_SOURCE
receipt['scope']='Four core synthetic fixtures: body/bibliography3 fields, tables6, endnotes2 and Unicode uppercase2;13 total. Actual two-save cycles use the authored-model oracle.'
receipt['selected_fixtures']=NAMES
receipt['runtime_receipt_sha256']=sha(RUNTIME/'runtime.json')
receipt['soffice_binary_sha256']=sha(SOFFICE.with_name('soffice.bin'))
try:
    run('dart-version',[DART,'--version'])
    run('libreoffice-version',[SOFFICE,'--version'])
    run('compile',[DART,'compile','kernel','--packages='+str(CONFIG),TOOL,'-o',OUT/'acceptance.dill'])
    prefix=[DART,'--packages='+str(CONFIG),OUT/'acceptance.dill']
    run('create',[*prefix,'create',OUT/'original',*SELECTOR])
    receipt['original_fixture_hashes_before']=fixtures(OUT/'original')
    convert('libreoffice-first-save',OUT/'original',OUT/'saved-first')
    receipt['saved_first_fixture_hashes_before']=fixtures(OUT/'saved-first')
    run('verify-first',[*prefix,'verify',OUT/'saved-first',OUT/'original',*SELECTOR])
    if 'first' in sys.argv[2:]:
        receipt['status']='passed-first-save-only'
    else:
        run('docx-and-odt-reexport',[*prefix,'reexport',OUT/'saved-first',OUT/'original',OUT/'reexported',*SELECTOR])
        receipt['reexported_fixture_hashes_before']=fixtures(OUT/'reexported')
        convert('libreoffice-second-save',OUT/'reexported',OUT/'saved-second')
        receipt['saved_second_fixture_hashes_before']=fixtures(OUT/'saved-second')
        run('verify-second',[*prefix,'verify',OUT/'saved-second',OUT/'original',*SELECTOR])
        receipt['status']='passed'
except BaseException as error:
    receipt['status']='failed';receipt['error']=repr(error);raise
finally:
    after=source();(OUT/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
    receipt['source_unchanged']=before==after
    receipt['source_changes']=[p for p in sorted(before.keys()|after.keys()) if before.get(p)!=after.get(p)]
    if 'original_fixture_hashes_before' in receipt:
        receipt['original_fixtures_unchanged']=receipt['original_fixture_hashes_before']==fixtures(OUT/'original')
    if 'reexported_fixture_hashes_before' in receipt:
        receipt['reexported_fixtures_unchanged']=receipt['reexported_fixture_hashes_before']==fixtures(OUT/'reexported')
    for stage in ['first','second']:
        key='saved_'+stage+'_fixture_hashes_before'
        if key in receipt: receipt['saved_'+stage+'_fixtures_unchanged']=receipt[key]==fixtures(OUT/('saved-'+stage))
    stable_keys=['source_unchanged','original_fixtures_unchanged','reexported_fixtures_unchanged','saved_first_fixtures_unchanged','saved_second_fixtures_unchanged']
    if receipt['status'].startswith('passed') and not all(receipt.get(key,True) is True for key in stable_keys):
        receipt['status']='failed';receipt['error']='Observed source or fixture inputs changed during qualification.'
    receipt['artifacts']={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file() and p.suffix in ['.odt','.docx','.json','.dart','.log'] and 'profile' not in p.parts and p.name!='receipt.json'}
    receipt['finished_at_utc']=datetime.now(timezone.utc).isoformat();save()

if not receipt['status'].startswith('passed'): raise RuntimeError(receipt.get('error','Qualification did not pass.'))
