"""Read-only Git ref accounting; outputs receipts only into scratch."""

import argparse
import collections
import datetime
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/4d323337693a/quds_office_suite')
INITIAL = Path('/workspace/scratch/4d323337693a/intake-equivalence.json')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def snapshot():
    raw = git('for-each-ref', '--format=%(refname) %(objectname)', 'refs/remotes')
    return dict(line.split(' ', 1) for line in raw.splitlines())


def verify_equivalence(candidate, main_ancestors, checkpoint_ancestors):
    head = candidate['head']
    replacement = candidate['replacement']
    head_tree = git('rev-parse', head + '^{tree}')
    replacement_tree = git('rev-parse', replacement + '^{tree}')
    result = {
        'ref': candidate['ref'], 'head': head, 'replacement': replacement,
        'replacement_is_main_ancestor': replacement in main_ancestors,
        'replacement_is_checkpoint_ancestor': replacement in checkpoint_ancestors,
        'head_tree': head_tree, 'replacement_tree': replacement_tree,
    }
    if head_tree == replacement_tree:
        result.update(proof='identical_complete_git_tree', exact=True)
    else:
        bases = git('merge-base', '--all', head, replacement).splitlines()
        assert len(bases) == 1
        paths = git('diff', '--name-only', bases[0], head).splitlines()
        entries = []
        for path in paths:
            left = git('ls-tree', head, '--', path)
            right = git('ls-tree', replacement, '--', path)
            entries.append({'path': path, 'head_entry': left,
                            'replacement_entry': right, 'identical': left == right})
        result.update(proof='identical_changed_path_mode_type_blob', merge_base=bases[0],
                      changed_path_count=len(paths), entries=entries,
                      exact=all(entry['identical'] for entry in entries))
    result['verified'] = result['exact'] and result['replacement_is_main_ancestor'] and result['replacement_is_checkpoint_ancestor']
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    parser.add_argument('--checkpoint', default='HEAD')
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    captured = datetime.datetime.now(datetime.timezone.utc).isoformat()
    refs_before = snapshot()
    observed_head = git('rev-parse', 'HEAD')
    checkpoint = git('rev-parse', args.checkpoint)
    main_sha = refs_before['refs/remotes/origin/main']
    main_ancestors = set(git('rev-list', main_sha).splitlines())
    checkpoint_ancestors = set(git('rev-list', checkpoint).splitlines())
    initial = json.loads(INITIAL.read_text())
    initial_refs = {row['ref']: row['sha'] for row in initial['refs']}
    proofs = [verify_equivalence(row, main_ancestors, checkpoint_ancestors)
              for row in initial['equivalences']]
    proof_by_sha = {row['head']: row for row in proofs}

    initial_coverage = []
    for ref, sha in initial_refs.items():
        if sha in checkpoint_ancestors and sha in main_ancestors:
            disposition = 'ancestor_of_main_and_checkpoint'
        elif sha in proof_by_sha and proof_by_sha[sha]['verified']:
            disposition = 'independently_verified_historical_equivalent'
        else:
            disposition = 'uncovered_initial_tip'
        initial_coverage.append({'ref': ref, 'initial_sha': sha,
                                 'disposition': disposition})

    records = []
    for ref, sha in refs_before.items():
        if ref in {'refs/remotes/origin/HEAD', 'refs/remotes/upstream/HEAD'}:
            continue
        is_main = sha in main_ancestors
        is_checkpoint = sha in checkpoint_ancestors
        if is_main and is_checkpoint:
            disposition = 'ancestor_of_main_and_checkpoint'
        elif is_checkpoint:
            disposition = 'current_checkpoint_ancestry_only'
        elif is_main:
            disposition = 'incoming_main_not_yet_in_checkpoint'
        elif sha in proof_by_sha and proof_by_sha[sha]['verified']:
            disposition = 'independently_verified_historical_equivalent'
        elif ref not in initial_refs or initial_refs[ref] != sha:
            disposition = 'later_concurrent_ongoing_ref'
        else:
            disposition = 'uncovered_initial_ref'
        record = {
            'ref': ref, 'sha': sha, 'ancestor_of_latest_main': is_main,
            'ancestor_of_checkpoint': is_checkpoint, 'disposition': disposition,
            'change_since_initial': 'new' if ref not in initial_refs else
                'advanced' if initial_refs[ref] != sha else 'unchanged',
        }
        if disposition == 'later_concurrent_ongoing_ref':
            record.update(
                subject=git('show', '-s', '--format=%s', sha),
                unique_commits_against_main=git('rev-list', '--count', main_sha + '..' + sha),
                unique_commits_against_checkpoint=git('rev-list', '--count', checkpoint + '..' + sha),
                qualification='Ongoing ref explicitly accounted for; not claimed merged or qualified by this audit.',
            )
        records.append(record)

    refs_after = snapshot()
    head_after = git('rev-parse', 'HEAD')
    incoming_commits = git('log', '--format=%H %s', checkpoint + '..' + main_sha).splitlines()
    summary = {
        'total_refs': len(records),
        'by_remote': dict(collections.Counter(row['ref'].split('/')[2] for row in records)),
        'by_disposition': dict(collections.Counter(row['disposition'] for row in records)),
        'initial_tips': len(initial_coverage),
        'initial_coverage': dict(collections.Counter(row['disposition'] for row in initial_coverage)),
        'historical_proofs_verified': sum(row['verified'] for row in proofs),
        'new_refs': sum(row['change_since_initial'] == 'new' for row in records),
        'advanced_refs': sum(row['change_since_initial'] == 'advanced' for row in records),
        'main_is_checkpoint_ancestor': main_sha in checkpoint_ancestors,
        'snapshot_stable': refs_before == refs_after and observed_head == head_after,
    }
    receipt = {
        'schema_version': 1, 'captured_utc': captured,
        'repository': 'CrispStrobe/quds_office_suite',
        'initial_baseline': initial['captured_main'], 'latest_main': main_sha,
        'checkpoint': checkpoint, 'summary': summary,
        'checkpoint_input': args.checkpoint, 'observed_head_before': observed_head,
        'method': 'Read-only inspection of already fetched immutable Git objects. Initial candidate replacements independently reverified by exact tree or changed-path mode/type/blob identities and both ancestry chains. No fetch, merge, ref/index/worktree/remote mutation or GitHub Actions interaction. Later concurrent refs are explicit ongoing dispositions, not claims of integration.',
        'raw_refs': [{'ref': ref, 'sha': sha} for ref, sha in refs_before.items()],
        'refs': records, 'initial_tip_coverage': initial_coverage,
        'historical_equivalence_proofs': proofs,
        'incoming_main_commits': [{'sha': line.split(' ', 1)[0], 'subject': line.split(' ', 1)[1]} for line in incoming_commits],
        'initial_refs_no_longer_advertised': [ref for ref in initial_refs if ref not in refs_before],
        'head_after': head_after,
        'changed_refs_during_audit': [ref for ref in set(refs_before) | set(refs_after) if refs_before.get(ref) != refs_after.get(ref)],
    }
    (output / 'all-ref-accounting.json').write_text(json.dumps(receipt, indent=2) + '\n')
    (output / 'refs.txt').write_text(''.join(f'{sha} {ref}\n' for ref, sha in refs_before.items()))
    ongoing = [row for row in records if row['disposition'] == 'later_concurrent_ongoing_ref']
    report = [
        '# Final fetched-ref accounting', '', f'Captured UTC: {captured}.',
        f'Latest main: `{main_sha}`. Checkpoint: `{checkpoint}`.', '',
        'The exact snapshot includes every fetched remote ref. Symbolic origin/HEAD and upstream/HEAD are retained in the raw snapshot but excluded from totals.', '',
        '## Summary', '', '```json', json.dumps(summary, indent=2), '```', '',
        'All initial task-start tip identities are checked independently of whether their branch names advanced later. Historical proof candidates are reverified from Git object identities.', '',
        '## Later concurrent ongoing refs', '',
        '| Ref | SHA | Subject |', '| --- | --- | --- |',
        *[f"| {row['ref']} | `{row['sha']}` | {row['subject']} |" for row in ongoing], '',
        'These refs are accounted for as ongoing work. This audit does not claim they were merged, qualified, or approved for integration.', '',
        '## Incoming main commits absent from checkpoint', '',
        *([f"- `{row['sha']}` {row['subject']}" for row in receipt['incoming_main_commits']] or ['None.']), '',
        'No Git mutations or GitHub Actions interactions were performed.', '',
    ]
    (output / 'review.md').write_text('\n'.join(report))
    print(json.dumps({'latest_main': main_sha, 'checkpoint': checkpoint,
                      'summary': summary, 'incoming_main_commits': receipt['incoming_main_commits'],
                      'ongoing_refs': ongoing, 'output': str(output)}, indent=2))
    if not summary['snapshot_stable'] or any('uncovered' in row['disposition'] for row in initial_coverage + records) or not all(row['verified'] for row in proofs):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
