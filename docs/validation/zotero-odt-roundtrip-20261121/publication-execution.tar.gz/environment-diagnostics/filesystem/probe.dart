import 'dart:convert';
import 'dart:io';

Future<void> main(List<String> args) async {
  final base = Directory(args[0]);
  final tag = args[1];
  final results = <Map<String, Object?>>[];
  Future<void> check(String name, Future<Directory> Function() action) async {
    Directory? directory;
    try {
      directory = await action();
      results.add({'operation': name, 'success': true, 'path': directory.path, 'exists': directory.existsSync()});
    } on FileSystemException catch (error) {
      results.add({'operation': name, 'success': false, 'error': error.toString(), 'errorCode': error.osError?.errorCode, 'errorPath': error.path});
    } catch (error) {
      results.add({'operation': name, 'success': false, 'error': error.toString()});
    } finally {
      if (directory != null && directory.existsSync()) directory.deleteSync(recursive: true);
    }
  }
  await check('direct_create_sync', () async => Directory('${base.path}/$tag-dart-sync')..createSync());
  await check('recursive_create_sync', () async {
    final parent = Directory('${base.path}/$tag-dart-recursive');
    Directory('${parent.path}/child').createSync(recursive: true);
    return parent;
  });
  await check('direct_create_async', () => Directory('${base.path}/$tag-dart-async').create());
  await check('explicit_temp_sync', () async => base.createTempSync('$tag-dart-explicit-'));
  await check('explicit_temp_async', () => base.createTemp('$tag-dart-async-temp-'));
  await check('system_temp_sync', () async => Directory.systemTemp.createTempSync('$tag-dart-system-'));
  print(jsonEncode({'runtime': 'Dart', 'version': Platform.version, 'executable': Platform.executable, 'cwd': Directory.current.path, 'configuredTmpdir': Platform.environment['TMPDIR'], 'systemTemp': Directory.systemTemp.path, 'results': results}));
}
