import 'dart:async';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_mail_core/quds_mail_core.dart';
import 'package:quds_mail_store/quds_mail_store.dart';
import 'package:quds_office_studio/studio_mail_mailbox_session.dart';
import 'package:quds_office_studio/studio_mail_mailbox_store.dart';
final account = MailAccountId('a', profile: MailProfileId('p', hostId: 'h'));
final mailbox = MailMailboxId('inbox', account: account);
final class OneShot extends Fake implements StudioMailMailboxStore {
  @override MailAccountId get account => mailbox.account;
  @override Future<MailCachedMailboxView?> loadView(MailMailboxId box) async => MailCachedMailboxView(mailbox: MailMailbox(id: box, displayName:'Inbox'), revision:1, capturedAt: DateTime.utc(2026), headers:[], hasMore:false);
}
void main() {
 testWidgets('finite-source cancellation stays in the widget task zone', (tester) async {
   final session=StudioMailMailboxSession(store: OneShot(),provider:MailProviderKind.imap);
   final subscription=session.changes.listen((event) {});
   var loaded=false;
   session.select(mailbox).then((_) => loaded=true);
   await tester.pump(); await tester.pump(const Duration(milliseconds:350)); await tester.pump();
   expect(loaded,true);
   var observedCancelled=false;
   subscription.cancel().then((_) => observedCancelled=true);
   await tester.pump();
   expect(observedCancelled,true,reason:'changes subscriber cancellation');
   var closed=false;
   session.close().then((_)=>closed=true);
   await tester.pump(); await tester.pump(const Duration(milliseconds:350)); await tester.pump();
   expect(closed,true,reason:'session close after finite source completed');
 });
 testWidgets('SDK finite subscription cancel completion', (tester) async {
   var done=false;
   final stream=Stream<int>.fromFuture(Future.value(1));
   final subscription=stream.listen((_) {},onDone:()=>done=true);
   await tester.pump();
   expect(done,true);
   var canceled=false;
   subscription.cancel().then((_)=>canceled=true);
   await tester.pump(); await tester.pump(const Duration(milliseconds:350)); await tester.pump();
   expect(canceled,true);
 });
}
