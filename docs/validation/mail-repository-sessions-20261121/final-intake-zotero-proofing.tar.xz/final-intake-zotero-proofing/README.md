# Final-cutoff Zotero and proofing qualification

The selected final-cutoff cohorts pass **562 tests**, with **zero failures or
skips**, and **three targeted analyzer groups** pass with `--fatal-infos`.
All gates used unchanged, identical engine/editor/Studio/Hunspell source-tree
fingerprints. No source or test repair was needed after the source freeze.

The frozen worktree is `8ff607b914f1a2828e6dceb68d4859e7f0ed4a8e`, tree
`c6e320878ceffb5ba640e62e4f0046988c86dfbe`; remote source checkpoint
`721ad2c74a5d81d54c2eaa2af084e82ba5077991` has the identical tree. The observed
incoming-branch cutoff is 2026-11-21 06:15:44 UTC. Exact incoming heads,
production changes and documentation reconciliation are in `cutoff-review.json`.

| Cohort | Passed | Scope |
| --- | ---: | --- |
| Transfer engine | 103 | New carrier/style/ownership cases and existing transfer session/protocol contracts |
| ODT inline export | 206 | New equal-target hyperlink grouping and existing writer, bookmark, comment, field, note, visual and column boundaries |
| Transfer editor | 53 | Transfer controller/dialog and shared citing-dialog behavior |
| Proofing core | 111 | Scheduling, sessions, incremental/cache/priority/manual/draft behavior |
| Proofing UI | 89 | Changed correction-menu/notes timing, review/dialog/navigation and correction workflows |

Engine, editor and the typed benchmark adapter have separate clean analyzer
receipts. The benchmark was not executed as a performance measurement.

## Evidence and reproduction

`summary.json` records exact commands through each per-gate receipt, runtime
identities, lock/config hashes, all target/test hashes and before/after source
fingerprints. `run_gates.py` reproduces a selected label after sourcing the pinned
runtime environment. Pure Dart groups use locked package:test 1.31.1 directly
with the kernel/VM runner; Flutter groups use genuine Flutter 3.47.8/Dart 3.13.7,
`--no-pub`, concurrency two and dedicated JSON file reporters. Logs are lossless
gzip files with compressed and uncompressed SHA256 digests.

This record supplements the earlier 649-test incoming-branch qualification; it
does not change that record's source scope or count overlapping tests as unique
across records. Section source had no new semantic changes; Mail and section
acceptance remains separately recorded. No GitHub Actions queue was queried or
awaited, and no broader optional suite was run after these selected gates passed.

## Limits

The local protocol, model, widget and ODT export-structure checks do not establish
installed Word/LibreOffice/Zotero plugin or independent converter acceptance.
Direct native ODT reference-mark input remains separate. Comparative-editor
source notes retain their attributed research and qualified scope. No new
comparative typing or target-device performance measurement is claimed.
