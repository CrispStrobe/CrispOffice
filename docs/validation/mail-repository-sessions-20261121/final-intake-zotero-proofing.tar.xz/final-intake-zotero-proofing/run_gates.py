import datetime, hashlib, json, os, pathlib, subprocess, sys, time
root = pathlib.Path(__file__).resolve().parents[4]
runtime = pathlib.Path(os.environ['FLUTTER_ROOT']).parent
output = root/'docs/validation/mail-repository-sessions-20261121/final-intake-zotero-proofing'
output.mkdir(parents=True, exist_ok=True)
engine='packages/quds_office_engine'
editor='packages/quds_office_editor'
studio=editor+'/example'
hunspell='packages/quds_proofing_hunspell'

def dart_tests(package, names):
    return (package, [str(runtime/'bin/dart'), '--disable-dart-dev', '--packages='+str(root/'.dart_tool/package_config.json'), str(runtime/'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'), '--compiler=kernel', '--platform', 'vm', '--reporter', 'expanded', '--concurrency=2', *['test/'+n+'.dart' for n in names]])
def flutter_tests(package,names):
    return (package,[str(runtime/'bin/flutter'),'test','--no-pub','--reporter','expanded','--concurrency=2',*['test/'+n+'.dart' for n in names]])
def analyze(package,paths):
    return (package,[str(runtime/'bin/dart'),'analyze','--fatal-infos',*paths])
gates={
'final-zotero-engine':dart_tests(engine,['word_zotero_transfer_test','word_zotero_transfer_session_test','zotero_transfer_protocol_test']),
'final-odt-inline':dart_tests(engine,['odt_hyperlink_range_fidelity_test','odt_document_writer_test','odt_bookmark_range_fidelity_test','odt_comment_fidelity_test','odt_header_variant_comment_fidelity_test','odt_inline_field_fidelity_test','odt_complex_field_fidelity_test','odt_page_field_fidelity_test','odt_inline_column_break_fidelity_test','odt_column_break_style_fidelity_test','odt_note_fidelity_test','odt_story_visual_fidelity_test']),
'final-zotero-editor':flutter_tests(editor,['word_zotero_transfer_controller_test','word_zotero_transfer_dialog_test','word_zotero_citing_dialog_test']),
'final-proofing-core':flutter_tests(editor,['word_typing_proofing_schedule_test','word_proofing_session_test','word_incremental_proofing_test','word_proofing_capture_cache_test','word_proofing_priority_test','word_manual_proofing_test','word_draft_proofing_test']),
'final-proofing-ui':flutter_tests(editor,['word_incremental_proofing_menu_test','word_notes_proofing_pane_test','word_proofing_dialog_test','word_review_pane_test','word_proofing_navigation_test','word_proofing_correction_test']),
'analysis-final-engine':analyze(engine,['lib/src/word/model/word_zotero_transfer.dart','lib/src/word/serial/odt_document_writer.dart','test/word_zotero_transfer_test.dart','test/odt_hyperlink_range_fidelity_test.dart','tool/zotero/transfer_acceptance.dart']),
'analysis-final-editor':analyze(editor,['lib/src/embed/word_zotero_dialog.dart','lib/src/proofing/word_proofing.dart','test/word_typing_proofing_schedule_test.dart','test/word_incremental_proofing_menu_test.dart','test/word_notes_proofing_pane_test.dart','test/word_zotero_transfer_controller_test.dart','test/word_zotero_transfer_dialog_test.dart']),
'analysis-final-benchmark':analyze(studio,['test/studio_typing_proofing_benchmark_test.dart']),
}

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def tree_hash(path):
    files=sorted((root/path).rglob('*.dart'))
    data=''.join(p.relative_to(root).as_posix()+'\0'+sha(p)+'\n' for p in files).encode()
    return {'file_count':len(files),'sha256':hashlib.sha256(data).hexdigest()}
def snapshot():return {p:tree_hash(p) for p in [engine+'/lib',editor+'/lib',studio+'/lib',hunspell+'/lib']}
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
status=0
for label in sys.argv[1:]:
    package,command=gates[label]
    attempt=1
    while (output/f'{label}-{attempt}.json').exists(): attempt+=1
    prefix=output/f'{label}-{attempt}'
    events=prefix.with_suffix('.events.jsonl')
    if not label.startswith('analysis-'):
        command=[*command,'--file-reporter','json:'+str(events)]
    before=snapshot()
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    began=time.monotonic()
    print(json.dumps({'label':label,'attempt':attempt,'started_utc':start}),flush=True)
    with prefix.with_suffix('.stdout').open('w') as stdout,prefix.with_suffix('.stderr').open('w') as stderr:
        result=subprocess.run(command,cwd=root/package,stdout=stdout,stderr=stderr)
    after=snapshot()
    tested_paths=[package+'/'+arg for arg in command if arg.startswith(('lib/','test/')) and (root/package/arg).is_file()]
    receipt={'label':label,'attempt':attempt,'started_utc':start,'duration_seconds':round(time.monotonic()-began,3),'command':command,'working_directory':package,'exit_code':result.returncode,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_tree_hash_algorithm':'SHA256 sorted(relative_path + NUL + file_sha256 + LF) for Dart files','source_before':before,'source_after':after,'source_unchanged':before==after,'exact_inputs_sha256':{p:sha(root/p) for p in tested_paths},'package_config_sha256':sha(root/'.dart_tool/package_config.json'),'pubspec_lock_sha256':sha(root/'pubspec.lock'),'stdout_file':prefix.with_suffix('.stdout').name,'stderr_file':prefix.with_suffix('.stderr').name}
    if events.exists():
        parsed=[json.loads(line) for line in events.read_text().splitlines() if line.startswith('{')]
        completed=[e for e in parsed if e.get('type')=='testDone' and not e.get('hidden')]
        receipt['tests']={'passed':sum(e.get('result')=='success' and not e.get('skipped') for e in completed),'failed':sum(e.get('result')!='success' and not e.get('skipped') for e in completed),'skipped':sum(bool(e.get('skipped')) for e in completed),'completed':any(e.get('type')=='done' and e.get('success') is True for e in parsed)}
        receipt['events_file']=events.name
    write(prefix.with_suffix('.json'),receipt)
    print(json.dumps({'label':label,'attempt':attempt,'exit_code':result.returncode,'duration_seconds':receipt['duration_seconds'],'source_unchanged':receipt['source_unchanged'],'tests':receipt.get('tests'),'receipt':str(prefix.with_suffix('.json'))}),flush=True)
    if result.returncode or not receipt['source_unchanged']:status=1
sys.exit(status)
