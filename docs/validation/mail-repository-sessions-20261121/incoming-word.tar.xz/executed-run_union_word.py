from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import base64
import hashlib
import json
import shutil
import subprocess
import time
from pathlib import Path

BASE = Path('/workspace/scratch/1a7ed08f64fe')
REPO = BASE / 'mail-union-20261121'
OUT = BASE / 'mail-validation/union-word'
RUNTIME = BASE / 'mail-runtime'
OUT.mkdir(parents=True, exist_ok=True)
ENGINE = REPO / 'packages/quds_office_engine'
EDITOR = REPO / 'packages/quds_office_editor'
TEST_RUNNER = RUNTIME / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
NATIVE_TESTS = [
    'test/office_macro_word_orientation_test.dart',
    'test/office_macro_word_section_start_test.dart',
    'test/office_vba_word_sections_test.dart',
    'test/office_vba_word_sections_integration_test.dart',
    'test/office_vba_word_page_setup_test.dart',
    'test/office_vba_word_page_setup_integration_test.dart',
    'test/word_section_clone_fidelity_test.dart',
    'test/word_structure_integrity_test.dart',
]
EDITOR_ANALYSIS = [
    'lib/src/embed/office_controller.dart',
    'test/word_incremental_layout_equivalence_test.dart',
    '../quds_office_engine/lib/src/word/layout/word_layout.dart',
    'example/integration_test/typing_profile_test.dart',
    'example/test/studio_typing_proofing_benchmark_test.dart',
    'example/test_driver/typing_profile_driver.dart',
]
EXPECTED_SKIPS = {
    'incremental layout equals full layout fixture legacy_doc_parser/test/fixtures/fidelity/image-appearance/authored/' + item + '.docx'
    for item in ['floating-both', 'floating-control', 'floating-horizontal',
                 'floating-margin-quarter', 'floating-negative-quarter',
                 'floating-outline-shadow', 'floating-quarter', 'floating-vertical']
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def inputs():
    files = {REPO / p for p in ['.fvmrc', 'pubspec.yaml', 'pubspec.lock',
             'analysis_options.yaml', '.dart_tool/package_config.json',
             'tool/perf/keystroke_trace_report.py']}
    for package in (REPO / 'packages').iterdir():
        if not package.is_dir():
            continue
        files.add(package / 'pubspec.yaml')
        files.update((package / 'lib').rglob('*.dart'))
    files.update((ENGINE / 'test').rglob('*.dart'))
    files.update((ENGINE / 'tool/macros').rglob('*.dart'))
    files.update((ENGINE / 'example/macros').rglob('*.bas'))
    files.update(EDITOR / name for name in EDITOR_ANALYSIS)
    for directory in ['packages/quds_office_editor/fonts',
                      'packages/quds_office_editor/example/fonts',
                      'packages/quds_office_editor/test/fixtures',
                      'packages/quds_office_engine/test/fixtures',
                      'packages/legacy_doc_parser/test/fixtures']:
        files.update(path for path in (REPO / directory).rglob('*') if path.is_file())
    return {str(path.resolve().relative_to(REPO)): sha(path)
            for path in sorted(files) if path.is_file()}

def tests(path, allow_skips=False):
    events = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    names = {event['test']['id']: event['test']['name'] for event in events
             if event.get('type') == 'testStart'}
    cases = [event for event in events if event.get('type') == 'testDone' and not event.get('hidden')]
    skipped = [names.get(event['testID'], '<unknown>') for event in cases if event.get('skipped')]
    failed = [names.get(event['testID'], '<unknown>') for event in cases
              if event.get('result') != 'success' and not event.get('skipped')]
    completed = any(event.get('type') == 'done' and event.get('success') is True for event in events)
    allowed = all(name in EXPECTED_SKIPS for name in skipped) if allow_skips else not skipped
    return {'passed': sum(event.get('result') == 'success' and not event.get('skipped') for event in cases),
            'failed': len(failed), 'skipped': len(skipped), 'skipped_names': skipped,
            'failed_names': failed, 'terminal_success': completed,
            'valid': completed and not failed and allowed and bool(cases)}

def run(name, command, cwd, test_log=None, allow_skips=False):
    record = {'name': name, 'command': command, 'cwd': str(cwd),
              'started_utc': datetime.now(timezone.utc).isoformat(), 'status': 'RUNNING'}
    dest = OUT / (name + '.receipt.json')
    write(dest, record)
    started = time.monotonic()
    stdout = OUT / (name + '.stdout.log')
    stderr = OUT / (name + '.stderr.log')
    with stdout.open('w') as out, stderr.open('w') as err:
        result = subprocess.run(command, cwd=cwd, stdout=out, stderr=err, timeout=1800)
    record.update(exit_code=result.returncode, elapsed_seconds=round(time.monotonic()-started, 3),
                  finished_utc=datetime.now(timezone.utc).isoformat(),
                  stdout_sha256=sha(stdout), stderr_sha256=sha(stderr),
                  status='PASS' if result.returncode == 0 else 'FAIL')
    if test_log is not None:
        summary = tests(test_log, allow_skips)
        record['tests'] = summary
        if not summary['valid']:
            record['status'] = 'FAIL'
    write(dest, record)
    print(json.dumps(record), flush=True)
    return record

before = inputs()
write(OUT / 'source-before.json', before)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
runtime = {str(p): sha(p) for p in [RUNTIME / 'runtime.json',
           RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart',
           RUNTIME / 'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester', TEST_RUNNER]}
write(OUT / 'runtime.json', runtime)
engine_log = OUT / 'sections-tests.jsonl'
editor_log = OUT / 'layout-tests.jsonl'
commands = [
    ('sections-analysis', ['dart', 'analyze', '--fatal-infos', 'lib/src/automation', 'tool/macros', *NATIVE_TESTS], ENGINE, None, False),
    ('sections-tests', ['dart', '--disable-dart-dev', '--packages=' + str(REPO / '.dart_tool/package_config.json'),
                       str(TEST_RUNNER), '--compiler=kernel', '--concurrency=2', '--reporter', 'expanded',
                       '--file-reporter', 'json:' + str(engine_log), *NATIVE_TESTS], ENGINE, engine_log, False),
    ('layout-analysis', ['dart', 'analyze', '--fatal-infos', *EDITOR_ANALYSIS], EDITOR, None, False),
    ('layout-tests', ['flutter', 'test', '--no-pub', '--concurrency=2', '--reporter', 'expanded',
                     '--file-reporter', 'json:' + str(editor_log),
                     'test/word_incremental_layout_equivalence_test.dart'], EDITOR, editor_log, True),
    ('trace-report', ['python3', str(BASE / 'mail-validation/check_union_trace.py')], REPO, None, False),
]
print('Starting source-bound Word union qualification', flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:
    checks = list(pool.map(lambda args: run(*args), commands))
portable = {}
for label, example, define_name, harness in [
    ('sections', 'word_sections.bas', 'WORD_SECTIONS_BAS_BASE64', 'web_vba_word_sections_smoke.dart'),
    ('page-setup', 'word_page_setup.bas', 'WORD_PAGE_SETUP_BAS_BASE64', 'web_vba_word_page_setup_smoke.dart'),
]:
    source = (ENGINE / 'example/macros' / example).read_bytes()
    define = '-D' + define_name + '=' + base64.b64encode(source).decode()
    smoke = 'tool/macros/' + harness
    compiled = OUT / (label + '.js')
    checks.append(run(label + '-vm', ['dart', define, smoke], ENGINE))
    compilation = run(label + '-compile-js', ['dart', 'compile', 'js', '-O1', define, smoke, '-o', str(compiled)], ENGINE)
    checks.append(compilation)
    if compilation['status'] != 'PASS':
        continue
    checks.append(run(label + '-js', [shutil.which('node'), '-e',
                      'globalThis.self=globalThis; require(process.argv[1]);', str(compiled)], ENGINE))
    vm = (OUT / (label + '-vm.stdout.log')).read_bytes()
    js = (OUT / (label + '-js.stdout.log')).read_bytes()
    portable[label] = {'example_sha256': hashlib.sha256(source).hexdigest(),
                       'vm_js_byte_identical': vm == js,
                       'output_sha256': hashlib.sha256(vm).hexdigest(),
                       'result': json.loads(vm)}
after = inputs()
write(OUT / 'source-after.json', after)
changed = [name for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)]
report = {'source_head': head, 'source_input_count': len(before), 'changed_inputs': changed,
          'checks': checks, 'portable': portable, 'github_actions': 'Not queried or awaited.',
          'limitations': ['No target-device profile measurement; trace parsing uses synthetic fixtures.',
                          'Eight image-only DOCX equivalence cases have no paragraphs to edit and remain expected skips.',
                          'Macro interoperability with installed Microsoft Word is not exercised.'],
          'accepted': all(item['status'] == 'PASS' for item in checks) and not changed
                      and len(portable) == 2 and all(item['vm_js_byte_identical'] for item in portable.values())}
write(OUT / 'receipt.json', report)
print(json.dumps({'accepted': report['accepted'], 'changed_inputs': changed, 'portable': portable}, indent=2), flush=True)
raise SystemExit(0 if report['accepted'] else 1)
