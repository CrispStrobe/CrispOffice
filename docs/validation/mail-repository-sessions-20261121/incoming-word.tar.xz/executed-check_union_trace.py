from contextlib import redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import py_compile

REPO = Path('/workspace/scratch/1a7ed08f64fe/mail-union-20261121')
OUT = REPO.parent / 'mail-validation/union-word'
OUT.mkdir(parents=True, exist_ok=True)
SOURCE = REPO / 'tool/perf/keystroke_trace_report.py'
py_compile.compile(str(SOURCE), cfile=str(OUT / 'keystroke_trace_report.pyc'), doraise=True)
spec = importlib.util.spec_from_file_location('trace_report', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def event(name, phase, stamp, thread=1, duration=None):
    value = {'name': name, 'cat': 'GC', 'ph': phase, 'ts': stamp, 'tid': thread}
    if duration is not None:
        value['dur'] = duration
    return value

cases = [
    ('complete_gc_excludes_idle', 1000, 11000, [
        event('Scavenge', 'X', 2000, duration=2000),
        event('NotifyIdle', 'X', 1000, duration=9000),
    ], 'GC events 1, total 2.0 ms; GC inside handlers 2.0 ms', '9.0 ms'),
    ('matched_pairs_and_unmatched_events', 1000, 11000, [
        event('MarkSweep', 'B', 0), event('MarkSweep', 'E', 4000),
        event('MarkCompact', 'E', 4500), event('Scavenge', 'B', 5000),
        event('Unrelated', 'X', 6000, duration=1000),
    ], 'GC events 1, total 4.0 ms; GC inside handlers 3.0 ms', '0.0 ms'),
    ('nested_same_name_pairs', 0, 10000, [
        event('MarkSweep', 'B', 1000), event('MarkSweep', 'B', 2000),
        event('MarkSweep', 'E', 4000), event('MarkSweep', 'E', 6000),
    ], 'GC events 2, total 7.0 ms; GC inside handlers 7.0 ms', '0.0 ms'),
    ('independent_threads_and_names', 0, 10000, [
        event('MarkSweep', 'B', 0), event('MarkSweep', 'B', 1000, thread=2),
        event('Scavenge', 'B', 2000), event('MarkSweep', 'E', 3000),
        event('Scavenge', 'E', 4000), event('MarkSweep', 'E', 6000, thread=2),
    ], 'GC events 3, total 10.0 ms; GC inside handlers 10.0 ms', '0.0 ms'),
    ('paired_idle_excluded', 0, 10000, [
        event('NotifyIdle', 'B', 0), event('Scavenge', 'X', 2000, duration=1000),
        event('NotifyIdle', 'E', 10000),
    ], 'GC events 1, total 1.0 ms; GC inside handlers 1.0 ms', '10.0 ms'),
]
receipts = []
for name, start, end, events, expected_gc, expected_idle in cases:
    fixture = {'keys': [{'handlerMs': (end-start)/1000, 'phases': {'layout': 1.0}}],
               'timeline': {'traceEvents': [
                   {'name': 'KEY_HANDLER', 'ph': 'b', 'id': 1, 'ts': start, 'args': {'key': 0}},
                   *events,
                   {'name': 'KEY_HANDLER', 'ph': 'e', 'id': 1, 'ts': end},
               ]}}
    path = OUT / (name + '.fixture.json')
    path.write_text(json.dumps(fixture, indent=2) + '\n')
    output = io.StringIO()
    with redirect_stdout(output):
        module.main(path)
    result = output.getvalue()
    (OUT / (name + '.stdout.log')).write_text(result)
    assert expected_gc in result, (name, result)
    assert 'idle-time GC (NotifyIdle, between frames) ' + expected_idle in result, (name, result)
    receipts.append({'name': name, 'passed': True})
print(json.dumps({'syntax': 'passed', 'fixtures': receipts}, indent=2))
