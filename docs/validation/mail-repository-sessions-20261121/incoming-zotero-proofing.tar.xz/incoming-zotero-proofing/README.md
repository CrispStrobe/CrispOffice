# Incoming Zotero and proofing qualification

The pinned incoming work passes **649 focused tests** and **five targeted
analysis groups** in the isolated Mail union. Every selected gate ran against
the same four Dart source-tree fingerprints; exact commands, target/test hashes,
runtime identities and log digests are in `summary.json` and each gate receipt.
This record adds local qualification to the earlier Zotero branch work record.

| Gate | Passed tests | Final receipt |
| --- | ---: | --- |
| Zotero engine transfer, protocol, citing, Add Note and document data | 237 | `zotero-engine-2.json` |
| Zotero editor transfer, citing dialogs/controllers and Add Note | 182 | `zotero-editor-1.json` |
| Proofing scheduling, sessions, incremental/cache/priority/manual/draft/platform | 139 | `proofing-editor-1.json` |
| Studio settings persistence and live application | 21 | `proofing-settings-1.json` |
| Engine proofing, result merging and German spelling | 59 | `proofing-engine-2.json` |
| Hunspell adapter | 11 | `hunspell-provider-2.json` |

All five final `analysis-*-2.json` receipts have exit code zero under
`dart analyze --fatal-infos`. The first transfer analyzer found 21 missing-brace
lint infos. The only production correction adds those braces in
`word_zotero_transfer.dart`; the formatter then reported no further changes.
Earlier receipts, including the initial lint failure, are retained. Final counts
above count each selected test cohort once.

## Reproduction and evidence

Source the same pinned runtime's `env.sh`. Run `run_gates.py` with any gate labels
listed in the receipts. Pure Dart groups invoke the locked `test` 1.31.1 kernel/VM
runner directly; this is the supported fallback for the ordinary `dart test`
launcher stall previously recorded during Store qualification. Flutter groups
use `flutter test --no-pub`, concurrency two, and a dedicated JSON file reporter.
Receipts preserve the literal commands. Raw stdout, stderr and JSON events are
stored as lossless gzip files with compressed and uncompressed SHA256 digests.
The initial failing analyzer is evidence, not an accepted gate.

## Boundaries

The tests exercise protocol/model behavior, staged edits, widget interaction,
scheduling and preference persistence. They do not qualify installed
Word/LibreOffice/Zotero interoperability, native ODT reference-mark import,
native dictionary installation or spelling-model quality. Hunspell and platform
adapter tests use their controlled transports. These runs make no measured
comparative typing-performance claim. Mail, sections and performance validation
are recorded separately. No GitHub Actions queue was queried or awaited.
