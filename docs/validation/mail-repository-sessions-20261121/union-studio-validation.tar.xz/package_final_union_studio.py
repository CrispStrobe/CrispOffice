from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys
import tarfile

BASE = Path('/workspace/scratch/1a7ed08f64fe')
REPO = BASE / 'quds_office_suite'
VALIDATION = BASE / 'mail-validation'
OUT = VALIDATION / 'final-union-studio'
DEST = REPO / 'docs/validation/mail-repository-sessions-20261121'
sys.path.insert(0, str(REPO / 'tools/mail'))
from check_store import test_summary


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


report = json.loads((OUT / 'receipt.json').read_text())
assert report['accepted'], 'Do not publish an unaccepted union run as passing.'
counts = test_summary(OUT / 'tests.jsonl')
assert counts['valid'], counts

# Preserve both the diagnostic attempt and its narrow proof alongside the
# source-bound accepted run. Prior Mail-slice evidence remains unchanged.
proof = VALIDATION / 'union-delete-fixture-proof'
proof_counts = test_summary(proof / 'tests.jsonl')
assert proof_counts['valid'], proof_counts
proof_report = {
    'scope': 'Three provider variants of delete after repository metadata update',
    'command': [
        'flutter', 'test', '--no-pub', '--concurrency=2', '--reporter',
        'expanded', '--file-reporter', 'json:' + str(proof / 'tests.jsonl'),
        '--plain-name',
        'delete survives metadata updates and cannot resurrect cached rows',
        'test/studio_mail_cached_host_test.dart',
    ],
    'cwd': str(REPO / 'packages/quds_office_editor/example'),
    'tests': {key: value for key, value in proof_counts.items() if key != 'cases'},
}
(proof / 'receipt.json').write_text(json.dumps(proof_report, indent=2) + '\n')

archive = DEST / 'union-studio-validation.tar.xz'
with tarfile.open(archive, 'w:xz') as tar:
    for name in (
        'final-union-studio', 'final-union-studio-initial',
        'union-delete-fixture-proof', 'run_final_union_studio.py',
        'package_final_union_studio.py',
    ):
        tar.add(VALIDATION / name, arcname=name)
    for name in ('runtime.json', 'env.sh'):
        tar.add(BASE / 'mail-runtime' / name, arcname='runtime/' + name)

suites = {}
for line in (OUT / 'tests.jsonl').read_text().splitlines():
    event = json.loads(line)
    if event['type'] == 'suite':
        suites[event['suite']['id']] = event['suite']['path']

by_suite = defaultdict(lambda: {'passed': 0, 'skipped': 0, 'failed': 0})
for case in counts['cases']:
    # The parser excludes loader events before returning executable test cases.
    suite = suites[case['suite_id']]
    key = str(Path(suite).relative_to(REPO / 'packages/quds_office_editor/example'))
    outcome = 'skipped' if case['skipped'] else (
        'passed' if case['result'] == 'success' else 'failed'
    )
    by_suite[key][outcome] += 1

delta = report.pop('mail_slice_to_union_delta')
report['by_suite'] = dict(by_suite)
report['mail_slice_to_union_comparison'] = {
    'prior_receipt': 'studio-validation.json',
    'prior_receipt_sha256': sha(DEST / 'studio-validation.json'),
    'manifest_delta_entries': len(delta),
    'changed_paths': list(delta),
    'explanation': (
        'Incoming shared Office, settings, proofing and Zotero source changes '
        'are included. The composer test is newly measured by this cohort, '
        'not newly created. Mail production code is unchanged from the '
        'accepted 285-case slice; the cached-host fixture has the isolated '
        'native draft-commit scheduling correction described below.'
    ),
    'full_hash_delta': 'final-union-studio/mail-slice-to-union.json in archive',
}
report['source_manifest_sha256'] = sha(OUT / 'source-after.json')
report['runtime_manifest_sha256'] = sha(OUT / 'runtime-after.json')
runtime = json.loads((BASE / 'mail-runtime/runtime.json').read_text())
report['toolchain'] = {
    'flutter': runtime['runtime']['flutterVersion'],
    'dart': runtime['runtime']['dartSdkVersion'],
    'activation': 'source ' + runtime['environment_script'],
}
report['fixture_correction'] = {
    'initial_union_result': '308 passed, 1 failed, 0 skipped; analyzer passed',
    'failed_case': 'graph delete survives metadata updates and cannot resurrect cached rows',
    'cause': (
        'The fixture fixed 1000-turn zero-delay helper exhausted before the '
        'unrelated native draft commit completed. Delete, subscription '
        'cancellation, reader removal and row-membership assertions had passed.'
    ),
    'correction': (
        'Only the unrelated owner.save draft commit now runs in tester.runAsync. '
        'Existing stream pumps and every assertion are preserved. All three '
        'provider variants passed before the complete union rerun.'
    ),
    'diagnostic_archive_directory': 'final-union-studio-initial',
}
report['logs_archive'] = {
    'file': archive.name,
    'bytes': archive.stat().st_size,
    'sha256': sha(archive),
}
destination = DEST / 'union-studio-validation.json'
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({
    'receipt': str(destination),
    'archive': report['logs_archive'],
    'by_suite': dict(by_suite),
}, indent=2))
