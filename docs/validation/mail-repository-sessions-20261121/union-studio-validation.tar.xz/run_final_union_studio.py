from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib, json, os, subprocess, sys, time
from pathlib import Path

BASE = Path('/workspace/scratch/1a7ed08f64fe')
REPO = BASE / 'quds_office_suite'
WORK = REPO / 'packages/quds_office_editor/example'
OUT = BASE / 'mail-validation/final-union-studio'
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(REPO / 'tools/mail'))
from check_store import test_summary

TESTS = [
    'test/studio_mail_cached_host_test.dart',
    'test/studio_mail_capture_projection_test.dart',
    'test/studio_mail_mailbox_store_test.dart',
    'test/studio_mail_cached_mail_test.dart',
    'test/studio_mail_mailbox_session_test.dart',
    'test/studio_mail_journal_host_test.dart',
    'test/studio_mail_flag_reconciliation_test.dart',
    'test/studio_mail_workspace_test.dart',
    'test/studio_mail_lifecycle_test.dart',
    'test/studio_mail_session_test.dart',
    'test/studio_mail_compose_test.dart',
]
LIBRARIES = [
    'lib/studio_mail_mailbox_session.dart',
    'lib/studio_mail_mailbox_store.dart',
    'lib/studio_mail_cached_mail.dart',
    'lib/studio_mail_cached_strings.dart',
    'lib/studio_mail_native.dart',
    'lib/studio_mail_ews.dart',
]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inputs():
    paths = {REPO / p for p in [
        '.fvmrc','pubspec.yaml','pubspec.lock','analysis_options.yaml',
        '.dart_tool/package_config.json','.dart_tool/package_graph.json',
        '.dart_tool/native_assets.yaml','tools/mail/check_store.py',
    ]}
    for package in (REPO/'packages').iterdir():
        if not package.is_dir(): continue
        paths.add(package/'pubspec.yaml')
        paths.update((package/'lib').rglob('*.dart'))
    paths.add(WORK/'pubspec.yaml')
    paths.update((WORK/'lib').rglob('*.dart'))
    paths.update((REPO/'third_party/enough_mail/lib').rglob('*.dart'))
    paths.update((WORK/'test/support').rglob('*.dart'))
    paths.update(WORK/p for p in TESTS)
    for directory in [REPO/'packages/quds_office_editor/fonts',WORK/'fonts']:
        paths.update(p for p in directory.rglob('*') if p.is_file())
    return {str(p.relative_to(REPO)):sha(p) for p in sorted(paths) if p.is_file()}

def runtime_inputs():
    runtime = BASE/'mail-runtime'
    paths = [
        runtime/'flutter/bin/cache/dart-sdk/bin/dart',
        runtime/'flutter/bin/cache/flutter_tools.snapshot',
        runtime/'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',
        runtime/'runtime.json', REPO/'.dart_tool/lib/libsqlite3.so',
    ]
    return {str(p):sha(p) for p in paths}

def git_head():
    return subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()

def run(name, command):
    record={'name':name,'command':command,'cwd':str(WORK),
            'started_at_utc':datetime.now(timezone.utc).isoformat(),'status':'RUNNING'}
    dest=OUT/(name+'-receipt.json')
    dest.write_text(json.dumps(record,indent=2)+'\n')
    start=time.monotonic()
    stdout=OUT/(name+'.stdout.log')
    stderr=OUT/(name+'.stderr.log')
    with stdout.open('w') as out, stderr.open('w') as err:
        result=subprocess.run(command,cwd=WORK,stdout=out,stderr=err,timeout=1800)
    record.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,
                  finished_at_utc=datetime.now(timezone.utc).isoformat(),
                  stdout_sha256=sha(stdout),stderr_sha256=sha(stderr),
                  status='PASS' if result.returncode==0 else 'FAIL')
    if name=='tests':
        counts=test_summary(OUT/'tests.jsonl')
        (OUT/'test-cases.json').write_text(json.dumps(counts,indent=2)+'\n')
        record['tests']={k:v for k,v in counts.items() if k!='cases'}
        if not counts['valid']: record['status']='FAIL'
    dest.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    return record

if __name__=='__main__':
    for path in TESTS+LIBRARIES:
        if not (WORK/path).is_file(): raise FileNotFoundError(path)
    before=inputs(); runtime_before=runtime_inputs(); head_before=git_head()
    slice_manifest=json.loads((BASE/'mail-validation/final-studio/source-after.json').read_text())
    slice_delta={path:{'mail_slice_sha256':slice_manifest.get(path),'union_sha256':before.get(path)} for path in sorted(slice_manifest.keys()|before.keys()) if slice_manifest.get(path)!=before.get(path)}
    (OUT/'mail-slice-to-union.json').write_text(json.dumps(slice_delta,indent=2)+'\n')
    (OUT/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
    (OUT/'runtime-before.json').write_text(json.dumps(runtime_before,indent=2)+'\n')
    command_tests=['flutter','test','--no-pub','--concurrency=2','--reporter','expanded',
                   '--file-reporter','json:'+str(OUT/'tests.jsonl'),*TESTS]
    command_analysis=['dart','analyze','--fatal-infos',*LIBRARIES,*TESTS]
    print('Starting final integrated Studio/composer cohort: '+str(len(TESTS))+' suites',flush=True)
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(run,'tests',command_tests),pool.submit(run,'analysis',command_analysis)]
        results=[future.result() for future in futures]
    after=inputs(); runtime_after=runtime_inputs(); head_after=git_head()
    (OUT/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
    (OUT/'runtime-after.json').write_text(json.dumps(runtime_after,indent=2)+'\n')
    changed=[p for p in sorted(before.keys()|after.keys()) if before.get(p)!=after.get(p)]
    runtime_changed=[p for p in sorted(runtime_before.keys()|runtime_after.keys()) if runtime_before.get(p)!=runtime_after.get(p)]
    report={'source_head_before':head_before,'source_head_after':head_after,
            'test_inventory':TESTS,'checks':results,'source_input_count':len(before),
            'changed_inputs':changed,'changed_runtime_inputs':runtime_changed,
            'mail_slice_to_union_delta':slice_delta,
            'github_actions':'Not queried or awaited.',
            'scope':'Final integrated-source Linux Flutter execution of ten Mail suites plus Word-based composer; controlled provider/storage fixtures and native SQLite. Incoming Office/Zotero/proofing are qualified separately. No live-provider or installed-platform acceptance claim.',
            'accepted':all(r['status']=='PASS' for r in results) and not changed and not runtime_changed}
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)
    raise SystemExit(0 if report['accepted'] else 1)
