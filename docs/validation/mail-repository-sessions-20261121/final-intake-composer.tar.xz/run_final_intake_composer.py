from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
from urllib.parse import unquote, urljoin, urlparse

BASE = Path('/workspace/scratch/1a7ed08f64fe')
REPO = BASE / 'mail-final-intake-20261121'
WORK = REPO / 'packages/quds_office_editor/example'
OUT = BASE / 'mail-validation/final-intake-composer'
PRIOR = BASE / 'mail-validation/final-union-studio'
TEST = 'test/studio_mail_compose_test.dart'
PREVIOUS_TESTS = json.loads((PRIOR / 'receipt.json').read_text())['test_inventory']
sys.path.insert(0, str(REPO / 'tools/mail'))
from check_store import test_summary


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs():
    paths = {REPO / p for p in (
        '.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
        '.dart_tool/package_config.json', '.dart_tool/package_graph.json',
        '.dart_tool/native_assets.yaml', 'tools/mail/check_store.py',
    )}
    for package in (REPO / 'packages').iterdir():
        if not package.is_dir():
            continue
        paths.add(package / 'pubspec.yaml')
        paths.update((package / 'lib').rglob('*.dart'))
    paths.add(WORK / 'pubspec.yaml')
    paths.update((WORK / 'lib').rglob('*.dart'))
    paths.update((REPO / 'third_party/enough_mail/lib').rglob('*.dart'))
    paths.update((WORK / 'test/support').rglob('*.dart'))
    paths.update(WORK / path for path in PREVIOUS_TESTS)
    for directory in (REPO / 'packages/quds_office_editor/fonts', WORK / 'fonts'):
        paths.update(p for p in directory.rglob('*') if p.is_file())
    return {
        str(path.relative_to(REPO)): sha(path)
        for path in sorted(paths) if path.is_file()
    }


def mail_or_shared_fixture(path):
    return (
        path.startswith('packages/quds_mail_')
        or path.startswith('third_party/enough_mail/')
        or path.startswith('packages/quds_office_editor/example/lib/')
        or path.startswith('packages/quds_office_editor/example/test/studio_mail_')
        or path.startswith('packages/quds_office_editor/example/test/support/')
        or '/fonts/' in path
        or path == 'tools/mail/check_store.py'
    )


def dependency_config():
    path = REPO / '.dart_tool/package_config.json'
    current = json.loads(path.read_text())
    prior_path = BASE / 'quds_office_suite/.dart_tool/package_config.json'
    prior = json.loads(prior_path.read_text())
    assert current == prior, 'Package resolution differs from accepted union.'
    roots = {}
    for package in current['packages']:
        if package['name'].startswith('quds_') or package['name'] == 'enough_mail':
            uri = urljoin(path.as_uri(), package['rootUri'])
            resolved = Path(unquote(urlparse(uri).path)).resolve()
            assert resolved.is_relative_to(REPO), (package['name'], resolved)
            roots[package['name']] = str(resolved)
    return {
        'identical_package_config': True,
        'local_package_roots': roots,
        'local_packages_resolve_to_tested_worktree': True,
    }


def runtime_inputs():
    runtime = BASE / 'mail-runtime'
    native_map_path = REPO / '.dart_tool/native_assets.yaml'
    native_text = native_map_path.read_text()
    native_map = json.loads(native_text[native_text.index('{'):])
    mapping = native_map['native-assets']['linux_x64'][
        'package:sqlite3/src/ffi/libsqlite3.g.dart'
    ]
    assert mapping[0] == 'absolute', mapping
    sqlite = Path(mapping[1])
    values = {
        'dart': runtime / 'flutter/bin/cache/dart-sdk/bin/dart',
        'flutter_tools': runtime / 'flutter/bin/cache/flutter_tools.snapshot',
        'flutter_tester': runtime / 'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',
        'runtime_receipt': runtime / 'runtime.json',
        'sqlite3': sqlite,
    }
    return {name: {'path': str(path), 'sha256': sha(path)} for name, path in values.items()}


def run(name, command):
    record = {
        'name': name, 'command': command, 'cwd': str(WORK),
        'started_at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'RUNNING',
    }
    destination = OUT / (name + '-receipt.json')
    destination.write_text(json.dumps(record, indent=2) + '\n')
    started = time.monotonic()
    stdout = OUT / (name + '.stdout.log')
    stderr = OUT / (name + '.stderr.log')
    with stdout.open('w') as out, stderr.open('w') as err:
        result = subprocess.run(command, cwd=WORK, stdout=out, stderr=err, timeout=600)
    record.update(
        exit_code=result.returncode,
        elapsed_seconds=time.monotonic() - started,
        finished_at_utc=datetime.now(timezone.utc).isoformat(),
        stdout_sha256=sha(stdout), stderr_sha256=sha(stderr),
        status='PASS' if result.returncode == 0 else 'FAIL',
    )
    if name == 'tests':
        counts = test_summary(OUT / 'tests.jsonl')
        (OUT / 'test-cases.json').write_text(json.dumps(counts, indent=2) + '\n')
        record['tests'] = {key: value for key, value in counts.items() if key != 'cases'}
        if not counts['valid'] or counts['passed'] != 24:
            record['status'] = 'FAIL'
    destination.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    return record


if __name__ == '__main__':
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT / 'receipt.json').exists(), 'Preserve prior attempts before rerunning.'
    before = inputs()
    prior = json.loads((PRIOR / 'source-after.json').read_text())
    delta = {
        path: {'accepted_union_sha256': prior.get(path), 'final_intake_sha256': before.get(path)}
        for path in sorted(prior.keys() | before.keys())
        if prior.get(path) != before.get(path)
    }
    mail_inputs = sorted(path for path in prior.keys() | before.keys() if mail_or_shared_fixture(path))
    changed_mail = [path for path in mail_inputs if path in delta]
    assert not changed_mail, ('Mail acceptance inputs changed', changed_mail)
    dependency_inputs = [
        path for path in prior.keys() | before.keys()
        if path.endswith('/pubspec.yaml') or path in (
            '.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'
        )
    ]
    assert not [path for path in dependency_inputs if path in delta], 'Pinned dependency inputs changed.'
    dependency_check = dependency_config()
    runtime_before = runtime_inputs()
    prior_runtime = json.loads((PRIOR / 'runtime-after.json').read_text())
    prior_by_hash = set(prior_runtime.values())
    assert all(item['sha256'] in prior_by_hash for item in runtime_before.values()), 'Runtime changed.'
    head_before = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    for name, value in (
        ('source-before.json', before), ('runtime-before.json', runtime_before),
        ('accepted-union-to-final-intake.json', delta),
        ('dependency-binding.json', dependency_check),
    ):
        (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
    tests = [
        'flutter', 'test', '--no-pub', '--concurrency=2', '--reporter', 'expanded',
        '--file-reporter', 'json:' + str(OUT / 'tests.jsonl'), TEST,
    ]
    analysis = ['dart', 'analyze', '--fatal-infos', 'lib/studio_mail_compose.dart', TEST]
    # Compile in isolation after the initial compiler process exited while
    # other incoming-source gates were compiling. Reuse only clean analysis
    # of the exact same source inputs, otherwise analyze after the test run.
    checks = [run('tests', tests)]
    initial = OUT.parent / 'final-intake-composer-initial'
    prior_analysis_path = initial / 'analysis-receipt.json'
    if (
        prior_analysis_path.exists()
        and json.loads((initial / 'source-before.json').read_text()) == before
        and json.loads((initial / 'source-after.json').read_text()) == before
    ):
        prior_analysis = json.loads(prior_analysis_path.read_text())
        assert prior_analysis['status'] == 'PASS'
        assert prior_analysis['command'] == analysis
        prior_analysis['reused_from_identical_source_run'] = str(prior_analysis_path)
        checks.append(prior_analysis)
        (OUT / 'analysis-receipt.json').write_text(json.dumps(prior_analysis, indent=2) + '\n')
    else:
        checks.append(run('analysis', analysis))
    after = inputs()
    runtime_after = runtime_inputs()
    head_after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    for name, value in (('source-after.json', after), ('runtime-after.json', runtime_after)):
        (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
    changed = [path for path in sorted(before.keys() | after.keys()) if before.get(path) != after.get(path)]
    runtime_changed = [name for name in runtime_before if runtime_before[name] != runtime_after.get(name)]
    report = {
        'scope': 'Final intake delta qualification of unchanged Mail inputs and shared Word-based composer.',
        'source_head_before': head_before, 'source_head_after': head_after,
        'tested_worktree': str(REPO), 'source_input_count': len(before),
        'mail_and_shared_fixture_input_count': len(mail_inputs),
        'changed_mail_inputs_from_accepted_union': changed_mail,
        'accepted_union_to_final_intake_delta': delta,
        'changed_inputs_during_run': changed,
        'changed_runtime_inputs_during_run': runtime_changed,
        'runtime_identical_to_accepted_union': True,
        'dependency_binding': dependency_check,
        'checks': checks,
        'review': {
            'composer': 'The only Mail WordEditorController uses an empty proofing-provider list and disables proofing. Its construction, editing, snapshot and disposal still share Word code; all 24 composer cases are rerun.',
            'zotero_odt': 'No Mail code invokes Zotero transfer or ODT document writing. Mail attachment handling recognizes ODT only as a MIME type.',
            'retained_acceptance': 'The accepted 309-case Mail/composer gate remains applicable to identical Mail and fixture inputs. Incoming Word/proofing/Zotero behavior is qualified by separate targeted gates.',
            'additional_mail_regressions': 'None: no changed Mail inputs or additional affected execution path found.',
        },
        'github_actions': 'Not queried or awaited.',
        'accepted': all(check['status'] == 'PASS' for check in checks) and not changed and not runtime_changed,
    }
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)
    raise SystemExit(0 if report['accepted'] else 1)
