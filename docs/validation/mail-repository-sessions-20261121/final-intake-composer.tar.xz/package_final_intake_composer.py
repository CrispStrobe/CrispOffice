import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

BASE = Path('/workspace/scratch/1a7ed08f64fe')
VALIDATION = BASE / 'mail-validation'
OUT = VALIDATION / 'final-intake-composer'
WORKTREE = BASE / 'mail-final-intake-20261121'
DEST = BASE / 'quds_office_suite/docs/validation/mail-repository-sessions-20261121'
REMOTE = '721ad2c74a5d81d54c2eaa2af084e82ba5077991'
PUBLICATION = 'dbe48121625a2f72ef4f6fb3fc8dc7a4cf7703a0'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORKTREE, text=True).strip()


raw = json.loads((OUT / 'receipt.json').read_text())
assert raw['accepted'], 'Only package accepted source-bound results.'
frozen = raw['source_head_after']
tree = git('rev-parse', frozen + '^{tree}')
assert git('rev-parse', REMOTE + '^{tree}') == tree
publication_delta = git('diff', '--name-only', frozen, PUBLICATION).splitlines()
assert all(path.startswith('docs/validation/') for path in publication_delta)
binding = {
    'frozen_worktree_commit': frozen,
    'remote_saved_commit': REMOTE,
    'identical_tree': tree,
    'publication_merge_commit': PUBLICATION,
    'publication_tree': git('rev-parse', PUBLICATION + '^{tree}'),
    'publication_changed_paths': publication_delta,
    'publication_changes_are_validation_docs_only': True,
    'production_test_tool_dependency_changes_at_publication': [],
}
(OUT / 'publication-source-binding.json').write_text(json.dumps(binding, indent=2) + '\n')

archive = DEST / 'final-intake-composer.tar.xz'
with tarfile.open(archive, 'w:xz') as tar:
    for name in (
        'final-intake-composer', 'final-intake-composer-initial',
        'run_final_intake_composer.py', 'package_final_intake_composer.py',
    ):
        tar.add(VALIDATION / name, arcname=name)
    for name in ('runtime.json', 'env.sh'):
        tar.add(BASE / 'mail-runtime' / name, arcname='runtime/' + name)

prior = DEST / 'union-studio-validation.json'
prior_receipt = json.loads(prior.read_text())
prior_tests = next(check['tests'] for check in prior_receipt['checks'] if check['name'] == 'tests')
assert prior_receipt['accepted'] and prior_tests['passed'] == 309
delta = raw['accepted_union_to_final_intake_delta']
report = {
    'accepted': True,
    'scope': raw['scope'],
    'source_binding': binding,
    'source_input_count': raw['source_input_count'],
    'unchanged_mail_and_shared_fixture_inputs': raw['mail_and_shared_fixture_input_count'],
    'changed_mail_inputs_from_accepted_union': raw['changed_mail_inputs_from_accepted_union'],
    'changed_inputs_during_run': raw['changed_inputs_during_run'],
    'changed_runtime_inputs_during_run': raw['changed_runtime_inputs_during_run'],
    'source_manifest_sha256': sha(OUT / 'source-after.json'),
    'runtime_manifest_sha256': sha(OUT / 'runtime-after.json'),
    'runtime_identical_to_accepted_union': raw['runtime_identical_to_accepted_union'],
    'prior_mail_acceptance': {
        'receipt': prior.name,
        'sha256': sha(prior),
        'passed': 309,
        'explanation': 'Previous full Mail acceptance is preserved; these 24 composer cases are a repeated integration check and are not additional unique tests.',
    },
    'source_delta': {path: values for path, values in delta.items() if not path.startswith('.dart_tool/')},
    'generated_config_delta': {
        path: values for path, values in delta.items() if path.startswith('.dart_tool/')
    },
    'generated_config_explanation': 'Only the native-assets absolute path changes to the final worktree; the SQLite binary hash is identical.',
    'dependency_binding': {
        'package_config_identical': raw['dependency_binding']['identical_package_config'],
        'local_package_count': len(raw['dependency_binding']['local_package_roots']),
        'all_local_packages_resolve_to_tested_worktree': True,
        'detail': 'final-intake-composer/dependency-binding.json in archive',
    },
    'checks': raw['checks'],
    'review': raw['review'],
    'initial_attempt': json.loads((VALIDATION / 'final-intake-composer-initial/diagnostic-receipt.json').read_text()),
    'rerun': 'After all other compiler jobs exited, the isolated 24-case composer run passed without source, fixture or assertion edits. Clean two-file analysis was reused only after exact before/after source-manifest equality and command checks.',
    'github_actions': raw['github_actions'],
    'logs_archive': {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive)},
}
destination = DEST / 'final-intake-composer.json'
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({
    'receipt': str(destination), 'archive': report['logs_archive'],
    'unchanged_mail_inputs': report['unchanged_mail_and_shared_fixture_inputs'],
    'source_delta': list(report['source_delta']), 'accepted': True,
}, indent=2))
