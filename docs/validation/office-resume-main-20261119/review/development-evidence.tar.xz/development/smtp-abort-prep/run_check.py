import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path('/workspace/scratch/261cd76b2166')
repo = base / 'quds_office_suite'
package = repo / 'third_party/enough_mail'
phase = sys.argv[1]
args = sys.argv[2:]
output = base / ('dev-smtp-abort-' + phase)
paths = [
    'lib/src/smtp/smtp_client.dart',
    'lib/src/private/util/client_base.dart',
    'lib/src/mail/mail_client.dart',
    'lib/src/private/mail/send_message_transaction.dart',
    'test/mail/mail_send_transaction_test.dart',
]
paths.extend(arg for arg in args if arg.endswith('.dart') and arg not in paths)
def hashes():
    return {path: hashlib.sha256((package / path).read_bytes()).hexdigest() for path in paths}
command = [
    str(base / 'quds-runtime/bin/dart'),
    '--disable-dart-dev',
    '--packages=' + str(repo / '.dart_tool/package_config.json'),
    str(base / 'quds-runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),
    '--reporter=json',
    *args,
]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
source_before = hashes()
start = time.monotonic()
with output.with_suffix('.jsonl').open('w') as out, output.with_suffix('.stderr').open('w') as err:
    result = subprocess.run(command, cwd=package, stdout=out, stderr=err, timeout=240)
events = []
for line in output.with_suffix('.jsonl').read_text().splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        pass
tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
done = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden', False)]
summary = {
    'phase': phase,
    'started_utc': started,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'duration_seconds': round(time.monotonic() - start, 3),
    'command': command,
    'cwd': str(package),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'exit_code': result.returncode,
    'source_sha256_before': source_before,
    'source_sha256_after': hashes(),
    'visible_passed': sum(e.get('result') == 'success' and not e.get('skipped') for e in done),
    'visible_failed': sum(e.get('result') in ['error', 'failure'] for e in done),
    'visible_skipped': sum(bool(e.get('skipped')) for e in done),
    'errors': [e for e in events if e.get('type') == 'error'],
    'completion': next((e for e in reversed(events) if e.get('type') == 'done'), None),
    'test_names': [tests.get(e['testID'], {}).get('name') for e in done],
}
output.with_suffix('.summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ['phase', 'exit_code', 'duration_seconds', 'visible_passed', 'visible_failed', 'visible_skipped', 'completion']}))
print(str(output.with_suffix('.summary.json')))
for error in summary['errors']:
    print(error.get('error'))
