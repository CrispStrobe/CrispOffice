import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

base = Path('/workspace/scratch/261cd76b2166')
repo = base / 'quds_office_suite'
work = base / 'nonmail-main-merge'
phase, runner, package = sys.argv[1:4]
args = sys.argv[4:]
cwd = repo / package
paths = json.loads((work / 'owned-paths.json').read_text())
for arg in args:
    if arg.endswith('.dart'):
        path = str((cwd / arg).relative_to(repo))
        if path not in paths:
            paths.append(path)
def runtime_hashes():
    return {str(path.relative_to(repo)): hashlib.sha256(path.read_bytes()).hexdigest() for path in [repo / '.dart_tool/package_config.json', repo / '.dart_tool/package_graph.json'] if path.exists()}
def hashes():
    return {path: hashlib.sha256((repo / path).read_bytes()).hexdigest() for path in paths}
if runner == 'dart':
    command = [str(base / 'quds-runtime/bin/dart'), '--disable-dart-dev', '--packages=' + str(repo / '.dart_tool/package_config.json'), str(base / 'quds-runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'), '--reporter=json', *args]
else:
    command = [str(base / 'quds-runtime/bin/flutter'), 'test', '--no-pub', '--reporter=json', *args]
output = work / phase
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
source_before = hashes()
runtime_before = runtime_hashes()
start = time.monotonic()
with output.with_suffix('.jsonl').open('w') as out, output.with_suffix('.stderr').open('w') as err:
    result = subprocess.run(command, cwd=cwd, stdout=out, stderr=err, timeout=600)
events=[]
for line in output.with_suffix('.jsonl').read_text().splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        pass
done=[e for e in events if e.get('type')=='testDone' and not e.get('hidden',False)]
summary={
    'phase':phase, 'started_utc':started, 'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'duration_seconds':round(time.monotonic()-start,3), 'command':command, 'cwd':str(cwd),
    'exit_code':result.returncode, 'source_sha256_before':source_before, 'source_sha256_after':hashes(),
    'runtime_sha256_before':runtime_before, 'runtime_sha256_after':runtime_hashes(),
    'visible_passed':sum(e.get('result')=='success' and not e.get('skipped') for e in done),
    'visible_failed':sum(e.get('result') in ['error','failure'] for e in done),
    'visible_skipped':sum(bool(e.get('skipped')) for e in done),
    'errors':[e for e in events if e.get('type')=='error'],
    'completion':next((e for e in reversed(events) if e.get('type')=='done'),None),
}
output.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({key:summary[key] for key in ['phase','exit_code','duration_seconds','visible_passed','visible_failed','visible_skipped','completion']}))
for error in summary['errors']:
    print(error.get('error'))
