#!/usr/bin/env python3
"""Read-only verification of saved receipts, reporter events, Git blobs and XML.

This script does not execute Dart, Flutter, LibreOffice or product tests.
"""
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
from xml.etree import ElementTree as ET
from zipfile import ZipFile

BASE = Path('/workspace/scratch/1bb837b7ac66/validation_work')
REPO = Path('/workspace/scratch/1bb837b7ac66/quds_office_suite')
FINAL = '8e18fb2ee53e11d0b96a449ea7e698223423dca2'
QUALIFIED = '52f53c99059b1521dd08b9f8f4f65133e87e980b'
errors = []
trees = {}
blob_hashes = {}
git = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=REPO,
                       stdin=subprocess.PIPE, stdout=subprocess.PIPE)


def check(condition, detail):
    if not condition:
        errors.append(detail)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda: f.read(1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def read(path):
    path = Path(path)
    if path.suffix == '.gz':
        with gzip.open(path, 'rt') as f:
            return json.load(f)
    return json.loads(path.read_text())


def cmd(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()


def tree(commit):
    if commit not in trees:
        out = subprocess.check_output(['git', 'ls-tree', '-rz', commit], cwd=REPO)
        trees[commit] = {p.decode(): meta.split()[2].decode()
                         for entry in out.split(b'\0') if entry
                         for meta, p in [entry.split(b'\t', 1)]}
    return trees[commit]


def blob_sha(blob):
    if blob not in blob_hashes:
        git.stdin.write((blob + '\n').encode())
        git.stdin.flush()
        header = git.stdout.readline().split()
        size = int(header[2])
        value = hashlib.sha256()
        left = size
        while left:
            data = git.stdout.read(min(left, 1024 * 1024))
            value.update(data)
            left -= len(data)
        assert git.stdout.read(1) == b'\n'
        blob_hashes[blob] = value.hexdigest()
    return blob_hashes[blob]


def bind(snapshot, commit, prefix):
    tracked, external = 0, []
    commit_tree = tree(commit)
    for name, value in snapshot.items():
        if name in commit_tree:
            check(blob_sha(commit_tree[name]) == value, f'{prefix}: Git source mismatch {name}')
            tracked += 1
        else:
            path = Path(name) if name.startswith('/') else REPO / name
            check(path.is_file() and sha(path) == value, f'{prefix}: external input mismatch {name}')
            external.append(name)
    return {'gitBoundInputs': tracked, 'externalInputs': external}


def physical(snapshot, root, prefix):
    for name, value in snapshot.items():
        path = root / name
        check(path.is_file() and sha(path) == value, f'{prefix}: file hash mismatch {name}')


def artifacts(root, values, prefix):
    for name, recorded in values.items():
        path = root / name
        expected = recorded['sha256'] if isinstance(recorded, dict) else recorded
        check(path.is_file() and sha(path) == expected, f'{prefix}: artifact hash mismatch {name}')
        if isinstance(recorded, dict) and 'bytes' in recorded:
            check(path.stat().st_size == recorded['bytes'], f'{prefix}: artifact size mismatch {name}')


def gate(name):
    root = BASE / name
    r = read(root / 'receipt.json')
    artifacts(root, r['artifacts_sha256'], name)
    check(sha(r['runtime_receipt']) == r['runtime_receipt_sha256'], f'{name}: runtime receipt hash')
    check(cmd('rev-parse', r['source_commit'] + '^{tree}') == r['source_tree'], f'{name}: source tree')
    before, after = read(root / 'inputs-before.json.gz'), read(root / 'inputs-after.json.gz')
    check(before == after and r['inputs_unchanged'] and not r['changed_inputs'], f'{name}: input drift')
    check(len(before) == r['input_count'], f'{name}: input count')
    binding = bind(before, r['source_commit'], name)
    starts, ends, suites, error_events, done, nonjson = {}, {}, {}, [], [], []
    with gzip.open(root / 'events.jsonl.gz', 'rt') as f:
        for line in f:
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                if line.strip():
                    nonjson.append(line.rstrip('\r\n'))
                continue
            kind = event.get('type')
            if kind == 'suite':
                suites[event['suite']['id']] = event['suite']['path']
            elif kind == 'testStart':
                t = event['test']
                check(t['id'] not in starts, f'{name}: repeated testStart ID {t["id"]}')
                starts[t['id']] = t
            elif kind == 'testDone':
                check(event['testID'] not in ends, f'{name}: repeated testDone ID {event["testID"]}')
                ends[event['testID']] = event
            elif kind == 'error':
                error_events.append(event)
            elif kind == 'done':
                done.append(event)
    visible = []
    for ident, start in starts.items():
        end = ends.get(ident, {})
        if end.get('hidden') or start.get('name', '').startswith('loading '):
            continue
        visible.append({'suite': suites.get(start['suiteID']), 'name': start['name'],
                        'result': end.get('result', 'unfinished'), 'skipped': end.get('skipped', False)})
    check(set(ends) <= set(starts), f'{name}: end without start')
    check(visible == read(root / 'cases.json'), f'{name}: cases differ from reporter')
    check(error_events == read(root / 'errors.json'), f'{name}: errors differ from reporter')
    counts = {'passed': 0, 'failed': 0, 'skipped': 0, 'unfinished': 0}
    for c in visible:
        if c['skipped']:
            counts['skipped'] += 1
        elif c['result'] == 'success':
            counts['passed'] += 1
        elif c['result'] == 'unfinished':
            counts['unfinished'] += 1
        else:
            counts['failed'] += 1
    identities = {(c['suite'], c['name']) for c in visible}
    check(len(identities) == len(visible), f'{name}: duplicate case identity')
    check(counts == r['counts'], f'{name}: receipt counts differ')
    check(done == r['done_events'], f'{name}: done event mismatch')
    check(len(error_events) == r['error_event_count'], f'{name}: error count mismatch')
    check(nonjson == r['non_json_lines'], f'{name}: non-JSON output mismatch')
    if r['status'] == 'passed':
        check(r['exit_code'] == 0 and len(done) == 1 and done[0]['success'] is True,
              f'{name}: accepted without successful exit/done')
        check(counts['passed'] > 0 and not any(counts[k] for k in ['failed', 'skipped', 'unfinished'])
              and not error_events, f'{name}: accepted with failures')
    return {'source': r['source_commit'], 'package': r['package'], 'status': r['status'],
            'counts': counts, 'suites': dict(sorted(Counter(c['suite'] for c in visible).items())),
            'inputCount': len(before), **binding, 'nonJsonLines': nonjson,
            'cases': visible, 'tests': r['tests']}


report = {'auditKind': 'read-only evidence audit; no product reruns', 'finalSource': FINAL,
          'qualifiedSource': QUALIFIED, 'createdUtc': datetime.now(timezone.utc).isoformat()}
names = ['engine-gate/final', 'final-editor', 'final-studio', 'final-word',
         'final-word-supplement', 'final-mail-core', 'final-mail-transport']
gates = {name: gate(name) for name in names}
old, supplement = gates['final-word'], gates['final-word-supplement']
replaced = set(supplement['tests'])
kept = [c for c in old['cases'] if c['suite'] not in replaced]
prior_replaced = [c for c in old['cases'] if c['suite'] in replaced]
check({(c['suite'], c['name']) for c in prior_replaced} ==
      {(c['suite'], c['name']) for c in supplement['cases']}, 'Word replacement identity set differs')
word = kept + supplement['cases']
check(len(word) == 583 and all(c['result'] == 'success' and not c['skipped'] for c in word),
      'Word effective gate is not 583 unique passing cases')
all_cases = [(g['package'], c['suite'], c['name'])
             for name, g in gates.items() if name not in ['final-word', 'final-word-supplement']
             for c in g['cases']]
all_cases += [(old['package'], c['suite'], c['name']) for c in word]
check(len(all_cases) == len(set(all_cases)) == 1332, 'Final overall case identities/count')
report['unitGates'] = {name: {k: v for k, v in g.items() if k not in ['cases', 'tests']}
                       for name, g in gates.items()}
report['effectiveWord'] = {'passed': len(word), 'unaffectedPriorCases': len(kept),
                         'replacedPriorCases': len(prior_replaced), 'supplementCases': len(supplement['cases']),
                         'supersededFailures': [c for c in prior_replaced if c['result'] != 'success'],
                         'suites': dict(sorted(Counter(c['suite'] for c in word).items()))}
report['effectiveUniqueUnitCases'] = len(all_cases)
report['zoteroUniqueUnitCases'] = sum(len(gates[n]['cases']) for n in
                                    ['engine-gate/final', 'final-editor', 'final-studio'])

changed = cmd('diff', '--name-only', QUALIFIED, FINAL).splitlines()
check(len(changed) == 4 and all('/test/' in p for p in changed), 'Unexpected production change at final source')
for name, g in gates.items():
    if name == 'final-word':
        continue
    selected = {g['package'] + '/' + p for p in g['tests']}
    if g['source'] == QUALIFIED:
        check(not selected.intersection(changed), f'{name}: selected tests changed since qualification')
check(not {old['package'] + '/' + c['suite'] for c in kept}.intersection(changed),
      'Unaffected Word suites changed at final source')
report['finalSourceChanges'] = changed

runtime = read(BASE.parent / 'runtime/runtime.json')
artifacts(Path('/'), runtime['executables_sha256'], 'runtime binaries')
check(runtime['workspace_lock_initial_sha256'] == runtime['workspace_lock_sha256'] ==
      sha(REPO / 'pubspec.lock'), 'Runtime lockfile mismatch')
report['runtime'] = {'version': runtime['runtime']['frameworkVersion'],
                     'dart': runtime['runtime']['dartSdkVersion'],
                     'verifiedExecutables': len(runtime['executables_sha256'])}

base_r = read(BASE / 'baseline-receipt.json')
base_manifest = read(BASE / 'baseline-source-manifest.json')
artifacts(BASE, base_r['files'], 'baseline')
check(sha(BASE / base_r['script']['path']) == base_r['script']['sha256'], 'baseline script hash')
check(sha(BASE / 'baseline-package-config.json') == base_r['packageConfigSha256'], 'baseline package config hash')
check(base_manifest['commit'] == base_r['sourceCommit'] and
      cmd('rev-parse', base_r['sourceCommit'] + '^{tree}') == base_r['sourceTree'], 'baseline source identity')
baseline_binding = bind(base_manifest['files'], base_r['sourceCommit'], 'baseline source')
physical(base_manifest['files'], BASE / 'baseline-source', 'baseline frozen')
check(len(base_manifest['files']) == base_r['frozenSourceFileCount'] == 436, 'baseline source count')
base_cases = read(BASE / 'baseline-results/report.json')['cases']
check(len(base_cases) == 2 and base_cases[0]['result'] == 'refused'
      and 'ordinary decimal numbering' in base_cases[0]['error']
      and base_cases[1]['result'] == 'exported'
      and all(c['unchangedAfterExport'] for c in base_cases), 'baseline reproduction outcomes')
report['baseline'] = {'source': base_r['sourceCommit'], **baseline_binding,
                      'outcomes': [{'case': c['case'], 'result': c['result']} for c in base_cases]}

T = '{urn:oasis:names:tc:opendocument:xmlns:text:1.0}'
S = '{urn:oasis:names:tc:opendocument:xmlns:style:1.0}'
M = '{urn:oasis:names:tc:opendocument:xmlns:meta:1.0}'
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
C = '{http://schemas.openxmlformats.org/officeDocument/2006/custom-properties}'


def metadata(name):
    marker = 'ZOTERO_ITEM CSL_CITATION '
    return json.JSONDecoder().raw_decode(name.split(marker, 1)[1])[0]


def odt_inventory(path):
    with ZipFile(path) as z:
        doc = ET.fromstring(z.read('content.xml'))
        styles = ET.fromstring(z.read('styles.xml')) if 'styles.xml' in z.namelist() else None
        meta = ET.fromstring(z.read('meta.xml'))
    notes, fields, counts = [], [], Counter()
    for note in doc.iter(T + 'note'):
        kind = note.attrib[T + 'note-class']
        counts[kind] += 1
        label = ''.join(note.find(T + 'note-citation').itertext())
        body = note.find(T + 'note-body')
        notes.append({'kind': kind, 'ordinal': counts[kind], 'label': label,
                      'text': ''.join(body.itertext())})
        starts = [x.attrib[T + 'name'] for x in body.iter(T + 'reference-mark-start')
                  if x.attrib.get(T + 'name', '').startswith('ZOTERO_ITEM CSL_CITATION ')]
        ends = [x.attrib[T + 'name'] for x in body.iter(T + 'reference-mark-end')
                if x.attrib.get(T + 'name', '').startswith('ZOTERO_ITEM CSL_CITATION ')]
        check(Counter(starts) == Counter(ends), f'{path.name}: active marker pairing')
        for name in starts:
            value = metadata(name)
            fields.append({'id': value['citationID'], 'metadata': value, 'kind': kind,
                           'ordinal': counts[kind], 'label': label})
    starts_all = [x for x in doc.iter(T + 'reference-mark-start')
                  if x.attrib.get(T + 'name', '').startswith('ZOTERO_ITEM CSL_CITATION ')]
    check(len(starts_all) == len(fields), f'{path.name}: active field outside expected note owner')
    config = {}
    for root in [doc, styles]:
        if root is not None:
            for x in root.iter(T + 'notes-configuration'):
                config[x.attrib[T + 'note-class']] = x.attrib.get(S + 'num-format')
    pref = {int(x.attrib[M + 'name'].rsplit('_', 1)[1]): ''.join(x.itertext())
            for x in meta.iter(M + 'user-defined')
            if x.attrib.get(M + 'name', '').startswith('ZOTERO_PREF_')}
    prefs = json.loads(''.join(pref[k] for k in sorted(pref))) if pref else None
    return notes, fields, config, prefs


def docx_inventory(path, expected):
    with ZipFile(path) as z:
        doc = ET.fromstring(z.read('word/document.xml'))
        custom = ET.fromstring(z.read('docProps/custom.xml'))
        parts = {kind: ET.fromstring(z.read('word/' + kind + 's.xml'))
                 for kind in ['footnote', 'endnote'] if 'word/' + kind + 's.xml' in z.namelist()}
    prefs = {int(x.attrib['name'].rsplit('_', 1)[1]): ''.join(x.itertext())
             for x in custom.iter(C + 'property') if x.attrib.get('name', '').startswith('ZOTERO_PREF_')}
    check(json.loads(''.join(prefs[k] for k in sorted(prefs))) == expected['model']['preferences'],
          f'{path}: DOCX preferences')
    counters, fields, notes = Counter(), [], []
    for ref in doc.iter():
        if ref.tag not in [W + 'footnoteReference', W + 'endnoteReference']:
            continue
        kind = ref.tag[len(W):].removesuffix('Reference')
        counters[kind] += 1
        note = next(x for x in parts[kind].findall(W + kind) if x.attrib[W + 'id'] == ref.attrib[W + 'id'])
        check(note.find('.//' + W + kind + 'Ref') is not None, f'{path}: DOCX automatic note reference')
        text = ''.join(x.text or '' for x in note.iter(W + 't'))
        notes.append({'kind': kind, 'ordinal': counters[kind], 'text': text})
        instruction = ''.join(x.text or '' for x in note.iter(W + 'instrText'))
        if 'ZOTERO_ITEM CSL_CITATION ' in instruction:
            value = metadata(instruction)
            fields.append({'id': value['citationID'], 'metadata': value,
                           'kind': kind, 'ordinal': counters[kind]})
    check(len(notes) == len(expected['model']['notes']), f'{path}: DOCX note count')
    for note, wanted in zip(notes, expected['model']['notes']):
        check(note['kind'] == wanted['kind'] and note['ordinal'] == wanted['ordinal']
              and wanted['token'] in note['text'], f'{path}: DOCX owner/content/order')
    check([f['id'] for f in fields] == [f['citationID'] for f in expected['model']['nativeOrder']],
          f'{path}: DOCX active citation order')
    for field in fields:
        wanted = expected['model']['fields'][field['id']]
        check(field['metadata'] == wanted['metadata'] and field['kind'] == wanted['owner']['kind']
              and field['ordinal'] == wanted['owner']['ordinal'], f'{path}: DOCX field metadata/owner')
    for kind, fmt in expected['odt']['xml']['formats'].items():
        native = {'1': 'decimal', 'i': 'lowerRoman', 'I': 'upperRoman'}[fmt]
        options = doc.findall('.//' + W + 'sectPr/' + W + kind + 'Pr/' + W + 'numFmt')
        check(options and all(x.attrib[W + 'val'] == native for x in options), f'{path}: DOCX note format')


conv = BASE / 'roman-converter/accepted-52f53c99'
cr = read(conv / 'receipt.json')
artifacts(conv, cr['artifactHashes'], 'converter')
for command in cr['commands']:
    check(command['exitCode'] == 0, f'converter command failed: {command["name"]}')
    for stream in ['stdout', 'stderr']:
        check(sha(conv / command[stream]) == command[stream + 'Sha256'], f'converter log hash: {command["name"]}/{stream}')
for name, value in cr['scripts'].items():
    location = BASE / name if name == 'reproduce_endnote_export.dart' else BASE / 'roman-converter' / name
    check(sha(location) == value, 'converter script hash: ' + name)
check(cr['sourceCommit'] == QUALIFIED and cmd('rev-parse', QUALIFIED + '^{tree}') == cr['sourceTree'], 'converter source identity')
for mode in ['frozen', 'live']:
    before, after = read(conv / (mode + '-inputs-before.json')), read(conv / (mode + '-inputs-after.json'))
    check(before == after, f'converter {mode} input drift')
    bind(before, QUALIFIED, 'converter ' + mode)
    physical(before, conv / 'frozen-source' if mode == 'frozen' else REPO, 'converter ' + mode)
check(sha(REPO / '.dart_tool/package_config.json') == cr['workspacePackageConfigSha256'], 'converter package config hash')
dart_bin = BASE.parent / 'runtime/flutter/bin/cache/dart-sdk/bin/dart'
soffice_bin = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/program/soffice.bin')
check(sha(dart_bin) == cr['runtime']['dartSha256'], 'converter Dart binary hash')
check(sha(soffice_bin) == cr['runtime']['sofficeBinSha256'], 'converter LibreOffice binary hash')
fixtures = ['default-lower-endnotes', 'mixed-upper-foot-lower-end']
stages = ['original', 'lo-save-1', 'lo-save-2']
notes_total, citations_total, details = 0, 0, []
for fixture in fixtures:
    expected = read(conv / 'original' / (fixture + '.expected.json'))
    model = expected['model']
    notes_total += len(model['notes'])
    citations_total += len(model['fields'])
    for stage in stages:
        observed = read(conv / stage / (fixture + '.observed.json'))
        check(observed['importedModel'] == model and observed['docxReopenedModel'] == model,
              f'{fixture}/{stage}: model round-trip mismatch')
        notes, fields, config, prefs = odt_inventory(conv / stage / (fixture + '.odt'))
        check(len(notes) == len(model['notes']), f'{fixture}/{stage}: XML note count')
        for note, wanted in zip(notes, model['notes']):
            check(all(note[k] == wanted[k] for k in ['kind', 'ordinal', 'label']) and wanted['token'] in note['text'],
                  f'{fixture}/{stage}: XML label/content/order mismatch')
        check([f['id'] for f in fields] == [f['citationID'] for f in model['nativeOrder']], f'{fixture}/{stage}: XML field order')
        for field in fields:
            wanted = model['fields'][field['id']]
            check(field['metadata'] == wanted['metadata'] and all(field[k] == wanted['owner'][k]
                  for k in ['kind', 'ordinal', 'label']), f'{fixture}/{stage}: XML field metadata/owner')
            value = field['metadata']['properties']['noteIndex']
            check(type(value) is int and value == field['ordinal'], f'{fixture}/{stage}: stored integer noteIndex')
        check(all(type(x['noteIndex']) is int for x in observed['importedModel']['nativeOrder']),
              f'{fixture}/{stage}: protocol integer noteIndex')
        check(all(config[k] == v for k, v in expected['odt']['xml']['formats'].items()), f'{fixture}/{stage}: active XML formats')
        check(prefs['prefs']['fieldType'] == 'ReferenceMark', f'{fixture}/{stage}: ODT raw reference-mark prefs')
        prefs['prefs']['fieldType'] = 'Field'
        check(prefs == model['preferences'], f'{fixture}/{stage}: ODT preference metadata')
        docx_inventory(conv / stage / (fixture + '.reopened.docx'), expected)
    details.append({'fixture': fixture, 'notes': len(model['notes']), 'activeCitations': len(model['fields']),
                    'classes': dict(Counter(n['kind'] for n in model['notes'])), 'formats': expected['odt']['xml']['formats']})
check(len(fixtures) == cr['fixtureCount'] == 2 and notes_total == cr['distinctNotes'] == 30 and
      citations_total == cr['distinctActiveCitations'] == 8, 'converter unique coverage count')
live_repro = read(conv / 'live-repro/report.json')['cases']
check(all(c['result'] == 'exported' and c['unchangedAfterExport'] for c in live_repro), 'qualified live reproduction')
report['converter'] = {'source': QUALIFIED, 'fixtures': details, 'distinctNotes': notes_total,
                       'distinctActiveCitations': citations_total, 'actualLibreOfficeSaveCycles': 2,
                       'stagesPerFixture': 3, 'odtPackagesIndependentlyInspected': 6,
                       'docxReopenedPackagesIndependentlyInspected': 6,
                       'normalization': 'LibreOffice adds an unused decimal footnote configuration to the endnote-only fixture.'}

alpha = BASE / 'alpha-probe-canonical'
ar = read(alpha / 'receipt.json')
artifacts(alpha / 'original', ar['inputs'], 'alphabetic input')
artifacts(alpha / 'saved', ar['saved'], 'alphabetic saved')
check(sha(BASE / 'probe_alpha_numbering_canonical.py') == ar['scriptSha256'], 'alphabetic script hash')
check(sha(ar['template']['path']) == ar['template']['sha256'], 'alphabetic template hash')
check(sha(soffice_bin) == ar['sofficeBinarySha256'], 'alphabetic converter binary hash')
alpha_endings = {}
for name in ar['inputs']:
    for folder, recorded in [('original', ar['inputs']), ('saved', ar['saved'])]:
        with ZipFile(alpha / folder / name) as z:
            doc = ET.fromstring(z.read('content.xml'))
        labels = [''.join(x.find(T + 'note-citation').itertext()) for x in doc.iter(T + 'note')]
        check(labels == recorded[name]['labels'] and len(labels) == 28, f'alphabetic labels {folder}/{name}')
        if folder == 'saved':
            alpha_endings[name] = labels[-3:]
            check(labels[-3:] == (['z', 'aa', 'bb'] if 'true' in name else ['z', 'aa', 'ab']), 'alphabetic observed convention')
report['alphabeticProbe'] = {'distinctFixtures': 3, 'notesPerFixture': 28, 'observedEndings': alpha_endings,
                             'countedAsProductCases': False}

portable = BASE / 'final-word-portability'
pr = read(portable / 'receipt.json')
artifacts(portable, pr['artifacts_sha256'], 'portable')
pb, pa = read(portable / 'inputs-before.json'), read(portable / 'inputs-after.json')
check(pb == pa and len(pb) == pr['input_count'], 'portable input drift/count')
bind(pb, pr['source_commit'], 'portable source')
check(not set(pb).intersection(changed), 'portable inputs changed between qualified/final source')
check(all(c['exit_code'] == 0 for c in pr['commands']) and pr['status'] == 'passed', 'portable command outcome')
prefix = read(portable / 'prefix-vm.json')
check(prefix == read(portable / 'prefix-js.json'), 'portable prefix VM/JS difference')
check(all(prefix[k] == v for k, v in pr['checks']['prefix_summary'].items()), 'portable prefix summary')
conformance = read(portable / 'conformance-vm.json')
check((portable / 'conformance-vm.json').read_bytes() == (portable / 'conformance-js.json').read_bytes(),
      'portable conformance VM/JS bytes differ')
check(len(conformance['cases']) == conformance['caseCount'] == pr['checks']['conformance_case_count'] == 78,
      'portable conformance count')
check(len({c['id'] for c in conformance['cases']}) == 78, 'portable duplicate conformance case identities')
report['portability'] = {'prefixOperations': prefix['operations'], 'prefixRevision': prefix['revision'],
                         'conformanceCases': 78, 'vmJsByteIdentity': True, 'inputCount': len(pb),
                         'countedInUnitTotal': False}

git.stdin.close()
git.wait()
report['errors'] = errors
report['result'] = 'PASS' if not errors else 'FAIL'
report['uniqueGitBlobsHashed'] = len(blob_hashes)
report['finishedUtc'] = datetime.now(timezone.utc).isoformat()
output = BASE / 'independent-evidence-audit.json'
output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'result': report['result'], 'errors': errors, 'uniqueUnitCases': len(all_cases),
                  'zoteroCases': report['zoteroUniqueUnitCases'], 'gitBlobs': len(blob_hashes),
                  'report': str(output)}, indent=2))
