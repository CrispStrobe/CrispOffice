#!/usr/bin/env python3
"""Independent ODF numbering probe; no Quds implementation imports."""
from datetime import datetime, timezone
import hashlib
import json
import re
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent / 'alpha-probe-canonical'
TEMPLATE = Path(__file__).resolve().parent / 'alpha-probe/saved/alphabetic-sync-absent.odt'
SOURCE = ROOT / 'original'
SAVED = ROOT / 'saved'
SOFFICE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/program/soffice')
NS = {
    'office': 'urn:oasis:names:tc:opendocument:xmlns:office:1.0',
    'text': 'urn:oasis:names:tc:opendocument:xmlns:text:1.0',
    'style': 'urn:oasis:names:tc:opendocument:xmlns:style:1.0',
}
DECLARATIONS = ' '.join(f'xmlns:{key}="{value}"' for key, value in NS.items())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inspect(path):
    with zipfile.ZipFile(path) as archive:
        content = ET.fromstring(archive.read('content.xml'))
        styles = ET.fromstring(archive.read('styles.xml'))
    notes = content.findall('.//text:note', NS)
    configurations = styles.findall('.//text:notes-configuration', NS)
    return {
        'sha256': digest(path),
        'bytes': path.stat().st_size,
        'labels': [note.find('text:note-citation', NS).text for note in notes],
        'noteIds': [note.get(f'{{{NS["text"]}}}id') for note in notes],
        'configurations': [dict(item.attrib) for item in configurations],
    }


def create(sync):
    name = f'alphabetic-sync-{sync if sync is not None else "absent"}.odt'
    target = SOURCE / name
    with zipfile.ZipFile(TEMPLATE) as source, zipfile.ZipFile(target, 'w') as archive:
        for info in source.infolist():
            data = source.read(info.filename)
            if info.filename == 'styles.xml':
                text = data.decode()
                def replace(match):
                    config = match.group(0).replace('style:num-format="1"', 'style:num-format="a"')
                    assert config != match.group(0), config
                    if sync is not None:
                        config = config.replace('/>', f' style:num-letter-sync="{sync}"/>')
                    return config
                text, count = re.subn(r'<text:notes-configuration[^>]*text:note-class="footnote"[^>]*/>', replace, text)
                assert count == 1, count
                data = text.encode()
            archive.writestr(info, data)
    return target


def main():
    for directory in [ROOT, SOURCE, SAVED]:
        directory.mkdir(parents=True, exist_ok=True)
    inputs = [create(sync) for sync in [None, 'false', 'true']]
    before = {path.name: inspect(path) for path in inputs}
    command = [str(SOFFICE), f'-env:UserInstallation={(ROOT / "profile").as_uri()}', '--headless', '--convert-to', 'odt:writer8', '--outdir', str(SAVED), *map(str, inputs)]
    started = time.monotonic()
    result = subprocess.run(command, text=True, capture_output=True, timeout=45)
    (ROOT / 'converter.stdout.log').write_text(result.stdout)
    (ROOT / 'converter.stderr.log').write_text(result.stderr)
    version = subprocess.check_output([str(SOFFICE), f'-env:UserInstallation={(ROOT / "version-profile").as_uri()}', '--version'], text=True).strip()
    receipt = {
        'completedUtc': datetime.now(timezone.utc).isoformat(),
        'command': command,
        'durationSeconds': round(time.monotonic() - started, 3),
        'converterExitCode': result.returncode,
        'converterVersion': version,
        'sofficeBinarySha256': digest(SOFFICE.with_name('soffice.bin')),
        'scriptSha256': digest(Path(__file__)),
        'inputs': before,
        'template': {'path': str(TEMPLATE), 'sha256': digest(TEMPLATE)},
        'saved': {path.name: inspect(SAVED / path.name) for path in inputs if (SAVED / path.name).exists()},
        'inputsUnchanged': all(digest(path) == before[path.name]['sha256'] for path in inputs),
        'scope': 'Synthetic ODF 1.3 alphabetic footnote configurations opened and saved by the identified LibreOffice build; not installed Zotero or Microsoft Word acceptance.',
    }
    (ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    assert result.returncode == 0, receipt
    assert len(receipt['saved']) == len(inputs), receipt
    assert receipt['inputsUnchanged'], receipt
    print(json.dumps({'converter': version, 'labels26to28': {name: value['labels'][25:28] for name, value in receipt['saved'].items()}, 'receipt': str(ROOT / 'receipt.json')}, indent=2))


if __name__ == '__main__':
    main()
