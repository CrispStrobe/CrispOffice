import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:quds_office_engine/quds_office_engine.dart';

WmlDocument document({required bool decimal}) {
  final body = WmlParagraph(inlines: [WmlRun(text: 'An endnote citation')]);
  final doc = WmlDocument(
    sections: [
      WmlSection(
        blocks: [body],
        sourceProperties: decimal
            ? WmlSectionSource(
                xml:
                    '<w:sectPr xmlns:w="${OfficeNamespaces.w}">'
                    '<w:endnotePr><w:numFmt w:val="decimal"/></w:endnotePr>'
                    '</w:sectPr>',
                values: const {},
              )
            : null,
      ),
    ],
    zoteroDocumentData: jsonEncode({
      'dataVersion': 4,
      'style': {
        'styleID': 'http://www.zotero.org/styles/chicago-fullnote-bibliography',
        'locale': 'en-US',
        'hasBibliography': true,
      },
      'prefs': {'fieldType': 'Field', 'noteType': 2},
    }),
  );
  final note = WordNotes.insert(doc, body, endnote: true, text: 'Source: ');
  WordZotero.insertCitation(
    note.paragraphs.single,
    ZoteroCitation.fromJson({
      'citationID': 'roman-endnote-independent',
      'citationItems': [
        {
          'id': 'http://zotero.org/users/42/items/ABCD1234',
          'uris': ['http://zotero.org/users/42/items/ABCD1234'],
          'itemData': {'id': 1, 'type': 'book', 'title': 'Independent reference'},
        },
      ],
      'properties': {
        'plainCitation': '(Independent reference)',
        'noteIndex': 1,
      },
    }),
  );
  return doc;
}

Map<String, Object?> state(WmlDocument doc) => {
  'bodyText': doc.paragraphs.map((p) => p.text).toList(),
  'notes': [
    for (final note in doc.endnotes)
      {
        'id': note.id,
        'label': WordNoteNumbering(doc).labelFor(note),
        'text': note.text,
      },
  ],
  'fields': [
    for (final field in WordZotero.fields(doc))
      {'instruction': field.instruction, 'text': field.cachedText},
  ],
  'documentData': doc.zoteroDocumentData,
  'sectionXml': doc.sections.single.sourceProperties?.xml,
};

Future<void> main(List<String> args) async {
  final output = Directory(args.single)..createSync(recursive: true);
  final rows = <Map<String, Object?>>[];
  for (final decimal in [false, true]) {
    final name = decimal ? 'explicit-decimal-control' : 'default-roman-endnote';
    final doc = document(decimal: decimal);
    final before = jsonEncode(state(doc));
    final row = <String, Object?>{
      'case': name,
      'inputState': state(doc),
    };
    File('${output.path}/$name.docx').writeAsBytesSync(
      WordSerializer().writeBytes(doc),
    );
    try {
      final bytes = OdtDocumentWriter.writeEditableZoteroBytes(doc);
      File('${output.path}/$name.odt').writeAsBytesSync(bytes);
      final inventory = await OdfZotero.inspect(bytes);
      final reopened = await OdtDocumentReader.readBytes(bytes);
      row.addAll({
        'result': 'exported',
        'bytes': bytes.length,
        'sha256': sha256.convert(bytes).toString(),
        'nativeZoteroFieldCount': inventory.fields.length,
        'nativeFieldsImportable': inventory.fields.every((f) => f.isImportCandidate),
        'reopenedState': state(reopened),
      });
    } catch (error, stack) {
      row.addAll({
        'result': 'refused',
        'errorType': error.runtimeType.toString(),
        'error': error.toString(),
        'stack': stack.toString(),
      });
    }
    row['unchangedAfterExport'] = before == jsonEncode(state(doc));
    rows.add(row);
  }
  final report = {'cases': rows};
  final text = const JsonEncoder.withIndent('  ').convert(report);
  File('${output.path}/report.json').writeAsStringSync('$text\n');
  stdout.writeln(text);
}
