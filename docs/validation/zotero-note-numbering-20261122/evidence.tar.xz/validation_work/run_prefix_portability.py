#!/usr/bin/env python3
"""Run the two newly added office-macros prefix portability gates locally."""

import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


ROOT = Path('/workspace/scratch/1bb837b7ac66/quds_office_suite')
PACKAGE = ROOT / 'packages/quds_office_engine'
OUTPUT = Path('/workspace/scratch/1bb837b7ac66/validation_work/final-word-portability')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def write(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2) + '\n')


def main():
    OUTPUT.mkdir(exist_ok=False)
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
    names = [name for name in tracked if name and (
        name.startswith('packages/') and any(part in name for part in ['/lib/', '/tool/', '/assets/', '/example/macros/', '/test/fixtures/', '/test/support/'])
        or name.endswith(('pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'))
        or name == '.github/workflows/office-macros.yml'
    )]
    names.append('.dart_tool/package_config.json')
    def snapshot():
        return {name: digest(ROOT / name) for name in sorted(names)}
    before = snapshot()
    write('inputs-before.json', before)
    runtime = Path(os.environ['FLUTTER_ROOT']).parent / 'runtime.json'
    receipt = {
        'source_commit': git('rev-parse', 'HEAD'),
        'source_tree': git('rev-parse', 'HEAD^{tree}'),
        'runtime_receipt': str(runtime),
        'runtime_receipt_sha256': digest(runtime),
        'runner_sha256': digest(Path(__file__)),
        'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'status': 'running',
        'commands': [],
        'checks': {},
        'limits': 'Only the newly added BAS prefix and word_cell_prefix_v1 portability gates; no installed Microsoft Word execution.',
    }
    write('receipt.json', receipt)
    def run(label, args, stdout_name):
        record = {'label': label, 'command': args, 'cwd': str(PACKAGE)}
        with (OUTPUT / stdout_name).open('wb') as out, (OUTPUT / (label + '.stderr.log')).open('wb') as err:
            try:
                record['exit_code'] = subprocess.run(args, cwd=PACKAGE, stdout=out, stderr=err, timeout=900, check=False).returncode
            except subprocess.TimeoutExpired:
                record['exit_code'] = None
                record['timed_out'] = True
        receipt['commands'].append(record)
        write('receipt.json', receipt)
        if record['exit_code'] != 0:
            raise RuntimeError(label + ' did not complete successfully')

    try:
        bas = base64.b64encode((PACKAGE / 'example/macros/word_table_prefix.bas').read_bytes()).decode()
        define = '-DWORD_CELL_PREFIX_BAS_BASE64=' + bas
        smoke = 'tool/macros/web_vba_word_cell_prefix_smoke.dart'
        run('prefix-vm', ['dart', define, smoke], 'prefix-vm.json')
        run('prefix-compile-js', ['dart', 'compile', 'js', '-O1', define, smoke, '-o', str(OUTPUT / 'prefix.js')], 'prefix-compile-js.log')
        run('prefix-js', ['node', '-e', 'globalThis.self = globalThis; require(process.argv[1])', str(OUTPUT / 'prefix.js')], 'prefix-js.json')
        vm = json.loads((OUTPUT / 'prefix-vm.json').read_text())
        js = json.loads((OUTPUT / 'prefix-js.json').read_text())
        receipt['checks']['prefix_json_equal'] = vm == js
        receipt['checks']['prefix_summary'] = {key: value for key, value in vm.items() if key != 'state'}
        if vm != js:
            raise RuntimeError('BAS prefix VM/JavaScript JSON differs')

        cases = base64.b64encode((PACKAGE / 'test/fixtures/vba_conformance/word_cell_prefix_v1.json').read_bytes()).decode()
        define = '-DVBA_CONFORMANCE_BASE64=' + cases
        packages = '--packages=../../.dart_tool/package_config.json'
        conformance = 'tool/macros/web_vba_conformance.dart'
        run('conformance-vm', ['dart', packages, define, conformance], 'conformance-vm.json')
        run('conformance-compile-js', ['dart', 'compile', 'js', '-O1', packages, define, conformance, '-o', str(OUTPUT / 'conformance.js')], 'conformance-compile-js.log')
        run('conformance-js', ['node', '-e', 'globalThis.self = globalThis; require(process.argv[1])', str(OUTPUT / 'conformance.js')], 'conformance-js.json')
        receipt['checks']['conformance_bytes_equal'] = (OUTPUT / 'conformance-vm.json').read_bytes() == (OUTPUT / 'conformance-js.json').read_bytes()
        if not receipt['checks']['conformance_bytes_equal']:
            raise RuntimeError('Conformance VM/JavaScript bytes differ')
        conformance_result = json.loads((OUTPUT / 'conformance-vm.json').read_text())
        receipt['checks']['conformance_case_count'] = conformance_result.get('caseCount')
        receipt['status'] = 'passed'
    except Exception as error:
        receipt['status'] = 'not_accepted'
        receipt['error'] = str(error)
    after = snapshot()
    write('inputs-after.json', after)
    receipt['inputs_unchanged'] = before == after
    receipt['input_count'] = len(before)
    receipt['changed_inputs'] = [name for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)]
    receipt['source_commit_after'] = git('rev-parse', 'HEAD')
    receipt['finished_at_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    if before != after:
        receipt['status'] = 'not_accepted'
    receipt['artifacts_sha256'] = {path.name: digest(path) for path in sorted(OUTPUT.iterdir()) if path.is_file() and path.name != 'receipt.json'}
    write('receipt.json', receipt)
    print(json.dumps({key: receipt.get(key) for key in ['status', 'checks', 'inputs_unchanged', 'input_count', 'error']}), flush=True)
    return 0 if receipt['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
