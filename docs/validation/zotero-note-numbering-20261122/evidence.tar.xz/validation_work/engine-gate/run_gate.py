#!/usr/bin/env python3
import argparse, collections, datetime, gzip, hashlib, json, os, subprocess, time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--expected-head', required=True)
args = parser.parse_args()
root = Path('/workspace/scratch/1bb837b7ac66')
repo = root / 'quds_office_suite'
runtime = root / 'runtime'
out = root / 'validation_work/engine-gate/final'
out.mkdir(parents=True, exist_ok=False)
package = repo / 'packages/quds_office_engine'
tests = [
    'odt_zotero_note_numbering_test.dart',
    'word_note_numbering_test.dart',
    'odt_zotero_export_lifecycle_test.dart',
    'odt_libreoffice_note_offsets_test.dart',
    'odt_note_configuration_styles_test.dart',
    'odt_reader_styles_test.dart',
    'odt_note_fidelity_test.dart',
    'odt_zotero_writer_test.dart',
    'odf_zotero_reference_marks_test.dart',
    'word_zotero_note_insertion_test.dart',
    'word_zotero_preference_flow_test.dart',
]
dart = runtime / 'flutter/bin/cache/dart-sdk/bin/dart'
command = [str(dart), 'test', '--concurrency=4', '--reporter=json', *['test/' + name for name in tests]]

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def git(*argv):
    return subprocess.check_output(['git', *argv], cwd=repo, text=True).strip()

head = git('rev-parse', 'HEAD')
if head != args.expected_head:
    raise RuntimeError('Source moved before gate: ' + head)
tracked = git('ls-files').splitlines()
source_paths = [p for p in tracked if
    (p.startswith('packages/') and '/lib/' in p and p.endswith('.dart')) or
    p.startswith('packages/quds_office_engine/test/') or
    p.startswith('packages/quds_office_engine/assets/') or
    Path(p).name in {'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'}]
# New tests must already be committed before the qualification gate.
for name in tests:
    if 'packages/quds_office_engine/test/' + name not in source_paths:
        raise RuntimeError('Uncommitted gate test: ' + name)
metadata_paths = [repo / '.dart_tool/package_config.json', runtime / 'runtime.json',
                  runtime / 'pub-cache-receipt.json', runtime / 'env.sh', dart]

config = json.loads((repo / '.dart_tool/package_config.json').read_text())
dependency_paths = []
from urllib.parse import urlparse, unquote
for entry in config['packages']:
    uri = entry['rootUri']
    resolved = Path(unquote(urlparse(uri).path)) if uri.startswith('file:') else (repo / '.dart_tool' / uri).resolve()
    if str(resolved).startswith(str(runtime / 'pub-cache')):
        dependency_paths.extend(p for p in (resolved / 'lib').rglob('*') if p.is_file())
        for name in ('pubspec.yaml', 'pubspec.lock'):
            if (resolved / name).is_file(): dependency_paths.append(resolved / name)

def snapshot():
    return {
        'repository': {p: sha(repo / p) for p in source_paths},
        'dependencies': {str(p.relative_to(root)): sha(p) for p in sorted(set(dependency_paths))},
        'runtime_and_resolution': {str(p.relative_to(root)): sha(p) for p in metadata_paths},
    }

def write_gz(name, value):
    with gzip.open(out / name, 'wt', encoding='utf-8') as f:
        json.dump(value, f, sort_keys=True, separators=(',', ':'))
        f.write('\n')

before = snapshot()
write_gz('inputs-before.json.gz', before)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
(out / 'command.json').write_text(json.dumps({'command': command, 'cwd': str(package), 'source_commit': head, 'started_at': started}, indent=2) + '\n')
with (out / 'tests.jsonl').open('wb') as stdout, (out / 'tests.stderr.log').open('wb') as stderr:
    process = subprocess.run(command, cwd=package, env=os.environ.copy(), stdout=stdout, stderr=stderr)
after = snapshot()
write_gz('inputs-after.json.gz', after)
rows = []
for line in (out / 'tests.jsonl').read_text().splitlines():
    rows.append(json.loads(line))
suites = {r['suite']['id']: r['suite'] for r in rows if r.get('type') == 'suite'}
starts = {r['test']['id']: r['test'] for r in rows if r.get('type') == 'testStart'}
cases = []
for row in rows:
    if row.get('type') != 'testDone' or row.get('hidden'): continue
    test = starts[row['testID']]
    if test['name'].startswith('loading '): continue
    suite = suites[test['suiteID']]
    path = suite.get('path', suite.get('url', ''))
    cases.append({'suite': path, 'name': test['name'], 'result': row['result'], 'skipped': row.get('skipped', False)})
identities = collections.Counter((c['suite'], c['name']) for c in cases)
counts = collections.Counter('skipped' if c['skipped'] else c['result'] for c in cases)
errors = [r for r in rows if r.get('type') == 'error']
done = [r for r in rows if r.get('type') == 'done']
write_gz('cases.json.gz', cases)
write_gz('errors.json.gz', errors)
with (out / 'tests.jsonl').open('rb') as source, gzip.open(out / 'tests.jsonl.gz', 'wb') as target:
    for block in iter(lambda: source.read(1024 * 1024), b''): target.write(block)
(out / 'tests.jsonl').unlink()
receipt = {
    'source_commit': head, 'head_after': git('rev-parse', 'HEAD'), 'command': command,
    'cwd': str(package), 'started_at': started, 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exit_code': process.returncode, 'suite_count': len(tests), 'loaded_suite_count': len(suites),
    'counts': dict(counts), 'case_count': len(cases), 'error_count': len(errors), 'done': done,
    'duplicate_case_identities': [list(key) for key, count in identities.items() if count != 1],
    'inputs_unchanged': before == after,
    'source_input_count': len(before['repository']), 'dependency_input_count': len(before['dependencies']),
    'runtime': json.loads((runtime / 'runtime.json').read_text()).get('runtime'),
    'artifacts_sha256': {p.name: sha(p) for p in out.iterdir() if p.is_file()},
}
receipt['accepted'] = (process.returncode == 0 and before == after and not errors and
    done == [dict(done[0], success=True)] if len(done) == 1 else False)
receipt['accepted'] = receipt['accepted'] and counts.get('failure', 0) == 0 and counts.get('error', 0) == 0 and counts.get('skipped', 0) == 0 and not receipt['duplicate_case_identities']
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['accepted', 'source_commit', 'counts', 'suite_count', 'error_count', 'inputs_unchanged', 'case_count']}), flush=True)
if not receipt['accepted']: raise SystemExit(1)
