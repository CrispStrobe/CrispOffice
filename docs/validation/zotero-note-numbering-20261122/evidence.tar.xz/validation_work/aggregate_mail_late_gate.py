#!/usr/bin/env python3
"""Preserve the latest complete Mail suite result and prove retained inputs."""

import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path('/workspace/scratch/1bb837b7ac66/validation_work')
SOURCE = ROOT.parent / 'quds_office_suite'
PACKAGE = 'packages/quds_office_editor/example'


def read(path):
    if path.suffix == '.gz':
        return json.loads(gzip.decompress(path.read_bytes()))
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    previous_path = ROOT / 'final-mail-studio-late'
    replacement_path = ROOT / 'final-mail-studio-late-supplement'
    previous = read(previous_path / 'receipt.json')
    replacement = read(replacement_path / 'receipt.json')
    assert previous['status'] == replacement['status'] == 'passed'
    assert previous['inputs_unchanged'] and replacement['inputs_unchanged']
    assert previous['runtime_receipt_sha256'] == replacement['runtime_receipt_sha256']
    before = read(previous_path / 'inputs-before.json.gz')
    after = read(replacement_path / 'inputs-before.json.gz')
    changed = [name for name in sorted(set(before) | set(after))
               if before.get(name) != after.get(name)]
    allowed = {
        PACKAGE + '/test/support/mail_membership_host_cases.dart',
        PACKAGE + '/test/support/mail_membership_recovery_cases.dart',
    }
    assert set(changed) == allowed, changed
    superseded = {str(SOURCE / PACKAGE / name) for name in replacement['tests']}
    expected = {
        str(SOURCE / PACKAGE / 'test/studio_mail_journal_host_test.dart'),
        str(SOURCE / PACKAGE / 'test/studio_mail_flag_recovery_dialog_test.dart'),
    }
    assert superseded == expected
    old_cases = read(previous_path / 'cases.json')
    new_cases = read(replacement_path / 'cases.json')
    for suite in superseded:
        assert {case['name'] for case in old_cases if case['suite'] == suite} == {
            case['name'] for case in new_cases if case['suite'] == suite}
    effective = []
    for case in old_cases:
        if case['suite'] in superseded:
            continue
        source = str(Path(case['suite']).relative_to(SOURCE))
        assert before[source] == after[source]
        effective.append({**case, 'gate': previous_path.name,
                          'executed_source_commit': previous['source_commit']})
    effective.extend({**case, 'gate': replacement_path.name,
                      'executed_source_commit': replacement['source_commit']}
                     for case in new_cases)
    assert len({(case['suite'], case['name']) for case in effective}) == len(effective)
    assert all(case['result'] == 'success' and not case['skipped'] for case in effective)
    target = ROOT / 'final-mail-studio-effective'
    target.mkdir(exist_ok=False)
    (target / 'cases.json').write_text(json.dumps(effective, indent=2) + '\n')
    receipt = {
        'status': 'passed',
        'method': 'Latest complete execution per suite. Two support-consuming suites replace their earlier executions; all production/dependency inputs and five retained Studio suites have identical hashes.',
        'qualification_commit': replacement['source_commit'],
        'qualification_tree': replacement['source_tree'],
        'counts': {'passed': len(effective), 'failed': 0, 'skipped': 0, 'unfinished': 0},
        'suite_count': len({case['suite'] for case in effective}),
        'per_suite_counts': dict(sorted(Counter(case['suite'] for case in effective).items())),
        'retained_cases': len(effective) - len(new_cases),
        'replacement_cases': len(new_cases),
        'superseded_suites': sorted(superseded),
        'changed_inputs': changed,
        'source_receipts': {str(path.relative_to(ROOT)): digest(path) for path in [
            previous_path / 'receipt.json', replacement_path / 'receipt.json']},
        'cases_sha256': digest(target / 'cases.json'),
        'runner_sha256': digest(Path(__file__)),
        'runtime_receipt_sha256': replacement['runtime_receipt_sha256'],
        'retained_package_gates': {},
    }
    for name in ['final-mail-core-late', 'final-mail-transport-late', 'final-mail-store-late']:
        path = ROOT / name
        gate = read(path / 'receipt.json')
        assert gate['status'] == 'passed' and gate['inputs_unchanged']
        assert read(path / 'inputs-before.json.gz') == before
        assert gate['runtime_receipt_sha256'] == replacement['runtime_receipt_sha256']
        receipt['retained_package_gates'][name] = {
            'executed_source_commit': gate['source_commit'],
            'qualification_commit': replacement['source_commit'],
            'all_production_and_package_test_inputs_unchanged': True,
            'counts': gate['counts'],
            'receipt_sha256': digest(path / 'receipt.json'),
        }
    (target / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in [
        'status', 'counts', 'suite_count', 'retained_cases',
        'replacement_cases', 'changed_inputs']}))


if __name__ == '__main__':
    main()
