#!/usr/bin/env python3
"""Source-bound real-file converter qualification; no installed Zotero claims."""
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import time
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent / 'quds_office_suite'
RUNTIME = ROOT.parent.parent / 'runtime'
DART = RUNTIME / 'bin/dart'
SOFFICE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/program/soffice')
COMMIT = sys.argv[1]
RUN = ROOT / sys.argv[2]
SOURCE_PATHS = ['packages/quds_office_engine/lib', 'packages/legacy_doc_parser/lib']
NAMES = ['default-lower-endnotes', 'mixed-upper-foot-lower-end']
T = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0'
S = 'urn:oasis:names:tc:opendocument:xmlns:style:1.0'
M = 'urn:oasis:names:tc:opendocument:xmlns:meta:1.0'
LOWER = ['i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix', 'x']
RUN.mkdir(parents=True, exist_ok=False)
record = {'sourceCommit': COMMIT, 'startedUtc': datetime.now(timezone.utc).isoformat(), 'commands': [], 'scope': 'Synthetic active Zotero ODT, actual LibreOffice open/save twice, Quds ODT import and DOCX save/reopen; no installed Zotero plugin or Microsoft Word execution.'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def save_record():
    write_json(RUN / 'receipt.json', record)


def execute(name, argv, cwd=REPO, timeout=180):
    print('START ' + name, flush=True)
    started = time.monotonic()
    out = RUN / (name + '.stdout.log')
    err = RUN / (name + '.stderr.log')
    with out.open('wb') as stdout, err.open('wb') as stderr:
        result = subprocess.run([str(x) for x in argv], cwd=cwd, stdout=stdout, stderr=stderr, timeout=timeout)
    record['commands'].append({'name': name, 'argv': list(map(str, argv)), 'cwd': str(cwd), 'exitCode': result.returncode, 'seconds': round(time.monotonic() - started, 3), 'stdout': out.name, 'stderr': err.name, 'stdoutSha256': sha(out), 'stderrSha256': sha(err)})
    save_record()
    print('END ' + name + ' exit=' + str(result.returncode), flush=True)
    if result.returncode:
        raise RuntimeError(name + ': ' + err.read_text(errors='replace')[-10000:] + out.read_text(errors='replace')[-10000:])


def live_inputs():
    paths = subprocess.check_output(['git', 'ls-files', *SOURCE_PATHS, '*pubspec.yaml', '*pubspec.lock'], cwd=REPO, text=True).splitlines()
    return {path: sha(REPO / path) for path in paths}


def frozen_inputs(source):
    return {path.relative_to(source).as_posix(): sha(path) for path in sorted(source.rglob('*')) if path.is_file()}


def raw_odt(path):
    with zipfile.ZipFile(path) as bundle:
        content = ET.fromstring(bundle.read('content.xml'))
        styles = ET.fromstring(bundle.read('styles.xml'))
        meta = ET.fromstring(bundle.read('meta.xml'))
    configurations = {node.get(f'{{{T}}}note-class'): dict(node.attrib) for node in styles.iter(f'{{{T}}}notes-configuration')}
    notes = []
    for node in content.iter(f'{{{T}}}note'):
        body = node.find(f'{{{T}}}note-body')
        citations = []
        for mark in body.iter(f'{{{T}}}reference-mark-start'):
            name = mark.get(f'{{{T}}}name', '')
            if name.startswith('ZOTERO_ITEM CSL_CITATION '):
                match = re.fullmatch(r'ZOTERO_ITEM CSL_CITATION (.+) RND[A-Za-z0-9]{10}', name)
                assert match, name
                citations.append(json.loads(match.group(1))['citationID'])
        notes.append({'kind': node.get(f'{{{T}}}note-class'), 'label': ''.join(node.find(f'{{{T}}}note-citation').itertext()), 'text': ''.join(body.itertext()), 'citationIDs': citations})
    chunks = {}
    for node in meta.iter(f'{{{M}}}user-defined'):
        name = node.get(f'{{{M}}}name', '')
        if name.startswith('ZOTERO_PREF_'):
            chunks[int(name[len('ZOTERO_PREF_'):])] = ''.join(node.itertext())
    prefs = json.loads(''.join(chunks[key] for key in sorted(chunks)))
    return {'sha256': sha(path), 'bytes': path.stat().st_size, 'configurations': configurations, 'notes': notes, 'preferences': prefs}


def independent_raw_gate(directory):
    inventory = {}
    for name in NAMES:
        found = raw_odt(directory / (name + '.odt'))
        expected_notes = []
        for index, lower in enumerate(LOWER, 1):
            for endnote in ([False, True] if name.startswith('mixed-') else [True]):
                kind = 'endnote' if endnote else 'footnote'
                token = f'{kind} source {index:02d}'
                cited = index in ({4, 9} if name.startswith('mixed-') else {3, 4, 9, 10})
                expected_notes.append({'kind': kind, 'label': lower if endnote else lower.upper(), 'token': token, 'citationIDs': [f'{name}-{kind}-{index}'] if cited else []})
        assert len(found['notes']) == len(expected_notes), (name, 'note count')
        for observed, expected in zip(found['notes'], expected_notes):
            for key in ['kind', 'label', 'citationIDs']:
                assert observed[key] == expected[key], (name, key, observed, expected)
            assert expected['token'] in observed['text'], (name, observed, expected)
        assert found['configurations']['endnote'][f'{{{S}}}num-format'] == 'i'
        if name.startswith('mixed-'):
            assert found['configurations']['footnote'][f'{{{S}}}num-format'] == 'I'
        assert found['preferences']['prefs']['fieldType'] == 'ReferenceMark'
        inventory[name] = found
    write_json(directory / 'independent-xml-inventory.json', inventory)
    return inventory


try:
    record['sourceTree'] = subprocess.check_output(['git', 'rev-parse', COMMIT + '^{tree}'], cwd=REPO, text=True).strip()
    before = live_inputs()
    for path, digest in before.items():
        if any(path.startswith(prefix + '/') for prefix in SOURCE_PATHS):
            assert hashlib.sha256(subprocess.check_output(['git', 'show', COMMIT + ':' + path], cwd=REPO)).hexdigest() == digest, 'Live source differs: ' + path
    write_json(RUN / 'live-inputs-before.json', before)
    original_config = REPO / '.dart_tool/package_config.json'
    record['workspacePackageConfigSha256'] = sha(original_config)
    source = RUN / 'frozen-source'
    source.mkdir()
    archive = subprocess.check_output(['git', 'archive', COMMIT, *SOURCE_PATHS, 'packages/quds_office_engine/pubspec.yaml', 'packages/legacy_doc_parser/pubspec.yaml'], cwd=REPO)
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:') as bundle:
        bundle.extractall(source, filter='data')
    frozen_before = frozen_inputs(source)
    write_json(RUN / 'frozen-inputs-before.json', frozen_before)
    config = json.loads(original_config.read_text())
    for package in config['packages']:
        package['rootUri'] = urllib.parse.urljoin(original_config.as_uri(), package['rootUri'])
        if package['name'] in {'quds_office_engine', 'legacy_doc_parser'}:
            package['rootUri'] = (source / 'packages' / package['name']).as_uri() + '/'
    package_config = RUN / 'package_config.json'
    write_json(package_config, config)
    record['scripts'] = {path.name: sha(path) for path in [Path(__file__), ROOT / 'roman_fixtures.dart', ROOT.parent / 'reproduce_endnote_export.dart']}
    record['runtime'] = {'dartSha256': sha(RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'), 'sofficeBinSha256': sha(SOFFICE.with_name('soffice.bin'))}
    execute('dart-version', [DART, '--version'])
    execute('libreoffice-version', [SOFFICE, '-env:UserInstallation=' + (RUN / 'version-profile').as_uri(), '--version'])
    execute('live-baseline-reproduction', [DART, '--packages=' + str(original_config), ROOT.parent / 'reproduce_endnote_export.dart', RUN / 'live-repro'])
    reproduction = json.loads((RUN / 'live-repro/report.json').read_text())
    assert all(case['result'] == 'exported' and case['nativeZoteroFieldCount'] == 1 and case['nativeFieldsImportable'] and case['unchangedAfterExport'] for case in reproduction['cases']), reproduction
    assert reproduction['cases'][0]['reopenedState']['notes'][0]['label'] == 'i', reproduction
    assert reproduction['cases'][1]['reopenedState']['notes'][0]['label'] == '1', reproduction
    record['liveReproductionPassed'] = True
    assert live_inputs() == before, 'Live inputs changed during reproduction'
    original = RUN / 'original'
    first = RUN / 'lo-save-1'
    second = RUN / 'lo-save-2'
    for directory in [original, first, second]:
        directory.mkdir()
    dart_command = [DART, '--packages=' + str(package_config), ROOT / 'roman_fixtures.dart']
    execute('create', [*dart_command, 'create', original])
    original_hashes = {path.name: sha(path) for path in original.glob('*') if path.is_file()}
    independent_raw_gate(original)
    execute('verify-original', [*dart_command, 'verify', original, original])
    for index, (input_dir, output_dir) in enumerate([(original, first), (first, second)], 1):
        input_hashes = {name: sha(input_dir / (name + '.odt')) for name in NAMES}
        execute('libreoffice-save-' + str(index), [SOFFICE, '-env:UserInstallation=' + (RUN / ('profile-' + str(index))).as_uri(), '--headless', '--convert-to', 'odt:writer8', '--outdir', output_dir, *[input_dir / (name + '.odt') for name in NAMES]], timeout=60)
        assert all(sha(input_dir / (name + '.odt')) == digest for name, digest in input_hashes.items()), 'Converter modified originals'
        independent_raw_gate(output_dir)
        execute('verify-save-' + str(index), [*dart_command, 'verify', output_dir, original])
    assert all(sha(original / name) == digest for name, digest in original_hashes.items()), 'Original generated files changed'
    frozen_after = frozen_inputs(source)
    after = live_inputs()
    write_json(RUN / 'frozen-inputs-after.json', frozen_after)
    write_json(RUN / 'live-inputs-after.json', after)
    assert frozen_before == frozen_after, 'Frozen tested source changed'
    record['frozenInputsUnchanged'] = True
    record['liveInputsUnchanged'] = before == after
    record['liveChangedPaths'] = [path for path in set(before) | set(after) if before.get(path) != after.get(path)]
    record['packageConfigUnchanged'] = record['workspacePackageConfigSha256'] == sha(original_config)
    record['fixtureCount'] = 2
    record['distinctNotes'] = 30
    record['distinctActiveCitations'] = 8
    record['libreofficeSaveCycles'] = 2
    record['odtImportAndDocxReopenStagesPerFixture'] = 3
    record['artifactHashes'] = {path.relative_to(RUN).as_posix(): {'sha256': sha(path), 'bytes': path.stat().st_size} for directory in [RUN / 'live-repro', original, first, second] for path in sorted(directory.glob('*')) if path.is_file()}
    record['result'] = 'PASS'
except BaseException as error:
    record['result'] = 'FAIL'
    record['error'] = repr(error)
    raise
finally:
    record['finishedUtc'] = datetime.now(timezone.utc).isoformat()
    save_record()
    print(json.dumps({'result': record['result'], 'error': record.get('error'), 'receipt': str(RUN / 'receipt.json')}), flush=True)
