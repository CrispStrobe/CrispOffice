This preliminary live reproduction is not accepted source-bound evidence.
The initial live-versus-b5e9885f source guard detected concurrent edits to word_note_numbering.dart.
The shell continued to run the reproduction after that setup exception; this output is retained here only as an unqualified development attempt.
The final run_qualification.py driver aborts immediately on a source mismatch and records source manifests before/after, with a frozen committed source for converter work.
