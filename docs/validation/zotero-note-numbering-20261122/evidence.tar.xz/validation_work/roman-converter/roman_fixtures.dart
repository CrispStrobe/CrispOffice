import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:quds_office_engine/quds_office_engine.dart';

const lower = ['i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix', 'x'];
const textNs = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0';
const styleNs = 'urn:oasis:names:tc:opendocument:xmlns:style:1.0';

Object? canonical(Object? value) {
  if (value is Map) {
    final keys = value.keys.cast<String>().toList()..sort();
    return {for (final key in keys) key: canonical(value[key])};
  }
  if (value is List) return value.map(canonical).toList();
  return value;
}

void equal(Object? actual, Object? expected, String context) {
  if (jsonEncode(canonical(actual)) != jsonEncode(canonical(expected))) {
    throw StateError(
      '$context\nActual: ${jsonEncode(actual)}\nExpected: ${jsonEncode(expected)}',
    );
  }
}

void require(bool condition, String context) {
  if (!condition) throw StateError(context);
}

ZoteroCitation citation(String id, int ordinal) => ZoteroCitation.fromJson({
  'citationID': id,
  'citationItems': [
    {
      'id': 'http://zotero.org/users/42/items/ABCD1234',
      'uris': ['http://zotero.org/users/42/items/ABCD1234'],
      'locator': '$ordinal–${ordinal + 2}',
      'label': 'page',
      'prefix': 'see ',
      'suffix': ' retained',
      'suppress-author': true,
      'itemData': {
        'id': 17,
        'type': 'book',
        'title': 'Independent Roman study العربية 😀',
        'author': [
          {'family': 'Sample', 'given': 'A.'},
        ],
        'issued': {
          'date-parts': [
            [2026],
          ],
        },
      },
      'futureItem': {'retain': true},
    },
  ],
  'properties': {
    'plainCitation': '(Sample $ordinal)',
    'formattedCitation': '(Sample $ordinal)',
    'noteIndex': ordinal,
  },
  'futureCitation': ['keep', null, 7],
});

WmlDocument fixture(String name) {
  final mixed = name == 'mixed-upper-foot-lower-end';
  final doc = WmlDocument(
    zoteroDocumentData: jsonEncode({
      'dataVersion': 4,
      'sessionID': 'independent-roman-converter',
      'style': {
        'styleID': 'http://www.zotero.org/styles/chicago-fullnote-bibliography',
        'locale': 'en-US',
        'hasBibliography': true,
        'bibliographyStyleHasBeenSet': false,
      },
      'prefs': {'fieldType': 'Field', 'noteType': 2},
      'futurePreference': {'text': 'Preserved العربية 😀', 'value': 17},
    }),
    sections: [
      WmlSection(
        blocks: [],
        sourceProperties: mixed
            ? WmlSectionSource(
                xml:
                    '<w:sectPr xmlns:w="${OfficeNamespaces.w}">'
                    '<w:footnotePr><w:numFmt w:val="upperRoman"/><w:numStart w:val="1"/><w:numRestart w:val="continuous"/></w:footnotePr>'
                    '<w:endnotePr><w:numFmt w:val="lowerRoman"/><w:numStart w:val="1"/><w:numRestart w:val="continuous"/></w:endnotePr>'
                    '</w:sectPr>',
                values: const {},
              )
            : null,
      ),
    ],
  );
  for (var ordinal = 1; ordinal <= 10; ordinal++) {
    for (final endnote in mixed ? [false, true] : [true]) {
      final kind = endnote ? 'endnote' : 'footnote';
      final token = '$kind source ${ordinal.toString().padLeft(2, '0')}';
      final body = WmlParagraph(inlines: [WmlRun(text: 'Anchor $token ')]);
      doc.sections.single.blocks.add(body);
      final note = WordNotes.insert(
        doc,
        body,
        endnote: endnote,
        text: '$token ',
      );
      final cited = mixed
          ? {4, 9}.contains(ordinal)
          : {3, 4, 9, 10}.contains(ordinal);
      if (cited) {
        WordZotero.insertCitation(
          note.paragraphs.single,
          citation('$name-$kind-$ordinal', ordinal),
        );
      }
    }
  }
  return doc;
}

Map<String, Object?> modelSnapshot(WmlDocument doc) {
  final numbering = WordNoteNumbering(doc);
  final counts = <String, int>{};
  final owners = <WmlNote, Map<String, Object?>>{};
  final notes = <Map<String, Object?>>[];
  for (final note in numbering.notes) {
    final kind = note.endnote ? 'endnote' : 'footnote';
    final ordinal = (counts[kind] ?? 0) + 1;
    counts[kind] = ordinal;
    final token = '$kind source ${ordinal.toString().padLeft(2, '0')}';
    require(
      note.text.contains(token),
      'Note ownership lost: $kind $ordinal (${note.text})',
    );
    require(numbering.hasExactLabel(note), 'Inexact numbering for $token');
    final owner = <String, Object?>{
      'kind': kind,
      'ordinal': ordinal,
      'label': numbering.labelFor(note),
      'token': token,
    };
    owners[note] = owner;
    notes.add(owner);
  }
  final anchorCounts = <WmlNote, int>{};
  for (final paragraph in doc.paragraphs) {
    for (final run in paragraph.inlines.whereType<WmlRun>()) {
      if (run.noteRefId == null) continue;
      final matches = numbering.notes
          .where(
            (n) => n.id == run.noteRefId && n.endnote == run.noteRefEndnote,
          )
          .toList();
      require(matches.length == 1, 'Missing or duplicate note definition');
      final note = matches.single;
      equal(
        numbering.referenceLabel(run),
        numbering.labelFor(note),
        'Visible note anchor',
      );
      anchorCounts.update(note, (n) => n + 1, ifAbsent: () => 1);
    }
  }
  require(
    numbering.notes.every((n) => anchorCounts[n] == 1),
    'Every note needs one exclusive body anchor',
  );
  final fields = <String, Object?>{};
  for (final field in WordZotero.fields(doc)) {
    require(field.isValid && field.canEdit, 'Native field lost editability');
    final owner = numbering.notes
        .where((n) => n.allParagraphs.contains(field.paragraph))
        .toList();
    require(owner.length == 1, 'Citation field changed native owner');
    final id = field.citation!.citationId;
    require(!fields.containsKey(id), 'Duplicate citation ID');
    fields[id] = {
      'owner': owners[owner.single],
      'text': field.cachedText,
      'metadata': field.citation!.toJson(),
    };
    require(
      field.citation!.properties['noteIndex'] is int,
      'Stored noteIndex is not an integer',
    );
    equal(
      field.citation!.properties['noteIndex'],
      owners[owner.single]!['ordinal'],
      'Stored numeric noteIndex',
    );
  }
  final session = WordZoteroCitingSession(
    document: doc,
    documentId: 'roman-qualification',
    insertionParagraph: doc.paragraphs.first,
  );
  final records = (session.handle('Document.getFields', [
    'roman-qualification',
    'Http',
  ]) as List<Object?>).cast<Map<String, Object>>();
  final wire = <Map<String, Object?>>[];
  for (final record in records) {
    final code = record['code']! as String;
    final metadata =
        jsonDecode(code.substring(code.indexOf('{'))) as Map<String, Object?>;
    final id = metadata['citationID']! as String;
    final field = fields[id]! as Map<String, Object?>;
    final owner = field['owner']! as Map<String, Object?>;
    require(record['noteIndex'] is int, 'Protocol noteIndex is not an integer');
    equal(record['noteIndex'], owner['ordinal'], 'Protocol numeric noteIndex');
    wire.add({
      'citationID': id,
      'noteIndex': record['noteIndex'],
      'kind': owner['kind'],
    });
  }
  return {
    'notes': notes,
    'fields': fields,
    'nativeOrder': wire,
    'preferences': jsonDecode(WordZoteroDocumentData.read(doc)),
  };
}

Iterable<XmlElement> elements(XmlElement root, String local, String ns) sync* {
  if (root.localName == local && root.namespaceUri == ns) yield root;
  for (final child in root.childElements) yield* elements(child, local, ns);
}

Map<String, Object?> odtXml(Uint8List bytes) {
  final zip = ZipReader.fromBytes(bytes);
  final styles = XmlDocument.parse(utf8.decode(zip.read('styles.xml'))).root!;
  final content = XmlDocument.parse(utf8.decode(zip.read('content.xml'))).root!;
  final formats = <String, String?>{};
  for (final configuration in elements(styles, 'notes-configuration', textNs)) {
    formats[configuration.getAttribute('note-class', namespaceUri: textNs)!] =
        configuration.getAttribute('num-format', namespaceUri: styleNs);
  }
  return {
    'formats': formats,
    'notes': [
      for (final note in elements(content, 'note', textNs))
        {
          'kind': note.getAttribute('note-class', namespaceUri: textNs),
          'label': note.firstChild('note-citation', namespaceUri: textNs)!.text,
        },
    ],
  };
}

Future<Map<String, Object?>> odtSnapshot(Uint8List bytes) async {
  final inventory = await OdfZotero.inspect(bytes);
  require(inventory.issues.isEmpty, 'ODT has document inventory issues');
  require(
    inventory.fields.every((f) => f.isImportCandidate),
    'ODT field is not importable',
  );
  require(
    inventory.preferences.isValid && inventory.preferences.usesReferenceMarks,
    'ODT preferences invalid',
  );
  return {
    'xml': odtXml(bytes),
    'fields': [
      for (final field in inventory.fields)
        {
          'name': field.name,
          'id': field.metadata!['citationID'],
          'metadata': field.metadata,
          'text': field.cachedText,
          'story': field.starts.single.story.name,
        },
    ],
    'preferences': jsonDecode(
      WordZoteroDocumentData.fromOdt(inventory.preferences.rawData!),
    ),
  };
}

void assertExpectedLabels(String name, Map<String, Object?> snapshot) {
  final notes = (snapshot['notes']! as List).cast<Map<String, Object?>>();
  final expected = <Map<String, Object?>>[];
  for (var index = 0; index < 10; index++) {
    for (final endnote
        in name == 'mixed-upper-foot-lower-end' ? [false, true] : [true]) {
      final kind = endnote ? 'endnote' : 'footnote';
      expected.add({
        'kind': kind,
        'ordinal': index + 1,
        'label': endnote ? lower[index] : lower[index].toUpperCase(),
        'token': '$kind source ${(index + 1).toString().padLeft(2, '0')}',
      });
    }
  }
  equal(notes, expected, 'Independent expected Roman sequence');
}

void writeJson(String path, Object? value) => File(
  path,
).writeAsStringSync('${const JsonEncoder.withIndent('  ').convert(value)}\n');

Future<void> main(List<String> args) async {
  final mode = args[0];
  final directory = Directory(args[1])..createSync(recursive: true);
  final names = ['default-lower-endnotes', 'mixed-upper-foot-lower-end'];
  final results = <Map<String, Object?>>[];
  for (final name in names) {
    if (mode == 'create') {
      final doc = fixture(name);
      final before = modelSnapshot(doc);
      assertExpectedLabels(name, before);
      final bytes = OdtDocumentWriter.writeEditableZoteroBytes(doc);
      equal(modelSnapshot(doc), before, 'Export modified source model');
      File('${directory.path}/$name.odt').writeAsBytesSync(bytes);
      File('${directory.path}/$name.docx')
          .writeAsBytesSync(WordSerializer().writeBytes(doc));
      final odt = await odtSnapshot(bytes);
      equal(
        odt['preferences'],
        before['preferences'],
        'Original ODT preferences',
      );
      final reimported = await OdtDocumentReader.readBytes(bytes);
      equal(modelSnapshot(reimported), before, 'Immediate ODT round trip');
      writeJson('${directory.path}/$name.expected.json', {
        'model': before,
        'odt': odt,
      });
      results.add({
        'name': name,
        'notes': (before['notes']! as List).length,
        'fields': (before['fields']! as Map).length,
        'odtSha256': sha256.convert(bytes).toString(),
        'result': 'PASS',
      });
    } else if (mode == 'verify') {
      final expected = jsonDecode(
        File('${args[2]}/$name.expected.json').readAsStringSync(),
      ) as Map<String, Object?>;
      final bytes = File('${directory.path}/$name.odt').readAsBytesSync();
      final actualOdt = await odtSnapshot(bytes);
      final expectedOdt = expected['odt']! as Map<String, Object?>;
      equal(
        actualOdt['fields'],
        expectedOdt['fields'],
        'LibreOffice field identities/text/owners/order',
      );
      equal(
        actualOdt['preferences'],
        expectedOdt['preferences'],
        'LibreOffice Zotero preferences',
      );
      final expectedXml = expectedOdt['xml']! as Map<String, Object?>;
      final actualXml = actualOdt['xml']! as Map<String, Object?>;
      equal(
        actualXml['notes'],
        expectedXml['notes'],
        'LibreOffice native note labels/order',
      );
      final expectedFormats = expectedXml['formats']! as Map<String, Object?>;
      final actualFormats = actualXml['formats']! as Map<String, Object?>;
      for (final kind in expectedFormats.keys)
        equal(
          actualFormats[kind],
          expectedFormats[kind],
          'LibreOffice $kind numbering format',
        );
      final imported = await OdtDocumentReader.readBytes(bytes);
      final importedModel = modelSnapshot(imported);
      assertExpectedLabels(name, importedModel);
      equal(
        importedModel,
        expected['model'],
        'LibreOffice ODT import into Quds',
      );
      final docx = WordSerializer().writeBytes(imported);
      File('${directory.path}/$name.reopened.docx').writeAsBytesSync(docx);
      final reopened = WordDeserializer().readBytes(docx);
      final reopenedModel = modelSnapshot(reopened);
      equal(
        reopenedModel,
        expected['model'],
        'DOCX save/reopen after LibreOffice',
      );
      writeJson('${directory.path}/$name.observed.json', {
        'odt': actualOdt,
        'importedModel': importedModel,
        'docxReopenedModel': reopenedModel,
      });
      results.add({
        'name': name,
        'notes': (importedModel['notes']! as List).length,
        'fields': (importedModel['fields']! as Map).length,
        'odtSha256': sha256.convert(bytes).toString(),
        'docxSha256': sha256.convert(docx).toString(),
        'result': 'PASS',
      });
    } else {
      throw ArgumentError('Unknown mode $mode');
    }
  }
  writeJson('${directory.path}/$mode-report.json', results);
  stdout.writeln(jsonEncode(results));
}
