#!/usr/bin/env python3
"""Reconcile final Word evidence by latest complete suite, with source proofs."""
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

WORK = Path(__file__).resolve().parent
REPO = WORK.parent / 'quds_office_suite'
LATEST = sys.argv[1]
TARGET = WORK / sys.argv[2]
TARGET.mkdir(exist_ok=False)


def read(path):
    data = gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes()
    return json.loads(data)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def word_dependency(path):
    return (
        path.startswith('packages/quds_office_engine/')
        and any('/' + part + '/' in path for part in ['lib', 'tool', 'assets', 'example/macros', 'test/fixtures', 'test/support'])
        or path.startswith('packages/legacy_doc_parser/lib/')
        or path.endswith(('pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'))
        or path in {'.dart_tool/package_config.json', '.github/workflows/office-macros.yml'}
    )


gates = ['final-word', 'final-word-supplement', LATEST]
data = {}
for gate in gates:
    directory = WORK / gate
    receipt = read(directory / 'receipt.json')
    assert receipt['inputs_unchanged'], gate
    if gate != 'final-word':
        assert receipt['status'] == 'passed', gate
    for artifact, digest in receipt['artifacts_sha256'].items():
        assert sha(directory / artifact) == digest, (gate, artifact)
    before = read(directory / 'inputs-before.json.gz')
    after = read(directory / 'inputs-after.json.gz')
    assert before == after, gate
    data[gate] = {'receipt': receipt, 'inputs': before, 'cases': read(directory / 'cases.json')}

latest = data[LATEST]
qualification = latest['receipt']['source_commit']
runtime = latest['receipt']['runtime_receipt_sha256']
assert all(row['receipt']['runtime_receipt_sha256'] == runtime for row in data.values())
current_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
by_suite = {}
for gate in gates:
    for suite in sorted({case['suite'] for case in data[gate]['cases']}):
        cases = [case for case in data[gate]['cases'] if case['suite'] == suite]
        by_suite[suite] = [dict(case, gate=gate, executed_source_commit=data[gate]['receipt']['source_commit']) for case in cases]

equivalence = {}
for gate, row in data.items():
    selected = {path: digest for path, digest in row['inputs'].items() if word_dependency(path)}
    mismatches = [path for path, digest in selected.items() if sha(REPO / path) != digest]
    assert not mismatches, (gate, 'Word dependencies changed', mismatches)
    retained_suites = sorted(suite for suite, cases in by_suite.items() if cases[0]['gate'] == gate)
    for suite in retained_suites:
        path = 'packages/quds_office_engine/' + suite
        assert sha(REPO / path) == row['inputs'][path], (gate, suite)
    equivalence[gate] = {
        'executed_source_commit': row['receipt']['source_commit'],
        'word_dependency_input_count': len(selected),
        'word_dependency_inputs_unchanged': True,
        'retained_suites': retained_suites,
        'retained_cases': sum(len(by_suite[suite]) for suite in retained_suites),
        'source_receipt_sha256': sha(WORK / gate / 'receipt.json'),
    }

effective = [case for suite in sorted(by_suite) for case in by_suite[suite]]
assert len({(case['suite'], case['name']) for case in effective}) == len(effective)
assert all(case['result'] == 'success' and not case['skipped'] for case in effective)
old_effective = read(WORK / 'final-word-effective/cases.json')
old_ids = {(case['suite'], case['name']) for case in old_effective}
new_ids = {(case['suite'], case['name']) for case in effective}

portable = WORK / 'final-word-portability'
portable_receipt = read(portable / 'receipt.json')
assert portable_receipt['status'] == 'passed' and portable_receipt['inputs_unchanged']
portable_before = read(portable / 'inputs-before.json')
portable_after = read(portable / 'inputs-after.json')
assert portable_before == portable_after
portable_selected = {path: digest for path, digest in portable_before.items() if word_dependency(path)}
assert all(sha(REPO / path) == digest for path, digest in portable_selected.items())
for artifact, digest in portable_receipt['artifacts_sha256'].items():
    assert sha(portable / artifact) == digest, ('portable', artifact)

converter = WORK / 'roman-converter/accepted-52f53c99'
converter_receipt = read(converter / 'receipt.json')
assert converter_receipt['result'] == 'PASS'
converter_before = read(converter / 'live-inputs-before.json')
converter_after = read(converter / 'live-inputs-after.json')
assert converter_before == converter_after
assert all(sha(REPO / path) == digest for path, digest in converter_before.items())
for artifact, detail in converter_receipt['artifactHashes'].items():
    assert sha(converter / artifact) == detail['sha256'], ('converter', artifact)

write(TARGET / 'cases.json', effective)
proof = {
    'qualification_commit': qualification,
    'current_head_at_audit': current_head,
    'suite_proofs': equivalence,
    'portability': {
        'executed_source_commit': portable_receipt['source_commit'],
        'relevant_input_count': len(portable_selected),
        'engine_parser_tools_bas_fixtures_support_and_dependencies_unchanged': True,
        'source_receipt_sha256': sha(portable / 'receipt.json'),
        'checks': portable_receipt['checks'],
        'rerun_required': False,
    },
    'roman_converter': {
        'executed_source_commit': converter_receipt['sourceCommit'],
        'input_count': len(converter_before),
        'all_recorded_engine_parser_and_manifest_inputs_unchanged': True,
        'source_receipt_sha256': sha(converter / 'receipt.json'),
        'rerun_required': False,
    },
}
write(TARGET / 'source-equivalence.json', proof)
receipt = {
    'status': 'passed',
    'recorded_utc': datetime.now(timezone.utc).isoformat(),
    'method': 'Latest complete execution replaces each whole suite. Original and supplemental results are retained only when exact suite and dependency hashes still match. The final integration suite replaces its prior 14 cases without double counting.',
    'qualification_commit': qualification,
    'qualification_tree': latest['receipt']['source_tree'],
    'counts': {'passed': len(effective), 'failed': 0, 'skipped': 0, 'unfinished': 0},
    'suite_count': len(by_suite),
    'new_case_count': len(new_ids - old_ids),
    'removed_case_count': len(old_ids - new_ids),
    'count_change': len(effective) - len(old_effective),
    'retained_case_counts_by_gate': dict(Counter(case['gate'] for case in effective)),
    'latest_execution_case_count': len(latest['cases']),
    'source_receipts': {gate + '/receipt.json': sha(WORK / gate / 'receipt.json') for gate in gates},
    'runtime_receipt_sha256': runtime,
    'cases_sha256': sha(TARGET / 'cases.json'),
    'source_equivalence_sha256': sha(TARGET / 'source-equivalence.json'),
    'runner_sha256': sha(Path(__file__)),
}
write(TARGET / 'receipt.json', receipt)
print(json.dumps({key: receipt[key] for key in ['status', 'counts', 'suite_count', 'count_change', 'retained_case_counts_by_gate']}))
