#!/usr/bin/env python3
"""Independently audit the bounded-intake reporter evidence, without reruns.

The previously reviewed read-only audit functions are loaded as declarations;
their old top-level audit is deliberately not executed or overwritten.
"""
import argparse
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/scratch/1bb837b7ac66/validation_work')
HELPER = BASE / 'independent_evidence_audit.py'
parser = argparse.ArgumentParser()
parser.add_argument('--target', default='89789360590b6dd0af0a378bfc257a3c4a18fc9c')
parser.add_argument('--mail-supplement')
args = parser.parse_args()
module = ast.parse(HELPER.read_text(), filename=str(HELPER))
declarations = []
for node in module.body:
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'report' for t in node.targets):
        break
    declarations.append(node)
helper = {}
exec(compile(ast.Module(body=declarations, type_ignores=[]), str(HELPER), 'exec'), helper)
gate, check, read, sha, cmd = (helper[n] for n in ['gate', 'check', 'read', 'sha', 'cmd'])
tree = helper['tree']
errors = helper['errors']
repo = helper['REPO']
names = ['engine-gate/final', 'final-editor', 'final-studio-latest', 'final-word',
         'final-word-supplement', 'final-word-latest-integration', 'final-mail-core-late',
         'final-mail-transport-late', 'final-mail-store-late', 'final-mail-studio-late']
if args.mail_supplement:
    names.append(args.mail_supplement)
gates = {name: gate(name) for name in names}
target_tree = tree(args.target)


def suite_path(package, suite):
    path = Path(suite)
    return str(path.relative_to(repo)) if path.is_absolute() else package + '/' + suite


def replace_whole_suites(ordered_names):
    suites = {}
    for name in ordered_names:
        g = gates[name]
        for suite in {c['suite'] for c in g['cases']}:
            suites[(g['package'], suite)] = [dict(c, gate=name, executed_source_commit=g['source'])
                                             for c in g['cases'] if c['suite'] == suite]
    return [dict(c, package=package) for (package, _), cases in suites.items() for c in cases]


word_names = ['final-word', 'final-word-supplement', 'final-word-latest-integration']
word = replace_whole_suites(word_names)
check(len(word) == 583, 'Effective Word total changed')
wr_dir = BASE / 'final-word-effective-latest'
wr = read(wr_dir / 'receipt.json')
check(wr['qualification_commit'] == '89789360590b6dd0af0a378bfc257a3c4a18fc9c', 'Word effective source')
check(sha(wr_dir / 'cases.json') == wr['cases_sha256'], 'Word effective cases hash')
check(sha(wr_dir / 'source-equivalence.json') == wr['source_equivalence_sha256'], 'Word source proof hash')
for name, digest in wr['source_receipts'].items():
    check(sha(BASE / name) == digest, 'Word effective source receipt hash: ' + name)
recorded_word = read(wr_dir / 'cases.json')
def stable_case(c):
    return tuple(c.get(k) for k in ['suite', 'name', 'result', 'skipped', 'gate', 'executed_source_commit'])
check({stable_case(c) for c in word} == {stable_case(c) for c in recorded_word}
      and len(recorded_word) == len(word), 'Word aggregate differs from independently replaced reporters')
check(dict(Counter(c['gate'] for c in word)) == wr['retained_case_counts_by_gate'], 'Word retention accounting')
mail_names = ['final-mail-studio-late'] + ([args.mail_supplement] if args.mail_supplement else [])
mail_studio = replace_whole_suites(mail_names)
check(len(mail_studio) == 305, 'Effective Studio Mail total changed')
single_names = ['engine-gate/final', 'final-editor', 'final-studio-latest', 'final-mail-core-late',
                'final-mail-transport-late', 'final-mail-store-late']
effective = [dict(c, package=gates[name]['package'], gate=name, executed_source_commit=gates[name]['source'])
             for name in single_names for c in gates[name]['cases']] + word + mail_studio
identities = [(c['package'], suite_path(c['package'], c['suite']), c['name']) for c in effective]
check(len(identities) == len(set(identities)) == 2723, 'Effective case total or duplicate identities')
check(all(c['result'] == 'success' and not c['skipped'] for c in effective), 'Effective nonpassing case')
for case in effective:
    path = suite_path(case['package'], case['suite'])
    old = tree(case['executed_source_commit'])
    check(old.get(path) == target_tree.get(path), 'Retained selected test changed: ' + path)

# Each reused gate's exact selected files were checked above. For engine,
# editor and converter the separate conservative closure proof binds all local
# dependencies, assets and fixtures. Whole-suite replacement covers the support
# cleanup; no edited support file may remain only under an older parent suite.
closure_root = BASE / 'source-applicability-89789360'
closure = read(closure_root / 'receipt.json')
check(closure['result'] == 'PASS' and not closure['errors'], 'Source-closure proof is not accepted')
alias_changed = cmd('diff', '--name-only', closure['targetSource'], args.target).splitlines()
if args.target != closure['targetSource']:
    check(args.mail_supplement is not None, 'Final source changed without cleanup supplement')
    check(len(alias_changed) == 2 and all('/example/test/support/' in p for p in alias_changed),
          'Final alias changed paths outside two Studio test support files')
for name in ['engine372', 'editor80', 'converter']:
    manifest = read(closure_root / (name + '-paths.json.gz'))
    check(not set(alias_changed).intersection(manifest), 'Final source alias enters ' + name + ' closure')
    for path, value in manifest.items():
        check(target_tree.get(path) == value['targetBlob'], name + ': applicability alias source mismatch ' + path)

# Verify the Word source slices represented by retained whole suites against
# final source; other changed product packages cannot enter those pure-Dart
# engine and parser scopes.
for name in word_names:
    source_tree = tree(gates[name]['source'])
    paths = {p for p in source_tree if p.startswith(('packages/quds_office_engine/lib/',
                                                   'packages/legacy_doc_parser/lib/',
                                                   'packages/quds_office_engine/tool/',
                                                   'packages/quds_office_engine/example/macros/',
                                                   'packages/quds_office_engine/test/fixtures/',
                                                   'packages/quds_office_engine/test/support/'))
             or Path(p).name in {'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'}}
    check(all(source_tree[p] == target_tree.get(p) for p in paths), 'Word dependency slice changed: ' + name)

helper['git'].stdin.close()
helper['git'].wait()
out = BASE / ('independent-audit-' + args.target[:8])
out.mkdir(exist_ok=True)
cases_path = out / 'effective-cases.json'
cases_path.write_text(json.dumps(sorted(effective, key=lambda c: (c['package'], c['suite'], c['name'])),
                                 indent=2, ensure_ascii=False) + '\n')
report = {'result': 'PASS' if not errors else 'FAIL', 'targetSource': args.target,
          'targetTree': cmd('rev-parse', args.target + '^{tree}'),
          'createdUtc': datetime.now(timezone.utc).isoformat(),
          'method': 'Read-only independent reporter recount, Git-source binding and whole-suite replacement; no product reruns.',
          'totalUniquePassingCases': len(effective), 'zoteroCases': 463, 'effectiveWordCases': len(word),
          'mailCoreCases': len(gates['final-mail-core-late']['cases']),
          'mailTransportCases': len(gates['final-mail-transport-late']['cases']),
          'mailStoreCases': len(gates['final-mail-store-late']['cases']),
          'effectiveStudioMailCases': len(mail_studio),
          'retainedCasesByGate': dict(sorted(Counter(c['gate'] for c in effective).items())),
          'gates': {name: {k: v for k, v in g.items() if k not in ['cases', 'tests']} for name, g in gates.items()},
          'sourceClosureReceiptSha256': sha(closure_root / 'receipt.json'),
          'finalAliasChangedPaths': alias_changed,
          'sourceReceiptHashes': {name: sha(BASE / name / 'receipt.json') for name in names},
          'auditFunctionsSha256': sha(HELPER), 'auditRunnerSha256': sha(__file__),
          'effectiveCasesSha256': sha(cases_path),
          'gitBlobsIndependentlyHashed': len(helper['blob_hashes']), 'errors': errors}
(out / 'receipt.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'result': report['result'], 'cases': len(effective), 'errors': errors,
                  'gitBlobs': report['gitBlobsIndependentlyHashed'], 'output': str(out)}, indent=2))
