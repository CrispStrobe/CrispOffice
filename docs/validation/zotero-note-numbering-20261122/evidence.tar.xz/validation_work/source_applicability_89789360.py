#!/usr/bin/env python3
"""Prove repository source applicability without re-executing product code."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import urljoin, urlparse, unquote
import yaml

BASE = Path('/workspace/scratch/1bb837b7ac66/validation_work')
REPO = BASE.parent / 'quds_office_suite'
TARGET = '89789360590b6dd0af0a378bfc257a3c4a18fc9c'
OUT = BASE / 'source-applicability-89789360'
OUT.mkdir(exist_ok=True)
errors = []
trees = {}


def check(value, message):
    if not value:
        errors.append(message)


def read(path):
    if str(path).endswith('.gz'):
        with gzip.open(path, 'rt') as f:
            return json.load(f)
    return json.loads(Path(path).read_text())


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()


def tree(commit):
    if commit not in trees:
        raw = subprocess.check_output(['git', 'ls-tree', '-rz', commit], cwd=REPO)
        trees[commit] = {path.decode(): data.split()[2].decode()
                         for record in raw.split(b'\0') if record
                         for data, path in [record.split(b'\t', 1)]}
    return trees[commit]


config_path = REPO / '.dart_tool/package_config.json'
config = read(config_path)
roots = {p['name']: Path(unquote(urlparse(urljoin(config_path.as_uri(), p['rootUri'])).path))
         for p in config['packages']}
package_uris = {p['name']: p.get('packageUri', 'lib/') for p in config['packages']}
runtime_path = BASE.parent / 'runtime/runtime.json'
runtime = read(runtime_path)
for path, digest in runtime['executables_sha256'].items():
    check(sha(path) == digest, 'runtime executable changed: ' + path)
final_tree = tree(TARGET)
manifest_paths = {p for p in final_tree if Path(p).name in
                  {'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'}}


def dependencies(start, dev):
    pending, seen = [start], {}
    while pending:
        name = pending.pop()
        if name in seen:
            continue
        check(name in roots, 'unresolved dependency: ' + name)
        root = roots[name]
        manifest = root / 'pubspec.yaml'
        value = yaml.safe_load(manifest.read_text())
        deps = dict(value.get('dependencies') or {})
        if name == start and dev:
            deps.update(value.get('dev_dependencies') or {})
        seen[name] = {'root': str(root), 'dependencies': sorted(deps),
                      'pubspecSha256': sha(manifest), 'repositoryPackage': root.is_relative_to(REPO)}
        pending.extend(set(deps) - set(seen))
    return seen


def prove(label, start, source, tests, snapshot, dev):
    graph = dependencies(start, dev)
    local = {name: Path(value['root']) for name, value in graph.items() if value['repositoryPackage']}
    closure = set(manifest_paths)
    roots_relative = {name: str(root.relative_to(REPO)) for name, root in local.items()}
    for name, root in local.items():
        prefix = str(root.relative_to(REPO)) + '/'
        manifest = yaml.safe_load((root / 'pubspec.yaml').read_text())
        asset_prefixes = [prefix + a for a in (manifest.get('flutter') or {}).get('assets', [])
                          if isinstance(a, str)]
        closure.update(p for p in final_tree if p.startswith(prefix + 'lib/'))
        closure.update(p for p in final_tree if p.startswith(prefix + 'test/fixtures/'))
        closure.update(p for p in final_tree if any(p == a or p.startswith(a) for a in asset_prefixes))
    selected = [str(roots[start].relative_to(REPO)) + '/' + p for p in tests]
    closure.update(selected)
    # Inspect all imports/exports/parts in the conservative local source closure.
    # Any relative or package directive reaching another repository file must
    # already lie within that closure; this detects undeclared Mail/example use.
    imported_local = set()
    for name in sorted(closure):
        if not name.endswith('.dart'):
            continue
        text = (REPO / name).read_text()
        for directive in re.findall(r'(?m)^\s*(?:import|export|part)\s+[^;]+;', text):
            for _, uri in re.findall(r"(['\"])(.*?)\1", directive):
                if uri.startswith('dart:') or not uri.endswith('.dart'):
                    continue
                if uri.startswith('package:'):
                    package, suffix = uri[len('package:'):].split('/', 1)
                    check(package in roots, label + ': unknown imported package ' + package)
                    target = (roots[package] / package_uris[package] / suffix).resolve()
                    if target.is_relative_to(REPO):
                        imported_local.add(package)
                        check(package in local, label + ': undeclared repository dependency ' + package)
                else:
                    target = (REPO / name).parent.joinpath(uri).resolve()
                if target.is_relative_to(REPO):
                    check(str(target.relative_to(REPO)) in closure,
                          label + ': repository directive outside closure ' + str(target))
    old_tree = tree(source)
    changed = sorted(p for p in closure if old_tree.get(p) != final_tree.get(p))
    check(not changed, label + ': changed repository closure files: ' + str(changed))
    file_records, snapshot_bound = {}, 0
    for name in sorted(closure):
        path = REPO / name
        data = path.read_bytes()
        disk_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        digest = hashlib.sha256(data).hexdigest()
        check(disk_blob == final_tree[name], label + ': worktree differs from final source ' + name)
        if name in snapshot:
            check(snapshot[name] == digest, label + ': prior execution snapshot differs ' + name)
            snapshot_bound += 1
        file_records[name] = {'sourceBlob': old_tree.get(name), 'targetBlob': final_tree[name], 'sha256': digest}
    changed_outside = [p for p in git('diff', '--name-only', source, TARGET).splitlines() if p not in closure]
    record = {'label': label, 'qualifiedSource': source, 'targetSource': TARGET,
              'dependencyPackageCount': len(graph), 'repositoryPackages': roots_relative,
              'importedRepositoryPackages': sorted(imported_local), 'selectedTests': selected,
              'repositoryClosureFiles': len(closure), 'priorExecutionSnapshotMatches': snapshot_bound,
              'byteIdenticalGitPaths': len(closure), 'changedClosureFiles': changed,
              'changedPathsOutsideClosure': changed_outside, 'dependencyGraph': graph}
    with gzip.open(OUT / (label + '-paths.json.gz'), 'wt') as f:
        json.dump(file_records, f, indent=2, sort_keys=True)
        f.write('\n')
    return record


engine_r = read(BASE / 'engine-gate/final/receipt.json')
editor_r = read(BASE / 'final-editor/receipt.json')
converter_dir = BASE / 'roman-converter/accepted-52f53c99'
converter_r = read(converter_dir / 'receipt.json')
records = []
for label, package, r, path in [('engine372', 'quds_office_engine', engine_r, 'engine-gate/final'),
                               ('editor80', 'quds_office_editor', editor_r, 'final-editor')]:
    snapshot = read(BASE / path / 'inputs-before.json.gz')
    check(snapshot == read(BASE / path / 'inputs-after.json.gz'), label + ': execution input drift')
    check(sha(config_path) == snapshot['.dart_tool/package_config.json'], label + ': dependency resolution changed')
    check(sha(runtime_path) == r['runtime_receipt_sha256'], label + ': runtime receipt changed')
    records.append(prove(label, package, r['source_commit'], r['tests'], snapshot, True))
converter_snapshot = read(converter_dir / 'live-inputs-before.json')
check(converter_snapshot == read(converter_dir / 'live-inputs-after.json'), 'converter execution input drift')
check(sha(config_path) == converter_r['workspacePackageConfigSha256'], 'converter dependency resolution changed')
records.append(prove('converter', 'quds_office_engine', converter_r['sourceCommit'], [], converter_snapshot, False))
frozen = read(converter_dir / 'frozen-inputs-before.json')
check(frozen == read(converter_dir / 'frozen-inputs-after.json'), 'converter frozen input drift')
for name, value in frozen.items():
    check(sha(REPO / name) == value, 'converter frozen source no longer identical: ' + name)
for name, digest in converter_r['scripts'].items():
    path = BASE / name if name == 'reproduce_endnote_export.dart' else BASE / 'roman-converter' / name
    check(sha(path) == digest, 'converter qualification script changed: ' + name)
check(git('rev-parse', TARGET + '^{tree}') == 'f3b0f40e2fe06ae372e4f69654058a36b4170e9c', 'target tree mismatch')
report = {'result': 'PASS' if not errors else 'FAIL', 'targetSource': TARGET,
          'targetTree': git('rev-parse', TARGET + '^{tree}'), 'createdUtc': datetime.now(timezone.utc).isoformat(),
          'scope': 'Repository source closure and unchanged resolved dependencies/runtime; no product tests rerun.',
          'externalDependencyEvidence': 'The prior locked resolution, package configuration and runtime receipt hashes remain identical. External manifest hashes record the current installed packages; they are not presented as a historical source snapshot.',
          'workspaceManifestCount': len(manifest_paths), 'workspacePackageConfigSha256': sha(config_path),
          'runtimeReceiptSha256': sha(runtime_path), 'qualifiedConverterFrozenFiles': len(frozen),
          'closures': records, 'errors': errors}
(OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
lines = ['# Source applicability at 89789360', '',
         f'**Result: {report["result"]}.** Target `{TARGET}` (tree `{report["targetTree"]}`).', '',
         'This is a read-only source and evidence comparison. No product tests were rerun.', '',
         '| Existing evidence | Qualified commit | Repository dependency packages | Unchanged closure files | Selected test files |',
         '|---|---|---|---:|---:|']
for r in records:
    lines.append(f'| {r["label"]} | `{r["qualifiedSource"][:8]}` | {", ".join(r["repositoryPackages"])} | {r["repositoryClosureFiles"]} | {len(r["selectedTests"])} |')
lines += ['', 'The conservative closure includes the dependency packages’ complete library source, declared editor assets, fixture directories, selected tests, and every tracked pubspec/lock/analysis-options file in the workspace. Source directives were inspected for repository imports outside that closure; none were found. The Mail packages and the nested Studio example package are outside these closures.', '',
          'Every closure path has the same Git blob at the qualified and target commits, and the current checked-out file matches that blob. Every path also present in the original execution snapshot matches its recorded SHA-256. Detailed path records are retained in the compressed manifests beside the receipt.', '',
          'The package configuration, lockfiles and runtime receipt retain their qualification hashes. External dependency manifest hashes in the receipt identify the current locked installation; they are not represented as a historical snapshot of the entire package cache.', '',
          f'The actual LibreOffice qualification’s {len(frozen)} frozen engine/parser source files and all three harness scripts remain identical. Its two distinct fixtures, 30 notes and eight active citations therefore apply to this target without another conversion cycle.', '',
          'The updated Mail and Studio surfaces require their separate final gates. Their earlier results are not carried forward by this proof.', '']
(OUT / 'README.md').write_text('\n'.join(lines))
print(json.dumps({'result': report['result'], 'errors': errors,
                  'closures': [{k: r[k] for k in ['label', 'dependencyPackageCount', 'repositoryClosureFiles', 'priorExecutionSnapshotMatches']} for r in records],
                  'output': str(OUT)}, indent=2))
