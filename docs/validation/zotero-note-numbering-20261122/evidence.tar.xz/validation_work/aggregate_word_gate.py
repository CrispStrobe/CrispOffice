#!/usr/bin/env python3
"""Combine the frozen Word gate and corrected-suite rerun without double counts."""

import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/1bb837b7ac66/validation_work')


def read(path):
    if path.suffix == '.gz':
        return json.loads(gzip.decompress(path.read_bytes()))
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    previous_path = ROOT / 'final-word'
    replacement_path = ROOT / 'final-word-supplement'
    previous = read(previous_path / 'receipt.json')
    replacement = read(replacement_path / 'receipt.json')
    assert replacement['status'] == 'passed'
    assert previous['inputs_unchanged'] and replacement['inputs_unchanged']
    assert previous['runtime_receipt_sha256'] == replacement['runtime_receipt_sha256']
    before = read(previous_path / 'inputs-before.json.gz')
    after = read(replacement_path / 'inputs-before.json.gz')
    changed = [name for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)]
    superseded = set(replacement['tests'])
    allowed = {'packages/quds_office_engine/' + name for name in superseded}
    allowed.add('packages/quds_office_editor/example/test/studio_zotero_odt_export_test.dart')
    assert set(changed) <= allowed, changed
    old_cases = read(previous_path / 'cases.json')
    new_cases = read(replacement_path / 'cases.json')
    for suite in superseded:
        assert {case['name'] for case in old_cases if case['suite'] == suite} == {case['name'] for case in new_cases if case['suite'] == suite}
    effective = []
    for case in old_cases:
        if case['suite'] in superseded:
            continue
        file = 'packages/quds_office_engine/' + case['suite']
        assert before[file] == after[file]
        effective.append({**case, 'gate': 'final-word', 'executed_source_commit': previous['source_commit']})
    effective.extend({**case, 'gate': 'final-word-supplement', 'executed_source_commit': replacement['source_commit']} for case in new_cases)
    identities = {(case['suite'], case['name']) for case in effective}
    assert len(identities) == len(effective)
    assert all(case['result'] == 'success' and not case['skipped'] for case in effective)
    counts = {'passed': len(effective), 'failed': 0, 'skipped': 0, 'unfinished': 0}
    target = ROOT / 'final-word-effective'
    target.mkdir(exist_ok=False)
    (target / 'cases.json').write_text(json.dumps(effective, indent=2) + '\n')
    receipt = {
        'status': 'passed',
        'method': 'Latest complete execution per suite; the three supplemental suites replace their earlier executions. All other production/dependency inputs and seven retained test suites have identical hashes.',
        'qualification_commit': replacement['source_commit'],
        'qualification_tree': replacement['source_tree'],
        'counts': counts,
        'suite_count': len({case['suite'] for case in effective}),
        'retained_cases': sum(case['gate'] == 'final-word' for case in effective),
        'replacement_cases': len(new_cases),
        'superseded_suites': sorted(superseded),
        'changed_inputs': changed,
        'initial_failure_cases': [case for case in old_cases if case['result'] != 'success'],
        'source_receipts': {str(path.relative_to(ROOT)): digest(path) for path in [previous_path / 'receipt.json', replacement_path / 'receipt.json']},
        'cases_sha256': digest(target / 'cases.json'),
        'runner_sha256': digest(Path(__file__)),
        'runtime_receipt_sha256': replacement['runtime_receipt_sha256'],
    }
    receipt['mail_source_equivalence'] = {}
    for gate in ['final-mail-core', 'final-mail-transport']:
        mail_path = ROOT / gate
        mail = read(mail_path / 'receipt.json')
        assert mail['status'] == 'passed' and mail['inputs_unchanged']
        assert read(mail_path / 'inputs-before.json.gz') == before
        receipt['mail_source_equivalence'][gate] = {
            'executed_source_commit': mail['source_commit'],
            'qualification_commit': replacement['source_commit'],
            'all_production_and_mail_test_inputs_unchanged': True,
            'counts': mail['counts'],
            'receipt_sha256': digest(mail_path / 'receipt.json'),
        }
    (target / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ['status', 'counts', 'suite_count', 'retained_cases', 'replacement_cases', 'changed_inputs']}))


if __name__ == '__main__':
    main()
