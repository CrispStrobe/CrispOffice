import hashlib,json,subprocess,time
from pathlib import Path
root=Path('/workspace/scratch/1bb837b7ac66/quds_office_suite')
out=Path('/workspace/scratch/1bb837b7ac66/validation_work/final-intake-static')
paths=[p for p in subprocess.check_output(['git','diff','--name-only','b13a170cdb5fd42b9a0f2c77d97c996caf5d0d7f','HEAD'],cwd=root,text=True).splitlines() if p.endswith('.dart') and (root/p).exists()]
def sha(p): return hashlib.sha256((root/p).read_bytes()).hexdigest()
def snap(): return {p:sha(p) for p in paths}
r={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'paths':paths,'started_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'before':snap(),'commands':[]}
for name,command in [('format',['dart','format','--output=none','--set-exit-if-changed',*paths]),('analysis',['dart','analyze','--fatal-infos',*paths])]:
    with (out/(name+'-final.log')).open('wb') as stream:
        run=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
    r['commands'].append({'name':name,'argv':command,'exit_code':run.returncode,'log':name+'-final.log'})
r['after']=snap()
r['inputs_unchanged']=r['before']==r['after']
r['finished_at_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
r['passed']=r['inputs_unchanged'] and all(c['exit_code']==0 for c in r['commands'])
r['artifacts_sha256']={c['log']:hashlib.sha256((out/c['log']).read_bytes()).hexdigest() for c in r['commands']}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'passed':r['passed'],'source_commit':r['source_commit'],'path_count':len(paths),'commands':[{k:v for k,v in c.items() if k!='argv'} for c in r['commands']]},indent=2))
raise SystemExit(0 if r['passed'] else 1)
