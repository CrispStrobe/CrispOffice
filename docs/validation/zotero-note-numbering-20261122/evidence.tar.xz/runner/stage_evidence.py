#!/usr/bin/env python3
"""Package exact local receipts and artifacts; omit reproducible installations."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile

BASE = Path('/workspace/scratch/1bb837b7ac66')
WORK = BASE / 'validation_work'
REPO = BASE / 'quds_office_suite'
RUNTIME = BASE / 'runtime'
OUTPUT = BASE / 'evidence_package'
STAGE = OUTPUT / 'staging'
OMITTED_COMPONENTS = {
    'baseline-source', 'candidate-source', 'frozen-source', '.dart_tool',
    '__pycache__', 'profile', 'version-profile',
}
OMITTED_FILENAMES = {'final-readme-template.md'}
OMISSION_NOTES = [
    'Reproducible committed source extracts: baseline-source, candidate-source, frozen-source. Exact commit identities and per-file hash manifests are retained.',
    'LibreOffice profile directories: profile, profile-*, version-profile. Original/saved documents, exact commands, native converter identity and binary hash are retained.',
    'Installed Flutter/Dart SDK and Pub package contents. Official archive, executable and package hashes, release metadata, extraction inventory, bootstrap script and logs are retained.',
    'Transient package caches, Python bytecode and runtime-ready marker files. Compiled portability JavaScript, source maps and dependency files are included.',
    'Unfinished final-readme-template.md is excluded. The completed human-readable README is published beside the evidence archive.',
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def copy_file(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    assert sha(source) == sha(target), ('Source changed while staging', str(source))


def omitted(relative):
    return any(part in OMITTED_COMPONENTS or part.startswith('profile-') for part in relative.parts[:-1]) or relative.suffix == '.pyc' or relative.name in OMITTED_FILENAMES


def running_gate(top):
    if not top.is_dir():
        return False
    receipt = top / 'receipt.json'
    if not receipt.exists():
        return False
    return json.loads(receipt.read_text()).get('status') == 'running'


def preserve_initial_attempts():
    target = STAGE / 'validation_work/packaging-attempts/pre-mail-support-fix'
    if target.exists():
        return
    target.mkdir(parents=True)
    for name in ['static', 'final-intake-static']:
        origin = WORK / name
        if origin.exists():
            for source in origin.rglob('*'):
                if source.is_file() and not omitted(source.relative_to(origin)):
                    copy_file(source, target / name / source.relative_to(origin))
    for name in ['independent-evidence-audit.json', 'independent_evidence_audit.py', 'run_final_static.py']:
        if (WORK / name).exists():
            copy_file(WORK / name, target / name)
    write_json(target / 'snapshot.json', {'capturedUtc': datetime.now(timezone.utc).isoformat(), 'purpose': 'Retain earlier failed/pending static and audit evidence before final Mail support-only corrections and final audit.'})


def stage():
    STAGE.mkdir(parents=True, exist_ok=True)
    for name in OMITTED_FILENAMES:
        stale = STAGE / 'validation_work' / name
        if stale.exists():
            stale.unlink()
    preserve_initial_attempts()
    skipped = []
    for top in sorted(WORK.iterdir()):
        if top.name in OMITTED_COMPONENTS:
            continue
        if running_gate(top):
            skipped.append(top.name)
            continue
        sources = [top] if top.is_file() else sorted(top.rglob('*'))
        for source in sources:
            if not source.is_file():
                continue
            relative = source.relative_to(WORK)
            if not omitted(relative):
                copy_file(source, STAGE / 'validation_work' / relative)
    for source in sorted(RUNTIME.iterdir()):
        if source.is_file() and source.suffix in {'.json', '.jsonl', '.py', '.sh', '.log'}:
            copy_file(source, STAGE / 'runtime' / source.name)
    for folder in ['logs', 'bin']:
        for source in sorted((RUNTIME / folder).rglob('*')):
            if source.is_file():
                copy_file(source, STAGE / 'runtime' / folder / source.relative_to(RUNTIME / folder))
    runner = REPO / 'docs/validation/zotero-note-numbering-20261122/run_local_gate.py'
    copy_file(runner, STAGE / 'runner/run_local_gate.py')
    copy_file(Path(__file__), STAGE / 'runner/stage_evidence.py')
    for name in ['intake.json', 'intake-final.json', 'main-reconciliation.json']:
        source = REPO / 'docs/validation/zotero-note-numbering-20261122' / name
        if source.exists():
            copy_file(source, STAGE / 'intake' / name)
    files = [p for p in STAGE.rglob('*') if p.is_file()]
    print(json.dumps({'mode': 'stage', 'files': len(files), 'bytes': sum(p.stat().st_size for p in files), 'running_gates_skipped': skipped}))
    return skipped


def seal():
    skipped = stage()
    assert not skipped, ('Cannot seal while gates are running', skipped)
    assert (STAGE / 'intake/intake-final.json').exists(), 'Final intake is required before sealing'
    files = [p for p in sorted(STAGE.rglob('*')) if p.is_file() and p != STAGE / 'INDEX.json']
    entries = [{'path': p.relative_to(STAGE).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in files]
    index = {
        'createdUtc': datetime.now(timezone.utc).isoformat(),
        'roots': ['validation_work/', 'runtime/', 'runner/', 'intake/'],
        'file_count_excluding_index': len(entries),
        'uncompressed_bytes_excluding_index': sum(p['bytes'] for p in entries),
        'omissions': OMISSION_NOTES,
        'index_self_hash_excluded': True,
        'files': entries,
    }
    write_json(OUTPUT / 'evidence.index.json', index)
    copy_file(OUTPUT / 'evidence.index.json', STAGE / 'INDEX.json')
    archive = OUTPUT / 'evidence.tar.xz'
    with tarfile.open(archive, 'w:xz', preset=6) as bundle:
        for path in sorted(STAGE.rglob('*')):
            if path.is_file():
                info = bundle.gettarinfo(str(path), arcname=path.relative_to(STAGE).as_posix())
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                with path.open('rb') as stream:
                    bundle.addfile(info, stream)
    with tarfile.open(archive, 'r:xz') as bundle:
        members = {member.name: member for member in bundle.getmembers()}
        assert len(members) == len(entries) + 1
        for entry in entries:
            data = bundle.extractfile(members[entry['path']]).read()
            assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256'], entry['path']
        assert bundle.extractfile(members['INDEX.json']).read() == (OUTPUT / 'evidence.index.json').read_bytes()
    receipt = {
        'sealedUtc': datetime.now(timezone.utc).isoformat(),
        'archive': archive.name,
        'archive_bytes': archive.stat().st_size,
        'archive_sha256': sha(archive),
        'index': 'evidence.index.json',
        'index_sha256': sha(OUTPUT / 'evidence.index.json'),
        'files_including_index': len(entries) + 1,
        'all_archive_member_hashes_verified': True,
        'receipt_bytes_preserved': True,
        'script_sha256': sha(Path(__file__)),
        'omissions': OMISSION_NOTES,
    }
    write_json(OUTPUT / 'package-receipt.json', receipt)
    print(json.dumps(receipt))


if __name__ == '__main__':
    if len(sys.argv) == 2 and sys.argv[1] == 'seal':
        seal()
    elif len(sys.argv) == 2 and sys.argv[1] == 'stage':
        stage()
    else:
        raise SystemExit('Use stage first; seal only after final gates and audit are complete.')
