# Native ODT loader and Studio integration checks

The scoped local gates passed 11 engine cases, 8 editor/controller cases, and
7 Studio/File-menu cases with zero failures or skips. These results overlap
parent aggregate gates and must not be added to them. Ten owned source/test
paths passed strict analysis and formatting; their hashes are recorded.

The first Studio attempt timed out in its async test helper. Correcting the
helper to pump frames while real isolate work completed produced the final
seven passing cases. Both original and corrected attempt logs are retained.
No product-code change was needed for that test-harness correction.

## Actual converter probe

The native-prose fixture was created by Quds as DOCX and converted by installed
LibreOfficeDev 26.8.0.0.alpha0 (2c87e51eeaa2b413ff4ae097b2705eea1995d8e5)
using a separate profile. It contains two ordinary rich-text paragraphs with
bold/italic runs, Arabic and supplementary Unicode. It contains no Zotero
fields and is not an installed Zotero-plugin fixture.

After empty office:scripts handling, the untouched converted ODT was explicitly
refused at fo:hyphenation-ladder-count. Other active native defaults are also
outside the reader envelope, including distinct complex-script size and Asian
font settings. This refusal is retained; no full native LibreOffice acceptance
or installed Word/Zotero/OpenOffice acceptance is claimed. The input bytes and
three relevant reader/style/preference sources were unchanged during that run.

The original DOCX, untouched ODT, extracted XML, converter version/commands,
probe program, raw refusal and hash records are included.
