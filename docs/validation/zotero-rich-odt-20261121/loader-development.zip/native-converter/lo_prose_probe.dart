import 'dart:convert';
import 'dart:io';

import 'package:quds_office_engine/quds_office_engine.dart';

Future<void> main(List<String> args) async {
  final directory = Directory('/workspace/scratch/1e8f5be6b406/runtime/lo-prose');
  directory.createSync(recursive: true);
  if (args.single == 'create') {
    final document = WmlDocument(sections: [
      WmlSection(blocks: [
        WmlParagraph(inlines: [
          WmlRun(text: 'Research '),
          WmlRun(text: 'bold', properties: WmlRunProps(bold: true)),
          WmlRun(text: ' and '),
          WmlRun(text: 'italic', properties: WmlRunProps(italic: true)),
          WmlRun(text: ' prose.'),
        ]),
        WmlParagraph(inlines: [WmlRun(text: 'Second paragraph العربية 😀.')]),
      ]),
    ]);
    File('${directory.path}/native-prose.docx').writeAsBytesSync(
      WordSerializer().writeBytes(document),
    );
    stdout.writeln(jsonEncode({'created': true, 'paragraphs': document.paragraphs.map((p) => p.text).toList()}));
    return;
  }
  final bytes = File('${directory.path}/native-prose.odt').readAsBytesSync();
  try {
    final document = await OdtDocumentReader.readBytes(bytes);
    final reopened = WordDeserializer().read(
      OpcPackage.openBytes(WordSerializer().writeBytes(document)),
    );
    stdout.writeln(jsonEncode({
      'success': true,
      'paragraphs': document.paragraphs.map((p) => p.text).toList(),
      'runs': [for (final p in document.paragraphs) [for (final r in p.inlines.whereType<WmlRun>()) {'text':r.text, 'bold':r.properties.bold, 'italic':r.properties.italic}]],
      'reopened': reopened.paragraphs.map((p) => p.text).toList(),
    }));
  } catch (error, stack) {
    stdout.writeln(jsonEncode({'success': false, 'error': error.toString(), 'type': error.runtimeType.toString(), 'stack': stack.toString()}));
    exitCode = 1;
  }
}
