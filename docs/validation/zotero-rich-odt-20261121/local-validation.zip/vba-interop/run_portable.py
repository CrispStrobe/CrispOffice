#!/usr/bin/env python3
"""Qualify the committed VBA example on Dart VM and compiled JavaScript."""
import base64
import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path('/workspace/scratch/1e8f5be6b406/quds_office_suite')
ENGINE = ROOT / 'packages/quds_office_engine'
OUT = pathlib.Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)
ENTRY = pathlib.Path('tool/macros/web_vba_word_language_controls_smoke.dart')
EXAMPLE = pathlib.Path('example/macros/word_language_controls.bas')
CONFIG = ROOT / '.dart_tool/package_config.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def manifest():
    files = sorted((ENGINE / 'lib').rglob('*.dart'))
    files += [ENGINE / ENTRY, ENGINE / EXAMPLE, CONFIG,
              ROOT / 'pubspec.yaml', ROOT / 'pubspec.lock', ENGINE / 'pubspec.yaml']
    return {str(path.relative_to(ROOT)): sha(path) for path in files}


def manifest_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


receipt = {
    'started_at_utc': now(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'cwd': str(ENGINE),
    'source_manifest_before': manifest(),
    'commands': [],
    'limitations': ['Compiled JavaScript runs in Node with the asynchronous dart2js self binding; no browser or installed Word host is claimed.'],
}
receipt['source_manifest_sha256'] = manifest_hash(receipt['source_manifest_before'])


def save():
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')


def run(label, command):
    started = time.monotonic()
    record = {'label': label, 'argv': command, 'started_at_utc': now()}
    receipt['commands'].append(record)
    save()
    stdout = OUT / (label + '.stdout')
    stderr = OUT / (label + '.stderr')
    with stdout.open('wb') as out, stderr.open('wb') as err:
        result = subprocess.run(command, cwd=ENGINE, stdout=out, stderr=err)
    record.update({'exit_code': result.returncode,
                   'elapsed_seconds': round(time.monotonic() - started, 3),
                   'stdout_file': stdout.name, 'stdout_sha256': sha(stdout),
                   'stderr_file': stderr.name, 'stderr_sha256': sha(stderr)})
    save()
    print(json.dumps({'stage': label, 'exit_code': result.returncode,
                      'elapsed_seconds': record['elapsed_seconds']}), flush=True)
    if result.returncode:
        raise RuntimeError(label + ' failed; see captured stdout/stderr')
    return stdout.read_text()


try:
    dart = shutil.which('dart')
    node = shutil.which('node')
    if not dart or not node:
        raise RuntimeError('Dart and Node must be available in PATH')
    receipt['dart_version'] = run('dart-version', [dart, '--version']).strip()
    receipt['node_version'] = run('node-version', [node, '--version']).strip()
    example_define = '-DWORD_LANGUAGE_CONTROLS_BAS_BASE64=' + base64.b64encode((ENGINE / EXAMPLE).read_bytes()).decode()
    vm_text = run('vm', [dart, '--enable-asserts', '--packages=' + str(CONFIG),
                         example_define, str(ENTRY)])
    javascript = OUT / 'word_language_controls.js'
    run('compile-js', [dart, 'compile', 'js', '-O2', '--packages=' + str(CONFIG),
                       example_define, '-o', str(javascript), str(ENTRY)])
    js_text = run('javascript', [node, '-e',
                                'globalThis.self = globalThis; require(process.argv[1]);',
                                str(javascript)])
    vm = json.loads(vm_text)
    js = json.loads(js_text)
    if vm != js:
        raise AssertionError('VM and JavaScript structured results differ')
    if not (vm['operations'] == 7 and vm['recordedSteps'] == 7 and
            vm['revision'] == 1 and vm['additionalReopens'] == 2 and
            vm['opaqueVbaPreserved'] is True and len(vm['nativePartSha256']) == 3):
        raise AssertionError('Unexpected portable smoke coverage')
    receipt['result'] = vm
    receipt['vm_javascript_structurally_identical'] = True
    receipt['compiled_javascript_sha256'] = sha(javascript)
    receipt['source_manifest_after'] = manifest()
    receipt['sources_unchanged_during_run'] = receipt['source_manifest_before'] == receipt['source_manifest_after']
    if not receipt['sources_unchanged_during_run']:
        raise AssertionError('Production source or smoke inputs changed during qualification')
    receipt['outcome'] = 'passed'
except Exception as error:
    receipt['outcome'] = 'failed'
    receipt['error'] = repr(error)
    raise
finally:
    receipt['completed_at_utc'] = now()
    save()

print(json.dumps({'outcome': receipt['outcome'], 'head': receipt['head'],
                  'source_manifest_sha256': receipt['source_manifest_sha256'],
                  'nativePartSha256': receipt['result']['nativePartSha256']}), flush=True)
