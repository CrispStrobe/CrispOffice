#!/usr/bin/env python3
"""Bind unchanged static inputs and qualify the sole changed final test."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/1e8f5be6b406')
REPO = ROOT / 'quds_office_suite'
BASE = ROOT / 'final-validation'
RUNTIME = ROOT / 'runtime'
HEAD = '4386cba498f5b4411dc7598bbc94c706005d04db'
PREVIOUS_HEAD = '77c4ef27008a1a2468b94c3b67423c43ac28438d'
CHANGED_TEST = 'packages/quds_office_engine/test/odt_reader_table_preservation_test.dart'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n')


def current_head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()


def loader_binding(label):
    original = json.loads((BASE / 'loader-final/inputs-after.json').read_text())
    live = {path: sha(REPO / path) if (REPO / path).is_file() else None for path in original}
    result = {
        'qualified_source_head': PREVIOUS_HEAD,
        'current_source_head': current_head(),
        'observed_at_utc': datetime.now(timezone.utc).isoformat(),
        'input_count': len(original),
        'qualified_manifest_sha256': sha(BASE / 'loader-final/inputs-after.json'),
        'changed': [path for path in original if original[path] != live[path]],
        'current_inputs': live,
        'tests_rerun': False,
        'scope': 'Byte identity binding only; final editor8 and Studio7 replay counts remain overlapping, not additive.',
    }
    result['accepted'] = not result['changed']
    write(BASE / ('loader-final-binding-' + label + '.json'), result)
    return result


assert current_head() == HEAD
previous = BASE / 'static'
preserved = BASE / 'static-at-77c4ef27'
assert previous.is_dir() and not preserved.exists()
old_result = json.loads((previous / 'result.json').read_text())
old_before = json.loads((previous / 'inputs-before.json').read_text())
old_after = json.loads((previous / 'inputs-after.json').read_text())
assert old_result['accepted'] is True and old_before == old_after
assert old_result['source_head'] == PREVIOUS_HEAD
paths = subprocess.check_output(
    ['git', 'diff', '--name-only', 'fcb212888', HEAD, '--', '*.dart'],
    cwd=REPO, text=True,
).splitlines()
assert len(paths) == 29 and set(paths) == set(old_after)
before = {path: sha(REPO / path) for path in paths}
changed = [path for path in paths if old_after[path] != before[path]]
assert changed == [CHANGED_TEST], changed
previous.rename(preserved)
previous.mkdir()
write(previous / 'paths.json', paths)
write(previous / 'inputs-before.json', before)
binding_before = loader_binding('4386-before')
assert binding_before['accepted']

environment = os.environ.copy()
environment.update({
    'PUB_CACHE': str(RUNTIME / 'pub-cache'),
    'TMPDIR': str(RUNTIME / 'tmp'),
    'XDG_CONFIG_HOME': str(RUNTIME / 'xdg-config'),
    'XDG_CACHE_HOME': str(RUNTIME / 'xdg-cache'),
    'BOT': 'true', 'CI': 'true', 'DASH__SUPPRESS_ANALYTICS': 'true',
    'FLUTTER_SUPPRESS_ANALYTICS': 'true',
})
result = {
    'source_head': HEAD,
    'started_at_utc': datetime.now(timezone.utc).isoformat(),
    'path_count': len(paths),
    'previous_source_head': PREVIOUS_HEAD,
    'previous_static_receipt': 'static-at-77c4ef27/result.json',
    'previous_static_receipt_sha256': sha(preserved / 'result.json'),
    'verified_unchanged_paths': [path for path in paths if path not in changed],
    'freshly_checked_paths': changed,
    'qualification_method': 'The previous accepted formatter/analyzer gate covered all29 paths. Twenty-eight inputs remain byte-identical. The sole changed test receives fresh strict formatting and analysis; all29 hashes are checked before/after.',
    'results': {},
}
dart = str(RUNTIME / 'flutter-sdk/bin/dart')
commands = {
    'format': [dart, 'format', '--output=none', '--set-exit-if-changed', CHANGED_TEST],
    'analyze': [dart, 'analyze', '--fatal-infos', CHANGED_TEST],
}
for name, command in commands.items():
    start = time.monotonic()
    with (previous / (name + '.stdout.log')).open('wb') as output, (previous / (name + '.stderr.log')).open('wb') as errors:
        process = subprocess.run(command, cwd=REPO, env=environment, stdout=output, stderr=errors)
    result['results'][name] = {
        'command': command, 'cwd': str(REPO), 'exit_code': process.returncode,
        'elapsed_seconds': time.monotonic() - start,
        'stdout_sha256': sha(previous / (name + '.stdout.log')),
        'stderr_sha256': sha(previous / (name + '.stderr.log')),
    }
    print(json.dumps({'check': name, 'exit_code': process.returncode}), flush=True)

after = {path: sha(REPO / path) for path in paths}
write(previous / 'inputs-after.json', after)
binding_after = loader_binding('4386-after')
result['inputs_changed'] = [path for path in paths if before[path] != after[path]]
result['loader_binding'] = {
    'input_count': binding_after['input_count'],
    'before_receipt': 'loader-final-binding-4386-before.json',
    'after_receipt': 'loader-final-binding-4386-after.json',
    'before_changed': binding_before['changed'], 'after_changed': binding_after['changed'],
    'tests_rerun': False,
}
result['source_head_after'] = current_head()
result['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
result['accepted'] = (all(check['exit_code'] == 0 for check in result['results'].values())
                      and not result['inputs_changed'] and binding_after['accepted']
                      and result['source_head_after'] == HEAD)
write(previous / 'result.json', result)
print(json.dumps({'accepted': result['accepted'], 'verified_unchanged': len(result['verified_unchanged_paths']),
                  'freshly_checked': changed, 'source_changes': result['inputs_changed'],
                  'loader_input_changes': binding_after['changed']}), flush=True)
raise SystemExit(0 if result['accepted'] else 1)
