# Local qualification evidence

The final engine receipt is engine-gate/summary.json.
The earlier successful test stream with a report-writer failure is preserved
under engine-receipt-diagnostic and is not added to final counts.
Static and formatter records retain their exact qualification scopes.
Portable VM/JavaScript and actual converter probes record their own source heads.
Use the repository validation README for support limits and source binding.
