import 'dart:convert';
import 'dart:io';

import 'package:analyzer/dart/analysis/utilities.dart';

void main(List<String> args) {
  final decoded = jsonDecode(File(args.single).readAsStringSync());
  if (decoded is! Map<String, Object?>) {
    throw const FormatException('Expected a source-path map.');
  }
  final snapshots = <String, Object?>{};
  for (final entry in decoded.entries) {
    final path = entry.value;
    if (path is! String) throw const FormatException('Invalid source path.');
    final parsed = parseString(content: File(path).readAsStringSync());
    final tokens = <Object?>[];
    var token = parsed.unit.beginToken;
    while (!token.isEof) {
      tokens.add(<String>[token.type.name, token.lexeme]);
      token = token.next!;
    }
    snapshots[entry.key] = tokens;
  }
  stdout.write(jsonEncode(snapshots));
}
