#!/usr/bin/env python3
"""Run frozen-source editor/Studio Zotero gates without GitHub Actions."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

import yaml

ROOT = Path('/workspace/scratch/1e8f5be6b406')
REPO = ROOT / 'quds_office_suite'
RUNTIME = ROOT / 'runtime'
HERE = ROOT / 'final-validation'
OUTPUT = HERE / 'editor-gate'


def write_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    # Some parser regressions deliberately include isolated UTF-16 surrogates
    # in test names. JSON escaping preserves them without an invalid UTF-8 file.
    path.write_text(json.dumps(data, indent=2, ensure_ascii=True) + '\n')


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def selections() -> dict[str, dict[str, object]]:
    editor = REPO / 'packages/quds_office_editor'
    files = sorted(p.relative_to(editor).as_posix()
                   for p in editor.glob('test/word_zotero_*_test.dart'))
    files += [
        'test/word_odt_load_test.dart',
        'test/word_content_control_fidelity_test.dart',
        'test/word_split_identity_test.dart',
        'test/word_tab_stops_editor_test.dart',
        'test/word_bookmark_copy_test.dart',
        'test/word_generated_bookmark_paste_test.dart',
        'test/word_bookmark_fidelity_test.dart',
        'test/word_notes_proofing_pane_test.dart',
        'test/word_protection_history_test.dart',
        'test/pending_edit_save_test.dart',
    ]
    studio = [
        'test/studio_odt_open_test.dart',
        'test/studio_file_menu_test.dart',
        'test/studio_zotero_citing_transport_test.dart',
        'test/studio_zotero_shortcuts_test.dart',
    ]
    cohorts = {
        'editor': {'cwd': str(editor), 'tests': sorted(set(files)), 'concurrency': 4},
        'studio': {'cwd': str(editor / 'example'), 'tests': studio, 'concurrency': 2},
    }
    for cohort in cohorts.values():
        for path in cohort['tests']:
            if not (Path(cohort['cwd']) / path).is_file():
                raise RuntimeError(f'Missing selected test: {path}')
    return cohorts


def input_paths(cohorts: dict[str, dict[str, object]]) -> list[Path]:
    paths = set(REPO.glob('packages/*/lib/**/*.dart'))
    paths.update(REPO.glob('packages/quds_office_editor/example/lib/**/*.dart'))
    paths.update(REPO.glob('third_party/*/lib/**/*.dart'))
    manifests = yaml.safe_load((REPO / 'pubspec.yaml').read_text())
    for member in [''] + manifests['workspace'] + ['third_party/enough_mail']:
        for name in ['pubspec.yaml', 'pubspec.lock', 'pubspec_overrides.yaml',
                     'analysis_options.yaml', 'dart_test.yaml']:
            path = REPO / member / name
            if path.is_file():
                paths.add(path)
    paths.add(REPO / '.fvmrc')
    paths.add(REPO / '.dart_tool/package_config.json')
    for base in ['packages/quds_office_editor/test/support',
                 'packages/quds_office_editor/example/test/support',
                 'packages/quds_office_editor/fonts',
                 'packages/quds_office_editor/example/fonts']:
        folder = REPO / base
        if folder.is_dir():
            paths.update(p for p in folder.rglob('*') if p.is_file())
    tests = {Path(cohort['cwd']) / test
             for cohort in cohorts.values() for test in cohort['tests']}
    pending = list(tests)
    while pending:
        current = pending.pop()
        if current in paths:
            continue
        paths.add(current)
        if current.suffix != '.dart':
            continue
        for imported in re.findall(r"(?:import|export|part)\s+['\"]([^'\"]+)['\"]", current.read_text()):
            if ':' in imported:
                continue
            target = (current.parent / imported).resolve()
            if target.is_file() and target.is_relative_to(REPO) and target not in paths:
                pending.append(target)
    for folder in [REPO / 'packages/quds_office_editor/test',
                   REPO / 'packages/quds_office_editor/example/test']:
        config = folder / 'flutter_test_config.dart'
        if config.is_file():
            paths.add(config)
    return sorted(paths)


def snapshot(cohorts: dict[str, dict[str, object]]) -> dict[str, str]:
    return {path.relative_to(REPO).as_posix(): sha(path)
            for path in input_paths(cohorts)}


def result_details(path: Path) -> dict[str, object]:
    events = []
    non_json = []
    for index, line in enumerate(path.read_text().splitlines(), 1):
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            if line.strip():
                non_json.append({'line': index, 'text': line})
            continue
        events.append(event)
    suites = {e['suite']['id']: e['suite'] for e in events if e.get('type') == 'suite'}
    tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    prints = defaultdict(list)
    for event in events:
        if event.get('type') == 'print':
            prints[event.get('testID')].append(event.get('message', ''))
    counts = Counter()
    by_suite = defaultdict(Counter)
    cases = []
    for event in events:
        if event.get('type') != 'testDone' or event.get('hidden', False):
            continue
        test = tests[event['testID']]
        result = 'skipped' if event.get('skipped', False) else event['result']
        suite_path = suites.get(test.get('suiteID'), {}).get('path', 'unknown')
        try:
            suite_path = Path(suite_path).relative_to(REPO).as_posix()
        except ValueError:
            pass
        counts[result] += 1
        by_suite[suite_path][result] += 1
        case = {'name': test['name'], 'suite': suite_path, 'result': result,
                'test_id': event['testID']}
        if result != 'success':
            case['messages'] = prints[event['testID']]
            case['metadata'] = test.get('metadata', {})
        cases.append(case)
    done = [event for event in events if event.get('type') == 'done']
    errors = [event for event in events if event.get('type') == 'error']
    return {'counts': dict(counts), 'by_suite': {p: dict(c) for p, c in by_suite.items()},
            'cases': cases, 'done': done, 'errors': errors, 'non_json_lines': non_json,
            'skips': [case for case in cases if case['result'] == 'skipped'],
            'failures': [case for case in cases if case['result'] not in ['success', 'skipped']]}


def run(cohorts: dict[str, dict[str, object]], expected_head: str) -> None:
    observed_head = git('rev-parse', 'HEAD')
    if observed_head != expected_head:
        raise RuntimeError(f'Starting HEAD changed: expected {expected_head}, saw {observed_head}')
    OUTPUT.mkdir(parents=True, exist_ok=True)
    if (OUTPUT / 'summary.json').exists():
        raise RuntimeError('Final gate receipt already exists; preserve it before another run.')
    environment = os.environ.copy()
    scoped = {
        'PATH': str(RUNTIME / 'flutter-sdk/bin') + os.pathsep + environment['PATH'],
        'PUB_CACHE': str(RUNTIME / 'pub-cache'),
        'TMPDIR': str(RUNTIME / 'tmp'),
        'XDG_CONFIG_HOME': str(RUNTIME / 'xdg-config'),
        'XDG_CACHE_HOME': str(RUNTIME / 'xdg-cache'),
        'BOT': 'true', 'CI': 'true', 'DASH__SUPPRESS_ANALYTICS': 'true',
        'FLUTTER_SUPPRESS_ANALYTICS': 'true',
    }
    environment.update(scoped)
    before = snapshot(cohorts)
    write_json(OUTPUT / 'inputs-before.json', before)
    sdk_paths = ['bin/cache/dart-sdk/bin/dart',
                 'bin/cache/artifacts/engine/linux-x64/flutter_tester',
                 'bin/cache/flutter_tools.snapshot', 'packages/flutter_tools/pubspec.lock']
    runtime_before = {path: sha(RUNTIME / 'flutter-sdk' / path) for path in sdk_paths}
    write_json(OUTPUT / 'runtime-before.json', runtime_before)
    summary = {'started_at_utc': datetime.now(timezone.utc).isoformat(),
               'source_head_at_start': observed_head, 'source_tree_at_start': git('rev-parse', 'HEAD^{tree}'),
               'scoped_environment': {k: v for k, v in scoped.items() if k != 'PATH'},
               'runtime': {'flutter': '3.47.8', 'dart': '3.13.7'}, 'cohorts': {},
               'input_count': len(before), 'github_actions_queried': False, 'github_actions_awaited': False,
               'counting_note': 'One final process per cohort. Development repeats are excluded; tests overlap prior scoped loader runs.'}
    for label, cohort in cohorts.items():
        directory = OUTPUT / label
        directory.mkdir(parents=True, exist_ok=True)
        command = [str(RUNTIME / 'flutter-sdk/bin/flutter'), '--no-version-check',
                   'test', '--no-pub', '--reporter=json',
                   '--concurrency=' + str(cohort['concurrency']), *cohort['tests']]
        spec = {'command': command, 'cwd': cohort['cwd'], 'test_files': cohort['tests']}
        write_json(directory / 'command.json', spec)
        print(json.dumps({'starting': label, 'test_files': len(cohort['tests']), 'inputs': len(before)}), flush=True)
        started = time.monotonic()
        with (directory / 'events.jsonl').open('w') as output, (directory / 'stderr.log').open('w') as errors:
            process = subprocess.run(command, cwd=cohort['cwd'], env=environment, stdout=output, stderr=errors)
        result = result_details(directory / 'events.jsonl')
        result.update({'exit_code': process.returncode, 'elapsed_seconds': time.monotonic() - started,
                       'events_sha256': sha(directory / 'events.jsonl'), 'stderr_sha256': sha(directory / 'stderr.log')})
        write_json(directory / 'result.json', result)
        summary['cohorts'][label] = {key: value for key, value in result.items() if key != 'cases'}
        print(json.dumps({'finished': label, 'exit_code': process.returncode, 'counts': result['counts'],
                          'errors': len(result['errors']), 'skips': len(result['skips'])}), flush=True)
        if process.returncode != 0 or result['errors'] or not result['done'] or not all(e.get('success') for e in result['done']):
            summary['stopped_after_failure'] = label
            break
    after = snapshot(cohorts)
    write_json(OUTPUT / 'inputs-after.json', after)
    runtime_after = {path: sha(RUNTIME / 'flutter-sdk' / path) for path in sdk_paths}
    write_json(OUTPUT / 'runtime-after.json', runtime_after)
    summary.update({'finished_at_utc': datetime.now(timezone.utc).isoformat(),
                    'source_head_at_end': git('rev-parse', 'HEAD'),
                    'inputs_changed': [p for p in sorted(set(before) | set(after)) if before.get(p) != after.get(p)],
                    'runtime_changed': [p for p in sdk_paths if runtime_before[p] != runtime_after[p]],
                    'input_manifest_sha256': {'before': sha(OUTPUT / 'inputs-before.json'), 'after': sha(OUTPUT / 'inputs-after.json')}})
    summary['accepted'] = (len(summary['cohorts']) == len(cohorts)
                           and not summary.get('stopped_after_failure')
                           and not summary['inputs_changed'] and not summary['runtime_changed'])
    write_json(OUTPUT / 'summary.json', summary)
    print(json.dumps({'accepted': summary['accepted'], 'source_changes': summary['inputs_changed'],
                      'runtime_changes': summary['runtime_changed'], 'summary': str(OUTPUT / 'summary.json')}), flush=True)
    if not summary['accepted']:
        sys.exit(1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--expected-head')
    args = parser.parse_args()
    cohorts = selections()
    write_json(HERE / 'editor-plan.json', {'cohorts': cohorts,
                                         'anticipated_input_count': len(input_paths(cohorts)),
                                         'execution_requires_parent_source_freeze': True})
    if args.run:
        if not args.expected_head:
            parser.error('--run requires --expected-head from the frozen source')
        run(cohorts, args.expected_head)
    else:
        print(json.dumps({'prepared_only': True, 'cohort_files': {label: len(cohort['tests']) for label, cohort in cohorts.items()},
                          'anticipated_input_count': len(input_paths(cohorts))}, indent=2))


if __name__ == '__main__':
    main()
