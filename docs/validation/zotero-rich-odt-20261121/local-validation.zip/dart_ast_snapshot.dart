import 'dart:convert';
import 'dart:io';

import 'package:analyzer/dart/analysis/utilities.dart';

void main(List<String> args) {
  final snapshots = <String, Object?>{};
  for (final manifest in args) {
    final paths = jsonDecode(File(manifest).readAsStringSync());
    if (paths is! Map<String, Object?>) {
      throw const FormatException('Expected a source-path map.');
    }
    snapshots[manifest] = <String, String>{
      for (final entry in paths.entries)
        entry.key: parseString(
          content: File(entry.value! as String).readAsStringSync(),
        ).unit.toSource(),
    };
  }
  stdout.write(jsonEncode(snapshots));
}
