#!/usr/bin/env python3
"""Package completed local qualification without changing qualified sources."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/1e8f5be6b406')
HERE = ROOT / 'final-validation'
REPO = ROOT / 'quds_office_suite'
DEST = REPO / 'docs/validation/zotero-rich-odt-20261121'
HEAD = '4386cba498f5b4411dc7598bbc94c706005d04db'


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    observed = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    assert observed == HEAD, observed
    engine = read(HERE / 'engine-gate/summary.json')
    editor = read(DEST / 'editor-results.json')
    loader = read(DEST / 'loader-final-results.json')
    static = read(HERE / 'static/result.json')
    formatter = read(HERE / 'format-equivalence/result.json')
    portable = read(HERE / 'vba-interop/receipt.json')
    binding = read(HERE / 'loader-final-binding-4386-after.json')
    assert engine['accepted'] and engine['exit_code'] == 0
    assert editor['accepted'] and loader['accepted'] and static['accepted']
    assert formatter['equivalent'] and portable['outcome'] == 'passed' and binding['accepted']
    engine_inputs = read(HERE / 'engine-gate/inputs-after.json')
    current = {p: sha(REPO / p) for p in engine_inputs}
    changes = [p for p in engine_inputs if current[p] != engine_inputs[p]]
    assert not changes, changes
    source_binding = {
        'observed_at_utc': datetime.now(timezone.utc).isoformat(),
        'qualified_source_head': HEAD,
        'qualified_source_tree': engine['source_tree_at_start'],
        'publication_source_head': observed,
        'input_count': len(current), 'changed': changes, 'current_inputs': current,
        'engine_manifest_sha256': sha(HERE / 'engine-gate/inputs-after.json'),
        'focused_loader_binding': 'local-validation.zip/loader-final-binding-4386-after.json',
        'static_binding': 'local-validation.zip/static/result.json',
        'broad_editor_binding': 'editor-results.json',
        'production_identical_to': '77c4ef27008a1a2468b94c3b67423c43ac28438d',
        'accepted': True,
    }
    prod_delta = subprocess.check_output([
        'git', 'diff', '--name-only', '77c4ef27008a1a2468b94c3b67423c43ac28438d', 'HEAD',
        '--', 'packages/*/lib/**/*.dart', 'packages/quds_office_editor/example/lib/**/*.dart',
    ], cwd=REPO, text=True).strip()
    assert not prod_delta, prod_delta
    write(DEST / 'source-binding.json', source_binding)
    shutil.copyfile(ROOT / 'publication-frontier.json', DEST / 'publication-frontier.json')
    shutil.copyfile(HERE / 'engine-gate/summary.json', DEST / 'engine-results.json')
    shutil.copyfile(HERE / 'static/result.json', DEST / 'static-results.json')

    folders = [
        'engine-gate', 'engine-receipt-diagnostic', 'static', 'static-at-77c4ef27',
        'static-before-format', 'format-equivalence', 'vba-interop', 'converter-probe',
    ]
    files = set()
    for name in folders:
        files.update(p for p in (HERE / name).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    for name in [
        'run_engine_gate.py', 'run_editor_gate.py', 'run_loader_final.py',
        'run_static_at_4386.py', 'dart_token_snapshot.dart', 'dart_ast_snapshot.dart',
        'loader-final-binding-4386-before.json', 'loader-final-binding-4386-after.json',
        'package_evidence.py', 'validation_readme.template.md',
    ]:
        files.add(HERE / name)
    member_hashes = {p.relative_to(HERE).as_posix(): sha(p) for p in sorted(files)}
    archive = DEST / 'local-validation.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(files):
            z.write(path, path.relative_to(HERE).as_posix())
        z.writestr('MANIFEST.json', json.dumps({'sha256': member_hashes}, indent=2) + '\n')
        z.writestr('README.md',
            '# Local qualification evidence\n\n'
            'The final engine receipt is engine-gate/summary.json.\n'
            'The earlier successful test stream with a report-writer failure is preserved\n'
            'under engine-receipt-diagnostic and is not added to final counts.\n'
            'Static and formatter records retain their exact qualification scopes.\n'
            'Portable VM/JavaScript and actual converter probes record their own source heads.\n'
            'Use the repository validation README for support limits and source binding.\n')
    archives = {}
    for path in sorted(DEST.glob('*.zip')):
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None, path
            contents = {name: hashlib.sha256(z.read(name)).hexdigest() for name in z.namelist()}
            if path == archive:
                assert all(contents[name] == value for name, value in member_hashes.items())
        archives[path.name] = {'bytes': path.stat().st_size, 'sha256': sha(path),
                               'member_count': len(contents), 'member_sha256': contents,
                               'crc_verified': True}
    write(DEST / 'evidence-sha256.json', {'archives': archives})
    results = {
        'qualified_source_head': HEAD, 'qualified_source_tree': engine['source_tree_at_start'],
        'engine': {'files': engine['test_file_count'], 'counts': engine['counts'],
                   'exit_code': engine['exit_code'], 'inputs': engine['input_count'],
                   'source_unchanged': not engine['inputs_changed'], 'accepted': engine['accepted']},
        'editor': {'files': 60, 'counts': editor['cohorts']['editor']['counts']},
        'studio': {'files': 4, 'counts': editor['cohorts']['studio']['counts']},
        'focused_loader_replay': {'editor': loader['cohorts']['editor']['counts'],
                                  'studio': loader['cohorts']['studio']['counts'],
                                  'add_to_totals': False, 'accepted': loader['accepted']},
        'static': {'paths': static['path_count'], 'accepted': static['accepted']},
        'portable_vba': {'outcome': portable['outcome'], 'source_head': portable['head'],
                         'vm_js_agreement': portable['vm_javascript_structurally_identical']},
        'actual_native_converter': {'result': 'refused at active fo:hyphenation-ladder-count',
                                    'general_host_acceptance': False,
                                    'receipt': 'local-validation.zip/converter-probe/result.json'},
        'counting': 'Use one final process per cohort. Earlier development/diagnostic runs and focused loader replays overlap and are not additive.',
        'github_actions_queried': False, 'github_actions_awaited': False,
        'archives': {name: {key: value for key, value in item.items() if key != 'member_sha256'}
                     for name, item in archives.items()},
    }
    write(DEST / 'results.json', results)
    template = (HERE / 'validation_readme.template.md').read_text()
    assert '@ENGINE_COUNT@' in template
    (DEST / 'README.md').write_text(template.replace('@ENGINE_COUNT@', f"{engine['counts']['success']:,}"))
    print(json.dumps({'engine': results['engine'], 'archives': results['archives'],
                      'source_bound': not changes, 'deliverable': str(DEST)}))


if __name__ == '__main__':
    main()
