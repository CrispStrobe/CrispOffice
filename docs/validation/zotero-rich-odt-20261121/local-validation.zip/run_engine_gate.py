#!/usr/bin/env python3
"""Qualify the combined native ODT/Zotero/Word source with the locked Dart runner."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import subprocess
import time

import run_editor_gate as common


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    repo, runtime = common.REPO, common.RUNTIME
    output = common.HERE / 'engine-gate'
    if (output / 'summary.json').exists():
        raise RuntimeError('Preserve an existing receipt before another run.')
    observed = common.git('rev-parse', 'HEAD')
    if observed != args.expected_head:
        raise RuntimeError(f'Source head changed: {observed}')
    cwd = repo / 'packages/quds_office_engine'
    tests = {p.relative_to(cwd).as_posix() for p in (cwd / 'test').glob('*_test.dart')
             if 'zotero' in p.name or p.name.startswith(('odf_', 'odt_', 'note_', 'word_note_'))}
    tests.update('test/' + name for name in [
        'office_isolate_open_test.dart', 'office_isolate_save_test.dart',
        'word_footnote_reference_test.dart', 'rich_note_test.dart',
        'style_cascade_test.dart', 'word_proofing_language_test.dart',
        'word_proofing_inheritance_test.dart', 'word_small_caps_test.dart',
        'word_package_preservation_test.dart',
        'office_vba_word_language_controls_test.dart',
        'office_macro_word_language_controls_test.dart',
        'office_vba_word_language_controls_integration_test.dart',
        'odt_vba_language_roundtrip_test.dart',
    ])
    tests = sorted(tests)
    assert all((cwd / test).is_file() for test in tests)
    cohorts = {'engine': {'cwd': str(cwd), 'tests': tests}}

    def snapshot() -> dict[str, str]:
        paths = set(common.input_paths(cohorts))
        paths.update(p for p in (cwd / 'test/fixtures').rglob('*') if p.is_file())
        paths.update(p for p in (cwd / 'test/support').rglob('*') if p.is_file())
        return {p.relative_to(repo).as_posix(): common.sha(p) for p in sorted(paths)}

    output.mkdir(parents=True, exist_ok=True)
    before = snapshot()
    common.write_json(output / 'inputs-before.json', before)
    sdk_paths = ['bin/cache/dart-sdk/bin/dart', 'bin/cache/dart-sdk/bin/dartaotruntime']
    runtime_before = {p: common.sha(runtime / 'flutter-sdk' / p) for p in sdk_paths}
    common.write_json(output / 'runtime-before.json', runtime_before)
    env = os.environ.copy()
    env.update({'PATH': str(runtime / 'flutter-sdk/bin') + os.pathsep + env['PATH'],
                'PUB_CACHE': str(runtime / 'pub-cache'),
                'TMPDIR': str(runtime / 'tmp'),
                'XDG_CONFIG_HOME': str(runtime / 'xdg-config'),
                'XDG_CACHE_HOME': str(runtime / 'xdg-cache'),
                'CI': 'true', 'BOT': 'true',
                'DASH__SUPPRESS_ANALYTICS': 'true', 'FLUTTER_SUPPRESS_ANALYTICS': 'true'})
    command = [str(runtime / 'flutter-sdk/bin/dart'), '--enable-asserts',
               '--packages=' + str(repo / '.dart_tool/package_config.json'),
               str(runtime / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),
               '--reporter=json', '--concurrency=4', *tests]
    spec = {'command': command, 'cwd': str(cwd), 'test_files': tests}
    common.write_json(output / 'command.json', spec)
    started_at = datetime.now(timezone.utc).isoformat()
    print({'starting': 'engine', 'test_files': len(tests), 'inputs': len(before)}, flush=True)
    start = time.monotonic()
    with (output / 'events.jsonl').open('w') as stdout, (output / 'stderr.log').open('w') as stderr:
        process = subprocess.run(command, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
    elapsed = time.monotonic() - start
    common.write_json(output / 'process.json', {
        'exit_code': process.returncode,
        'elapsed_seconds': elapsed,
        'finished_at_utc': datetime.now(timezone.utc).isoformat(),
    })
    result = common.result_details(output / 'events.jsonl')
    common.write_json(output / 'result.json', result)
    after = snapshot()
    common.write_json(output / 'inputs-after.json', after)
    runtime_after = {p: common.sha(runtime / 'flutter-sdk' / p) for p in sdk_paths}
    common.write_json(output / 'runtime-after.json', runtime_after)
    changes = [p for p in sorted(set(before) | set(after)) if before.get(p) != after.get(p)]
    runtime_changes = [p for p in sdk_paths if runtime_before[p] != runtime_after[p]]
    accepted = (process.returncode == 0 and not result['errors'] and bool(result['done'])
                and all(e.get('success') for e in result['done']) and not changes and not runtime_changes)
    summary = {k: v for k, v in result.items() if k != 'cases'}
    summary.update({'accepted': accepted, 'exit_code': process.returncode,
                    'source_head_at_start': observed, 'source_head_at_end': common.git('rev-parse', 'HEAD'),
                    'source_tree_at_start': common.git('rev-parse', observed + '^{tree}'),
                    'started_at_utc': started_at, 'finished_at_utc': datetime.now(timezone.utc).isoformat(),
                    'elapsed_seconds': elapsed, 'test_file_count': len(tests), 'input_count': len(before),
                    'inputs_changed': changes, 'runtime_changed': runtime_changes,
                    'runtime': {'flutter': '3.47.8', 'dart': '3.13.7'},
                    'events_sha256': common.sha(output / 'events.jsonl'),
                    'input_manifest_sha256': {'before': common.sha(output / 'inputs-before.json'),
                                              'after': common.sha(output / 'inputs-after.json')},
                    'github_actions_queried': False, 'github_actions_awaited': False,
                    'counting_note': 'One final engine process. Development and overlapping scoped counts are excluded.'})
    common.write_json(output / 'summary.json', summary)
    print({'accepted': accepted, 'counts': result['counts'], 'errors': len(result['errors']),
           'skips': len(result['skips']), 'source_changes': changes}, flush=True)
    raise SystemExit(0 if accepted else 1)


if __name__ == '__main__':
    main()
