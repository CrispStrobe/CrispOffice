#!/usr/bin/env python3
"""Focused final-source replay after the incoming duplicate-style guard."""
import argparse
import json

import run_editor_gate as gate


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--expected-head')
    args = parser.parse_args()
    editor = gate.REPO / 'packages/quds_office_editor'
    cohorts = {
        'editor': {
            'cwd': str(editor),
            'tests': ['test/word_odt_load_test.dart'],
            'concurrency': 1,
        },
        'studio': {
            'cwd': str(editor / 'example'),
            'tests': ['test/studio_odt_open_test.dart', 'test/studio_file_menu_test.dart'],
            'concurrency': 2,
        },
    }
    gate.write_json(gate.HERE / 'loader-final-plan.json', {
        'cohorts': cohorts,
        'anticipated_input_count': len(gate.input_paths(cohorts)),
        'scope': 'Focused final-source replay after the duplicate-used-property-container refusal guard. These tests overlap the accepted 1043 editor and 40 Studio aggregate cases; do not add counts.',
        'execution_requires_parent_source_freeze': True,
    })
    if not args.run:
        print(json.dumps({'prepared_only': True,
                          'cohort_files': {label: len(spec['tests']) for label, spec in cohorts.items()},
                          'anticipated_input_count': len(gate.input_paths(cohorts))}, indent=2))
        return
    if not args.expected_head:
        parser.error('--run requires --expected-head from the final frozen source')
    gate.OUTPUT = gate.HERE / 'loader-final'
    try:
        gate.run(cohorts, args.expected_head)
    finally:
        receipt = gate.OUTPUT / 'summary.json'
        if receipt.exists():
            result = json.loads(receipt.read_text())
            result['scope'] = 'Focused final-source ODT loader/editor/Studio replay after incoming duplicate-used-property-container refusal and token-equivalent formatting.'
            result['counting_note'] = 'These cases are already included in the accepted 1043 editor and 40 Studio aggregate cases. This replay is separate evidence, never an additive coverage count.'
            gate.write_json(receipt, result)


if __name__ == '__main__':
    main()
