# Focused final-source loader replay

Source: 77c4ef27008a1a2468b94c3b67423c43ac28438d.

The one-file editor replay passed all eight native ODT controller cases.
The two-file Studio replay passed all seven ODT open/save and File-menu cases.
Both processes exited zero with no failures, errors or skips. All three
selected files executed. All 1,062 captured production/dependency/test inputs
and four runtime identities remained unchanged before/after. Exact commands,
raw JSON events, stderr, per-case results, and full manifests are retained.

This focused replay follows the incoming duplicate used style-property
container guard and formatter normalization. It verifies the final loading,
publication, and source-file protection pipeline. Dedicated engine tests
qualify the guard's duplicate-refusal cases separately.

These eight and seven cases were already included in the earlier accepted
1,043 editor and 40 Studio aggregate counts. They are overlapping replay
evidence and must not be added to the aggregate coverage total. No GitHub
Actions were queried or awaited.
