import 'dart:convert';

import 'package:quds_office_engine/quds_office_automation.dart';

void main() {
  const bodies = <String, String>{
    'null-concatenation-then-arithmetic':
        'Worksheets(1).Range("A1").Value2 = IsNull((Null & Null) + 1)',
    'null-concatenation-then-not':
        'Worksheets(1).Range("A1").Value2 = IsNull(Not (Null & Null))',
    'null-arithmetic-then-logical':
        'Worksheets(1).Range("A1").Value2 = IsNull((Null + 1) And True)',
    'null-comparison-then-arithmetic':
        'Worksheets(1).Range("A1").Value2 = IsNull((Null = Null) + 1)',
    'null-arithmetic-then-string-comparison':
        'Worksheets(1).Range("A1").Value2 = IsNull((Null + 1) = "x")',
    'same-null-concatenation-via-variant':
        'Dim value As Variant\nvalue = Null & Null\n'
        'Worksheets(1).Range("A1").Value2 = IsNull(value + 1)',
    'same-null-arithmetic-via-variant':
        'Dim value As Variant\nvalue = Null + 1\n'
        'Worksheets(1).Range("A1").Value2 = IsNull(value And True)',
    'unused-state-set-to-object':
        'Dim value As Range\nIf False Then\nSet value = Empty\nEnd If',
  };
  for (final entry in bodies.entries) {
    final source = 'Sub Main()\n${entry.value}\nEnd Sub\n';
    try {
      final result = const OfficeVbaMacroLanguage().compile(
        OfficeMacroSource(
          language: 'vba-excel',
          format: OfficeMacroFormat.xlsx,
          source: source,
          moduleName: 'Review',
        ),
      );
      print(jsonEncode(<String, Object?>{
        'id': entry.key,
        'source': source,
        'steps': [for (final step in result.steps) step.toJson()],
      }));
    } on OfficeVbaCompileException catch (error) {
      print(jsonEncode(<String, Object?>{
        'id': entry.key,
        'source': source,
        'diagnostic': error.toJson(),
      }));
    }
  }
}
