"""Author the Variant corpus from explicit contract expectations.

No compiler is imported or executed. Values and refusals are independently
specified here; diagnostic markers identify the intended source token.
"""

import json
from pathlib import Path

ROOT = Path('/workspace/scratch/bfb797b611e2/quds_office_suite')
FIXTURE = ROOT / 'packages/quds_office_engine/test/fixtures/vba_conformance/variant_conversions_v1.json'
REF = 'https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/'
DOC = 'https://github.com/CrispStrobe/quds_office_suite/blob/main/docs/VBA_MACROS.md'
CONVERT = 'https://learn.microsoft.com/en-us/office/vba/language/concepts/getting-started/type-conversion-functions'
EMPTY = 'https://learn.microsoft.com/en-us/openspecs/microsoft_general_purpose_programming_languages/ms-vbal/e2637723-3010-449d-bead-9f17533dc105'
CASES = []


def module(body, extra=''):
    return 'Sub Main()\n' + body.rstrip() + '\nEnd Sub\n' + extra


def write(expr, cell='A1'):
    return f'  Worksheets(1).Range("{cell}").Value2 = {expr}'


def writes(exprs):
    return '\n'.join(write(expr, f'A{i}') for i, expr in enumerate(exprs, 1))


def step(value, cell='A1'):
    return {'tool': 'xlsx.cellValue', 'arguments': {'sheet': 0, 'cell': cell, 'value': value}}


def steps(values):
    return [step(value, f'A{i}') for i, value in enumerate(values, 1)]


def provenance(kind, refs, note):
    return {'kind': kind, 'references': refs, 'note': note}


def add(case_id, feature, source, expected, refs=None, note=None, dialect=False):
    kind = 'dialect-contract' if dialect else 'spec-derived'
    if refs is None:
        refs = [DOC] if dialect else [REF + 'variant-data-type']
    if note is None:
        note = ('Bounded dialect behavior; no Office host was executed.' if dialect else
                'Specification-derived expectation; no Office host was executed.')
    CASES.append({'id': case_id, 'feature': feature, 'source': source,
                  'expected': expected, 'provenance': provenance(kind, refs, note)})


def ok(case_id, feature, exprs, values, *, before='', extra='', refs=None, note=None, dialect=False):
    add(case_id, feature, module(before + writes(exprs), extra), {'steps': steps(values)},
        refs=refs, note=note, dialect=dialect)


def bad(case_id, feature, source, code='vba_type_error', *, refs=None, note=None):
    assert source.count('«') == 1, case_id
    prefix, suffix = source.split('«')
    line = prefix.count('\n') + 1
    column = len(prefix.rsplit('\n', 1)[-1].encode('utf-16-le')) // 2 + 1
    add(case_id, feature, prefix + suffix,
        {'diagnostic': {'code': code, 'line': line, 'column': column}},
        refs=refs, note=note, dialect=True)


ok('state-defaults-and-predicates', 'Variant defaults',
   ['IsEmpty(value)', 'IsNull(value)', 'IsEmpty(omitted)', 'IsEmpty(Empty)',
    'IsNull(Null)', 'IsEmpty(Null)', 'IsNull(Empty)', 'IsEmpty("")',
    'IsNull("")', 'IsEmpty(0)', 'IsNull(0)', 'IsEmpty(False)', 'IsNull(True)'],
   [True, False, True, True, True, False, False, False, False, False, False, False, False],
   before='  Dim value As Variant, omitted\n',
   refs=[REF + 'variant-data-type', REF + 'isempty-function', REF + 'isnull-function'])

add('state-assignment-reset', 'Variant assignment', module('''  Dim value As Variant
  value = Null
  Worksheets(1).Range("A1").Value2 = IsNull(value)
  value = ""
  Worksheets(1).Range("A2").Value2 = IsEmpty(value)
  value = 0
  Worksheets(1).Range("A3").Value2 = IsEmpty(value)
  value = False
  Worksheets(1).Range("A4").Value2 = IsNull(value)
  value = Empty
  Worksheets(1).Range("A5").Value2 = IsEmpty(value)'''),
    {'steps': steps([True, False, False, False, True])},
    refs=[REF + 'variant-data-type', REF + 'isempty-function', REF + 'isnull-function'])

ok('state-case-insensitive', 'Variant literals and intrinsic names',
   ['iSeMpTy(eMpTy)', 'iSnUlL(nUlL)', 'cBoOl("tRuE")', 'cDlBlValue(EmPtY)'],
   [True, True, True, 0],
   extra='Function cDlBlValue(ByVal value As Variant) As Double\n  cDlBlValue = cDbL(value)\nEnd Function\n',
   dialect=True)

ok('implicit-variant-starts-empty', 'Implicit Variant defaults', ['IsEmpty(value)'], [True],
   before='  If False Then\n    value = 8\n  End If\n', dialect=True,
   note='The dialect predeclares an implicit scalar assignment target; its initial value is Empty even when that assignment is inactive.')

ok('fixed-variant-slots-start-empty', 'Fixed Variant arrays',
   ['IsEmpty(data(-1))', 'IsEmpty(data(0))', 'IsEmpty(data(1))'],
   [True, True, True], before='  Dim data(-1 To 1) As Variant\n',
   refs=[REF + 'redim-statement', REF + 'variant-data-type'])

add('fixed-erase-restores-empty', 'Fixed Variant arrays', module('''  Dim data(1 To 2) As Variant
  data(1) = Null
  data(2) = "retired"
  Erase data
  Worksheets(1).Range("A1").Value2 = IsEmpty(data(1))
  Worksheets(1).Range("A2").Value2 = IsEmpty(data(2))
  Worksheets(1).Range("A3").Value2 = LBound(data)
  Worksheets(1).Range("A4").Value2 = UBound(data)'''),
    {'steps': steps([True, True, 1, 2])}, refs=[REF + 'erase-statement'])

add('dynamic-preserve-and-reset-states', 'Dynamic Variant arrays', module('''  Dim data() As Variant
  ReDim data(1 To 2)
  Worksheets(1).Range("A1").Value2 = IsEmpty(data(1))
  data(1) = Null
  data(2) = 7
  ReDim Preserve data(1 To 3)
  Worksheets(1).Range("A2").Value2 = IsNull(data(1))
  Worksheets(1).Range("A3").Value2 = data(2)
  Worksheets(1).Range("A4").Value2 = IsEmpty(data(3))
  data(3) = "discard"
  ReDim Preserve data(1 To 1)
  ReDim Preserve data(1 To 3)
  Worksheets(1).Range("A5").Value2 = IsNull(data(1))
  Worksheets(1).Range("A6").Value2 = IsEmpty(data(2))
  Worksheets(1).Range("A7").Value2 = IsEmpty(data(3))
  ReDim data(-1 To 0)
  Worksheets(1).Range("A8").Value2 = IsEmpty(data(-1))
  Erase data
  ReDim data(0)
  Worksheets(1).Range("A9").Value2 = IsEmpty(data(0))'''),
    {'steps': steps([True, True, 7, True, True, True, True, True, True])},
    refs=[REF + 'redim-statement', REF + 'erase-statement'])

bad('dynamic-erased-is-not-empty-slot', 'Dynamic Variant arrays', module('''  Dim data() As Variant
  ReDim data(0)
  Erase data
  Worksheets(1).Range("A1").Value2 = IsEmpty(data(«0))'''),
    'vba_subscript_out_of_range',
    note='Dynamic Erase releases storage; IsEmpty does not hide an unallocated-array error.')

add('foreach-visits-empty-and-null', 'For Each Variant states', module('''  Dim data(1 To 3), item As Variant, row As Long
  data(2) = Null
  data(3) = "text"
  row = 1
  For Each item In data
    Worksheets(1).Cells(row, 1).Value2 = IsEmpty(item)
    Worksheets(1).Cells(row, 2).Value2 = IsNull(item)
    row = row + 1
  Next item
  Worksheets(1).Range("A4").Value2 = item'''),
    {'steps': [step(True, 'A1'), step(False, 'B1'), step(False, 'A2'), step(True, 'B2'),
               step(False, 'A3'), step(False, 'B3'), step('text', 'A4')]},
    refs=[REF + 'for-eachnext-statement', REF + 'variant-data-type'])

ok('function-default-and-byval-states', 'Variant procedures',
   ['IsEmpty(Unassigned())', 'IsNull(ReturnNull())', 'IsEmpty(Echo(Empty))',
    'IsNull(Echo(Null))', 'IsEmpty(Change(value))', 'IsNull(value)'],
   [True, True, True, True, True, True], before='  Dim value As Variant\n  value = Null\n',
   extra='''Function Unassigned() As Variant
End Function
Function ReturnNull()
  ReturnNull = Null
End Function
Function Echo(ByVal value As Variant) As Variant
  Echo = value
End Function
Function Change(ByVal value As Variant) As Variant
  value = Empty
  Change = value
End Function
''', refs=[REF + 'function-statement', REF + 'variant-data-type'])

ok('typed-empty-assignment-defaults', 'Empty Let coercion',
   ['number', 'real', 'text', 'flag', 'values(0)', 'words(0)', 'flags(0)',
    'IsEmpty(NumberValue(Empty))', 'NumberValue(Empty)', 'StringValue(Empty)'],
   [0, 0, '', False, 0, '', False, False, 0, ''],
   before='''  Dim number As Long, real As Double, text As String, flag As Boolean
  Dim values(0) As Long, words(0) As String, flags(0) As Boolean
  number = Empty
  real = Empty
  text = Empty
  flag = Empty
  values(0) = Empty
  words(0) = Empty
  flags(0) = Empty
''', extra='''Function NumberValue(ByVal value As Long) As Long
  NumberValue = value
End Function
Function StringValue(ByVal value As String) As String
  StringValue = value
End Function
''', refs=[EMPTY])

for dtype in ['Long', 'Double', 'String', 'Boolean']:
    bad('typed-null-' + dtype.lower(), 'Null Let coercion',
        module(f'  Dim value As {dtype}\n  «value = Null'), 'vba_invalid_use_of_null',
        refs=[DOC, REF + 'invalid-use-of-null-error-94'],
        note='Null is not a typed scalar default; the diagnostic identifies the assignment target.')

bad('typed-array-null', 'Null Let coercion',
    module('  Dim data(0) As Long\n  «data(0) = Null'), 'vba_invalid_use_of_null')
bad('typed-argument-null', 'Null Let coercion',
    module('  Call «Accept(Null)', 'Sub Accept(ByVal value As Boolean)\nEnd Sub\n'),
    'vba_invalid_use_of_null')
bad('typed-function-null', 'Null Let coercion',
    module(write('Broken()'), 'Function Broken() As String\n  «Broken = Null\nEnd Function\n'),
    'vba_invalid_use_of_null')

ok('empty-numeric-arithmetic', 'Empty arithmetic',
   ['+Empty', '-Empty', 'Empty + Empty', 'Empty + 4', '4 + Empty',
    'Empty - 4', '4 - Empty', 'Empty * 4', '4 * Empty', 'Empty / 4'],
   [0, 0, 0, 4, 4, -4, 4, 0, 0, 0],
   refs=[EMPTY, REF + 'plus-operator'])

ok('null-arithmetic-propagation', 'Null arithmetic',
   ['IsNull(+Null)', 'IsNull(-Null)', 'IsNull(Null + 4)', 'IsNull(4 + Null)',
    'IsNull(Null - 4)', 'IsNull(4 - Null)', 'IsNull(Null * 4)',
    'IsNull(4 * Null)', 'IsNull(Null / 0)', 'IsNull(0 / Null)'],
   [True] * 10,
   refs=['https://learn.microsoft.com/en-us/openspecs/microsoft_general_purpose_programming_languages/ms-vbal/e070115f-8d40-40cf-ac6d-ab18b9c6c906'])

ok('empty-comparisons-adopt-context', 'Empty comparisons',
   ['Empty = Empty', 'Empty <> Empty', 'Empty = 0', '0 = Empty', 'Empty < 1',
    'Empty > -1', 'Empty <= 0', 'Empty >= 0', 'Empty = ""', '"" = Empty',
    'Empty < "a"', '"a" > Empty', 'Empty = False', 'False = Empty',
    'Empty > True', 'True < Empty'],
   [True, False, True, True, True, True, True, True, True, True, True, True,
    True, True, True, True], refs=[REF + 'comparison-operators'])

ok('null-comparisons-never-boolean-equality', 'Null comparisons',
   [f'IsNull(Null {operator} Null)' for operator in ['=', '<>', '<', '>', '<=', '>=']] +
   ['IsNull(Null = 0)', 'IsNull(0 = Null)', 'IsNull(Null = "")',
    'IsNull("" <> Null)', 'IsNull(False = Null)', 'IsNull(Empty = Null)'],
   [True] * 12, refs=[REF + 'comparison-operators'])

ok('state-concatenation', 'Variant concatenation',
   ['Empty & "x"', '"x" & Empty', 'Empty & Empty', 'Null & "x"', '"x" & Null',
    'Empty & Null', 'Null & Empty', 'Null & 0', 'True & Null', 'IsNull(Null & Null)',
    '(Null & Null) & "tail"', '"head" & (Null & Null)'],
   ['x', 'x', '', 'x', 'x', '', '', '0', 'True', True, 'tail', 'head'],
   refs=[REF + 'ampersand-operator'])

for operator, answers in [
    ('And', [True, False, None, False, False, False, None, False, None]),
    ('Or', [True, True, True, True, False, None, True, None, None]),
    ('Xor', [False, True, None, True, False, None, None, None, None]),
]:
    exprs = []
    values = []
    for (left, right), value in zip(((a, b) for a in ['True', 'False', 'Null']
                                           for b in ['True', 'False', 'Null']), answers):
        expr = f'{left} {operator} {right}'
        exprs.append(f'IsNull({expr})' if value is None else expr)
        values.append(True if value is None else value)
    ok('null-' + operator.lower() + '-truth-table', 'Boolean/Null logic', exprs, values,
       refs=[REF + operator.lower() + '-operator'])

ok('null-not', 'Boolean/Null logic', ['Not True', 'Not False', 'IsNull(Not Null)'],
   [False, True, True], refs=[REF + 'not-operator'])

for ident, expression, token in [
    ('not-empty', '«Not Empty', 'not'),
    ('empty-and-boolean', 'Empty «And True', 'and'),
    ('boolean-or-empty', 'False «Or Empty', 'or'),
    ('empty-xor-null', 'Empty «Xor Null', 'xor'),
]:
    bad(ident, 'Strict logical operands', module(write(expression)),
        note='Empty would select numeric/bitwise VBA semantics; this Boolean/Null-only dialect requires explicit CBool.')

add('conditions-distinguish-null-from-cbool', 'Variant conditions', module('''  If Empty Then
    Worksheets(1).Range("A1").Value2 = "wrong"
  Else
    Worksheets(1).Range("A1").Value2 = "empty-false"
  End If
  If Null Then
    Worksheets(1).Range("A2").Value2 = "wrong"
  ElseIf Null = Null Then
    Worksheets(1).Range("A2").Value2 = "wrong"
  Else
    Worksheets(1).Range("A2").Value2 = "null-false"
  End If
  If IsNull(Null) Then
    Worksheets(1).Range("A3").Value2 = True
  End If'''), {'steps': steps(['empty-false', 'null-false', True])},
    refs=[REF + 'ifthenelse-statement', EMPTY])

add('loop-conditions-treat-states-as-false', 'Variant conditions', module('''  Dim count As Long
  Do While Null
    count = count + 100
  Loop
  While Empty
    count = count + 100
  Wend
  Do
    count = count + 1
  Loop While Null
  Do Until Empty
    count = count + 1
    Exit Do
  Loop
  Do
    count = count + 1
    If count = 4 Then
      Exit Do
    End If
  Loop Until Null
  Worksheets(1).Range("A1").Value2 = count'''), {'steps': steps([4])}, dialect=True,
    note='Supported condition contexts treat Empty/Null as False without admitting numeric/String truthiness.')

add('select-state-values', 'Variant Select Case', module('''  Select Case Null
    Case Null, 0
      Worksheets(1).Range("A1").Value2 = "wrong"
    Case Else
      Worksheets(1).Range("A1").Value2 = "null-no-match"
  End Select
  Select Case Empty
    Case 0
      Worksheets(1).Range("A2").Value2 = "zero"
  End Select
  Select Case Empty
    Case ""
      Worksheets(1).Range("A3").Value2 = "blank"
  End Select
  Select Case 0
    Case Empty To 1
      Worksheets(1).Range("A4").Value2 = "in-range"
  End Select'''), {'steps': steps(['null-no-match', 'zero', 'blank', 'in-range'])},
    refs=[REF + 'comparison-operators', REF + 'select-case-statement'])

add('select-null-range-evaluates-both-endpoints', 'Variant Select Case', module('''  Select Case 0
    Case LowValue() To HighValue()
      Worksheets(1).Range("A1").Value2 = "wrong"
    Case Else
      Worksheets(1).Range("A1").Value2 = "no-match"
  End Select''', '''Function LowValue() As Variant
  Worksheets(1).Range("B1").Value2 = "lower"
  LowValue = Null
End Function
Function HighValue() As Long
  Worksheets(1).Range("B2").Value2 = "upper"
  HighValue = 1
End Function
'''), {'steps': [step('lower', 'B1'), step('upper', 'B2'), step('no-match')]}, dialect=True,
    note='Case To preserves the dialect\'s eager endpoint evaluation even when its first comparison produces Null.')

ok('cvar-preserves-values-and-states', 'CVar',
   ['IsEmpty(CVar(Empty))', 'IsNull(CVar(Null))', 'CVar(12)', 'CVar(1.25)',
    'CVar("001")', 'CVar(False)', 'CVar("NaN")', 'IsEmpty(CVar(""))'],
   [True, True, 12, 1.25, '001', False, 'NaN', False], refs=[CONVERT, REF + 'variant-data-type'])

ok('cbool-numeric-and-empty', 'CBool',
   ['CBool(Empty)', 'CBool(False)', 'CBool(True)', 'CBool(0)', 'CBool(-0.0)',
    'CBool(0.5)', 'CBool(-0.5)', 'CBool(-1)', 'CBool(9007199254740991)', 'Not CBool(Empty)'],
   [False, False, True, False, False, True, True, True, True, True], refs=[CONVERT, EMPTY])

ok('cdbl-numeric-boolean-and-empty', 'CDbl',
   ['CDbl(Empty)', 'CDbl(False)', 'CDbl(True)', 'CDbl(0)', 'CDbl(-0.0)',
    'CDbl(0.5)', 'CDbl(-1)', 'CDbl(9007199254740991)'],
   [0, 0, -1, 0, 0, 0.5, -1, 9007199254740991], refs=[CONVERT, EMPTY])

ok('clng-nearest-ties-to-even', 'CLng',
   ['CLng(Empty)', 'CLng(False)', 'CLng(True)', 'CLng(0.5)', 'CLng(-0.5)',
    'CLng(1.5)', 'CLng(-1.5)', 'CLng(2.5)', 'CLng(-2.5)', 'CLng(3.5)', 'CLng(-3.5)',
    'CLng(1.49)', 'CLng(-1.49)', 'CLng(1.51)', 'CLng(-1.51)'],
   [0, 0, -1, 0, 0, 2, -2, 2, -2, 4, -4, 1, -1, 2, -2], refs=[CONVERT, EMPTY])

ok('clng-round-before-range-check', 'CLng',
   ['CLng(2147483647)', 'CLng(2147483647.49)', 'CLng(-2147483648)',
    'CLng(-2147483648.5)', 'CLng(-2147483648.49)'],
   [2147483647, 2147483647, -2147483648, -2147483648, -2147483648], refs=[CONVERT])

ok('numeric-strings-invariant-decimal-exponent', 'Invariant numeric strings',
   ['CDbl("42")', 'CDbl(" -1.25 ")', 'CDbl(".5")', 'CDbl("1.")',
    'CDbl("1e3")', 'CDbl("+2E-2")', 'CDbl("-0")', 'CDbl("0e100")',
    'CDbl("9007199254740991")', 'CLng("2.5")', 'CLng("-3.5")', 'CLng("+1E2")'],
   [42, -1.25, 0.5, 1, 1000, 0.02, 0, 0, 9007199254740991, 2, -4, 100],
   dialect=True, note='Explicit conversions use an invariant ASCII decimal/exponent grammar, not Office locale parsing.')

ok('cbool-trimmed-text-and-numeric-strings', 'Invariant Boolean strings',
   ['CBool("true")', 'CBool(" TRUE\t ")', 'CBool(" FaLsE ")', 'CBool("0")',
    'CBool("-0")', 'CBool("1.25")', 'CBool("-2")', 'CBool(" +2E-1 ")'],
   [True, True, False, False, False, True, True, True], dialect=True)

ok('numeric-string-ascii-whitespace', 'Invariant numeric strings',
   ['CDbl("\t\v\f 2.5 \f\v\t")', 'CLng("\t-2.5\t")', 'CBool("\fTRUE\v")'],
   [2.5, -2, True], dialect=True,
   note='ASCII whitespace is admitted around a conversion input; Unicode spaces are deliberately not trimmed.')

ok('cstr-supported-scalars', 'CStr',
   ['CStr(Empty)', 'CStr(False)', 'CStr(True)', 'CStr("")', 'CStr("A😀B")',
    'CStr(0)', 'CStr(-0.0)', 'CStr(42)', 'CStr(-12)', 'CStr(1.25)',
    'CStr(-0.5)', 'CStr(0.000001)', 'CStr(0.0000001)', 'CStr(9007199254740991)'],
   ['', 'False', 'True', '', 'A😀B', '0', '0', '42', '-12', '1.25', '-0.5',
    '0.000001', '1e-7', '9007199254740991'], dialect=True,
   note='CStr uses invariant shortest round-trip numerics, normalized zero, fixed notation for exponent >= -6, and normalized lowercase scientific notation below that boundary.')

ok('cstr-binary64-extreme-shortest-roundtrips', 'CStr binary64 portability',
   ['CStr(CDbl("4.9406564584124654e-324"))', 'CStr(CDbl("2.2250738585072014e-308"))',
    'CStr(0.10000000000000002)', 'CStr(CDbl("1.7976931348623157e-308"))'],
   ['5e-324', '2.2250738585072014e-308', '0.10000000000000002', '1.7976931348623155e-308'],
   dialect=True,
   note='Invariant shortest-roundtrip expectations were independently checked using binary64 hexadecimal identities and exact Decimal values; these are portability cases, not Office formatting observations.')

ok('conversion-composition', 'Explicit conversions',
   ['CStr(CLng("2.5"))', 'CDbl(CStr(1.25))', 'CBool(CLng("0.49"))',
    'IsEmpty(CVar(CStr(Empty)))', 'CLng(CBool("True"))', 'CStr(CVar(Null) & "resolved")'],
   ['2', 1.25, False, False, -1, 'resolved'], dialect=True)

for name in ['CBool', 'CDbl', 'CLng', 'CStr']:
    bad(name.lower() + '-null-refused', name, module(write(f'{name}(«Null)')),
        'vba_invalid_use_of_null', refs=[DOC, CONVERT, REF + 'invalid-use-of-null-error-94'])

for name, literal in [('CLng', '2147483647.5'), ('CLng', '-2147483648.51'),
                      ('CLng', '"2147483648"')]:
    slug = {'2147483647.5': 'upper-tie', '-2147483648.51': 'below-lower-tie',
            '"2147483648"': 'numeric-string'}[literal]
    bad('clng-overflow-' + slug, 'CLng', module(write(f'{name}(«{literal})')),
        refs=[DOC, CONVERT], note='CLng rejects the rounded result when it lies outside signed 32-bit bounds.')

invalid_texts = [
    ('empty', ''), ('spaces', '  '), ('nan', 'NaN'), ('infinity', 'Infinity'),
    ('comma-grouping', '1,000'), ('decimal-comma', '1,5'), ('currency', '$12'),
    ('vba-hex', '&H10'), ('c-hex', '0x10'), ('octal', '&O10'),
    ('missing-exponent', '1e'), ('embedded-space', '1 2'), ('two-points', '1.2.3'),
    ('d-exponent', '1D3'), ('numeric-separator', '1_000'), ('unicode-digits', '١٢'),
    ('unicode-space', '\u00a012\u00a0'), ('trailing-text', '12kg'),
]
for slug, value in invalid_texts:
    quoted = '"' + value.replace('"', '""') + '"'
    bad('cdbl-invalid-' + slug, 'Invariant numeric strings',
        module(write('CDbl(«' + quoted + ')')),
        note='Only the explicit ASCII decimal/exponent grammar is accepted; parsing cannot depend on Dart or host locale extensions.')

for name, values in [('CBool', [('blank', ''), ('yes', 'yes'), ('false-suffix', 'False0'),
                               ('comma', '1,0')]),
                     ('CLng', [('blank', ''), ('nan', 'NaN'), ('fraction-slash', '1/2')])]:
    for slug, value in values:
        bad(name.lower() + '-invalid-' + slug, 'Invariant conversion strings',
            module(write(f'{name}(«"{value}")')))

for name, value in [('CDbl', '9007199254740992'), ('CDbl', '1e309'),
                     ('CBool', '1e309'), ('CLng', '1e309')]:
    bad(name.lower() + '-portable-limit-' + value.replace('+', ''), 'Portable numeric bounds',
        module(write(f'{name}(«"{value}")')), 'vba_limit_exceeded',
        note='Explicit numeric conversions retain the dialect\'s finite magnitude limit of 2^53-1.')

for name in ['IsEmpty', 'IsNull', 'CBool', 'CDbl', 'CLng', 'CStr', 'CVar']:
    bad(name.lower() + '-arity', 'Intrinsic arity', module(write(f'«{name}()')),
        note='Every state predicate/conversion takes exactly one positional scalar argument, checked even in unused code.')

bad('conversion-extra-argument-in-unused-procedure', 'Static checking',
    module('', 'Sub Unused()\n  Dim value As Variant\n  value = «CVar(1, 2)\nEnd Sub\n'))
bad('predicate-object-refused', 'Scalar conversion boundary',
    module(write('IsEmpty(«Worksheets(1))')))
bad('conversion-object-refused-in-unused-code', 'Static checking',
    module('', 'Sub Unused()\n  Dim value As Variant\n  value = CDbl(Worksheets(1).«Range("A1"))\nEnd Sub\n'))
bad('cvar-array-refused', 'Scalar conversion boundary',
    module('  Dim data(0)\n' + write('CVar(«data)')))
bad('object-default-is-not-empty', 'Object boundary',
    module('  Dim target As Range\n' + write('IsEmpty(«target)')))

bad('intrinsic-name-cannot-be-local', 'Reserved names', module('  Dim «CStr As String'),
    'vba_name_error')
bad('intrinsic-name-cannot-be-procedure', 'Reserved names',
    module('', 'Function «IsNull() As Boolean\nEnd Function\n'), 'vba_name_error')
bad('nothing-remains-unsupported', 'Object boundary', module(write('IsEmpty(«Nothing)')),
    'vba_name_error')

for name in ['Empty', 'Null']:
    bad('state-constant-refused-' + name.lower(), 'Constant restrictions',
        module(f'  Const value = «{name}'), 'vba_unsupported',
        note='State literals in constant expressions and fixed-array bounds remain deliberately outside this increment.')
bad('state-fixed-bound-refused', 'Constant restrictions',
    module('  Dim data(«Empty To 2)'), 'vba_unsupported')
bad('conversion-in-constant-refused', 'Constant restrictions',
    module('  Const value = «CLng("2")'), 'vba_unsupported')

add('empty-cell-publication-clears', 'Native state publication', module('''  Dim value As Variant
  Worksheets(1).Range("A1").Value2 = value
  Worksheets(1).Range("A2").Value = Empty
  Worksheets(1).Range("A3:B3").Value2 = CVar(Empty)'''),
    {'steps': [step(None, 'A1'), step(None, 'A2'), step(None, 'A3'), step(None, 'B3')]},
    dialect=True, note='At Value/Value2 only, Empty lowers explicitly to the native cell-clear operation; Null never shares that lowering.')

for prop in ['Value', 'Value2']:
    bad('null-cell-refused-' + prop.lower(), 'Native state publication',
        module('  Worksheets(1).Range("A1").«' + prop + ' = Null'),
        'vba_invalid_use_of_null',
        note='Null is refused at the explicit native publication boundary instead of silently clearing the cell.')

bad('null-font-refused', 'Native state publication',
    module('  Worksheets(1).Range("A1").Font.«Bold = Null'),
    note='Formatting properties retain their strict actual-type contract; Null is not accepted as a Boolean format value.')
bad('cstr-does-not-admit-formula-like-values', 'Native state publication',
    module('  Worksheets(1).Range("A1").«Value2 = CStr("=1+1")'), 'vba_unsupported')
bad('cstr-preserves-utf16-publication-guard', 'Native state publication',
    module('  Worksheets(1).Range("A1").«Value2 = CStr(Left$("😀", 1))'))
ok('cstr-internal-surrogate-can-be-measured', 'Internal String states',
   ['Len(CStr(Left$("😀", 1)))'], [1], dialect=True,
   note='Internal String values may contain UTF-16 halves; publication still requires a well-formed pair.')

bad('len-empty-remains-strict', 'Existing String intrinsic boundary', module(write('Len(«Empty)')),
    note='Len retains its actual-String-only contract; explicit CStr(Empty) supplies a String.')
bad('left-null-remains-strict', 'Existing String intrinsic boundary', module(write('Left$(«Null, 1)')),
    note='The String intrinsic contract stays strict; new Variant states do not add implicit text conversions.')
bad('implicit-string-number-stays-refused', 'Implicit conversion boundary',
    module('  Dim value As Long\n  value = «"12"'),
    note='Explicit CLng/CDbl support does not admit general String-to-number assignment.')
bad('implicit-boolean-number-stays-refused', 'Implicit conversion boundary',
    module(write('1 + «True')),
    note='Explicit CLng(True) or CDbl(True) is required for Boolean numeric conversion.')

add('conversion-and-predicate-arguments-run-once', 'Evaluation order', module('''  Worksheets(1).Range("A1").Value2 = IsEmpty(Probe(1, Empty))
  Worksheets(1).Range("A2").Value2 = IsNull(CVar(Probe(2, Null)))
  Worksheets(1).Range("A3").Value2 = CLng(Probe(3, "2.5"))
  Worksheets(1).Range("A4").Value2 = CStr(Probe(4, True))''', '''Function Probe(ByVal row As Long, ByVal value As Variant) As Variant
  Worksheets(1).Cells(row, 2).Value2 = row
  Probe = value
End Function
'''), {'steps': [step(1, 'B1'), step(True, 'A1'), step(2, 'B2'), step(True, 'A2'),
               step(3, 'B3'), step(2, 'A3'), step(4, 'B4'), step('True', 'A4')]},
    dialect=True, note='Each intrinsic evaluates its argument exactly once; nested helper writes precede the final converted value.')

add('null-operators-retain-eager-order', 'Evaluation order', module('''  Worksheets(1).Range("A1").Value2 = IsNull(Probe(1, Null) + Probe(2, 8))
  Worksheets(1).Range("A2").Value2 = Probe(3, False) And Probe(4, Null)
  Worksheets(1).Range("A3").Value2 = Probe(5, True) Or Probe(6, Null)
  Worksheets(1).Range("A4").Value2 = Probe(7, Null) & Probe(8, "tail")''', '''Function Probe(ByVal row As Long, ByVal value As Variant) As Variant
  Worksheets(1).Cells(row, 2).Value2 = row
  Probe = value
End Function
'''), {'steps': [step(1, 'B1'), step(2, 'B2'), step(True, 'A1'),
               step(3, 'B3'), step(4, 'B4'), step(False, 'A2'),
               step(5, 'B5'), step(6, 'B6'), step(True, 'A3'),
               step(7, 'B7'), step(8, 'B8'), step('tail', 'A4')]},
    dialect=True, note='Null propagation and decisive Boolean operands never suppress evaluation of the other operand.')

bad('null-arithmetic-does-not-hide-argument-error', 'Evaluation order',
    module(write('IsNull(Null + CLng(«"bad"))')))
bad('false-and-does-not-hide-argument-error', 'Evaluation order',
    module(write('False And CBool(«"bad")')))
bad('null-failure-after-earlier-writes-is-atomic', 'Native state publication',
    module(write('1') + '\n  Worksheets(1).Range("A2").«Value2 = Null'),
    'vba_invalid_use_of_null',
    note='Compilation fails as a whole; earlier emitted operations never escape as a partial returned plan.')

ok('inactive-null-conversion-is-not-evaluated', 'Value-dependent checking', ['"reachable"'], ['reachable'],
   before='  If False Then\n    Worksheets(1).Range("B1").Value2 = CBool(Null)\n  End If\n',
   dialect=True)

for function in ['CDbl', 'CStr']:
    bad(function.lower() + '-shared-copy-work-limit', 'Shared resource budget', module(f'''  Dim text As String, value As Variant, i As Long
  text = "0"
  For i = 1 To 14
    text = text & text
  Next i
  For i = 1 To 8
    value = {function}(«text)
  Next i'''), 'vba_limit_exceeded',
        note='Each explicit String conversion charges input/output units against the shared 100,000-work budget before parsing or copying.')

suite = {'schemaVersion': 1, 'suite': 'vba-variant-conversions', 'dialect': 'vba-excel', 'cases': CASES}
assert len({case['id'] for case in CASES}) == len(CASES)
FIXTURE.parent.mkdir(parents=True, exist_ok=True)
# Keep one case per line. The canonical bytes must fit a single base64 Dart
# compiler-definition argument on Linux; no duplicate generated Dart corpus.
lines = ['{', '  "schemaVersion": 1,', '  "suite": "vba-variant-conversions",',
         '  "dialect": "vba-excel",', '  "cases": [']
for index, case in enumerate(CASES):
    lines.append('    ' + json.dumps(case, ensure_ascii=False, separators=(',', ':')) +
                 (',' if index + 1 < len(CASES) else ''))
lines.extend(['  ]', '}'])
FIXTURE.write_text('\n'.join(lines) + '\n')
print(f'Wrote {len(CASES)} independently specified cases, {FIXTURE.stat().st_size} UTF-8 bytes')
