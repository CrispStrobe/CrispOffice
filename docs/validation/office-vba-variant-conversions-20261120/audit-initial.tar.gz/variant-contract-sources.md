# Variant state and conversion contract sources

Research date: 20 November 2026. All normative references below were read from
Microsoft Learn, including a second search engine check for authoritative
coverage. No Microsoft Office process was run. The authored fixture distinguishes
specification-derived results from deliberate bounded dialect choices.

## Source references

- Variant state meaning and defaults: https://learn.microsoft.com/en-us/office/vba/Language/Reference/User-Interface-Help/variant-data-type
- Empty assignment conversion: https://learn.microsoft.com/en-us/openspecs/microsoft_general_purpose_programming_languages/ms-vbal/e2637723-3010-449d-bead-9f17533dc105
- Function defaults: https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/function-statement
- Allocation and preservation: https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/redim-statement
- Fixed reset/dynamic release: https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/erase-statement
- Predicates: https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/isempty-function and https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/isnull-function
- Conversion rules and rounding: https://learn.microsoft.com/en-us/office/vba/language/concepts/getting-started/type-conversion-functions
- Invalid Null use: https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/invalid-use-of-null-error-94
- Arithmetic state rules: https://learn.microsoft.com/en-us/openspecs/microsoft_general_purpose_programming_languages/ms-vbal/e070115f-8d40-40cf-ac6d-ab18b9c6c906
- Comparisons: https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/comparison-operators
- Concatenation: https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/ampersand-operator
- Boolean/Null logic: https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/and-operator , https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/or-operator , https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/xor-operator , https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/not-operator
- Empty logical operands select integral behavior: https://learn.microsoft.com/en-us/openspecs/microsoft_general_purpose_programming_languages/ms-vbal/2d70780d-6e99-47d6-9759-2b3a46b8e862
- Null conditions: https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/ifthenelse-statement
- Len's full VBA state behavior (intentionally not enabled in existing strict String slice): https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/len-function

## Contract choices recorded as dialect evidence

The implementation retains document-independent source-to-plan compilation,
Boolean-only ordinary logic, numeric-only ordinary arithmetic, actual-String
intrinsic text arguments, exact indices, and the existing numeric magnitude,
String and aggregate work limits. Empty/Null are scalar states, not Dart null
or uninitialized object bindings. Empty logical operands remain refused to avoid
silently replacing VBA's integral/bitwise result with a Boolean.

Explicit conversion parsing is invariant ASCII decimal/exponent syntax. It
trims HT/LF/VT/FF/CR/space and does not accept locale separators, Unicode digits,
currencies, date syntax, base prefixes, type suffixes, infinities or NaN.
CBool additionally accepts case-insensitive ASCII True/False text. CStr numeric
formatting is invariant, not Office locale/subtype display formatting. CLng rounds
nearest, ties to even, then checks the signed 32-bit result.

Variant state literals in Const and fixed bounds remain explicitly refused;
all function calls in ordinary constants retain the existing refusal. Empty
cell writes lower to native clears; Null cell writes fail. Neither mapping is
presented as a newly observed Excel-host result.

## Corpus authorship

The corpus was authored independently from the implementation. The helper script
`build_variant_corpus.py` encodes explicit expected values, complete ordered native
operations and intended diagnostic tokens; it does not import, execute or query
the Dart compiler. Runtime verification may correct a diagnostic token position
following source review, but must not accept unexpected semantic outputs as new
expectations. One case is stored per JSON line to keep the exact canonical bytes
within a single Linux base64 compiler-definition argument.
