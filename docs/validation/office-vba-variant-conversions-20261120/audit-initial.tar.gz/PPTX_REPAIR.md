# Bounded incoming PPTX repair

The combined source after reconciling all four incoming heads was
`ce02d89da9207b68d6497f5c20a327d67db9c6f5`. The incoming picture-background
implementation had one basic import test. New ownership and publication tests
exposed sixteen behavioral regressions against that exact isolated engine
snapshot; four control cases already passed.

## Changes

- Resolve exactly one authored background from slide, layout, then master.
  Its picture is painted before ordinary master/layout decorations. A local
  solid/empty fill suppresses pictures inherited from less specific owners.
- Keep the background independent of `showMasterSp`; that flag continues to
  suppress only master decorations. A slide's own picture also loads when
  there is no layout relationship.
- Require an internal image relationship. Preserve source crop, brightness,
  contrast, and alpha metadata in the picture model.
- Add an explicit immutable `PmlShape.isBackgroundPicture` role, retained by
  `copy()`. The existing `backgroundShapes` API and renderer remain unchanged.
- Save that role as a native `p:bg` picture fill with slide-owned image media.
  Copying a slide and saving it twice preserves the selected picture exactly
  once. Assigning a solid slide background replaces the picture and writes the
  native solid fill.
- Apply the first-stop gradient fallback consistently at all three owners.
  Effect colors cannot be mistaken for the paper color.
- Keep the incoming PDF border implementation and test its width/color,
  rectangle, order after the image, and placement after restoring the crop clip.

## Local development verification

Twenty new tests are in `slide_picture_background_test.dart`. All existing
incoming background-import assertions remain intact. The original dark-slide
test bodies remain unchanged; incoming Zotero/Mail adds one extra regression.

The final development run passes **218 application tests in twelve engine
rendering files**, with no failed or skipped cases. Strict analysis of the
three changed implementation files and new test file reports no issues.
The corrected twenty-test corpus run against the isolated pre-repair engine
has **sixteen failures and four passes**, proving that it detects the incoming
defects. These baseline failures are expected controls, not current failures.

Raw logs, prior diagnostic attempts, exact final source hashes, and parsed
counts are in `evidence/pptx-development/summary.json`. This is development
evidence; root's later source-bound combined qualification is the acceptance
record. The early compile typo in a fixture content-type constant and one
incorrect PDF stream-syntax expectation remain retained and explicitly
superseded by the corrected run.

The supported picture representation remains a resolved full-slide stretched
snapshot. This does not add tiled backgrounds, theme background-reference
resolution, or new installed PowerPoint interoperability acceptance. Crop and
other modeled image-adjustment metadata are retained; broader picture-effect
rendering remains the existing renderer's scope.

Suggested engine changelog entry: "Preserve picture background ownership,
master-visibility independence, crop and native media through copied slides
and repeated PPTX saves; retain explicit solid overrides and consistent
gradient fallback."
