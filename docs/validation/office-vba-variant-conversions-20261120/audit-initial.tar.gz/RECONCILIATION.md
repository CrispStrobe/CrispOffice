# Remote reconciliation audit — 20 November 2026

Captured fork main: `85c019cd8fda1a735a727bff98c2a56fb25a368e` (merged PR #224).
This audit did not query or await GitHub Actions, workflow runs, checks, or commit statuses.

## Inventory

| Source | Classification |
| --- | --- |
| 17 fork branches | Main, 3 ancestor heads, 9 historical equivalents, 4 unique incoming heads |
| Latest 100 updated PR heads | 83 ancestor heads, 14 historical equivalents, 3 unique open PR heads |
| Four branches of `MohammedAsaadAsaad/quds_office_suite` | All already ancestors |

Historical equivalents were freshly rechecked by complete changed-path Git mode, type, and blob identity against accepted ancestor equivalents. Mapping sources are the prior dynamic-array and string-conformance reconciliation records. They were not accepted solely because an earlier report called them equivalent.

## Incoming heads

| Branch | Captured head | Readiness and integration implications |
| --- | --- | --- |
| `codex/zotero-research-materials-20261120` | `e79c32e77f1990e303527e477e4909df993c1b9b` | PR #223 remains open. Its body still says qualification in progress, but the current source contains completed receipts and a report of 2,886 distinct local tests in 135 files, with 55 Dart targets statically checked. These are inherited claims with their original source/runtime attribution. |
| `feat/spacy-grammar-v2-20261120` | `4973e712045bdcf45fd36dcfe37d380c52265d3c` | PR #225 is ready and already contains captured main. Three new grammar families are qualified and default-on inside the opt-in manual provider; subject-person is explicitly experimental/default-off. The consumed native protocol and results must remain immutable. |
| `integrate/recent-pptx` | `9d8a13733bde66f4a5cdb80e006a1637fc09bb77` | Contains earlier Mail and Zotero implementations via actual merge ancestry, then adds picture backgrounds/gradient fallback and picture borders in PDF. The background commit adds one basic import test; the PDF border commit adds no test. Fresh ownership/round-trip coverage is needed. |
| `work/mail-attachments-20261120` | `f80b46e2115d32b11b633cc47acec820aecf2db4` | PR #221 remains draft. Its core attachment implementation is already in the captured Zotero/PPTX histories. Latest unique product changes include narrow/RTL composition layout and orientation tests. The user expressly requested integration of all recent branches. |

Each incoming head separately merges cleanly with captured main. An object-only union simulation of main → spaCy → Zotero is also clean. Adding Mail produces documentation conflicts only in `docs/roadmaps/mail/attachments.md` and `docs/roadmaps/mail/status.md`; preserve the completed behavior and both branches' attribution. The simulation created unreferenced Git objects only and changed no branch refs or worktree files.

## Focused local validation

`incoming_validation_plan.json` defines 10 disjoint cohorts with 60 explicit existing test paths. They cover the new Zotero client/dialog behavior and adjacent identity/details paths; slide parsing/rendering/copy/serialization/PDF; mail attachments/composer/MIME/transport; spaCy synthetic planner/provider/lifecycle behavior and Studio setup. Add the new picture-background regressions to the rendering cohort.

Use the pinned Flutter 3.47.8 / Dart 3.13.7 with locked dependencies, genuine Dart for VM suites, and Flutter with `--no-pub --concurrency=1` for widget suites. Record source head, raw machine events, exit status, and source fingerprints. Do not count test loader events as application cases. No live service interaction is required by this selection.

The incoming spaCy report documents a known full-Studio baseline failure, `studio_comment_draft_proofing_test: language changes invalidate existing draft suggestions`. It is outside this focused selection. A focused pass must not be described as a full Studio suite pass. The selected spaCy tests use synthetic annotations/backends and do not establish fresh native model qualification.

## PPTX overlap defect found during review

Commit `23d409c9` currently conflates picture backgrounds with ordinary master/layout decorations. An explicit slide picture is inserted before master/layout picture decorations, allowing inherited pictures to paint over it; explicit solid backgrounds do not suppress inherited pictures; `showMasterSp=false` hides a master picture background; a slide without a layout never gets its own picture background. `slideToXml` does not write `p:bg`, so a slide-owned picture would also disappear on save. These cases require a bounded background-ownership repair and fresh regressions before final publication.

## Evidence files

- `initial_remote_inventory.json`: live fork branches plus latest 100 PR metadata, including complete open-PR descriptions.
- `upstream_inventory.json`: exact four upstream branch heads.
- `initial_remote_classification.json`: per-head ancestry and fresh equivalence proofs.
- `classify_inventory.py`: reproducible classification script and exact historical mapping sources.
- `initial_merge_analysis.json`: pairwise ancestry matrix and read-only merge-tree results against captured main.
- `combined_merge_simulation.json`: sequential object-only union simulation and documentation conflict paths.
- `incoming_validation_plan.json`: exact focused test paths, runners, and scope caveats.

These files describe the captured intake. Root must refresh the live remote heads before final publication and preserve any later advances with ordinary ancestry and an expected-head update.
