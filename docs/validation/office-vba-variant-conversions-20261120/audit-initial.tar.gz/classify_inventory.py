import collections
import datetime
import json
import pathlib
import subprocess

root = pathlib.Path('/workspace/scratch/bfb797b611e2')
repo = root / 'quds_office_suite'
audit = json.loads((root/'audit/initial_remote_inventory.json').read_text())
upstream = json.loads((root/'audit/upstream_inventory.json').read_text())
main = next(x['sha'] for x in audit['branches'] if x['name']=='main')

def git(*args, check=True):
    p = subprocess.run(['git', *args], cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and p.returncode:
        raise RuntimeError(p.stderr.decode())
    return p

def ancestor(a, b):
    return git('merge-base', '--is-ancestor', a, b, check=False).returncode == 0

prior = json.loads((repo/'docs/validation/office-vba-string-conformance-20261120/initial-remote-audit.json').read_text())
hist = {}
older = json.loads((repo/'docs/validation/office-vba-dynamic-arrays-20261119/initial-reconciliation.json').read_text())
for item in older['branches']+older['recentPullRequests']:
    if 'historicalEquivalence' in item:
        hist[item['sha']] = item['historicalEquivalence']
for group in ['forkBranches','recentPullRequests','upstreamBranches']:
    for item in prior[group]:
        if 'historicalEquivalence' in item:
            hist[item.get('sha', item.get('head'))] = item['historicalEquivalence']

missing = []
for pr in audit['prs']:
    if git('cat-file', '-e', pr['head_sha']+'^{commit}', check=False).returncode:
        missing.append(f"{pr['head_sha']}:refs/audit/variant-pr/{pr['number']}")
for branch in audit['branches']:
    if git('cat-file', '-e', branch['sha']+'^{commit}', check=False).returncode:
        missing.append(f"{branch['sha']}:refs/audit/variant-branch/{branch['name']}")
if missing:
    git('fetch', '--no-tags', 'origin', *missing)

cache = {}
def classify(sha):
    if sha in cache:
        return cache[sha]
    if sha == main:
        value = {'disposition':'main'}
    elif ancestor(sha, main):
        value = {'disposition':'already_ancestor'}
    elif sha in hist:
        h = hist[sha]
        base, equivalent = h['commonBase'], h['equivalent']
        paths = [x for x in git('diff','--name-only','-z',base,sha).stdout.decode().split('\0') if x]
        mismatches = [p for p in paths if git('ls-tree',sha,'--',p).stdout != git('ls-tree',equivalent,'--',p).stdout]
        ok = ancestor(equivalent,main) and not mismatches
        value = {'disposition':'historical_equivalent' if ok else 'unresolved', 'historicalEquivalence':{'commonBase':base,'equivalent':equivalent,'equivalentIsAncestor':ancestor(equivalent,main),'deltaPaths':len(paths),'deltaMismatches':mismatches,'method':'fresh_complete_delta_path_mode_type_blob_identity','passed':ok}}
    else:
        value = {'disposition':'incoming_source','uniqueCommits':git('rev-list','--reverse',f'{main}..{sha}').stdout.decode().splitlines()}
    cache[sha] = value
    return value

for branch in audit['branches']+upstream:
    branch.update(classify(branch['sha']))
for pr in audit['prs']:
    pr.update(classify(pr['head_sha']))
audit['upstreamBranches'] = upstream
audit['main'] = main
audit['classificationCompletedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
audit['classificationMethod'] = 'Fresh local ancestry and exact changed-path Git mode/type/blob identity against already accepted equivalents'
audit['historicalEquivalenceMappingsFrom'] = 'docs/validation/office-vba-string-conformance-20261120/initial-remote-audit.json'
audit['githubActionsQueriedOrAwaited'] = False
audit['fetchedMissingRefs'] = missing
audit['counts'] = {g: dict(collections.Counter(x['disposition'] for x in audit[g])) for g in ['branches','prs','upstreamBranches']}
(root/'audit/initial_remote_classification.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({'main':main,'counts':audit['counts'],'missingRefs':missing,'incoming':{g:[{k:v for k,v in x.items() if k not in ['body','uniqueCommits']} for x in audit[g] if x['disposition'] in ['incoming_source','unresolved']] for g in ['branches','prs','upstreamBranches']}},indent=2))
