import 'dart:io';

import 'package:quds_office_engine/quds_office_engine.dart';

void main() {
  final first = WmlParagraph(inlines: [WmlRun(text: 'Roman note')]);
  final second = WmlParagraph(inlines: [WmlRun(text: 'Decimal note')]);
  final document = WmlDocument(
    zoteroDocumentData: '{"prefs":{"fieldType":"Field","noteType":2}}',
    sections: [
      WmlSection(blocks: [first]),
      WmlSection(
        blocks: [second],
        sourceProperties: WmlSectionSource(
          xml: '<w:sectPr xmlns:w="${OfficeNamespaces.w}">'
              '<w:endnotePr><w:numFmt w:val="decimal"/></w:endnotePr>'
              '</w:sectPr>',
          values: const {},
        ),
      ),
    ],
  );
  WordNotes.insert(document, first, endnote: true, text: 'Uncited');
  final note = WordNotes.insert(document, second, endnote: true, text: 'Cited');
  WordZotero.insertCitation(
    note.paragraphs.single,
    ZoteroCitation(
      citationId: 'mixed',
      plainCitation: '(Source)',
      items: [
        ZoteroCitationItem.fromCsl(
          itemData: {'id': 1, 'type': 'book', 'title': 'Source'},
          uris: ['http://zotero.org/users/42/items/ABCD1234'],
        ),
      ],
    ),
  );
  final numbering = WordNoteNumbering(document);
  print(document.endnotes.map(numbering.labelFor).toList());
  File('/workspace/scratch/41f814a8b629/odt_reconcile_validation/mixed-notes.odt')
      .writeAsBytesSync(OdtDocumentWriter.writeEditableZoteroBytes(document));
}
