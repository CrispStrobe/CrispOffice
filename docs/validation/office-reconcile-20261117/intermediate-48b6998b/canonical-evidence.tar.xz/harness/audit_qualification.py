#!/usr/bin/env python3
"""Independently recount completed raw Dart events and verify final evidence."""
from __future__ import annotations

import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
from urllib.parse import unquote, urlparse


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    run = args.run.resolve()
    receipt = read_json(run / 'receipt.json')
    plan = read_json(run / 'plan.json')
    historical = read_json(Path(__file__).resolve().parent / 'prior-qualified-plan-189.json')
    errors = []

    def require(condition, message):
        if not condition:
            errors.append(message)

    require(receipt['status'] == 'passed' and receipt['all_passed'], 'Accepted runner status')
    require(receipt['source_commit'] == plan['source_commit'], 'Plan source identity')
    require(digest((run / 'plan.json').read_bytes()) == receipt['plan_sha256'], 'Plan hash')
    require(all(receipt['input_integrity'].values()), 'All recorded inputs unchanged')
    require(receipt['analysis_config_restored'], 'Analyzer configuration restored')
    require(receipt['working_head_after'] == receipt['source_commit'], 'Frozen HEAD unchanged')
    old = {(group['kind'], path) for group in historical['cohorts'].values() for path in group['tests']}
    selection = [(group['kind'], path) for group in plan['cohorts'].values() for path in group['tests']]
    require(len(selection) == len(set(selection)), 'Selected suites disjoint')
    require(old <= set(selection), 'All 189 prior suite files retained')
    require(len(selection) == plan['unique_test_files'], 'Selection count')
    commands = {row['name']: row for row in receipt['commands']}
    expected_commands = ({name + '-strict-analysis' for name in plan['analysis_targets']}
                         | set(plan['cohorts']) | {'format', 'python-controls'})
    require(set(commands) == expected_commands, 'Every planned gate executed exactly once')
    require(len(commands) == len(receipt['commands']), 'No duplicate gate names')
    cohorts = {}
    for name, command in commands.items():
        require(command['status'] == 'passed' and command['exit_code'] == 0, name + ': successful process')
        raw = {}
        for stream in ('stdout', 'stderr'):
            packed = (run / command[stream]).read_bytes()
            data = gzip.decompress(packed)
            raw[stream] = data
            require(digest(packed) == command[stream + '_gzip_sha256'], name + ': compressed ' + stream + ' hash')
            require(digest(data) == command[stream + '_sha256'], name + ': raw ' + stream + ' hash')
        if name not in plan['cohorts']:
            continue
        events = []
        for line in raw['stdout'].decode(errors='replace').splitlines():
            try:
                event = json.loads(line)
            except ValueError:
                continue
            if isinstance(event, dict):
                events.append(event)
        starts = [event['test'] for event in events if event.get('type') == 'testStart']
        finishes = [event for event in events if event.get('type') == 'testDone']
        by_id = {row['id']: row for row in starts}
        start_counts = Counter(row['id'] for row in starts)
        finish_counts = Counter(row['testID'] for row in finishes)
        require(all(value == 1 for value in start_counts.values()), name + ': no duplicate starts')
        require(start_counts == finish_counts, name + ': every started ID completes once')
        visible = [row for row in finishes if not row.get('hidden')]
        skips = [row for row in visible if row.get('skipped')]
        failures = [row for row in visible if row.get('result') != 'success']
        require(not skips and not failures, name + ': no skipped or failed test events')
        require(not [event for event in events if event.get('type') == 'error'], name + ': no error events')
        terminal = [event for event in events if event.get('type') == 'done']
        require(len(terminal) == 1 and terminal[0].get('success') is True, name + ': one successful terminal event')
        suites = {event['suite']['id']: event['suite'] for event in events if event.get('type') == 'suite'}
        cwd = Path(command['cwd'])
        actual_paths = set()
        for row in suites.values():
            value = row['path']
            path = Path(unquote(urlparse(value).path) if value.startswith('file:') else value)
            actual_paths.add((path if path.is_absolute() else cwd / path).resolve())
        expected_paths = {(cwd / path).resolve() for path in plan['cohorts'][name]['tests']}
        require(actual_paths == expected_paths, name + ': selected and executed file sets equal')
        excluded = []
        for row in visible:
            test = by_id[row['testID']]
            suite = suites[test['suiteID']]
            if suite['path'].endswith('/pdf_file_test.dart') and any(
                test['name'] == title or test['name'].endswith(' ' + title)
                for title in ('TrueType subsets without cmap get ToUnicode cmap for the host',
                              'JPEG with DCT SMask attaches softMaskJpeg for the host')):
                require(read_json(run / 'system-before.json')['/home/mohammed/Desktop/al_tahreer_profile.pdf'] is None,
                        name + ': unavailable fixture status independently checked')
                excluded.append(test['name'])
        count = len(visible) - len(excluded)
        summary = command['test_summary']
        require(len(visible) == summary['raw_success_count'], name + ': raw count agrees')
        require(count == summary['substantive_success_count'], name + ': substantive count agrees')
        require(len(excluded) == len(summary['excluded_success_cases']), name + ': exclusion count agrees')
        cohorts[name] = {'executed_files': len(actual_paths), 'started_ids': len(starts),
                         'completed_ids': len(finishes), 'raw_passes': len(visible),
                         'substantive_passes': count, 'excluded_private_cases': excluded,
                         'skips': len(skips), 'failures': len(failures),
                         'stdout_sha256': digest(raw['stdout'])}
    python = read_json(run / 'python-controls-summary.json')
    python_selected = python['selected_test_ids']
    python_successes = python['successful_test_ids']
    require(len(python_selected) == len(set(python_selected)), 'Python selection unique')
    require(len(python_successes) == len(set(python_successes)), 'Python successes unique')
    require(set(python_selected) == set(python_successes), 'Every selected Python case succeeds')
    require(python['tests_run'] == len(python_successes) == python['substantive_success_count'], 'Python counts agree')
    require(not any(python[key] for key in ('skipped_cases', 'failures', 'errors', 'unexpected_successes', 'expected_failures')), 'Python has no exceptional outcomes')
    require(python['runtime_before'] == python['runtime_after'], 'Python dependencies unchanged')
    require(python['runtime_before']['onnx_available'] and python['runtime_before']['onnxruntime_available'], 'ONNX runtime present')
    converter = 'test_qualification.TinyConverterTests.test_real_quantizer_preserves_both_head_matrices'
    converter_passed = converter in python_successes
    require(converter_passed, 'Real tiny ONNX quantizer case passed')
    for category in ('source', 'dependencies', 'runtime', 'workspace', 'system', 'harness'):
        require(read_json(run / f'{category}-before.json') == read_json(run / f'{category}-after.json'), category + ': independent before/after map comparison')
    source = Path(receipt['repo'])
    require(subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == receipt['source_commit'], 'Current frozen source SHA')
    require(subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD^{tree}'], text=True).strip() == receipt['source_tree'], 'Current frozen source tree')
    require(not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True), 'Frozen source remains clean')
    source_map = read_json(run / 'source-after.json')['files']
    for relative, row in source_map.items():
        path = source / relative
        data = path.readlink().as_posix().encode() if path.is_symlink() else path.read_bytes()
        require(digest(data) == row['sha256'], 'Current source hash: ' + relative)
    native_name = 'real native dual heads own their output and reject use after dispose'
    native_rows = commands['gector-contract']['test_summary']['completed_tests']
    native_passed = any(row['name'] == native_name and row['outcome'] == 'success' for row in native_rows)
    require(native_passed, 'Pinned real native GECToR test succeeds')
    total = sum(row['substantive_passes'] for row in cohorts.values())
    require(total == receipt['substantive_success_total'], 'Overall substantive pass total')
    result = {'source_commit': receipt['source_commit'], 'source_tree': receipt['source_tree'],
              'runner_receipt_sha256': digest((run / 'receipt.json').read_bytes()),
              'source_files_rechecked': len(source_map), 'selected_test_files': len(selection),
              'historical_files_retained': len(old), 'fresh_dart_flutter_substantive_passes': total,
              'fresh_python_passes': len(python_successes), 'cohorts': cohorts,
              'analysis_scopes': len(plan['analysis_targets']), 'format_targets': len(plan['format_targets']),
              'real_native_gector_case_passed': native_passed, 'tiny_onnx_quantizer_case_passed': converter_passed,
              'historical_pass_counts_added': False, 'errors': errors, 'passed': not errors}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if not errors else 1)


if __name__ == '__main__':
    main()
