#!/usr/bin/env python3
"""Archive completed canonical evidence and read back every indexed member."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--accepted', type=Path, required=True)
    parser.add_argument('--failed', type=Path, action='append', default=[])
    parser.add_argument('--prefix', type=Path, required=True)
    args = parser.parse_args()
    receipt = json.loads((args.accepted / 'receipt.json').read_text())
    assert receipt['all_passed'] and receipt['status'] == 'passed'
    commit = receipt['source_commit']
    archive_path = args.prefix.with_suffix('.tar.xz')
    index_path = args.prefix.with_suffix('.index.json')
    assert not archive_path.exists() and not index_path.exists()
    files = {}

    def add(path, name):
        assert path.is_file(), path
        assert name not in files, name
        files[name] = path

    for label, directory in [('accepted', args.accepted), *[(f'failed-{i+1}', path) for i, path in enumerate(args.failed)]]:
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                add(path, label + '/' + str(path.relative_to(directory)))
    for name in ('prior_run_qualification.py', 'prior_python_controls.py', 'run_qualification.py',
                 'python_controls.py', 'prepare_workspace.py', 'run_frozen.py',
                 'audit_qualification.py', 'package_evidence.py', 'historical-plan-179.json',
                 'prepared-inputs.json', 'runtime-audit.json', 'prior-qualified-plan-189.json'):
        add(HERE / name, 'harness/' + name)
    for path in sorted(HERE.glob('workspace-*.json')):
        add(path, 'setup/' + path.name)
    for path in sorted((HERE / 'logs').glob('*')):
        if path.is_file():
            add(path, 'setup/logs/' + path.name)
    for name in ('consumer-extension-review.json', 'new-test-inventory-eaa.json'):
        path = HERE / name
        if path.is_file():
            add(path, 'reviews/' + name)
    for path in sorted((HERE / 'format-correction-4a4101c1').glob('*')):
        if path.is_file():
            add(path, 'reviews/format-correction-4a4101c1/' + path.name)
    for name in ('pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.dart_tool/package_config.json', '.dart_tool/package_graph.json'):
        add(Path(receipt['test_workspace']) / name, 'setup/workspace/' + name)
    workspace = Path(receipt['test_workspace'])
    manifests = [*workspace.glob('packages/*/pubspec.yaml'), *workspace.glob('packages/*/example/pubspec.yaml'), *workspace.glob('apps/*/pubspec.yaml')]
    for path in manifests:
        add(path, 'setup/workspace/' + str(path.relative_to(workspace)))
    add(HERE.parent / 'flutter-sdk/bin/cache/flutter.version.json', 'setup/flutter-version.json')
    add(Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/assets/native-development-pack-v1/pack.json'), 'setup/native-development-pack-manifest.json')
    rows = []
    with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
        for name, path in sorted(files.items()):
            data = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            import io
            archive.addfile(info, io.BytesIO(data))
            rows.append({'name': name, 'bytes': len(data), 'sha256': sha(data)})
    readback = []
    with tarfile.open(archive_path, 'r:xz') as archive:
        assert archive.getnames() == [row['name'] for row in rows]
        for member, expected in zip(archive.getmembers(), rows):
            assert member.isfile() and member.size == expected['bytes']
            data = archive.extractfile(member).read()
            assert sha(data) == expected['sha256']
            readback.append(member.name)
    index = {'source_commit': commit, 'source_tree': receipt['source_tree'],
             'archive': archive_path.name, 'archive_bytes': archive_path.stat().st_size,
             'archive_sha256': sha(archive_path.read_bytes()), 'members': rows,
             'readback': {'every_member_fully_read': True, 'verified_members': len(readback),
                          'sizes_and_sha256_match': True},
             'failed_attempts_included': len(args.failed),
             'large_native_model_or_runtime_binaries_included': False}
    index_path.write_text(json.dumps(index, indent=2) + '\n')
    print(json.dumps({key: value for key, value in index.items() if key != 'members'}, indent=2))


if __name__ == '__main__':
    main()
