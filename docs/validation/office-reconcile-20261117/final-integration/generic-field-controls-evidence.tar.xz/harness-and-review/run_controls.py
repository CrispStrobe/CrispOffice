from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import time

BASE = Path(__file__).resolve().parent
SDK = BASE.parent / 'flutter-sdk/bin/cache/dart-sdk/bin/dart'
RUNNER = BASE.parent / 'wave2/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'

p = argparse.ArgumentParser()
p.add_argument('--source', choices=['incoming', 'candidate', 'integrated', 'no_cache_base', 'final_integrated'], required=True)
p.add_argument('--label', required=True)
p.add_argument('--test', default='test/odt_complex_field_fidelity_test.dart')
p.add_argument('--selection', type=Path)
args = p.parse_args()
root = BASE / (args.source + '-13/packages/quds_office_engine')
output = BASE / args.label
output.mkdir(exist_ok=False)
for name in ['fixtures', 'tmp', 'config']:
    (output / name).mkdir()
env = dict(os.environ, ODT_FIELD_FIXTURE_DIRECTORY=str(output / 'fixtures'),
           PUB_CACHE=str(BASE.parent / 'wave2/pub-cache'),
           TMPDIR=str(output / 'tmp'), XDG_CONFIG_HOME=str(output / 'config'),
           DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true')
tests = json.loads(args.selection.read_text()) if args.selection else [args.test]
command = [str(SDK), '--packages=' + str(root / '.dart_tool/package_config.json'),
           str(RUNNER), '--reporter=json', '--concurrency=1', *tests]
writer = root / 'lib/src/word/serial/odt_document_writer.dart'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
test_hashes = lambda: {name: sha(root / name) for name in tests} if args.selection else sha(root / args.test)
before = {'writer': sha(writer), 'test': test_hashes(),
          'package_config': sha(root / '.dart_tool/package_config.json')}
start = time.monotonic()
with (output / 'stdout.jsonl').open('wb') as stdout, (output / 'stderr.log').open('wb') as stderr:
    result = subprocess.run(command, cwd=root, env=env, stdout=stdout, stderr=stderr)
events = []
for line in (output / 'stdout.jsonl').read_text().splitlines():
    try:
        value = json.loads(line)
    except ValueError:
        continue
    if isinstance(value, dict):
        events.append(value)
names = {e['test']['id']: e['test']['name'] for e in events if e.get('type') == 'testStart'}
cases = [{'name': names[e['testID']], 'result': e['result'], 'skipped': e.get('skipped', False)}
         for e in events if e.get('type') == 'testDone' and not e.get('hidden')]
after = {'writer': sha(writer), 'test': test_hashes(),
         'package_config': sha(root / '.dart_tool/package_config.json')}
record = {'source': args.source, 'command': command, 'cwd': str(root),
          'exit_code': result.returncode, 'duration_seconds': time.monotonic() - start,
          'inputs_before': before, 'inputs_after': after, 'inputs_unchanged': before == after,
          'cases': cases, 'passed': sum(e['result'] == 'success' and not e['skipped'] for e in cases),
          'failed': sum(e['result'] != 'success' for e in cases),
          'skipped': sum(e['skipped'] for e in cases),
          'stdout_sha256': sha(output / 'stdout.jsonl'), 'stderr_sha256': sha(output / 'stderr.log')}
(output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ['source', 'exit_code', 'passed', 'failed', 'skipped', 'inputs_unchanged']}))
