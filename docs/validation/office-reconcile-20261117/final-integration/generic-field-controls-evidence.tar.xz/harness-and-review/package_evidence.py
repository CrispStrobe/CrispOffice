from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1] / 'quds_office_suite'
SOURCE = HERE / 'final_integrated-13/packages/quds_office_engine'
sha = lambda data: hashlib.sha256(data).hexdigest()
raw = subprocess.check_output(['git', 'archive', '13e7172977d671190ba8c3cf964deec4d7473090',
                               'packages/quds_office_engine'], cwd=ROOT)
assert sha(raw) == json.loads((HERE / 'setup.json').read_text())['engine_archive_sha256']
baseline = {}
with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
    for member in archive.getmembers():
        if member.isfile():
            baseline[member.name] = archive.extractfile(member).read()
files = {}

def add(path, name):
    assert name not in files
    files[name] = path.read_bytes()

for path in sorted(HERE.iterdir()):
    if path.is_file() and path.suffix in {'.py', '.dart', '.json', '.log', '.patch', '.md'}:
        add(path, 'harness-and-review/' + path.name)
for directory in sorted(HERE.iterdir()):
    if not directory.is_dir() or directory.name.endswith('-13'):
        continue
    if not ((directory / 'stdout.jsonl').is_file() or (directory / 'receipt.json').is_file()):
        continue
    for name in ('stdout.jsonl', 'stderr.log', 'receipt.json', 'command.json'):
        path = directory / name
        if path.is_file():
            add(path, 'runs/' + directory.name + '/' + name)
    for path in sorted((directory / 'fixtures').glob('*.odt')):
        add(path, 'runs/' + directory.name + '/fixtures/' + path.name)
for name, path in {
    'incoming-writer.dart': HERE / 'incoming-13/packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart',
    'candidate19-writer.dart': HERE / 'candidate-13/packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart',
    'interaction21-controls.dart': HERE / 'integrated-13/packages/quds_office_engine/test/odt_complex_field_fidelity_test.dart',
    'incoming-unchanged-writer-test.dart': HERE / 'incoming-13/packages/quds_office_engine/test/odt_document_writer_test.dart',
    'accepted-field-controls.dart': SOURCE / 'test/odt_complex_field_fidelity_test.dart',
}.items():
    add(path, 'source-versions/' + name)
overlay = []
actual = {}
for path in sorted(SOURCE.rglob('*')):
    if not path.is_file() or '.dart_tool' in path.parts:
        continue
    name = 'packages/quds_office_engine/' + str(path.relative_to(SOURCE))
    actual[name] = path.read_bytes()
    if baseline.get(name) != actual[name]:
        files['integrated-overlay/' + name] = actual[name]
        overlay.append(name)
recipe = {'baseline_commit': '13e7172977d671190ba8c3cf964deec4d7473090',
          'baseline_git_archive_sha256': sha(raw), 'overlay_paths': overlay,
          'removed_paths': sorted(set(baseline) - set(actual)),
          'purpose': 'Reconstruct the exact engine snapshot used for the final provisional focused run before the final remote qualification.'}
files['integrated-overlay/recipe.json'] = (json.dumps(recipe, indent=2) + '\n').encode()
for path in sorted((HERE.parent / 'main13-audit').glob('*.json')):
    add(path, 'main13-audit/' + path.name)
destination = HERE / 'generic-field-controls-evidence.tar.xz'
index_path = HERE / 'generic-field-controls-evidence.index.json'
assert not destination.exists() and not index_path.exists()
rows = []
with tarfile.open(destination, 'w:xz', preset=6) as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
        rows.append({'name': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(destination, 'r:xz') as archive:
    assert archive.getnames() == [row['name'] for row in rows]
    for member, row in zip(archive.getmembers(), rows):
        data = archive.extractfile(member).read()
        assert member.isfile() and len(data) == row['bytes'] and sha(data) == row['sha256']
index = {'archive': destination.name, 'bytes': destination.stat().st_size,
         'sha256': sha(destination.read_bytes()), 'members': rows,
         'readback_every_member_sizes_and_hashes_verified': True,
         'verified_members': len(rows), 'overlay_files': len(overlay),
         'final_focused_binding': json.loads((HERE / 'final-integration-binding.json').read_text())}
index_path.write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({key: value for key, value in index.items() if key not in {'members', 'final_focused_binding'}}, indent=2))
