from pathlib import Path
import argparse
import hashlib
import json
import zipfile
from lxml import etree

p = argparse.ArgumentParser()
p.add_argument('--fixtures', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
args = p.parse_args()
schemas = Path('/workspace/scratch/44ccebb41cba/consumer-runtime/schemas')
expected = {
    'OpenDocument-v1.3-schema.rng': '40bad03efdbb02825230d357da0aa6ac679934c5bf56c6281752c0c24d58e4e6',
    'OpenDocument-v1.3-manifest-schema.rng': '8aee71f03484be112af972d622cc9031280c007b0a454ae8815e8e333c9bdd17',
}
for name, digest in expected.items():
    assert hashlib.sha256((schemas / name).read_bytes()).hexdigest() == digest
validators = {name: etree.RelaxNG(etree.parse(str(schemas / name))) for name in expected}
rows = []
for fixture in sorted(args.fixtures.glob('*.odt')):
    parts = []
    with zipfile.ZipFile(fixture) as archive:
        assert archive.testzip() is None
        for part in ('content.xml', 'styles.xml', 'meta.xml', 'META-INF/manifest.xml'):
            validator = validators['OpenDocument-v1.3-manifest-schema.rng'
                                   if part.startswith('META-INF') else 'OpenDocument-v1.3-schema.rng']
            passed = validator.validate(etree.fromstring(archive.read(part)))
            parts.append({'part': part, 'passed': passed,
                          'errors': None if passed else str(validator.error_log)})
    rows.append({'file': fixture.name, 'sha256': hashlib.sha256(fixture.read_bytes()).hexdigest(),
                 'parts': parts})
result = {'schemas': expected, 'fixtures': rows,
          'libxml_version': etree.LIBXML_VERSION, 'lxml_version': etree.LXML_VERSION,
          'passed': bool(rows) and all(part['passed'] for row in rows for part in row['parts']),
          'schema_parts_passed': sum(part['passed'] for row in rows for part in row['parts']),
          'schema_parts_total': 4 * len(rows)}
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'fixtures'}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
