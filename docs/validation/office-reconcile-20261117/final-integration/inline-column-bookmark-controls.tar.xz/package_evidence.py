#!/usr/bin/env python3
"""Bind every recorded source snapshot, then preserve the control evidence."""
import collections
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/workspace/scratch/44ccebb41cba')
REPO = ROOT / 'quds_office_suite'
WORK = ROOT / 'quds-audit/inline-column'
OUT = WORK / 'evidence'
OUT.mkdir(exist_ok=True)
FINAL = '7596af95f763972995403d44dd251a1da22799be'
BASE = '48b6998bb47ffdf43e95025229dc5a5eab09ee9a'
INTERMEDIATE = '38dc9b712f3e019d46268e1263206dc1ce489560'
PREFIX = 'packages/quds_office_engine/'
WRITER = PREFIX + 'lib/src/word/serial/odt_document_writer.dart'
BOOKMARK_TEST = PREFIX + 'test/odt_bookmark_end_fidelity_test.dart'
COLUMN_TEST = PREFIX + 'test/odt_inline_column_break_fidelity_test.dart'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_bytes(source, path):
    return subprocess.check_output(['git', 'show', source + ':' + path], cwd=REPO)


def output_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


# These early positive attempts preceded a one-line correction to a comment.
# Reconstruct and hash their actual executed source instead of attributing it
# falsely to the final committed file.
early_writer = git_bytes(FINAL, WRITER).replace(
    b'omits, such as an unmodeled TOC cache.',
    b'omits, such as a covered table cell.',
)
(OUT / 'executed-early-bookmark-writer.dart').write_bytes(early_writer)

phases = {
    'incoming-48b6998b': (BASE, False, False),
    'corrected-working': (INTERMEDIATE, False, False),
    'bookmark-incoming-48b': (BASE, False, True),
    'column-corrected': (FINAL, True, False),
    'bookmark-corrected': (FINAL, True, True),
    'bookmark-final-negative-48b': (BASE, False, False),
    'bookmark-final-positive': (FINAL, False, False),
    'final-focused': (FINAL, False, False),
}
bindings = []
for phase, (source, early, old_test) in phases.items():
    receipt = json.loads((WORK / (phase + '-receipt.json')).read_text())
    assert receipt['inputs_before'] == receipt['inputs_after'], phase
    verified = []
    for path, expected in receipt['inputs_before'].items():
        if PREFIX not in path:
            continue
        relative = path[path.index(PREFIX):]
        if relative == WRITER and early:
            data = early_writer
            attribution = 'executed-early-bookmark-writer.dart'
        elif relative == BOOKMARK_TEST and old_test:
            data = (WORK / 'bookmark-attempt1-test.dart').read_bytes()
            attribution = 'bookmark-attempt1-test.dart'
        else:
            attribution = FINAL if '/test/' in relative else source
            data = git_bytes(attribution, relative)
        assert sha(data) == expected, (phase, relative, expected, sha(data))
        verified.append({'path': relative, 'sha256': expected, 'source': attribution})
    events = [json.loads(line) for line in (WORK / (phase + '.jsonl')).read_text().splitlines()
              if line.startswith('{')]
    tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    completions = [e for e in events if e.get('type') == 'testDone']
    substantive = [e for e in completions if not e['hidden']
                   and not tests[e['testID']]['name'].startswith('loading ')
                   and not tests[e['testID']]['name'].endswith(('(setUpAll)', '(tearDownAll)'))]
    assert len({e['testID'] for e in completions}) == len(completions)
    assert set(tests) == {e['testID'] for e in completions}
    counts = dict(collections.Counter(e['result'] for e in substantive))
    bindings.append({
        'phase': phase, 'base_source': source,
        'inputs_unchanged': True, 'verified_files': len(verified),
        'input_bindings': verified, 'counts': counts,
        'skips': sum(e['skipped'] for e in substantive),
        'terminal': [e for e in events if e.get('type') == 'done'],
        'all_started_tests_terminated_once': True,
        'assertion_errors': [e for e in events if e.get('type') == 'error'],
    })
    for suffix in ('.jsonl', '.stderr', '-receipt.json'):
        shutil.copyfile(WORK / (phase + suffix), OUT / (phase + suffix))

focused = json.loads((WORK / 'final-focused-receipt.json').read_text())
assert focused['source_commit'] == FINAL
assert focused['counts'] == {'success': 518} and focused['skips'] == 0
assert len(focused['selected_files']) == 31
assert len(focused['controls']) == 13
assert {str(REPO / path) for path in focused['selected_files']} == set(focused['count_by_file'])
assert focused['all_started_tests_terminated'] and not focused['duplicate_terminal_ids']
output_json('source-bindings.json', bindings)
output_json('final-review.json', {
    'source': FINAL, 'tree': subprocess.check_output(['git', 'rev-parse', FINAL + '^{tree}'], cwd=REPO, text=True).strip(),
    'files': 31, 'passes': 518, 'skips': 0, 'controls': 13,
    'all_selected_files_executed': True, 'all_started_tests_terminated_once': True,
    'negative_final_column_controls': 9, 'negative_final_bookmark_controls': 4,
    'same_final_control_bytes_in_negative_and_final_positive': True,
    'test_hashes': {path: sha(git_bytes(FINAL, path)) for path in [COLUMN_TEST, BOOKMARK_TEST]},
    'scope': 'Focused engine ODT/ODP/ODF tests. This does not qualify a later main/generic-field merge or the host app.',
})
output_json('bookmark-oracle-correction.json', {
    'original_test_sha256': sha((WORK / 'bookmark-attempt1-test.dart').read_bytes()),
    'final_test_sha256': sha(git_bytes(FINAL, BOOKMARK_TEST)),
    'original_failure': 'The fourth newly added probe incorrectly expected covered-cell raw text and its bookmark start to be omitted.',
    'existing_contract': 'ODT table serialization retains raw covered-cell text; only note/comment body expansion is suppressed there. Existing odt_table_merge_test and odt_comment_fidelity_test assert this retained content.',
    'correction': 'Use an unexported TOC cache to exercise a structurally valid start that this bounded writer does not emit. Keep body/table range pairing and covered-cell behavior unchanged.',
    'no_host_or_column_test_changes': True,
    'original_failed_attempt_preserved': True,
    'final_negative_rerun': 'bookmark-final-negative-48b',
    'final_positive': 'final-focused',
})

for path in WORK.iterdir():
    if path.is_file() and (path.name in {
        'run_controls.py', 'run_focused.py', 'qualify_static.py', 'package_evidence.py',
        'bookmark-attempt1-test.dart', 'incoming-package-config.json', 'final-static.json',
    } or path.name.startswith('final-analysis-') or path.name in {'final-format.txt', 'final-whitespace.txt'}):
        shutil.copyfile(path, OUT / path.name)
for path in [COLUMN_TEST, BOOKMARK_TEST]:
    (OUT / Path(path).name).write_bytes(git_bytes(FINAL, path))
(OUT / 'source-correction.patch').write_bytes(subprocess.check_output(
    ['git', 'diff', 'ad09b5dac68d24cb344a86bbb44516193995779f', FINAL, '--',
     PREFIX + 'lib', PREFIX + 'test/odt_inline_column_break_fidelity_test.dart', BOOKMARK_TEST], cwd=REPO))
(OUT / 'qualified-package-config.json').write_bytes((REPO / '.dart_tool/package_config.json').read_bytes())

print(json.dumps({'source': FINAL, 'bindings': [(b['phase'], b['verified_files'], b['counts']) for b in bindings],
                  'evidence_directory': str(OUT)}, indent=2))
