#!/usr/bin/env python3
import argparse
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--engine', type=Path, required=True)
parser.add_argument('--test', type=Path, required=True)
parser.add_argument('--config', type=Path, required=True)
parser.add_argument('--source', required=True)
parser.add_argument('--phase', required=True)
args = parser.parse_args()
root = Path('/workspace/scratch/44ccebb41cba')
out = root / 'quds-audit/inline-column'
runtime = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime')
dart = runtime / 'flutter-sdk/bin/cache/dart-sdk/bin/dart'
test = runtime / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
environment = dict(os.environ, PUB_CACHE=str(runtime / 'pub-cache'),
                   TMPDIR=str(out / 'tmp'), DART_SUPPRESS_ANALYTICS='true')
paths = sorted((args.engine / 'lib').rglob('*.dart')) + [args.test, args.config]


def hashes():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}


command = [str(dart), '--disable-dart-dev', '--packages=' + str(args.config), str(test),
           '--reporter=json', '--concurrency=1', str(args.test)]
receipt = {'phase': args.phase, 'source_commit': args.source, 'command': command,
           'cwd': str(args.engine), 'started': time.time(), 'inputs_before': hashes()}
with (out / (args.phase + '.jsonl')).open('w') as stdout, (out / (args.phase + '.stderr')).open('w') as stderr:
    result = subprocess.run(command, cwd=args.engine, env=environment,
                            stdout=stdout, stderr=stderr, timeout=300)
receipt.update(exit_code=result.returncode, ended=time.time(), inputs_after=hashes())
events = []
for line in (out / (args.phase + '.jsonl')).read_text().splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        pass
tests = {event['test']['id']: event['test']['name'] for event in events if event.get('type') == 'testStart'}
completed = [{'name': tests.get(event['testID']), 'result': event['result'],
              'skipped': event['skipped'], 'hidden': event['hidden']}
             for event in events if event.get('type') == 'testDone']
receipt.update(completed=completed, terminal=[e for e in events if e.get('type') == 'done'])
(out / (args.phase + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'phase': args.phase, 'source': args.source, 'exit_code': result.returncode,
                  'inputs_unchanged': receipt['inputs_before'] == receipt['inputs_after'],
                  'totals': dict(collections.Counter(e['result'] for e in completed if not e['hidden'])),
                  'completed': [e for e in completed if not e['hidden']]}, indent=2))
