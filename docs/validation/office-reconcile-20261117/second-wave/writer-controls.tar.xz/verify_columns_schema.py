#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

from lxml import etree

parser = argparse.ArgumentParser()
parser.add_argument('--engine', type=Path, required=True)
parser.add_argument('--config', type=Path, required=True)
parser.add_argument('--source', required=True)
parser.add_argument('--phase', required=True)
args = parser.parse_args()
root = Path('/workspace/scratch/44ccebb41cba')
out = root / 'quds-audit/second-wave'
runtime = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime')
program = out / 'evidence/make_column_control.dart'
schema_path = root / 'consumer-runtime/schemas/OpenDocument-v1.3-schema.rng'
artifact = out / (args.phase + '-columns.odt')
command = [str(runtime / 'flutter-sdk/bin/cache/dart-sdk/bin/dart'), '--disable-dart-dev',
           '--packages=' + str(args.config), str(program), str(artifact)]
environment = dict(os.environ, PUB_CACHE=str(runtime / 'pub-cache'),
                   TMPDIR=str(out / 'tmp'), DART_SUPPRESS_ANALYTICS='true')
result = subprocess.run(command, cwd=args.engine, env=environment,
                        capture_output=True, text=True, timeout=120)
(out / (args.phase + '-columns.stdout')).write_text(result.stdout)
(out / (args.phase + '-columns.stderr')).write_text(result.stderr)
if result.returncode:
    raise RuntimeError(result.stderr)
with zipfile.ZipFile(artifact) as archive:
    content = archive.read('content.xml')
(out / (args.phase + '-columns-content.xml')).write_bytes(content)
schema = etree.RelaxNG(etree.parse(str(schema_path)))
valid = schema.validate(etree.fromstring(content))
report = {'source': args.source, 'command': command, 'exit_code': result.returncode,
          'program_sha256': hashlib.sha256(program.read_bytes()).hexdigest(),
          'package_config_sha256': hashlib.sha256(args.config.read_bytes()).hexdigest(),
          'schema_path': str(schema_path), 'schema_sha256': hashlib.sha256(schema_path.read_bytes()).hexdigest(),
          'artifact_sha256': hashlib.sha256(artifact.read_bytes()).hexdigest(),
          'content_sha256': hashlib.sha256(content).hexdigest(), 'valid': valid,
          'errors': [{'line': e.line, 'type': e.type_name, 'message': e.message} for e in schema.error_log]}
(out / (args.phase + '-columns-schema.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
