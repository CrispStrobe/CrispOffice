import 'dart:io';

import 'package:quds_office_engine/quds_office_engine.dart';

void main(List<String> args) {
  final document = WmlDocument(
    sections: [
      WmlSection(
        columnCount: 2,
        columnSpace: 18,
        blocks: [
          WmlParagraph(inlines: [WmlRun(text: 'Column source control')]),
        ],
      ),
    ],
  );
  File(args.single).writeAsBytesSync(OdtDocumentWriter.writeBytes(document));
}
