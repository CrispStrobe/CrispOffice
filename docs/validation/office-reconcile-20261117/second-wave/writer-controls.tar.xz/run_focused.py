#!/usr/bin/env python3
"""Run all current ODT, ODP and shared ODF files against the committed source."""
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/scratch/44ccebb41cba')
repo = root / 'quds_office_suite'
engine = repo / 'packages/quds_office_engine'
out = root / 'quds-audit/second-wave'
runtime = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime')
dart = runtime / 'flutter-sdk/bin/cache/dart-sdk/bin/dart'
entrypoint = runtime / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
config = repo / '.dart_tool/package_config.json'
tests = sorted({path for prefix in ('odt_', 'odp_', 'odf_')
                for path in (engine / 'test').glob(prefix + '*_test.dart')})
paths = sorted((engine / 'lib').rglob('*.dart')) + tests + [config]


def hashes():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}


command = [str(dart), '--disable-dart-dev', '--packages=' + str(config), str(entrypoint),
           '--reporter=json', '--concurrency=1', *map(str, tests)]
source = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD']).decode().strip()
receipt = {'source_commit': source, 'command': command, 'cwd': str(engine),
           'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'selected_files': [str(path.relative_to(repo)) for path in tests],
           'inputs_before': hashes(), 'started': time.time()}
environment = dict(os.environ, PUB_CACHE=str(runtime / 'pub-cache'),
                   TMPDIR=str(out / 'tmp'), DART_SUPPRESS_ANALYTICS='true')
with (out / 'final-focused.jsonl').open('w') as stdout, (out / 'final-focused.stderr').open('w') as stderr:
    result = subprocess.run(command, cwd=engine, env=environment,
                            stdout=stdout, stderr=stderr, timeout=300)
receipt.update(exit_code=result.returncode, ended=time.time(), inputs_after=hashes())
events = []
for line in (out / 'final-focused.jsonl').read_text().splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        pass
tests_by_id = {event['test']['id']: event['test'] for event in events if event.get('type') == 'testStart'}
suites = {event['suite']['id']: event['suite']['path'] for event in events if event.get('type') == 'suite'}
completed = []
for event in events:
    if event.get('type') != 'testDone':
        continue
    test = tests_by_id.get(event['testID'], {})
    name = test.get('name', '')
    completed.append({'id': event['testID'], 'name': name, 'result': event['result'],
                      'skipped': event['skipped'], 'hidden': event['hidden'],
                      'suite': suites.get(test.get('suiteID')),
                      'administrative': event['hidden'] or name.startswith('loading ')
                          or name.endswith('(setUpAll)') or name.endswith('(tearDownAll)')})
receipt.update(completed=completed, terminal=[e for e in events if e.get('type') == 'done'])
substantive = [e for e in completed if not e['administrative']]
receipt['counts'] = dict(collections.Counter(e['result'] for e in substantive if not e['skipped']))
receipt['skips'] = sum(e['skipped'] for e in substantive)
receipt['count_by_file'] = dict(collections.Counter(e['suite'] for e in substantive))
receipt['controls'] = [e for e in substantive if e['suite'].endswith('odt_columns_breaks_fidelity_test.dart')]
receipt['all_started_tests_terminated'] = set(tests_by_id) == {e['id'] for e in completed}
receipt['duplicate_terminal_ids'] = [k for k, n in collections.Counter(e['id'] for e in completed).items() if n > 1]
(out / 'final-focused-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'source': source, 'exit_code': result.returncode, 'files': len(tests),
                  'inputs_unchanged': receipt['inputs_before'] == receipt['inputs_after'],
                  'counts': receipt['counts'], 'skips': receipt['skips'],
                  'all_started_tests_terminated': receipt['all_started_tests_terminated'],
                  'controls': receipt['controls'],
                  'failures': [e for e in substantive if e['result'] != 'success']}, indent=2))
