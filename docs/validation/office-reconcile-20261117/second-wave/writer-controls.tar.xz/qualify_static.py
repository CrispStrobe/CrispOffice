#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/workspace/scratch/44ccebb41cba')
repo = root / 'quds_office_suite'
out = root / 'quds-audit/second-wave'
dart = '/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/flutter-sdk/bin/cache/dart-sdk/bin/dart'
targets = ['packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart',
           'packages/quds_office_engine/test/odt_columns_breaks_fidelity_test.dart']
commands = [('analysis-' + str(i), [dart, 'analyze', '--fatal-infos', path])
            for i, path in enumerate(targets)]
commands += [('format', [dart, 'format', '--output=none', '--set-exit-if-changed', *targets]),
             ('whitespace', ['git', 'diff', '--check', 'eaa0f92a016e0d39426af19e52b1f3454d77693a', 'HEAD'])]
report = {'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
          'inputs': {path: hashlib.sha256((repo / path).read_bytes()).hexdigest() for path in targets},
          'commands': []}
for name, command in commands:
    result = subprocess.run(command, cwd=repo, capture_output=True, text=True, timeout=120)
    (out / ('final-' + name + '.txt')).write_text(result.stdout + result.stderr)
    report['commands'].append({'name': name, 'command': command, 'exit_code': result.returncode})
report['inputs_unchanged'] = report['inputs'] == {
    path: hashlib.sha256((repo / path).read_bytes()).hexdigest() for path in targets}
report['passed'] = report['inputs_unchanged'] and all(x['exit_code'] == 0 for x in report['commands'])
(out / 'final-static.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
