import collections
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

REPO = pathlib.Path('/workspace/scratch/44ccebb41cba/quds_office_suite')
AUDIT = pathlib.Path('/workspace/scratch/44ccebb41cba/quds-audit')
RUNTIME = pathlib.Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime')
OUT = AUDIT / 'style-regression'
HARNESS = AUDIT / 'harness'
phase = sys.argv[1]
paths = sys.argv[2:] or ['packages/quds_office_engine/test/odt_table_tab_fidelity_test.dart']
dart = RUNTIME / 'flutter-sdk/bin/cache/dart-sdk/bin/dart'
test = RUNTIME / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
config = pathlib.Path(os.environ.get('ODT_TEST_CONFIG', str(HARNESS / '.dart_tool/package_config.json')))
writer = pathlib.Path(os.environ.get('ODT_WRITER_SOURCE', str(REPO / 'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart')))
command = [str(dart), '--disable-dart-dev', '--packages=' + str(config), str(test), '--reporter=json', '--concurrency=1', *[str(REPO / p) for p in paths]]
environment = dict(os.environ, PUB_CACHE=str(RUNTIME / 'pub-cache'), TMPDIR=str(AUDIT / 'tmp'), DART_SUPPRESS_ANALYTICS='true')
(AUDIT / 'tmp').mkdir(exist_ok=True)
OUT.mkdir(exist_ok=True)
input_paths = ['packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart', *paths]
def inputs():
    return {p: hashlib.sha256((writer if p.endswith('/lib/src/word/serial/odt_document_writer.dart') else REPO / p).read_bytes()).hexdigest() for p in input_paths}
cwd = REPO / 'packages/quds_office_engine'
receipt = dict(phase=phase, source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(), writer_source=str(writer), package_config_sha256=hashlib.sha256(config.read_bytes()).hexdigest(), command=command, cwd=str(cwd), inputs_before=inputs(), started=time.time())
with (OUT / (phase + '.jsonl')).open('w') as stdout, (OUT / (phase + '.stderr')).open('w') as stderr:
    result = subprocess.run(command, cwd=cwd, env=environment, stdout=stdout, stderr=stderr, timeout=300)
receipt.update(exit_code=result.returncode, ended=time.time(), inputs_after=inputs())
events = []
for line in (OUT / (phase + '.jsonl')).read_text().splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        pass
tests = {e['test']['id']: e['test']['name'] for e in events if e.get('type') == 'testStart'}
completed = [dict(id=e['testID'], name=tests.get(e['testID']), result=e['result'], skipped=e['skipped'], hidden=e['hidden']) for e in events if e.get('type') == 'testDone']
receipt.update(completed=completed, terminal=[e for e in events if e.get('type') == 'done'])
(OUT / (phase + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(dict(phase=phase, exit_code=result.returncode, duration=receipt['ended']-receipt['started'], totals=dict(collections.Counter(e['result'] for e in completed if not e['hidden'])), terminal=receipt['terminal'], failures=[e for e in completed if e['result'] != 'success']), indent=2))
if result.returncode:
    print((OUT / (phase + '.stderr')).read_text()[-2000:])
    print((OUT / (phase + '.jsonl')).read_text()[-4000:])
