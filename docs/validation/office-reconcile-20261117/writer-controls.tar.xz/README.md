# ODT tab and table style repair

The repaired source is published as `60a116d2df566793720bfb4f76d7f6523529bcb2`,
following the combined incoming source
`b9bfe664a4efe4128a47792a1ea2cce16c7dd2c8`. Local source commit
`d4589966d5b22de2fa5000369d46778ba9fdac29` and that remote checkpoint have the
exact same tree `a4ea1790fb02fd414fdfd0bcb5e87e07e07de39c`; publication changed
commit metadata only. The source equality record preserves both identities.

## Defects and changes

The newly integrated tab-stop export omitted custom tabs from paragraph-style
cache identity. A preceding plain paragraph could suppress every later custom
tab, while differing tab positions, alignment and leaders could alias one style.
The cache now includes the normalized serialized positions and the authored
alignment/leader values in source order. Invalid positions are omitted before
both caching and serialization. Signed positions remain allowed by ODF.
Exact dot, hyphen and underscore leader characters use `style:leader-text`.

The table row height in the existing model is a minimum: its DOCX serializer
writes `w:hRule="atLeast"` and layout takes the maximum of the specified height
and cell content. Export now uses `style:min-row-height` instead of a fixed
`style:row-height`. Nonfinite, negative or exponent-valued row minima are
omitted. Zero minima remain valid, including a normalized signed zero.
Column widths must remain positive after the existing two-decimal rounding;
invalid widths leave the original column and its cell content present without
an invalid width attribute.

Cell fills now use the same six-ASCII-hex RGB validation as paragraph colors.
Invalid fills cannot inject XML attributes or markup, and omission of an
invalid fill preserves independently specified cell borders and visible text.
All of these changes leave source model objects unchanged.

## Paired regression evidence

The final-format test file has SHA-256
`6250ae71be0f2ea8d4154ffdb8eb9aca1f3b0d3b7f6f5fbad4cf8964c7708ece`.
The same exact bytes run in both final source conditions:

| Run | Result |
| --- | --- |
| Incoming engine library at `b9bfe664`, isolated overlay | 9 failing cases: 3 absent-tab errors and 6 assertion failures; 1 passing valid-color control |
| Repaired source, complete 19-file ODT/ODF cohort | 351 passed, zero failures or skips; includes all 10 paired cases |
| Strict analysis of the three changed Dart files | All passed with fatal infos enabled |
| Formatting under the workspace's Dart language version 3.12 | All three files unchanged by formatter |

The paired cases inspect tab position/type/character and leader attributes,
minimum-height semantics, invalid numeric dimensions, normalized/invalid cell
colors, retained borders, document text and source model values. The complete
cohort includes the original PAGE, decoration, note/comment, section/list,
table-merge, annotation and text-extraction cases.

`control-source-equivalence.json` proves that the isolated incoming engine
library and repaired engine library differ only in the writer file, binds the
committed test bytes, and verifies unchanged test/writer inputs across both
runs. The exact package maps, runner, raw JSON events, stderr and per-run
receipts are retained beside this report. Earlier executions are not added to
the final 351-case count.

## Retained setup and development attempts

The first launcher attempt invoked `dart run`, which attempted dependency setup
and failed before tests because this sandbox does not have `/tmp`. It is retained
as `setup-attempt.*`. Subsequent runs invoke the already cached test entrypoint
directly with an explicit package map and writable `TMPDIR`; no dependency
resolution is used.

The first broad run used the harness working directory and recorded 350 passes
plus one missing relative Zotero-fixture error. That entire failed run remains
as `odt-odf.*`. The accepted run uses the engine package as its working directory
and passes the original fixture-backed case without changing its assertions.

The first paired run used the formatter's fallback language version because
the fresh checkout lacked a package map. Restoring the locked map made the
formatter honor the workspace's language version 3.12. The test's formatting
changed, so the negative control was repeated with the final exact bytes in an
isolated incoming-source overlay. Both old and final-format test sources and
all original attempts remain preserved.

## Contract sources and limits

The official [ODF 1.3 schema](https://docs.oasis-open.org/office/OpenDocument/v1.3/os/schemas/OpenDocument-v1.3-schema-rng.html)
defines signed tab positions, nonnegative row minima and positive column widths.
[ODF 1.3 Part 3](https://docs.oasis-open.org/office/OpenDocument/v1.3/os/part3-schema/OpenDocument-v1.3-os-part3-schema.html),
sections 19.490, 20.320 and 20.348 define exact tab leader characters, minimum
row height and fixed row height respectively. `source-contracts.json` records
these references and the matching model/DOCX behavior.

These results establish source and serialized contracts. They do not claim an
observed LibreOffice or Word rendering/roundtrip for this newly repaired source;
consumer results must be reported separately. No GitHub CI endpoint was queried
or awaited.
