# ODF negative control

The retained 22-case test versions ran on the integrated source recorded in
`source.json` and `receipt.json`: 21 assertion failures, 1 passing block-visual
control, no test errors or skips. The four production files match the recorded
commit exactly. No GitHub Actions were used.

The baseline predates the later legal signed-zero/padded-count case and optional
fixture output. It therefore does not claim to run all 23 final added cases.
The final scoped cohort includes those 23 plus existing writer, search and
builder tests, recorded separately under `odf-qualification/`.

Two preliminary runs failed to compile the structural test because its fixture
used a nonexistent visual enum value. Their logs are retained in `attempt-*`
and excluded from the valid negative-control count. The final baseline uses
`OfficeVisualKind.chartColumn`; the test snapshots at this directory root are
its exact inputs.
