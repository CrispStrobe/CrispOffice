import 'dart:convert';
import 'dart:typed_data';

import '../../office/office_document_properties.dart';
import '../../opc/content_types.dart';
import '../../opc/opc_archive.dart';
import '../../opc/package_part.dart';
import '../../opc/relationships.dart';
import '../../visual/sheet_chart_data.dart';
import '../../xml/namespaces.dart';
import '../../xml/xml_node.dart';
import '../../xml/xml_reader.dart';
import '../../xml/xml_writer.dart';
import '../formula/dep_graph.dart';
import '../formula/formula_eval.dart';
import '../formula/formula_refs.dart';
import '../model/sml_analysis.dart';
import '../model/sml_conditional_format.dart';
import '../model/sml_sparkline.dart';
import '../model/sml_workbook.dart';
import '../shared_strings.dart';
import '../styles/sml_styles.dart';
import 'sheet_drawing_io.dart';

part 'sheet_package_fidelity.dart';

bool _hasOtherPartReference(
  OpcPackage package,
  String targetUri, {
  String? ignoredSourceUri,
  String? ignoredRelationshipId,
}) {
  bool references(RelationshipCollection relationships) {
    return relationships.items.any((relationship) {
      if (relationships.sourcePartUri == ignoredSourceUri &&
          relationship.id == ignoredRelationshipId) {
        return false;
      }
      return relationship.targetMode == RelationshipTargetMode.internal &&
          relationships.resolve(relationship) == targetUri;
    });
  }

  return references(package.packageRelationships) ||
      package.parts.any(
        (part) => references(package.relationshipsFor(part.uri)),
      );
}

PackagePart? _sheetCommentsPart(
  SmlWorksheet sheet,
  OpcPackage package,
  String sheetUri,
) {
  final relationships = package.relationshipsFor(sheetUri);
  final links = relationships.byType(RelationshipTypes.comments).toList();
  if (links.length > 1) {
    throw const FormatException('Multiple worksheet comments relationships.');
  }
  PackagePart? part;
  if (links.isEmpty) {
    // Older Quds packages omitted the relationship. Keep that bounded fallback
    // only for a genuine comments part not owned by another relationship.
    part = package.getPart('/xl/comments${sheet.sheetId}.xml');
    if (part == null ||
        part.contentType != OfficeContentTypes.sheetComments ||
        _hasOtherPartReference(package, part.uri)) {
      return null;
    }
  } else {
    final link = links.single;
    final target = Uri.tryParse(link.target);
    if (link.targetMode != RelationshipTargetMode.internal ||
        target == null ||
        target.path.isEmpty ||
        target.hasScheme ||
        target.hasAuthority ||
        target.hasQuery ||
        target.hasFragment) {
      throw const FormatException(
        'Invalid internal worksheet comments target.',
      );
    }
    part = package.getPart(relationships.resolve(link));
    if (part == null || part.contentType != OfficeContentTypes.sheetComments) {
      throw const FormatException(
        'Missing or invalid worksheet comments part.',
      );
    }
  }
  final reader = XmlPullReader(part.readText());
  while (reader.next()) {
    if (reader.eventType != XmlEventType.startElement) continue;
    if (reader.localName == 'comments' &&
        (reader.namespaceUri.isEmpty ||
            reader.namespaceUri == OfficeNamespaces.x)) {
      return part;
    }
    break;
  }
  throw const FormatException('Invalid worksheet comments root element.');
}

/// Class SheetDeserializer.
class SheetDeserializer {
  /// Font lookup stays with the caller; null leaves the documented 7px fallback.
  SheetDeserializer({this.columnMetricsResolver});

  final SmlColumnMetricsResolver? columnMetricsResolver;

  /// read API.
  SmlWorkbook read(OpcPackage package) {
    package.assertUnsignedForEditing();
    final SharedStringTable sst =
        package.getPart('/xl/sharedStrings.xml') == null
        ? SharedStringTable()
        : SharedStringTable.parse(
            package.getPart('/xl/sharedStrings.xml')!.readText(),
          );
    SmlStyleSheet? styles;
    if (package.getPart('/xl/styles.xml') != null) {
      List<String>? theme;
      Map<String, String>? themeFonts;
      final PackagePart? themePart = package.getPart('/xl/theme/theme1.xml');
      if (themePart != null) {
        theme = SmlStyleSheet.parseTheme(themePart.readText());
        themeFonts = SmlStyleSheet.parseThemeFontFamilies(themePart.readText());
      }
      styles = SmlStyleSheet.parse(
        package.getPart('/xl/styles.xml')!.readText(),
        themeColors: theme,
        themeFontFamilies: themeFonts,
      );
    }
    final SmlWorkbook book = SmlWorkbook(
      sheets: <SmlWorksheet>[],
      sharedStrings: sst.values,
      package: package,
      styles: styles,
      properties: OfficeDocumentProperties.fromPackage(package),
    );
    final PackagePart? wb = package.getPart('/xl/workbook.xml');
    if (wb == null) {
      return book;
    }
    final RelationshipCollection rels = package.relationshipsFor(
      '/xl/workbook.xml',
    );
    final XmlPullReader reader = XmlPullReader(wb.readText());
    while (reader.next()) {
      if (reader.eventType != XmlEventType.startElement ||
          reader.localName != 'sheet') {
        continue;
      }
      final String name = reader.getAttribute('name') ?? 'Sheet';
      final int id = int.parse(reader.getAttribute('sheetId') ?? '1');
      final String? rid = reader.getAttribute(
        'id',
        namespaceUri: OfficeNamespaces.r,
      );
      final SmlWorksheet sheet = SmlWorksheet(name: name, sheetId: id)
        ..hidden = switch (reader.getAttribute('state')) {
          'hidden' || 'veryHidden' => true,
          _ => false,
        };
      if (rid != null) {
        final PackageRelationship? rel = rels.byId(rid);
        if (rel != null) {
          final String uri = rels.resolve(rel);
          sheet.sourcePartUri = uri;
          final PackagePart? part = package.getPart(uri);
          if (part != null) {
            _readSheet(part.readText(), sheet, sst, package, uri, styles);
          }
        }
      }
      book.sheets.add(sheet);
    }
    if (book.sheets.isEmpty) {
      book.sheets.add(SmlWorksheet(name: 'Sheet1', sheetId: 1));
    }
    final resolver = columnMetricsResolver;
    if (resolver != null) book.resolveColumnMetrics(resolver);
    _readDefinedNames(wb.readText(), book);
    book.sourceDefinedNameState = book.definedNameState();
    SheetChartData.refreshWorkbook(book);
    for (final sheet in book.sheets) {
      for (final drawing in sheet.drawings) {
        if (drawing.sourceChartPartUri != null) {
          drawing.sourceChartState = SheetDrawingIo.chartState(drawing, sheet);
        }
      }
    }
    return book;
  }

  /// readBytes API.
  SmlWorkbook readBytes(Uint8List bytes, {String? password}) =>
      read(OpcPackage.openBytes(bytes, password: password));

  static void _readDefinedNames(String xml, SmlWorkbook book) {
    final names = XmlDocument.parse(xml).root?.firstChild('definedNames');
    if (names == null) return;
    // Relative references depend on the definition's active-cell origin.
    // Project only absolute in-workbook A1 references; retain every other
    // definition as authored so an unsupported local still shadows a global.
    final absoluteReference = RegExp(
      r"^('(?:[^']|'')+'|[\p{L}_][\p{L}\p{N}_.]*)!(\$[A-Za-z]+\$[1-9]\d*(?::\$[A-Za-z]+\$[1-9]\d*)?)$",
      unicode: true,
    );
    for (final element in names.childrenNamed('definedName')) {
      final name = element.getAttribute('name');
      if (name == null) continue;
      final raw = element.text;
      final scope = element.getAttribute('localSheetId');
      if (name == '_xlnm.Print_Titles') {
        _applyPrintTitles(book, raw.trim(), scope);
        continue;
      }
      if (name == '_xlnm.Print_Area') {
        _applyPrintArea(book, raw.trim(), scope);
        continue;
      }
      final localSheetId = scope == null ? null : (int.tryParse(scope) ?? -1);
      final attributes = <String, String>{
        for (final attribute in element.attributes)
          if (attribute.qualifiedName != 'name' &&
              attribute.qualifiedName != 'localSheetId')
            attribute.qualifiedName: attribute.value,
      };
      final match = absoluteReference.firstMatch(raw.trim());
      if (match != null) {
        var sheetName = match[1]!;
        if (sheetName.startsWith("'")) {
          sheetName = sheetName
              .substring(1, sheetName.length - 1)
              .replaceAll("''", "'");
        }
        final range = SmlRange.parse(match[2]!);
        if (!sheetName.contains(RegExp(r'[\[\]:]')) &&
            range.maxCol < 16384 &&
            range.maxRow < 1048576) {
          book.namedRanges.add(
            SmlNamedRange(
              name: name,
              sheetName: sheetName,
              range: range,
              localSheetId: localSheetId,
              attributes: attributes,
            ),
          );
          continue;
        }
      }
      book.formulaNames.add(
        SmlFormulaName(
          name: name,
          formula: raw,
          localSheetId: localSheetId,
          attributes: attributes,
        ),
      );
    }
  }

  static void _applyPrintTitles(
    SmlWorkbook book,
    String raw,
    String? localSheetId,
  ) {
    SmlWorksheet? sheet;
    final int? idx = int.tryParse(localSheetId ?? '');
    if (idx != null && idx >= 0 && idx < book.sheets.length) {
      sheet = book.sheets[idx];
    }
    for (final String part in raw.split(',')) {
      final String token = part.trim();
      final int bang = token.lastIndexOf('!');
      if (bang <= 0) {
        continue;
      }
      var sheetName = token.substring(0, bang);
      if (sheetName.startsWith("'") && sheetName.endsWith("'")) {
        sheetName = sheetName.substring(1, sheetName.length - 1);
      }
      sheet ??= () {
        for (final SmlWorksheet s in book.sheets) {
          if (s.name == sheetName) {
            return s;
          }
        }
        return null;
      }();
      if (sheet == null) {
        continue;
      }
      final String ref = token.substring(bang + 1).replaceAll('\$', '');
      final Match? rows = RegExp(r'^(\d+):(\d+)$').firstMatch(ref);
      if (rows != null) {
        final int r0 = int.parse(rows.group(1)!) - 1;
        final int r1 = int.parse(rows.group(2)!) - 1;
        sheet.printTitleRows = SmlRange(SmlCellRef(0, r0), SmlCellRef(0, r1));
        continue;
      }
      final Match? cols = RegExp(r'^([A-Za-z]+):([A-Za-z]+)$').firstMatch(ref);
      if (cols != null) {
        final int c0 = SmlCellRef.parse('${cols.group(1)}1').col;
        final int c1 = SmlCellRef.parse('${cols.group(2)}1').col;
        sheet.printTitleCols = SmlRange(SmlCellRef(c0, 0), SmlCellRef(c1, 0));
      }
    }
  }

  static void _applyPrintArea(
    SmlWorkbook book,
    String raw,
    String? localSheetId,
  ) {
    if (raw.isEmpty) return;
    SmlWorksheet? sheet;
    final idx = int.tryParse(localSheetId ?? '');
    if (idx != null && idx >= 0 && idx < book.sheets.length) {
      sheet = book.sheets[idx];
    }
    final bang = raw.lastIndexOf('!');
    if (bang <= 0) return;
    var sheetName = raw.substring(0, bang).trim();
    if (sheetName.startsWith("'") && sheetName.endsWith("'")) {
      sheetName = sheetName
          .substring(1, sheetName.length - 1)
          .replaceAll("''", "'");
    }
    sheet ??= book.sheetByName(sheetName);
    if (sheet == null) return;
    final ref = raw.substring(bang + 1).replaceAll('\$', '').trim();
    try {
      sheet.printArea = SmlRange.parse(ref);
    } on FormatException {
      // Leave an unparseable print area untouched.
    }
  }

  static String _elementText(XmlPullReader reader) {
    if (reader.isEmptyElement) {
      return '';
    }
    final int depth = reader.depth;
    final StringBuffer buffer = StringBuffer();
    while (reader.next() && reader.depth >= depth) {
      if (reader.eventType == XmlEventType.characters ||
          reader.eventType == XmlEventType.cdata) {
        buffer.write(reader.text);
      }
    }
    return buffer.toString();
  }

  static void _applyHeaderFooterSection(
    SmlHeaderFooter hf,
    String raw, {
    required bool header,
  }) {
    // Formatting codes (`&"Arial,Bold"`, `&12`, `&B`, `&&`) stay in the
    // section text; only `&L` / `&C` / `&R` switch sections.
    final Map<String, StringBuffer> sections = <String, StringBuffer>{
      'L': StringBuffer(),
      'C': StringBuffer(),
      'R': StringBuffer(),
    };
    StringBuffer current = sections['C']!;
    var i = 0;
    while (i < raw.length) {
      final String ch = raw[i];
      if (ch != '&' || i + 1 >= raw.length) {
        current.write(ch);
        i++;
        continue;
      }
      final String code = raw[i + 1];
      final StringBuffer? target = sections[code];
      if (target != null) {
        current = target;
        i += 2;
      } else if (code == '"') {
        final int close = raw.indexOf('"', i + 2);
        final int end = close < 0 ? raw.length : close + 1;
        current.write(raw.substring(i, end));
        i = end;
      } else {
        current.write(raw.substring(i, i + 2));
        i += 2;
      }
    }
    final String left = sections['L'].toString();
    final String center = sections['C'].toString();
    final String right = sections['R'].toString();
    if (header) {
      hf
        ..headerLeft = left
        ..headerCenter = center
        ..headerRight = right;
    } else {
      hf
        ..footerLeft = left
        ..footerCenter = center
        ..footerRight = right;
    }
  }

  void _readSheet(
    String xml,
    SmlWorksheet sheet,
    SharedStringTable sst,
    OpcPackage package,
    String sheetUri,
    SmlStyleSheet? styles,
  ) {
    final XmlPullReader reader = XmlPullReader(xml);
    SmlCell? current;
    String? valueType;
    // `t="shared"` masters by `si`: formula text and the cell it is written for.
    final Map<String, ({String formula, SmlCellRef anchor})> shared =
        <String, ({String formula, SmlCellRef anchor})>{};
    SmlPageSetup? pageSetup;
    SmlPageSetup ensurePageSetup() => pageSetup ??= SmlPageSetup();
    SmlRange? conditionalRange;
    SmlConditionalRule? conditionalRule;
    while (reader.next()) {
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'sheetView') {
        final String? rtl = reader.getAttribute('rightToLeft');
        sheet.rightToLeft = rtl == '1' || rtl?.toLowerCase() == 'true';
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'autoFilter') {
        final String? ref = reader.getAttribute('ref');
        if (ref != null && ref.isNotEmpty) {
          sheet.autoFilter = SmlAutoFilter(range: SmlRange.parse(ref));
        }
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'sheetProtection') {
        sheet.protection = SmlSheetProtection(enabled: true);
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'oddHeader') {
        sheet.headerFooter ??= SmlHeaderFooter();
        final String text = _elementText(reader);
        _applyHeaderFooterSection(sheet.headerFooter!, text, header: true);
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'oddFooter') {
        sheet.headerFooter ??= SmlHeaderFooter();
        final String text = _elementText(reader);
        _applyHeaderFooterSection(sheet.headerFooter!, text, header: false);
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'tabColor') {
        final rgb = reader.getAttribute('rgb');
        if (rgb != null) {
          final hex = rgb.length == 8 ? rgb.substring(2) : rgb;
          if (RegExp(r'^[0-9A-Fa-f]{6}$').hasMatch(hex)) {
            sheet.tabColorRgb = hex.toUpperCase();
          }
        }
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'dataValidation') {
        final String? sqref = reader.getAttribute('sqref');
        final String type = reader.getAttribute('type') ?? 'custom';
        if (sqref != null && sqref.isNotEmpty) {
          sheet.validations.add(
            SmlDataValidation(
              range: SmlRange.parse(sqref.split(' ').first),
              kind: switch (type) {
                'list' => SmlValidationKind.list,
                'whole' => SmlValidationKind.whole,
                'decimal' => SmlValidationKind.decimal,
                'date' => SmlValidationKind.date,
                'textLength' => SmlValidationKind.textLength,
                _ => SmlValidationKind.custom,
              },
              formula1: '',
              operator: switch (reader.getAttribute('operator')) {
                'notBetween' => SmlValidationOperator.notBetween,
                'equal' => SmlValidationOperator.equal,
                'notEqual' => SmlValidationOperator.notEqual,
                'greaterThan' => SmlValidationOperator.greaterThan,
                'lessThan' => SmlValidationOperator.lessThan,
                'greaterThanOrEqual' =>
                  SmlValidationOperator.greaterThanOrEqual,
                'lessThanOrEqual' => SmlValidationOperator.lessThanOrEqual,
                _ => SmlValidationOperator.between,
              },
              allowBlank: reader.getAttribute('allowBlank') != '0',
              promptTitle: reader.getAttribute('promptTitle') ?? '',
              prompt: reader.getAttribute('prompt') ?? '',
              errorStyle: reader.getAttribute('errorStyle') ?? 'stop',
            ),
          );
        }
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'formula1' &&
          sheet.validations.isNotEmpty) {
        sheet.validations.last.formula1 = _readText(reader);
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'formula2' &&
          sheet.validations.isNotEmpty) {
        sheet.validations.last.formula2 = _readText(reader);
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'formula' &&
          conditionalRule != null) {
        final text = _readText(reader);
        if (conditionalRule.formula.isEmpty) {
          conditionalRule.formula = text;
        } else if (conditionalRule.formula2.isEmpty) {
          conditionalRule.formula2 = text;
        }
      }
      if (reader.eventType == XmlEventType.endElement &&
          reader.localName == 'cfRule') {
        conditionalRule = null;
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'conditionalFormatting') {
        final String? sqref = reader.getAttribute('sqref');
        conditionalRange = sqref == null || sqref.isEmpty
            ? null
            : SmlRange.parse(sqref.split(' ').first);
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'cfRule' &&
          conditionalRange != null) {
        final type = reader.getAttribute('type') ?? '';
        final operator = reader.getAttribute('operator') ?? '';
        SmlConditionalKind? kind;
        final text = reader.getAttribute('text') ?? '';
        switch (type) {
          case 'cellIs':
            kind = switch (operator) {
              'greaterThan' => SmlConditionalKind.greaterThan,
              'greaterThanOrEqual' => SmlConditionalKind.greaterOrEqual,
              'lessThan' => SmlConditionalKind.lessThan,
              'lessThanOrEqual' => SmlConditionalKind.lessOrEqual,
              'equal' => SmlConditionalKind.equal,
              'notEqual' => SmlConditionalKind.notEqual,
              'between' => SmlConditionalKind.between,
              'notBetween' => SmlConditionalKind.notBetween,
              _ => null,
            };
          case 'containsText':
            kind = SmlConditionalKind.contains;
          case 'expression':
            kind = SmlConditionalKind.expression;
          case 'beginsWith':
            kind = SmlConditionalKind.beginsWith;
          case 'endsWith':
            kind = SmlConditionalKind.endsWith;
          case 'duplicateValues':
            kind = SmlConditionalKind.duplicate;
          case 'top10':
            final bottom = _readBoolean(reader.getAttribute('bottom'));
            final percent = _readBoolean(reader.getAttribute('percent'));
            kind = bottom
                ? (percent
                      ? SmlConditionalKind.bottomPercent
                      : SmlConditionalKind.bottom)
                : (percent
                      ? SmlConditionalKind.topPercent
                      : SmlConditionalKind.top);
          case 'aboveAverage':
            kind =
                _readBoolean(
                  reader.getAttribute('aboveAverage'),
                  defaultValue: true,
                )
                ? SmlConditionalKind.aboveAverage
                : SmlConditionalKind.belowAverage;
        }
        if (kind == null) continue;
        final dxfId = int.tryParse(reader.getAttribute('dxfId') ?? '');
        final dxfFill =
            dxfId != null &&
                styles != null &&
                dxfId >= 0 &&
                dxfId < styles.dxfFills.length
            ? styles.dxfFills[dxfId]
            : '';
        final dxfFont =
            dxfId != null &&
                styles != null &&
                dxfId >= 0 &&
                dxfId < styles.dxfFonts.length
            ? styles.dxfFonts[dxfId]
            : '';
        conditionalRule = SmlConditionalRule(
          range: conditionalRange,
          kind: kind,
          formula: text,
          rank: int.tryParse(reader.getAttribute('rank') ?? '') ?? 10,
          priority: int.tryParse(reader.getAttribute('priority') ?? ''),
          stopIfTrue: _readBoolean(reader.getAttribute('stopIfTrue')),
          fillRgb: dxfFill,
          fontRgb: dxfFont,
          dxfId: dxfId,
        );
        sheet.conditionalFormats.add(conditionalRule);
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'pane') {
        // xSplit/ySplit are positional (1/20 pt) for frozen panes: Excel can
        // write xSplit="1" while the frozen area is 36 columns wide. The
        // authoritative anchor for a frozen pane is topLeftCell.
        final String? state = reader.getAttribute('state');
        final String? topLeft = reader.getAttribute('topLeftCell');
        if (topLeft != null &&
            (state == null || state == 'frozen' || state == 'frozenSplit')) {
          final SmlCellRef anchor = SmlCellRef.parse(topLeft);
          sheet.freezeCols = anchor.col.clamp(
            0,
            SmlWorksheet.excelColumnCount - 1,
          );
          sheet.freezeRows = anchor.row.clamp(
            0,
            SmlWorksheet.excelRowCount - 1,
          );
        } else {
          final int x = int.tryParse(reader.getAttribute('xSplit') ?? '0') ?? 0;
          final int y = int.tryParse(reader.getAttribute('ySplit') ?? '0') ?? 0;
          sheet.freezeCols = x.clamp(0, SmlWorksheet.excelColumnCount - 1);
          sheet.freezeRows = y.clamp(0, SmlWorksheet.excelRowCount - 1);
        }
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'printOptions') {
        final setup = ensurePageSetup();
        setup.printHeadings = reader.getAttribute('headings') == '1';
        setup.printGridlines = reader.getAttribute('gridLines') == '1';
        setup.centerHorizontally =
            reader.getAttribute('horizontalCentered') == '1';
        setup.centerVertically = reader.getAttribute('verticalCentered') == '1';
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'pageMargins') {
        final setup = ensurePageSetup();
        setup.marginLeftIn =
            double.tryParse(reader.getAttribute('left') ?? '') ??
            setup.marginLeftIn;
        setup.marginRightIn =
            double.tryParse(reader.getAttribute('right') ?? '') ??
            setup.marginRightIn;
        setup.marginTopIn =
            double.tryParse(reader.getAttribute('top') ?? '') ??
            setup.marginTopIn;
        setup.marginBottomIn =
            double.tryParse(reader.getAttribute('bottom') ?? '') ??
            setup.marginBottomIn;
        setup.headerMarginIn =
            double.tryParse(reader.getAttribute('header') ?? '') ??
            setup.headerMarginIn;
        setup.footerMarginIn =
            double.tryParse(reader.getAttribute('footer') ?? '') ??
            setup.footerMarginIn;
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'pageSetup') {
        final setup = ensurePageSetup();
        setup.orientation = reader.getAttribute('orientation') == 'landscape'
            ? SmlPageOrientation.landscape
            : SmlPageOrientation.portrait;
        setup.paperSize =
            int.tryParse(reader.getAttribute('paperSize') ?? '') ??
            setup.paperSize;
        setup.scale =
            int.tryParse(reader.getAttribute('scale') ?? '') ?? setup.scale;
        setup.fitToWidth =
            int.tryParse(reader.getAttribute('fitToWidth') ?? '') ??
            setup.fitToWidth;
        setup.fitToHeight =
            int.tryParse(reader.getAttribute('fitToHeight') ?? '') ??
            setup.fitToHeight;
        setup.blackAndWhite = reader.getAttribute('blackAndWhite') == '1';
        setup.draft = reader.getAttribute('draft') == '1';
        setup.useFirstPageNumber =
            reader.getAttribute('useFirstPageNumber') == '1';
        setup.firstPageNumber = int.tryParse(
          reader.getAttribute('firstPageNumber') ?? '',
        );
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'sheetFormatPr') {
        final width = double.tryParse(
          reader.getAttribute('defaultColWidth') ?? '',
        );
        final base = int.tryParse(reader.getAttribute('baseColWidth') ?? '');
        sheet.importDefaultColumnWidth(
          excelWidth: width != null && width.isFinite && width >= 0
              ? width
              : null,
          baseCharacters: base != null && base >= 0 ? base : null,
        );
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'col') {
        final int min = int.tryParse(reader.getAttribute('min') ?? '1') ?? 1;
        final int max =
            int.tryParse(reader.getAttribute('max') ?? '$min') ?? min;
        final double? width = double.tryParse(
          reader.getAttribute('width') ?? '',
        );
        final properties = <String, String>{};
        for (final name in <String>[
          'hidden',
          'outlineLevel',
          'collapsed',
          'style',
          'bestFit',
          'phonetic',
          'customWidth',
        ]) {
          final value = reader.getAttribute(name);
          if (value != null) properties[name] = value;
        }
        final int from = (min - 1).clamp(0, SmlWorksheet.excelColumnCount - 1);
        final int to = (max - 1).clamp(0, SmlWorksheet.excelColumnCount - 1);
        for (int c = from; c <= to; c++) {
          if (width != null) sheet.importColumnWidth(c, width);
          if (properties.isNotEmpty) {
            sheet.columnProperties[c] = Map<String, String>.from(properties);
          }
        }
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'row') {
        final int r = (int.tryParse(reader.getAttribute('r') ?? '1') ?? 1) - 1;
        final double? ht = double.tryParse(reader.getAttribute('ht') ?? '');
        if (ht != null && r >= 0 && r < SmlWorksheet.excelRowCount) {
          sheet.rowHeights[r] = SmlWorksheet.rowHeightFromExcel(ht);
        }
        final hidden = reader.getAttribute('hidden');
        if ((hidden == '1' || hidden == 'true') &&
            r >= 0 &&
            r < SmlWorksheet.excelRowCount) {
          sheet.hiddenRows.add(r);
        }
        final outline = int.tryParse(reader.getAttribute('outlineLevel') ?? '');
        if (outline != null &&
            outline > 0 &&
            r >= 0 &&
            r < SmlWorksheet.excelRowCount) {
          sheet.rowOutlineLevels[r] = outline;
        }
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'c') {
        final String ref = reader.getAttribute('r') ?? 'A1';
        final String? t = reader.getAttribute('t');
        valueType = t;
        final String? nativeStyle = reader.getAttribute('s');
        final int s = int.parse(nativeStyle ?? '0');
        current = sheet.cellA1(ref);
        current.styleIndex = s;
        current.hasExplicitStyleIndex = nativeStyle != null;
        current.horizontalAlign = styles?.alignAt(s) ?? SmlHAlign.general;
        current.fillRgb = styles?.fillAt(s) ?? '';
        current.hasExplicitFillColorEdit = false;
        current.fontRgb = styles?.fontAt(s) ?? '';
        current.hasExplicitFontColorEdit = false;
        current.fontBold = styles?.boldAt(s) ?? false;
        current.fontSize = styles?.sizeAt(s) ?? 11;
        current.fontFamily = styles?.familyAt(s) ?? 'Calibri';
        current.type = switch (t) {
          's' => SmlCellType.string,
          'b' => SmlCellType.boolean,
          'e' => SmlCellType.error,
          'str' || 'inlineStr' => SmlCellType.string,
          _ => SmlCellType.number,
        };
      } else if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'f' &&
          current != null) {
        // formula text follows
      } else if (reader.eventType == XmlEventType.characters &&
          current != null) {
        // assigned below via element-end tracking
      } else if (reader.eventType == XmlEventType.endElement &&
          reader.localName == 'c') {
        current = null;
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'is' &&
          current != null) {
        current.value = _readInlineString(reader);
      }
      if (reader.eventType == XmlEventType.startElement &&
          (reader.localName == 'v' || reader.localName == 'f') &&
          current != null) {
        final String name = reader.localName;
        final String? formulaKind = name == 'f'
            ? reader.getAttribute('t')
            : null;
        final String? sharedIndex = name == 'f'
            ? reader.getAttribute('si')
            : null;
        final String text = _readText(reader);
        if (name == 'f') {
          String? formula = text;
          if (formulaKind == 'shared' && sharedIndex != null) {
            final ({String formula, SmlCellRef anchor})? master =
                shared[sharedIndex];
            if (text.isNotEmpty) {
              shared[sharedIndex] = (formula: text, anchor: current.ref);
            } else if (master != null) {
              formula = FormulaRefShift.shift(
                master.formula,
                rows: current.ref.row - master.anchor.row,
                columns: current.ref.col - master.anchor.col,
              );
            } else {
              formula = null;
            }
          }
          if (formula != null && formula.isNotEmpty) {
            current.formula = formula;
            current.type = valueType == 'e'
                ? SmlCellType.error
                : valueType == 'str' || valueType == 's'
                ? SmlCellType.string
                : SmlCellType.formula;
          }
        } else if (valueType == 's' && int.tryParse(text) != null) {
          current.value = sst[int.parse(text)];
        } else if (valueType == 'b') {
          current.value = text == '1' || text.toLowerCase() == 'true';
        } else if (valueType == 'str' ||
            valueType == 'inlineStr' ||
            valueType == 'e') {
          current.value = text;
        } else {
          current.value = double.tryParse(text) ?? text;
        }
      }
      if (reader.eventType == XmlEventType.startElement &&
          reader.localName == 'mergeCell') {
        final String? ref = reader.getAttribute('ref');
        if (ref != null && ref.isNotEmpty) {
          sheet.merges.add(SmlMerge.parse(ref));
        }
      }
    }
    if (pageSetup != null) {
      SheetSerializer._applyPaperSize(pageSetup!);
      sheet.pageSetup = pageSetup;
    }
    SheetDrawingIo.readSheet(sheet, package, sheetUri);
    _readSheetExtras(sheet, package, sheetUri);
    sheet.sourceValidationState = sheet.validationState();
    sheet.sourceConditionalFormatState = sheet.conditionalFormatState();
  }

  static void _readSheetExtras(
    SmlWorksheet sheet,
    OpcPackage package,
    String sheetUri,
  ) {
    final PackagePart? comments = _sheetCommentsPart(sheet, package, sheetUri);
    if (comments != null) {
      final XmlPullReader reader = XmlPullReader(comments.readText());
      final List<String> authors = <String>[];
      String? ref;
      String author = '';
      while (reader.next()) {
        if (reader.eventType == XmlEventType.startElement &&
            reader.localName == 'author') {
          authors.add(_readText(reader));
        } else if (reader.eventType == XmlEventType.startElement &&
            reader.localName == 'comment') {
          ref = reader.getAttribute('ref');
          // OOXML stores an index into <authors>; older generators wrote the
          // name directly, so accept both shapes on import.
          final String? authorId = reader.getAttribute('authorId');
          final int? index = int.tryParse(authorId ?? '');
          final String? name = reader.getAttribute('author');
          author = index != null && index >= 0 && index < authors.length
              ? authors[index]
              : (name ?? '');
        } else if (reader.eventType == XmlEventType.startElement &&
            reader.localName == 'text' &&
            ref != null) {
          sheet.comments.add(
            SmlComment(
              ref: SmlCellRef.parse(ref),
              text: _readText(reader),
              author: author,
            ),
          );
          ref = null;
        }
      }
    }
    final PackagePart? tables = package.getPart(
      '/xl/tables${sheet.sheetId}.xml',
    );
    if (tables != null) {
      final XmlPullReader reader = XmlPullReader(tables.readText());
      while (reader.next()) {
        if (reader.eventType == XmlEventType.startElement &&
            reader.localName == 'table') {
          final String name = reader.getAttribute('name') ?? 'Table';
          final String? ref = reader.getAttribute('ref');
          if (ref != null) {
            sheet.tables.add(SmlTable(name: name, range: SmlRange.parse(ref)));
          }
        }
      }
    }
    final PackagePart? sparks = package.getPart(
      '/xl/sparklines${sheet.sheetId}.xml',
    );
    if (sparks != null) {
      final XmlPullReader reader = XmlPullReader(sparks.readText());
      while (reader.next()) {
        if (reader.eventType != XmlEventType.startElement ||
            reader.localName != 'sparkline') {
          continue;
        }
        final String? ref = reader.getAttribute('ref');
        final String? sqref = reader.getAttribute('sqref');
        if (ref == null || sqref == null) {
          continue;
        }
        sheet.sparklines.add(
          SmlSparkline(
            anchor: SmlCellRef.parse(ref),
            source: SmlRange.parse(sqref),
            kind: reader.getAttribute('type') == 'column'
                ? SmlSparklineKind.column
                : SmlSparklineKind.line,
          ),
        );
      }
    }
    _readPivots(sheet, package, sheetUri);
  }

  // XML Schema booleans permit both numeric and word spellings. Each optional
  // SpreadsheetML attribute keeps its specified default when absent.
  static bool _readBoolean(String? value, {bool defaultValue = false}) =>
      switch (value?.trim()) {
        '1' || 'true' => true,
        '0' || 'false' => false,
        _ => defaultValue,
      };

  /// Text of an inline string (`<is>`): plain `<t>` or rich-text runs,
  /// without phonetic (`<rPh>`) readings.
  static String _readInlineString(XmlPullReader reader) {
    if (reader.isEmptyElement) {
      return '';
    }
    final StringBuffer buffer = StringBuffer();
    final int depth = reader.depth;
    var inText = false;
    while (reader.next() && reader.depth >= depth) {
      if (reader.eventType == XmlEventType.startElement) {
        if (reader.localName == 'rPh') {
          reader.skip();
        } else if (reader.localName == 't') {
          inText = !reader.isEmptyElement;
        }
      } else if (reader.eventType == XmlEventType.endElement) {
        if (reader.localName == 't') {
          inText = false;
        }
      } else if (inText &&
          (reader.eventType == XmlEventType.characters ||
              reader.eventType == XmlEventType.cdata)) {
        buffer.write(reader.text);
      }
    }
    return buffer.toString();
  }

  static String _readText(XmlPullReader reader) {
    if (reader.isEmptyElement) {
      return '';
    }
    final StringBuffer buffer = StringBuffer();
    final int depth = reader.depth;
    while (reader.next() && reader.depth >= depth) {
      if (reader.eventType == XmlEventType.characters) {
        buffer.write(reader.text);
      }
    }
    return buffer.toString();
  }
}

/// Class SheetSerializer.
class SheetSerializer {
  /// writeBytes API.
  Uint8List writeBytes(
    SmlWorkbook book, {
    bool recalculate = true,
    String? password,
  }) {
    return write(book, recalculate: recalculate).save(password: password);
  }

  /// write API.
  OpcPackage write(SmlWorkbook book, {bool recalculate = true}) {
    book.package?.assertUnsignedForEditing();
    final sourcePackage = book.package;
    final sourceComments = <SmlWorksheet, PackagePart?>{};
    if (sourcePackage != null) {
      // Capture only existing source-sheet ownership before any parts change.
      // Newly allocated sheets must never adopt an unrelated legacy-named part.
      for (final sheet in book.sheets) {
        final sourceUri = sheet.sourcePartUri;
        if (sourceUri != null && sourcePackage.getPart(sourceUri) != null) {
          sourceComments[sheet] = _sheetCommentsPart(
            sheet,
            sourcePackage,
            sourceUri,
          );
        }
      }
    }
    book.applyResolvedColumnMetrics();
    if (recalculate) {
      FormulaDepGraph(book).recalculate();
    }
    // Explicit native cache types are authoritative. A caller bypassing
    // recalculation must type an error-looking cache instead of asking the
    // writer to guess whether it is literal text or an actual error.
    for (final sheet in book.sheets) {
      for (final cell in sheet.allCells) {
        if (cell.formula != null &&
            cell.type == SmlCellType.formula &&
            FormulaEvaluator.hasErrorSpelling(cell.value)) {
          throw UnsupportedError(
            'Ambiguous formula cache type at ${sheet.name}!${cell.ref.a1}; recalculate or supply an explicit text/error type',
          );
        }
      }
    }
    SheetChartData.refreshWorkbook(book);
    final bool fresh = book.package == null;
    final OpcPackage package =
        book.package ?? OpcPackage.create(OpcPackageKind.sheet);
    final SharedStringTable sst = SharedStringTable();
    for (final SmlWorksheet sheet in book.sheets) {
      for (final SmlCell cell in sheet.allCells) {
        if (cell.type == SmlCellType.string || cell.value is String) {
          sst.intern(cell.asString);
        }
      }
    }
    if (package.getPart('/xl/sharedStrings.xml') == null) {
      package.createPart(
        '/xl/sharedStrings.xml',
        OfficeContentTypes.sheetSharedStrings,
        utf8.encode(sst.toXml()),
      );
    } else {
      package.getPart('/xl/sharedStrings.xml')!.writeText(sst.toXml());
    }
    _syncStyles(book, package);
    book.properties.writeToPackage(package);

    final RelationshipCollection rels = package.relationshipsFor(
      '/xl/workbook.xml',
    );
    final List<String> sheetIds = [];
    final Set<String> used = {};
    for (int i = 0; i < book.sheets.length; i++) {
      String? uri =
          book.sheets[i].sourcePartUri ??
          (fresh ? '/xl/worksheets/sheet${i + 1}.xml' : null);
      if (uri == null || used.contains(uri)) {
        var n = 1;
        while (package.getPart('/xl/worksheets/sheet$n.xml') != null) {
          n++;
        }
        uri = '/xl/worksheets/sheet$n.xml';
      }
      used.add(uri);
      book.sheets[i].sourcePartUri = uri;
      PackageRelationship? relationship = rels
          .byType(RelationshipTypes.worksheet)
          .where((r) => rels.resolve(r) == uri)
          .firstOrNull;
      relationship ??= rels.add(
        type: RelationshipTypes.worksheet,
        target: OpcUris.relativize('/xl/workbook.xml', uri),
      );
      sheetIds.add(relationship.id);
      if (package.getPart(uri) == null) {
        package.createPart(
          uri,
          OfficeContentTypes.sheetWorksheet,
          utf8.encode(''),
        );
      }
      SheetDrawingIo.syncSheet(
        book.sheets[i],
        package,
        uri,
        i + 1,
        workbook: book,
      );
      package
          .getPart(uri)!
          .writeText(_sheetXml(book.sheets[i], sst, package, uri));
      _writeSheetExtras(
        book.sheets[i],
        package,
        commentsPart: sourceComments[book.sheets[i]],
      );
      _writePivots(book, book.sheets[i], package, uri);
    }
    if (package
            .relationshipsFor('/xl/workbook.xml')
            .firstByType(RelationshipTypes.sharedStrings) ==
        null) {
      package
          .relationshipsFor('/xl/workbook.xml')
          .add(
            type: RelationshipTypes.sharedStrings,
            target: 'sharedStrings.xml',
          );
    }
    for (final rel in rels.byType(RelationshipTypes.worksheet).toList()) {
      if (!sheetIds.contains(rel.id)) rels.removeById(rel.id);
    }
    package
        .getPart('/xl/workbook.xml')!
        .writeText(_workbookXml(book, package, sheetIds));
    book.package = package;
    book.sharedStrings = sst.values;
    return package;
  }

  static void _writeSheetExtras(
    SmlWorksheet sheet,
    OpcPackage package, {
    required PackagePart? commentsPart,
  }) {
    final sheetUri = sheet.sourcePartUri!;
    final relationships = package.relationshipsFor(sheetUri);
    final commentsLink = relationships.firstByType(RelationshipTypes.comments);
    final legacyPart = package.getPart('/xl/comments${sheet.sheetId}.xml');
    // A new sheet or removal of an authored link can expose an unrelated
    // legacy-named part as the fallback on the next import. Keep a distinct
    // authoritative empty part so the orphan survives without becoming a note.
    final keepEmptyAuthority =
        legacyPart != null &&
        legacyPart.uri != commentsPart?.uri &&
        legacyPart.contentType == OfficeContentTypes.sheetComments &&
        !_hasOtherPartReference(package, legacyPart.uri);
    if (sheet.comments.isNotEmpty || keepEmptyAuthority) {
      // A shared part must not be overwritten through only one worksheet's
      // model. Give this sheet its own part while retaining the other owner.
      String? retainedUri = commentsPart?.uri;
      if (retainedUri != null &&
          _hasOtherPartReference(
            package,
            retainedUri,
            ignoredSourceUri: sheetUri,
            ignoredRelationshipId: commentsLink?.id,
          )) {
        retainedUri = null;
      }
      var uri = retainedUri ?? '/xl/comments${sheet.sheetId}.xml';
      if (retainedUri == null) {
        var suffix = 1;
        while (package.getPart(uri) != null) {
          uri = '/xl/comments${sheet.sheetId}_${suffix++}.xml';
        }
      }
      final XmlWriter w = XmlWriter();
      w.writeStartDocument();
      w.writeStartElement('comments', namespaceUri: OfficeNamespaces.x);
      // CT_Comments requires <authors> before <commentList>, and each comment's
      // author is an index into that table (not a name attribute).
      // Retain first-seen order while keeping large imported comment sets
      // linear; repeated list searches would make distinct authors quadratic.
      final Map<String, int> authors = <String, int>{};
      for (final SmlComment comment in sheet.comments) {
        authors.putIfAbsent(comment.author, () => authors.length);
      }
      w.writeStartElement('authors');
      for (final String author in authors.keys) {
        w.writeStartElement('author');
        w.writeText(author);
        w.writeEndElement();
      }
      w.writeEndElement();
      w.writeStartElement('commentList');
      for (final SmlComment comment in sheet.comments) {
        w.writeStartElement('comment');
        w.writeAttribute('ref', comment.ref.a1);
        w.writeAttribute('authorId', '${authors[comment.author]}');
        w.writeStartElement('text');
        w.writeStartElement('t');
        w.writeAttribute('xml:space', 'preserve');
        w.writeText(comment.text);
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
      }
      w.writeEndElement();
      w.writeEndElement();
      final PackagePart? existing = package.getPart(uri);
      if (existing == null) {
        package.createPart(
          uri,
          OfficeContentTypes.sheetComments,
          utf8.encode(w.toXml()),
        );
      } else {
        existing
          ..contentType = OfficeContentTypes.sheetComments
          ..writeText(w.toXml());
      }
      if (commentsLink == null || relationships.resolve(commentsLink) != uri) {
        if (commentsLink != null) relationships.removeById(commentsLink.id);
        relationships.add(
          id: commentsLink?.id,
          type: RelationshipTypes.comments,
          target: OpcUris.relativize(sheetUri, uri),
        );
      }
    } else if (commentsPart != null) {
      if (commentsLink != null) relationships.removeById(commentsLink.id);
      if (!_hasOtherPartReference(package, commentsPart.uri)) {
        package.deletePart(commentsPart.uri);
      }
    }
    if (sheet.tables.isNotEmpty) {
      final XmlWriter w = XmlWriter();
      w.writeStartDocument();
      w.writeStartElement('tables');
      for (final SmlTable table in sheet.tables) {
        w.writeEmptyElement(
          'table',
          attributes: <String, String>{
            'name': table.name,
            'ref': '${table.range.start.a1}:${table.range.end.a1}',
            'headerRow': table.headerRow ? '1' : '0',
            'bandedRows': table.bandedRows ? '1' : '0',
          },
        );
      }
      w.writeEndElement();
      final String uri = '/xl/tables${sheet.sheetId}.xml';
      final PackagePart? existing = package.getPart(uri);
      if (existing == null) {
        package.createPart(
          uri,
          OfficeContentTypes.sheetWorksheet,
          utf8.encode(w.toXml()),
        );
      } else {
        existing.writeText(w.toXml());
      }
    }
    if (sheet.sparklines.isNotEmpty) {
      final XmlWriter w = XmlWriter();
      w.writeStartDocument();
      w.writeStartElement('sparklines');
      for (final SmlSparkline spark in sheet.sparklines) {
        w.writeEmptyElement(
          'sparkline',
          attributes: <String, String>{
            'ref': spark.anchor.a1,
            'sqref': '${spark.source.start.a1}:${spark.source.end.a1}',
            'type': spark.kind.name,
          },
        );
      }
      w.writeEndElement();
      final String uri = '/xl/sparklines${sheet.sheetId}.xml';
      final PackagePart? existing = package.getPart(uri);
      if (existing == null) {
        package.createPart(
          uri,
          OfficeContentTypes.sheetWorksheet,
          utf8.encode(w.toXml()),
        );
      } else {
        existing.writeText(w.toXml());
      }
    }
  }

  static void _syncStyles(SmlWorkbook book, OpcPackage package) {
    var needsStyles = book.styles != null;
    for (final SmlWorksheet sheet in book.sheets) {
      if (sheet.conditionalFormats.isNotEmpty) {
        needsStyles = true;
        break;
      }
      for (final SmlCell cell in sheet.allCells) {
        if (cell.horizontalAlign != SmlHAlign.general ||
            cell.fillRgb.isNotEmpty ||
            cell.fontRgb.isNotEmpty ||
            cell.fontBold ||
            cell.fontSize != 11 ||
            cell.wrapText != null) {
          needsStyles = true;
          break;
        }
      }
      if (needsStyles) {
        break;
      }
    }
    if (!needsStyles) {
      return;
    }
    final SmlStyleSheet styles = book.styles ?? SmlStyleSheet();
    final generatedDxfs = <({String fillRgb, String fontRgb})>[];
    final generateDxfs = book.sheets.every(
      (sheet) => sheet.sourceConditionalFormatState == null,
    );
    if (generateDxfs) {
      for (final sheet in book.sheets) {
        for (final rule in sheet.conditionalFormats) {
          rule.dxfId = generatedDxfs.length;
          generatedDxfs.add((fillRgb: rule.fillRgb, fontRgb: rule.fontRgb));
        }
      }
    }
    for (final SmlWorksheet sheet in book.sheets) {
      for (final SmlCell cell in sheet.allCells) {
        // Defaults can be an intentional edit away from an imported style.
        // xfFor returns the original index when the modeled properties match,
        // retaining explicit style presence and native inherited properties.
        cell.styleIndex = styles.xfFor(
          baseStyleIndex: cell.styleIndex,
          align: cell.horizontalAlign,
          fillRgb: cell.fillRgb,
          fillColorExplicit: cell.hasExplicitFillColorEdit,
          fontRgb: cell.fontRgb,
          fontColorExplicit: cell.hasExplicitFontColorEdit,
          bold: cell.fontBold,
          size: cell.fontSize,
          fontFamily: cell.fontFamily,
          wrapText: cell.wrapText,
        );
      }
    }
    book.styles = styles;
    if (package.getPart('/xl/styles.xml') == null) {
      package.createPart(
        '/xl/styles.xml',
        OfficeContentTypes.sheetStyles,
        utf8.encode(
          styles.toXml(dxfs: generateDxfs ? generatedDxfs : const []),
        ),
      );
    } else {
      package
          .getPart('/xl/styles.xml')!
          .writeText(
            styles.toXml(dxfs: generateDxfs ? generatedDxfs : const []),
          );
    }
    final RelationshipCollection rels = package.relationshipsFor(
      '/xl/workbook.xml',
    );
    if (rels.firstByType(RelationshipTypes.styles) == null) {
      rels.add(type: RelationshipTypes.styles, target: 'styles.xml');
    }
  }

  String _workbookXml(
    SmlWorkbook book,
    OpcPackage package,
    List<String> sheetIds,
  ) {
    final preserveNames =
        book.sourceDefinedNameState != null &&
        book.sourceDefinedNameState == book.definedNameState();
    final XmlWriter w = XmlWriter();
    w.writeStartDocument();
    w.writeStartElement('workbook');
    w.writeAttribute('xmlns', OfficeNamespaces.x);
    w.writeNamespace('r', OfficeNamespaces.r);
    w.writeStartElement('sheets');
    for (int i = 0; i < book.sheets.length; i++) {
      final SmlWorksheet s = book.sheets[i];
      w.writeStartElement('sheet');
      w.writeAttribute('name', s.name);
      w.writeAttribute('sheetId', '${s.sheetId}');
      w.writeAttribute('r:id', sheetIds[i]);
      if (s.hidden) w.writeAttribute('state', 'hidden');
      w.writeEndElement();
    }
    w.writeEndElement();
    if (!preserveNames &&
        (book.definedNames.isNotEmpty ||
            book.sheets.any(
              (SmlWorksheet s) =>
                  s.printTitleRows != null ||
                  s.printTitleCols != null ||
                  s.printArea != null,
            ))) {
      w.writeStartElement('definedNames');
      for (final name in book.definedNames) {
        w.writeStartElement('definedName');
        w.writeAttribute('name', name.name);
        if (name.localSheetId != null) {
          w.writeAttribute('localSheetId', '${name.localSheetId}');
        }
        name.attributes.forEach(w.writeAttribute);
        w.writeText(name.formula);
        w.writeEndElement();
      }
      for (int i = 0; i < book.sheets.length; i++) {
        final SmlWorksheet sheet = book.sheets[i];
        if (sheet.printArea != null) {
          String absolute(SmlCellRef cell) => cell.a1.replaceFirstMapped(
            RegExp(r'^([A-Z]+)(\d+)$'),
            (match) => '\$${match[1]}\$${match[2]}',
          );
          final area = sheet.printArea!;
          final ref = area.isSingleCell
              ? absolute(area.start)
              : '${absolute(area.start)}:${absolute(area.end)}';
          w.writeStartElement('definedName');
          w.writeAttribute('name', '_xlnm.Print_Area');
          w.writeAttribute('localSheetId', '$i');
          w.writeText("'${sheet.name.replaceAll("'", "''")}'!$ref");
          w.writeEndElement();
        }
        final List<String> parts = <String>[];
        if (sheet.printTitleRows != null) {
          final SmlRange r = sheet.printTitleRows!;
          parts.add(
            "'${sheet.name.replaceAll("'", "''")}'!\$${r.minRow + 1}:\$${r.maxRow + 1}",
          );
        }
        if (sheet.printTitleCols != null) {
          final SmlRange c = sheet.printTitleCols!;
          final String a = SmlCellRef(
            c.minCol,
            0,
          ).a1.replaceAll(RegExp(r'\d+'), '');
          final String b = SmlCellRef(
            c.maxCol,
            0,
          ).a1.replaceAll(RegExp(r'\d+'), '');
          parts.add("'${sheet.name.replaceAll("'", "''")}'!\$$a:\$$b");
        }
        if (parts.isEmpty) {
          continue;
        }
        w.writeStartElement('definedName');
        w.writeAttribute('name', '_xlnm.Print_Titles');
        w.writeAttribute('localSheetId', '$i');
        w.writeText(parts.join(','));
        w.writeEndElement();
      }
      w.writeEndElement();
    }
    w.writeEndElement();
    return _preserveSheetParts(
      package.getPart('/xl/workbook.xml')?.readText(),
      w.toXml(),
      {'sheets', if (!preserveNames) 'definedNames'},
      _workbookOrder,
    );
  }

  static List<int> _conditionalPriorities(List<SmlConditionalRule> rules) =>
      SmlConditionalResolver.effectivePriorities(rules);

  String _sheetXml(
    SmlWorksheet sheet,
    SharedStringTable sst,
    OpcPackage package,
    String sheetUri,
  ) {
    final sourceXml = package.getPart(sheetUri)?.readText();
    final preserveValidations =
        sheet.sourceValidationState != null &&
        sheet.sourceValidationState == sheet.validationState();
    final preserveConditional =
        sheet.sourceConditionalFormatState != null &&
        sheet.sourceConditionalFormatState == sheet.conditionalFormatState();
    final XmlWriter w = XmlWriter();
    w.writeStartDocument();
    w.writeStartElement('worksheet');
    w.writeAttribute('xmlns', OfficeNamespaces.x);
    if (sheet.drawings.isNotEmpty ||
        sheet.rows.values.any(
          (row) => row.cells.values.any(
            (cell) => cell.hyperlink?.contains('://') ?? false,
          ),
        )) {
      w.writeNamespace('r', OfficeNamespaces.r);
    }
    if (sheet.tabColorRgb case final rgb?) {
      w.writeStartElement('sheetPr');
      w.writeEmptyElement('tabColor', attributes: {'rgb': 'FF$rgb'});
      w.writeEndElement();
    }
    _writeSheetViews(w, sheet);
    _writeSheetFormat(w, sheet, sourceXml);
    _writeCols(w, sheet);
    w.writeStartElement('sheetData');
    final Set<int> rowKeys = <int>{
      ...sheet.rows.keys,
      ...sheet.rowHeights.keys,
      ...sheet.hiddenRows,
      ...sheet.rowOutlineLevels.keys,
    };
    final List<int> rowIdx = rowKeys.toList()..sort();
    for (final int r in rowIdx) {
      final SmlRow row = sheet.rows[r] ?? SmlRow(r);
      w.writeStartElement('row');
      w.writeAttribute('r', '${r + 1}');
      if (sheet.hiddenRows.contains(r)) w.writeAttribute('hidden', '1');
      final outline = sheet.rowOutlineLevels[r];
      if (outline != null && outline > 0) {
        w.writeAttribute('outlineLevel', '$outline');
      }
      final double? ht = sheet.rowHeights[r];
      if (ht != null) {
        w.writeAttribute('ht', '${SmlWorksheet.rowHeightToExcel(ht)}');
        w.writeAttribute('customHeight', '1');
      }
      final List<int> cols = row.cells.keys.toList()..sort();
      for (final int c in cols) {
        final SmlCell cell = row.cells[c]!;
        w.writeStartElement('c');
        w.writeAttribute('r', cell.ref.a1);
        if (cell.styleIndex != 0 || cell.hasExplicitStyleIndex) {
          w.writeAttribute('s', '${cell.styleIndex}');
        }
        if (cell.formula != null) {
          if (cell.value is bool) {
            w.writeAttribute('t', 'b');
          } else if (cell.value is String) {
            w.writeAttribute('t', cell.type == SmlCellType.error ? 'e' : 'str');
          }
          w.writeStartElement('f');
          w.writeText(
            cell.formula!.startsWith('=')
                ? cell.formula!.substring(1)
                : cell.formula!,
          );
          w.writeEndElement();
          w.writeStartElement('v');
          w.writeText(
            cell.value is bool
                ? (cell.value == true ? '1' : '0')
                : cell.asString,
          );
          w.writeEndElement();
        } else if (cell.type == SmlCellType.error) {
          w.writeAttribute('t', 'e');
          w.writeStartElement('v');
          w.writeText(cell.asString);
          w.writeEndElement();
        } else if (cell.type == SmlCellType.string || cell.value is String) {
          w.writeAttribute('t', 's');
          w.writeStartElement('v');
          w.writeText('${sst.intern(cell.asString)}');
          w.writeEndElement();
        } else if (cell.type == SmlCellType.boolean) {
          w.writeAttribute('t', 'b');
          w.writeStartElement('v');
          w.writeText(cell.value == true ? '1' : '0');
          w.writeEndElement();
        } else if (cell.value != null) {
          w.writeStartElement('v');
          w.writeText(cell.asString);
          w.writeEndElement();
        }
        w.writeEndElement();
      }
      w.writeEndElement();
    }
    w.writeEndElement();
    if (sheet.autoFilter != null) {
      final filter = sheet.autoFilter!;
      final ref = '${filter.range.start.a1}:${filter.range.end.a1}';
      if (filter.hiddenValues.values.every((values) => values.isEmpty)) {
        w.writeEmptyElement('autoFilter', attributes: {'ref': ref});
      } else {
        w.writeStartElement('autoFilter');
        w.writeAttribute('ref', ref);
        for (final entry in filter.hiddenValues.entries) {
          if (entry.value.isEmpty) continue;
          final column = filter.range.minCol + entry.key;
          final values = <String>{};
          for (
            var row = filter.range.minRow + 1;
            row <= filter.range.maxRow;
            row++
          ) {
            final value = sheet.cell(SmlCellRef(column, row)).asString;
            if (value.isNotEmpty) values.add(value);
          }
          final visible = values.difference(entry.value).toList()..sort();
          if (visible.isEmpty) continue;
          w.writeStartElement('filterColumn');
          w.writeAttribute('colId', '${entry.key}');
          w.writeStartElement('filters');
          for (final value in visible) {
            w.writeEmptyElement('filter', attributes: {'val': value});
          }
          w.writeEndElement();
          w.writeEndElement();
        }
        w.writeEndElement();
      }
    }
    if (sheet.protection != null && sheet.protection!.enabled) {
      w.writeEmptyElement(
        'sheetProtection',
        attributes: <String, String>{'sheet': '1'},
      );
    }
    if (!preserveValidations && sheet.validations.isNotEmpty) {
      w.writeStartElement('dataValidations');
      w.writeAttribute('count', '${sheet.validations.length}');
      for (final SmlDataValidation rule in sheet.validations) {
        w.writeStartElement('dataValidation');
        w.writeAttribute('type', switch (rule.kind) {
          SmlValidationKind.list => 'list',
          SmlValidationKind.whole => 'whole',
          SmlValidationKind.decimal => 'decimal',
          SmlValidationKind.date => 'date',
          SmlValidationKind.textLength => 'textLength',
          SmlValidationKind.custom => 'custom',
        });
        w.writeAttribute(
          'sqref',
          '${rule.range.start.a1}:${rule.range.end.a1}',
        );
        w.writeAttribute('allowBlank', rule.allowBlank ? '1' : '0');
        if (rule.promptTitle.isNotEmpty) {
          w.writeAttribute('promptTitle', rule.promptTitle);
        }
        if (rule.prompt.isNotEmpty) {
          w.writeAttribute('prompt', rule.prompt);
        }
        if (rule.errorTitle.isNotEmpty) {
          w.writeAttribute('errorTitle', rule.errorTitle);
        }
        if (rule.error.isNotEmpty) {
          w.writeAttribute('error', rule.error);
        }
        if (rule.errorStyle != 'stop') {
          w.writeAttribute('errorStyle', rule.errorStyle);
        }
        if (rule.kind != SmlValidationKind.list) {
          w.writeAttribute('operator', switch (rule.operator) {
            SmlValidationOperator.between => 'between',
            SmlValidationOperator.notBetween => 'notBetween',
            SmlValidationOperator.equal => 'equal',
            SmlValidationOperator.notEqual => 'notEqual',
            SmlValidationOperator.greaterThan => 'greaterThan',
            SmlValidationOperator.lessThan => 'lessThan',
            SmlValidationOperator.greaterThanOrEqual => 'greaterThanOrEqual',
            SmlValidationOperator.lessThanOrEqual => 'lessThanOrEqual',
          });
        }
        final formula1 = rule.kind == SmlValidationKind.list
            ? '"${rule.listItems.join(',')}"'
            : rule.formula1;
        if (formula1.isNotEmpty) {
          w.writeStartElement('formula1');
          w.writeText(formula1);
          w.writeEndElement();
        }
        if (rule.formula2.isNotEmpty) {
          w.writeStartElement('formula2');
          w.writeText(rule.formula2);
          w.writeEndElement();
        }
        w.writeEndElement();
      }
      w.writeEndElement();
    }
    if (!preserveConditional && sheet.conditionalFormats.isNotEmpty) {
      final priorities = _conditionalPriorities(sheet.conditionalFormats);
      for (var i = 0; i < sheet.conditionalFormats.length; i++) {
        final rule = sheet.conditionalFormats[i];
        w.writeStartElement('conditionalFormatting');
        w.writeAttribute(
          'sqref',
          '${rule.range.start.a1}:${rule.range.end.a1}',
        );
        w.writeStartElement('cfRule');
        w.writeAttribute('priority', '${priorities[i]}');
        w.writeAttribute('stopIfTrue', rule.stopIfTrue ? '1' : '0');
        switch (rule.kind) {
          case SmlConditionalKind.contains:
          case SmlConditionalKind.beginsWith:
          case SmlConditionalKind.endsWith:
            w.writeAttribute(
              'type',
              rule.kind == SmlConditionalKind.contains
                  ? 'containsText'
                  : rule.kind == SmlConditionalKind.beginsWith
                  ? 'beginsWith'
                  : 'endsWith',
            );
            w.writeAttribute(
              'operator',
              rule.kind == SmlConditionalKind.contains
                  ? 'containsText'
                  : rule.kind == SmlConditionalKind.beginsWith
                  ? 'beginsWith'
                  : 'endsWith',
            );
            w.writeAttribute('text', rule.formula);
          case SmlConditionalKind.expression:
            w.writeAttribute('type', 'expression');
          case SmlConditionalKind.duplicate:
            w.writeAttribute('type', 'duplicateValues');
          case SmlConditionalKind.top:
          case SmlConditionalKind.topPercent:
            w.writeAttribute('type', 'top10');
            w.writeAttribute('rank', '${rule.rank}');
            if (rule.kind == SmlConditionalKind.topPercent) {
              w.writeAttribute('percent', '1');
            }
          case SmlConditionalKind.bottom:
          case SmlConditionalKind.bottomPercent:
            w.writeAttribute('type', 'top10');
            w.writeAttribute('bottom', '1');
            w.writeAttribute('rank', '${rule.rank}');
            if (rule.kind == SmlConditionalKind.bottomPercent) {
              w.writeAttribute('percent', '1');
            }
          case SmlConditionalKind.aboveAverage:
            w.writeAttribute('type', 'aboveAverage');
          case SmlConditionalKind.belowAverage:
            w.writeAttribute('type', 'aboveAverage');
            w.writeAttribute('aboveAverage', '0');
          default:
            w.writeAttribute('type', 'cellIs');
            w.writeAttribute('operator', switch (rule.kind) {
              SmlConditionalKind.greaterThan => 'greaterThan',
              SmlConditionalKind.greaterOrEqual => 'greaterThanOrEqual',
              SmlConditionalKind.lessThan => 'lessThan',
              SmlConditionalKind.lessOrEqual => 'lessThanOrEqual',
              SmlConditionalKind.equal => 'equal',
              SmlConditionalKind.notEqual => 'notEqual',
              SmlConditionalKind.between => 'between',
              SmlConditionalKind.notBetween => 'notBetween',
              SmlConditionalKind.contains ||
              SmlConditionalKind.beginsWith ||
              SmlConditionalKind.endsWith ||
              SmlConditionalKind.expression ||
              SmlConditionalKind.duplicate ||
              SmlConditionalKind.top ||
              SmlConditionalKind.bottom ||
              SmlConditionalKind.topPercent ||
              SmlConditionalKind.bottomPercent ||
              SmlConditionalKind.aboveAverage ||
              SmlConditionalKind.belowAverage => throw StateError(
                'handled above',
              ),
            });
        }
        if (rule.dxfId case final dxfId?) {
          w.writeAttribute('dxfId', '$dxfId');
        }
        if (rule.kind != SmlConditionalKind.contains &&
            rule.kind != SmlConditionalKind.beginsWith &&
            rule.kind != SmlConditionalKind.endsWith &&
            rule.kind != SmlConditionalKind.duplicate &&
            rule.kind != SmlConditionalKind.top &&
            rule.kind != SmlConditionalKind.bottom &&
            rule.kind != SmlConditionalKind.topPercent &&
            rule.kind != SmlConditionalKind.bottomPercent &&
            rule.kind != SmlConditionalKind.aboveAverage &&
            rule.kind != SmlConditionalKind.belowAverage) {
          if (rule.formula.isNotEmpty) {
            w.writeStartElement('formula');
            w.writeText(rule.formula);
            w.writeEndElement();
          }
          if (rule.formula2.isNotEmpty) {
            w.writeStartElement('formula');
            w.writeText(rule.formula2);
            w.writeEndElement();
          }
        }
        w.writeEndElement();
        w.writeEndElement();
      }
    }
    if (sheet.merges.isNotEmpty) {
      w.writeStartElement('mergeCells');
      w.writeAttribute('count', '${sheet.merges.length}');
      for (final SmlMerge merge in sheet.merges) {
        w.writeEmptyElement(
          'mergeCell',
          attributes: <String, String>{'ref': merge.a1},
        );
      }
      w.writeEndElement();
    }
    _writeHyperlinks(w, sheet, package, sheetUri);
    _writePageSetup(w, sheet);
    final SmlHeaderFooter? hf = sheet.headerFooter;
    if (hf != null && !hf.isEmpty) {
      w.writeStartElement('headerFooter');
      final String oddHeader = <String>[
        if (hf.headerLeft.isNotEmpty) '&L${hf.headerLeft}',
        if (hf.headerCenter.isNotEmpty) '&C${hf.headerCenter}',
        if (hf.headerRight.isNotEmpty) '&R${hf.headerRight}',
      ].join();
      final String oddFooter = <String>[
        if (hf.footerLeft.isNotEmpty) '&L${hf.footerLeft}',
        if (hf.footerCenter.isNotEmpty) '&C${hf.footerCenter}',
        if (hf.footerRight.isNotEmpty) '&R${hf.footerRight}',
      ].join();
      if (oddHeader.isNotEmpty) {
        w.writeStartElement('oddHeader');
        w.writeText(oddHeader);
        w.writeEndElement();
      }
      if (oddFooter.isNotEmpty) {
        w.writeStartElement('oddFooter');
        w.writeText(oddFooter);
        w.writeEndElement();
      }
      w.writeEndElement();
    }
    if (sheet.drawings.isNotEmpty) {
      final String? rid = SheetDrawingIo.drawingRelationshipId(
        package,
        sheetUri,
      );
      if (rid != null) {
        w.writeEmptyElement(
          'drawing',
          attributes: <String, String>{'r:id': rid},
        );
      }
    }
    w.writeEndElement();
    return _preserveSheetParts(sourceXml, w.toXml(), {
      'sheetViews',
      'cols',
      'sheetData',
      'sheetProtection',
      'autoFilter',
      if (!preserveConditional) 'conditionalFormatting',
      if (!preserveValidations) 'dataValidations',
      'mergeCells',
      if (sheet.pageSetup != null) 'printOptions',
      if (sheet.pageSetup != null) 'pageMargins',
      if (sheet.pageSetup != null) 'pageSetup',
      'headerFooter',
      'drawing',
    }, _worksheetOrder);
  }

  static void _applyPaperSize(SmlPageSetup setup) {
    switch (setup.paperSize) {
      case 1:
        setup
          ..paperWidthIn = 8.5
          ..paperHeightIn = 11;
      case 3:
        setup
          ..paperWidthIn = 11
          ..paperHeightIn = 17;
      case 5:
        setup
          ..paperWidthIn = 8.5
          ..paperHeightIn = 14;
      case 8:
        setup
          ..paperWidthIn = 11.69
          ..paperHeightIn = 16.54;
      case 9:
        setup
          ..paperWidthIn = 8.2677
          ..paperHeightIn = 11.6929;
      case 11:
        setup
          ..paperWidthIn = 5.83
          ..paperHeightIn = 8.27;
      case 12:
        setup
          ..paperWidthIn = 9.84
          ..paperHeightIn = 13.9;
      case 13:
        setup
          ..paperWidthIn = 6.93
          ..paperHeightIn = 9.84;
    }
  }

  static void _writePageSetup(XmlWriter w, SmlWorksheet sheet) {
    final setup = sheet.pageSetup;
    if (setup == null) return;
    if (setup.printGridlines ||
        setup.printHeadings ||
        setup.centerHorizontally ||
        setup.centerVertically) {
      w.writeEmptyElement(
        'printOptions',
        attributes: <String, String>{
          if (setup.printGridlines) 'gridLines': '1',
          if (setup.printHeadings) 'headings': '1',
          if (setup.centerHorizontally) 'horizontalCentered': '1',
          if (setup.centerVertically) 'verticalCentered': '1',
        },
      );
    }
    w.writeEmptyElement(
      'pageMargins',
      attributes: <String, String>{
        'left': '${setup.marginLeftIn}',
        'right': '${setup.marginRightIn}',
        'top': '${setup.marginTopIn}',
        'bottom': '${setup.marginBottomIn}',
        'header': '${setup.headerMarginIn}',
        'footer': '${setup.footerMarginIn}',
      },
    );
    w.writeEmptyElement(
      'pageSetup',
      attributes: <String, String>{
        'paperSize': '${setup.paperSize}',
        'orientation': setup.orientation == SmlPageOrientation.landscape
            ? 'landscape'
            : 'portrait',
        'scale': '${setup.scale}',
        'fitToWidth': '${setup.fitToWidth}',
        'fitToHeight': '${setup.fitToHeight}',
        if (setup.useFirstPageNumber && setup.firstPageNumber != null)
          'useFirstPageNumber': '1',
        if (setup.useFirstPageNumber && setup.firstPageNumber != null)
          'firstPageNumber': '${setup.firstPageNumber}',
        if (setup.blackAndWhite) 'blackAndWhite': '1',
        if (setup.draft) 'draft': '1',
      },
    );
  }

  static void _writeHyperlinks(
    XmlWriter w,
    SmlWorksheet sheet,
    OpcPackage package,
    String sheetUri,
  ) {
    final linked = <SmlCell>[
      for (final row in sheet.rows.values)
        for (final cell in row.cells.values)
          if (cell.hyperlink case final link? when link.isNotEmpty) cell,
    ];
    if (linked.isEmpty) return;
    final rels = package.relationshipsFor(sheetUri);
    w.writeStartElement('hyperlinks');
    for (final cell in linked) {
      final link = cell.hyperlink!;
      w.writeStartElement('hyperlink');
      w.writeAttribute('ref', cell.ref.a1);
      final external =
          link.contains('://') ||
          link.startsWith('mailto:') ||
          link.startsWith('ftp:');
      if (external) {
        final existing = rels.items
            .where(
              (rel) =>
                  rel.type == RelationshipTypes.hyperlink &&
                  rel.targetMode == RelationshipTargetMode.external &&
                  rel.target == link,
            )
            .firstOrNull;
        final rel =
            existing ??
            rels.add(
              type: RelationshipTypes.hyperlink,
              target: link,
              targetMode: RelationshipTargetMode.external,
            );
        w.writeAttribute('r:id', rel.id);
      } else {
        w.writeAttribute(
          'location',
          link.startsWith('#') ? link.substring(1) : link,
        );
      }
      w.writeEndElement();
    }
    w.writeEndElement();
  }

  static void _writeSheetFormat(
    XmlWriter w,
    SmlWorksheet sheet,
    String? sourceXml,
  ) {
    final width = sheet.nativeDefaultColumnWidth;
    final base = sheet.nativeBaseColumnWidth;
    if (width == null && base == null) return;
    // Existing native XML can contain additional sheet defaults that are not
    // modeled here. Leave that complete element to _preserveSheetParts.
    if (sourceXml != null &&
        sourceXml.trim().isNotEmpty &&
        XmlDocument.parse(sourceXml).root?.firstChild('sheetFormatPr') !=
            null) {
      return;
    }
    w.writeEmptyElement(
      'sheetFormatPr',
      attributes: <String, String>{
        'defaultRowHeight': '${SmlWorksheet.defaultRowHeightPx * 72 / 96}',
        if (width != null) 'defaultColWidth': '$width',
        if (base != null) 'baseColWidth': '$base',
      },
    );
  }

  static void _writeSheetViews(XmlWriter w, SmlWorksheet sheet) {
    if (!sheet.rightToLeft && sheet.freezeRows <= 0 && sheet.freezeCols <= 0) {
      return;
    }
    w.writeStartElement('sheetViews');
    w.writeStartElement('sheetView');
    w.writeAttribute('workbookViewId', '0');
    if (sheet.rightToLeft) {
      w.writeAttribute('rightToLeft', '1');
    }
    if (sheet.freezeRows > 0 || sheet.freezeCols > 0) {
      w.writeStartElement('pane');
      w.writeAttribute('xSplit', '${sheet.freezeCols}');
      w.writeAttribute('ySplit', '${sheet.freezeRows}');
      w.writeAttribute(
        'topLeftCell',
        SmlCellRef(sheet.freezeCols, sheet.freezeRows).a1,
      );
      w.writeAttribute('activePane', 'bottomRight');
      w.writeAttribute('state', 'frozen');
      w.writeEndElement();
    }
    w.writeEndElement();
    w.writeEndElement();
  }

  static void _writeCols(XmlWriter w, SmlWorksheet sheet) {
    if (sheet.columnWidths.isEmpty && sheet.columnProperties.isEmpty) {
      return;
    }
    final List<int> keys = <int>{
      ...sheet.columnWidths.keys,
      ...sheet.columnProperties.keys,
    }.toList()..sort();
    double? widthAt(int col) => sheet.columnWidths.containsKey(col)
        ? sheet.exportColumnWidth(col)
        : null;
    bool sameProperties(Map<String, String> a, Map<String, String> b) =>
        a.length == b.length &&
        a.entries.every((entry) => b[entry.key] == entry.value);
    w.writeStartElement('cols');
    var i = 0;
    while (i < keys.length) {
      final int start = keys[i];
      final double? width = widthAt(start);
      final properties = sheet.exportColumnProperties(start);
      var end = start;
      while (i + 1 < keys.length &&
          keys[i + 1] == end + 1 &&
          widthAt(keys[i + 1]) == width &&
          sameProperties(
            properties,
            sheet.exportColumnProperties(keys[i + 1]),
          )) {
        i++;
        end = keys[i];
      }
      w.writeStartElement('col');
      w.writeAttribute('min', '${start + 1}');
      w.writeAttribute('max', '${end + 1}');
      if (width != null) w.writeAttribute('width', '$width');
      for (final entry in properties.entries) {
        if (!<String>{'min', 'max', 'width'}.contains(entry.key)) {
          w.writeAttribute(entry.key, entry.value);
        }
      }
      w.writeEndElement();
      i++;
    }
    w.writeEndElement();
  }
}
