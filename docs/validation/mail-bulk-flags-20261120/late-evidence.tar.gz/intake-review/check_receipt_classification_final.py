#!/usr/bin/env python3
"""Small independent parser probes; never executes a recorded source command."""
from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
ROOT=Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
SCRIPT=ROOT/'docs/validation/mail-bulk-flags-20261120/verify_late_evidence.py'
OUT=ROOT.parent/'late-main-validation/intake-review'
spec=importlib.util.spec_from_file_location('reviewed_verifier',SCRIPT)
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
PATH='packages/quds_office_engine/lib/src/word/layout/word_layout.dart'
BODY=b'independent review fixture\n'
DIGEST=hashlib.sha256(BODY).hexdigest()
class Git:
 def tree(self,commit):return {PATH:{'type':'blob','blob':'review'}}
 def preload(self,commit,hashes):pass
 def read(self,commit,path):assert path==PATH;return BODY

def probe(name, *, log='00:01 +1: All tests passed!\n', code=0, stable=True, after=None, runtime_only=False, before=None):
 hashes={v.RUNTIME_CONFIG:'f'*64} if runtime_only else {PATH:before or DIGEST}
 row={'name':'probe','argv':['dart','test','test/example_test.dart'],'exit_code':code,'source_before':hashes,'source_after':after or hashes,'source_unchanged':stable,'log':'probe.log','log_sha256':v.sha(log.encode())}
 payloads={'peer-main/review/receipt.json':json.dumps(row).encode(),'peer-main/review/probe.log':log.encode()}
 try:
  result=v.compile_cohorts(payloads,Git(),'review-checkpoint')[0]
  return {'name':name,'disposition':result['disposition'],'source_stable':result.get('source_stable'),'tracked_source_count':result['tracked_source_count'],'terminal_test_success':result.get('terminal_test_success'),'passed':result.get('passed'),'skipped':result.get('skipped')}
 except (ValueError,KeyError,TypeError) as e:return {'name':name,'rejected':str(e)}

results=[
 probe('stable_success'),
 probe('stable_success_with_skips',log='00:01 +3 ~8: All tests passed!\n'),
 probe('missing_terminal',log='00:00 +0: loading test/example_test.dart\n'),
 probe('nonterminal_success',log='00:01 +1: All tests passed!\nUnexpected later output\n'),
 probe('failed_exit',code=1),
 probe('source_transition_success',stable=False,after={PATH:'a'*64}),
 probe('source_transition_failure',code=1,stable=False,after={PATH:'a'*64}),
 probe('false_stability_declaration',stable=True,after={PATH:'a'*64}),
 probe('stable_historical_source',before='b'*64),
 probe('runtime_config_only',runtime_only=True),
]
record={'verifier_sha256':hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),'scope':'Classification unit probes with a minimal in-memory Git reader, no source tests or archive execution. These do not substitute for the complete bundle verifier.','results':results}
(OUT/'receipt-classification-review-final.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
