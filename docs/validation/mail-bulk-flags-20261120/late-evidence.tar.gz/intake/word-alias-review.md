# Zotero PR #276: historical-source reconciliation review

Compared incoming main `698209aaa6e7f1350b6541df5eb192b7b233443d` with the accepted integration tree `9265604a3d2ed91fc382e4be77cc1041572ea86c`. The aggregate main delta from `e975cec13b289fe067ef406cd3044701ecc44744` contains 50 paths, including already-accounted-for source history. This review makes no runtime acceptance claim for the new Zotero implementation.

## Keep the accepted mail union

The incoming `bulk_flags.dart` is exactly historical blob `d5a6a9f3892504f619ccc6e4e2d1e38dd6f1eb52`, already reviewed at `b60c0ec26f2a80c984076fb1d480eb2e641b542e`. It is not a new coordinator implementation. Its test is blob `fbbb20b4ee8d7cb6fe03dfe4606394154749132b`, already retained byte-for-byte as `packages/quds_mail_core/test/bulk_flags_coordinator_test.dart`. Keep the current combined runtime, mutation evidence, coordinator compatibility, provider-result factory, all four core suites, and the current UI/host contract. Incoming ancestry need not restore an older runtime or test filename.

## Consolidate four positional aliases

The canonical positional example, source suite, integration suite and driver already exist under the `word_measurements` names. Incoming `_positional` names repeat them:

| Incoming alias | Retained canonical path | Proof |
|---|---|---|
| `example/macros/word_measurements_positional.bas` | `example/macros/word_measurements.bas` | Identical mode/type/blob `01834ab0fb95c43a4ff4a19e1c3bd7a9e554c2c5` |
| `test/office_vba_word_measurements_positional_test.dart` | `test/office_vba_word_measurements_test.dart` | Identical mode/type/blob `eb78cf4e18994c001f2785d0dd9d1f8abbccc3b3` |
| `test/office_vba_word_measurements_positional_integration_test.dart` | `test/office_vba_word_measurements_integration_test.dart` | Exactly equal after two filename substitutions and one import-line wrap; all substitutions and hashes recorded in JSON |
| `tool/macros/web_vba_word_measurements_positional_smoke.dart` | `tool/macros/web_vba_word_measurements_smoke.dart` | Identical mode/type/blob `bd5707ab5cc784b7e7bbade7aaa7e42f2bf5b312` |

All paths in this table are under `packages/quds_office_engine/`. Omit the duplicate aliases from the final tree. Preserve their authored historical validation records unchanged and point the new integration supplement to the explicit canonical mapping.

The incoming named source/integration fixtures are strict older subsets of the accepted versions. The accepted files retain every incoming byte-line in order and add exactly 43 and 105 lines, respectively. Keep those additive cases and `office_vba_word_bulk_intake_conversions_test.dart`. Canonical positional/unit-conversion files, the three BAS examples, both canonical portable drivers and the production VBA compiler already agree; no Word implementation change is needed for this intake.

## Preserve true Zotero work

Retain the four changed production files: `word/model/word_zotero.dart`, `word/model/word_zotero_citing.dart`, `word/model/word_zotero_note.dart`, and `zotero/zotero_citing.dart`. Retain the horizontal-cell and adjacent-citation engine/editor regression suites, research-target acceptance tools, Zotero roadmap/support/validation updates and authored validation artifacts. The exact 50-path inventory, current/incoming blob IDs and dispositions are in the JSON record. These changes require their own local qualification against the reconciled Office repairs.

## Documentation resolution

- Keep the current VBA contract's distinction between statically checked argument types and Variant contents checked when evaluated. Incoming prose weakens that distinction despite an unchanged compiler.
- Keep the current separate eight-, nine- and thirteen-operation examples and their canonical paths. Avoid introducing duplicate `_positional` links into current user-facing documentation.
- Keep the corrected TabStops paragraph that points to supported conversion functions below. Incoming prose again says unit-conversion intrinsics are absent.
- The incoming explicit statement that intermediate multiplication uses floating-point arithmetic is compatible with the accepted compiler and can be added without removing current bounds/precision details.
- Retain current source-bound VM/JavaScript qualification links for VBA; incoming Zotero intake evidence is historical context, not a replacement qualification of the accepted mail/Word union.
- Union the new Zotero changelog entries with current mail and Word entries, preserving the existing compatibility and example details.

## Replay

`python verify_late_main_word_aliases.py --repo /path/to/quds_office_suite` checks the exact public Git objects, all four alias mappings, both insertion-only fixture supersets, and the preserved peer core suite. It changes no refs and disables lazy fetching. The observed result is PASS. No GitHub Actions or status endpoints were queried.
