#!/usr/bin/env python3
"""Build a deterministic late evidence bundle after all inputs are frozen.

Use --plan for a read-only inventory while gates run.  Actual publication needs
--stable-inputs and, when peer-main receipts exist, --peer-source COMMIT.  Old
cohorts keep their immutable 00d44 binding; only peer-main/ uses the new source.
The original evidence archive and its verifier are never rewritten.
"""
from __future__ import annotations

import argparse
from collections import Counter
import gzip
import importlib.util
import io
import json
from pathlib import Path
import stat
import sys
import tarfile

sys.dont_write_bytecode = True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--baseline-directory", type=Path)
    parser.add_argument("--verifier", type=Path)
    parser.add_argument("--peer-source", help="Final published peer reconciliation source checkpoint")
    parser.add_argument("--exclude-prefix", action="append", default=[], help="Explicit immutable source-copy subtree; repeated; never used for raw receipts")
    parser.add_argument("--required-peer-cohorts", type=Path, help="JSON list of required receipt#name IDs; otherwise every successful peer receipt must qualify")
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--stable-inputs", action="store_true")
    args = parser.parse_args()
    docs = args.repo / "docs/validation/mail-bulk-flags-20261120"
    output = args.output or docs
    baseline = args.baseline_directory or docs
    verifier_path = args.verifier or docs / "verify_late_evidence.py"
    spec = importlib.util.spec_from_file_location("late_evidence_verifier", verifier_path)
    verify = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verify)
    git = verify.Git(args.repo)
    peer = git.commit(args.peer_source) if args.peer_source else None
    base_files, base_manifest, base_payloads = verify.baseline_payloads(baseline)
    png_index = {}
    for row in base_manifest["members"]:
        if row["path"].endswith(".png"):
            png_index.setdefault((row["sha256"], row["bytes"]), []).append(row)

    selected = {}
    original = {}
    modes = {}
    exclusions = []
    visuals = []
    skipped_dirs = {"__pycache__", ".git", ".dart_tool", "node_modules", "build"}
    prefixes = [verify.safe_name(x.rstrip("/")) + "/" for x in args.exclude_prefix]
    for path in sorted(args.source.rglob("*")):
        if not path.is_file():
            continue
        name = path.relative_to(args.source).as_posix()
        verify.safe_name(name)
        verify.require(not path.is_symlink(), f"Symlink in evidence source: {name}")
        body = path.read_bytes()
        info = {"source": "late-main-validation/" + name, "path": name, "bytes": len(body), "sha256": verify.sha(body)}
        reason = None
        if any(part in skipped_dirs for part in Path(name).parts):
            reason = "runtime, dependency or build cache"
        elif any(name.startswith(prefix) for prefix in prefixes):
            verify.require(not name.endswith((".json", ".jsonl", ".log", ".log.gz")), f"Explicit source-copy exclusion would omit raw evidence: {name}")
            reason = "explicit immutable source-copy subtree; Git objects bind the source"
        elif name.endswith((".js", ".js.map", ".js.deps")):
            reason = "generated JavaScript/compiler sidecar; commands, source hashes, output comparison and logs retained"
        elif name.endswith(".png") and (info["sha256"], info["bytes"]) in png_index:
            matches = png_index[(info["sha256"], info["bytes"])]
            preferred = [row for row in matches if Path(row["path"]).name == path.name]
            target = sorted(preferred or matches, key=lambda row: row["path"])[0]
            verify.require(base_payloads[target["path"]] == body, "PNG hash match without byte equality")
            visuals.append({"source": info["source"], "omitted_member": name, "bytes": len(body), "sha256": info["sha256"], "baseline_member": target["path"], "baseline_source": target["source"]})
            reason = "byte-identical image retained in immutable baseline archive"
        original[name] = body
        if reason:
            exclusions.append(info | {"reason": reason})
            continue
        selected[name] = body
        modes[name] = "0755" if path.stat().st_mode & stat.S_IXUSR else "0644"
    cohorts = verify.compile_cohorts(selected, git, peer["commit"] if peer else None)
    by_id = {row["id"]: row for row in cohorts}
    missing = [name for name, passed in verify.REQUIRED.items() if name not in by_id or by_id[name]["disposition"] != "accepted" or (passed is not None and by_id[name]["passed"] != passed)]
    peer_rows = [row for row in cohorts if row["receipt"].startswith("peer-main/")]
    required_peer = json.loads(args.required_peer_cohorts.read_text()) if args.required_peer_cohorts else sorted(set(verify.REQUIRED_PEER if peer else ()) | {row["id"] for row in peer_rows if row["exit_code"] == 0})
    missing_peer = [name for name in required_peer if name not in by_id or by_id[name]["disposition"] != "accepted"]
    plan = {"mode": "plan", "selected_members": len(selected), "selected_bytes": sum(map(len, selected.values())), "excluded_files": len(exclusions), "deduplicated_pngs": len(visuals), "cohorts": len(cohorts), "dispositions": dict(Counter(row["disposition"] for row in cohorts)), "missing_original_accepted": missing, "missing_peer_accepted": missing_peer, "peer_source": peer}
    if args.plan:
        print(json.dumps(plan, indent=2, sort_keys=True))
        return 0
    verify.require(args.stable_inputs, "Actual packaging requires --stable-inputs after all writers have stopped")
    verify.require(not missing and not missing_peer, f"Incomplete qualification: original={missing}, peer={missing_peer}")
    verify.require(not peer_rows or peer is not None, "Peer receipts need --peer-source")
    # Hash and source checks happen before a byte is written to the destination.
    inheritance = verify.verify_inheritance(selected, git)
    aliases = verify.verify_aliases(git)
    peer_inheritance = verify.verify_peer_inheritance(selected, git, peer) if peer else None
    core_member = next(row["path"] for row in base_manifest["members"] if row["source"] == "bulk-core-provider-results-validation/accepted/receipt.json")
    artifact_path = "docs/validation/zotero-merged-cells-20261120/local-validation.tar.gz"
    artifact = git.read(verify.LATE, artifact_path)
    verify.require(artifact == git.read(verify.INCOMING, artifact_path), "PR276 archive not retained exactly")
    stream = io.BytesIO()
    members = []
    with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
            for name, body in sorted(selected.items()):
                member = tarfile.TarInfo(name)
                member.size = len(body)
                member.mode = int(modes[name], 8)
                member.uid = member.gid = member.mtime = 0
                member.uname = member.gname = ""
                archive.addfile(member, io.BytesIO(body))
                members.append({"path": name, "source": "late-main-validation/" + name, "bytes": len(body), "sha256": verify.sha(body), "mode": modes[name]})
    archive_bytes = stream.getvalue()
    archive_record = {"path": "late-evidence.tar.gz", "bytes": len(archive_bytes), "sha256": verify.sha(archive_bytes)}
    manifest = {"format_version": 1, "archive": archive_record, "packing": {"gzip_mtime": 0, "tar_mtime": 0, "ownership": "uid/gid zero; empty names", "order": "sorted POSIX member paths", "regular_files_only": True}, "member_count": len(members), "uncompressed_member_bytes": sum(row["bytes"] for row in members), "members": members, "exclusions": exclusions}
    manifest_bytes = verify.json_bytes(manifest)
    comparisons = verify.verify_driver_comparisons(selected, manifest)
    application = {
        "format_version": 1,
        "scope": "Original late-main cohorts qualify 00d44 only; peer-main cohorts qualify the separate peer checkpoint. Historical and diagnostic executions are preserved without relabeling. Git verification never uses current working-tree source.",
        "original_late_source": git.commit(verify.LATE), "peer_source": peer,
        "archive": archive_record,
        "manifest": {"path": "late-evidence-members.json", "bytes": len(manifest_bytes), "sha256": verify.sha(manifest_bytes)},
        "verifier_sha256": verify.sha(verifier_path.read_bytes()),
        "baseline_files": {name: {"bytes": len(body), "sha256": verify.sha(body)} for name, body in base_files.items()},
        "cohorts": cohorts, "required_peer_cohorts": required_peer,
        "visual_inheritance": visuals,
        "runtime_configuration_policy": "Only .dart_tool/package_config.json is excluded from Git comparison; its runtime hashes remain in each receipt. No other source mismatch is exempted for accepted executions.",
        "baseline_core_inheritance": {"receipt": core_member, "receipt_sha256": verify.sha(base_payloads[core_member]), "qualified_baseline": verify.BASE, "inherited_at": verify.LATE, "scope": "Five accepted core/provider cohorts; final peer core changes require their own new receipts."},
        "source_inheritance": {"member": "source-inheritance.json", "sha256": verify.sha(selected["source-inheritance.json"]), "replayed": inheritance},
        "alias_replay": aliases,
        "peer_source_inheritance": peer_inheritance,
        "equal_vm_javascript_driver_pairs": comparisons,
        "incoming_artifact": {"path": artifact_path, "bytes": len(artifact), "sha256": verify.sha(artifact), "incoming_commit": verify.INCOMING, "retained_at": verify.LATE},
    }
    # Confirm stability of every retained/deduplicated/explicitly excluded raw
    # input, including diagnostics and generated-output metadata.
    for name, body in original.items():
        verify.require((args.source / name).read_bytes() == body, f"Input changed during packaging: {name}")
    final_paths = {path.relative_to(args.source).as_posix() for path in args.source.rglob("*") if path.is_file()}
    verify.require(final_paths == set(original), "Evidence file inventory changed during packaging")
    output.mkdir(parents=True, exist_ok=True)
    (output / "late-evidence.tar.gz").write_bytes(archive_bytes)
    (output / "late-evidence-members.json").write_bytes(manifest_bytes)
    (output / "late-source-applicability.json").write_bytes(verify.json_bytes(application))
    result = verify.verify_bundle(output, args.repo, baseline_folder=baseline)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, KeyError, TypeError, StopIteration) as error:
        print(json.dumps({"status": "FAIL", "error": str(error)}, indent=2), file=sys.stderr)
        raise SystemExit(1)
