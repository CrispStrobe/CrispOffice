#!/usr/bin/env python3
"""Read-only replay of historical aliases reintroduced by Zotero PR #276."""
import argparse, hashlib, json, os, pathlib, subprocess
CURRENT='9265604a3d2ed91fc382e4be77cc1041572ea86c'
INCOMING='698209aaa6e7f1350b6541df5eb192b7b233443d'
PREVIOUS_MAIN='e975cec13b289fe067ef406cd3044701ecc44744'
HISTORICAL_MAIL='b60c0ec26f2a80c984076fb1d480eb2e641b542e'
PAIRS=[
('packages/quds_office_engine/example/macros/word_measurements_positional.bas','packages/quds_office_engine/example/macros/word_measurements.bas'),
('packages/quds_office_engine/test/office_vba_word_measurements_positional_test.dart','packages/quds_office_engine/test/office_vba_word_measurements_test.dart'),
('packages/quds_office_engine/test/office_vba_word_measurements_positional_integration_test.dart','packages/quds_office_engine/test/office_vba_word_measurements_integration_test.dart'),
('packages/quds_office_engine/tool/macros/web_vba_word_measurements_positional_smoke.dart','packages/quds_office_engine/tool/macros/web_vba_word_measurements_smoke.dart'),
]
SUBSTITUTIONS=[
('web_vba_word_measurements_positional_smoke.dart','web_vba_word_measurements_smoke.dart'),
('word_measurements_positional.bas','word_measurements.bas'),
("import '../tool/macros/web_vba_word_measurements_smoke.dart'\n    as portable;", "import '../tool/macros/web_vba_word_measurements_smoke.dart' as portable;"),
]
ADDITIONS={
'packages/quds_office_engine/test/office_vba_word_named_measurements_test.dart':43,
'packages/quds_office_engine/test/office_vba_word_named_measurements_integration_test.dart':105,
}

def require(value,message):
 if not value: raise ValueError(message)
def digest(data): return hashlib.sha256(data).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent/'quds_office_suite');args=p.parse_args()
 env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
 def git(*values):return subprocess.check_output(['git','-C',str(args.repo),*values],env=env)
 def blob(ref,path):return git('cat-file','blob',ref+':'+path)
 def entry(ref,path):
  line=git('ls-tree',ref,'--',path).decode().strip();return line.split('\t',1)[0].split() if line else None
 aliases=[]
 for source,target in PAIRS:
  old,new=blob(INCOMING,source),blob(CURRENT,target);normalized=old;normalizations=[]
  if source.endswith('positional_integration_test.dart'):
   text=old.decode()
   for before,after in SUBSTITUTIONS:
    require(text.count(before)==1,'Expected exactly one normalization occurrence')
    text=text.replace(before,after,1);normalizations.append({'before':before,'after':after})
   normalized=text.encode()
  require(normalized==new,'Alias content differs: '+source)
  incoming_entry,current_entry=entry(INCOMING,source),entry(CURRENT,target)
  require(incoming_entry[:2]==current_entry[:2],'Alias mode/type differs')
  aliases.append({'incoming_path':source,'retained_path':target,'incoming_mode_type_blob':incoming_entry,'retained_mode_type_blob':current_entry,'incoming_sha256':digest(old),'retained_sha256':digest(new),'normalized_sha256':digest(normalized),'exact_blob_equal':old==new,'exact_normalizations':normalizations})
 additions=[]
 for path,count in ADDITIONS.items():
  old,new=blob(INCOMING,path),blob(CURRENT,path);old_lines,new_lines=old.splitlines(keepends=True),new.splitlines(keepends=True);cursor=0
  for line in old_lines:
   while cursor<len(new_lines) and new_lines[cursor]!=line:cursor+=1
   require(cursor<len(new_lines),'Current fixture removed or replaced incoming text')
   cursor+=1
  require(len(new_lines)-len(old_lines)==count,'Unexpected additive line count')
  additions.append({'path':path,'incoming_sha256':digest(old),'retained_sha256':digest(new),'inserted_lines_in_retained':count,'removed_lines':0,'all_incoming_lines_retained_in_order':True})
 mail_source='packages/quds_mail_core/lib/src/sync/bulk_flags.dart';mail_old_test='packages/quds_mail_core/test/bulk_flags_test.dart';mail_retained_test='packages/quds_mail_core/test/bulk_flags_coordinator_test.dart'
 require(blob(INCOMING,mail_source)==blob(HISTORICAL_MAIL,mail_source),'Incoming mail core has new source')
 require(blob(INCOMING,mail_old_test)==blob(CURRENT,mail_retained_test),'Incoming peer test is not preserved')
 delta=git('diff','--name-status',PREVIOUS_MAIN,INCOMING).decode().splitlines()
 inventory=[]
 for row in delta:
  status,path=row.split('\t',1);a,b=entry(CURRENT,path),entry(INCOMING,path)
  kind=('already-identical' if a==b else 'duplicate-alias' if path in {x[0] for x in PAIRS} else 'preserve-reviewed-mail-union' if path.startswith('packages/quds_mail_core/') else 'zotero-source-tests-docs' if 'zotero' in path.lower() else 'merge-documentation-without-dropping-current-contracts')
  inventory.append({'incoming_status':status,'path':path,'current_mode_type_blob':a,'incoming_mode_type_blob':b,'disposition':kind})
 result={'status':'PASS','incoming_main':INCOMING,'previous_main':PREVIOUS_MAIN,'compared_current':CURRENT,'aggregate_delta_paths':len(inventory),'aliases':aliases,'retained_additive_fixtures':additions,'historical_mail':{'incoming_core_blob':entry(INCOMING,mail_source)[2],'identical_historical_commit':HISTORICAL_MAIL,'existing_combined_core_blob':entry(CURRENT,mail_source)[2],'retained_peer_test':mail_retained_test,'retained_peer_test_blob':entry(CURRENT,mail_retained_test)[2],'incoming_test_exactly_preserved':True,'decision':'Keep the already-reviewed combined core and both API entry points; no runtime equivalence claim.'},'inventory':inventory,'github_actions':'NOT QUERIED OR AWAITED'}
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
