#!/usr/bin/env python3
"""Fresh source-bound acceptance after the late-main Word import/layout repairs."""

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
ENGINE = ROOT / 'packages/quds_office_engine'
OUT = ROOT.parent / 'late-main-validation/peer-main/word'
OUT.mkdir(exist_ok=True)
PACKAGE_CONFIG = ROOT / '.dart_tool/package_config.json'
TEST_ENTRY = Path(os.environ['PUB_CACHE']) / 'hosted/pub.dev/test-1.31.1/bin/test.dart'
DART = shutil.which('dart')
NODE = shutil.which('node')
PURE = ['test/word_table_style_import_regression_test.dart', 'test/style_cascade_test.dart', 'test/word_styles_layout_test.dart', 'test/word_structure_integrity_test.dart', 'test/word_table_test.dart', 'test/word_table_direction_test.dart', 'test/word_header_visual_reconciliation_test.dart', 'test/word_inline_picture_test.dart', 'test/word_preserved_header_test.dart', 'test/header_footer_sdt_test.dart', 'test/word_layout_test.dart', 'test/word_contained_text_wrap_test.dart', 'test/word_table_nested_layout_test.dart', 'test/word_table_tall_frame_layout_test.dart', 'test/word_table_tall_toc_layout_test.dart', 'test/word_incremental_layout_test.dart', 'test/word_incremental_layout_prefix_test.dart', 'test/word_incremental_layout_differential_test.dart', 'test/word_header_picture_layout_regression_test.dart', 'test/word_table_style_precedence_test.dart']
INTEGRATION = ['test/zotero_citing_test.dart']
DRIVERS = []


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot():
    paths = set((ENGINE / 'lib').rglob('*.dart'))
    paths.update((ENGINE / 'test/support').rglob('*.dart'))
    paths.update(ENGINE / value for value in PURE + INTEGRATION)
    paths.update((ENGINE / 'tool/macros').rglob('*.dart'))
    paths.update((ENGINE / 'example/macros').rglob('*.bas'))
    paths.update([ROOT / 'pubspec.yaml', ROOT / 'pubspec.lock', ENGINE / 'pubspec.yaml'])
    return {str(p.relative_to(ROOT)): digest(p) for p in sorted(paths) if p.is_file()}


def run(name, argv, *, timeout=1200):
    log = OUT / f'{name}.log'
    before = snapshot()
    started = time.time()
    print(f'START {name}', flush=True)
    with log.open('wb') as stream:
        try:
            result = subprocess.run(argv, cwd=ENGINE, stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
            code = result.returncode
            failure = None
        except subprocess.TimeoutExpired:
            code = None
            failure = f'Process exceeded {timeout} seconds'
    after = snapshot()
    text = log.read_text(errors='replace')
    totals = re.findall(r'\+(\d+)', text)
    item = {
        'name': name,
        'cwd': str(ENGINE),
        'argv': argv,
        'started_unix': started,
        'duration_seconds': round(time.time() - started, 3),
        'exit_code': code,
        'failure': failure,
        'log': str(log),
        'log_sha256': digest(log),
        'source_before': before,
        'source_after': after,
        'source_unchanged': before == after,
    }
    if 'All tests passed!' in text and totals:
        item['passed'] = int(totals[-1])
    (OUT / f'{name}.json').write_text(json.dumps(item, indent=2) + '\n')
    print(json.dumps({k: v for k, v in item.items() if not k.startswith('source_') and k != 'argv'}), flush=True)
    print(text[-2400:], flush=True)
    return item


def test(name, paths, *, platform=None):
    argv = [DART, f'--packages={PACKAGE_CONFIG}', str(TEST_ENTRY), '--reporter', 'expanded', '--concurrency=1']
    if platform:
        argv.extend(['--platform', platform])
    return run(name, argv + paths)


def portable():
    for name, define in DRIVERS:
        bas = ENGINE / f'example/macros/word_{name}.bas'
        driver = ENGINE / f'tool/macros/web_vba_word_{name}_smoke.dart'
        define_arg = f'-D{define}={base64.b64encode(bas.read_bytes()).decode()}'
        vm = run(f'{name}-driver-vm', [DART, f'--packages={PACKAGE_CONFIG}', define_arg, str(driver)])
        output = OUT / f'{name}.js'
        compile_result = run(f'{name}-driver-js-compile', [DART, 'compile', 'js', f'--packages={PACKAGE_CONFIG}', define_arg, str(driver), '-o', str(output)])
        if compile_result['exit_code'] != 0:
            continue
        node = run(f'{name}-driver-js-run', [NODE, '-e', 'globalThis.self = globalThis; require(process.argv[1]);', str(output)])
        comparison = {
            'driver': str(driver),
            'driver_sha256': digest(driver),
            'bas': str(bas),
            'bas_sha256': digest(bas),
            'define': define,
            'compiled_js_sha256': digest(output),
            'vm_exit_code': vm['exit_code'],
            'js_exit_code': node['exit_code'],
        }
        if vm['exit_code'] == 0 and node['exit_code'] == 0:
            vm_data = json.loads(Path(vm['log']).read_text())
            js_data = json.loads(Path(node['log']).read_text())
            comparison.update({'vm_json': vm_data, 'js_json': js_data, 'json_equal': vm_data == js_data})
        (OUT / f'{name}-vm-js-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
        print(json.dumps({k: v for k, v in comparison.items() if not k.endswith('_json')}), flush=True)


def static_checks():
    paths = ['lib/src/word/layout/word_layout.dart', 'lib/src/word/serial/word_deserializer.dart'] + PURE + INTEGRATION
    paths += [f'tool/macros/web_vba_word_{name}_smoke.dart' for name, _ in DRIVERS]
    run('focused-analyze', [DART, 'analyze'] + paths)
    run('focused-format-check', [DART, 'format', '--output=none', '--set-exit-if-changed'] + paths)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['initial', 'vm', 'node', 'portable', 'static', 'all'])
    args = parser.parse_args()
    if args.phase == 'initial':
        test('initial-peer-regressions', ['test/word_header_picture_layout_regression_test.dart', 'test/word_table_style_precedence_test.dart'])
    if args.phase in ('vm', 'all'):
        test('focused-vm', PURE)
    if args.phase == 'node':
        test('word-node', PURE, platform='node')
    if args.phase in ('portable', 'all'):
        portable()
    if args.phase in ('static', 'all'):
        static_checks()
