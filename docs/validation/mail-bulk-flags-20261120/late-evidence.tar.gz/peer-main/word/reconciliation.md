# Office reconciliation with main 0a2afc41

## Scope and preserved evidence

Incoming main `0a2afc41bae4e719b77657a7e2d8d3e7ec02849b` merged peer PR 273 after our prior source-bound acceptance at `00d44a69d19de20cdb7754b754c4d32d86d078cc`. The completed `final-word/` and `zotero/` receipts remain unchanged and describe their original source. The new Office union is saved in remote checkpoint `64da231816b1b3ddab35e0e12d50d885bf24f75f`, tree `e8a89e675839f54b75b66a898fccc656d6d9bcdb`.

The first scratch-only probe overlapped the parent's merge window. It failed at loading because source files temporarily contained merge conflict markers. That raw log and receipt remain in `../../peer-office-review/`; this is a source-transition/infrastructure diagnostic, not a product regression. After the merge window closed, the accepted layout and deserializer SHA256 values were verified before the substantive initial run.

## Demonstrated gaps

The two exact incoming regression suites ran against restored 00d44 production with unchanged before/after hashes: **29 passed, four failed**.

1. Distinct header nodes sharing one OfficeVisual asset lost an authored occurrence.
2. The same loss occurred in a footer.
3. An inline-only 100-point header image ended at y=118 while body text began at y=72.
4. An automatic-color direct table border with no declared width kept 0.5 points instead of inheriting the style's 1-point width.

These failures are preserved in `initial-peer-regressions.log` and `.json`.

## Selected production union

- **Occurrence identity:** header/footer duplicate suppression now uses WmlVisual node identity. A shared node exposed through inline and list representations paints once at its explicit list placement. Repeated list references to the same node also paint once. Distinct nodes remain distinct even when OfficeVisual, image bytes, dimensions, coordinates and picture adjustments match.
- **Header clearance:** ordinary, first-page and even-page inline header images participate in the existing body-clearance calculation.
- **Continuous sections:** the reviewed body-frame prefix helper remains unchanged. Previously emitted chrome is not carried as body content or used to push continuation text downward.
- **Table border width:** import records whether a drawn direct border declares its own width. Explicit sizes continue to win; an omitted size may inherit from the table style when resolving automatic/omitted color. The tracking set is cleared between imports.
- **Sparse formatting:** our conditional imported-baseline update for native table spacing remains unchanged. The redundant first-row formatting pass stays removed, preserving the existing style cascade and nested-table ownership.

## Two corrected fixture assumptions

The importer moves the exact pending WmlVisual node into `inlineVisual`; the serializer emits every distinct authored WmlVisual occurrence and may reuse its OfficeVisual media asset. Asset equality is therefore not provenance for deleting an occurrence. Two overlapping transparent pictures can also render differently from one.

The first existing layout fixture was corrected to share the same WmlVisual node between its inline and list representations. Its one-frame, image-identity and explicit-placement assertions remain intact. Previously it created two distinct nodes while describing them as one occurrence.

The existing equal-content/equal-placement fixture now requires both distinct authored nodes to survive, with their order, identities and coordinates checked. Its previous expectation of one frame encoded the unsupported assumption above. This is an explicit model-contract correction, not removal of coverage. The original source and test expectations remain preserved in the earlier source-bound evidence.

All twelve existing layout cases remain. Three additional cases cover a repeated reference to one listed node and separate transparent occurrences using either copied or shared assets, bringing the suite to fifteen cases. The fourteen earlier import cases, the contained-text usable-width fixture, and all continuous/incremental assertions remain intact.

## Incoming coverage retained

Both incoming Word suites remain byte-for-byte intact: eleven header-picture cases and twenty-two table-style precedence cases. Their complementary coverage includes footer symmetry, shared assets, multiple direct false values, repeated DOCX roundtrips, missing border sizes, explicit nil borders, and document/table/paragraph/direct spacing precedence.

The two incoming installed-font cases were copied exactly into `office_system_fonts_test.dart`; they check all four Arial/Times alias styles and canonical-name precedence using licensed repository font fixtures. The three-line braces-only change to `zotero_citing_test.dart` was also copied exactly, removing the previously recorded style info. The root agent runs the Flutter font suite alongside its final acceptance cohort.

## Qualification scope

`run.py` performs the expanded combined Word VM/Node cohorts, both actual BASIC fixtures on VM and compiled JavaScript, output equivalence, analysis and formatting. `focused.py` runs twenty distinct surrounding import/layout suites, including table ownership, nested/tall tables, header/footer stories, contained text and incremental equivalence. All command receipts snapshot source before and after execution.

The neighboring `../zotero/` supplement reruns the two table suites on VM and Node and the HTTP protocol suite carrying the braces-only cleanup on VM. It targets the affected document import/layout/save/reopen paths without repeating the unrelated 1,500-citation stress fixture. The earlier 282/175 Zotero receipts remain historical and are not relabeled as results on the new Word implementation.

## Observed final results

On the frozen union, the expanded Word cohort passed **929 VM tests** and **787 Node tests**; the twenty surrounding import/layout suites passed **244 VM tests**. Both actual BASIC macro fixtures passed on VM and compiled JavaScript with identical output JSON. All scoped analyses were clean and all formatting checks reported zero changes.

The affected Zotero follow-up passed **165 VM tests** across the two table suites and protocol suite, plus **117 Node tests** across the two table suites. Its analysis is clean, including the imported braces-only correction.

`../qualify.py` verified all seventeen accepted command receipts, their log digests, source stability, current worktree bytes, and corresponding Git blob identities in checkpoint `64da231816b1b3ddab35e0e12d50d885bf24f75f`. Word combined, Word focused, and Zotero source manifests contain 416, 423, and 405 files respectively. These cohorts overlap and must not be added as unique-test counts. The original baseline evidence archive retains SHA256 `63e9efefcf3eb36ef3ae06483cd1d8da622560265494a3c8de9e0f8713d65074`.
