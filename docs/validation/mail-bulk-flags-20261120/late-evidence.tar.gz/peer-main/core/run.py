from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
OUT = Path(__file__).resolve().parent
DART = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/dart-sdk/bin/dart'
RUNNER = Path(os.environ['PUB_CACHE']) / 'hosted/pub.dev/test-1.31.1/bin/test.dart'
BASE = [str(DART), '--packages=' + str(ROOT / '.dart_tool/package_config.json'), str(RUNNER)]
CHANGED = [
    'packages/quds_mail_core/lib/src/sync/bulk_flags.dart',
    'packages/quds_mail_core/test/bulk_flags_compatibility_test.dart',
    'packages/quds_mail_core/test/bulk_flags_provider_results_test.dart',
    'packages/quds_mail_transport/lib/src/cloud/provider.dart',
    'packages/quds_mail_transport/test/cloud_provider_test.dart',
    'packages/quds_mail_transport/test/cloud_unsupported_test.dart',
    'packages/quds_mail_transport/test/ews_unsupported_test.dart',
    'packages/quds_mail_transport/test/unsupported_test.dart',
]
COMMANDS = [
    ('core-vm', ROOT / 'packages/quds_mail_core', BASE + ['--reporter', 'expanded', '--concurrency=2']),
    ('transport-boundaries', ROOT / 'packages/quds_mail_transport', BASE + ['--reporter', 'expanded', '--concurrency=1', 'test/native_provider_test.dart', 'test/ews_provider_test.dart', 'test/cloud_provider_test.dart']),
    ('bulk-node', ROOT / 'packages/quds_mail_core', BASE + ['--platform=node', '--concurrency=1', '--reporter', 'expanded', 'test/bulk_flags_test.dart', 'test/bulk_flags_coordinator_test.dart', 'test/bulk_flags_compatibility_test.dart', 'test/bulk_flags_provider_results_test.dart']),
    ('unsupported-node', ROOT / 'packages/quds_mail_transport', BASE + ['--platform=node', '--concurrency=1', '--reporter', 'expanded', 'test/unsupported_test.dart', 'test/ews_unsupported_test.dart', 'test/cloud_unsupported_test.dart']),
    ('core-analyze', ROOT, [str(DART), 'analyze', 'packages/quds_mail_core']),
    ('transport-analyze', ROOT, [str(DART), 'analyze', 'packages/quds_mail_transport']),
    ('format', ROOT, [str(DART), 'format', '--output=none', '--set-exit-if-changed', *CHANGED]),
    ('whitespace', ROOT, ['git', 'diff', '--check', '--', *CHANGED]),
]
PATHS = sorted(
    path
    for package in ['quds_mail_core', 'quds_mail_transport']
    for directory in ['lib', 'test', 'tool']
    for path in (ROOT / 'packages' / package / directory).rglob('*.dart')
)
PATHS += [ROOT / 'pubspec.lock', ROOT / 'analysis_options.yaml', ROOT / '.dart_tool/package_config.json']


def hashes():
    return {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in PATHS
    }


initial = hashes()
(OUT / 'source-before.json').write_text(json.dumps(initial, indent=2) + '\n')
records = []
for name, cwd, command in COMMANDS:
    before = hashes()
    began = time.time()
    log = OUT / (name + '.log')
    with log.open('w') as output:
        result = subprocess.run(command, cwd=cwd, stdout=output, stderr=subprocess.STDOUT)
    after = hashes()
    records.append({
        'name': name,
        'command': command,
        'cwd': str(cwd),
        'exit_code': result.returncode,
        'elapsed_seconds': round(time.time() - began, 3),
        'source_hashes_unchanged': before == after,
        'changed_paths': [path for path in before if before[path] != after[path]],
        'log': log.name,
        'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
    })
    (OUT / 'checks.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, 'exit', result.returncode, 'source stable', before == after, flush=True)
    print('\n'.join(log.read_text().splitlines()[-5:]), flush=True)

final = hashes()
(OUT / 'source-after.json').write_text(json.dumps(final, indent=2) + '\n')
receipt = {
    'checks': records,
    'source_hashes_before': 'source-before.json',
    'source_hashes_before_sha256': hashlib.sha256((OUT / 'source-before.json').read_bytes()).hexdigest(),
    'source_hashes_after': 'source-after.json',
    'source_hashes_after_sha256': hashlib.sha256((OUT / 'source-after.json').read_bytes()).hexdigest(),
    'source_hashes_unchanged': initial == final,
    'changed_paths': [path for path in initial if initial[path] != final[path]],
}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('receipt SHA256', hashlib.sha256((OUT / 'receipt.json').read_bytes()).hexdigest(), flush=True)
raise SystemExit(0 if initial == final and all(item['exit_code'] == 0 and item['source_hashes_unchanged'] for item in records) else 1)
