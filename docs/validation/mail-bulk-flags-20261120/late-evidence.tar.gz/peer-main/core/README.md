# Final peer-main bulk quota reconciliation

This increment reconciles the actual core/transport additions between the
previously reviewed peer `639ea75a813d558cb5a1a848a6242fbf17bcf0c3` and merged
main `0a2afc41bae4e719b77657a7e2d8d3e7ec02849b`, preserving the combined API and
the accepted runner/coordinator suites from `00d44a69d19de20cdb7754b754c4d32d86d078cc`.

## Bounded behavior change

A certified no-effect `quotaExceeded` result now stops the single execution
engine with `MailBulkFlagStopReason.rateLimited`. The confirmed prefix remains
confirmed, the rejected message remains failed, and the remaining selection
stays unattempted. The exact provider problem, including optional `retryAfter`,
is retained in both its item and `stopProblem`. The runner performs no retry,
timer-based resumption, or further dispatch.

Quota is not itself delivery evidence. A possible or unknown mutation still
produces an uncertain outcome and uncertain stop reason, ahead of concurrent
scope retirement or user stop. The two public entry points continue to share
one private dispatch algorithm. The runner, single-use coordinator, frozen
operation identities, immutable receipts, reentrant lease checks, contradictory
evidence handling, and nullable observation behavior remain intact.

`requiresRefresh` retains its accepted core meaning: uncertain outcomes require
fresh observation. Hosts separately enforce refresh and publication guards for
retired scopes. The peer's wider core `requiresRefresh` definition was not
substituted for that established API.

## Deliberate cloud 429 expectation update

The prior accepted cloud policy conservatively treated dispatched HTTP 429 as
possibly applied. Provider-specific documentation supplies stronger evidence
for this status:

- [Microsoft Graph throttling guidance](https://learn.microsoft.com/en-us/graph/throttling)
  describes throttled requests as failures, with HTTP 429 and a suggested wait
  time in the failed response.
- [Gmail API error guidance](https://developers.google.com/workspace/gmail/api/guides/handle-errors)
  describes HTTP 429 limits, retrying failed requests, and waiting for the
  service to accept requests again. The sending pipeline has additional
  caveats, so this change does not redefine submission outcomes.

For the Gmail/Graph `apply` transport only, a received 429 response is therefore
classified as a known rejection without mutation. Its bulk outcome changes
from uncertain to failed/rate-limited, retains `Retry-After`, and stops the
remaining batch. This is a provider-specific interpretation of the documented
response, not an inference from an arbitrary generic quota problem.

The existing submission classification branch is unchanged. Its rejection,
retryable-failure and Retry-After assertions remain, with additional peer
assertions confirming the quota code and one request. Unknown HTTP 499 remains
uncertain. The apply whitelist was expanded only by 429; the peer's broader
whole-operation whitelist and additional apply 410 classification were not
adopted. Other established rejection and send assertions were retained.

## Test reconciliation

Five test files are exact byte copies of the incoming peer versions; their
commit/blob/SHA-256 bindings are in `imported-peer-tests.json`:

- `bulk_flags_provider_results_test.dart`: retains its original cases and adds
  the peer's 33 lines covering three quota-evidence states.
- `cloud_provider_test.dart`: distinguishes documented 429 rejection from
  unfamiliar 499 uncertainty, preserves the pending tail, and checks the
  Retry-After evidence without extra requests.
- The cloud, EWS, and native unsupported-provider test files: confirm that
  unsupported adapters produce definite failures through `fromResult`. Their
  implementation already supplied explicit no-mutation evidence.

The original `bulk_flags_test.dart` and exact imported
`bulk_flags_coordinator_test.dart` remain. The combined compatibility suite adds
six cases across the runner and coordinator. They cover all three quota
evidence values, confirmed-prefix preservation, no tail dispatch, exact problem
and command identity, Retry-After retention, and precedence over simultaneous
scope retirement and stop requests.

The peer's reentrant-guard, contradictory-evidence, immutable-report and
single-use cases were already covered by the retained suites. Its new
predispatch stale-scope scenarios also have existing dispatch/count/reason
coverage; the different refresh-helper expectation is addressed by the explicit
core/host API decision above. Shared UI production did not change after the
reviewed peer baseline, and its added Escape test was already in the accepted
UI suite.

## Local qualification

| Cohort/check | Result |
| --- | --- |
| Complete mail-core Dart VM suite | **214 passed** |
| Four bulk suites compiled to JavaScript and run on Node | **120 passed** |
| Native, EWS and cloud provider boundaries | **195 passed** |
| Three unsupported-provider suites compiled to JavaScript and run on Node | **6 passed** |
| Complete core and transport analysis | **No issues found** |
| Formatting | **Eight files checked; zero changes** |
| Scoped whitespace | **Passed** |

These cohorts overlap and must not be summed as unique tests. `receipt.json`
records commands, working directories, exit codes, timings and log hashes.
`source-before.json` and `source-after.json` include every core/transport
library/test/tool Dart file plus the lock, analysis configuration and package
configuration. All hashes remained stable during every check and across the
whole run. The pinned runtime and locked dependencies were reused; no live
provider requests or GitHub Actions checks were made.

Receipt SHA-256:
`a24111ba610006f7f27192364f536340ccb641c8446a86196570cbe19c2a654d`.

Earlier acceptance receipts and the prior `00d44` inheritance proof remain
historical evidence for their exact source versions. Publication binding for
this increment is recorded in `publication-binding.json`: every tracked
core/transport input matches published commit
`64da231816b1b3ddab35e0e12d50d885bf24f75f`.

The separate `../../fixture-applicability.json` proves that all of those inputs
and the accepted Word inputs remain unchanged at
`44f3f61fa7d812971e973f1763ac8e04eb39785a`. That follow-up changes only the new
native host test fixture's construction; fresh host/Flutter acceptance is
recorded separately and is not inferred from this core receipt.
