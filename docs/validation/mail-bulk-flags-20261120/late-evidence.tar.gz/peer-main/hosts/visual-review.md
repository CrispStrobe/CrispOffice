# Final localized receipt visual review

Reviewed source: `44f3f61fa7d812971e973f1763ac8e04eb39785a` (tree `9ad9555b01e5c0a0872f868356c232e669a8b977`). The seven source bindings and accepted host/visual receipt entries are recorded in [visual-review.json](visual-review.json). No source or image was changed.

## Six new captures

Each original PNG was opened individually with `view_image`. The fixture uses a **440 × 850 logical surface, 1.4 text scale and 1.5 capture pixel ratio**; each PNG is **660 × 1275 pixels**. The real font fixture loads Liberation Sans and Tajawal regular/bold.

| Capture pair | Observation |
| --- | --- |
| English receipt and details | All four summary counts and refresh guidance are readable. Distinct confirmed, failed and uncertain explanations fit the detail list; title and Close remain clear. |
| German receipt and details | Long labels and instructions wrap without horizontal overflow. The third detail explanation continues below the initial list viewport; the fixed Schließen action remains visible. |
| Arabic receipt and details | Arabic glyphs join correctly. Headings, counts, messages and details follow right-to-left flow. The Close action correctly mirrors to the lower left. |

**No concrete visual defect was found in these six captures.**

## Scrolling and retry guidance

The dialog intentionally displays a bounded, scrolling list. In all three detail captures the fourth result is below the initial viewport; in German, part of the third explanation is below it too. This does not obscure the fixed Close action. The accepted `studio_mail_bulk_provider_test.dart` cases for EN/DE/AR use a smaller **320 × 260 surface at 1.5 text scale**, open the dialog, scroll to `studio-mail-bulk-result-3`, find its subject and close the dialog without exceptions. These interaction cases are recorded in the accepted **378-test host receipt**. The screenshot alone is not treated as proof of a scrolling gesture.

The six PNGs visually qualify the translated refresh-before-another-change guidance. They **do not show numeric Retry-After text or the rate-limited summary**, because their fixture is a mixed confirmed/failed/uncertain/unattempted report without a quota problem. Accepted provider tests separately assert the English 12-second wait message, and the native test asserts the rounded 2-second message in both summary and details. This review makes no additional claim of visual DE/AR quota-state coverage.

## Prior capture preservation

All **20 pre-existing PNGs**—15 Studio selection/action/working captures and five shared-UI captures—are **exactly byte-identical** to the raw PNG members in the immutable baseline `docs/validation/mail-bulk-flags-20261120/evidence.tar.gz`.

Baseline archive SHA256: `63e9efefcf3eb36ef3ae06483cd1d8da622560265494a3c8de9e0f8713d65074`.

The JSON records each baseline member, current filename, byte size and both SHA256 values. The accepted source-bound visual receipts report **5 shared-UI tests and 8 Studio tests**, with unchanged source manifests. All 26 reviewed or compared files remain unmodified.
