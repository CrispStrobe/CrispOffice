#!/usr/bin/env python3
"""Verify the post-peer Office receipts against their frozen remote checkpoint."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess

ROOT=Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
BASE=ROOT.parent/'late-main-validation/peer-main'
COMMIT='64da231816b1b3ddab35e0e12d50d885bf24f75f'
TREE='e8a89e675839f54b75b66a898fccc656d6d9bcdb'
BASELINE='63e9efefcf3eb36ef3ae06483cd1d8da622560265494a3c8de9e0f8713d65074'

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

parser=argparse.ArgumentParser();parser.add_argument('scope',choices=['word','zotero']);args=parser.parse_args()
out=BASE/args.scope
word=args.scope=='word'
assert subprocess.check_output(['git','rev-parse',COMMIT+'^{tree}'],cwd=ROOT,text=True).strip()==TREE
raw=subprocess.check_output(['git','ls-tree','-rz','--full-tree',COMMIT,'--','packages/quds_office_engine','packages/quds_office_editor/test/office_system_fonts_test.dart','pubspec.yaml','pubspec.lock'],cwd=ROOT)
blobs={}
for entry in raw.split(b'\0'):
 if not entry:continue
 metadata,path=entry.split(b'\t',1)
 mode,kind,sha=metadata.split()
 if kind==b'blob':blobs[path.decode()]=sha.decode()

names=([f'word-{phase}' for phase in ['vm','node','analyze','format-check']]+[name+'-driver-'+phase for name in ['measurements','named_measurements'] for phase in ['vm','js-compile','js-run']]+['focused-vm','focused-analyze','focused-format-check']) if word else [f'zotero-{phase}' for phase in ['vm','node','analyze','format-check']]
items=[];manifests={};combined={};diagnostics=[]
for name in names:
 path=out/(name+'.json');receipt=json.loads(path.read_text())
 assert receipt['exit_code']==0 and receipt['failure'] is None,name
 assert receipt['source_unchanged'] and receipt['source_before']==receipt['source_after'],name
 assert digest(Path(receipt['log']))==receipt['log_sha256'],name
 snapshot=receipt['source_before']
 group='focused' if name.startswith('focused-') else 'combined'
 if group in manifests:assert manifests[group]==snapshot,name
 else:manifests[group]=snapshot
 for source,sha in snapshot.items():
  actual=(ROOT/source).read_bytes()
  assert hashlib.sha256(actual).hexdigest()==sha,(name,source,'worktree drift')
  assert blob(actual)==blobs[source],(name,source,'checkpoint mismatch')
  if source in combined:assert combined[source]==sha,(name,source,'cohort disagreement')
  combined[source]=sha
 if name.endswith('-analyze'):
  for line in Path(receipt['log']).read_text().splitlines():
   match=re.match(r'\s*(info|warning|error) - (.*)',line)
   if match:diagnostics.append({'run':name,'severity':match.group(1),'message':match.group(2)})
 items.append({'name':name,'receipt':str(path),'receipt_sha256':digest(path),'log_sha256':receipt['log_sha256'],'exit_code':0,'passed':receipt.get('passed'),'duration_seconds':receipt['duration_seconds'],'source_unchanged':True,'matches_checkpoint':True})

prefix='word' if word else 'zotero'
vm=json.loads((out/(prefix+'-vm.json')).read_text())['passed']
node=json.loads((out/(prefix+'-node.json')).read_text())['passed']
assert (vm,node)==((929,787) if word else (165,117)),(vm,node)
comparisons=[]
if word:
 for name in ['measurements','named_measurements']:
  path=out/(name+'-vm-js-comparison.json');v=json.loads(path.read_text())
  assert v['vm_exit_code']==v['js_exit_code']==0
  assert v['json_equal'] and v['vm_json']==v['js_json']
  assert digest(Path(v['bas']))==v['bas_sha256'] and digest(Path(v['driver']))==v['driver_sha256']
  comparisons.append({'name':name,'receipt':str(path),'receipt_sha256':digest(path),'json_equal':True,'bas_sha256':v['bas_sha256'],'driver_sha256':v['driver_sha256']})
 assert json.loads((out/'focused-vm.json').read_text())['passed']==244
 assert not diagnostics,diagnostics
 archive=ROOT/'docs/validation/mail-bulk-flags-20261120/evidence.tar.gz'
 assert digest(archive)==BASELINE

keys=['packages/quds_office_engine/lib/src/word/layout/word_layout.dart','packages/quds_office_engine/lib/src/word/serial/word_deserializer.dart','pubspec.lock']
result={'scope':'Expanded Word and focused import/layout acceptance after the reviewed peer Office union.' if word else 'Affected Zotero table/roundtrip and protocol follow-up after the Office union; not a rerun of the historical full Zotero cohort.','qualified_source_commit':COMMIT,'qualified_source_tree':TREE,'head_at_audit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'vm_passed':vm,'vm_suites':14 if word else 3,'node_passed':node,'node_suites':9 if word else 2,'focused_vm_passed':244 if word else None,'focused_vm_suites':20 if word else None,'counting_note':'The Node cohort also occurs on VM; focused Word tests overlap combined Word. Do not sum these into a unique total. Earlier receipts retain their original source bindings.','source_manifests':{group:{'files':len(snapshot),'sha256':hashlib.sha256(json.dumps(snapshot,sort_keys=True,separators=(',',':')).encode()).hexdigest()} for group,snapshot in manifests.items()},'key_source_sha256':{key:combined[key] for key in keys},'all_runs_passed':True,'all_runs_source_stable':True,'all_recorded_sources_match_checkpoint_and_worktree':True,'analysis_clean':not diagnostics,'analysis_diagnostics':diagnostics,'receipts':items,'bas_comparisons':comparisons,'runner_sha256':digest(out/'run.py'),'auditor_sha256':digest(Path(__file__)),'limits':['JavaScript executed on Node, not a native browser/WASM runtime.','No installed Word/Zotero desktop host or live provider session was exercised.']}
if word:result.update({'focused_runner_sha256':digest(out/'focused.py'),'baseline_archive_unchanged_sha256':BASELINE})
(out/'qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:result[key] for key in ['scope','qualified_source_commit','vm_passed','node_passed','focused_vm_passed','source_manifests','all_runs_passed','analysis_clean','all_recorded_sources_match_checkpoint_and_worktree']},indent=2))
