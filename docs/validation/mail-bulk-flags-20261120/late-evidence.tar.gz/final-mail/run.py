import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

SCRATCH = Path('/workspace/scratch/33e256b7ecf8')
ROOT = SCRATCH / 'quds_office_suite'
OUT = Path(__file__).resolve().parent
DART = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/dart-sdk/bin/dart'
FLUTTER = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/flutter_tools.snapshot'
EXAMPLE = ROOT / 'packages/quds_office_editor/example'
UI = ROOT / 'packages/quds_mail_ui'
tests = [
    'studio_mail_bulk_provider_test.dart', 'studio_mail_message_loader_test.dart',
    'studio_mail_workspace_test.dart', 'studio_mail_ews_test.dart',
    'studio_mail_cloud_test.dart', 'studio_mail_cached_host_test.dart',
    'studio_mail_cached_mail_test.dart',
]
host_inputs = json.loads((SCRATCH / 'mail-host-validation/receipt.json').read_text())[0]['source_hashes']
ui_inputs = json.loads((SCRATCH / 'mail-ui-validation/cutoff-peer-receipt.json').read_text())[0]['source_hashes_before']
paths = sorted(set(host_inputs) | set(ui_inputs) | {str(path.relative_to(ROOT)) for path in ROOT.glob('packages/*/lib/**/*.dart')} | {str(path.relative_to(ROOT)) for path in ROOT.glob('packages/quds_office_editor/example/lib/**/*.dart')} | {str(path.relative_to(ROOT)) for path in (ROOT / 'packages/quds_office_editor/test').glob('*.dart')} | {
    'packages/quds_office_editor/lib/src/embed/office_system_fonts_io.dart',
    'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
    'packages/quds_office_engine/lib/src/word/serial/word_deserializer.dart',
    'packages/quds_office_editor/example/test/studio_comment_draft_proofing_test.dart',
    'packages/quds_office_editor/example/test/studio_word_chrome_settle_test.dart',
    'packages/quds_office_editor/tool/zotero/research_target_acceptance.dart',
})


def hashes():
    return {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in paths}


flutter = [str(DART), str(FLUTTER), '--no-version-check', 'test', '--no-pub', '--concurrency=1', '--reporter', 'expanded']
commands = [
    ('hosts', EXAMPLE, flutter + ['test/' + test for test in tests], {}),
    ('ui', UI, flutter, {}),
    ('ui-visual', UI, flutter + ['tool/bulk_flags_visual_test.dart'], {'MAIL_BULK_UI_EVIDENCE': str(OUT / 'ui-screenshots')}),
    ('studio-visual', EXAMPLE, flutter + ['--dart-define=MAIL_BULK_SCREENSHOT_DIR=' + str(OUT / 'studio-screenshots'), 'test/studio_mail_bulk_visual_test.dart'], {}),
    ('analysis', EXAMPLE, [str(DART), 'analyze',
        'lib/studio_mail_bulk_status.dart', 'lib/studio_mail_ews.dart',
        'lib/studio_mail_native.dart', 'lib/studio_mail_message_loader.dart',
        'lib/studio_mail_workspace_strings.dart',
        *['test/' + test for test in tests],
        '../lib/src/embed/office_system_fonts_io.dart',
    ], {}),
]
editor_suites = [
    'word_zotero_adjacent_citations_controller_test.dart',
    'word_incremental_layout_equivalence_test.dart',
    'word_zotero_add_note_controller_test.dart',
    'word_zotero_note_target_test.dart',
    'word_zotero_note_image_controller_test.dart',
    'word_zotero_citing_controller_test.dart',
    'word_zotero_citing_dialog_test.dart',
    'word_zotero_direct_command_test.dart',
    'word_zotero_bibliography_controller_test.dart',
    'word_zotero_rich_controller_test.dart',
    'word_proofing_session_test.dart',
    'word_proofing_capture_cache_test.dart',
]
EDITOR = ROOT / 'packages/quds_office_editor'
commands += [
    ('zotero-editor', EDITOR, flutter + ['test/' + test for test in editor_suites], {}),
    ('zotero-studio', EXAMPLE, flutter + ['test/studio_comment_draft_proofing_test.dart', 'test/studio_word_chrome_settle_test.dart'], {}),
    ('zotero-editor-analysis', EDITOR, [str(DART), 'analyze', 'test/word_zotero_add_note_controller_test.dart', 'test/word_zotero_adjacent_citations_controller_test.dart', 'tool/zotero/research_target_acceptance.dart'], {}),
]
records = []
for name, cwd, command, overrides in commands:
    before = hashes()
    started = time.time()
    print('START', name, flush=True)
    log = OUT / (name + '.log')
    with log.open('w') as output:
        result = subprocess.run(command, cwd=cwd, env=os.environ | overrides, stdout=output, stderr=subprocess.STDOUT)
    after = hashes()
    content = log.read_text()
    counts = re.findall(r'\+(\d+)(?: ~(\d+))?: All tests passed!', content)
    record = dict(
        name=name, command=command, cwd=str(cwd), environment_overrides=overrides,
        exit_code=result.returncode, elapsed_seconds=round(time.time() - started, 3),
        passed=int(counts[-1][0]) if counts else None, skipped=int(counts[-1][1] or 0) if counts else None, source_hashes_before=before,
        source_hashes_after=after, sources_unchanged=before == after,
        log=log.name, log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
    )
    records.append(record)
    (OUT / 'receipt.json').write_text(json.dumps(records, indent=2) + '\n')
    print('DONE', name, result.returncode, record['passed'], record['elapsed_seconds'], flush=True)
    print('\n'.join(content.splitlines()[-8:]), flush=True)
    if result.returncode or before != after:
        raise SystemExit(result.returncode or 1)

comparisons = []
for kind, previous, current in [
    ('shared-ui', SCRATCH / 'mail-ui-validation/ui-cutoff-screenshots', OUT / 'ui-screenshots'),
    ('studio', SCRATCH / 'mail-ui-validation/peer-cutoff-screenshots', OUT / 'studio-screenshots'),
]:
    expected = sorted(path.name for path in previous.glob('*.png'))
    actual = sorted(path.name for path in current.glob('*.png'))
    assert expected == actual, (kind, expected, actual)
    for name in actual:
        a = hashlib.sha256((previous / name).read_bytes()).hexdigest()
        b = hashlib.sha256((current / name).read_bytes()).hexdigest()
        comparisons.append(dict(cohort=kind, file=name, baseline_sha256=a, current_sha256=b, identical=a == b))
(OUT / 'visual-comparison.json').write_text(json.dumps(comparisons, indent=2) + '\n')
print('Visual comparison:', len(comparisons), 'captures;', sum(row['identical'] for row in comparisons), 'byte-identical', flush=True)
