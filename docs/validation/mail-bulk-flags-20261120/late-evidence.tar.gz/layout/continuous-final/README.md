# Continuous-section body-frame follow-up

This is a follow-up to the accepted 145-test layout qualification in the parent
directory. That qualification and all prior failing evidence remain unchanged.

## Reproduction and repair

The standalone probe in `../continuous_section_probe.dart` showed that the
continuous-section handoff copied prior header/footer frames into the next
body frame list. Two sections sharing one header rendered it twice; distinct
section headers left both old and current pictures. The same frames also
entered `_contentBottom`, so a footer pushed the next continuous body paragraph
onto a needless second page. The three original failures and unchanged source
hashes are recorded in `../continuous-probe-incoming.log` and its receipt.

The correction adds one private `_bodyFrames` iterator. Both the handoff and
content-bottom calculation now use the prefix recorded by `_PageOrigin`:
`page.frames.take(page._origin?.bodyFrames ?? page.frames.length)`, with the
existing note exclusion retained. The null-origin fallback follows the prior
`_splice` convention. `_makePage` recreates the current section's chrome once,
and body-frame accounting no longer includes carried chrome.

Only `word_layout.dart` and `word_header_visual_reconciliation_test.dart`
changed in this follow-up. The accepted contained-text geometry fixture and
the deserializer repair remain unchanged.

Three new regressions assert the shared-header case, replacement-header/body
preservation case, and footer/continuous-body position case. The body case
retains two legitimate pictures and compares incremental versus fresh full
layout after a subsequent paragraph edit. The test file now contains 12 cases.

## Accepted qualification

| Check | Result |
| --- | --- |
| Same 13-suite layout cohort plus three new cases | **148 passed** |
| Unchanged standalone reproduction probe | **All three expectations pass** |
| Narrow analyzer for the two changed files | **No issues found** |
| Formatter | **Two files checked; zero changes** |
| Scoped whitespace check | **Passed** |

`receipt.json` records every exact command, working directory, result, timing,
and log hash. The before/after manifests include every engine library Dart file,
the selected tests, lockfile, and package config. The hashes remained stable
during every check and across the complete run. The standalone probe hash is
also recorded, confirming the successful probe used the same source as the
original three-failure reproduction.

- Receipt SHA-256: `469d29b201ea707a0c711f7e84d590e56979ea0e1e70b97c8045d738964657ac`
- Final layout source SHA-256: `727b13db5d0b55e2978c10665d7ec073c206cfde876f38eb73d677d13dad27db`
- Final regression test SHA-256: `deec0611f02ffc0992b0e5db5ad221c2697b48d7a6feebcc0a8a0a9aea16cfff`
- Unchanged contained-text fixture SHA-256: `bd2a716360ec7cc20d28ce10b49885b2dcd0e8b940fd6dd46834720545cce730`

These counts overlap the earlier layout and broader Word cohorts; they are not
additional unique-test totals. Final combined Word/Flutter qualification is
owned and recorded separately by the root and runtime agents.
