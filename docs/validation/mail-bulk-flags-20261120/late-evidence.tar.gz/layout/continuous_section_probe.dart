import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:quds_office_engine/quds_office_engine.dart';

WmlParagraph paragraph(String text) =>
    WmlParagraph(inlines: [WmlRun(text: text)]);

OfficeVisual picture(String title, int byte, {double y = 20}) => OfficeVisual(
  kind: OfficeVisualKind.picture,
  title: title,
  imageBytes: Uint8List.fromList([byte, 2, 3, 4]),
  width: 32,
  height: 16,
  offsetX: 80,
  offsetY: y,
);

Map<String, Object?> probe(
  String name, {
  required OfficeVisual firstHeader,
  required OfficeVisual secondHeader,
  OfficeVisual? footer,
}) {
  WmlSection section(String text, OfficeVisual header, bool continuous) =>
      WmlSection(
        breakKind: continuous
            ? WmlSectionBreakKind.continuous
            : WmlSectionBreakKind.nextPage,
        blocks: [paragraph(text)],
        headerVisuals: [WmlVisual(visual: header)],
        footerVisuals: [if (footer != null) WmlVisual(visual: footer)],
      );
  final laid = WordLayoutEngine(font: null).layout(
    WmlDocument(
      sections: [
        section('First section', firstHeader, false),
        section('Second section', secondHeader, true),
      ],
    ),
    updateFields: false,
  );
  final pictures = laid.pages
      .expand((page) => page.frames)
      .where((frame) => frame.kind == LaidOutBoxKind.picture)
      .toList();
  final valid = laid.pages.length == 1 &&
      pictures.length == (footer == null ? 1 : 2) &&
      pictures.where((frame) => identical(frame.visual, secondHeader)).length ==
          1 &&
      (footer == null ||
          pictures.where((frame) => identical(frame.visual, footer)).length == 1);
  return {
    'case': name,
    'expected_pages': 1,
    'expected_picture_count': footer == null ? 1 : 2,
    'current_section_header_expected_once': secondHeader.title,
    'passed': valid,
    'actual_pages': [
      for (final page in laid.pages)
        {
          'index': page.index,
          'section_index': page.sectionIndex,
          'lines': [
            for (final line in page.lines)
              {'text': line.text, 'y': line.y, 'height': line.height},
          ],
          'pictures': [
            for (final frame in page.frames)
              if (frame.kind == LaidOutBoxKind.picture)
                {
                  'title': frame.visual?.title,
                  'x': frame.x,
                  'y': frame.y,
                  'width': frame.width,
                  'height': frame.height,
                },
          ],
        },
    ],
  };
}

void main() {
  final shared = picture('shared-header', 1);
  final first = picture('old-header', 2);
  final second = picture('current-header', 3);
  final footer = picture('shared-footer', 4);
  final cases = [
    probe(
      'shared header across two continuous sections',
      firstHeader: shared,
      secondHeader: shared,
    ),
    probe(
      'current section replaces previous header',
      firstHeader: first,
      secondHeader: second,
    ),
    probe(
      'footer must not advance continuous body to page bottom',
      firstHeader: shared,
      secondHeader: shared,
      footer: footer,
    ),
  ];
  print(const JsonEncoder.withIndent('  ').convert(cases));
  if (cases.any((result) => result['passed'] != true)) exitCode = 1;
}
