# Late-main header/footer image layout reconciliation

This supplement qualifies the layout changes imported from main commit
`e975cec13b289fe067ef406cd3044701ecc44744` and the bounded fixes made during
review. It does not alter or requalify the mail implementation.

## Reviewed defects and retained behavior

The incoming implementation could exclude a shared visual from both its inline
and separate header/footer representations. It also treated similar dimensions
as duplicate identity. A later page-wide filter compared position, dimensions,
and byte count without comparing image content or vertical placement. That
filter could remove legitimate chrome pictures and body picture frames, while
the incremental-layout origin still recorded the original body-frame count.

The accepted implementation keeps the separate representation of an identical
inline/separate object, suppresses exact picture duplicates only within the
current header or footer story, and compares placement, dimensions, complete
image bytes, and picture adjustments before suppressing a separate copy. It
does not delete or reorder body frames. Equal-size images, equal-byte-count
images with different content, distinct vertical placements, adjusted copies,
and independent header/footer copies remain visible. The incoming inline
header/footer picture support and replacement of the object marker in displayed
chrome text remain; the authored story remains unchanged.

The incoming default cell padding of 4.25pt remains. Its comment now correctly
states 85 twips. One existing cluster-wrapping fixture depended on the former
padding through a fixed 42pt cell width. Its grid now expresses the intended
31.2pt usable width as `31.2 + 2 * LaidOutLine.tableCellPad`; every existing exact
cluster-boundary, glyph-ownership, authored-text, and save-cycle assertion
remains unchanged.

## Recorded runs

| Evidence | Source/fixture stage | Result |
| --- | --- | --- |
| `incoming-regressions.log`, `incoming-receipt.json` | Unmodified incoming layout; initial nine-case fixture | 4 passed, 5 failed: shared representation disappeared; distinct same-size images collapsed; equal-byte-count content collapsed; vertical placement ignored; picture adjustments ignored |
| `incoming-body-regression.log`, `incoming-body-receipt.json` | Unmodified incoming layout; refined floating-body fixture | 1 failed: two legitimate body pictures became one |
| `picture-fixed-layout-tests.log`, `picture-fixed-layout-receipt.json` | Picture fix; original fixed-width Indic fixture | 144 passed, 1 failed: new cell padding changed the fixture's available content width |
| `accepted-layout-tests.log`, `accepted-layout-receipt.json` | Picture fix and geometry-preserving fixture correction | **145 passed** |
| `final-analysis.log`, `final-analysis-receipt.json` | All three final changed files | **No issues found** |

The first body fixture used ordinary block images and did not reach the incoming
filter's narrow top-of-page condition. The separately recorded reproduction
uses two legitimate floating body images near the header. The final case
checks both their preservation and incremental/full-layout fingerprint parity
after editing a subsequent body paragraph. The final inline-picture assertion
checks displayed overlay text directly; authored text still contains its
object marker.

The accepted cohort includes the nine new regression cases and 136 existing
cases across header/footer preservation, inline images, layout/styles,
contained text, nested and tall tables, incremental prefixes, and differential
layout. These counts overlap broader Word validation and must not be summed
as unique-test totals.

## Source binding

Every receipt records its exact command, exit status, log SHA-256, and source
binding. The accepted test and final analysis manifests include every engine
library Dart file, the selected tests, `pubspec.lock`, and the package config.
All recorded hashes remained unchanged during their runs.

- Accepted manifest: `accepted-source-hashes.json`
- Manifest SHA-256: `2ea2399eef6ac175f5128d4e46ddc79c4232ba29c297b2c29bcee52f8a221c46`
- Original incoming layout SHA-256: `6e27419ab6d4d27e1a3da12b3034bbd1e1d9aa664fd66ea024607ce650d80e6b`
- Final `word_layout.dart` SHA-256: `c27aaf40952b52f7bc9067b6f4fd9111a9dc4ec43a765b021ba531d075227e48`
- Final `word_header_visual_reconciliation_test.dart` SHA-256: `15c828da824d808f9d0054a80d0c8cea3cd528c092a5d0883cf23cc4bf32704b`
- Final `word_contained_text_wrap_test.dart` SHA-256: `bd2a716360ec7cc20d28ce10b49885b2dcd0e8b940fd6dd46834720545cce730`

Formatting produced no remaining changes and the scoped whitespace check
passed. Tests used the pinned restored Dart runtime and locked dependencies,
with test concurrency two. The original failing runs are retained rather than
reclassified as successful. Broader final Word VM/JavaScript validation is
recorded separately by the final qualification owner.
