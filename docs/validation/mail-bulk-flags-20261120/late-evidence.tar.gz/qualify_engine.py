#!/usr/bin/env python3
"""Audit final Word or focused Zotero command receipts against current source."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
BASE = ROOT.parent / 'late-main-validation'
BASELINE = '63e9efefcf3eb36ef3ae06483cd1d8da622560265494a3c8de9e0f8713d65074'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument('cohort', choices=['final-word', 'zotero'])
args = parser.parse_args()
folder = BASE / args.cohort
word = args.cohort == 'final-word'
prefix = 'word' if word else 'zotero'
names = [prefix + '-vm', prefix + '-node', prefix + '-analyze', prefix + '-format-check']
if word:
    names += [name + '-driver-' + phase for name in ['measurements', 'named_measurements'] for phase in ['vm', 'js-compile', 'js-run']]
receipts = []
snapshot = None
for name in names:
    path = folder / (name + '.json')
    value = json.loads(path.read_text())
    assert value['exit_code'] == 0 and value['failure'] is None, name
    assert value['source_unchanged'] and value['source_before'] == value['source_after'], name
    assert value['log_sha256'] == digest(Path(value['log'])), name
    if snapshot is None:
        snapshot = value['source_before']
    else:
        assert snapshot == value['source_before'], name
    receipts.append({'name': name, 'receipt': str(path), 'sha256': digest(path), 'log_sha256': value['log_sha256'], 'exit_code': 0, 'passed': value.get('passed'), 'source_unchanged': True, 'duration_seconds': value['duration_seconds']})
assert all((ROOT / path).is_file() and digest(ROOT / path) == sha for path, sha in snapshot.items()), 'Current source drifted'
vm = json.loads((folder / (prefix + '-vm.json')).read_text())
node = json.loads((folder / (prefix + '-node.json')).read_text())
if word:
    assert vm['passed'] == 893 and node['passed'] == 751
comparisons = []
if word:
    for name in ['measurements', 'named_measurements']:
        path = folder / (name + '-vm-js-comparison.json')
        value = json.loads(path.read_text())
        assert value['vm_exit_code'] == value['js_exit_code'] == 0
        assert value['json_equal'] and value['vm_json'] == value['js_json']
        assert digest(Path(value['driver'])) == value['driver_sha256']
        assert digest(Path(value['bas'])) == value['bas_sha256']
        comparisons.append({'name': name, 'receipt': str(path), 'receipt_sha256': digest(path), 'vm_exit_code': 0, 'js_exit_code': 0, 'json_equal': True, 'bas_sha256': value['bas_sha256'], 'driver_sha256': value['driver_sha256']})
archive = ROOT / 'docs/validation/mail-bulk-flags-20261120/evidence.tar.gz'
assert digest(archive) == BASELINE
keys = [
    'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
    'packages/quds_office_engine/lib/src/word/serial/word_deserializer.dart',
    'pubspec.lock',
]
keys += (['packages/quds_office_engine/test/word_header_visual_reconciliation_test.dart', 'packages/quds_office_engine/test/word_table_style_import_regression_test.dart'] if word else [
    'packages/quds_office_engine/lib/src/word/model/word_zotero.dart',
    'packages/quds_office_engine/lib/src/word/model/word_zotero_citing.dart',
    'packages/quds_office_engine/lib/src/word/model/word_zotero_note.dart',
    'packages/quds_office_engine/lib/src/zotero/zotero_citing.dart',
])
analysis_diagnostics = []
for line in (folder / (prefix + '-analyze.log')).read_text().splitlines():
    match = re.match(r'\s*(info|warning|error) - (.*)', line)
    if match:
        analysis_diagnostics.append({'severity': match.group(1), 'message': match.group(2)})
result = {
    'scope': 'Fresh combined Word acceptance including continuous-section chrome fixes on the integrated Zotero main source.' if word else 'Focused acceptance for the four incoming Zotero production changes on the integrated and repaired engine source.',
    'head_at_receipt_audit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'publication_status': 'Qualified only for the exact source hashes in these receipts; any later source change requires an applicability check or rerun.',
    'vm_passed': vm['passed'], 'vm_suites': 12 if word else 6,
    'node_passed': node['passed'], 'node_suites': 7 if word else 4,
    'counts_note': 'Each count comes from one complete invocation. Node cases also occur in the VM cohort. The 14 import and 12 layout regressions are included in the Word totals; separate focused cohorts overlap.' if word else 'Each count comes from one complete invocation. The four Node-compatible suites also occur in the six-suite VM cohort. Historical author-source results and editor coverage are separate.',
    'recorded_source_files': len(snapshot),
    'source_manifest_sha256': hashlib.sha256(json.dumps(snapshot, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
    'key_source_sha256': {key: snapshot[key] for key in keys},
    'all_runs_passed': True, 'analysis_exit_code': 0, 'analysis_clean': not analysis_diagnostics, 'analysis_diagnostics': analysis_diagnostics, 'all_runs_source_stable': True, 'all_runs_same_source_manifest': True, 'current_source_matches_receipts': True,
    'receipts': receipts, 'bas_comparisons': comparisons,
    'runner': 'run.py', 'runner_sha256': digest(folder / 'run.py'),
    'qualification_auditor': '../qualify_engine.py', 'qualification_auditor_sha256': digest(Path(__file__)),
    'baseline_archive_unchanged_sha256': BASELINE,
    'limits': ['Compiled JavaScript ran on Node, not in a browser or WASM.', 'No installed Microsoft Word or live Zotero desktop session was exercised.', 'Original source-bound evidence remains preserved separately.'],
}
(folder / 'qualification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['scope', 'head_at_receipt_audit', 'vm_passed', 'node_passed', 'recorded_source_files', 'source_manifest_sha256', 'all_runs_passed', 'all_runs_source_stable', 'current_source_matches_receipts']}, indent=2))
