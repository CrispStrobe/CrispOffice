#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,re,subprocess,time
ROOT=Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
OUT=ROOT.parent/'late-main-validation/peer-office-review'
ENGINE=ROOT/'packages/quds_office_engine'
REF='0a2afc41bae4e719b77657a7e2d8d3e7ec02849b'
PATH='packages/quds_office_engine/test/word_table_style_precedence_test.dart'
raw=subprocess.check_output(['git','show',REF+':'+PATH],cwd=ROOT)
fixture=OUT/'word_table_style_precedence_test.dart'
fixture.write_bytes(raw)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
 paths=set((ENGINE/'lib').rglob('*.dart'))
 paths.update((ENGINE/'test/support').rglob('*.dart'))
 paths.update([ROOT/'pubspec.lock',ROOT/'pubspec.yaml',ENGINE/'pubspec.yaml'])
 return {str(p.relative_to(ROOT)):digest(p) for p in sorted(paths)}
before=snapshot()
command=[str(ROOT.parent/'runtime/bin/dart'),'--packages='+str(ROOT/'.dart_tool/package_config.json'),str(Path(os.environ['PUB_CACHE'])/'hosted/pub.dev/test-1.31.1/bin/test.dart'),'--reporter','expanded','--concurrency=1',str(fixture)]
log=OUT/'current-source-table-probe.log'
start=time.time()
with log.open('wb') as stream: run=subprocess.run(command,cwd=ENGINE,stdout=stream,stderr=subprocess.STDOUT,timeout=120)
after=snapshot()
result={'scope':'Exact incoming table regression suite against unchanged qualified 00d44 production, copied only to scratch.', 'incoming_ref':REF,'incoming_path':PATH,'fixture_sha256':digest(fixture),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'argv':command,'cwd':str(ENGINE),'exit_code':run.returncode,'duration_seconds':time.time()-start,'log':str(log),'log_sha256':digest(log),'source_before':before,'source_after':after,'source_unchanged':before==after}
(OUT/'current-source-table-probe.json').write_text(json.dumps(result,indent=2)+'\n')
print(log.read_text()[-5000:])
