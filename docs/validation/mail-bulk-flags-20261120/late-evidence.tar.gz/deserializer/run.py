#!/usr/bin/env python3
"""Qualify the repaired late-main Word table import behavior locally."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
ENGINE = ROOT / 'packages/quds_office_engine'
OUT = ROOT.parent / 'late-main-validation/deserializer'
OUT.mkdir(parents=True, exist_ok=True)
NEW = 'test/word_table_style_import_regression_test.dart'
EXISTING = [
    'test/style_cascade_test.dart',
    'test/word_styles_layout_test.dart',
    'test/word_structure_integrity_test.dart',
    'test/word_table_test.dart',
    'test/word_table_direction_test.dart',
]
DART = shutil.which('dart')
TEST = Path(os.environ['PUB_CACHE']) / 'hosted/pub.dev/test-1.31.1/bin/test.dart'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot():
    files = set((ENGINE / 'lib').rglob('*.dart'))
    files.update(ENGINE / path for path in [NEW, *EXISTING])
    files.update((ENGINE / 'test/support').rglob('*.dart'))
    files.update([ROOT / 'pubspec.lock', ROOT / 'pubspec.yaml', ENGINE / 'pubspec.yaml'])
    return {str(path.relative_to(ROOT)): digest(path) for path in sorted(files)}


def run(name, argv):
    before = snapshot()
    start = time.time()
    log = OUT / f'{name}.log'
    with log.open('wb') as stream:
        result = subprocess.run(argv, cwd=ENGINE, stdout=stream, stderr=subprocess.STDOUT, timeout=1200)
    after = snapshot()
    output = log.read_text(errors='replace')
    totals = re.findall(r'\+(\d+)', output)
    receipt = {
        'name': name,
        'argv': argv,
        'cwd': str(ENGINE),
        'exit_code': result.returncode,
        'duration_seconds': round(time.time() - start, 3),
        'source_before': before,
        'source_after': after,
        'source_unchanged': before == after,
        'log': str(log),
        'log_sha256': digest(log),
    }
    if 'All tests passed!' in output and totals:
        receipt['passed'] = int(totals[-1])
    (OUT / f'{name}.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: value for key, value in receipt.items() if key not in {'source_before', 'source_after'}}), flush=True)
    print(output[-3000:], flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['regressions', 'focused', 'node', 'static'])
    phase = parser.parse_args().phase
    common = [DART, f'--packages={ROOT / ".dart_tool/package_config.json"}', str(TEST), '--reporter', 'expanded', '--concurrency=1']
    if phase == 'regressions':
        run('repaired-regressions', common + [NEW])
    elif phase == 'focused':
        run('focused-vm', common + [NEW, *EXISTING])
    elif phase == 'node':
        run('regressions-node', common + ['--platform=node', NEW])
    else:
        files = ['lib/src/word/serial/word_deserializer.dart', NEW]
        run('analyze', [DART, 'analyze', *files])
        run('format', [DART, 'format', '--output=none', '--set-exit-if-changed', *files])
