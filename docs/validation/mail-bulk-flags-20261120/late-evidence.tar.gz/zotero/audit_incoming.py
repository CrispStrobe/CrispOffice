#!/usr/bin/env python3
"""Verify incoming archival receipts and their applicability to current Zotero source."""
from pathlib import Path
import collections
import hashlib
import json
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
OUT = ROOT.parent / 'late-main-validation/zotero'
EVIDENCE = ROOT / 'docs/validation/zotero-merged-cells-20261120'
MAIN = '698209aaa6e7f1350b6541df5eb192b7b233443d'
PRODUCTION = [
    'packages/quds_office_engine/lib/src/word/model/word_zotero.dart',
    'packages/quds_office_engine/lib/src/word/model/word_zotero_citing.dart',
    'packages/quds_office_engine/lib/src/word/model/word_zotero_note.dart',
    'packages/quds_office_engine/lib/src/zotero/zotero_citing.dart',
]
TESTS = [
    'word_zotero_adjacent_citations_test.dart',
    'word_zotero_note_table_test.dart',
    'word_zotero_note_tables_integration_test.dart',
    'word_zotero_add_note_test.dart',
    'word_zotero_citing_test.dart',
    'zotero_citing_test.dart',
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def recount(data):
    events = []
    for line in data.decode().splitlines():
        if not line.strip():
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            assert not line.lstrip().startswith('{'), line
    starts = {row['test']['id']: row['test'] for row in events if row['type'] == 'testStart'}
    completed = set()
    counts = collections.Counter()
    skipped = []
    for row in events:
        if row['type'] != 'testDone':
            continue
        identity = row['testID']
        assert identity not in completed
        completed.add(identity)
        name = starts[identity]['name']
        if row.get('hidden') or name.startswith('loading ') or name.endswith(('(setUpAll)', '(tearDownAll)')):
            continue
        outcome = 'skipped' if row.get('skipped') else row['result']
        counts[outcome] += 1
        if outcome == 'skipped':
            skipped.append(name)
    done = [row for row in events if row['type'] == 'done']
    errors = [row for row in events if row['type'] == 'error']
    assert completed == set(starts)
    assert len(done) == 1 and done[0]['success'] is True
    assert not errors and not counts['failure'] and not counts['error']
    return {'passed': counts['success'], 'skipped': counts['skipped'], 'failed': 0, 'errors': 0, 'skipped_cases': skipped, 'done_success': True}


receipt = json.loads((EVIDENCE / 'qualification.json').read_text())
archive = EVIDENCE / receipt['archive']['path']
assert len(archive.read_bytes()) == receipt['archive']['bytes']
assert digest(archive.read_bytes()) == receipt['archive']['sha256']
verified = {}
recounts = {}
with tarfile.open(archive) as bundle:
    for name, entry in receipt['archive']['members'].items():
        raw = bundle.extractfile('local-validation/' + name).read()
        assert len(raw) == entry['bytes'], name
        assert digest(raw) == entry['sha256'], name
        verified[name] = entry
    raw_names = {member.name for member in bundle if member.isfile()}
    assert raw_names == {'local-validation/' + name for name in verified}
    for name, expected in [('final-main-engine', (495, 0)), ('final-main-editor', (378, 8)), ('final-main-incoming', (928, 0)), ('final-formatted-incoming', (405, 0))]:
        data = bundle.extractfile('local-validation/' + name + '.jsonl').read()
        result = recount(data)
        assert (result['passed'], result['skipped']) == expected
        assert bundle.extractfile('local-validation/' + name + '.stderr').read() == b''
        recounts[name] = result

current = {}
for path in PRODUCTION + ['packages/quds_office_engine/test/' + name for name in TESTS]:
    incoming = subprocess.check_output(['git', 'show', MAIN + ':' + path], cwd=ROOT)
    actual = (ROOT / path).read_bytes()
    current[path] = {'current_sha256': digest(actual), 'incoming_main_sha256': digest(incoming), 'exact_main_bytes': incoming == actual}
    assert incoming == actual, path

result = {
    'incoming_main_commit': MAIN,
    'head_at_audit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'incoming_qualification_sha256': digest((EVIDENCE / 'qualification.json').read_bytes()),
    'archive': {'path': str(archive.relative_to(ROOT)), 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()), 'verified_members': len(verified), 'all_declared_members_verified': True, 'no_undeclared_files': True},
    'historical_recounts': recounts,
    'historical_count_note': 'These are incoming author-source results only. The 405-case formatting follow-up is a subset of the 928 incoming cohort; do not add it. Current integrated source is qualified separately in zotero-vm/node and final-word receipts.',
    'current_source_matches_incoming_main': current,
}
(OUT / 'incoming-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'archive': result['archive'], 'historical_counts': {k:{x:v[x] for x in ['passed','skipped','failed','errors']} for k,v in recounts.items()}, 'exact_main_source_and_tests': len(current)}, indent=2))
