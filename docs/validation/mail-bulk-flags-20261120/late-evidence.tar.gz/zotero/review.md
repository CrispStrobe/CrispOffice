# Incoming Zotero source review and current-source acceptance

Reviewed incoming main `698209aaa6e7f1350b6541df5eb192b7b233443d` (PR 276) against its first parent. The four production files and six selected engine suites retain the exact incoming bytes. `incoming-audit.json` records the SHA256 comparison against Git objects and verifies the archived upstream receipts.

## Findings

No concrete defect requiring an implementation change was found in the four incoming production changes.

- **Citation adjacency:** `WordZotero.adjacentCitationPairs` groups editable citation packets by paragraph identity, scans actual inline packet endpoints, and refuses structural, comment, paragraph and cell boundaries. Empty ordinary formatting runs may be skipped, but linked, atomic, commented or nonempty runs break adjacency. The map is immutable. This avoids treating equal visible text offsets as sufficient proof of adjacency.
- **Citing session:** `Document.getFields` advertises adjacency only to the next enumerated original citation, in the same note and without a staged note move. Bibliography entries and staged insertions cannot be bridged. Reported native adjacency is checked again before applying staged updates. Existing staged result/update/delete commands perform merging; no extra unsupported protocol command is introduced.
- **Merged research-note cells:** parsing accepts horizontal spans from 1 through 32, validates a bounded per-column width vector, reconciles each logical column across rows, and retains a rectangular logical grid. Zero widths mean unspecified; unspecified columns receive the existing 120-point default. The resulting table width remains bounded, and each native cell receives the sum of its columns. Vertical merges, nested tables, malformed widths and inconsistent grids are still refused before document publication.
- **Protocol capabilities:** citation merging and text insertion must be Boolean when present; document import/export remains unsupported. The relaxed capability check corresponds to already implemented field mutation operations.

## Current-source acceptance scope

`run.py` executes these six suites on Dart VM:

1. `word_zotero_adjacent_citations_test.dart`
2. `word_zotero_note_table_test.dart`
3. `word_zotero_note_tables_integration_test.dart`
4. `word_zotero_add_note_test.dart`
5. `word_zotero_citing_test.dart`
6. `zotero_citing_test.dart`

The first four also compile to JavaScript and run on Node. The last two use `dart:io` to exercise the HTTP protocol with local fixtures and are VM-only. No Flutter engine process is required for this cohort. Static analysis and formatting cover all four changed production files and all six selected suites. Each command binds all engine library files, selected tests, shared test helpers and dependency locks before and after execution.

This covers native adjacency and staged merging, stale structural boundaries, long citation chains, note/table/cell boundaries, note insertion and replacement, merged-cell ownership, widths and bounds, DOCX save/reopen, and capability/transaction validation. The root agent separately runs the incoming editor aggregate's twelve editor suites and two Studio suites in one Flutter process. Its full list is preserved in `packages/quds_office_editor/tool/zotero/research_target_acceptance.dart`; those tests are not counted in this engine cohort.

The separate `../final-word/` acceptance binds the same integrated engine source and exercises Word import/layout regressions plus both actual BASIC macro fixtures on VM and compiled JavaScript. No separate Zotero script driver was introduced by PR 276; the engine and editor aggregate Dart files only collect existing suites.

## Incoming historical evidence audit

`audit_incoming.py` independently verifies the archive SHA256 and all 48 declared members, with no extra files, and recounts the raw Dart/Flutter test events. The incoming author's final engine cohort records 495 passes; editor records 378 passes and eight image-only skips; incoming Word/Mail records 928 passes. The 405-case formatting rerun is a subset of the 928, not an additional cohort. These are preserved historical results at their recorded source bindings. They are not substituted for the current integrated-source receipts generated here.

Tests use in-memory document fixtures and local protocol fixtures. They do not claim a live Zotero desktop session, native browser/WASM execution, or installed platform release validation.

## Observed current-source results

The focused VM invocation passed **282 tests**; the four portable suites passed **175 tests** after compilation to JavaScript and execution on Node. Analysis exited successfully with one retained incoming test-only style info (`curly_braces_in_flow_control_structures` at `test/zotero_citing_test.dart:582`); the four production targets had no diagnostics. Formatting reported **10 files, zero changes**. All four command receipts shared one unchanged 408-file source manifest and matched the worktree when audited at `00d44a69d19de20cdb7754b754c4d32d86d078cc`. See `qualification.json` for receipt hashes and complete source bindings.

The unchanged 1,500-citation stress fixture completed in approximately 57 seconds on VM and 129 seconds on Node, as measured by consecutive expanded-reporter timestamps. Its incoming author VM evidence took 55.17 seconds. The original run continued and passed; no assertion, source, or timeout was changed. This timing demonstrates completion of this bounded fixture, not a general performance guarantee. `citation-stress-timing.json` preserves the relevant raw lines.
