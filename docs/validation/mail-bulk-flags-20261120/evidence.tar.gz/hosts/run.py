import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
OUT = Path(__file__).resolve().parent
DART = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/dart-sdk/bin/dart'
FLUTTER = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/flutter_tools.snapshot'
EXAMPLE = ROOT / 'packages/quds_office_editor/example'
TESTS = [
    'studio_mail_bulk_provider_test.dart',
    'studio_mail_message_loader_test.dart',
    'studio_mail_workspace_test.dart',
    'studio_mail_ews_test.dart',
    'studio_mail_cloud_test.dart',
    'studio_mail_cached_host_test.dart',
    'studio_mail_cached_mail_test.dart',
]
PROVIDER_ONLY = os.environ.get('MAIL_HOST_PROVIDER_ONLY') == '1'
ANALYZE = [
    'studio_mail_bulk_status.dart', 'studio_mail_ews.dart',
    'studio_mail_native.dart', 'studio_mail_message_loader.dart',
    'studio_mail_workspace_strings.dart',
]
PATHS = [
    p for package in ['quds_mail_core', 'quds_mail_ui', 'quds_mail_transport']
    for p in (ROOT / 'packages' / package / 'lib').rglob('*.dart')
] + list((EXAMPLE / 'lib').glob('studio_mail*.dart'))
PATHS += [EXAMPLE / 'test' / name for name in TESTS]
PATHS += [ROOT / 'pubspec.lock', ROOT / '.dart_tool/package_config.json']


def hashes():
    return {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(PATHS)
    }


commands = [
    ('provider-rerun' if PROVIDER_ONLY else 'host-tests', EXAMPLE, [
        str(DART), str(FLUTTER), '--no-version-check', 'test', '--no-pub',
        '--concurrency=1', '--reporter', 'expanded',
        *['test/' + name for name in (TESTS[:1] if PROVIDER_ONLY else TESTS)],
    ]),
    ('host-analysis', EXAMPLE, [
        str(DART), 'analyze', *['lib/' + name for name in ANALYZE],
        *['test/' + name for name in TESTS],
    ]),
]
receipts = []
for name, cwd, command in commands:
    before = hashes()
    started = time.time()
    log = OUT / (name + '.log')
    print('START', name, flush=True)
    with log.open('w') as handle:
        result = subprocess.run(command, cwd=cwd, stdout=handle, stderr=subprocess.STDOUT)
    after = hashes()
    receipt = dict(
        name=name, command=[str(arg) for arg in command], cwd=str(cwd),
        exit_code=result.returncode, elapsed_seconds=round(time.time()-started, 3),
        source_hashes=before, source_hashes_unchanged=before == after,
        changed_sources=[key for key in sorted(set(before) | set(after)) if before.get(key) != after.get(key)],
        log=log.name, log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
    )
    receipts.append(receipt)
    (OUT / 'receipt.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print('DONE', name, result.returncode, receipt['elapsed_seconds'], flush=True)
    print('\n'.join(log.read_text().splitlines()[-14:]), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
