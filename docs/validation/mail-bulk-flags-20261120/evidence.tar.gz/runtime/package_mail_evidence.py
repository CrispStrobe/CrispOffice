#!/usr/bin/env python3
"""Package selected, immutable local mail qualification evidence without Git."""

import argparse
from collections import defaultdict
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import tarfile


TEXT_SUFFIXES = {'.json', '.log', '.py', '.md', '.sh'}
DIRECTORY_MAP = {
    'bulk-core-validation': 'core',
    'bulk-core-compatibility-validation': 'core-compatibility',
    'bulk-core-provider-results-validation': 'core-provider-results',
    'mail-ui-validation': 'ui',
    'mail-host-validation': 'hosts',
    'native-bulk-validation': 'native',
    'final-checks': 'final-checks',
}
RUNTIME_FILES = [
    'setup-receipt.json',
    'sdk-archive-members.json',
    'pub-cache-bootstrap-manifest.json',
    'smoke-receipt.json',
    'finish_runtime.py',
    'bootstrap_pub_cache.py',
    'smoke.py',
    'env.sh',
    'bin/dart',
    'bin/flutter',
    'package_mail_evidence.py',
]
RUNTIME_LOGS = [
    'setup.log',
    'pub-cache-bootstrap.log',
    'flutter-tools-pub-get.log',
    'workspace-pub-get.log',
    'flutter-version.log',
    'core-models-smoke.log',
    'ui-controller-smoke.log',
    'smoke.log',
]
SENSITIVE_PATTERNS = [
    re.compile(rb'gh[oprsu]_[A-Za-z0-9_]{30,}'),
    re.compile(rb'github_pat_[A-Za-z0-9_]{30,}'),
    re.compile(rb'AKIA[A-Z0-9]{16}'),
    re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def collect(workspace):
    selected = {}

    def add(source, archive_path):
        if source.is_symlink() or not source.is_file():
            raise ValueError(f'Expected a regular source file: {source}')
        if archive_path in selected:
            raise ValueError(f'Duplicate archive member: {archive_path}')
        if PurePosixPath(archive_path).is_absolute() or '..' in PurePosixPath(archive_path).parts:
            raise ValueError(f'Unsafe archive member: {archive_path}')
        data = source.read_bytes()
        if source.suffix not in {'.png', '.jpg'}:
            if any(pattern.search(data) for pattern in SENSITIVE_PATTERNS):
                raise ValueError(f'Possible sensitive credential in selected source: {source}')
            data.decode('utf-8')
        selected[archive_path] = {
            'source': source,
            'data': data,
            'mode': 0o755 if source.stat().st_mode & 0o111 else 0o644,
        }

    for directory, prefix in DIRECTORY_MAP.items():
        source_root = workspace / directory
        if not source_root.is_dir():
            raise ValueError(f'Missing evidence directory: {source_root}')
        for source in sorted(source_root.rglob('*')):
            if source.is_file() and source.suffix in TEXT_SUFFIXES:
                add(source, f'{prefix}/{source.relative_to(source_root).as_posix()}')

    # Preserve every final cutoff capture as exact original PNG bytes.
    # Earlier duplicate images and derived JPEG sheets are unnecessary because
    # the original final images and all raw review/hash metadata are retained.
    for directory in ['peer-cutoff-screenshots', 'ui-cutoff-screenshots']:
        for source in sorted((workspace / 'mail-ui-validation' / directory).glob('*.png')):
            add(source, f'ui/{directory}/{source.name}')

    runtime = workspace / 'runtime'
    for relative in RUNTIME_FILES:
        add(runtime / relative, f'runtime/{relative}')
    for name in RUNTIME_LOGS:
        add(runtime / 'logs' / name, f'runtime/logs/{name}')
    add(runtime / 'provider-bulk-validation.json', 'provider-host/provider-bulk-validation.json')
    for source in sorted((runtime / 'logs').glob('provider-*.log')):
        add(source, f'provider-host/logs/{source.name}')

    for source in sorted((runtime / 'word-validation').rglob('*')):
        if source.is_file() and source.suffix in {'.json', '.log'}:
            add(source, f'word/{source.relative_to(runtime / "word-validation").as_posix()}')
    for name in ['word_validation.py', 'word_supplement_validation.py']:
        add(runtime / name, f'word/{name}')
    for source in sorted(runtime.glob('word-*-orchestration.log')):
        add(source, f'word/{source.name}')

    final = json.loads((workspace / 'final-checks/receipt.json').read_text())
    if not isinstance(final, list) or len(final) != 3:
        raise ValueError('Final checks must contain exactly three completed receipts')

    return dict(sorted(selected.items()))


def packed_bytes(selected):
    result = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=result, mode='wb', compresslevel=9, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for name, entry in selected.items():
                info = tarfile.TarInfo(name)
                info.size = len(entry['data'])
                info.mode = entry['mode']
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                archive.addfile(info, io.BytesIO(entry['data']))
    return result.getvalue()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--workspace', type=Path, default=Path('/workspace/scratch/33e256b7ecf8'))
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    destination = workspace / 'quds_office_suite/docs/validation/mail-bulk-flags-20261120'
    selected = collect(workspace)
    content = packed_bytes(selected)
    repeated = packed_bytes(selected)
    if content != repeated:
        raise ValueError('Deterministic packing verification failed')

    with tarfile.open(fileobj=io.BytesIO(content), mode='r:gz') as archive:
        if archive.getnames() != list(selected):
            raise ValueError('Archive member ordering or inventory differs')
        for info in archive.getmembers():
            entry = selected[info.name]
            if not info.isfile() or archive.extractfile(info).read() != entry['data']:
                raise ValueError(f'Raw member bytes differ: {info.name}')
            if info.mtime != 0 or info.uid != 0 or info.gid != 0 or info.mode != entry['mode']:
                raise ValueError(f'Noncanonical metadata: {info.name}')

    # The archive is a snapshot of exact raw files; no selected file may change
    # between collection and publication of the archive and member manifest.
    for entry in selected.values():
        if entry['source'].read_bytes() != entry['data']:
            raise ValueError(f'Evidence changed while packaging: {entry["source"]}')

    members = [
        {
            'path': name,
            'source': entry['source'].relative_to(workspace).as_posix(),
            'bytes': len(entry['data']),
            'sha256': sha(entry['data']),
            'mode': f'{entry["mode"]:04o}',
        }
        for name, entry in selected.items()
    ]
    groups = defaultdict(lambda: {'members': 0, 'uncompressed_bytes': 0, 'source_roots': set()})
    for member in members:
        prefix = member['path'].split('/', 1)[0] + '/'
        groups[prefix]['members'] += 1
        groups[prefix]['uncompressed_bytes'] += member['bytes']
        groups[prefix]['source_roots'].add(member['source'].split('/', 1)[0] + '/')
    prefix_map = {
        key: {**value, 'source_roots': sorted(value['source_roots'])}
        for key, value in sorted(groups.items())
    }
    manifest = {
        'format_version': 1,
        'archive': {'path': 'evidence.tar.gz', 'bytes': len(content), 'sha256': sha(content)},
        'member_count': len(members),
        'uncompressed_member_bytes': sum(member['bytes'] for member in members),
        'packing': {
            'member_order': 'lexicographic by archive path',
            'tar_format': 'PAX',
            'uid': 0,
            'gid': 0,
            'user_and_group_names': '',
            'mtime': 0,
            'mode': '0755 for executable source files; 0644 otherwise',
            'gzip_level': 9,
            'gzip_mtime': 0,
            'gzip_filename': '',
            'raw_file_contents': 'unchanged',
        },
        'prefix_map': prefix_map,
        'exclusions': [
            'SDK, package cache, downloaded archives, build outputs and credentials',
            'Compiled Word JavaScript, source maps and dependency outputs',
            'Previous runtime restoration records superseded by current setup evidence',
            'Earlier duplicate PNG captures and derived JPEG contact sheets; all twenty final cutoff PNGs and all raw visual metadata are included',
        ],
        'verification': {
            'deterministic_double_pack': True,
            'read_back_members': len(members),
            'all_raw_bytes_equal': True,
            'canonical_metadata': True,
            'source_files_unchanged_during_packaging': True,
        },
        'members': members,
    }
    destination.mkdir(parents=True, exist_ok=True)
    temporary_archive = workspace / 'runtime/mail-evidence.tmp.tar.gz'
    temporary_manifest = workspace / 'runtime/mail-evidence.tmp.json'
    temporary_archive.write_bytes(content)
    temporary_manifest.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    temporary_archive.replace(destination / 'evidence.tar.gz')
    temporary_manifest.replace(destination / 'evidence-members.json')
    print(json.dumps({
        'archive': manifest['archive'],
        'member_count': len(members),
        'uncompressed_member_bytes': manifest['uncompressed_member_bytes'],
        'prefix_map': prefix_map,
    }, indent=2))


if __name__ == '__main__':
    main()
