#!/usr/bin/env python3
"""Install only SHA256-verified hosted archives from the two current locks."""

from __future__ import annotations

import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import tempfile
import time
from datetime import datetime, timezone

import yaml


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent / "quds_office_suite"
LOCKS = [
    WORKSPACE / "pubspec.lock",
    ROOT / "flutter/packages/flutter_tools/pubspec.lock",
]
PUB_CACHE = ROOT / "pub-cache"
ARCHIVES = ROOT / "downloads/pub"
HOSTED = PUB_CACHE / "hosted/pub.dev"
HASHES = PUB_CACHE / "hosted-hashes/pub.dev"
MANIFEST = ROOT / "pub-cache-bootstrap-manifest.json"
WORKERS = 12


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def locked_packages() -> tuple[list[dict], list[dict]]:
    union: dict[tuple[str, str], dict] = {}
    lock_records = []
    for lock in LOCKS:
        raw = lock.read_bytes()
        packages = yaml.safe_load(raw)["packages"]
        hosted_count = 0
        for name, spec in packages.items():
            if spec["source"] in ("path", "sdk"):
                continue
            if spec["source"] != "hosted":
                raise ValueError(f"Unsupported dependency source: {name}")
            description = spec["description"]
            if description["url"].rstrip("/") != "https://pub.dev":
                raise ValueError(f"Unexpected registry for {name}")
            version = str(spec["version"])
            expected = description["sha256"]
            if not re.fullmatch(r"[a-zA-Z0-9_]+", name):
                raise ValueError(f"Unsafe package name: {name}")
            if not re.fullmatch(r"[a-zA-Z0-9.+-]+", version):
                raise ValueError(f"Unsafe version for {name}")
            if not re.fullmatch(r"[0-9a-f]{64}", expected):
                raise ValueError(f"Missing SHA256 for {name}")
            if description["name"] != name:
                raise ValueError(f"Mismatched lock identity for {name}")
            key = (name, version)
            previous = union.get(key)
            if previous is not None and previous["sha256"] != expected:
                raise ValueError(f"Conflicting lock hashes for {name} {version}")
            if previous is None:
                union[key] = {
                    "name": name,
                    "version": version,
                    "sha256": expected,
                    "url": f"https://pub.dev/api/archives/{name}-{version}.tar.gz",
                    "lock_sources": [],
                }
            union[key]["lock_sources"].append(str(lock))
            hosted_count += 1
        lock_records.append({
            "path": str(lock),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "hosted_dependencies": hosted_count,
        })
    return [union[key] for key in sorted(union)], lock_records


def install(package: dict) -> dict:
    started = time.monotonic()
    name = package["name"]
    version = package["version"]
    identity = f"{name}-{version}"
    expected = package["sha256"]
    archive = ARCHIVES / f"{identity}.tar.gz"
    cached_archive = archive.is_file() and sha256(archive) == expected
    if not cached_archive:
        partial = ARCHIVES / f"{identity}.partial"
        result = subprocess.run(
            [
                "curl", "--fail", "--location", "--silent", "--show-error",
                "--connect-timeout", "20", "--max-time", "180",
                "--retry", "3", "--retry-all-errors", "--retry-delay", "1",
                "--output", str(partial), package["url"],
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        if result.returncode:
            raise RuntimeError(
                f"Download failed for {identity}: {result.stderr.strip()[:500]}"
            )
        actual = sha256(partial)
        if actual != expected:
            partial.unlink(missing_ok=True)
            raise ValueError(f"Archive SHA256 mismatch for {identity}: {actual}")
        os.replace(partial, archive)

    target = HOSTED / identity
    marker = HASHES / f"{identity}.sha256"
    reused = (
        target.is_dir()
        and (target / "pubspec.yaml").is_file()
        and marker.is_file()
        and marker.read_text() == expected
    )
    files = None
    expanded_bytes = None
    if not reused:
        with tempfile.TemporaryDirectory(prefix=f".{identity}-", dir=HOSTED) as temporary:
            staging = Path(temporary)
            with tarfile.open(archive, "r:gz") as source:
                entries = source.getmembers()
                files = len(entries)
                expanded_bytes = sum(item.size for item in entries if item.isfile())
                if files > 100000 or expanded_bytes > 512 * 1024 * 1024:
                    raise ValueError(f"Archive resource limit exceeded: {identity}")
                # data_filter rejects path traversal, escaping links and special
                # files. No unverified archive content is ever extracted.
                source.extractall(staging, members=entries, filter="data")
            pubspec = yaml.safe_load((staging / "pubspec.yaml").read_text())
            if pubspec.get("name") != name or str(pubspec.get("version")) != version:
                raise ValueError(f"Archive pubspec does not match lock: {identity}")
            if target.exists():
                if target.is_symlink():
                    raise ValueError(f"Refusing symlink cache target: {identity}")
                shutil.rmtree(target)
            os.replace(staging, target)
        # Pub compares the complete marker contents with the locked hash.
        # These files contain exactly 64 hex characters, with no newline.
        marker.write_text(expected)
    return {
        **package,
        "archive": str(archive),
        "archive_bytes": archive.stat().st_size,
        "verified": True,
        "archive_reused": cached_archive,
        "installed_path": str(target),
        "hash_marker": str(marker),
        "hash_marker_format": "64 lowercase hexadecimal bytes; no newline",
        "cache_reused": reused,
        "archive_entries": files,
        "expanded_bytes": expanded_bytes,
        "elapsed_seconds": round(time.monotonic() - started, 3),
    }


def main() -> int:
    for path in [ARCHIVES, HOSTED, HASHES]:
        path.mkdir(parents=True, exist_ok=True)
    packages, lock_records = locked_packages()
    results = []
    failures = []
    started = datetime.now(timezone.utc).isoformat()

    def save_manifest(complete: bool = False) -> None:
        for record in lock_records:
            if sha256(Path(record["path"])) != record["sha256"]:
                raise RuntimeError("Lockfile changed during bootstrap")
        manifest = {
            "purpose": "runtime dependency setup; not a test result",
            "started_at": started,
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "workers": WORKERS,
            "pub_cache": str(PUB_CACHE),
            "expected_packages": len(packages),
            "installed_packages": len(results),
            "complete": complete and not failures and len(results) == len(packages),
            "locks": lock_records,
            "archives": sorted(results, key=lambda p: (p["name"], p["version"])),
            "failures": failures,
        }
        partial = MANIFEST.with_suffix(".partial")
        partial.write_text(json.dumps(manifest, indent=2) + "\n")
        os.replace(partial, MANIFEST)

    save_manifest()
    print(f"Installing {len(packages)} locked archives with {WORKERS} workers", flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
        futures = {pool.submit(install, package): package for package in packages}
        for future in concurrent.futures.as_completed(futures):
            package = futures[future]
            try:
                result = future.result()
                results.append(result)
                print(
                    f"{len(results)}/{len(packages)} verified "
                    f"{package['name']} {package['version']} "
                    f"({result['archive_bytes']} bytes)",
                    flush=True,
                )
            except Exception as error:
                failures.append({**package, "error": str(error)})
                print(f"FAILED {package['name']} {package['version']}: {error}", flush=True)
            save_manifest()
    save_manifest(complete=True)
    print(f"Manifest: {MANIFEST}", flush=True)
    print(f"Installed {len(results)}, failed {len(failures)}", flush=True)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
