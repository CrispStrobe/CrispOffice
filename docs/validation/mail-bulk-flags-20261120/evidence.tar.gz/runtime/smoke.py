#!/usr/bin/env python3
"""Small runtime qualification; full feature acceptance belongs to root."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'quds_office_suite'
DART = ROOT / 'flutter/bin/cache/dart-sdk/bin/dart'
FLUTTER = ROOT / 'flutter/bin/cache/flutter_tools.snapshot'
PACKAGES = REPO / '.dart_tool/package_config.json'
RUNNER = ROOT / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
OUT = ROOT / 'smoke-receipt.json'
env = dict(os.environ, PUB_CACHE=str(ROOT / 'pub-cache'), FLUTTER_ROOT=str(ROOT / 'flutter'), CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true', DASH__SUPPRESS_ANALYTICS='true', TZ='Europe/Berlin', XDG_DATA_HOME=str(ROOT / 'data'), XDG_CONFIG_HOME=str(ROOT / 'config'), XDG_CACHE_HOME=str(ROOT / 'cache'), TMPDIR=str(ROOT / 'tmp'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

record = {'started_at': datetime.now(timezone.utc).isoformat(), 'purpose': 'Pinned runtime smoke, not feature acceptance', 'source_head_at_start': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(), 'workspace_lock_sha256': sha(REPO / 'pubspec.lock'), 'package_config_sha256': sha(PACKAGES), 'runs': []}
checks = [
    ('core-models', REPO / 'packages/quds_mail_core', [DART, '--packages=' + str(PACKAGES), RUNNER, '--reporter', 'expanded', 'test/models_test.dart']),
    ('ui-controller', REPO / 'packages/quds_mail_ui', [DART, FLUTTER, '--no-version-check', 'test', '--no-pub', '--reporter', 'expanded', 'test/controller_test.dart']),
]
try:
    for name, cwd, argv in checks:
        source_paths = list((cwd / 'lib').rglob('*.dart')) + [cwd / ('test/models_test.dart' if name == 'core-models' else 'test/controller_test.dart')]
        before = {str(path.relative_to(REPO)): sha(path) for path in source_paths}
        log = ROOT / 'logs' / (name + '-smoke.log')
        print('START ' + name, flush=True)
        started = time.monotonic()
        with log.open('wb') as stream:
            result = subprocess.run([str(a) for a in argv], cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=300)
        after = {str(path.relative_to(REPO)): sha(path) for path in source_paths}
        run = {'name': name, 'command': [str(a) for a in argv], 'cwd': str(cwd), 'exit_code': result.returncode, 'elapsed_seconds': round(time.monotonic() - started, 3), 'source_hashes_at_start': before, 'source_hashes_unchanged': before == after, 'log': str(log), 'log_sha256': sha(log)}
        record['runs'].append(run)
        OUT.write_text(json.dumps(record, indent=2) + '\n')
        print('END ' + name + ' exit=' + str(result.returncode), flush=True)
        if result.returncode:
            raise RuntimeError(name + ': ' + log.read_text(errors='replace')[-5000:])
    record['status'] = 'passed'
except BaseException as error:
    record['status'] = 'failed'
    record['error'] = repr(error)
    raise
finally:
    record['finished_at'] = datetime.now(timezone.utc).isoformat()
    OUT.write_text(json.dumps(record, indent=2) + '\n')
