#!/usr/bin/env python3
"""Restore the repository-pinned Flutter SDK and verify unchanged locks."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import shlex
import subprocess
import tarfile
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'quds_office_suite'
SDK = ROOT / 'flutter'
ARCHIVE = ROOT / 'downloads/flutter_linux_3.47.8-stable.tar.xz'
URL = 'https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.47.8-stable.tar.xz'
EXPECTED = 'baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2'
RECEIPT = ROOT / 'setup-receipt.json'
record = {'started_at': datetime.now(timezone.utc).isoformat(), 'status': 'running', 'source': str(REPO), 'sdk': str(SDK), 'checks': []}

def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()

def save():
    RECEIPT.write_text(json.dumps(record, indent=2) + '\n')

def selected(name):
    parts = PurePosixPath(name).parts
    if not parts or parts[0] != 'flutter':
        return False
    if len(parts) == 1 or parts[1] == '.git':
        return True
    if parts[1] == 'bin':
        if '/'.join(parts[1:]).startswith('bin/cache/artifacts/engine/'):
            platform = parts[5] if len(parts) > 5 else ''
            if platform.startswith(('android', 'ios', 'darwin', 'windows', 'linux-arm64', 'linux-x64-profile', 'linux-x64-release')):
                return False
        return True
    if parts[1] == 'packages':
        return not (len(parts) > 3 and parts[3] in {'test', 'test_private', 'test_fixes', 'example', 'examples', 'benchmark', 'benchmarks'})
    return len(parts) == 2 and parts[1] in {'LICENSE', 'AUTHORS', 'README.md', 'version', '.metadata', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', 'flutter_console.bat'}

env = dict(os.environ, PUB_CACHE=str(ROOT / 'pub-cache'), FLUTTER_ROOT=str(SDK), CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true', DASH__SUPPRESS_ANALYTICS='true', XDG_DATA_HOME=str(ROOT / 'data'), XDG_CONFIG_HOME=str(ROOT / 'config'), XDG_CACHE_HOME=str(ROOT / 'cache'), TMPDIR=str(ROOT / 'tmp'))

def run(name, argv, cwd, timeout=300):
    log = ROOT / 'logs' / (name + '.log')
    print('START ' + name, flush=True)
    started = time.monotonic()
    with log.open('wb') as output:
        result = subprocess.run([str(a) for a in argv], cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=timeout)
    check = {'name': name, 'command': [str(a) for a in argv], 'cwd': str(cwd), 'exit_code': result.returncode, 'log': str(log), 'log_sha256': sha(log), 'elapsed_seconds': round(time.monotonic() - started, 3)}
    record['checks'].append(check)
    save()
    print('END ' + name + ' exit=' + str(result.returncode), flush=True)
    if result.returncode:
        raise RuntimeError(name + ': ' + log.read_text(errors='replace')[-5000:])
    return log

try:
    record['workspace_lock_before'] = sha(REPO / 'pubspec.lock')
    save()
    actual = sha(ARCHIVE)
    if actual != EXPECTED:
        raise RuntimeError('SDK archive hash mismatch: ' + actual)
    record['archive'] = {'url': URL, 'path': str(ARCHIVE), 'sha256': actual, 'bytes': ARCHIVE.stat().st_size, 'verified': True}
    save()
    if not (ROOT / 'sdk-extracted').exists():
        files = []
        expanded = 0
        started = time.monotonic()
        with tarfile.open(ARCHIVE, 'r|xz') as bundle:
            for member in bundle:
                if selected(member.name):
                    expanded += member.size
                    if expanded > 10 * 1024**3:
                        raise RuntimeError('SDK extraction exceeded budget')
                    bundle.extract(member, ROOT, filter='data')
                    if member.isfile():
                        files.append({'path': member.name, 'bytes': member.size})
                if time.monotonic() - started > 30:
                    print('Expanded bytes: ' + str(expanded), flush=True)
                    started = time.monotonic()
        (ROOT / 'sdk-archive-members.json').write_text(json.dumps(files, indent=2) + '\n')
        (ROOT / 'sdk-extracted').touch()
        record['extracted_files'] = len(files)
        record['extracted_bytes'] = expanded
        save()
    dart = SDK / 'bin/cache/dart-sdk/bin/dart'
    tester = SDK / 'bin/cache/artifacts/engine/linux-x64/flutter_tester'
    expected_executables = {str(dart): '01e869e4af277734b02ab8898b870c6b00c9bec61bbcf9c923cd14de7ed85fbb', str(tester): '800f4ca182df7dd2fb46a42dea5d76277b9dbc5e8cd2915e02bcbc978681b45f'}
    for path, digest in expected_executables.items():
        if sha(Path(path)) != digest:
            raise RuntimeError('Executable hash mismatch: ' + path)
    record['executable_sha256'] = expected_executables
    record['flutter_tools_lock_sha256'] = sha(SDK / 'packages/flutter_tools/pubspec.lock')
    save()
    run('pub-cache-bootstrap', ['python3', ROOT / 'bootstrap_pub_cache.py'], ROOT, timeout=900)
    run('flutter-tools-pub-get', [dart, 'pub', 'get', '--offline', '--enforce-lockfile'], SDK / 'packages/flutter_tools')
    run('workspace-pub-get', [dart, 'pub', 'get', '--offline', '--enforce-lockfile'], REPO)
    record['workspace_lock_after'] = sha(REPO / 'pubspec.lock')
    if record['workspace_lock_before'] != record['workspace_lock_after']:
        raise RuntimeError('Workspace lock changed')
    record['package_config_sha256'] = sha(REPO / '.dart_tool/package_config.json')
    bindir = ROOT / 'bin'
    bindir.mkdir(exist_ok=True)
    (bindir / 'dart').write_text('#!/bin/sh\nexec ' + shlex.quote(str(dart)) + ' "$@"\n')
    (bindir / 'flutter').write_text('#!/bin/sh\nexec ' + shlex.quote(str(dart)) + ' ' + shlex.quote(str(SDK / 'bin/cache/flutter_tools.snapshot')) + ' --no-version-check "$@"\n')
    (bindir / 'dart').chmod(0o755)
    (bindir / 'flutter').chmod(0o755)
    keys = ['PUB_CACHE', 'FLUTTER_ROOT', 'CI', 'DART_SUPPRESS_ANALYTICS', 'FLUTTER_SUPPRESS_ANALYTICS', 'DASH__SUPPRESS_ANALYTICS', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME', 'XDG_CACHE_HOME', 'TMPDIR']
    (ROOT / 'env.sh').write_text('\n'.join('export ' + key + '=' + shlex.quote(env[key]) for key in keys) + '\nexport PATH=' + shlex.quote(str(bindir)) + ':"$PATH"\n')
    env['PATH'] = str(bindir) + ':' + env.get('PATH', '')
    version = run('flutter-version', [bindir / 'flutter', '--version', '--machine'], REPO)
    record['version'] = json.loads(version.read_text())
    if record['version']['frameworkRevision'] != '737ba8f885dc774b53b442759999a312c9461e4e' or record['version']['dartSdkVersion'] != '3.13.7':
        raise RuntimeError('Unexpected runtime identity')
    record['status'] = 'ready'
    (ROOT / 'runtime-ready').touch()
except BaseException as error:
    record['status'] = 'failed'
    record['error'] = repr(error)
    raise
finally:
    record['finished_at'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], flush=True)
