import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
OUT = Path(__file__).resolve().parent
DART = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/dart-sdk/bin/dart'
BASE = 'c954d00d2fc85604ae394674bca91ea8a1dede0e'
paths = subprocess.check_output(
    ['git', 'diff', '--name-only', BASE, 'HEAD'], cwd=ROOT, text=True,
).splitlines()
dart_paths = [p for p in paths if p.endswith('.dart') and (ROOT / p).is_file()]
hashes = lambda: {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in dart_paths}
commands = [
    ('format', [str(DART), 'format', '--output=none', '--set-exit-if-changed', *dart_paths]),
    ('source-whitespace', ['git', 'diff', '--check', BASE, 'HEAD']),
    ('intake-replay', ['python3', 'docs/validation/mail-bulk-flags-20261120/verify_intake.py']),
]
receipts = []
for name, command in commands:
    before = hashes()
    started = time.time()
    log = OUT / (name + '.log')
    with log.open('w') as output:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    after = hashes()
    receipts.append(dict(
        name=name, command=command, cwd=str(ROOT), exit_code=result.returncode,
        elapsed_seconds=round(time.time() - started, 3),
        source_hashes=before, sources_unchanged=before == after,
        source_file_count=len(dart_paths), log=log.name,
        log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
    ))
    (OUT / 'receipt.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(name, result.returncode, len(dart_paths), log.read_text(), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
