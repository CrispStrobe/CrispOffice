import difflib
import hashlib
import json
from pathlib import Path
import subprocess

SCRATCH = Path('/workspace/scratch/33e256b7ecf8')
ROOT = SCRATCH / 'quds_office_suite'
OUT = Path(__file__).resolve().parent
SOURCE = '3645e8a4db535fc0ab5ab0923ee7385e5c4e5195'
WORD_BASE = '3b753b0251d5dffe1b5b3e1496748f39caba8587'
NAMED = {
    'packages/quds_office_engine/test/office_vba_word_named_measurements_test.dart': 43,
    'packages/quds_office_engine/test/office_vba_word_named_measurements_integration_test.dart': 105,
}
PROVIDER_TEST = 'packages/quds_office_editor/example/test/studio_mail_bulk_provider_test.dart'
REPAIR = "import 'package:quds_office_studio/studio_mail_workspace_strings.dart';\n"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads((SCRATCH / path).read_text())


def current(path):
    p = Path(path)
    return digest((p if p.is_absolute() else ROOT / p).read_bytes())


rows = []


def verify_file(relative, allowed=(), permit_failed=False):
    data = read_json(relative)
    for record in data if isinstance(data, list) else [data]:
        key = next(k for k in ('source_hashes', 'source_hashes_before', 'source_before') if k in record)
        before = record[key]
        after = record.get('source_hashes_after', record.get('source_after', before))
        assert before == after, (relative, 'source changed during run')
        stable = record.get('source_hashes_unchanged', record.get('sources_unchanged', record.get('source_unchanged', True)))
        assert stable, relative
        assert record['exit_code'] == 0 or permit_failed, relative
        differences = sorted(path for path, value in before.items() if current(path) != value)
        assert differences == sorted(allowed), (relative, differences, allowed)
        rows.append(dict(
            receipt=relative, name=record.get('name', record.get('cohort')),
            exit_code=record['exit_code'], source_file_count=len(before),
            recorded_sources_stable=True, current_source_differences=differences,
            receipt_sha256=digest((SCRATCH / relative).read_bytes()),
        ))
    return data


verify_file('bulk-core-provider-results-validation/accepted/receipt.json')
verify_file('mail-ui-validation/cutoff-peer-receipt.json')
verify_file('mail-host-validation/receipt.json')
failed_host = verify_file('mail-host-validation/late-intake-initial/receipt.json', [PROVIDER_TEST], True)[0]
assert failed_host['exit_code'] == 1
before_repair = (ROOT / PROVIDER_TEST).read_text().replace(REPAIR, '', 1).encode()
assert digest(before_repair) == failed_host['source_hashes'][PROVIDER_TEST]

word = read_json('runtime/word-validation/qualification.json')
for entry in word['receipts']:
    verify_file('runtime/word-validation/' + Path(entry['receipt']).name, NAMED)
for entry in word['supplement_receipts']:
    verify_file('runtime/word-validation/' + Path(entry['receipt']).name)

additions = []
for path, expected_insertions in NAMED.items():
    old = subprocess.check_output(['git', 'show', WORD_BASE + ':' + path], cwd=ROOT)
    new = (ROOT / path).read_bytes()
    matcher = difflib.SequenceMatcher(None, old.decode().splitlines(), new.decode().splitlines(), autojunk=False)
    opcodes = matcher.get_opcodes()
    assert all(tag in ('equal', 'insert') for tag, *_ in opcodes), path
    inserted = sum(j2 - j1 for tag, i1, i2, j1, j2 in opcodes if tag == 'insert')
    assert inserted == expected_insertions, (path, inserted)
    assert read_json('runtime/word-validation/word-vm.json')['source_before'][path] == digest(old)
    additions.append(dict(path=path, inserted_lines=inserted, removed_lines=0, before_sha256=digest(old), after_sha256=digest(new)))

verify_file('final-checks/receipt.json')
assert subprocess.check_output(['git', 'rev-parse', SOURCE + '^{tree}'], cwd=ROOT, text=True).strip() == '0df4f1db0f920cf3adf3c5abcf8e22abdd8ee007'
result = dict(
    status='PASS', qualified_source_commit=SOURCE,
    qualified_source_tree='0df4f1db0f920cf3adf3c5abcf8e22abdd8ee007',
    receipt_checks=rows,
    host_composition=dict(
        accepted_unique_cases=374, unchanged_suites_passed=338,
        corrected_provider_suite_passed=36,
        original_run_exit_code=1, original_failure='Provider test suite failed to load because its newly used localized extension was not imported.',
        repair=dict(path=PROVIDER_TEST, inserted_line=REPAIR.rstrip(), before_sha256=digest(before_repair), after_sha256=current(PROVIDER_TEST), assertions_changed=False),
        interpretation='Six unchanged suites passed in the original mixed run; only the corrected provider suite was rerun. The original run remains failed.',
    ),
    word_composition=dict(
        vm=867, node=725, original_vm=853, original_node=712,
        added_vm=14, added_node=13, additive_fixture_proof=additions,
        interpretation='Composed distinct executed cases, not single invocations of these totals. All previous test text, production code, examples and drivers are unchanged.',
    ),
)
(OUT / 'source-applicability.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(status=result['status'], receipt_checks=len(rows), host_cases=374, word_vm=867, word_node=725)))
