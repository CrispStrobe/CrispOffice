import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
out=Path('/workspace/scratch/33e256b7ecf8/bulk-core-compatibility-validation')
dart=Path(os.environ['FLUTTER_ROOT'])/'bin/cache/dart-sdk/bin/dart'
runner=Path(os.environ['PUB_CACHE'])/'hosted/pub.dev/test-1.31.1/bin/test.dart'
base=[str(dart),'--packages='+str(root/'.dart_tool/package_config.json'),str(runner)]
commands=[
 ('core-vm',root/'packages/quds_mail_core',base+['--reporter','expanded','--concurrency=2']),
 ('transport-boundaries',root/'packages/quds_mail_transport',base+['--reporter','expanded','--concurrency=1','test/native_provider_test.dart','test/ews_provider_test.dart','test/cloud_provider_test.dart']),
 ('bulk-node',root/'packages/quds_mail_core',base+['--platform=node','--concurrency=1','--reporter','expanded','test/bulk_flags_test.dart','test/bulk_flags_coordinator_test.dart','test/bulk_flags_compatibility_test.dart']),
 ('core-analyze',root,[str(dart),'analyze','packages/quds_mail_core']),
 ('transport-analyze',root,[str(dart),'analyze','packages/quds_mail_transport']),
]
paths=[p for pkg in ['quds_mail_core','quds_mail_transport'] for d in ['lib','test'] for p in (root/'packages'/pkg/d).rglob('*.dart')]
paths += [root/'pubspec.lock',root/'analysis_options.yaml',root/'.dart_tool/package_config.json']
def hashes(): return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
receipts=[]
for name,cwd,args in commands:
 before=hashes();start=time.time(); log=out/(name+'.log')
 print('START',name,flush=True)
 with log.open('w') as f: p=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 receipt=dict(name=name,command=args,cwd=str(cwd),exit_code=p.returncode,elapsed_seconds=round(time.time()-start,3),source_hashes=before,source_hashes_unchanged=before==hashes(),log=log.name,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
 receipts.append(receipt);(out/'receipt.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print('DONE',name,p.returncode,receipt['elapsed_seconds'],flush=True)
 print('\n'.join(log.read_text().splitlines()[-5:]),flush=True)
 if p.returncode: break
