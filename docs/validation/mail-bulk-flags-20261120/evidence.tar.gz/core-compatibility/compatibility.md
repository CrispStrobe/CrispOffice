# Bulk API reconciliation

The combined implementation preserves the public coordinator API from
`b60c0ec26f2a80c984076fb1d480eb2e641b542e` and the provider-facing runner from
the saved integration checkpoint `034d73d2`. Both entry points delegate to one
private `_runBulkFlags` dispatch loop; there is no parallel executor to diverge.

## Preserved API and evidence

- `MailBulkFlagPlan.provider` is inferred from the frozen identities. An optional
  constructor `provider` validates that inference, retaining compatibility with
  the peer's required argument and the runner hosts that omit it.
- Public `operationAt(index)` uses the peer's `planId:index` ID convention. The
  provider runner's three literal ID expectations changed from `batch-0` to
  `batch:0` and corresponding indices; all behavioral assertions remain.
- Plan IDs follow the peer's stricter nonblank, 256-character bound. The common
  1–1000 identity bound is checked before traversing caller input.
- `MailBulkFlagAttempt`, `MailBulkFlagApply`, the single-use coordinator and its
  separate cancellation token are retained. Progress and `shouldStop` are also
  available through the coordinator.
- Reports expose `items` as the same immutable list as `results`, retain the
  exact dispatched `operation` object, retain the original `MailProblem`
  instance, and expose both `stopReason` and `stopProblem`.
- The provider runner still requires explicit
  `mutationMayHaveOccurred: false` to classify a failure as definite. The
  coordinator's explicit `failed` attempt is itself a caller certificate of no
  effect, so the peer's unknown-metadata rejection cases remain definite.

## Deliberate safety refinements

- A `failed` attempt whose problem explicitly says mutation may have occurred
  becomes uncertain. Contradictory evidence cannot hide possible remote writes.
- Certified `cancelled` or `staleOperation` adapter failures stop further
  dispatch even if the caller has not yet retired its lease or scope predicate.
- Both entry points recheck lease/cancellation after caller guard callbacks, so
  reentrant retirement cannot dispatch a new operation.
- A coordinator is consumed even when its first run fails the predispatch
  scope check; later reuse requires constructing a new coordinator and plan.
- Uncertainty takes precedence over simultaneous stop or scope change. Next
  come a certified provider cancellation/stale result, then foreign account,
  cancellation token, stale lease, scope predicate and requested-stop checks.
  Confirmed in-flight results remain in the receipt regardless of the reason.
- Callback exceptions remain uncertain and stop without retrying. Observer
  exceptions cannot erase outcomes or cause replay.

## Tests and source binding

`test/bulk_flags_coordinator_test.dart` is byte-for-byte the peer's original
`test/bulk_flags_test.dart`, renamed to avoid collision. Its Git blob is
`fbbb20b4ee8d7cb6fe03dfe4606394154749132b`; none of its 31 tests or assertions
were relaxed. Seventeen additional tests exercise compatibility and the
specific refinements above through both public entry points.

The accompanying `receipt.json` records exact command arguments, working
directories, all core/transport Dart source hashes, package/lock configuration
hashes, log hashes and source stability for every command.

| Cohort | Result |
| --- | --- |
| Entire core on Dart VM | 172 passed |
| Three bulk suites compiled to JavaScript and run on Node | 78 passed |
| Native, EWS and cloud provider boundary suites | 191 passed |
| Entire core analysis | Clean |
| Entire transport analysis | Clean |

These cohorts overlap and must not be added into a unique-test total. This
qualifies the foreground contract and deterministic adapters; it does not
qualify live provider sessions or durable persistence of bulk receipts.
