#!/usr/bin/env python3
"""Qualify only the additional named-measurement cases from the late intake."""

import word_validation as acceptance


PATTERN = (
    'accepts an explicitly converted numeric string|'
    'large metric conversions retain portable numeric results|'
    'converted tab positions retain the exact native upper boundary|'
    'conversion-only loops retain the shared source work budget|'
    'converted tabs preserve existing stops and playback recording'
)
COMPILER = 'test/office_vba_word_named_measurements_test.dart'
INTEGRATION = 'test/office_vba_word_named_measurements_integration_test.dart'
COMMON = [
    acceptance.DART,
    f'--packages={acceptance.PACKAGE_CONFIG}',
    str(acceptance.TEST_ENTRY),
    '--reporter',
    'expanded',
    '--concurrency=1',
    '--name',
    PATTERN,
]


if __name__ == '__main__':
    acceptance.run('word-supplement-vm', COMMON + [COMPILER, INTEGRATION])
    acceptance.run('word-supplement-node', COMMON + ['--platform=node', COMPILER])
    acceptance.run('word-supplement-analyze', [acceptance.DART, 'analyze', COMPILER, INTEGRATION])
    acceptance.run('word-supplement-format', [acceptance.DART, 'format', '--output=none', '--set-exit-if-changed', COMPILER, INTEGRATION])
