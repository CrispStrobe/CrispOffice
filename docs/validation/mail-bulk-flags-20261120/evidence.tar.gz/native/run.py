import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
out=Path('/workspace/scratch/33e256b7ecf8/native-bulk-validation')
dart=Path(os.environ['FLUTTER_ROOT'])/'bin/cache/dart-sdk/bin/dart'
flutter=Path(os.environ['FLUTTER_ROOT'])/'bin/cache/flutter_tools.snapshot'
paths=[p for pkg in ['quds_mail_core','quds_mail_ui','quds_mail_transport'] for p in (root/'packages'/pkg/'lib').rglob('*.dart')]
paths += [p for p in (root/'packages/quds_office_editor/example/lib').glob('studio_mail*.dart')]
paths += [root/'packages/quds_office_editor/example/test'/n for n in ['studio_mail_message_loader_test.dart','studio_mail_workspace_test.dart']]
paths += [root/'pubspec.lock',root/'.dart_tool/package_config.json']
def hashes():return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
commands=[
 ('native-tests',root/'packages/quds_office_editor/example',[str(dart),str(flutter),'--no-version-check','test','--no-pub','--concurrency=1','--reporter','expanded','test/studio_mail_message_loader_test.dart','test/studio_mail_workspace_test.dart']),
 ('native-analysis',root,[str(dart),'analyze','packages/quds_office_editor/example/lib/studio_mail_native.dart','packages/quds_office_editor/example/lib/studio_mail_message_loader.dart','packages/quds_office_editor/example/test/studio_mail_message_loader_test.dart','packages/quds_office_editor/example/test/studio_mail_workspace_test.dart'])]
receipts=[]
for name,cwd,args in commands:
 before=hashes();start=time.time();log=out/(name+'.log')
 print('START',name,flush=True)
 with log.open('w') as f:p=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 after=hashes()
 receipt=dict(name=name,command=args,cwd=str(cwd),exit_code=p.returncode,elapsed_seconds=round(time.time()-start,3),source_hashes=before,source_hashes_unchanged=before==after,changed_sources=[k for k in set(before)|set(after) if before.get(k)!=after.get(k)],log=log.name,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
 receipts.append(receipt);(out/'receipt.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print('DONE',name,p.returncode,receipt['elapsed_seconds'],flush=True)
 print('\n'.join(log.read_text().splitlines()[-12:]),flush=True)
 if p.returncode:break
