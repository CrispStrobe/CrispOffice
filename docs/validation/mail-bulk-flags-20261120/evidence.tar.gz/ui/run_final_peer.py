import datetime, hashlib, json, pathlib, subprocess
root = pathlib.Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
out = pathlib.Path('/workspace/scratch/33e256b7ecf8/mail-ui-validation')

def hashes():
    files = set()
    for folder in ('packages/quds_mail_core/lib', 'packages/quds_mail_ui/lib', 'packages/quds_mail_ui/test', 'packages/quds_mail_transport/lib'):
        files.update((root / folder).rglob('*.dart'))
    files.update((root / 'packages/quds_office_editor/example/lib').glob('studio_mail*.dart'))
    for path in ('packages/quds_office_editor/example/lib/studio_strings.dart', 'packages/quds_office_editor/example/test/studio_mail_workspace_test.dart', 'packages/quds_office_editor/example/test/studio_mail_bulk_visual_test.dart'):
        files.add(root/path)
    for path in ('pubspec.yaml', 'pubspec.lock', 'packages/quds_office_editor/example/pubspec.yaml', 'packages/quds_office_editor/example/pubspec.lock', 'packages/quds_mail_ui/pubspec.yaml'):
        if (root/path).exists(): files.add(root/path)
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
receipts = []
for name, cwd, tests in (
    ('ui-final-peer', 'packages/quds_mail_ui', []),
    ('native-workspace-final-peer', 'packages/quds_office_editor/example', ['test/studio_mail_workspace_test.dart']),
    ('peer-visual-final', 'packages/quds_office_editor/example', ['test/studio_mail_bulk_visual_test.dart', '--dart-define=MAIL_BULK_SCREENSHOT_DIR='+str(out/'peer-screenshots')]),
):
    command = ['flutter', 'test', '--no-pub', '--reporter', 'expanded', *tests]
    receipt = dict(cohort=name, command=command, cwd=str(root/cwd), started_utc=now(), source_hashes_before=hashes())
    log = out / f'{name}.log'
    with log.open('w') as handle:
        result = subprocess.run(command, cwd=root/cwd, stdout=handle, stderr=subprocess.STDOUT)
    receipt.update(finished_utc=now(), exit_code=result.returncode, source_hashes_after=hashes(), log=log.name)
    receipt['sources_unchanged'] = receipt['source_hashes_before'] == receipt['source_hashes_after']
    receipts.append(receipt)
    (out/'final-peer-receipt.json').write_text(json.dumps(receipts, indent=2)+'\n')
    print(name, 'exit', result.returncode, 'unchanged', receipt['sources_unchanged'], flush=True)
    print('\n'.join(log.read_text().splitlines()[-5:]), flush=True)
