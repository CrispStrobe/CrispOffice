import datetime, hashlib, json, pathlib, subprocess
root = pathlib.Path('/workspace/scratch/33e256b7ecf8/quds_office_suite')
out = pathlib.Path('/workspace/scratch/33e256b7ecf8/mail-ui-validation')

def hashes():
    files = set()
    for folder in ('packages/quds_mail_core/lib', 'packages/quds_mail_ui/lib', 'packages/quds_mail_ui/test'):
        files.update((root / folder).rglob('*.dart'))
    files.update((root / 'packages/quds_office_editor/example/lib').glob('studio_mail*.dart'))
    files.add(root / 'packages/quds_office_editor/example/lib/studio_strings.dart')
    files.add(root / 'packages/quds_office_editor/example/test/studio_mail_workspace_test.dart')
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
receipts = []
for name, cwd, tests in (
    ('ui-reconciliation', 'packages/quds_mail_ui', []),
    ('native-workspace-reconciliation', 'packages/quds_office_editor/example', ['test/studio_mail_workspace_test.dart']),
):
    command = ['flutter', 'test', '--no-pub', '--reporter', 'expanded', *tests]
    receipt = dict(cohort=name, command=command, cwd=str(root/cwd), started_utc=now(), source_hashes_before=hashes())
    log = out / f'{name}.log'
    with log.open('w') as handle:
        result = subprocess.run(command, cwd=root/cwd, stdout=handle, stderr=subprocess.STDOUT)
    receipt.update(finished_utc=now(), exit_code=result.returncode, source_hashes_after=hashes(), log=log.name)
    receipt['sources_unchanged'] = receipt['source_hashes_before'] == receipt['source_hashes_after']
    receipts.append(receipt)
    (out/'reconciliation-receipt.json').write_text(json.dumps(receipts, indent=2)+'\n')
    print(name, 'exit', result.returncode, 'unchanged', receipt['sources_unchanged'], flush=True)
    print('\n'.join(log.read_text().splitlines()[-5:]), flush=True)
