import 'dart:convert';
import 'dart:io';
import 'package:analyzer/dart/analysis/utilities.dart';
import 'package:analyzer/dart/ast/ast.dart';

var oldLabels = 0;
var newLabels = 0;
String canonical(AstNode node) {
  if (node is ParenthesizedExpression) return canonical(node.expression);
  if (node is SimpleStringLiteral) return 'String:${jsonEncode(node.value)}';
  if (node is ConditionalExpression && node.condition.toSource() == '_arabic' &&
      node.thenExpression is StringLiteral && node.elseExpression is StringLiteral) {
    oldLabels++;
    return 'LocalLabel(${canonical(node.thenExpression)},${canonical(node.elseExpression)})';
  }
  if (node is MethodInvocation && node.methodName.name == '_t') {
    final a = node.argumentList.arguments;
    if (a.length == 3 && a.first is StringLiteral && a.last is StringLiteral) {
      final de = a[1];
      if (de is MethodInvocation && de.target?.toSource() == 'StudioStrings' &&
          de.methodName.name == 'de' && de.argumentList.arguments.length == 1 &&
          de.argumentList.arguments.first.toSource() == a.first.toSource()) {
        newLabels++;
        return 'LocalLabel(${canonical(a.last)},${canonical(a.first)})';
      }
    }
  }
  return '${node.runtimeType}(${node.childEntities.map((e) => e is AstNode ? canonical(e) : e.toString()).join('|')})';
}
Map<String, String> members(String path) {
  final parsed = parseString(content: File(path).readAsStringSync());
  if (parsed.errors.isNotEmpty) throw StateError('${parsed.errors}');
  final out = <String,String>{};
  for (final declaration in parsed.unit.declarations) {
    if (declaration is ClassDeclaration) {
      for (final member in declaration.body.members) {
        final name = member is MethodDeclaration ? '${member.isGetter ? 'get' : member.isSetter ? 'set' : 'method'}:${member.name}' :
          member is ConstructorDeclaration ? 'constructor:${member.name}' :
          member is FieldDeclaration ? 'fields:${member.fields.variables.map((e)=>e.name.toString()).join(',')}' : member.runtimeType.toString();
        final key = '${declaration.namePart}:$name';
        if (out.containsKey(key)) throw StateError('Duplicate $key');
        out[key] = canonical(member);
      }
    } else {
      out['top:${declaration.toSource().split('{').first}'] = canonical(declaration);
    }
  }
  return out;
}
void main(List<String> args) {
  final before=members(args[0]);
  final beforeLabelCounts = {'conditionals': oldLabels, 'map_calls': newLabels};
  oldLabels = newLabels = 0;
  final after=members(args[1]);
  print(const JsonEncoder.withIndent('  ').convert({
    'before_members':before.length,'after_members':after.length,
    'normalized_labels_before':beforeLabelCounts,
    'normalized_labels_after':{'conditionals': oldLabels, 'map_calls': newLabels},
    'added':after.keys.where((k)=>!before.containsKey(k)).toList(),
    'removed':before.keys.where((k)=>!after.containsKey(k)).toList(),
    'changed':before.keys.where((k)=>after.containsKey(k)&&before[k]!=after[k]).toList(),
    'unchanged':before.keys.where((k)=>before[k]==after[k]).length,
    'scope':'AST comparison normalizes only exact Arabic/English conditional labels to matching German-map lookup calls, and redundant parentheses. Other syntax is preserved structurally.'
  }));
}
