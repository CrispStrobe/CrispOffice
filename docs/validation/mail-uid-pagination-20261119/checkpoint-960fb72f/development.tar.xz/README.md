# Development observations, outside final acceptance

These logs preserve author checks and repairs before frozen source 960fb72f.
They are not added to the 1,000 final executions. The first range-store run
failed because the test helper requested 100 rows against a deliberate page
limit of 1; the repaired helper and all 15 range-store cases subsequently passed.
The initial direct `dart test` launcher stalled in build hooks and was cancelled
before any tests ran; transport-development.jsonl retains that output. A first
attempt to use a manually named package:test path failed because the lock uses
1.31.1, not 1.31.0; the successful run resolved the launcher from package_config.
That setup error was observed in the session and is summarized here, not recreated
as an original raw log. The host-store reopen fixture was then strengthened to
high UIDs and covered by the final frozen-source gate. Earlier parser checks
predate the added malformed-delimiter cases; the final fork author log has
68 substantive passing cases. Initial lint diagnostics were repaired before
final qualification. No GitHub Actions were queried, dispatched or awaited.
