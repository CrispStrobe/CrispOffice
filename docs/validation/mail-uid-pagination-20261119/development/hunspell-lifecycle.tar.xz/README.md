# Hunspell native lifecycle development evidence

Both defects were reproduced against the native transport from published
`94b4f2bdc541cbd3821b3dfaeb40a6a1466f4eb2`, using the instrumented C ABI
fixture through the actual Dart FFI/isolate path. The red normal-disposal test
observed zero native closes; the red allocation-failed replacement test
observed reuse of the freed handle instead of an unavailable dictionary.

The repaired transport passes all eight lifecycle cases in
`green-reviewed-native-lifecycle.jsonl`. Earlier successful intermediate
executions remain separate. Five existing missing-library/actual Hunspell and
AyaSpell cases also passed in `green-real-library.jsonl`. The latter run
predates only the independent review's static finalizer root; final combined
qualification reexecutes that real library coverage on the frozen source.
No case in these configured focused green runs was skipped.

Strict analysis and formatting passed. `receipt.json` binds final source,
fixture library and raw logs by SHA-256; it distinguishes these focused
development checks from the final combined qualification. Build provenance
for the fixture is retained by the runtime owner.

Normal disposal rejects pending Dart work, serializes close after an active
native call, waits for the explicit close acknowledgement, and shares cleanup
across repeated callers. Ownership is cleared before failed replacement can
reuse it. A statically rooted native finalizer backs up abnormal shutdown.
The two-second forced shutdown fallback does not establish immediate native
call cancellation or prompt finalizer execution.
