import 'package:quds_office_engine/quds_office_engine.dart';
void main() {
  for (final marker in ['rtl', 'cs']) {
    final p = OpcPackage.create(OpcPackageKind.word);
    p.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="${OfficeNamespaces.w}"><w:body><w:p><w:r><w:rPr><w:rStyle w:val="Off"/><w:$marker/><w:lang w:val="en-US" w:bidi="ar-SA"/></w:rPr><w:t>Latin123</w:t></w:r></w:p><w:sectPr/></w:body></w:document>');
    p.createPart('/word/styles.xml', OfficeContentTypes.wordStyles).writeText('<w:styles xmlns:w="${OfficeNamespaces.w}"><w:style w:type="character" w:styleId="Off"><w:rPr><w:$marker w:val="0"/></w:rPr></w:style></w:styles>');
    p.relationshipsFor('/word/document.xml').add(type: RelationshipTypes.styles, target:'styles.xml');
    final d=WordDeserializer().read(p);
    final paragraph=d.paragraphs.single;
    final run=paragraph.inlines.whereType<WmlRun>().single;
    print('$marker: complex=${run.properties.complexScript}, language=${wordRunProofingLanguage(run,paragraph)}, expected complex=true language=ar-SA');
  }
}
