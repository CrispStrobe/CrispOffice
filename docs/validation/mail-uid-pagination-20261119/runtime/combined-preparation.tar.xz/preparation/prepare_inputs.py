#!/usr/bin/env python3
"""Prepare verified public build inputs without changing repository source."""
from __future__ import annotations
from datetime import datetime, timezone
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import urllib.request
import zipfile

ROOT=Path('/workspace/scratch/ab196f483cec')
RUNTIME=ROOT/'runtime'
REPO=ROOT/'quds_office_suite'
REF='dc267fb4957d5a6499ce8174fd4a2acc39a4acf8'


def get(url: str) -> bytes:
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url,timeout=60) as response:
                return response.read()
        except Exception:
            if attempt==2:raise


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write(path: Path,value) -> None:
    path.write_text(json.dumps(value,indent=2)+'\n')


def cmake() -> None:
    version='3.31.10'
    directory=RUNTIME/'build-tools'/('cmake-'+version)
    directory.mkdir(parents=True,exist_ok=False)
    metadata_url=f'https://pypi.org/pypi/cmake/{version}/json'
    metadata_bytes=get(metadata_url)
    metadata=json.loads(metadata_bytes)
    candidates=[x for x in metadata['urls'] if x['filename']==f'cmake-{version}-py3-none-manylinux_2_17_x86_64.manylinux2014_x86_64.whl']
    if len(candidates)!=1:raise RuntimeError('Expected exact pinned Linux x64 CMake wheel')
    item=candidates[0]
    data=get(item['url'])
    if len(data)!=item['size'] or sha(data)!=item['digests']['sha256']:
        raise RuntimeError('CMake wheel differs from official PyPI release metadata')
    wheel=directory/item['filename'];wheel.write_bytes(data)
    (directory/'pypi-release.json').write_bytes(metadata_bytes)
    target=directory/'installed';target.mkdir()
    with zipfile.ZipFile(wheel) as archive:
        for member in archive.infolist():
            destination=(target/member.filename).resolve()
            if not destination.is_relative_to(target.resolve()):raise RuntimeError('Unsafe wheel member')
        archive.extractall(target)
        for member in archive.infolist():
            path=target/member.filename
            if path.is_file() and member.external_attr>>16:
                path.chmod((member.external_attr>>16)&0o777)
    executable=target/'cmake/data/bin/cmake'
    observed=subprocess.check_output([str(executable),'--version'],text=True)
    if observed.splitlines()[0]!=f'cmake version {version}':raise RuntimeError('Unexpected CMake version')
    compiler=Path('/usr/bin/g++').resolve()
    receipt={'at_utc':datetime.now(timezone.utc).isoformat(),'version':version,
             'metadata_url':metadata_url,'metadata_sha256':sha(metadata_bytes),
             'wheel':{'url':item['url'],'file':str(wheel),'bytes':len(data),'sha256':sha(data)},
             'executable':str(executable),'executable_sha256':sha(executable.read_bytes()),
             'version_output':observed,'compiler':{'path':str(compiler),'sha256':sha(compiler.read_bytes()),
               'version':subprocess.check_output([str(compiler),'--version'],text=True)}}
    write(directory/'receipt.json',receipt)
    print(json.dumps(receipt,indent=2))


def dictionary() -> None:
    folder=RUNTIME/'hunspell';folder.mkdir(exist_ok=True)
    source_path='packages/quds_proofing_hunspell/lib/src/hunspell_catalog.dart'
    catalog=subprocess.check_output(['git','-C',str(REPO),'show',REF+':'+source_path])
    text=catalog.decode()
    repository=re.search(r"repository:\s*'([^']+)'",text)[1]
    revision=re.search(r"revision:\s*'([0-9a-f]{40})'",text)[1]
    artifacts=re.findall(r"HunspellArtifact\(\s*'([^']+)',\s*'([0-9a-f]{64})',\s*(\d+),",text)
    if len(artifacts)!=8 or sum(int(row[2]) for row in artifacts)!=7332691:
        raise RuntimeError('Unexpected pinned AyaSpell catalog shape')
    target=folder/('ayaspell-'+revision);target.mkdir(exist_ok=False)
    files=[]
    for name,expected,size in artifacts:
        if not re.fullmatch(r'[A-Za-z0-9._-]+',name):raise RuntimeError('Unsafe artifact name')
        url=f'https://huggingface.co/{repository}/resolve/{revision}/{name}'
        data=get(url)
        if len(data)!=int(size) or sha(data)!=expected:raise RuntimeError('Dictionary differs from catalog: '+name)
        (target/name).write_bytes(data)
        files.append({'file':name,'path':str(target/name),'url':url,'bytes':len(data),'sha256':sha(data)})
        print(json.dumps({'verified':name,'bytes':len(data)}),flush=True)
    receipt={'at_utc':datetime.now(timezone.utc).isoformat(),'repository':repository,'revision':revision,
             'catalog_source_commit':REF,'catalog_source_path':source_path,'catalog_sha256':sha(catalog),
             'directory':str(target),'files':files,'total_bytes':sum(x['bytes'] for x in files)}
    write(folder/'dictionary-receipt.json',receipt)
    print(json.dumps({'complete':True,'directory':str(target),'files':len(files)}))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['cmake','dictionary'])
    args=parser.parse_args()
    (cmake if args.mode=='cmake' else dictionary)()
