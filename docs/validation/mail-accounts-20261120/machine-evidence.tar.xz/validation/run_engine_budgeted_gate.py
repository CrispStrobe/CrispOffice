#!/usr/bin/env python3
"""Repeat the unchanged integration cohort with a bounded CLI startup budget.

The original 30-second-per-test attempt is preserved and rejected. Each CLI
case starts two fresh Dart source processes. This wrapper changes only the
package:test deadline to two minutes; it preserves every assertion, the
600-second cohort deadline, and all strict acceptance checks. It additionally
binds the CLI source and the two macro fixtures opened by runtime file paths.
"""

import json
from pathlib import Path
import shutil
import sys

import run_final_engine_gate as gate


def main():
    if gate.head() != '625f4d76d10ddf2144220f25ae8d867452eeed61':
        raise RuntimeError('The qualified source must remain frozen.')
    plan = json.loads((gate.VALIDATION / 'cohort-plan-625f4d76.json').read_text())
    cohort = next(item for item in plan if item['name'] == 'engine-integration-625f4d76')
    selected = [gate.resolve_test(name) for name in cohort['tests']]
    roots = gate.package_roots()
    runner = roots['test'] / 'bin/test.dart'
    dart = shutil.which('dart')
    if dart is None or not runner.is_file():
        raise RuntimeError('Source mail-runtime/env.sh before running this gate.')
    explicit = {
        gate.ENGINE / 'tool/macros/office_macro.dart',
        gate.ENGINE / 'example/macros/word_optional_helpers.bas',
        gate.ENGINE / 'example/macros/powerpoint_optional_helpers.bas',
    }
    if not all(path.is_file() for path in explicit):
        raise RuntimeError('A spawned CLI source or macro fixture is missing.')

    def snapshot(tests, package_roots, previous=()):
        paths = gate.input_paths(tests, package_roots) | explicit
        paths |= {gate.ROOT / name for name in previous}
        paths = gate.include_local_dart_support(paths, package_roots)
        return {
            str(path.relative_to(gate.ROOT)): gate.sha(path) if path.is_file() else None
            for path in sorted(paths)
        }

    command = [
        dart, '--packages=' + str(gate.PACKAGE_CONFIG), str(runner),
        '--concurrency=1', '--timeout=2m', '--reporter=json',
        *(str(path.relative_to(gate.ENGINE)) for path in selected),
    ]
    return gate.run_gate(
        'engine-integration-budgeted-625f4d76', selected, gate.ENGINE,
        command, roots, snapshot,
        'Original engine integration scope plus the spawned macro CLI and two '
        'runtime-read BAS fixtures. Unchanged product/test source and assertions. '
        'A two-minute per-test ceiling accommodates two fresh Dart CLI starts; '
        'the whole cohort remains bounded to 600 seconds.',
        [Path(gate.__file__).resolve(), Path(__file__).resolve()], 600,
        {
            'test_runner': str(runner),
            'test_runner_sha256': gate.sha(runner),
            'per_test_timeout': '2m',
            'rejected_predecessor': 'engine-integration-625f4d76',
            'additional_runtime_inputs': sorted(str(path.relative_to(gate.ROOT)) for path in explicit),
        },
    )


if __name__ == '__main__':
    sys.exit(main())
