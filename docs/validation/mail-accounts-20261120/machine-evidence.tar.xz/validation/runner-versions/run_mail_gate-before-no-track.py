#!/usr/bin/env python3
"""Run an explicit Mail/Studio cohort with strict, source-bound evidence.

Source mail-runtime/env.sh first. QUDS_OFFICE_ROOT optionally selects a checkout.
Default package: packages/quds_office_editor/example. Use --package for another
workspace package and --tool dart for a pure Dart cohort. Keep this script beside
run_final_engine_gate.py, which supplies shared evidence and event handling.
No package resolution, cache deletion, or prior evidence overwrite is performed.
"""

import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys

import run_final_engine_gate as gate


ROOT = gate.ROOT
DEFAULT_PACKAGE = 'packages/quds_office_editor/example'
EQUIVALENCE_TEST = 'word_incremental_layout_equivalence_test.dart'
EQUIVALENCE_ROOTS = (
    'packages/legacy_doc_parser/test/fixtures/fidelity',
    'packages/legacy_doc_parser/test/fixtures/fidelity/semantic-contracts',
    'packages/legacy_doc_parser/test/fixtures/fidelity/image-appearance/authored',
    'packages/legacy_doc_parser/test/fixtures/word_native',
    'packages/quds_office_engine/test/fixtures',
    'packages/quds_office_engine/test/fixtures/fidelity',
    'packages/quds_office_engine/test/fixtures/word-kerning',
    'docs/validation/word-native-layout-20261120/reference',
    'packages/quds_office_editor/test/fixtures',
)
EQUIVALENCE_FILES = tuple(
    'docs/validation/word-line-boxes-20261120/reference/' + name + '.docx'
    for name in ('wl2-justify-arial', 'wl2-mixed-size-valid',
                 'calibri-auto-360', 'times-exact-360')
)
POI_ROOT = 'packages/legacy_doc_parser/test/fixtures/external/poi-20261114/poi/docx'


def tree_entries(arguments):
    completed = subprocess.run(
        ['git', 'ls-tree', '-z', *arguments], cwd=ROOT, capture_output=True,
    )
    if completed.returncode != 0:
        return {}, completed.stderr.decode('utf-8', errors='replace').strip()
    result = {}
    for entry in completed.stdout.split(b'\0'):
        if not entry:
            continue
        metadata, name = entry.decode('utf-8').split('\t', 1)
        mode, kind, identifier = metadata.split(' ')
        result[name] = {'mode': mode, 'kind': kind, 'git_blob_sha': identifier}
    return result, None


def equivalence_inventory():
    # Match _fixtures() exactly: immediate .docx files, not recursive traversal.
    # Read tree metadata only; this does not materialize any fixture blobs.
    source_head = gate.head()
    poi = os.environ.get('QUDS_EQUIVALENCE_POI') == '1'
    roots = (*EQUIVALENCE_ROOTS, *((POI_ROOT,) if poi else ()))
    expected, observed, directories, errors = {}, set(), [], []
    for relative in roots:
        entries, error = tree_entries([source_head + ':' + relative])
        if error:
            errors.append({'path': relative, 'error': error})
        tracked = {
            relative + '/' + name: metadata['git_blob_sha']
            for name, metadata in entries.items()
            if metadata['kind'] == 'blob' and name.endswith('.docx')
        }
        expected.update(tracked)
        directory = ROOT / relative
        actual = sorted(
            str(path.relative_to(ROOT)) for path in directory.iterdir()
            if path.is_file() and path.name.endswith('.docx')
        ) if directory.is_dir() else []
        observed.update(actual)
        directories.append({
            'path': relative, 'exists': directory.exists(),
            'is_directory': directory.is_dir(), 'tracked': error is None,
            'expected_docx_files': sorted(tracked), 'actual_docx_files': actual,
        })
    entries, error = tree_entries([source_head, '--', *EQUIVALENCE_FILES])
    if error:
        errors.append({'path': 'explicit reference files', 'error': error})
    for relative in EQUIVALENCE_FILES:
        metadata = entries.get(relative)
        if metadata is None or metadata['kind'] != 'blob':
            errors.append({'path': relative, 'error': 'Explicit reference is not tracked at HEAD'})
        else:
            expected[relative] = metadata['git_blob_sha']
        if (ROOT / relative).is_file():
            observed.add(relative)
    files = []
    for relative in sorted(expected.keys() | observed):
        path = ROOT / relative
        present = path.is_file()
        files.append({
            'path': relative, 'exists': path.exists(), 'is_file': present,
            'git_blob_sha': expected.get(relative),
            'sha256': gate.sha(path) if present else None,
            'bytes': path.stat().st_size if present else None,
        })
    missing = sorted(expected.keys() - observed)
    unexpected = sorted(observed - expected.keys())
    return {
        'source_head': source_head, 'optional_poi_enabled': poi,
        'directories': directories, 'explicit_files': list(EQUIVALENCE_FILES),
        'files': files, 'expected_docx_count': len(expected),
        'materialized_docx_count': len(observed),
        'registered_corpus_expected': len(expected), 'missing_files': missing,
        'unexpected_files': unexpected, 'git_errors': errors,
        'complete': bool(expected) and not missing and not unexpected and not errors
                    and all(entry['is_directory'] for entry in directories),
    }



def resolve_package(value):
    requested = Path(value)
    package = (requested if requested.is_absolute() else ROOT / requested).resolve()
    if not package.is_relative_to(ROOT) or not (package / 'pubspec.yaml').is_file():
        raise ValueError(f'Expected a workspace package with pubspec.yaml: {value}')
    return package


def resolve_test(value, package):
    path = Path(value)
    if path.is_absolute():
        candidate = path
    elif path.parts and path.parts[0] in ('packages', 'third_party'):
        candidate = ROOT / path
    elif path.parts and path.parts[0] == 'test':
        candidate = package / path
    else:
        candidate = package / 'test' / path
    candidate = candidate.resolve()
    if (not candidate.is_relative_to(package / 'test')
            or not candidate.name.endswith('_test.dart')
            or not candidate.is_file()):
        raise ValueError(f'Expected an existing explicit test within {package}: {value}')
    return candidate


def manifests():
    # Re-inventory on each snapshot. Prune generated/cache directories instead
    # of allowing build products or old evidence to become source inputs.
    result = {ROOT / 'pubspec.yaml'}
    excluded = {'.git', '.dart_tool', 'build', 'node_modules'}
    for base in (ROOT / 'packages', ROOT / 'third_party'):
        if not base.is_dir():
            continue
        for directory, children, files in os.walk(base):
            children[:] = [child for child in children if child not in excluded]
            if 'pubspec.yaml' in files:
                result.add(Path(directory) / 'pubspec.yaml')
    return result


def input_paths(selected, roots, package):
    paths = set(selected)
    local_roots = {ROOT, package, ROOT / 'third_party/enough_mail'}
    local_roots.update(path for path in roots.values() if path.is_relative_to(ROOT))
    packages = ROOT / 'packages'
    if packages.is_dir():
        local_roots.update(path for path in packages.iterdir() if path.is_dir())
    for base in local_roots:
        for area in ('lib', 'assets', 'fonts', 'templates'):
            paths.update(path for path in (base / area).rglob('*') if path.is_file())
    package_manifests = manifests()
    paths.update(package_manifests)
    manifest_roots = local_roots | {path.parent for path in package_manifests}
    for base in manifest_roots:
        for relative in ('pubspec.yaml', 'pubspec.lock',
                         '.dart_tool/package_config.json', 'pubspec_overrides.yaml'):
            paths.add(base / relative)
    for base in (ROOT, package):
        paths.add(base / 'dart_test.yaml')
    # Snapshot every materialized helper/fixture under the selected package.
    # Imported test cases are then added by the transitive directive walk.
    paths.update(
        path for path in (package / 'test').rglob('*')
        if path.is_file() and not path.name.endswith('_test.dart')
    )
    return gate.include_local_dart_support(paths, roots)


def snapshot(selected, roots, package, previous=(), fixture_inputs=()):
    paths = input_paths(selected, roots, package) | {ROOT / name for name in previous}
    paths.update(ROOT / name for name in fixture_inputs)
    return {
        str(path.relative_to(ROOT)): gate.sha(path) if path.is_file() else None
        for path in sorted(paths)
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('name', help='New evidence directory name (never overwritten)')
    parser.add_argument('tests', nargs='+', help='Explicit package *_test.dart paths')
    parser.add_argument('--package', default=DEFAULT_PACKAGE)
    parser.add_argument('--tool', choices=('flutter', 'dart'), default='flutter')
    parser.add_argument('--timeout', type=int, default=600)
    args = parser.parse_args()
    gate.validate_arguments(parser, args)
    try:
        package = resolve_package(args.package)
        selected = [resolve_test(value, package) for value in args.tests]
        if len(set(selected)) != len(selected):
            raise ValueError('Duplicate test paths are not allowed')
        roots = gate.package_roots()
        executable = shutil.which(args.tool)
        if executable is None:
            raise ValueError(f'{args.tool} is unavailable; source mail-runtime/env.sh first')
        tests = [str(path.relative_to(package)) for path in selected]
        extra = {'package': str(package.relative_to(ROOT)), 'tool': args.tool}
        if args.tool == 'flutter':
            command = [executable, 'test', '--no-pub', '--concurrency=1',
                       '--reporter=json', *tests]
        else:
            test_runner = roots['test'] / 'bin/test.dart'
            if not test_runner.is_file():
                raise ValueError('The configured package:test runner is unavailable')
            command = [executable, '--packages=' + str(gate.PACKAGE_CONFIG),
                       str(test_runner), '--concurrency=1', '--reporter=json', *tests]
            extra.update(test_runner=str(test_runner),
                         test_runner_sha256=gate.sha(test_runner))
    except (ValueError, KeyError, OSError) as error:
        parser.error(str(error))

    fixture_state = {}
    has_equivalence = any(path.name == EQUIVALENCE_TEST for path in selected)

    def collect_inventory():
        current = equivalence_inventory()
        fixture_state.clear()
        fixture_state.update(current)
        return current

    def take_snapshot(selected, roots, previous=()):
        return snapshot(
            selected, roots, package, previous,
            [entry['path'] for entry in fixture_state.get('files', [])],
        )

    scope = ('All workspace package libraries and assets/fonts/templates, including '
             'the selected Studio or Mail package and local enough_mail; all '
             'workspace/nested package manifests, locks, overrides and package '
             'configurations; selected tests; all materialized selected-package '
             'test helpers/fixtures and transitive local Dart support; root and '
             'selected-package test configuration. A focused cohort, not a '
             'whole-repository or live-provider acceptance gate. For the incremental '
             'equivalence suite, include exactly its declared immediate external DOCX '
             'roots and four explicit references; optional POI only when enabled.')
    return gate.run_gate(
        args.name, selected, package, command, roots, take_snapshot, scope,
        [Path(__file__).resolve(), Path(gate.__file__).resolve()], args.timeout, extra,
        inventory=collect_inventory if has_equivalence else None,
    )


if __name__ == '__main__':
    sys.exit(main())
