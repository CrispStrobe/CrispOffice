#!/usr/bin/env python3
"""Replay retained test/static evidence without running Dart, Flutter, or CI.

From an extracted validation directory:
  python3 replay_evidence.py --output replay-check.json
With an optional repository containing the qualified commit:
  python3 replay_evidence.py --repo /path/to/repo --output replay-check.json

Exit zero means retained evidence agrees with its declared accepted/rejected
dispositions. Expected rejected runs remain rejected and contribute zero cases.
Without --repo, source bindings are verified against the retained, previously
Git-verified blob manifest. With --repo, those bindings are recomputed from the
qualified commit, irrespective of the repository's current HEAD or checkout.
"""
import argparse
import collections
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import posixpath
import re
import subprocess
import sys


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def artifact(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Evidence path leaves validation directory: " + str(relative))
    return path


def tally(cases):
    return {
        "total": len(cases),
        "passed": sum(c["result"] == "success" and not c["skipped"] for c in cases),
        "failed": sum(c["result"] != "success" and not c["skipped"] for c in cases),
        "skipped": sum(c["skipped"] for c in cases),
    }


def parse_events(raw):
    """Use physical LF records; Unicode separators inside names are not lines."""
    starts, done, suites = {}, {}, {}
    counts = collections.Counter()
    invalid, duplicate_starts, duplicate_done = [], [], []
    errors, prints, finals = [], [], []
    last_kind = None
    physical_lines = 0
    for number, line in enumerate(io.BytesIO(raw), 1):
        physical_lines = number
        try:
            event = json.loads(line)
        except (ValueError, UnicodeDecodeError):
            invalid.append(number)
            continue
        if not isinstance(event, dict) or not isinstance(event.get("type"), str):
            invalid.append(number)
            continue
        kind = last_kind = event["type"]
        counts[kind] += 1
        if kind == "suite":
            suites[event["suite"]["id"]] = event["suite"]["path"]
        elif kind == "testStart":
            test = event["test"]
            if test["id"] in starts:
                duplicate_starts.append(test["id"])
            starts[test["id"]] = test
        elif kind == "testDone":
            key = event["testID"]
            if key in done:
                duplicate_done.append(key)
            done[key] = event
        elif kind == "error":
            errors.append(event)
        elif kind == "print":
            prints.append(event)
        elif kind == "done":
            finals.append(event)
    parts = {"substantive": [], "loading": [], "other_hidden": []}
    for key, event in done.items():
        test = starts.get(key, {})
        loading = (
            str(test.get("name", "")).startswith("loading ")
            and not test.get("groupIDs")
            and test.get("line") is None
        )
        case = {
            "id": key,
            "name": test.get("name"),
            "suite": suites.get(test.get("suiteID")),
            "result": event.get("result"),
            "skipped": bool(event.get("skipped", False)),
            "hidden": bool(event.get("hidden", False)),
            "loading": loading,
            "metadata": test.get("metadata", {}),
        }
        part = "loading" if loading else "other_hidden" if case["hidden"] else "substantive"
        parts[part].append(case)
    all_cases = sum(parts.values(), [])
    suite_counts = {
        path: tally([case for case in parts["substantive"] if case["suite"] == path])
        for path in suites.values()
    }
    registered = [
        {
            "id": key,
            "name": test.get("name"),
            "suite": suites.get(test.get("suiteID")),
            "metadata": test.get("metadata", {}),
            "completion": done.get(key),
            "output_events": [e for e in prints if e.get("testID") == key],
        }
        for key, test in starts.items()
        if str(suites.get(test.get("suiteID"), "")).endswith(
            "word_incremental_layout_equivalence_test.dart"
        )
        and re.search(r"(?:^|\s)fixture ", str(test.get("name", "")))
    ]
    return {
        **tally(parts["substantive"]),
        "substantive": tally(parts["substantive"]),
        "loading": tally(parts["loading"]),
        "other_hidden": tally(parts["other_hidden"]),
        "hidden": tally([c for c in all_cases if c["hidden"]]),
        "all_completions": tally(all_cases),
        "cases": parts["substantive"],
        "loading_cases": parts["loading"],
        "other_hidden_cases": parts["other_hidden"],
        "suites": suite_counts,
        "event_counts": dict(counts),
        "errors": errors,
        "print_events": prints,
        "skip_events": [e for e in prints if e.get("messageType") == "skip"],
        "skipped_cases": [c for c in all_cases if c["skipped"]],
        "model_error_events": [
            e for e in prints if "EQUIVALENCE_MODEL_ERROR" in str(e.get("message", ""))
        ],
        "registered_corpus": registered,
        "registered_corpus_count": len(registered),
        "invalid_jsonl_lines": invalid,
        "duplicate_completions": duplicate_done,
        "unfinished_tests": sorted(set(starts) - set(done)),
        "unmatched_completions": sorted(set(done) - set(starts)),
        "final_done_count": len(finals),
        "final_event": finals[-1] if finals else None,
        "duplicate_test_starts": duplicate_starts,
        "last_event_kind": last_kind,
        "physical_jsonl_lines": physical_lines,
        "unicode_separator_occurrences": {
            "NEL": raw.count("\u0085".encode()),
            "LINE_SEPARATOR": raw.count("\u2028".encode()),
            "PARAGRAPH_SEPARATOR": raw.count("\u2029".encode()),
        },
    }


def logical_path(value, record):
    """Normalize recorded paths lexically; never access the old absolute path."""
    value = posixpath.normpath(value)
    if not value.startswith("/"):
        value = posixpath.normpath(posixpath.join(record["cwd"], value))
    return str(PurePosixPath(value).relative_to(record["repository_root"]))


def source_check(inputs, bindings):
    problems = []
    tracked = 0
    for path, value in inputs.items():
        if path in bindings["tracked_inputs"]:
            tracked += 1
            expected = bindings["tracked_inputs"][path]["sha256"]
            if value != expected:
                problems.append({"path": path, "recorded": value, "expected": expected})
        elif path in bindings["non_repository_input_values"]:
            if value not in bindings["non_repository_input_values"][path]:
                problems.append({"path": path, "unexpected_runtime_or_absent_value": value})
        else:
            problems.append({"path": path, "missing_source_binding": True})
    return {"tracked_inputs_checked": tracked, "mismatches": problems, "passed": not problems}


def verify_git_bindings(repo, bindings):
    env = dict(os.environ, GIT_NO_LAZY_FETCH="1", GIT_OPTIONAL_LOCKS="0")
    commit = bindings["qualified_commit"]
    if not re.fullmatch("[0-9a-f]{40}", commit):
        raise ValueError("Invalid qualified commit")
    def git(*args):
        return subprocess.check_output(
            ["git", "--no-optional-locks", *args], cwd=repo, env=env
        )
    tree_id = git("rev-parse", commit + "^{tree}").decode().strip()
    if tree_id != bindings["qualified_tree"]:
        raise ValueError("Qualified Git tree differs from source manifest")
    entries = {}
    for row in git("ls-tree", "-rz", commit).split(b"\0"):
        if not row:
            continue
        metadata, path = row.split(b"\t", 1)
        mode, kind, oid = metadata.decode().split()
        entries[os.fsdecode(path)] = {"mode": mode, "type": kind, "oid": oid}
    for path, saved in bindings["tracked_inputs"].items():
        if entries.get(path) != {k: saved[k] for k in ("mode", "type", "oid")}:
            raise ValueError("Git tree entry differs: " + path)
    expected = {
        row["oid"]: row["sha256"] for row in bindings["tracked_inputs"].values()
    }
    proc = subprocess.Popen(
        ["git", "--no-optional-locks", "cat-file", "--batch"],
        cwd=repo, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    try:
        for oid, wanted in sorted(expected.items()):
            proc.stdin.write((oid + "\n").encode())
            proc.stdin.flush()
            header = proc.stdout.readline().decode().strip().split()
            if len(header) != 3 or header[:2] != [oid, "blob"]:
                raise ValueError("Unavailable qualified blob: " + oid)
            remaining = int(header[2])
            calculated = hashlib.sha256()
            while remaining:
                chunk = proc.stdout.read(min(remaining, 1024 * 1024))
                if not chunk:
                    raise ValueError("Truncated Git blob")
                calculated.update(chunk)
                remaining -= len(chunk)
            if proc.stdout.read(1) != b"\n" or calculated.hexdigest() != wanted:
                raise ValueError("Qualified blob SHA-256 differs: " + oid)
    finally:
        proc.stdin.close()
        result = proc.wait(timeout=30)
    if result:
        raise ValueError("Git blob verifier failed")
    return {
        "mode": "recomputed_from_qualified_git_commit",
        "commit": commit,
        "tree": tree_id,
        "tracked_paths": len(bindings["tracked_inputs"]),
        "unique_blobs": len(expected),
    }


def audit_gate(root, spec, plan, bindings):
    folder = artifact(root, spec["name"])
    summary = read_json(folder / "summary.json")
    start = read_json(folder / "run-start.json")
    process = read_json(folder / "process-exit.json")
    before = read_json(folder / "inputs-before.json")
    after = read_json(folder / "inputs-after.json")
    raw = (folder / "events.jsonl").read_bytes()
    parsed = parse_events(raw)
    inconsistencies = []
    for key, value in parsed.items():
        if key in summary and summary[key] != value:
            inconsistencies.append("raw_vs_summary:" + key)
    for key in ("head_before", "command", "cwd", "selected_tests", "runner_sources_before"):
        if summary.get(key) != start.get(key):
            inconsistencies.append("run_start:" + key)
    for key in ("process_exit_code", "runner_error", "timed_out"):
        if summary.get(key) != process.get(key):
            inconsistencies.append("process_exit:" + key)
    for field, name in (
        ("stdout_sha256", "events.jsonl"), ("stderr_sha256", "stderr.log"),
        ("inputs_before_sha256", "inputs-before.json"),
        ("inputs_after_sha256", "inputs-after.json"),
    ):
        if summary.get(field) != digest((folder / name).read_bytes()):
            inconsistencies.append("digest:" + field)
    same_inputs = before == after
    if summary.get("inputs_unchanged") != same_inputs:
        inconsistencies.append("inputs_unchanged")
    if summary.get("selected_tests") != spec["selected_tests"]:
        inconsistencies.append("selected_tests_plan")
    if summary.get("input_keys") != len(before):
        inconsistencies.append("input_keys")
    if summary.get("input_files") != sum(v is not None for v in before.values()):
        inconsistencies.append("input_files")
    changed = sorted(p for p in set(before) | set(after) if before.get(p) != after.get(p))
    if summary.get("changed_inputs") != changed:
        inconsistencies.append("changed_inputs")
    source = source_check(before, bindings)
    selected = {logical_path(p, summary) for p in summary["selected_tests"]}
    loaded = {logical_path(p, summary) for p in parsed["suites"]}
    cases = [
        {**c, "canonical_suite": logical_path(c["suite"], summary)}
        for c in parsed["cases"]
    ]
    reasons = []
    def require(value, label):
        if not value:
            reasons.append(label)
    require(not inconsistencies, "receipt_summary_inconsistency")
    require(summary.get("head_before") == plan["qualified_commit"]
            and summary.get("head_after") == plan["qualified_commit"],
            "wrong_or_changed_qualified_source")
    require(process.get("process_exit_code") == 0, "nonzero_process_exit")
    require(not process.get("timed_out") and process.get("runner_error") is None,
            "timeout_or_runner_error")
    require(summary.get("after_config_error") is None, "after_snapshot_error")
    require(summary.get("gate_passed") is True and summary.get("wrapper_exit_code") == 0,
            "strict_runner_rejected")
    require(parsed["final_done_count"] == 1
            and (parsed["final_event"] or {}).get("success") is True
            and parsed["last_event_kind"] == "done", "invalid_terminal_done")
    require(same_inputs and source["passed"], "input_drift_or_source_binding_failure")
    require(summary.get("runner_sources_before") == summary.get("runner_sources_after"),
            "runner_source_drift")
    for name, value in summary.get("runner_sources_before", {}).items():
        require(plan["runner_source_sha256"].get(name) == value,
                "unbound_runner_source:" + name)
    if summary.get("test_runner"):
        entry = bindings["external_test_entrypoints"].get(summary["test_runner"], {})
        require(entry.get("sha256") == summary.get("test_runner_sha256"),
                "unbound_external_test_entrypoint")
    require(summary.get("fixture_inventory_unchanged") is True
            and summary.get("fixture_inventory_complete") is True
            and summary.get("fixture_inventory_before") == summary.get("fixture_inventory_after"),
            "fixture_inventory_drift_or_gap")
    require(summary.get("corpus_registration_matches") is True, "corpus_registration_gap")
    require(parsed["passed"] > 0 and parsed["all_completions"]["failed"] == 0
            and parsed["all_completions"]["skipped"] == 0, "failed_or_skipped_cases")
    require(loaded == selected
            and all(count["passed"] > 0 for count in parsed["suites"].values()),
            "selected_suite_coverage_gap")
    require(all(path in before for path in selected), "selected_test_not_source_bound")
    for key in (
        "errors", "skip_events", "model_error_events", "invalid_jsonl_lines",
        "duplicate_test_starts", "duplicate_completions", "unfinished_tests",
        "unmatched_completions",
    ):
        require(not parsed[key], key)
    require(not any(c["metadata"].get("skip") for c in
                    parsed["cases"] + parsed["loading_cases"] + parsed["other_hidden_cases"]),
            "skip_metadata")
    identities = [(c["canonical_suite"], c["name"]) for c in cases]
    require(len(identities) == len(set(identities)), "duplicate_case_identities")
    observed_acceptance = not reasons
    return {
        "name": spec["name"],
        "expected_acceptance": spec["expected_acceptance"],
        "accepted_for_fixed_source": observed_acceptance,
        "disposition_matches_plan": observed_acceptance == spec["expected_acceptance"],
        "rejection_reasons": reasons,
        "summary_raw_consistent": not inconsistencies,
        "inconsistencies": inconsistencies,
        "head_before": summary.get("head_before"),
        "head_after": summary.get("head_after"),
        "command": summary["command"],
        "selected_tests": summary["selected_tests"],
        "source_binding": source,
        "process_exit": process,
        "counts": {k: parsed[k] for k in (
            "substantive", "loading", "other_hidden", "hidden", "all_completions")},
        "accepted_substantive_cases": parsed["passed"] if observed_acceptance else 0,
        "cases": cases,
        "suite_counts": {logical_path(k, summary): v for k, v in parsed["suites"].items()},
        "final_event": parsed["final_event"],
        "final_done_count": parsed["final_done_count"],
        "raw_event_counts": parsed["event_counts"],
        "physical_jsonl_lines": parsed["physical_jsonl_lines"],
        "unicode_separator_occurrences": parsed["unicode_separator_occurrences"],
        "errors": parsed["errors"],
        "model_error_events": parsed["model_error_events"],
        "source_snapshots_unchanged": same_inputs,
        "runner_sources_before": summary.get("runner_sources_before"),
        "runner_sources_after": summary.get("runner_sources_after"),
        "receipt_sha256": {
            name: digest((folder / name).read_bytes())
            for name in ("summary.json", "run-start.json", "process-exit.json",
                         "events.jsonl", "stderr.log", "inputs-before.json", "inputs-after.json")
        },
    }


def audit_static(root, plan, bindings):
    folder = artifact(root, plan["static_gate"])
    summary = read_json(folder / "summary.json")
    before = read_json(folder / "inputs-before.json")
    after = read_json(folder / "inputs-after.json")
    reasons, groups = [], []
    if summary.get("head_before") != plan["qualified_commit"] or summary.get("head_after") != plan["qualified_commit"]:
        reasons.append("wrong_static_source")
    if before["files"] != after["files"] or before.get("head") != plan["qualified_commit"]:
        reasons.append("static_input_drift")
    source = source_check(before["files"], bindings)
    if not source["passed"]:
        reasons.append("static_source_binding_failure")
    all_targets = []
    for group in summary["groups"]:
        receipt = read_json(folder / (group["name"] + "-exit.json"))
        output = read_json(folder / (group["name"] + ".log"))
        targets = [x for x in group["command"] if x.endswith(".dart")]
        all_targets += targets
        good = (
            receipt == group and group["exit_code"] == 0
            and "--fatal-infos" in group["command"]
            and "--format=json" in group["command"]
            and output.get("diagnostics") == []
            and targets == group.get("files")
        )
        groups.append({"name": group["name"], "passed": good, "targets": targets,
                       "diagnostics": output.get("diagnostics"), "exit_code": group["exit_code"]})
        if not good:
            reasons.append("static_group:" + group["name"])
    expected = plan["expected_static_targets"]
    if sorted(all_targets) != sorted(expected) or sorted(before["files"]) != sorted(expected):
        reasons.append("static_target_coverage_gap")
    format_log = (folder / "format.log").read_text()
    formatted = re.search(r"Formatted (\d+) files \((\d+) changed\)", format_log)
    if not (formatted and int(formatted[1]) == len(expected) and int(formatted[2]) == 0
            and summary.get("format_exit_code") == 0):
        reasons.append("format_receipt_not_clean")
    if summary.get("files") != len(expected) or summary.get("passed") is not True or summary.get("changed_inputs"):
        reasons.append("static_summary_not_clean")
    return {"name": plan["static_gate"], "accepted": not reasons, "reasons": reasons,
            "target_count": len(expected), "targets": expected, "groups": groups,
            "format_log": format_log, "format_exit_code": summary.get("format_exit_code"),
            "source_binding": source, "inputs_unchanged": before["files"] == after["files"],
            "qualification": "Strict analysis of the 19 Dart delta files; not whole-repository analysis."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validation-root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--plan", default="replay-plan.json")
    parser.add_argument("--repo", type=Path, help="Optional repo containing the qualified commit; HEAD need not match.")
    parser.add_argument("--output", type=Path, help="Optional review JSON destination. No files are written otherwise.")
    args = parser.parse_args()
    root = args.validation_root.resolve()
    plan_path = artifact(root, args.plan)
    plan = read_json(plan_path)
    source_path = artifact(root, plan["source_bindings_file"])
    if digest(source_path.read_bytes()) != plan["source_bindings_sha256"]:
        raise ValueError("Source-binding manifest digest changed")
    bindings = read_json(source_path)
    if (bindings["qualified_commit"], bindings["qualified_tree"]) != (
            plan["qualified_commit"], plan["qualified_tree"]):
        raise ValueError("Source binding and replay plan disagree")
    failures = []
    for name, wanted in plan["receipt_sha256"].items():
        if digest(artifact(root, name).read_bytes()) != wanted:
            failures.append("receipt_digest:" + name)
    for name, wanted in plan["runner_source_sha256"].items():
        if digest(artifact(root, name).read_bytes()) != wanted:
            failures.append("runner_digest:" + name)
    for collection in ("retained_generated_inputs", "external_test_entrypoints"):
        for item in bindings[collection].values():
            if digest(artifact(root, item["retained_path"]).read_bytes()) != item["sha256"]:
                failures.append("retained_runtime_digest:" + item["retained_path"])
    canonical = plan["canonical_source_review"]
    if digest(artifact(root, canonical["path"]).read_bytes()) != canonical["sha256"]:
        failures.append("canonical_source_review_digest")
    source_mode = (
        verify_git_bindings(args.repo.resolve(), bindings) if args.repo else
        {"mode": "retained_previously_git_verified_blob_manifest",
         "commit": plan["qualified_commit"], "tree": plan["qualified_tree"],
         "tracked_paths": len(bindings["tracked_inputs"]),
         "limitation": "No live Git object reread without --repo."}
    )
    gates = [audit_gate(root, item, plan, bindings) for item in plan["cohorts"]]
    static = audit_static(root, plan, bindings)
    for gate in gates:
        if not gate["disposition_matches_plan"] or not gate["summary_raw_consistent"]:
            failures.append("gate_disposition_or_receipt:" + gate["name"])
    if not static["accepted"]:
        failures.append("static_gate")
    accepted = [g for g in gates if g["accepted_for_fixed_source"]]
    identities = [(c["canonical_suite"], c["name"]) for g in accepted for c in g["cases"]]
    suites = {c["canonical_suite"] for g in accepted for c in g["cases"]}
    if len(identities) != len(set(identities)):
        failures.append("repeated_case_identities_across_accepted_cohorts")
    original = next(g for g in gates if g["name"] == "engine-integration-625f4d76")
    retry = next(g for g in gates if g["name"] == "engine-integration-budgeted-625f4d76")
    previous_inputs = read_json(artifact(root, original["name"] + "/inputs-before.json"))
    retry_inputs = read_json(artifact(root, retry["name"] + "/inputs-before.json"))
    retry_continuity = {
        "same_selected_suites": original["selected_tests"] == retry["selected_tests"],
        "same_90_case_identities": sorted(
            (c["canonical_suite"], c["name"]) for c in original["cases"]
        ) == sorted((c["canonical_suite"], c["name"]) for c in retry["cases"]),
        "existing_input_changes": sorted(p for p in previous_inputs if previous_inputs[p] != retry_inputs.get(p)),
        "added_source_inputs": sorted(set(retry_inputs) - set(previous_inputs)),
        "same_source_commit": original["head_before"] == retry["head_before"] == plan["qualified_commit"],
        "retry_timeout_argument_present": "--timeout=2m" in retry["command"],
        "original_rejected_cases_contributed": 0,
    }
    if not (retry_continuity["same_selected_suites"] and retry_continuity["same_90_case_identities"]
            and retry_continuity["same_source_commit"] and not retry_continuity["existing_input_changes"]
            and retry_continuity["retry_timeout_argument_present"]):
        failures.append("engine_retry_continuity")
    report = {
        "schema": "quds-mail-final-evidence-review/v2",
        "reviewed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "fixed_source_commit": plan["qualified_commit"],
        "fixed_source_tree": plan["qualified_tree"],
        "evidence_verified": not failures,
        "all_planned_gates_complete": plan["all_requested_final_cohorts_completed"] and not failures,
        "summary": {
            "accepted_cohorts": len(accepted),
            "accepted_substantive_cases": len(identities),
            "accepted_unique_suite_case_identities": len(set(identities)),
            "accepted_suites": len(suites),
            "accepted_mail_studio_cases": sum(g["accepted_substantive_cases"] for g in accepted if not g["name"].startswith("engine-")),
            "accepted_engine_cases": sum(g["accepted_substantive_cases"] for g in accepted if g["name"].startswith("engine-")),
            "rejected_runs": [g["name"] for g in gates if not g["accepted_for_fixed_source"]],
            "rejected_partial_successes_contributed": 0,
            "hidden_or_loading_completions_contributed": 0,
            "static_analyzed_dart_files": static["target_count"] if static["accepted"] else 0,
            "failures": failures,
        },
        "gates": gates,
        "static": static,
        "engine_retry_continuity": retry_continuity,
        "source_binding_verification": source_mode,
        "integrity": {
            "plan_sha256": digest(plan_path.read_bytes()),
            "source_bindings_sha256": digest(source_path.read_bytes()),
            "verifier_sha256": digest(Path(__file__).read_bytes()),
            "anchored_receipt_files": len(plan["receipt_sha256"]),
            "runner_sources": plan["runner_source_sha256"],
        },
        "method": {
            "physical_LF_JSONL_records": True,
            "unicode_separators_inside_JSON_strings_preserved": True,
            "raw_events_parsed_independently_of_gate_runner": True,
            "original_absolute_runtime_paths_not_accessed": True,
            "qualified_commit_used_instead_of_current_HEAD": True,
            "compilers_tests_analyzers_or_CI_executed": False,
            "repository_index_HEAD_refs_or_runner_files_changed": False,
        },
        "qualification_limits": plan["limitations"] + [
            "Only the seven accepted qualified-source cohorts contribute totals.",
            "The two original engine timeouts remain recorded; the complete 90-case replacement passed with a two-minute case budget and the same product/test source.",
            "Generated runtime configuration is bound by retained hashes; replay does not recreate or execute the runtime.",
            "Publication/main continuity is separately established by verify_publication.py and source-continuity.json.",
        ],
    }
    if args.output:
        args.output.write_text(json.dumps(report, indent=2, ensure_ascii=True) + "\n")
    print(json.dumps({
        "evidence_verified": report["evidence_verified"], "summary": report["summary"],
        "source_binding_mode": source_mode["mode"],
        "engine_retry_continuity": retry_continuity,
        "output": str(args.output) if args.output else None,
    }, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, OSError, subprocess.SubprocessError) as error:
        print(json.dumps({"evidence_verified": False, "error": str(error)}), file=sys.stderr)
        raise SystemExit(2)

