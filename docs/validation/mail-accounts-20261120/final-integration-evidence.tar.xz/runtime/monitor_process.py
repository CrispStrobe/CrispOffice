#!/usr/bin/env python3
"""Observe one command and its process subtree without changing its assertions."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--log', required=True)
parser.add_argument('--cwd', default=os.getcwd())
parser.add_argument('--interval', type=float, default=2.0)
parser.add_argument('--timeout', type=float)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
if not command or args.interval < 0.5 or (args.timeout is not None and args.timeout <= 0):
    parser.error('Supply a command, interval >= 0.5, and an optional positive timeout.')
log_path = Path(args.log)
log_path.parent.mkdir(parents=True, exist_ok=True)
log = log_path.open('x')
clock_ticks = os.sysconf('SC_CLK_TCK')
started = time.monotonic()
known = {}
previous = {}

def emit(event, **data):
    log.write(json.dumps({'event': event, 'elapsed_s': round(time.monotonic()-started, 3), **data}) + '\n')
    log.flush()

def host_memory():
    memory = {}
    for line in Path('/proc/meminfo').read_text().splitlines():
        key, value = line.split(':', 1)
        if key in ('MemTotal', 'MemAvailable', 'MemFree', 'SwapTotal', 'SwapFree', 'Shmem'):
            memory[key + '_kib'] = int(value.split()[0])
    for line in Path('/proc/vmstat').read_text().splitlines():
        if line.startswith('oom_kill '):
            memory['host_oom_kill_counter'] = int(line.split()[1])
            break
    return memory

def read_process(pid):
    try:
        root = Path('/proc') / str(pid)
        raw = (root/'stat').read_text()
        end = raw.rfind(')')
        fields = raw[end+2:].split()
        command_name = raw[raw.find('(')+1:end]
        status = {}
        for line in (root/'status').read_text().splitlines():
            if ':' in line:
                key, value = line.split(':', 1)
                if key in ('VmRSS', 'VmHWM', 'VmSize', 'RssAnon', 'RssFile', 'RssShmem', 'Threads'):
                    status[key] = int(value.split()[0])
        raw_args = (root/'cmdline').read_bytes().split(b'\0')
        role = 'other'
        for label, marker in [('frontend_compiler', b'frontend_server'),
                              ('analysis_server', b'analysis_server'),
                              ('flutter_tester', b'flutter_tester'),
                              ('flutter_tools', b'flutter_tools.snapshot')]:
            if any(marker in part for part in raw_args):
                role = label
                break
        result = {'pid': pid, 'ppid': int(fields[1]), 'name': command_name,
                  'role': role, 'state': fields[0], 'start_ticks': int(fields[19]),
                  'cpu_seconds': round((int(fields[11])+int(fields[12]))/clock_ticks, 3),
                  'rss_kib': status.get('VmRSS', 0), 'peak_rss_kib': status.get('VmHWM', 0),
                  'vm_size_kib': status.get('VmSize', 0), 'threads': status.get('Threads'),
                  'rss_anon_kib': status.get('RssAnon'), 'rss_file_kib': status.get('RssFile'),
                  'rss_shmem_kib': status.get('RssShmem')}
        if fields[0] == 'Z' and len(fields) >= 50:
            result['raw_wait_status'] = int(fields[49])
            result['observed_exit_code'] = os.waitstatus_to_exitcode(int(fields[49]))
        return result
    except (OSError, ValueError, IndexError):
        return None

def snapshot(root_pid):
    all_processes = {}
    for entry in Path('/proc').iterdir():
        if entry.name.isdigit():
            item = read_process(int(entry.name))
            if item is not None:
                all_processes[item['pid']] = item
    owned = {root_pid} if root_pid in all_processes else set()
    owned.update(pid for pid, start in known.items()
                 if pid in all_processes and all_processes[pid]['start_ticks'] == start)
    changed = True
    while changed:
        additions = {pid for pid, item in all_processes.items()
                     if item['ppid'] in owned and pid not in owned}
        changed = bool(additions)
        owned.update(additions)
    result = {pid: all_processes[pid] for pid in owned}
    for pid, item in result.items():
        known[pid] = item['start_ticks']
    return result

def terminate_owned(proc):
    tree = snapshot(proc.pid)
    for pid in sorted(tree, reverse=True):
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass
    remaining = snapshot(proc.pid)
    for pid in sorted(remaining, reverse=True):
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    if proc.poll() is None:
        proc.wait()
    emit('cleanup_after_interrupt_or_timeout', term_pids=sorted(tree), kill_pids=sorted(remaining))

emit('start', command=command, cwd=str(Path(args.cwd).resolve()),
     interval_s=args.interval, timeout_s=args.timeout, host=host_memory(),
     note='Grandchild disappearance alone does not establish its exit code or cause.')
proc = subprocess.Popen(command, cwd=args.cwd, start_new_session=True)
timed_out = False
interrupted = False
last_sample_time = started
try:
    while True:
        now = time.monotonic()
        current = snapshot(proc.pid)
        for pid, old in previous.items():
            if pid not in current:
                emit('process_disappeared', pid=pid, name=old['name'], role=old['role'],
                     last_state=old['state'], last_cpu_seconds=old['cpu_seconds'],
                     last_peak_rss_kib=old['peak_rss_kib'])
        for pid, item in current.items():
            old = previous.get(pid)
            if old is not None and old['start_ticks'] == item['start_ticks']:
                delta = max(now-last_sample_time, 0.001)
                item['cpu_percent_since_previous_sample'] = round(
                    100*(item['cpu_seconds']-old['cpu_seconds'])/delta, 1)
        emit('sample', processes=sorted(current.values(), key=lambda p:p['pid']),
             subtree_rss_kib=sum(p['rss_kib'] for p in current.values()),
             host=host_memory())
        previous = current
        last_sample_time = now
        if proc.poll() is not None:
            break
        if args.timeout is not None and now-started >= args.timeout:
            timed_out = True
            emit('timeout', timeout_s=args.timeout)
            terminate_owned(proc)
            break
        time.sleep(args.interval)
except KeyboardInterrupt:
    interrupted = True
    terminate_owned(proc)
finally:
    if proc.poll() is None:
        terminate_owned(proc)
    raw_exit = proc.returncode
    wrapper_exit = 124 if timed_out else 130 if interrupted else raw_exit if raw_exit >= 0 else 128-raw_exit
    emit('exit', child_exit_code=raw_exit, wrapper_exit_code=wrapper_exit,
         timed_out=timed_out, interrupted=interrupted, host=host_memory(),
         remaining_known_descendants=list(snapshot(proc.pid).values()))
    log.close()
sys.exit(wrapper_exit)
