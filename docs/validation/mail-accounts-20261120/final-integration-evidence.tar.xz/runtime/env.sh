export FLUTTER_ROOT="/home/agent/.codex/skills/remote-skills/.quds-mail-9cfead7d593b/mail-runtime/flutter"
export PUB_CACHE="/home/agent/.codex/skills/remote-skills/.quds-mail-9cfead7d593b/mail-runtime/pub-cache"
export TMPDIR="/home/agent/.codex/skills/remote-skills/.quds-mail-9cfead7d593b/mail-runtime/tmp"
export XDG_CONFIG_HOME="/home/agent/.codex/skills/remote-skills/.quds-mail-9cfead7d593b/mail-runtime/config"
export FLUTTER_SUPPRESS_ANALYTICS=true
export DART_SUPPRESS_ANALYTICS=true
export CI=true
export PATH="/home/agent/.codex/skills/remote-skills/.quds-mail-9cfead7d593b/mail-runtime/bin:/home/agent/.codex/skills/remote-skills/.quds-mail-9cfead7d593b/mail-runtime/flutter/bin:/home/agent/.codex/skills/remote-skills/.quds-mail-9cfead7d593b/mail-runtime/flutter/bin/cache/dart-sdk/bin:$PATH"
