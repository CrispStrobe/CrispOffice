#!/usr/bin/env python3
"""Strictly analyze every Dart path in the final delta against captured main."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
RUNTIME = HERE.parent
ROOT = RUNTIME.parent / 'quds_office_suite'
OUTPUT = HERE / 'static-c20b41d9'
OUTPUT.mkdir()
SOURCE = 'c20b41d9c7eed574c02e49f1fd96789843aec2e6'
MAIN = '13be50464d1b43e9f2100fb9ccc12f8fe22eb55e'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def write(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2) + '\n')


files = [name for name in git('diff', '--name-only', MAIN, SOURCE).splitlines()
         if name.endswith('.dart')]
old_groups = json.loads((RUNTIME / 'validation/static-625f4d76/summary.json').read_text())['groups']
assert set(files) == {name for group in old_groups for name in group['files']}
assert git('rev-parse', 'HEAD') == SOURCE
assert git('status', '--porcelain') == ''


def inputs():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in files}


before = inputs()
write('inputs-before.json', {'head': SOURCE, 'files': before})
format_command = ['dart', 'format', '--output=none', '--set-exit-if-changed', *files]
with (OUTPUT / 'format.log').open('x') as output:
    format_result = subprocess.run(format_command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
groups = []
for group in old_groups:
    command = ['dart', 'analyze', '--fatal-infos',
               '--cache=' + str(RUNTIME / 'analysis-cache/static-c20b41d9'),
               '--format=json', '--memory', *group['files']]
    monitored = [sys.executable, str(RUNTIME / 'monitor_process.py'),
                 '--log', str(OUTPUT / (group['name'] + '-resources.jsonl')),
                 '--timeout', '240', '--cwd', str(ROOT), '--', *command]
    with (OUTPUT / (group['name'] + '.log')).open('x') as output:
        result = subprocess.run(monitored, stdout=output, stderr=subprocess.STDOUT)
    item = {'name': group['name'], 'command': command, 'files': group['files'],
            'exit_code': result.returncode}
    write(group['name'] + '-exit.json', item)
    groups.append(item)
    print(json.dumps({'static_group': group['name'], 'exit_code': result.returncode}), flush=True)
    if result.returncode:
        break
after = inputs()
write('inputs-after.json', {'files': after})
head_after = git('rev-parse', 'HEAD')
changed = [name for name in files if before[name] != after[name]]
passed = (format_result.returncode == 0 and len(groups) == 3
          and all(group['exit_code'] == 0 for group in groups)
          and not changed and head_after == SOURCE and git('status', '--porcelain') == '')
summary = {'head_before': SOURCE, 'head_after': head_after, 'files': len(files),
           'base_main': MAIN, 'format_command': format_command,
           'format_exit_code': format_result.returncode, 'groups': groups,
           'changed_inputs': changed, 'passed': passed}
write('summary.json', summary)
print(json.dumps({'static_passed': passed, 'files': len(files)}), flush=True)
sys.exit(0 if passed else 1)
