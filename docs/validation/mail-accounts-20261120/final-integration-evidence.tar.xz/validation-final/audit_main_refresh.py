#!/usr/bin/env python3
"""Read-only fixed-Git-source audit; no Dart/Flutter/test or remote invocation."""
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import posixpath
import re
import subprocess
import tarfile

TASK = Path(__file__).resolve().parents[2]
REPO = TASK / 'quds_office_suite'
OUT = Path(__file__).resolve().parent
OLD = '625f4d76d10ddf2144220f25ae8d867452eeed61'
OURS = 'e1fd2e14cf49f70532a7243e3e64330ac4ad80a6'
BASE = 'b42eca1db058f0def247b86c2f15dea90c11b4e8'
INCOMING = '13be50464d1b43e9f2100fb9ccc12f8fe22eb55e'
QUALIFIED = 'ce9ff1c8b155c03a0e2707d6fc8b41b52e611a93'
MERGED = 'c20b41d9c7eed574c02e49f1fd96789843aec2e6'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=REPO, env=ENV)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def tree(commit):
    answer = {}
    for row in git('ls-tree', '-rz', commit).split(b'\0'):
        if not row:
            continue
        meta, path = row.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        answer[os.fsdecode(path)] = dict(mode=mode, type=kind, oid=oid)
    return answer

TREES = {s: tree(s) for s in (OLD, OURS, BASE, INCOMING, QUALIFIED, MERGED)}
BATCH = subprocess.Popen(['git', '--no-optional-locks', 'cat-file', '--batch'], cwd=REPO,
                         env=ENV, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
CACHE = {}

def blob(commit, path):
    oid = TREES[commit][path]['oid']
    if oid not in CACHE:
        BATCH.stdin.write((oid + '\n').encode())
        BATCH.stdin.flush()
        header = BATCH.stdout.readline().decode().strip().split()
        if len(header) != 3 or header[:2] != [oid, 'blob']:
            raise RuntimeError('Unavailable fixed blob: ' + oid)
        data = BATCH.stdout.read(int(header[2]))
        if BATCH.stdout.read(1) != b'\n':
            raise RuntimeError('Malformed blob boundary')
        CACHE[oid] = data
    return CACHE[oid]

def changed(a, b):
    return sorted(p for p in set(TREES[a]) | set(TREES[b])
                  if TREES[a].get(p) != TREES[b].get(p))

def describe(commit, path):
    if path not in TREES[commit]:
        return None
    return {**TREES[commit][path], 'sha256': sha(blob(commit, path))}

def known_manifest(path):
    return (path.endswith('/pubspec.yaml') or path.endswith('/pubspec.lock')
            or path in ('pubspec.yaml', 'pubspec.lock', '.fvmrc')
            or path.endswith('/analysis_options.yaml') or path == 'analysis_options.yaml')

package_config_path = REPO / '.dart_tool/package_config.json'
package_config = json.loads(package_config_path.read_bytes())
package_roots = {}
for package in package_config['packages']:
    uri = package['rootUri']
    if uri.startswith('file:'):
        from urllib.parse import unquote, urlparse
        root = Path(unquote(urlparse(uri).path))
    else:
        root = (package_config_path.parent / uri).resolve()
    if root.is_relative_to(REPO.resolve()):
        package_roots[package['name']] = str((root / package.get('packageUri', '')).relative_to(REPO))

# A directive must be followed immediately by a string; ordinary variable
# assignments such as `part = switch ...` are not Dart import directives.
DIRECTIVE = re.compile(r'^\s*(?:import|export|part)\s+(?=[\"\'])([^;]*);', re.M)
QUOTED = re.compile(r'[\"\']([^\"\']+)[\"\']')
IMPORT_CACHE = {}

def edges(commit, path):
    key = (commit, path)
    if key in IMPORT_CACHE:
        return IMPORT_CACHE[key]
    local, missing = [], []
    text = blob(commit, path).decode('utf-8')
    for statement in DIRECTIVE.findall(text):
        for uri in QUOTED.findall(statement):
            if uri.startswith('dart:'):
                continue
            if uri.startswith('package:'):
                package, sep, suffix = uri[8:].partition('/')
                if not sep or package not in package_roots:
                    continue
                target = posixpath.normpath(posixpath.join(package_roots[package], suffix))
            elif ':' in uri:
                continue
            else:
                target = posixpath.normpath(posixpath.join(posixpath.dirname(path), uri))
            if target in TREES[commit] and target.endswith('.dart'):
                local.append(target)
            else:
                missing.append(dict(source=path, uri=uri, target=target))
    IMPORT_CACHE[key] = (sorted(set(local)), missing)
    return IMPORT_CACHE[key]

def closure(commit, target):
    seen, missing, queue = set(), [], [target]
    while queue:
        path = queue.pop()
        if path in seen:
            continue
        if path not in TREES[commit]:
            missing.append(dict(source=None, uri=path, target=path))
            continue
        seen.add(path)
        links, failures = edges(commit, path)
        queue.extend(p for p in links if p not in seen)
        missing.extend(failures)
    return sorted(seen), missing

old_plan = json.loads((OUT.parent / 'validation/replay-plan.json').read_bytes())
own_targets = old_plan['expected_static_targets']
incoming_paths = changed(BASE, INCOMING)
incoming_dart = {p for p in incoming_paths if p.endswith('.dart')}
remaining_paths = changed(INCOMING, MERGED)
remaining_dart = [p for p in remaining_paths if p.endswith('.dart')]
native = 'packages/quds_office_editor/example/lib/studio_mail_native.dart'

static_closure = []
for path in own_targets:
    paths, missing = closure(MERGED, path)
    old_paths, old_missing = closure(OLD, path)
    differences = [p for p in sorted(set(paths) | set(old_paths))
                   if TREES[OLD].get(p) != TREES[MERGED].get(p)]
    static_closure.append(dict(target=path, local_dart_files=len(paths),
                               changed_local_inputs_since_625=differences,
                               incoming_delta_reachable=sorted(set(paths) & incoming_dart),
                               unresolved_local_directives=missing,
                               previous_unresolved_local_directives=old_missing))

studio = 'packages/quds_office_editor/example/test/'
selected = [studio + n + '_test.dart' for n in (
    'studio_mail_outbox_store', 'studio_mail_outbox_submission',
    'studio_mail_outbox_dialog', 'studio_mail_outbox_host',
    'studio_mail_outbox_cloud', 'studio_mail_draft_autosave',
    'studio_mail_draft_store', 'studio_mail_session',
    'studio_mail_compose', 'studio_mail_credential_backend_switch')]
selected += ['packages/quds_mail_core/test/outbox_test.dart',
             'packages/quds_mail_store/test/codec_test.dart',
             'packages/quds_mail_store/test/outbox_draft_transfer_test.dart',
             'packages/quds_mail_store/test/draft_editor_state_test.dart']
selected += ['packages/quds_office_engine/test/' + n + '_test.dart' for n in (
    'word_incremental_layout', 'word_incremental_layout_prefix',
    'word_incremental_layout_differential')]
fresh_closures, union = [], set()
for path in selected:
    paths, missing = closure(MERGED, path)
    union.update(paths)
    fresh_closures.append(dict(target=path, local_dart_files=len(paths),
        own_delta_reachable=sorted(set(paths) & set(remaining_dart)),
        incoming_delta_reachable=sorted(set(paths) & incoming_dart),
        unresolved_local_directives=missing))

old_suite_closure = []
for cohort in old_plan['cohorts']:
    if not cohort['expected_acceptance']:
        continue
    historical_summary = json.loads((OUT.parent / 'validation' / cohort['name'] / 'summary.json').read_bytes())
    for path in cohort['selected_tests']:
        if not path.startswith('/'):
            path = posixpath.normpath(posixpath.join(historical_summary['cwd'], path))
        path = str(Path(path).relative_to(historical_summary['repository_root']))
        paths, missing = closure(MERGED, path)
        old_paths, old_missing = closure(OLD, path)
        differences = [p for p in sorted(set(paths) | set(old_paths))
                       if TREES[OLD].get(p) != TREES[MERGED].get(p)]
        old_suite_closure.append(dict(target=path, cohort=cohort['name'],
            local_dart_files=len(paths), changed_local_inputs_since_625=differences,
            unchanged_static_local_source_closure=not differences,
            unresolved_local_directives=missing,
            previous_unresolved_local_directives=old_missing))

receipt_base = 'docs/validation/mail-outbox-20261120/'
acceptance_raw = blob(INCOMING, receipt_base + 'acceptance.json')
acceptance = json.loads(acceptance_raw)
archive_manifest = json.loads(blob(INCOMING, receipt_base + 'evidence-manifest.json'))
archive_description = archive_manifest['archives'][0]
archive_raw = blob(INCOMING, receipt_base + archive_description['path'])
archive = tarfile.open(fileobj=io.BytesIO(archive_raw), mode='r:gz')
members = {member.name: archive.extractfile(member).read() for member in archive
           if member.isfile()}
archive_failures = []
if len(archive_raw) != archive_description['bytes'] or sha(archive_raw) != archive_description['sha256']:
    archive_failures.append('archive')
for record in archive_description['members']:
    raw = members.get(record['path'])
    if raw is None or len(raw) != record['bytes'] or sha(raw) != record['sha256']:
        archive_failures.append(record['path'])
if set(members) != {record['path'] for record in archive_description['members']}:
    archive_failures.append('member_inventory')

source_receipts = []
for folder in ('final-dart', 'final-studio'):
    before = json.loads(members[folder + '/before-manifest.json'])
    after = json.loads(members[folder + '/after-manifest.json'])
    mismatches, incoming_differences, merged_differences = [], [], []
    for record in before['source']:
        path = record['path']
        if path not in TREES[QUALIFIED] or sha(blob(QUALIFIED, path)) != record['sha256']:
            mismatches.append(path)
        if TREES[QUALIFIED].get(path) != TREES[INCOMING].get(path):
            incoming_differences.append(path)
        if TREES[INCOMING].get(path) != TREES[MERGED].get(path):
            merged_differences.append(path)
    source_receipts.append(dict(cohort_group=folder, source_count=len(before['source']),
        source_before_after_identical=before['source'] == after['source'],
        selected_runtime_before_after_identical=before['runtime'] == after['runtime'],
        qualified_checkpoint_sha256_mismatches=mismatches,
        incoming_main_differences_since_qualification=incoming_differences,
        merged_differences_from_incoming=merged_differences,
        before_manifest_sha256=sha(members[folder + '/before-manifest.json']),
        after_manifest_sha256=sha(members[folder + '/after-manifest.json'])))

protected_incoming = [p for p in incoming_paths
                      if not p.startswith('docs/') and not p.endswith('/CHANGELOG.md')
                      and p != native]
protected_mismatches = [p for p in protected_incoming
                        if TREES[INCOMING].get(p) != TREES[MERGED].get(p)]
own_preserved = [p for p in own_targets if p != native]
own_mismatches = [p for p in own_preserved
                  if TREES[OURS].get(p) != TREES[MERGED].get(p)]
manifests = sorted(p for p in set(TREES[OLD]) | set(TREES[MERGED]) if known_manifest(p))
manifest_differences = [p for p in manifests if TREES[OLD].get(p) != TREES[MERGED].get(p)]
dependency_current_mismatches = [p for p in manifests if p in TREES[MERGED]
    and (not (REPO / p).is_file() or sha((REPO / p).read_bytes()) != sha(blob(MERGED, p)))]
own_product = [p for p in remaining_dart if '/test/' not in p]
new_products = [p for p in incoming_dart if '/test/' not in p]

result = dict(
    schema='quds-mail-fixed-main-integration-review-v1',
    captured_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    repository='CrispStrobe/quds_office_suite',
    incoming_pr=250,
    fixed_sources=dict(previous_qualified=OLD, prior_publication=OURS,
                       previous_main=BASE, incoming_qualified=QUALIFIED,
                       incoming_main=INCOMING, merged_checkpoint=MERGED,
                       merged_tree=git('rev-parse', MERGED + '^{tree}').decode().strip(),
                       merged_parents=git('show', '-s', '--format=%P', MERGED).decode().strip().split()),
    source_preservation=dict(incoming_changed_paths=len(incoming_paths),
        incoming_changed_dart_paths=len(incoming_dart),
        remaining_dart_delta_vs_new_main=remaining_dart,
        remaining_dart_delta_matches_previous19=sorted(own_targets) == remaining_dart,
        incoming_implementation_test_checker_paths_preserved=protected_incoming,
        incoming_preservation_mismatches=protected_mismatches,
        retained_own18_non_native_paths=own_preserved,
        retained_own_path_mismatches=own_mismatches,
        dependency_manifest_count=len(manifests),
        dependency_changes_since625=manifest_differences,
        current_dependency_file_mismatches=dependency_current_mismatches,
        merged_native=dict(ours=describe(OURS, native), incoming=describe(INCOMING, native),
                           merged=describe(MERGED, native))),
    incoming_receipts=dict(
        acceptance_path=receipt_base + 'acceptance.json',
        acceptance_sha256=sha(acceptance_raw),
        qualified_commit=acceptance['source_checkpoint'],
        qualified_tree=acceptance['source_tree'],
        claimed_source_specific_cases=acceptance['combined_distinct_cases'],
        claimed_source_specific_suites=acceptance['combined_distinct_suite_files'],
        cohorts=acceptance['cohorts'],
        archive=dict(path=archive_description['path'], sha256=sha(archive_raw),
                     bytes=len(archive_raw), members=len(members), verification_errors=archive_failures),
        source_manifests=source_receipts,
        reviewer_raw_event_replay_performed=False,
        reason='Parent requested focused fresh requalification; no optional 874-case replay.',
        accepted_new_merged_source_cases_from_this_receipt=0,
        upstream_correction='Original Studio summary and driver exit1 are retained; separate unchanged-byte LF-framing audit reports610 complete cases. This source audit does not replace that raw-event audit.'),
    static_import_closure=dict(
        method='Literal import/export/part directives, including conditional URI alternatives, resolved through current configured repository-local package roots. Git blobs are read at fixed commits. This is a conservative static source closure, not a dynamic/runtime/assets completeness claim.',
        package_config_sha256=sha(package_config_path.read_bytes()),
        repository_package_roots=package_roots,
        targets=static_closure,
        historical_accepted_test_targets=old_suite_closure,
        fresh_selected_test_targets=fresh_closures,
        fresh_test_union_local_dart_files=len(union),
        own_product_deltas_outside_fresh_test_import_closure=sorted(set(own_product) - union),
        incoming_product_deltas_outside_fresh_test_import_closure=sorted(set(new_products) - union)),
    qualification_recommendation=dict(
        fresh_cohort_scope=selected,
        fresh_test_files=len(selected),
        strict_analysis_targets=remaining_dart,
        fresh_counts='Pending parent-run raw machine events; do not infer passes from source declarations.',
        old699_disposition='Preserve unchanged, qualified only at625. No automatic reassignment or addition to fresh totals.',
        incoming874_disposition='Upstream exact-source receipts remain ce9-specific. No automatic addition to fresh merged counts.',
        preservation_focus=['Combined native account/backend ownership plus new foreground Outbox lifecycle',
                            'Same-account durable draft revision transfer, explicit retry and uncertain-send persistence',
                            'Unmodified incoming Word frame-cache repair with its3 focused suites'],
        limits=['No live providers or installed platform qualification.',
                'Import closure alone does not attest runtime libraries, assets or subprocess fixtures.',
                'Unselected historical suites remain historical even if their static local source closure is unchanged.']),
    bounded_scope='Fixed commits named above only; no moving branch/PR polling, remote reads, CI endpoints, product edits, Git mutations, compilers or tests.',
)
BATCH.stdin.close()
if BATCH.wait(timeout=30):
    raise RuntimeError('Git object reader failed')
OUT.mkdir(parents=True, exist_ok=True)
target = OUT / 'main-refresh-review.json'
target.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(dict(output=str(target), sha256=sha(target.read_bytes()),
    incoming_paths=len(incoming_paths), remaining_dart=len(remaining_dart),
    own18_preserved=not own_mismatches, incoming_preserved=not protected_mismatches,
    manifest_differences=manifest_differences, archive_errors=archive_failures,
    static_targets_changed_closure=sum(bool(r['changed_local_inputs_since_625']) for r in static_closure),
    static_targets_unchanged_closure=[r['target'] for r in static_closure if not r['changed_local_inputs_since_625']],
    fresh_test_files=len(selected), incoming_product_gaps=sorted(set(new_products) - union),
    own_product_gaps=sorted(set(own_product) - union)), indent=2))
