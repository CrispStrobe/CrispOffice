#!/usr/bin/env python3
"""Run the selected post-Outbox integration boundaries serially."""
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
RUNTIME = HERE.parent
ROOT = RUNTIME.parent / 'quds_office_suite'
SOURCE = 'c20b41d9c7eed574c02e49f1fd96789843aec2e6'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
for item in json.loads((HERE / 'cohort-plan.json').read_text()):
    command = [sys.executable, str(HERE / item['runner']), item['name']]
    if item['runner'] == 'run_mail_gate.py':
        command += ['--package', item['package'], '--tool', item['tool']]
        if item['tool'] == 'flutter':
            command += ['--no-track-widget-creation']
    command += item['tests']
    monitor = [sys.executable, str(RUNTIME / 'monitor_process.py'),
               '--log', str(HERE / 'monitors' / (item['name'] + '.jsonl')),
               '--timeout', '660', '--cwd', str(ROOT), '--', *command]
    print('START ' + item['name'], flush=True)
    with (HERE / (item['name'] + '-driver.log')).open('x') as output:
        result = subprocess.run(monitor, stdout=output, stderr=subprocess.STDOUT)
    summary = json.loads((HERE / item['name'] / 'summary.json').read_text())
    print(json.dumps({key: summary.get(key) for key in
                     ['name', 'gate_passed', 'substantive', 'process_exit_code',
                      'wrapper_exit_code', 'inputs_unchanged', 'head_unchanged']}), flush=True)
    if result.returncode != 0 or not summary['gate_passed']:
        sys.exit(1)
print('ALL SELECTED COHORTS PASSED', flush=True)
