#!/usr/bin/env python3
"""Run an explicit engine cohort once, preserving raw and source-bound evidence.

Source mail-runtime/env.sh first. Set QUDS_OFFICE_ROOT to replay against another
checkout. Output is validation/NAME; an existing NAME is refused. Tests may be
engine-relative, repository-relative, or absolute paths. This runner does not
resolve packages, delete caches, or modify product sources.
"""

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import signal
import subprocess
import sys
from urllib.parse import unquote, urljoin, urlparse


DEFAULT_ROOT = Path(__file__).resolve().parents[2] / 'quds_office_suite'
ROOT = Path(os.environ.get('QUDS_OFFICE_ROOT', DEFAULT_ROOT)).expanduser().resolve()
ENGINE = ROOT / 'packages/quds_office_engine'
PACKAGE_CONFIG = ROOT / '.dart_tool/package_config.json'
VALIDATION = Path(__file__).resolve().parent
DIRECTIVE = re.compile(r'^\s*(?:import|export|part)\s+(?!of\b)([^;]*);', re.M)
QUOTED = re.compile(r'''["']([^"']+)["']''')


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def head():
    return subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True
    ).strip()


def package_roots():
    configuration = json.loads(PACKAGE_CONFIG.read_text())
    roots = {}
    for package in configuration['packages']:
        uri = urlparse(urljoin(PACKAGE_CONFIG.as_uri(), package['rootUri']))
        if uri.scheme == 'file' and not uri.netloc:
            roots[package['name']] = Path(unquote(uri.path)).resolve()
    return roots


def resolve_test(value):
    path = Path(value)
    if path.is_absolute():
        candidate = path
    elif path.parts[:3] == ('packages', 'quds_office_engine', 'test'):
        candidate = ROOT / path
    elif path.parts and path.parts[0] == 'test':
        candidate = ENGINE / path
    else:
        candidate = ENGINE / 'test' / path
    candidate = candidate.resolve()
    if (not candidate.is_relative_to(ENGINE / 'test')
            or not candidate.name.endswith('_test.dart')
            or not candidate.is_file()):
        raise ValueError(f'Expected an existing explicit engine test: {value}')
    return candidate


def include_local_dart_support(paths, roots):
    pending = [path for path in paths if path.suffix == '.dart']
    visited = set()
    while pending:
        source = pending.pop()
        if source in visited or not source.is_file():
            continue
        visited.add(source)
        for directive in DIRECTIVE.finditer(source.read_text()):
            for uri in QUOTED.findall(directive.group(1)):
                if uri.startswith('dart:'):
                    continue
                if uri.startswith('package:'):
                    package, _, relative = uri[8:].partition('/')
                    base = roots.get(package)
                    if base is None or not base.is_relative_to(ROOT):
                        continue
                    dependency = (base / 'lib' / relative).resolve()
                elif ':' not in uri:
                    dependency = (source.parent / uri).resolve()
                else:
                    continue
                if dependency.is_relative_to(ROOT) and dependency not in paths:
                    paths.add(dependency)
                    if dependency.suffix == '.dart':
                        pending.append(dependency)
    return paths


def input_paths(selected, roots):
    paths = set(selected)
    for area in (ENGINE / 'lib', ROOT / 'packages/legacy_doc_parser/lib'):
        paths.update(path for path in area.rglob('*') if path.is_file())
    paths.update(
        path for path in (ENGINE / 'test').rglob('*')
        if path.is_file() and not path.name.endswith('_test.dart')
    )
    local_roots = {ROOT, ENGINE, ROOT / 'packages/legacy_doc_parser'}
    local_roots.update(path for path in roots.values() if path.is_relative_to(ROOT))
    for package in local_roots:
        for relative in ('pubspec.yaml', 'pubspec.lock', '.dart_tool/package_config.json'):
            paths.add(package / relative)
    for base in (ROOT, ENGINE):
        paths.update(base / name for name in ('dart_test.yaml', 'pubspec_overrides.yaml'))
    return include_local_dart_support(paths, roots)


def snapshot(selected, roots, previous=()):
    paths = input_paths(selected, roots) | {ROOT / name for name in previous}
    return {
        str(path.relative_to(ROOT)): sha(path) if path.is_file() else None
        for path in sorted(paths)
    }


def tally(cases):
    return {
        'total': len(cases),
        'passed': sum(case['result'] == 'success' and not case['skipped'] for case in cases),
        'failed': sum(case['result'] != 'success' and not case['skipped'] for case in cases),
        'skipped': sum(case['skipped'] for case in cases),
    }


def parse_events(path):
    starts, completions, suites = {}, {}, {}
    event_counts = Counter()
    errors, invalid_lines, duplicate_completions, finals, prints = [], [], [], [], []
    with path.open(encoding='utf-8', errors='replace') as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                invalid_lines.append(line_number)
                continue
            if not isinstance(event, dict) or not isinstance(event.get('type'), str):
                invalid_lines.append(line_number)
                continue
            kind = event['type']
            event_counts[kind] += 1
            if kind == 'suite':
                suites[event['suite']['id']] = event['suite']['path']
            elif kind == 'testStart':
                starts[event['test']['id']] = event['test']
            elif kind == 'testDone':
                identifier = event['testID']
                if identifier in completions:
                    duplicate_completions.append(identifier)
                completions[identifier] = event
            elif kind == 'error':
                errors.append(event)
            elif kind == 'done':
                finals.append(event)
            elif kind == 'print':
                prints.append(event)
    cases, loading, other_hidden = [], [], []
    for identifier, event in completions.items():
        test = starts.get(identifier, {})
        is_loading = (str(test.get('name', '')).startswith('loading ')
                      and not test.get('groupIDs') and test.get('line') is None)
        case = {
            'id': identifier, 'name': test.get('name'),
            'suite': suites.get(test.get('suiteID')),
            'result': event.get('result'), 'skipped': event.get('skipped', False),
            'hidden': event.get('hidden', False), 'loading': is_loading,
            'metadata': test.get('metadata', {}),
        }
        (loading if is_loading else other_hidden if case['hidden'] else cases).append(case)
    all_cases = cases + loading + other_hidden
    per_suite = {}
    for suite in suites.values():
        per_suite[suite] = tally([case for case in cases if case['suite'] == suite])
    registered_corpus = [
        {
            'id': identifier, 'name': test.get('name'),
            'suite': suites.get(test.get('suiteID')),
            'metadata': test.get('metadata', {}),
            'completion': completions.get(identifier),
            'output_events': [event for event in prints if event.get('testID') == identifier],
        }
        for identifier, test in starts.items()
        if str(suites.get(test.get('suiteID'), '')).endswith(
            'word_incremental_layout_equivalence_test.dart')
        and re.search(r'(?:^|\s)fixture ', str(test.get('name', '')))
    ]
    return {
        **tally(cases), 'substantive': tally(cases),
        'loading': tally(loading), 'other_hidden': tally(other_hidden),
        'hidden': tally([case for case in all_cases if case['hidden']]),
        'all_completions': tally(all_cases), 'cases': cases,
        'loading_cases': loading, 'other_hidden_cases': other_hidden,
        'suites': per_suite, 'event_counts': dict(event_counts), 'errors': errors,
        'print_events': prints,
        'skip_events': [event for event in prints if event.get('messageType') == 'skip'],
        'skipped_cases': [case for case in all_cases if case['skipped']],
        'model_error_events': [event for event in prints
                               if 'EQUIVALENCE_MODEL_ERROR' in str(event.get('message', ''))],
        'registered_corpus': registered_corpus,
        'registered_corpus_count': len(registered_corpus),
        'invalid_jsonl_lines': invalid_lines,
        'duplicate_completions': duplicate_completions,
        'unfinished_tests': sorted(starts.keys() - completions.keys()),
        'unmatched_completions': sorted(completions.keys() - starts.keys()),
        'final_done_count': len(finals), 'final_event': finals[-1] if finals else None,
    }


def stop_process(process):
    if process.poll() is None:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    try:
        return process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        return process.wait()


def run_gate(name, selected, cwd, command, roots, take_snapshot, scope,
             runner_files, timeout, extra=None, inventory=None):
    output = VALIDATION / name
    output.mkdir(exist_ok=False)
    inventory_before = inventory() if inventory is not None else None
    if inventory_before is not None:
        write_json(output / 'fixture-inventory-before.json', inventory_before)
    before = take_snapshot(selected, roots)
    write_json(output / 'inputs-before.json', before)
    runner_before = {path.name: sha(path) for path in runner_files}
    record = {
        'name': name, 'started_at_utc': timestamp(), 'repository_root': str(ROOT),
        'command': command, 'command_shell': shlex.join(command), 'cwd': str(cwd),
        'head_before': head(),
        'selected_tests': [str(path.relative_to(cwd)) for path in selected],
        'timeout_seconds': timeout, 'free_bytes_before': shutil.disk_usage(ROOT).free,
        'input_files': sum(value is not None for value in before.values()),
        'input_keys': len(before), 'runner_sources_before': runner_before, 'scope': scope,
        'fixture_inventory_before': inventory_before,
    }
    if extra:
        record.update(extra)
    write_json(output / 'run-start.json', record)
    print(f'Starting {name}; {len(selected)} suites; {record["input_files"]} input files', flush=True)
    returncode, runner_error, timed_out = None, None, False
    process = None
    with (output / 'events.jsonl').open('xb') as stdout, (output / 'stderr.log').open('xb') as stderr:
        try:
            process = subprocess.Popen(command, cwd=cwd, stdout=stdout, stderr=stderr,
                                       start_new_session=True)
            returncode = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            runner_error = f'Cohort exceeded {timeout} seconds'
            returncode = stop_process(process)
        except KeyboardInterrupt:
            runner_error = 'Validation interrupted'
            if process is not None:
                returncode = stop_process(process)
        except OSError as error:
            runner_error = f'{type(error).__name__}: {error}'
            if process is not None:
                returncode = stop_process(process)
    # Preserve the real process status even if subsequent evidence collection
    # fails (for example, a full disk or a malformed package configuration).
    record.update(process_exit_code=returncode, exit_code=returncode,
                  runner_error=runner_error, timed_out=timed_out)
    write_json(output / 'process-exit.json', {
        'recorded_at_utc': timestamp(), 'process_exit_code': returncode,
        'runner_error': runner_error, 'timed_out': timed_out,
    })
    after_config_error = None
    try:
        after_roots = package_roots()
    except (ValueError, KeyError, OSError) as error:
        after_roots = roots
        after_config_error = f'{type(error).__name__}: {error}'
    inventory_after = inventory() if inventory is not None else None
    if inventory_after is not None:
        write_json(output / 'fixture-inventory-after.json', inventory_after)
    after = take_snapshot(selected, after_roots, before)
    write_json(output / 'inputs-after.json', after)
    parsed = parse_events(output / 'events.jsonl')
    changed = sorted(name for name in before.keys() | after.keys()
                     if before.get(name) != after.get(name))
    runner_after = {path.name: sha(path) if path.is_file() else None for path in runner_files}
    record.update(parsed)
    record.update(
        finished_at_utc=timestamp(), after_config_error=after_config_error,
        head_after=head(), inputs_unchanged=not changed, changed_inputs=changed,
        added_inputs=[name for name in changed if before.get(name) is None],
        removed_inputs=[name for name in changed if after.get(name) is None],
        runner_sources_after=runner_after, runners_unchanged=runner_before == runner_after,
        fixture_inventory_after=inventory_after,
        fixture_inventory_unchanged=inventory_before == inventory_after,
        fixture_inventory_complete=(inventory_before is None or
                                    inventory_before.get('complete', False)) and
                                   (inventory_after is None or
                                    inventory_after.get('complete', False)),
        free_bytes_after=shutil.disk_usage(ROOT).free,
        stdout_sha256=sha(output / 'events.jsonl'), stderr_sha256=sha(output / 'stderr.log'),
        inputs_before_sha256=sha(output / 'inputs-before.json'),
        inputs_after_sha256=sha(output / 'inputs-after.json'),
    )
    expected_corpus = (inventory_before or {}).get('registered_corpus_expected')
    record['corpus_registration_matches'] = (
        expected_corpus is None or parsed['registered_corpus_count'] == expected_corpus
    )
    record['head_unchanged'] = record['head_before'] == record['head_after']
    record['gate_passed'] = (
        returncode == 0 and runner_error is None and after_config_error is None
        and record['head_unchanged'] and record['inputs_unchanged'] and record['runners_unchanged']
        and record['fixture_inventory_unchanged'] and record['fixture_inventory_complete']
        and record['corpus_registration_matches']
        and parsed['final_done_count'] == 1 and parsed['final_event'].get('success') is True
        and parsed['passed'] > 0 and parsed['all_completions']['failed'] == 0
        and parsed['all_completions']['skipped'] == 0
        and len(parsed['suites']) == len(selected)
        and all(counts['passed'] > 0 for counts in parsed['suites'].values())
        and not any(parsed[key] for key in (
            'errors', 'model_error_events', 'invalid_jsonl_lines', 'duplicate_completions',
            'unfinished_tests', 'unmatched_completions'))
    )
    wrapper_exit = (returncode if returncode is not None and returncode > 0
                    else 128 - returncode if returncode is not None and returncode < 0
                    else 0 if record['gate_passed'] else 1)
    record['wrapper_exit_code'] = wrapper_exit
    write_json(output / 'summary.json', record)
    excluded = {'cases', 'loading_cases', 'other_hidden_cases', 'errors',
                'print_events', 'registered_corpus', 'fixture_inventory_before',
                'fixture_inventory_after'}
    print(json.dumps({key: value for key, value in record.items() if key not in excluded}, indent=2), flush=True)
    if parsed['errors']:
        print(json.dumps(parsed['errors'], indent=2)[-12000:], flush=True)
    stderr_text = (output / 'stderr.log').read_text(errors='replace')
    if stderr_text:
        print(stderr_text[-10000:], flush=True)
    return wrapper_exit


def validate_arguments(parser, args):
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', args.name):
        parser.error('name must be a single safe directory name')
    if args.timeout <= 0:
        parser.error('--timeout must be positive')
    if (VALIDATION / args.name).exists():
        parser.error('Existing evidence is preserved; choose a new name')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('name', help='New evidence directory name (never overwritten)')
    parser.add_argument('tests', nargs='+', help='Explicit engine *_test.dart paths')
    parser.add_argument('--timeout', type=int, default=600)
    args = parser.parse_args()
    validate_arguments(parser, args)
    try:
        selected = [resolve_test(value) for value in args.tests]
        if len(set(selected)) != len(selected):
            raise ValueError('Duplicate test paths are not allowed')
        roots = package_roots()
        test_runner = roots['test'] / 'bin/test.dart'
        if not test_runner.is_file():
            raise ValueError('The configured package:test runner is unavailable')
        dart = shutil.which('dart')
        if dart is None:
            raise ValueError('dart is unavailable; source mail-runtime/env.sh first')
    except (ValueError, KeyError, OSError) as error:
        parser.error(str(error))
    tests = [str(path.relative_to(ENGINE)) for path in selected]
    command = [dart, '--packages=' + str(PACKAGE_CONFIG), str(test_runner),
               '--concurrency=1', '--reporter=json', *tests]
    scope = ('All engine and legacy_doc_parser library files; selected engine '
             'tests; all materialized engine test helpers/fixtures and transitive '
             'local Dart support; workspace/local-package manifests, locks and '
             'package configurations; root/engine test configuration. '
             'A focused integration gate, not a whole-repository gate.')
    return run_gate(args.name, selected, ENGINE, command, roots, snapshot, scope,
                    [Path(__file__).resolve()], args.timeout,
                    {'test_runner': str(test_runner), 'test_runner_sha256': sha(test_runner)})


if __name__ == '__main__':
    sys.exit(main())
