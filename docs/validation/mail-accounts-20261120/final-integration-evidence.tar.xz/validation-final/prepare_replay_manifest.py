#!/usr/bin/env python3
"""Bind completed fresh receipts to fixed Git inputs without rerunning tests."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / 'quds_office_suite'
SOURCE = 'c20b41d9c7eed574c02e49f1fd96789843aec2e6'
MAIN = '13be50464d1b43e9f2100fb9ccc12f8fe22eb55e'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=REPO, env=ENV)

config = read(HERE / 'cohort-plan.json')
config = [dict(item) for item in config]
for item in config:
    if item['name'] == 'outbox-store-c20b41d9':
        item['expected_acceptance'] = False
if not any(item['name'] == 'outbox-store-native-c20b41d9' for item in config):
    config.append(dict(name='outbox-store-native-c20b41d9', runner='run_store_native_gate.py',
        package='packages/quds_mail_store', tool='dart', expected_acceptance=True,
        retry_of='outbox-store-c20b41d9',
        tests=['codec_test.dart', 'outbox_draft_transfer_test.dart', 'draft_editor_state_test.dart']))
static_name = 'static-c20b41d9'
static = read(HERE / static_name / 'summary.json')
all_inputs = {}
summaries = {}
receipts = {}
runner_hashes = {}
specs = []

def receipt(relative):
    receipts[relative] = digest((HERE / relative).read_bytes())

def capture_inputs(values):
    for path, value in values.items():
        all_inputs.setdefault(path, set()).add(value)

for item in config:
    name = item['name']
    summary = read(HERE / name / 'summary.json')
    summaries[name] = summary
    selected = ['test/' + t for t in item['tests']]
    if summary['selected_tests'] != selected:
        raise ValueError('Executed suite selection differs from frozen cohort plan: ' + name)
    for suffix in ('summary.json', 'run-start.json', 'process-exit.json', 'events.jsonl',
                   'stderr.log', 'inputs-before.json', 'inputs-after.json'):
        receipt(name + '/' + suffix)
    for suffix in ('inputs-before.json', 'inputs-after.json'):
        capture_inputs(read(HERE / name / suffix))
    for source_name, value in summary['runner_sources_before'].items():
        if source_name in runner_hashes and runner_hashes[source_name] != value:
            raise ValueError('Runner identity differs across cohorts: ' + source_name)
        if digest((HERE / source_name).read_bytes()) != value:
            raise ValueError('Retained runner does not match executed bytes: ' + source_name)
        runner_hashes[source_name] = value
    specs.append(dict(name=name, expected_acceptance=item.get('expected_acceptance', True), selected_tests=selected,
        recorded_repository_root=summary['repository_root'], recorded_cwd=summary['cwd']))

for suffix in ('summary.json', 'inputs-before.json', 'inputs-after.json', 'format.log'):
    receipt(static_name + '/' + suffix)
for group in static['groups']:
    for suffix in ('-exit.json', '.log'):
        receipt(static_name + '/' + group['name'] + suffix)
for suffix in ('inputs-before.json', 'inputs-after.json'):
    capture_inputs(read(HERE / static_name / suffix)['files'])
runner_hashes['run_static_delta.py'] = digest((HERE / 'run_static_delta.py').read_bytes())
receipt('cohort-plan.json')
receipt('main-refresh-review.json')
for path in ('native-assets-preparation.json', 'sqlite-generated-native-assets.json',
             'sqlite-workspace-native-assets.yaml'):
    receipt(path)

entries = {}
for row in git('ls-tree', '-rz', SOURCE).split(b'\0'):
    if row:
        meta, path = row.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        entries[os.fsdecode(path)] = dict(mode=mode, type=kind, oid=oid)
batch = subprocess.Popen(['git', '--no-optional-locks', 'cat-file', '--batch'],
                         cwd=REPO, env=ENV, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
blob_hashes = {}
tracked = {}
nonrepo = {}
retained = {}
external = {}
hash_only_runtime = {}
runtime = HERE / 'replay-runtime-sources'
runtime.mkdir(exist_ok=True)

for path, values in sorted(all_inputs.items()):
    entry = entries.get(path)
    if entry:
        oid = entry['oid']
        if oid not in blob_hashes:
            batch.stdin.write((oid + '\n').encode())
            batch.stdin.flush()
            header = batch.stdout.readline().decode().strip().split()
            if len(header) != 3 or header[:2] != [oid, 'blob']:
                raise ValueError('Missing qualified Git blob: ' + oid)
            data = batch.stdout.read(int(header[2]))
            if batch.stdout.read(1) != b'\n':
                raise ValueError('Malformed blob stream')
            blob_hashes[oid] = digest(data)
        value = blob_hashes[oid]
        if values != {value}:
            raise ValueError('Input differs from fixed source: ' + path)
        tracked[path] = {**entry, 'sha256': value}
    else:
        nonrepo[path] = sorted(values, key=lambda value: '' if value is None else value)
        actual_values = {value for value in values if value is not None}
        if actual_values:
            original = REPO / path
            if not original.resolve().is_relative_to(REPO.resolve()):
                raise ValueError('Generated input leaves repository: ' + path)
            data = original.read_bytes()
            value = digest(data)
            if actual_values != {value}:
                raise ValueError('Generated source changed: ' + path)
            if path.endswith('/libsqlite3.so'):
                hash_only_runtime[path] = dict(sha256=value, bytes=len(data),
                    verified_from_actual_runtime_bytes=True,
                    limitation='Native binary hash-bound by before/after snapshots and this read; binary bytes are not bundled.')
                continue
            relative = 'replay-runtime-sources/generated-input-' + value[:16] + original.suffix
            (HERE / relative).write_bytes(data)
            retained[path] = dict(retained_path=relative, sha256=value)
batch.stdin.close()
if batch.wait(timeout=30):
    raise ValueError('Git object reader failed')

for summary in summaries.values():
    original = summary.get('test_runner')
    if not original or original in external:
        continue
    data = Path(original).read_bytes()
    value = digest(data)
    if value != summary['test_runner_sha256']:
        raise ValueError('External test entrypoint changed: ' + original)
    relative = 'replay-runtime-sources/test-entrypoint-' + value[:16] + '.dart'
    (HERE / relative).write_bytes(data)
    external[original] = dict(retained_path=relative, sha256=value)

tree = git('rev-parse', SOURCE + '^{tree}').decode().strip()
bindings = dict(schema='quds-mail-portable-source-bindings/v1',
    captured_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    qualified_commit=SOURCE, qualified_tree=tree,
    method='Every tracked snapshot input is independently compared with the fixed Git blob SHA256; generated configuration and the package:test entrypoint are retained separately.',
    tracked_inputs=tracked, non_repository_input_values=nonrepo,
    retained_generated_inputs=retained, external_test_entrypoints=external,
    hash_only_runtime_inputs=hash_only_runtime)
binding_path = HERE / 'source-bindings-c20b41d9.json'
write(binding_path, bindings)
targets = sorted(read(HERE / static_name / 'inputs-before.json')['files'])
expected = sorted(p for p in git('diff', '--name-only', MAIN, SOURCE).decode().split('\n') if p.endswith('.dart'))
if targets != expected:
    raise ValueError('Static targets do not cover exact final Dart delta')
review = HERE / 'main-refresh-review.json'
plan = dict(schema='quds-mail-final-integration-replay-plan/v1',
    qualified_commit=SOURCE, qualified_tree=tree, incoming_main=MAIN,
    source_bindings_file=binding_path.name, source_bindings_sha256=digest(binding_path.read_bytes()),
    cohorts=specs, engine_cohorts=[item['name'] for item in config if item['runner'] == 'run_final_engine_gate.py'],
    static_gate=static_name, expected_static_targets=targets,
    receipt_sha256=receipts, runner_source_sha256=runner_hashes,
    canonical_source_review=dict(path=review.name, sha256=digest(review.read_bytes())),
    all_requested_final_cohorts_completed=True,
    native_runtime=dict(receipt='native-assets-preparation.json',
        cohort='outbox-store-native-c20b41d9',
        maps={'packages/quds_office_editor/example/build/native_assets/linux/native_assets.json':
              'sqlite-generated-native-assets.json',
              '.dart_tool/native_assets.yaml': 'sqlite-workspace-native-assets.yaml'},
        library='packages/quds_office_editor/example/build/native_assets/linux/libsqlite3.so'),
    retries=[dict(original=item['retry_of'], replacement=item['name'])
             for item in config if item.get('retry_of')],
    historical_exclusion=['625 qualification:699 cases remain source-specific and contribute zero here.',
                          'PR250 ce9 qualification:874 cases remain source-specific and contribute zero here.'],
    limitations=['Fresh scope is the17 selected integration suites plus strict analysis of19 Dart delta files.',
                 'No live provider, installed OS credential store, whole-repository, visual parity or performance qualification follows.',
                 'Conservative local import and explicit fixture snapshots do not claim a complete transitive runtime-file inventory.'])
write(HERE / 'replay-plan.json', plan)
print(json.dumps(dict(plan='replay-plan.json', qualified_commit=SOURCE,
    tracked_paths=len(tracked), unique_git_blobs=len(blob_hashes),
    non_repository_keys=len(nonrepo), retained_generated=len(retained),
    external_test_entrypoints=len(external), anchored_receipts=len(receipts),
    static_targets=len(targets), cohorts=len(specs)), indent=2))
