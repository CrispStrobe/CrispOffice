#!/usr/bin/env python3
"""Qualify unchanged store tests using the genuine generated SQLite asset map."""
import ctypes
import json
from pathlib import Path
import shutil
import sys

import run_final_engine_gate as gate
import run_mail_gate as mail


def main():
    if gate.head() != 'c20b41d9c7eed574c02e49f1fd96789843aec2e6':
        raise RuntimeError('Final source must remain frozen.')
    package = gate.ROOT / 'packages/quds_mail_store'
    generated = gate.ROOT / 'packages/quds_office_editor/example/build/native_assets/linux/native_assets.json'
    prepared = gate.ROOT / '.dart_tool/native_assets.yaml'
    mapping = json.loads(generated.read_text())
    kind, library_name = mapping['native-assets']['linux_x64']['package:sqlite3/src/ffi/libsqlite3.g.dart']
    library = Path(library_name)
    if kind != 'absolute' or not library.is_file():
        raise RuntimeError('The genuine generated SQLite asset is unavailable.')
    library_sha = gate.sha(library)
    if library_sha != '0a65852703763619a7a34633b4959b3b86c4103804a4dfe4e8b27b5de1c0647b':
        raise RuntimeError('SQLite asset differs from the observed and incoming qualification binary.')
    if (package / '.dart_tool/native_assets.yaml').exists():
        raise RuntimeError('Unexpected package-local native asset shadow map.')
    if prepared.exists() and prepared.read_bytes() != generated.read_bytes():
        raise RuntimeError('Refusing to replace a different workspace asset map.')
    shutil.copyfile(generated, prepared)
    shared_library = ctypes.CDLL(str(library))
    shared_library.sqlite3_libversion.restype = ctypes.c_char_p
    sqlite_version = shared_library.sqlite3_libversion().decode()
    runtime_inputs = [generated, prepared, library]
    receipt = {
        'source_commit': gate.head(), 'sqlite_version': sqlite_version,
        'reason': 'The original direct runner omitted the kernel compiler native-asset map. '
                  'Copy the actual Flutter-generated JSON map, a YAML subset, to the supported '
                  'workspace native_assets.yaml lookup location. No product, dependency, test '
                  'or assertion is changed and no system SQLite substitution is used.',
        'inputs': [{'repository_relative_path': str(path.relative_to(gate.ROOT)),
                    'sha256': gate.sha(path), 'bytes': path.stat().st_size}
                   for path in runtime_inputs],
        'rejected_predecessor': 'outbox-store-c20b41d9',
        'original_rejected_cases_contributed': 0,
    }
    gate.write_json(gate.VALIDATION / 'native-assets-preparation.json', receipt)
    for source, name in [(generated, 'sqlite-generated-native-assets.json'),
                         (prepared, 'sqlite-workspace-native-assets.yaml')]:
        shutil.copyfile(source, gate.VALIDATION / name)
    roots = gate.package_roots()
    tests = ['codec_test.dart', 'outbox_draft_transfer_test.dart', 'draft_editor_state_test.dart']
    selected = [package / 'test' / name for name in tests]
    runner = roots['test'] / 'bin/test.dart'
    command = [shutil.which('dart'), '--disable-dart-dev',
               '--packages=' + str(gate.PACKAGE_CONFIG), str(runner),
               '--compiler=kernel', '--concurrency=1', '--reporter=json',
               *('test/' + name for name in tests)]

    def snapshot(suites, package_roots, previous=()):
        result = mail.snapshot(suites, package_roots, package, previous)
        for path in runtime_inputs:
            result[str(path.relative_to(gate.ROOT))] = gate.sha(path) if path.is_file() else None
        return result

    return gate.run_gate(
        'outbox-store-native-c20b41d9', selected, package, command, roots,
        snapshot, 'Full existing Mail gate input scope, plus the generated asset map, '
        'its exact workspace copy and genuine bundled SQLite library before/after. '
        'The same 63 store cases and assertions as the rejected missing-asset attempt.',
        [Path(gate.__file__), Path(mail.__file__), Path(__file__)], 600,
        {'package': 'packages/quds_mail_store', 'tool': 'dart',
         'test_runner': str(runner), 'test_runner_sha256': gate.sha(runner),
         'native_runtime': receipt},
    )


if __name__ == '__main__':
    sys.exit(main())
