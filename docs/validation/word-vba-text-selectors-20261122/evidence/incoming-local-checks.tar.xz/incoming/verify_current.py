#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

repo = Path('/workspace/scratch/58a062e5b571/quds_office_suite')
out = Path('/workspace/scratch/58a062e5b571/verification/incoming')
qualification = json.loads((out / 'qualification.json').read_text())
results = []
for group in qualification['groups']:
    name = group['package'].replace('packages/', '').replace('/', '-')
    snapshot = json.loads((out / name / 'sources-after.json').read_text())
    changed = []
    for relative, expected in snapshot.items():
        path = repo / relative
        current = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        if current != expected:
            changed.append(relative)
    results.append({'package': group['package'], 'accepted_run': group['accepted'],
                    'passed': group['passed'], 'changed_inputs_since_run': changed,
                    'matches_current': not changed})
print(json.dumps({'groups': results, 'all_current': all(g['accepted_run'] and g['matches_current'] for g in results)}, indent=2))
