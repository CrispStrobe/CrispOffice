#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
import yaml

REPO = Path('/workspace/scratch/58a062e5b571/quds_office_suite')
RUNTIME = REPO.parent / 'runtime'
OUT = REPO.parent / 'verification/incoming'
selection = json.loads((OUT / 'selection.json').read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def sources(package):
    pending = [(REPO / package, True)]
    seen = set()
    paths = {'pubspec.yaml', 'pubspec.lock', '.fvmrc', 'analysis_options.yaml'}
    while pending:
        root, include_tests = pending.pop()
        if root in seen:
            continue
        seen.add(root)
        manifest = root / 'pubspec.yaml'
        data = yaml.safe_load(manifest.read_text())
        prefix = root.relative_to(REPO).as_posix()
        specs = [prefix + '/pubspec.yaml', prefix + '/lib', prefix + '/assets']
        if include_tests:
            specs += [prefix + '/test', prefix + '/dart_test.yaml', prefix + '/analysis_options.yaml']
        paths.update(git('ls-files', '--', *specs).splitlines())
        dependencies = dict(data.get('dependencies') or {})
        if include_tests:
            dependencies.update(data.get('dev_dependencies') or {})
        for dependency in dependencies.values():
            if isinstance(dependency, dict) and 'path' in dependency:
                resolved = (root / dependency['path']).resolve()
                if resolved.is_relative_to(REPO):
                    pending.append((resolved, False))
    return {p: digest(REPO / p) for p in sorted(paths) if (REPO / p).is_file()}


def parse(log):
    tests, results, suites, errors, done = {}, {}, {}, [], None
    for line in log.read_text(errors='replace').splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if not isinstance(event, dict):
            continue
        kind = event.get('type')
        if kind == 'testStart':
            tests[event['test']['id']] = event['test']
        elif kind == 'testDone':
            results[event['testID']] = event
        elif kind == 'suite':
            suites[event['suite']['id']] = event['suite']
        elif kind == 'error':
            errors.append(event)
        elif kind == 'done':
            done = event
    cases = []
    hooks = []
    for test_id, test in tests.items():
        name = test['name']
        result = results.get(test_id)
        record = {'name': name, 'suite': suites.get(test['suiteID'], {}).get('path'),
                  'result': result.get('result') if result else 'unresolved',
                  'skipped': result.get('skipped', False) if result else False}
        if name.startswith('loading ') or '(setUpAll)' in name or '(tearDownAll)' in name:
            hooks.append(record)
        else:
            cases.append(record)
    return {'done': done, 'suites': list(suites.values()), 'cases': cases,
            'passed': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
            'failed': sum(c['result'] in ('failure', 'error') for c in cases),
            'skipped': sum(c['skipped'] for c in cases),
            'unresolved': sum(c['result'] == 'unresolved' for c in cases),
            'hooks_and_loaders': hooks, 'errors': errors}


env = dict(os.environ)
env.update({'FLUTTER_ROOT': str(RUNTIME / 'flutter'),
            'PUB_CACHE': str(RUNTIME / 'pub-cache'),
            'TMPDIR': str(RUNTIME / 'tmp'),
            'XDG_CONFIG_HOME': str(RUNTIME / 'config'),
            'XDG_CACHE_HOME': str(RUNTIME / 'cache'),
            'XDG_DATA_HOME': str(RUNTIME / 'data'),
            'CI': 'true', 'DART_SUPPRESS_ANALYTICS': 'true',
            'FLUTTER_SUPPRESS_ANALYTICS': 'true',
            'DASH__SUPPRESS_ANALYTICS': 'true',
            'PATH': str(RUNTIME / 'bin') + os.pathsep + env['PATH']})
only = set(sys.argv[1:])
if only and (OUT / 'qualification.json').exists():
    record = json.loads((OUT / 'qualification.json').read_text())
else:
    record = {'started_at': datetime.now(timezone.utc).isoformat(),
              'selection': selection, 'runtime': str(RUNTIME / 'runtime.json'),
              'groups': []}
record['selection'] = selection
write(OUT / 'qualification.json', record)
for package, tests in selection['groups'].items():
    name = package.replace('packages/', '').replace('/', '-')
    if only and name not in only:
        continue
    directory = OUT / name
    if only and directory.exists():
        previous = [g for g in record['groups'] if g['package'] == package]
        suffix = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')
        archive = OUT / 'attempts' / (name + '-' + suffix)
        archive.parent.mkdir(exist_ok=True)
        shutil.move(str(directory), archive)
        for item in previous:
            item['archived_evidence_directory'] = str(archive)
        record.setdefault('attempt_history', []).extend(previous)
        record['groups'] = [g for g in record['groups'] if g['package'] != package]
    directory.mkdir(exist_ok=True)
    before = sources(package)
    write(directory / 'sources-before.json', before)
    head = git('rev-parse', 'HEAD')
    is_flutter = 'editor' in package or package.endswith('quds_mail_ui')
    command = ([str(RUNTIME / 'bin/flutter'), 'test', '--no-pub'] if is_flutter
               else [str(RUNTIME / 'run-dart-tests.sh'), '--compiler=kernel'])
    command += ['--concurrency=1', '--timeout=2x', '--reporter=json', *tests]
    print(json.dumps({'phase': 'start', 'package': package, 'tests': len(tests), 'head': head}), flush=True)
    start = time.monotonic()
    with (directory / 'stdout.jsonl').open('w') as stdout, (directory / 'stderr.log').open('w') as stderr:
        try:
            result = subprocess.run(command, cwd=REPO / package, env=env,
                                    stdout=stdout, stderr=stderr, timeout=600)
            exit_code = result.returncode
        except subprocess.TimeoutExpired:
            exit_code = 124
    after = sources(package)
    write(directory / 'sources-after.json', after)
    parsed = parse(directory / 'stdout.jsonl')
    write(directory / 'cases.json', parsed)
    item = {'package': package, 'head_at_start': head, 'command': command,
            'cwd': str(REPO / package), 'exit_code': exit_code,
            'seconds': round(time.monotonic() - start, 3),
            'tests_selected': tests,
            'passed': parsed['passed'], 'failed': parsed['failed'],
            'skipped': parsed['skipped'], 'unresolved': parsed['unresolved'],
            'source_count': len(before),
            'changed_inputs': sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p)),
            'stdout_sha256': digest(directory / 'stdout.jsonl'),
            'stderr_sha256': digest(directory / 'stderr.log'),
            'sources_before_sha256': digest(directory / 'sources-before.json'),
            'sources_after_sha256': digest(directory / 'sources-after.json'),
            'successful_completion': bool(parsed['done'] and parsed['done'].get('success'))}
    item['accepted'] = (exit_code == 0 and item['successful_completion']
                        and not item['changed_inputs'] and not item['failed']
                        and not item['skipped'] and not item['unresolved'])
    record['groups'].append(item)
    write(directory / 'command.json', item)
    write(OUT / 'qualification.json', record)
    print(json.dumps({'phase': 'finish', **{k: item[k] for k in ['package','exit_code','passed','failed','skipped','unresolved','accepted','changed_inputs']}}), flush=True)
record['finished_at'] = datetime.now(timezone.utc).isoformat()
record['accepted_passes'] = sum(g['passed'] for g in record['groups'] if g['accepted'])
record['all_selected_accepted'] = all(g['accepted'] for g in record['groups'])
write(OUT / 'qualification.json', record)
print(json.dumps({'phase':'done','accepted_passes':record['accepted_passes'],'all_selected_accepted':record['all_selected_accepted']}), flush=True)
