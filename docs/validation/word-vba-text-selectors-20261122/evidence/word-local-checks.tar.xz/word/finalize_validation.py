import collections
import datetime
import functools
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
from urllib.parse import unquote, urljoin, urlparse

ROOT=Path('/workspace/scratch/58a062e5b571/quds_office_suite')
VERIFY=Path('/workspace/scratch/58a062e5b571/verification')
WORD=VERIFY/'word'
DEST=ROOT/'docs/validation/word-vba-text-selectors-20261122'
DEST.mkdir(parents=True,exist_ok=True)
(DEST/'evidence').mkdir(exist_ok=True)

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
def write(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()

# Replace the entire affected suite, never add rerun passes to the broad count.
def parse_cases(path):
    suites,tests,outcomes={},{},{}
    for line in path.read_text().splitlines():
        try:e=json.loads(line)
        except json.JSONDecodeError:continue
        kind=e.get('type')
        if kind=='suite':suites[e['suite']['id']]=e['suite']
        elif kind=='testStart':tests[e['test']['id']]=e['test']
        elif kind=='testDone':outcomes[e['testID']]=e
    result=[]
    for i,test in tests.items():
        name=test['name']
        if name.startswith('loading ') or name.endswith('(setUpAll)') or name.endswith('(tearDownAll)'):continue
        path=(test.get('url') or suites[test['suiteID']]['path']).removeprefix('file://').removeprefix(str(ROOT)+'/')
        if path.startswith('test/'):path='packages/quds_office_engine/'+path
        outcome=outcomes.get(i,{})
        result.append({'suite':path,'name':name,'result':outcome.get('result'),'skipped':outcome.get('skipped',False)})
    return result

broad=read(WORD/'broad/qualification.json')
initial=parse_cases(WORD/'broad/tests.jsonl')
replacement=parse_cases(WORD/'measurement-preservation/tests.jsonl')
replaced={c['suite'] for c in replacement}
assert len(replaced)==1 and len(replacement)==11
macro=[c for c in initial if c['suite'] not in replaced]+replacement
rtl=parse_cases(WORD/'rtl-interaction/repo-tests.jsonl')
assert len(macro)==8317 and len(rtl)==2
incoming_receipt=read(VERIFY/'incoming/qualification.json')
incoming=[]
for group in incoming_receipt['groups']:
    assert group['accepted']
    folder=group['package'].replace('packages/','').replace('/','-')
    for case in read(VERIFY/'incoming'/folder/'cases.json')['cases']:
        incoming.append({**case,'suite':group['package']+'/'+case['suite']})
assert len(incoming)==1163
assert not ({c['suite'] for c in macro}|{c['suite'] for c in rtl}) & {c['suite'] for c in incoming}
accepted=macro+rtl+incoming
counts=collections.Counter()
for case in accepted:
    assert case['result']=='success' and not case['skipped']
    counts[case['suite']]+=1
    case['caseOrdinal']=counts[case['suite']]
assert len(accepted)==9482 and len(counts)==193
write(WORD/'accepted-cases.json',accepted)

# Check all production/configuration bytes and specifically trace local Dart
# imports for retained suites whose broad snapshots overcaptured other tests.
changed=git('diff','--name-only','0cf0127').splitlines()
production=[p for p in changed if '/lib/' in p or p.endswith(('pubspec.yaml','pubspec.lock','analysis_options.yaml')) or p=='.fvmrc']
assert not production,production
configuration=ROOT/'.dart_tool/package_config.json'
package_roots={}
for p in read(configuration)['packages']:
    uri=urljoin(configuration.as_uri(),p['rootUri'])
    package_roots[p['name']]=Path(unquote(urlparse(uri).path))/p.get('packageUri','lib/')

@functools.lru_cache(None)
def imports(relative):
    path=ROOT/relative
    if not path.is_file():return ()
    found=[]
    for declaration in re.findall(r'(?m)^\s*(?:import|export|part)\s+([^;]+);',path.read_text()):
        for _,uri in re.findall(r"(['\"])(.*?)\1",declaration):
            if not uri.endswith('.dart') or uri.startswith('dart:'):continue
            if uri.startswith('package:'):
                package,_,tail=uri[8:].partition('/')
                if package not in package_roots:continue
                target=package_roots[package]/tail
            else:target=path.parent/uri
            target=target.resolve()
            try:r=target.relative_to(ROOT).as_posix()
            except ValueError:continue
            if target.is_file():found.append(r)
    return tuple(found)

def closure(paths):
    seen=set();pending=list(paths)
    while pending:
        p=pending.pop()
        if p in seen:continue
        seen.add(p);pending.extend(imports(p))
    return seen

def compare(snapshot):
    return [p for p,h in snapshot.items() if not (ROOT/p).is_file()
            or sha(ROOT/p)!=(h['sha256'] if isinstance(h,dict) else h)]

allowed_test_changes={
 'packages/quds_office_engine/tool/macros/web_vba_word_named_measurements_smoke.dart',
 'packages/quds_office_engine/test/office_vba_word_named_measurements_integration_test.dart',
}
continuity={'productionBaseline':'0cf0127af28ee2300d38dab699437d4f2f922421','currentHead':git('rev-parse','HEAD'),'productionOrConfigurationChanges':production,'checks':[],'dependencyScope':'Local Dart import/export/part closure, including conditional import alternatives; dependency archives and SDK are identified separately by pinned lock/runtime provenance.'}
broad_changes=compare(read(WORD/'broad/source-after.json'))
assert set(broad_changes)<=allowed_test_changes,broad_changes
retained_suites={c['suite'] for c in macro if c['suite'] not in replaced}
retained_closure=closure(retained_suites)
assert not set(broad_changes)&retained_closure
continuity['checks'].append({'gate':'retained macro suites','suites':len(retained_suites),'overcapturedChangedInputs':broad_changes,'changesInLocalDependencyClosure':[],'localDartDependencyFiles':len(retained_closure),'accepted':True})
for group in incoming_receipt['groups']:
    folder=group['package'].replace('packages/','').replace('/','-')
    differences=compare(read(VERIFY/'incoming'/folder/'sources-after.json'))
    assert set(differences)<=allowed_test_changes,differences
    selected=[group['package']+'/'+p for p in incoming_receipt['selection']['groups'][group['package']]]
    dependencies=closure(selected)
    assert not set(differences)&dependencies
    continuity['checks'].append({'gate':group['package'],'overcapturedChangedInputs':differences,'changesInLocalDependencyClosure':[],'localDartDependencyFiles':len(dependencies),'accepted':True})
for name,start in [('example-portable','packages/quds_office_engine/tool/macros/web_vba_word_text_selectors_smoke.dart'),('measurement-preservation','packages/quds_office_engine/tool/macros/web_vba_word_named_measurements_smoke.dart')]:
    differences=compare(read(WORD/name/'inputs-after.json'))
    assert set(differences)<=allowed_test_changes,differences
    dependencies=closure([start])
    assert not set(differences)&dependencies
    continuity['checks'].append({'gate':name,'overcapturedChangedInputs':differences,'changesInLocalDependencyClosure':[],'localDartDependencyFiles':len(dependencies),'accepted':True})
corpus=read(WORD/'conformance-portable/receipt.json')
assert not compare(corpus['inputs_after'])
continuity['checks'].append({'gate':'canonical corpus','capturedInputs':len(corpus['inputs_after']),'changedInputs':[],'accepted':True})
write(WORD/'final-source-continuity.json',continuity)

snapshot=read(WORD/'final-remote-snapshot.json')
ancestry=read(WORD/'final-ancestry.json')
assert ancestry['allAncestors']
assert subprocess.run(['git','merge-base','--is-ancestor',ancestry['qualifiedHead'],'HEAD'],cwd=ROOT).returncode==0
write(DEST/'final-intake.json',{'remoteSnapshot':snapshot,'ancestryVerification':ancestry,'continuedHead':git('rev-parse','HEAD')})
measurement=read(WORD/'measurement-preservation/qualification.json')
example=read(WORD/'example-portable/qualification.json')
assert measurement['success'] and example['success'] and corpus['outputs_equal']
q={
 'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'qualifiedSourceHead':git('rev-parse','HEAD'),
 'compilerSha256':sha(ROOT/'packages/quds_office_engine/lib/src/automation/office_vba_language.dart'),
 'accepted':True,'substantiveCases':len(accepted),'suites':len(counts),'failed':0,'skipped':0,'unresolved':0,
 'caseIdentity':'Repository-relative suite plus ordinal within its single accepted run; repeated human-readable labels are allowed. No rerun is added twice. Loaders and lifecycle hooks are excluded.',
 'macro':{'broadSuites':157,'cases':8317,'broadPasses':broad['passed'],'broadFailures':len(broad['errors']),'replacedWholeSuiteCases':11,'replacementPasses':len(replacement),'reason':'All three failures required obsolete deletion of foreign indentation XML. The helper now positively verifies preservation, without changing production code; its full 11-case suite and actual BAS were rerun.'},
 'newRtlInteraction':{'suites':1,'cases':len(rtl)},
 'incoming':{'suites':35,'cases':len(incoming),'groups':[{'package':g['package'],'passed':g['passed']} for g in incoming_receipt['groups']]},
 'portable':{'canonicalCorpus':{'cases':64,'vmJsByteEqual':True,'receiptSha256':sha(WORD/'conformance-portable/vm.stdout')},'actualTextSelectorBas':{'vmJsSemanticEqual':True,'vmJsByteEqual':False,'difference':'72 integral spacing values use 0.0/8.0 on VM and 0/8 on JavaScript; all parsed values match.'},'actualMeasurementBas':{'vmJsSemanticEqual':True,'vmJsByteEqual':True,'receiptSha256':measurement['vm_stdout_sha256']}},
 'static':{'wordChangedDartFiles':15,'strictAnalysis':'passed','format':'passed','incomingChangedDartFiles':9,'incomingNativeSerialDirectoryAnalysis':'passed'},
 'runtime':{'flutter':'3.47.8','dart':'3.13.7','node':'24.22.3','lockfileChanged':False},
 'sourceContinuity':'evidence/word-local-checks.tar.xz:word/final-source-continuity.json',
 'priorAttempts':'Preserved in evidence archives and excluded from accepted totals.',
 'githubActions':'No workflow/queue/status endpoint queried or awaited; local validation gates only.',
 'limits':['Bounded source-to-native-plan VBA subset, not a full VBA interpreter.','No installed Microsoft Word differential acceptance performed for these VBA changes.','New collections remain immutable selectors without Count/enumeration/live document reads; ByVal-only object helpers.','Opaque embedded VBA/signature bytes are preserved, not executed or authenticated.'],
}
write(DEST/'qualification.json',q)
shutil.copy2(Path('/workspace/scratch/58a062e5b571/runtime/runtime.json'),DEST/'evidence/runtime-provenance.json')

# Preserve raw receipts and failed attempts, omitting reproducible compilation
# products and the transient GitHub upload payload. Their hashes remain logged.
excluded_suffixes={'.js','.map','.deps','.dill','.pyc'}
archives=[]
for name,source,prefix in [('word-local-checks.tar.xz',WORD,'word'),('incoming-local-checks.tar.xz',VERIFY/'incoming','incoming')]:
    files=sorted(p for p in source.rglob('*') if p.is_file() and p.name!='checkpoint-payload.json' and p.suffix not in excluded_suffixes and '__pycache__' not in p.parts)
    target=DEST/'evidence'/name
    with tarfile.open(target,mode='w:xz',preset=6) as archive:
        for path in files:
            arcname=prefix+'/'+path.relative_to(source).as_posix()
            info=archive.gettarinfo(str(path),arcname);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644
            with path.open('rb') as stream:archive.addfile(info,stream)
    archives.append({'path':'evidence/'+name,'bytes':target.stat().st_size,'sha256':sha(target),'files':[{'path':prefix+'/'+p.relative_to(source).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]})
write(DEST/'evidence/artifacts.json',{'archives':archives,'compiledArtifactPolicy':'Reproducible JS, JS maps/dependency lists and dill binaries omitted; exact commands and artifact hashes retained. Source, stdout/stderr, receipts, manifests, verifiers and prior attempts are included.','runtimeProvenanceSha256':sha(DEST/'evidence/runtime-provenance.json')})
print(json.dumps({'accepted':q['accepted'],'cases':q['substantiveCases'],'suites':q['suites'],'compiler':q['compilerSha256'],'continuityChecks':len(continuity['checks']),'archives':[{'path':a['path'],'bytes':a['bytes'],'files':len(a['files']),'sha256':a['sha256']} for a in archives]},indent=2))
