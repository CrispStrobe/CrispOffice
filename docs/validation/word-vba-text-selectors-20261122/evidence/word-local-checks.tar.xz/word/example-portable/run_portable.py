from pathlib import Path
import base64
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

repo = Path('/workspace/scratch/58a062e5b571/quds_office_suite')
engine = repo / 'packages/quds_office_engine'
out = Path('/workspace/scratch/58a062e5b571/verification/word/example-portable')
expected_compiler = 'd9126240652b062c5ffbb73d4333cd471e1076698af380e040bf424d58248ac5'
compiler = repo / 'packages/quds_office_engine/lib/src/automation/office_vba_language.dart'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
if sha(compiler) != expected_compiler:
    raise SystemExit('Refusing to qualify a compiler that differs from the agreed final source')

dart = Path('/workspace/scratch/58a062e5b571/runtime/flutter/bin/cache/dart-sdk/bin/dart')
node = Path(shutil.which('node')).resolve()
config = repo / '.dart_tool/package_config.json'
bas = engine / 'example/macros/word_text_selectors.bas'
helper = engine / 'tool/macros/web_vba_word_text_selectors_smoke.dart'
encoded = base64.b64encode(bas.read_bytes()).decode('ascii')

def json_file(name, data):
    (out / name).write_text(json.dumps(data, indent=2, ensure_ascii=True) + '\n')

def snapshot():
    roots = [
        'packages/quds_office_engine/lib',
        'packages/quds_office_engine/test',
        'packages/quds_office_engine/tool/macros',
        'packages/quds_office_engine/example/macros',
        'packages/legacy_doc_parser/lib',
    ]
    files = subprocess.check_output(['rg', '--files', *roots], cwd=repo, text=True).splitlines()
    files += [
        '.fvmrc', '.dart_tool/package_config.json', 'pubspec.yaml', 'pubspec.lock',
        'packages/quds_office_engine/pubspec.yaml',
        'packages/legacy_doc_parser/pubspec.yaml',
    ]
    return {
        path: {'sha256': sha(repo / path), 'bytes': (repo / path).stat().st_size}
        for path in sorted(set(files))
    }

before = snapshot()
json_file('inputs-before.json', before)
head_before = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
status_before = subprocess.check_output(['git', 'status', '--short'], cwd=repo, text=True)
(out / 'worktree-before.txt').write_text(status_before)
commands = []
json_file('toolchain.json', {
    'dart': {'path': str(dart), 'sha256': sha(dart)},
    'node': {'path': str(node), 'sha256': sha(node)},
    'package_config': {'path': str(config), 'sha256': sha(config)},
    'environment_setup': '/workspace/scratch/58a062e5b571/runtime/env.sh',
    'environment_setup_sha256': sha('/workspace/scratch/58a062e5b571/runtime/env.sh'),
    'git_head_before': head_before,
    'compiler_sha256': sha(compiler),
    'source_bas_sha256': sha(bas),
    'portable_helper_sha256': sha(helper),
    'input_manifest_scope': 'All engine lib/test/macro tool/macro example files plus legacy_doc_parser lib, package manifests, lock, pinned Flutter version, and generated package config. Git HEAD alone does not identify the dirty qualified tree; the input manifest is authoritative.',
})

def run(name, argv):
    stdout = out / (name + '.stdout')
    stderr = out / (name + '.stderr')
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    began = time.monotonic()
    with stdout.open('wb') as so, stderr.open('wb') as se:
        result = subprocess.run(argv, cwd=engine, stdout=so, stderr=se, check=False)
    record = {
        'name': name, 'argv': [str(arg) for arg in argv], 'cwd': str(engine),
        'started_at_utc': start, 'duration_seconds': round(time.monotonic() - began, 4),
        'exit_code': result.returncode,
        'stdout_file': stdout.name, 'stdout_sha256': sha(stdout),
        'stderr_file': stderr.name, 'stderr_sha256': sha(stderr),
    }
    commands.append(record)
    json_file('commands.json', commands)
    print(name + ': exit=' + str(result.returncode), flush=True)
    if result.returncode:
        print(stderr.read_text(errors='replace')[-4000:], flush=True)
        raise SystemExit(result.returncode)
    return stdout

try:
    run('dart-version', [str(dart), '--version'])
    run('node-version', [str(node), '--version'])
    run('strict-analysis', [
        str(dart), 'analyze', '--fatal-infos',
        str(compiler), str(helper),
        str(engine / 'test/office_vba_word_text_selectors_integration_test.dart'),
        str(engine / 'test/office_vba_word_text_selectors_cli_test.dart'),
    ])
    definition = '-DWORD_TEXT_SELECTORS_BAS_BASE64=' + encoded
    vm = run('example-vm', [
        str(dart), '--packages=' + str(config), definition, str(helper),
    ])
    compiled = out / 'example.js'
    run('example-js-compile', [
        str(dart), 'compile', 'js', '-O2', '--packages=' + str(config),
        definition, str(helper), '-o', str(compiled),
    ])
    js = run('example-js-node', [str(node), '-e', 'globalThis.self=globalThis;require(process.argv[1]);', str(compiled)])
    after = snapshot()
    json_file('inputs-after.json', after)
    subprocess.run([sys.executable, str(out / 'verify_receipts.py')], check=True)
    print('PASS: final integrated source passes portable semantic receipt equality', flush=True)

finally:
    if not (out / 'inputs-after.json').exists():
        json_file('inputs-after.json', snapshot())
