from pathlib import Path
import hashlib
import json
import math

root = Path('/workspace/scratch/58a062e5b571/verification/word/example-portable')
repo = Path('/workspace/scratch/58a062e5b571/quds_office_suite')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
load = lambda name: json.loads((root / name).read_text())

commands = load('commands.json')
expected_commands = [
    'dart-version', 'node-version', 'strict-analysis',
    'example-vm', 'example-js-compile', 'example-js-node',
]
assert [command['name'] for command in commands] == expected_commands
for command in commands:
    assert command['exit_code'] == 0, command['name']
    assert sha(root / command['stdout_file']) == command['stdout_sha256']
    assert sha(root / command['stderr_file']) == command['stderr_sha256']
assert 'No issues found!' in (root / 'strict-analysis.stdout').read_text()
assert '-O2' in commands[4]['argv']
assert commands[5]['argv'][1:3] == [
    '-e', 'globalThis.self=globalThis;require(process.argv[1]);',
]

vm_raw = (root / 'example-vm.stdout').read_bytes()
js_raw = (root / 'example-js-node.stdout').read_bytes()
assert vm_raw and js_raw
vm, js = json.loads(vm_raw), json.loads(js_raw)
numeric_spelling = []
def equal(actual, expected, path=''):
    if isinstance(actual, bool) or isinstance(expected, bool):
        assert type(actual) is type(expected) and actual == expected, path
    elif isinstance(actual, (int, float)) and isinstance(expected, (int, float)):
        assert math.isfinite(actual) and math.isfinite(expected) and actual == expected, path
        if type(actual) is not type(expected):
            assert path.startswith('/state/') and path.endswith(('/before', '/after')), path
            assert float(actual).is_integer() and float(expected).is_integer(), path
            numeric_spelling.append({
                'path': path,
                'vm_json_number': actual,
                'node_json_number': expected,
                'vm_parsed_python_type': type(actual).__name__,
                'node_parsed_python_type': type(expected).__name__,
            })
    elif isinstance(actual, dict) and isinstance(expected, dict):
        assert actual.keys() == expected.keys(), path
        for key in actual:
            equal(actual[key], expected[key], path + '/' + key)
    elif isinstance(actual, list) and isinstance(expected, list):
        assert len(actual) == len(expected), path
        for index, (left, right) in enumerate(zip(actual, expected)):
            equal(left, right, path + '/' + str(index))
    else:
        assert type(actual) is type(expected) and actual == expected, path
equal(vm, js)
assert len(numeric_spelling) == 72

expected = {
    'language': 'vba-word', 'fixtureFormat': 'docm',
    'operations': 5, 'firstRunRevision': 1, 'repeatedRevision': 2,
    'additionalReopens': 2, 'recordedSteps': 5,
    'untouchedStoryParagraphs': 33, 'untouchedBodyParagraphs': 2,
    'opaquePayloadsPreserved': True, 'immutableValidation': True,
    'nativeRecordingAndReplay': True, 'lateRollbackAndRecording': True,
    'mcpCompileValidateRun': True, 'inactiveNamedArgumentRejected': True,
    'hostPolicyGuards': True,
}
for key, value in expected.items():
    assert type(vm[key]) is type(value) and vm[key] == value, key
state = vm['state']
assert state['body'] == ['INV Body 1', 'Body 2', 'Body 3']
for key, value in {
    '2.header.1': 'INV 0042 / DE: S2 header 1',
    '2.evenFooter.2': 'DE S2 evenFooter 2',
    '3.firstHeader.1': 'Pending: S3 firstHeader 1',
}.items():
    assert state[key]['text'] == value, key
assert state['2.header.1']['bold'] == [True]

before, after = load('inputs-before.json'), load('inputs-after.json')
assert before == after, 'Captured inputs changed during execution'
for path, metadata in after.items():
    assert sha(repo / path) == metadata['sha256'], 'Current input changed: ' + path
toolchain = load('toolchain.json')
compiler = repo / 'packages/quds_office_engine/lib/src/automation/office_vba_language.dart'
assert sha(compiler) == toolchain['compiler_sha256']
assert toolchain['compiler_sha256'] == 'd9126240652b062c5ffbb73d4333cd471e1076698af380e040bf424d58248ac5'
for runtime in ['dart', 'node']:
    assert sha(toolchain[runtime]['path']) == toolchain[runtime]['sha256']
result = {
    'success': True,
    'qualification_scope': 'Executed exact BAS on the Dart VM and optimized Dart JavaScript in Node; semantic document-state receipt equality',
    'compiler_sha256': sha(compiler),
    'bas_sha256': toolchain['source_bas_sha256'],
    'helper_sha256': toolchain['portable_helper_sha256'],
    'captured_input_count': len(before),
    'input_manifest_sha256': sha(root / 'inputs-before.json'),
    'captured_inputs_identical_before_after_and_current': True,
    'all_six_tool_commands_exit_zero': True,
    'strict_analysis_no_issues': True,
    'vm_js_stdout_byte_identical': vm_raw == js_raw,
    'vm_js_parsed_json_equal': True,
    'vm_stdout_bytes': len(vm_raw),
    'vm_stdout_sha256': sha(root / 'example-vm.stdout'),
    'node_stdout_bytes': len(js_raw),
    'node_stdout_sha256': sha(root / 'example-js-node.stdout'),
    'compiled_js_sha256': sha(root / 'example.js'),
    'numeric_spelling_difference_count': len(numeric_spelling),
    'numeric_spelling_differences': numeric_spelling,
    'checked_receipt_fields': expected,
    'verification_script_sha256': sha(__file__),
    'qualification_notes': [
        'All product checks execute inside the unchanged portable helper before it emits its receipt.',
        'The VM emits integral paragraph spacing as 0.0/8.0; Dart JavaScript emits the same JSON numbers as 0/8. These 72 spellings account for the 144-byte output-length difference.',
        'The initial raw-byte gate rejected those harmless serialization differences. Final acceptance requires exact structural and numeric JSON equality, allowing only the documented integral spacing spellings; no source normalization was introduced.',
        'Initial bare-Node invocation is separately preserved and uncredited under initial-bare-node.',
        'This document-state example does not claim raw-byte equality. The independent canonical compiler corpus is qualified separately.',
        'No installed Microsoft Office host, browser UI, or GitHub Actions execution is claimed.',
    ],
}
(root / 'qualification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'numeric_spelling_differences'}, indent=2))
