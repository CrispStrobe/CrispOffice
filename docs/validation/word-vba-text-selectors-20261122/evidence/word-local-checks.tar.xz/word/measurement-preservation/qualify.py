from pathlib import Path
import base64
import datetime
import hashlib
import json
import shutil
import subprocess
import time


repo = Path('/workspace/scratch/58a062e5b571/quds_office_suite')
engine = repo / 'packages/quds_office_engine'
out = Path(__file__).resolve().parent
runtime = Path('/workspace/scratch/58a062e5b571/runtime')
dart = runtime / 'flutter/bin/cache/dart-sdk/bin/dart'
node = Path(shutil.which('node')).resolve()
config = repo / '.dart_tool/package_config.json'
helper = engine / 'tool/macros/web_vba_word_named_measurements_smoke.dart'
suite = engine / 'test/office_vba_word_named_measurements_integration_test.dart'
bas = engine / 'example/macros/word_named_measurements.bas'
documentation = repo / 'docs/vba-word-macros-details.md'
compiler = engine / 'lib/src/automation/office_vba_language.dart'
commands = []


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')


def snapshot():
    roots = [
        'packages/quds_office_engine/lib',
        'packages/legacy_doc_parser/lib',
    ]
    paths = subprocess.check_output(
        ['rg', '--files', *roots], cwd=repo, text=True,
    ).splitlines()
    paths += [
        str(path.relative_to(repo))
        for path in [helper, suite, bas, documentation, config]
    ]
    paths += [
        '.fvmrc', 'pubspec.yaml', 'pubspec.lock',
        'packages/quds_office_engine/pubspec.yaml',
        'packages/legacy_doc_parser/pubspec.yaml',
        'packages/quds_office_engine/tool/macros/office_macro.dart',
        'packages/quds_office_engine/test/support/office_macro_cli.dart',
    ]
    return {
        name: {'sha256': sha(repo / name), 'bytes': (repo / name).stat().st_size}
        for name in sorted(set(paths))
    }


def run(name, argv, stdout_name=None):
    stdout = out / (stdout_name or name + '.stdout')
    stderr = out / (name + '.stderr')
    began = time.monotonic()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with stdout.open('wb') as so, stderr.open('wb') as se:
        process = subprocess.run(
            [str(item) for item in argv], cwd=engine,
            stdout=so, stderr=se, check=False,
        )
    commands.append({
        'name': name, 'argv': [str(item) for item in argv], 'cwd': str(engine),
        'started_at_utc': started,
        'duration_seconds': round(time.monotonic() - began, 4),
        'exit_code': process.returncode,
        'stdout_file': stdout.name, 'stdout_sha256': sha(stdout),
        'stderr_file': stderr.name, 'stderr_sha256': sha(stderr),
    })
    write_json('commands.json', commands)
    print(f'{name}: exit={process.returncode}', flush=True)
    if process.returncode != 0:
        print(stdout.read_text(errors='replace')[-4000:], flush=True)
        print(stderr.read_text(errors='replace')[-4000:], flush=True)
        raise SystemExit(process.returncode)
    return stdout


run('dart-version', [dart, '--version'])
run('node-version', [node, '--version'])
run('format', [dart, 'format', helper, suite])
run('format-check', [dart, 'format', '--output=none', '--set-exit-if-changed', helper, suite])
run('diff-check', ['git', 'diff', '--check', '--', helper, suite, documentation])
before = snapshot()
write_json('inputs-before.json', before)
write_json('toolchain.json', {
    'git_head_before': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=repo, text=True,
    ).strip(),
    'dart': {'path': str(dart), 'sha256': sha(dart)},
    'node': {'path': str(node), 'sha256': sha(node)},
    'runner': {
        'path': str(runtime / 'run-dart-tests.sh'),
        'sha256': sha(runtime / 'run-dart-tests.sh'),
        'kernel_sha256': sha(runtime / 'test-runner/test-runner.dill'),
    },
    'environment': {'path': str(runtime / 'env.sh'), 'sha256': sha(runtime / 'env.sh')},
    'package_config': {'path': str(config), 'sha256': sha(config)},
    'source_manifest_scope': (
        'All engine library and legacy_doc_parser library files, exact measurement '
        'helper/integration test/BAS, CLI entry and test support, corrected documentation, '
        'package manifests/lock, pinned SDK version and generated package config. '
        'Unrelated tests are excluded because they are not runtime inputs to this gate.'
    ),
})
(out / 'worktree-before.txt').write_text(subprocess.check_output(
    ['git', 'status', '--short'], cwd=repo, text=True,
))

try:
    run('strict-analysis', [dart, 'analyze', '--fatal-infos', helper, suite])
    tests = run('integration-tests', [
        runtime / 'run-dart-tests.sh',
        'test/office_vba_word_named_measurements_integration_test.dart',
        '-r', 'json', '--concurrency=1',
    ], 'tests.jsonl')
    definition = '-DWORD_NAMED_MEASUREMENTS_BAS_BASE64=' + base64.b64encode(bas.read_bytes()).decode('ascii')
    vm = run('example-vm', [dart, '--packages=' + str(config), definition, helper])
    compiled = out / 'example.js'
    run('example-js-compile', [
        dart, 'compile', 'js', '-O2', '--packages=' + str(config),
        definition, helper, '-o', compiled,
    ])
    js = run('example-js-node', [
        node, '-e', 'globalThis.self=globalThis;require(process.argv[1]);', compiled,
    ])

    records = [json.loads(line) for line in tests.read_text().splitlines() if line.strip()]
    started = {
        event['test']['id']: event['test']
        for event in records if event.get('type') == 'testStart'
    }
    completed = [event for event in records if event.get('type') == 'testDone']
    substantive = [
        event for event in completed
        if not started[event['testID']]['name'].startswith('loading ')
        and started[event['testID']]['name'] not in ['(setUpAll)', '(tearDownAll)']
    ]
    errors = [event for event in records if event.get('type') == 'error']
    done = [event for event in records if event.get('type') == 'done']
    assert len(done) == 1 and done[0]['success'] is True, done
    assert not errors, errors
    assert len(substantive) > 0
    assert all(event['result'] == 'success' and not event['skipped'] for event in substantive)

    vm_json = json.loads(vm.read_text())
    js_json = json.loads(js.read_text())
    assert vm_json == js_json, 'VM and JavaScript semantic receipts differ'
    expected_example = {
        'operations': 13,
        'revisionAfterReplay': 2,
        'additionalReopens': 2,
        'opaqueVbaPreserved': True,
        'nativeIndentGeometryReplaced': True,
        'nativeIndentExtensionsPreserved': True,
    }
    for key, value in expected_example.items():
        assert vm_json['example'][key] == value and type(vm_json['example'][key]) is type(value), key
    assert 'nativeIndentGroupReplaced' not in vm_json['example']
    expected_guards = {
        'refusedPolicies': 3,
        'completeAllowlistRevision': 1,
        'lateFailureStep': 1,
        'validateAndRunRollback': True,
    }
    assert vm_json['guards'] == expected_guards
    after = snapshot()
    write_json('inputs-after.json', after)
    assert before == after, 'Source inputs changed during qualification'
    assert 'No issues found!' in (out / 'strict-analysis.stdout').read_text()

    summary = {
        'success': True,
        'qualification_scope': 'Measurement native-indentation preservation helper correction; actual BAS on VM and optimized JavaScript plus whole affected integration suite',
        'product_code_changed': False,
        'captured_input_count': len(before),
        'captured_inputs_identical_before_after': True,
        'input_manifest_sha256': sha(out / 'inputs-before.json'),
        'compiler_sha256': sha(compiler),
        'helper_sha256': sha(helper),
        'integration_test_sha256': sha(suite),
        'bas_sha256': sha(bas),
        'documentation_sha256': sha(documentation),
        'strict_analysis_no_issues': True,
        'format_check_passed': True,
        'test_summary': {
            'substantive_tests': len(substantive),
            'passed': len(substantive),
            'failed': 0,
            'skipped': 0,
            'errors': 0,
            'loader_and_lifecycle_events': len(completed) - len(substantive),
            'raw_test_done_events': len(completed),
            'test_names': [started[event['testID']]['name'] for event in substantive],
        },
        'vm_js_parsed_json_equal': True,
        'vm_js_stdout_byte_identical': vm.read_bytes() == js.read_bytes(),
        'vm_stdout_bytes': vm.stat().st_size,
        'vm_stdout_sha256': sha(vm),
        'node_stdout_bytes': js.stat().st_size,
        'node_stdout_sha256': sha(js),
        'compiled_js_sha256': sha(compiled),
        'checked_receipt': vm_json,
        'qualifier_sha256': sha(__file__),
        'all_commands_exit_zero': all(record['exit_code'] == 0 for record in commands),
        'notes': [
            'The previous broad gate retains its three stale-helper failures; this scoped gate supersedes that helper assertion only.',
            'No installed Microsoft Office, browser UI, or GitHub Actions execution is claimed.',
            'No receipt normalization is performed by this verifier.',
        ],
    }
    write_json('qualification.json', summary)
    print(json.dumps({key: value for key, value in summary.items() if key not in ['checked_receipt', 'test_summary']}, indent=2), flush=True)
    print(f"PASS: {len(substantive)} substantive integration tests; VM/JS semantic equality; raw byte equality={summary['vm_js_stdout_byte_identical']}", flush=True)
finally:
    if not (out / 'inputs-after.json').exists():
        write_json('inputs-after.json', snapshot())
