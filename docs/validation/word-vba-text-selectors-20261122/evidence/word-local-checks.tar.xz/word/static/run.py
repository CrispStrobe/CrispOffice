import concurrent.futures, hashlib, json, pathlib, subprocess, time
root=pathlib.Path('/workspace/scratch/58a062e5b571/quds_office_suite')
out=pathlib.Path('/workspace/scratch/58a062e5b571/verification/word/static')
dart='/workspace/scratch/58a062e5b571/runtime/flutter/bin/cache/dart-sdk/bin/dart'
files=[p for p in subprocess.check_output(['git','diff','--name-only','091be781','bc15ae55','--','packages/quds_office_engine'],cwd=root,text=True).splitlines() if p.endswith('.dart')]
before={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
def run(i,p):
 cmd=[dart,'analyze','--fatal-infos',p]
 started=time.time()
 a=subprocess.run(cmd,cwd=root,text=True,capture_output=True)
 (out/f'analysis-{i:02}.stdout').write_text(a.stdout)
 (out/f'analysis-{i:02}.stderr').write_text(a.stderr)
 return {'command':cmd,'cwd':str(root),'exitCode':a.returncode,'seconds':time.time()-started,'stdout':f'analysis-{i:02}.stdout','stderr':f'analysis-{i:02}.stderr'}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 receipts=list(pool.map(lambda pair:run(*pair),enumerate(files)))
cmd=[dart,'format','--output=none','--set-exit-if-changed',*files]
f=subprocess.run(cmd,cwd=root,text=True,capture_output=True)
(out/'format.stdout').write_text(f.stdout);(out/'format.stderr').write_text(f.stderr)
after={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
q={'files':files,'before':before,'after':after,'unchanged':before==after,'analysis':receipts,'format':{'command':cmd,'exitCode':f.returncode},'success':before==after and f.returncode==0 and all(r['exitCode']==0 for r in receipts)}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
print(json.dumps({'success':q['success'],'files':len(files),'analysisExitCodes':[r['exitCode'] for r in receipts],'formatExitCode':f.returncode,'unchanged':before==after}))
raise SystemExit(0 if q['success'] else 1)
