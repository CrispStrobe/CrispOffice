from pathlib import Path
import base64
import hashlib
import json
import subprocess
import time

ROOT = Path('/workspace/scratch/58a062e5b571')
REPO = ROOT / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
OUT = Path(__file__).resolve().parent
DART = ROOT / 'runtime/flutter/bin/cache/dart-sdk/bin/dart'
FIXTURE = ENGINE / 'test/fixtures/vba_conformance/word_text_selectors_v1.json'
PATHS = sorted((ENGINE / 'lib').rglob('*.dart')) + [
    FIXTURE,
    ENGINE / 'test/support/vba_conformance.dart',
    ENGINE / 'test/office_vba_word_text_selectors_conformance_test.dart',
    ENGINE / 'tool/macros/web_vba_conformance.dart',
    REPO / 'pubspec.lock',
    REPO / '.dart_tool/package_config.json',
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs():
    return {str(path.relative_to(REPO)): sha(path) for path in PATHS}


receipt = {
    'input_scope': 'All engine lib Dart sources, canonical fixture, conformance test/support/runner, workspace lock and package configuration. External dependency contents are not exhaustively hashed by this receipt.',
    'inputs_before': inputs(),
    'runs': [],
}
assert receipt['inputs_before']['packages/quds_office_engine/lib/src/automation/office_vba_language.dart'] == 'd9126240652b062c5ffbb73d4333cd471e1076698af380e040bf424d58248ac5', 'The announced final compiler input changed before this run.'
receipt['alias_reproduction_sha256'] = sha(OUT / 'collection-alias-review.dart')


def write_receipt():
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')


def run(name, args):
    start = time.monotonic()
    with (OUT / (name + '.stdout')).open('w') as stdout:
        with (OUT / (name + '.stderr')).open('w') as stderr:
            result = subprocess.run(args, cwd=ENGINE, stdout=stdout, stderr=stderr, timeout=180)
    receipt['runs'].append({
        'name': name,
        'command': [arg if not arg.startswith('-DVBA_CONFORMANCE_BASE64=') else '-DVBA_CONFORMANCE_BASE64=<base64 of exact fixture bytes hashed in inputs_before>' for arg in args],
        'exit_code': result.returncode,
        'elapsed_seconds': round(time.monotonic() - start, 3),
        'stdout_sha256': sha(OUT / (name + '.stdout')),
        'stderr_sha256': sha(OUT / (name + '.stderr')),
        'stderr_bytes': (OUT / (name + '.stderr')).stat().st_size,
    })
    write_receipt()
    if result.returncode:
        raise SystemExit(name + ' failed; inspect retained output')


write_receipt()
encoded = '-DVBA_CONFORMANCE_BASE64=' + base64.b64encode(FIXTURE.read_bytes()).decode()
packages = '--packages=' + str(REPO / '.dart_tool/package_config.json')
run('alias-review', [str(DART), packages, str(OUT / 'collection-alias-review.dart')])
assert all(not result['accepted'] for result in json.loads((OUT / 'alias-review.stdout').read_text()).values()), 'A cell-only selector escaped a checked source boundary.'
run('test', [str(ROOT / 'runtime/run-dart-tests.sh'), 'test/office_vba_word_text_selectors_conformance_test.dart', '--concurrency=1', '-r', 'json'])
run('vm', [str(DART), encoded, packages, 'tool/macros/web_vba_conformance.dart'])
run('compile-js', [str(DART), 'compile', 'js', '-O2', encoded, packages, '-o', str(OUT / 'corpus.js'), 'tool/macros/web_vba_conformance.dart'])
run('node', ['node', str(OUT / 'corpus.js')])
receipt['inputs_after'] = inputs()
receipt['inputs_unchanged'] = receipt['inputs_before'] == receipt['inputs_after']
receipt['outputs_equal'] = (OUT / 'vm.stdout').read_bytes() == (OUT / 'node.stdout').read_bytes()
receipt['case_count'] = json.loads((OUT / 'vm.stdout').read_text())['caseCount']
receipt['runtime'] = {}
for name, args in [('dart', [str(DART), '--version']), ('node', ['node', '--version'])]:
    result = subprocess.run(args, capture_output=True, text=True)
    receipt['runtime'][name] = {'command': args, 'stdout': result.stdout.strip(), 'stderr': result.stderr.strip(), 'exit_code': result.returncode}
receipt['runtime']['dart']['executable_sha256'] = sha(DART)
write_receipt()
print(json.dumps({'case_count': receipt['case_count'], 'input_count': len(PATHS), 'inputs_unchanged': receipt['inputs_unchanged'], 'outputs_equal': receipt['outputs_equal'], 'runs': receipt['runs']}, indent=2))
if not receipt['inputs_unchanged'] or not receipt['outputs_equal']:
    raise SystemExit(1)
