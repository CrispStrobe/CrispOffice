import 'dart:convert';
import 'package:quds_office_engine/quds_office_automation.dart';

void main() {
  const bindings = '''
  Dim selected As Paragraphs, retained As Paragraphs
  Set selected = ThisDocument.Tables(1).Cell(1, 1).Range.Paragraphs
  Set retained = selected
  Set selected = retained
  retained.Item(Index:=1).Range.ListFormat.ApplyBulletDefault
''';
  final cases = <String, String>{
    'inactive-cell-collection-cycle':
        'Sub Main()\nEnd Sub\nSub Unused()\n$bindings\nEnd Sub',
    'active-cell-collection-cycle': 'Sub Main()\n$bindings\nEnd Sub',
    'active-cell-generic-byval': '''
Sub Main()
  Apply ThisDocument.Tables(1).Cell(1, 1).Range.Paragraphs
End Sub
Sub Apply(ByVal items As Paragraphs)
  items.Item(Index:=1).Range.ListFormat.ApplyBulletDefault
End Sub
''',
  };
  final results = <String, Object>{};
  for (final entry in cases.entries) {
    try {
      final plan = OfficeMacroLanguages().compile(OfficeMacroSource(
        language: 'vba-word',
        format: OfficeMacroFormat.docx,
        source: entry.value,
      ));
      results[entry.key] = {'accepted': true, 'steps': plan.steps.length};
    } on OfficeVbaCompileException catch (error) {
      results[entry.key] = {
        'accepted': false,
        'code': error.code,
        'line': error.line,
        'column': error.column,
      };
    }
  }
  print(jsonEncode(results));
}
