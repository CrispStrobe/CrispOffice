import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/58a062e5b571/quds_office_suite')
OUT = Path('/workspace/scratch/58a062e5b571/verification/word/broad')
ENGINE = ROOT / 'packages/quds_office_engine'


def manifest():
    paths = set(subprocess.check_output(
        ['git', 'ls-files', 'packages/quds_office_engine', 'packages/legacy_doc_parser'],
        cwd=ROOT, text=True).splitlines())
    paths.update(p.relative_to(ROOT).as_posix() for p in ENGINE.rglob('*')
                 if p.is_file() and '.dart_tool' not in p.parts
                 and 'build' not in p.parts and p.suffix in {'.dart', '.bas', '.json'})
    paths.update(['pubspec.yaml', 'pubspec.lock', '.fvmrc', '.dart_tool/package_config.json'])
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest()
            for p in sorted(paths) if (ROOT / p).is_file()}


selection = json.loads((OUT / 'selection.json').read_text())
command = ['/workspace/scratch/58a062e5b571/runtime/run-dart-tests.sh',
           '--concurrency=2', '--reporter=json', '--timeout=2x', *selection]
before = manifest()
(OUT / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
started = time.time()
with (OUT / 'tests.jsonl').open('wb') as stdout, (OUT / 'tests.stderr').open('wb') as stderr:
    run = subprocess.run(command, cwd=ENGINE, stdout=stdout, stderr=stderr)
after = manifest()
(OUT / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
starts, outcomes, errors = {}, {}, []
done = None
for line in (OUT / 'tests.jsonl').read_text().splitlines():
    try:
        event = json.loads(line)
    except json.JSONDecodeError:
        continue
    if event.get('type') == 'testStart':
        starts[event['test']['id']] = event['test']
    elif event.get('type') == 'testDone':
        outcomes[event['testID']] = event
    elif event.get('type') == 'error':
        errors.append(event)
    elif event.get('type') == 'done':
        done = event
cases = []
for test_id, test in starts.items():
    name = test['name']
    if name.startswith('loading ') or name.endswith('(setUpAll)') or name.endswith('(tearDownAll)'):
        continue
    cases.append({'name': name, 'suiteID': test['suiteID'], 'result': outcomes.get(test_id)})
passed = sum(c['result'] is not None and c['result']['result'] == 'success'
             and not c['result'].get('skipped', False) for c in cases)
skipped = sum(c['result'] is not None and c['result'].get('skipped', False) for c in cases)
unresolved = sum(c['result'] is None for c in cases)
result = {
    'command': command, 'cwd': str(ENGINE), 'startedEpoch': started,
    'elapsedSeconds': time.time() - started, 'exitCode': run.returncode,
    'suites': len(selection), 'substantiveCases': len(cases), 'passed': passed,
    'skipped': skipped, 'unresolved': unresolved, 'errors': errors,
    'done': done, 'sourceUnchanged': before == after, 'capturedInputs': len(before),
    'logs': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
             for p in [OUT / 'tests.jsonl', OUT / 'tests.stderr']},
}
(OUT / 'cases.json').write_text(json.dumps(cases, indent=2) + '\n')
(OUT / 'qualification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in {'command', 'errors'}}, indent=2))
raise SystemExit(0 if run.returncode == 0 and before == after and not errors
                 and not skipped and not unresolved else 1)
