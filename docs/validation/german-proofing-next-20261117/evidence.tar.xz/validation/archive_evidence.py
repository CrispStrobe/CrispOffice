#!/usr/bin/env python3
"""Plan, then explicitly build and verify the continuation evidence archive.

Default execution only inventories source evidence; it writes no archive.
Use --build after all producers have finished and the coordinating agent has
declared readiness. No network, Git mutation, redaction, or extraction occurs.
All source evidence is read byte-for-byte, with workspace-relative member names.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import tarfile
import tempfile


VALIDATION_DIRS = (
    "quality", "quality-final", "quality-integrated", "provider-integrated",
    "integration", "proofing", "final", "final-morphology", "spelling-fixes",
    "tooling", "office-integration-review", "integrated-final", "accepted-final",
)
RUNTIME_FILE_SUFFIXES = (".log", ".json", ".sha256")
RUNTIME_FILES = ("env.sh", "native-env.sh")
RUNTIME_DIRECTORY_PREFIXES = (
    "incremental-quality-", "merge-helper-", "german-quote-",
)
EXCLUDED_DIRS = {
    "__pycache__", "pub-cache", "flutter", "dart-sdk", "node_modules", ".git",
    ".dart_tool", ".staging", "model", "models",
}
EXCLUDED_SUFFIXES = (
    ".aot", ".so", ".pyc", ".pyo", ".dill", ".dylib", ".dll", ".exe",
    ".o", ".a", ".gguf", ".onnx", ".safetensors", ".pt", ".pth", ".staging",
)
BUILDER_MEMBER = "validation/archive_evidence.py"
OUTPUT_DIRECTORY = "docs/validation/german-proofing-next-20261117"
CHUNK = 1024 * 1024
XZ_PRESET = 9


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(CHUNK):
            result.update(chunk)
    return result.hexdigest()


def safe_member(name: str) -> None:
    path = PurePosixPath(name)
    if not name or path.is_absolute() or ".." in path.parts or str(path) != name:
        raise ValueError(f"Unsafe archive member: {name!r}")


def discover(workspace: Path) -> tuple[dict[str, Path], list[dict], list[str]]:
    selected: dict[str, Path] = {}
    excluded: list[dict] = []
    missing: list[str] = []

    def visit(path: Path) -> None:
        name = path.relative_to(workspace).as_posix()
        safe_member(name)
        info = path.lstat()
        reason = None
        if stat.S_ISLNK(info.st_mode):
            reason = "symlink not followed"
        elif stat.S_ISDIR(info.st_mode):
            if (path.name in EXCLUDED_DIRS or path.name.startswith(".staging")
                    or path.name.startswith(".gector-aot-")):
                reason = "excluded cache, model, SDK or staging directory"
            else:
                for child in sorted(path.iterdir()):
                    visit(child)
                return
        elif not stat.S_ISREG(info.st_mode):
            reason = "nonregular file"
        elif (path.name == "wortliste" or path.name.endswith(EXCLUDED_SUFFIXES)
                or ".so." in path.name):
            reason = "excluded binary, model, word-list or bytecode file"
        if reason:
            item = {"path": name, "reason": reason}
            if not stat.S_ISDIR(info.st_mode):
                item["bytes"] = info.st_size
            excluded.append(item)
            return
        selected[name] = path

    for relative in (
        *(f"validation/{name}" for name in VALIDATION_DIRS), "runtime/setup",
    ):
        path = workspace / relative
        if path.exists() or path.is_symlink():
            visit(path)
        else:
            missing.append(relative)
    runtime = workspace / "runtime"
    if runtime.is_dir() and not runtime.is_symlink():
        for path in sorted(runtime.iterdir()):
            if (path.name.endswith(RUNTIME_FILE_SUFFIXES)
                    or path.name in RUNTIME_FILES
                    or (path.is_dir()
                        and path.name.startswith(RUNTIME_DIRECTORY_PREFIXES))):
                visit(path)
    builder = workspace / BUILDER_MEMBER
    if not builder.is_file() or builder.is_symlink():
        raise ValueError(f"Missing regular archive-builder source: {builder}")
    visit(builder)
    return dict(sorted(selected.items())), sorted(excluded, key=lambda x: x["path"]), missing


def snapshot(files: dict[str, Path]) -> dict[str, dict]:
    result = {}
    for name, path in files.items():
        before = path.stat()
        value = digest(path)
        after = path.stat()
        if (before.st_size, before.st_mtime_ns, before.st_ino) != (
                after.st_size, after.st_mtime_ns, after.st_ino):
            raise RuntimeError(f"Evidence changed while hashing: {name}")
        result[name] = {"bytes": before.st_size, "sha256": value}
    return result


def verify_archive(archive: Path, expected: dict[str, dict]) -> dict:
    """Read regular members as streams; never extract a file or follow a link."""
    names = []
    with tarfile.open(archive, mode="r|xz") as package:
        for member in package:
            safe_member(member.name)
            if member.name in names or member.name not in expected:
                raise ValueError(f"Unexpected/duplicate member: {member.name}")
            if not member.isreg():
                raise ValueError(f"Nonregular member: {member.name}")
            if member.size != expected[member.name]["bytes"]:
                raise ValueError(f"Member header size mismatch: {member.name}")
            if (member.mtime, member.uid, member.gid, member.uname,
                    member.gname, member.mode) != (0, 0, 0, "", "", 0o644):
                raise ValueError(f"Nondeterministic header: {member.name}")
            stream = package.extractfile(member)
            if stream is None:
                raise ValueError(f"Missing member payload: {member.name}")
            result = hashlib.sha256()
            length = 0
            with stream:
                while chunk := stream.read(CHUNK):
                    result.update(chunk)
                    length += len(chunk)
            if {"bytes": length, "sha256": result.hexdigest()} != expected[member.name]:
                raise ValueError(f"Member byte/hash mismatch: {member.name}")
            if length != member.size:
                raise ValueError(f"Member header size mismatch: {member.name}")
            names.append(member.name)
    if names != sorted(expected):
        raise ValueError("Missing members or noncanonical member order")
    return {"bytes": archive.stat().st_size, "sha256": digest(archive)}


def estimate_size(files: dict[str, Path]) -> int:
    """Sum separately compressed payload sizes: a sizing estimate, not a bound."""
    total = 0
    for path in files.values():
        compressor = lzma.LZMACompressor(format=lzma.FORMAT_XZ, preset=XZ_PRESET)
        with path.open("rb") as source:
            while chunk := source.read(CHUNK):
                total += len(compressor.compress(chunk))
        total += len(compressor.flush())
    return total


def build(workspace: Path, repository: Path, files: dict[str, Path],
          members: dict[str, dict], excluded: list[dict], missing: list[str]) -> dict:
    if missing:
        raise ValueError(f"Required evidence roots are not ready: {missing}")
    destination = repository / OUTPUT_DIRECTORY
    archive = destination / "evidence.tar.xz"
    index = destination / "evidence-index.json"
    for path in (archive, index):
        if path.exists() or path.is_symlink():
            raise FileExistsError(f"Refusing to overwrite: {path}")
    # Stage outside the repository. Failure leaves all original evidence intact.
    stage = Path(tempfile.mkdtemp(prefix="archive-staging-", dir=workspace / "validation"))
    staged_archive = stage / archive.name
    published: list[Path] = []
    try:
        with lzma.open(staged_archive, "wb", format=lzma.FORMAT_XZ, preset=XZ_PRESET,
                       check=lzma.CHECK_CRC64) as compressed:
            with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as package:
                for name, path in files.items():
                    payload = path.read_bytes()
                    if {"bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()} != members[name]:
                        raise RuntimeError(f"Evidence changed before packaging: {name}")
                    entry = tarfile.TarInfo(name)
                    entry.size = len(payload)
                    entry.mtime = entry.uid = entry.gid = 0
                    entry.uname = entry.gname = ""
                    entry.mode = 0o644
                    entry.pax_headers = {}
                    package.addfile(entry, io.BytesIO(payload))
        archive_pin = verify_archive(staged_archive, members)
        after_files, after_excluded, after_missing = discover(workspace)
        if (snapshot(after_files) != members or after_excluded != excluded
                or after_missing != missing):
            raise RuntimeError("Evidence changed during archive construction")
        report = {
            "schema_version": 1,
            "kind": "quds-german-proofing-evidence-archive",
            "archive": {"path": archive.name, **archive_pin},
            "member_count": len(members),
            "uncompressed_member_bytes": sum(x["bytes"] for x in members.values()),
            "members": members,
            "verification": {
                "every_member_size_and_sha256_checked": True,
                "member_order_and_headers_checked": True,
                "source_snapshot_unchanged": True,
                "extraction_performed": False,
            },
            "archive_policy": {
                "format": f"PAX tar in XZ (preset {XZ_PRESET}, CRC64)",
                "member_order": "workspace-relative path, ascending",
                "mtime": 0, "uid": 0, "gid": 0, "mode": "0644",
                "uname": "", "gname": "", "regular_files_only": True,
                "content_redaction": "none; original bytes and provenance retained",
            },
            "selected_roots": [f"validation/{name}" for name in VALIDATION_DIRS],
            "runtime_scope": {
                "setup": "runtime/setup",
                "immediate_suffixes": list(RUNTIME_FILE_SUFFIXES),
                "additional_files": list(RUNTIME_FILES),
                "optional_directory_prefixes": list(RUNTIME_DIRECTORY_PREFIXES),
            },
            "excluded": excluded,
            "missing_required_inputs": missing,
            "builder": {"member": BUILDER_MEMBER, **members[BUILDER_MEMBER]},
            "reproduction": {
                "python_version": sys.version,
                "argv": [sys.executable, str(workspace / BUILDER_MEMBER),
                         "--workspace", str(workspace), "--repo", str(repository), "--build"],
                "note": "Original commands and paths identify this workspace. Reproduction on another host requires explicitly substituting locally prepared SDK, dependency, corpus and verified asset paths; no path text has been rewritten inside retained receipts.",
            },
        }
        staged_index = stage / index.name
        staged_index.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        destination.mkdir(parents=True, exist_ok=True)
        for source, target in ((staged_archive, archive), (staged_index, index)):
            os.link(source, target)  # Atomic exclusive publication; existing paths fail.
            published.append(target)
        if verify_archive(archive, members) != archive_pin:
            raise RuntimeError("Published archive does not match staged verification")
        return {"archive": str(archive), "index": str(index), **archive_pin,
                "member_count": len(members), "verified": True}
    except BaseException:
        # Only remove outputs created by this invocation, never preexisting data.
        for path in reversed(published):
            path.unlink()
        raise
    finally:
        shutil.rmtree(stage)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--repo", type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--build", action="store_true", help="Explicitly create final archive/index after producer readiness")
    mode.add_argument("--verify", action="store_true", help="Verify the existing final archive/index without extraction")
    parser.add_argument("--estimate-compressed", action="store_true", help="Plan mode only: estimate via separately compressed payloads")
    options = parser.parse_args()
    workspace = options.workspace.resolve(strict=True)
    repository = (options.repo or workspace / "quds_office_suite").resolve(strict=True)
    if Path(__file__).resolve() != workspace / BUILDER_MEMBER:
        raise ValueError("Run the builder source located inside the selected workspace")
    if not repository.is_relative_to(workspace):
        raise ValueError("The selected repository must be inside the workspace")
    if options.estimate_compressed and (options.build or options.verify):
        parser.error("--estimate-compressed is for planning only")
    if options.verify:
        root = repository / OUTPUT_DIRECTORY
        report = json.loads((root / "evidence-index.json").read_text(encoding="utf-8"))
        pin = verify_archive(root / "evidence.tar.xz", report["members"])
        if pin != {key: report["archive"][key] for key in ("bytes", "sha256")}:
            raise ValueError("Whole archive byte/hash mismatch")
        print(json.dumps({"verified": True, "member_count": len(report["members"]), **pin}, indent=2))
        return
    files, excluded, missing = discover(workspace)
    members = snapshot(files)
    if options.build:
        result = build(workspace, repository, files, members, excluded, missing)
    else:
        result = {
            "mode": "plan-only", "archive_created": False,
            "member_count": len(members),
            "uncompressed_member_bytes": sum(x["bytes"] for x in members.values()),
            "excluded": excluded, "missing_required_inputs": missing,
            "members": members,
        }
        if options.estimate_compressed:
            result["sum_separate_xz_payload_bytes"] = estimate_size(files)
            result["estimate_note"] = "Sizing estimate only. A solid tar/XZ stream and tar headers produce a different actual size."
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
