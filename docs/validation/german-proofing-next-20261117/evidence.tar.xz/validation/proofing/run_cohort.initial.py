#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse, unquote
import argparse, gzip, hashlib, json, os, shutil, subprocess, time

ROOT=Path('/workspace/scratch/52d8185c7137/quds_office_suite')
BASE=Path('/workspace/scratch/52d8185c7137/validation/proofing')
RUNTIME=Path('/workspace/scratch/52d8185c7137/runtime')
DART=RUNTIME/'flutter/bin/cache/dart-sdk/bin/dart'
FLUTTER=RUNTIME/'flutter/bin/flutter'
NATIVE=Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/assets/native-development-pack-v1')
MODEL_HASH='549ee3a5272726d48608cebdb435aaea6a984f3f53508b20b3194a7175a5ef5b'
LIB_HASH='9b0b7bcc0a5f19288d5ec3772594c6e64339becb56204276530d48e45c512604'
ENV={**os.environ,'PUB_CACHE':str(RUNTIME/'pub-cache'),'TMPDIR':str(RUNTIME/'tmp'),'FLUTTER_ROOT':str(RUNTIME/'flutter'),'CI':'true','DART_SUPPRESS_ANALYTICS':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','XDG_CONFIG_HOME':str(RUNTIME/'config'),'XDG_CACHE_HOME':str(RUNTIME/'cache'),'XDG_DATA_HOME':str(RUNTIME/'data')}
EDITOR_TESTS=['platform_spelling_provider','word_german_grammar_integration','word_hyphenation_caret','word_hyphenation_paint','word_hyphenation_resume','word_hyphenation_source_presentation','word_manual_proofing','word_proofing_context','word_proofing_correction','word_proofing_dialog','word_proofing_geometry','word_proofing_navigation','word_proofing_session']

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def save(out,name,obj): (out/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def savegz(out,name,obj):
 data=(json.dumps(obj,sort_keys=True,indent=2,ensure_ascii=False)+'\n').encode()
 (out/name).write_bytes(gzip.compress(data,mtime=0))
 return {'path':name,'entries':len(obj),'sha256':sha(out/name),'uncompressed_sha256':hashlib.sha256(data).hexdigest()}
def parse_test(log):
 tests={};done={};errors=[];finished=None;suites={}
 for line in log.read_text().split('\n'):
  if not line.strip():continue
  try:e=json.loads(line)
  except json.JSONDecodeError:continue
  if e.get('type')=='testStart': tests[e['test']['id']]=e['test']
  elif e.get('type')=='testDone':done[e['testID']]=e
  elif e.get('type')=='error':errors.append(e)
  elif e.get('type')=='done':finished=e
  elif e.get('type')=='suite':suites[e['suite']['id']]=e['suite']
 substantive=[(t,done.get(i)) for i,t in tests.items() if not t.get('metadata',{}).get('hidden',False) and not t['name'].startswith('loading ')]
 counts={'started':len(substantive),'passed':sum(d is not None and d.get('result')=='success' and not d.get('skipped',False) for t,d in substantive),'skipped':sum(d is not None and d.get('skipped',False) for t,d in substantive),'failed':sum(d is not None and d.get('result')!='success' for t,d in substantive),'unfinished':sum(d is None for t,d in substantive),'errors':errors,'final_event':finished,'suites':list(suites.values())}
 return counts

def external_inputs():
 config=ROOT/'.dart_tool/package_config.json'
 paths={config, DART,DART.parent/'dartaotruntime',FLUTTER,RUNTIME/'flutter/bin/cache/flutter_tools.snapshot',RUNTIME/'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',Path(shutil.which('node')).resolve()}
 package_roots=[]
 for p in json.loads(config.read_text())['packages']:
  uri=urljoin(config.as_uri(),p['rootUri']);parsed=urlparse(uri)
  if parsed.scheme!='file':raise RuntimeError('Unexpected package URI '+uri)
  base=Path(unquote(parsed.path)).resolve()
  if base.is_relative_to(ROOT):continue
  package_roots.append({'name':p['name'],'root':str(base)})
  if (base/'pubspec.yaml').is_file():paths.add(base/'pubspec.yaml')
  lib=base/p.get('packageUri','lib/')
  if lib.is_dir():paths.update(x for x in lib.rglob('*') if x.is_file())
 return paths,package_roots

def main():
 parser=argparse.ArgumentParser();parser.add_argument('cohort',choices=['engine_vm','engine_node','editor','gector']);args=parser.parse_args();group=args.cohort
 out=BASE/group;out.mkdir(exist_ok=False)
 engine=ROOT/'packages/quds_office_engine';editor=ROOT/'packages/quds_office_editor';gector=ROOT/'packages/quds_proofing_gector'
 packages=[engine,ROOT/'packages/legacy_doc_parser']
 if group.startswith('engine_'):
  cwd=engine;tests=sorted((engine/'test/proofing').rglob('*.dart'))
  argv=[str(DART),'test','--reporter=json','--concurrency=2']+(['--platform=node'] if group=='engine_node' else [])+['test/proofing']
 elif group=='editor':
  cwd=editor;tests=[editor/'test'/(n+'_test.dart') for n in EDITOR_TESTS];packages+=[editor,ROOT/'packages/quds_proofing_harper']
  argv=[str(FLUTTER),'test','--no-pub','--reporter=json','--concurrency=2',*[str(p.relative_to(editor)) for p in tests]]
 else:
  cwd=gector;tests=sorted((gector/'test').rglob('*'));tests=[p for p in tests if p.is_file()];packages+=[gector]
  argv=[str(DART),'test','--reporter=json','--concurrency=2']
  ENV.update({'CRISPEMBED_GECTOR':'1','GECTOR_TEST_MODEL':str(NATIVE/'model'/MODEL_HASH/'gector-de-mixed-q4_k.gguf'),'GECTOR_TEST_MODEL_SHA256':MODEL_HASH,'GECTOR_TEST_LIBRARY':str(NATIVE/'native'/LIB_HASH/'libcrispembed-gector.so'),'GECTOR_TEST_LIBRARY_SHA256':LIB_HASH})
 source={ROOT/'pubspec.yaml',ROOT/'pubspec.lock',ROOT/'analysis_options.yaml'}|set(tests)
 for pkg in packages:
  source.update(p for p in (pkg/'lib').rglob('*') if p.is_file())
  for name in ['pubspec.yaml','analysis_options.yaml']:
   if (pkg/name).is_file():source.add(pkg/name)
 if group=='gector':source.update(p for p in (gector/'tool').rglob('*') if p.is_file() and '__pycache__' not in p.parts)
 runtime,package_roots=external_inputs()
 if group=='gector':runtime.update(p for p in NATIVE.rglob('*') if p.is_file())
 def snap(paths,repo=False):return {str(p.relative_to(ROOT)) if repo else str(p):sha(p) for p in sorted(paths)}
 before=snap(source,True);runtime_before=snap(runtime)
 save(out,'inputs-before.json',before);runtime_input=savegz(out,'runtime-before.json.gz',runtime_before)
 receipt={'cohort':group,'started_at':now(),'source_head':git('rev-parse','HEAD'),'source_tree':git('rev-parse','HEAD^{tree}'),'input_policy':'Actual file hashes, not HEAD alone, identify tested source. Maps include full selected workspace libraries, selected tests, configuration/lock, all activated external package libraries, launchers/runtime executables, and explicit native fixture assets when used.','source_files':len(source),'runtime_inputs':runtime_input,'package_roots':package_roots,'test_files':[str(p.relative_to(ROOT)) for p in tests],'argv':argv,'cwd':str(cwd),'dart_version':subprocess.check_output([str(DART),'--version'],env=ENV,text=True).strip(),'node_version':subprocess.check_output([shutil.which('node'),'--version'],text=True).strip(),'native_env':{k:ENV[k] for k in ENV if k.startswith('GECTOR_TEST_') or k=='CRISPEMBED_GECTOR'},'status':'running'}
 save(out,'receipt.json',receipt);print('START '+group,flush=True)
 start=time.monotonic();log=out/'tests.jsonl'
 with log.open('wb') as f:
  try:cp=subprocess.run(argv,cwd=cwd,env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=1200);code=cp.returncode
  except subprocess.TimeoutExpired:code=124
 after=snap(source,True);runtime_after=snap(runtime)
 save(out,'inputs-after.json',after);after_manifest=savegz(out,'runtime-after.json.gz',runtime_after)
 tests_result=parse_test(log);changed=[p for p,h in before.items() if after.get(p)!=h];runtime_changed=[p for p,h in runtime_before.items() if runtime_after.get(p)!=h]
 receipt.update({'finished_at':now(),'exit_code':code,'elapsed_seconds':time.monotonic()-start,'source_head_after':git('rev-parse','HEAD'),'source_changes':changed,'runtime_changes':runtime_changed,'runtime_inputs_after':after_manifest,'log':'tests.jsonl','log_sha256':sha(log),'tests':tests_result,'status':'passed' if code==0 and not changed and not runtime_changed and not tests_result['failed'] and not tests_result['unfinished'] and not tests_result['errors'] and tests_result['final_event'] and tests_result['final_event'].get('success') else 'failed'})
 save(out,'receipt.json',receipt);print(json.dumps({k:receipt[k] for k in ['cohort','status','exit_code','elapsed_seconds','source_changes','runtime_changes','tests']}),flush=True)
 return 0 if receipt['status']=='passed' else 1
if __name__=='__main__':raise SystemExit(main())
