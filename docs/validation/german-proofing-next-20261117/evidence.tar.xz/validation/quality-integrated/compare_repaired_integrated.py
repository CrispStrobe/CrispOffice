#!/usr/bin/env python3
"""Compare every quality outcome across the repaired and integrated sources."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before', required=True, type=Path)
    parser.add_argument('--after', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists():
        parser.error('Refusing to overwrite evidence.')
    before_audit = json.loads((args.before / 'audit_final.json').read_text())
    after_audit = json.loads((args.after / 'audit_integrated.json').read_text())
    assert before_audit['passed'] and after_audit['passed']
    result = {
        'kind': 'repaired-to-integrated-german-quality-comparison',
        'before_source': before_audit['source_commit'],
        'after_source': after_audit['source_commit'],
        'scope': 'All case declarations, findings, statuses, merge decisions and diagnostic projections; only per-case timing_ms excluded.',
        'script_sha256': sha(Path(__file__)),
        'audits': {
            'before_sha256': sha(args.before / 'audit_final.json'),
            'after_sha256': sha(args.after / 'audit_integrated.json'),
        },
        'panels': {},
    }
    for panel in ['frozen', 'prospective']:
        bp, ap = args.before / (panel + '.json'), args.after / (panel + '.json')
        before, after = json.loads(bp.read_text()), json.loads(ap.read_text())
        assert sha(bp) == before_audit['panels'][panel]['report_sha256']
        assert sha(ap) == after_audit['panels'][panel]['report_sha256']
        for field in ['declared_cases', 'cases_sha256', 'model',
                      'native_library_sha256', 'bundle_assets',
                      'projection_policy', 'vocabulary']:
            assert before[field] == after[field], (panel, field)
        assert [x['id'] for x in before['cases']] == [x['id'] for x in after['cases']]
        differences = []
        lanes = 0
        for a, b in zip(before['cases'], after['cases']):
            aa = {k: v for k, v in a.items() if k != 'timing_ms'}
            bb = {k: v for k, v in b.items() if k != 'timing_ms'}
            lanes += len(a['outcomes'])
            if aa != bb:
                differences.append({'id': a['id'], 'before': aa, 'after': bb})
        assert before['summary'] == after['summary'], panel + ' summary changed'
        result['panels'][panel] = {
            'before_sha256': sha(bp), 'after_sha256': sha(ap),
            'case_rows_compared': len(before['cases']),
            'lane_outcomes_compared': lanes,
            'differences': differences,
            'identical_outcomes': not differences,
        }
    old_build = json.loads((args.before / 'build.json').read_text())
    new_build = json.loads((args.after / 'build.json').read_text())
    assert old_build['sdk_inputs'] == new_build['sdk_inputs']
    old, new = old_build['source_files'], new_build['source_files']
    result['selected_source_changes'] = {
        name: {'before_sha256': old.get(name), 'after_sha256': new.get(name)}
        for name in sorted(old.keys() | new.keys()) if old.get(name) != new.get(name)
    }
    result['passed'] = all(p['identical_outcomes'] for p in result['panels'].values())
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({'passed': result['passed'], 'panels': {
        name: {k: v for k, v in p.items() if k not in ['differences']}
        for name, p in result['panels'].items()},
        'selected_source_changes': list(result['selected_source_changes'])}))
    if not result['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
