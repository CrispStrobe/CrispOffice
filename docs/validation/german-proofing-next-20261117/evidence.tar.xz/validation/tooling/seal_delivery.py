#!/usr/bin/env python3
"""Write compact delivery receipts from the preserved, source-specific evidence."""
import hashlib
import json
from pathlib import Path
import subprocess

WORKSPACE = Path(__file__).resolve().parents[2]
REPO = WORKSPACE / 'quds_office_suite'
OUT = REPO / 'docs/validation/german-proofing-next-20261117'
ACCEPTED = '6971819edfb53ed40e97fc2b4cd436e89a39a648'


def load(name):
    return json.loads((WORKSPACE / name).read_text())


def pin(name):
    raw = (WORKSPACE / name).read_bytes()
    return {'archive_member': name, 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO,
                                   text=True).strip() == ACCEPTED
    old = load('validation/final/proofing/final-source-binding.json')
    accepted = load('validation/accepted-final/proofing/final-source-binding.json')
    core = load('validation/accepted-final/prior-c9-continuity.json')
    model = load('validation/accepted-final/retained-gector-native-quality.json')
    quality = load('validation/quality-integrated/audit_integrated.json')
    provider = load('validation/provider-integrated/provider.json')
    native = load('validation/provider-integrated/audit-final.json')
    run = load('validation/provider-integrated/run.json')
    python = load('validation/tooling/python-integrated.json')
    for record in [old, accepted, core, model]:
        assert record['status'] == 'passed'
    for record in [quality, native, run, python]:
        assert record['passed']
    assert provider['all_requested_checks_passed'] and provider['source_stable']
    assert accepted['source_commit'] == ACCEPTED
    assert native['source_sha'] == run['source_sha'] == ACCEPTED

    rows = [
        ('Engine proofing, VM', 602, 0, old['source_commit'],
         'validation/final/proofing/engine_vm/receipt.json'),
        ('Engine proofing, compiled JavaScript/Node', 602, 0, old['source_commit'],
         'validation/final/proofing/engine_node/receipt.json'),
        ('Flutter proofing/correction/hyphenation', 176, 0, old['source_commit'],
         'validation/final/proofing/editor/receipt.json'),
        ('GECToR, including real native fixture', 194, 0,
         '121f3be504a89e56bde40bda8f93f4e81d8c2503',
         'validation/integrated-final/proofing/gector/receipt.json'),
        ('Office preservation, VM', 380, 0, ACCEPTED,
         'validation/accepted-final/integration/receipt.json'),
        ('Portable Office and separately selected shading regression, Node',
         307, 0, ACCEPTED, 'validation/accepted-final/integration-node/receipt.json'),
        ('Python qualification controls', 107, 1, ACCEPTED,
         'validation/tooling/python-integrated.json'),
    ]
    checks = []
    for label, count, skipped, commit, name in rows:
        record = load(name)
        assert record.get('status', 'passed' if record.get('passed') else None) == 'passed', name
        events = ([record['tests']] if 'tests' in record else
                  [x['tests'] for x in record.get('commands', []) if 'tests' in x])
        if events:
            assert sum(x['passed'] for x in events) == count, name
            assert sum(x.get('failed', 0) for x in events) == 0, name
            assert sum(x.get('skipped', 0) for x in events) == skipped, name
        else:
            assert 'Ran 108 tests' in '\n'.join(record['tail'])
            assert record['tail'][-1] == 'OK (skipped=1)'
        checks.append({'name': label, 'passed': count, 'skipped': skipped,
                       'failed': 0, 'tested_source': commit, 'evidence': pin(name)})

    binding = {
        'schema_version': 1, 'status': 'passed',
        'accepted_product_source': ACCEPTED,
        'source_tree': accepted['source_tree'],
        'interpretation': 'Historical executions retain their original source attribution. Continuity audits name unchanged relevant inputs and all broader-map Office differences; fresh affected Office runs qualify those differences.',
        'fresh_accepted_office': {
            'source_inputs': accepted['source_inputs'],
            'declared_runtime_inputs': accepted['declared_runtime_inputs'],
            'issues': accepted['issues'],
            'seal': pin('validation/accepted-final/proofing/final-source-binding.json'),
        },
        'retained_proofing_and_flutter': {
            'tested_source': old['source_commit'],
            'original_source_inputs': old['source_inputs'],
            'original_runtime_inputs': old['declared_runtime_inputs'],
            'unchanged_core_paths': 222,
            'broader_map_exceptions': [
                'packages/quds_office_engine/lib/src/extract/office_text_extractor.dart',
                'packages/quds_office_engine/lib/src/odf/odf_text.dart',
                'packages/quds_office_engine/lib/src/slide/serial/odp_presentation_writer.dart',
                'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart'],
            'original_seal': pin('validation/final/proofing/final-source-binding.json'),
            'continuity': pin('validation/accepted-final/prior-c9-continuity.json'),
        },
        'retained_gector_and_incremental_quality': {
            'tested_source': '121f3be504a89e56bde40bda8f93f4e81d8c2503',
            'unchanged_model_related_inputs': 98,
            'unchanged_unique_quality_inputs': 70,
            'gector_broader_map_exception': 'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart',
            'continuity': pin('validation/accepted-final/retained-gector-native-quality.json'),
            'independent_quality_audit': pin('validation/quality-integrated/audit_integrated.json'),
        },
        'fresh_segmented_native_provider': {
            'tested_source': ACCEPTED,
            'build': pin('validation/provider-integrated/build-final.json'),
            'run': pin('validation/provider-integrated/run.json'),
            'independent_audit': pin('validation/provider-integrated/audit-final.json'),
            'source_binding': native['source_binding'],
        },
    }
    save('source-binding.json', binding)
    verification = {
        'schema_version': 1, 'status': 'passed',
        'accepted_product_source': ACCEPTED,
        'branch': 'codex/german-morphology-20261117', 'followup_pr': 114,
        'prior_pr': {'number': 105, 'merged_externally': True,
                     'merged_head': '6f1abf273bd10d7ebe5641661dd307c492f897c2'},
        'ci': 'No GitHub Actions workflow dispatched, awaited, or used as a gate. No CI-status endpoints queried.',
        'tests': checks,
        'counting_policy': 'Cohorts overlap; VM and Node repeat the same cases. Do not sum these counts as unique tests. Evidence assertions are not tests.',
        'analysis': [
            {'scope': 'Full engine and affected Office', 'status': 'no issues', 'tested_source': ACCEPTED},
            {'scope': 'GECToR, native and incremental-quality runners', 'status': 'no issues',
             'tested_source': '121f3be504a89e56bde40bda8f93f4e81d8c2503'},
            {'scope': 'Editor proofing', 'status': 'no issues', 'tested_source': old['source_commit']},
        ],
        'source_binding': 'source-binding.json',
        'native_quality': {'source': quality['source_commit'],
                           'summary': 'integrated-quality/summary.json',
                           'comparison': 'quality-comparison.json'},
        'segmented_native': {
            'source': ACCEPTED, 'report': 'provider-segmented.json.gz',
            'setup_ms': provider['setup_ms'],
            'short_timing': provider['warm_checks_up_to_64_wordpieces'],
            'peak_process_rss_bytes': provider['peak_process_rss_bytes'],
            'engineering_budgets': provider['engineering_budgets'],
            'operational_controls_passed': len(provider['controls']),
            'segmentation_controls_passed': len(provider['segmentation_controls']),
            'interpretation': 'One Linux host, two native threads, one warmup and three measured repetitions per input. Repeated-sentence structural probes are not a representative long-document quality evaluation or evidence of a speedup over previous runs.'},
        'morphology': {'comparison': 'morphology-comparison.json',
                       'records_per_runtime': 1700, 'changed_records': 0,
                       'core_exact': '70/81', 'core_clean_flags': '0/175',
                       'review_exact': '24/24', 'review_clean_flags': '0/60'},
        'preserved_failures_and_qualifications': [
            'Exact quotation regression and six lexical tests fail before the spelling repairs.',
            'Initial Flutter wrapper stamp race; accepted analysis uses the direct SDK.',
            'Earlier incomplete GECToR input capture and Flutter hidden-lifecycle counting correction are retained.',
            'At121f the Office VM and Node selections each fail the same conflicting empty-document test. Both corrected selections pass at6971819.',
            'First provider AOT build fails because the default temporary directory is absent; fresh output paths and an existing scratch TMPDIR produce sealed successful builds.',
            'An initial continuity audit treats declared-corpus as a literal path; the corrected alias-aware audit and correction receipt are both retained.',
            'One tiny ONNX converter control remains explicitly skipped because optional development dependencies are absent.'
        ],
        'remaining_limits': [
            'Synthetic panels establish bounded regressions, not representative German precision/recall or exclusion from model training.',
            'Post-repair measurements use a panel that informed repairs and are not fresh prospective evidence.',
            'First-replacement projection is a diagnostic convention; the editor presents reviewable suggestions.',
            'Contextual accusative, participle and word-order errors remain.',
            'de-AT/de-CH model support, target-device performance, exact native distribution acceptance and default/background inference remain unqualified or unimplemented.',
            'Segmented structural probes at256 logical tokens and above exceed500ms; the500ms budget applies only to the pooled short cohort.'
        ],
    }
    save('verification.json', verification)
    print(json.dumps({'status': 'passed', 'tests': [(c['name'], c['passed']) for c in checks],
                      'source': ACCEPTED}))


if __name__ == '__main__':
    main()
