#!/usr/bin/env python3
"""Complete the reviewed report draft with sealed qualification results."""
from pathlib import Path

workspace = Path(__file__).resolve().parents[2]
text = (workspace / 'validation/tooling/report-draft.md').read_text()


def replace(old, new):
    global text
    assert old in text, old[:100]
    text = text.replace(old, new, 1)


replace('at **15:44:28 UTC**', 'at **16:44:28 CET (15:44:28 UTC)**')
replace('snapshot at **15:47:52 UTC**', 'snapshot at **16:47:52 CET (15:47:52 UTC)**')
replace('is genuinely prospective', 'is prospective')
replace(
    'The captured integration checkpoint is **`121f3be504a89e56bde40bda8f93f4e81d8c2503`** on `codex/german-morphology-20261117`.',
    'The accepted product source is **`6971819edfb53ed40e97fc2b4cd436e89a39a648`** on `codex/german-morphology-20261117`. The captured integration checkpoint is `121f3be504a89e56bde40bda8f93f4e81d8c2503`; the accepted source also includes the subsequently observed main commit `7cf48a2f` for paragraph shading and borders and the reconciled empty-document test.')
replace(
    'It does not claim results for the later integrated segmentation implementation.',
    'Fresh default-decoder execution after the segmentation integration at `121f3be5` independently reproduces all **106 case rows and 424 substantive lane outcomes** from the repaired run. Only timing observations differ. The selected quality inputs remain unchanged in accepted source `6971819e`; the conservative resolved-library graph also contains the separately tested Office writer changes. [Integrated summary](integrated-quality/summary.json) · [Complete integration comparison](quality-comparison.json)')
replace('[Complete comparison](quality-comparison.json)', '[Complete spelling comparison](spelling-quality-comparison.json)')
replace(
    '## Incoming histories and Office preservation',
    'The lexical generator was rerun against the same pinned MIT word list, SHA-256 `55b457fac8e322146853f45bbda59046a55496a3e3deb32d3a88feb908eca243`. Its check mode passed before and after regeneration. Decoding both generated supplements confirms exactly three added forms—`Hof`, `Grüezi`, and `grüezi`—and no removals. Standard forms increase from 444,130 to 444,133; the 9,451 Swiss additions and every upstream shard are unchanged. [Generator audit](lexicon-generation.json)\n\n## Incoming histories and Office preservation')
replace(
    'Source comparison confirms that the combined ODT writer equals captured main `9941c80d` plus the incoming empty-document guard.',
    'Source comparison at `121f3be5` confirms that the combined ODT writer equals captured main `9941c80d` plus the incoming empty-document guard.')
replace(
    'the continuation regression file exactly matches `a499549e`.',
    'the initially integrated continuation regression file exactly matches `a499549e`. The final bounded main update adds six writer lines for paragraph shading/borders and its writer regression; no proofing or model source changes in that update.')
replace(
    'The first integrated Office VM run exposed one contradictory inherited test expectation: **378 passed, one errored**. The continuation test expected a synthetic `SB0` paragraph for an explicitly zero-section document; the preserved writer and two other tests require an empty body with default styles. The intended reconciliation changes only that stale body assertion, retaining its default master/layout geometry and model-immutability checks. Authored empty sections still require their actual boundary anchors. **Reconciliation and final rerun: PENDING.** The failed attempt remains part of the evidence.',
    'The first integrated Office run exposed one contradictory inherited test expectation: **378 passed and one failed on VM; 305 passed and one failed on Node**. The continuation test expected a synthetic `SB0` paragraph for an explicitly zero-section document; the preserved writer and two other tests require an empty body with default styles. The accepted source changes only that stale assertion, retaining all default master/layout geometry and model-immutability checks. Authored empty sections still require their actual boundary anchors. The fresh accepted runs pass **380 VM tests and 307 Node tests**, including the arriving shading regression. Both failed attempts remain in the evidence.')
replace(
    'Incoming provider history also adds bounded, opt-in segmentation and decoder/guard changes. **Integrated quality and test results: PENDING.** Record fresh measurements in [integrated-quality/summary.json](integrated-quality/summary.json); the earlier `c9bf` results above must not be relabeled as measurements of the combined provider.',
    '''## Real native segmentation qualification

Incoming provider history adds bounded, opt-in segmentation and decoder/guard changes. A fresh compiled provider at accepted source `6971819e`, using `--segment-target-tokens 64`, passes all eight original operational controls and six additional segmented controls. The latter verify a late correction at original UTF-16 span **2543–2547**, request offset **137** and an initial emoji; protected code; and whole-request rejection at native-sequence, total-token, segment-count and source-length limits. Capacity failures publish no partial suggestions. Five compiled CLI controls reject invalid, out-of-range, duplicate or unknown options before model loading.

The frozen guarded result remains **6/18 exact corrections, 0/10 supported clean controls changed and two Swiss cases explicitly unsupported**. Its strict historical comparison preserves all five earlier fixes and adds the already integrated `verb-wir` alias correction. This is separate from the combined editor evaluation above.

The run used two native threads, one warmup and three measured repetitions per input. Other local test, analysis and hashing jobs had completed before timing. The 87-sample pooled short cohort and peak memory meet the provisional host budgets:

| Measurement | Fresh accepted run |
| --- | ---: |
| Model verification, dictionary and worker startup | 3.223 s |
| Pooled warm median through 64 logical WordPieces | 22.886 ms |
| Pooled warm p95 through 64 logical WordPieces | 62.875 ms |
| Peak whole-process RSS | 359.6875 MiB |
| Pinned mixed Q4_K model | 82,756,896 bytes |

| Structural probe: logical tokens | Segments | Actual initial model tokens | Warm p95 |
| ---: | ---: | ---: | ---: |
| 61 | 1 | 61 | 167.485 ms |
| 126 | 3 | 128 | 395.586 ms |
| 256 | 5 | 260 | 840.740 ms |
| 636 | 11 | 646 | 1,705.884 ms |
| 1,276 | 22 | 1,297 | 3,732.003 ms |

The complete original source is partitioned and covered in every long probe. Actual model-token totals include each segment's terminal handling and CLS/SEP tokens, so they differ from logical original-text counts. The 636- and 1,276-token probes establish bounded operation beyond a single native sequence; they do not establish a speedup. The 256-token and larger probes still exceed 500 ms. Repeated grammatical sentences are structural controls, not representative long-document language evaluation or target-device qualification.

The independent audit reconstructs 84 retained results, 15 edits, 94 source segments and 105 timing samples. The producer records output stability over all repeats; only the warmup and first measured output are retained per measured input, so the independent audit does not claim access to omitted repeat outputs. Source, dependency, SDK, model, native library, executable and reference identities are stable before and after execution. The first AOT attempt's absent temporary directory and subsequent successful builds are retained separately. [Complete native report](provider-segmented.json.gz) · [Independent audit](provider-audit.json) · [Build](provider-build.json.gz) · [Run closure](provider-run.json.gz)''')
start = text.index('| Check | Qualified result | Source scope |')
end = text.index('\nThe shared merge helper', start)
text = text[:start] + '''| Check | Qualified result | Tested source |
| --- | ---: | --- |
| Engine proofing, Dart VM | **602 passed** | `c9bf20a6` |
| Engine proofing, JavaScript/Node | **602 passed** | `c9bf20a6` |
| Focused Flutter proofing, correction and hyphenation | **176 passed** | `c9bf20a6` |
| GECToR package, real native fixture included | **194 passed, zero skipped** | `121f3be5` |
| Office export, extraction and preservation, VM | **380 passed** | `6971819e` |
| Portable Office cohort plus shading regression, Node | **307 passed** | `6971819e` |
| Python qualification controls | **107 passed, one explicit skip** | `6971819e` |
| Full engine, editor, GECToR, runner and affected Office strict analysis | **No issues** | Recorded source-specific receipts |
| Native segmented provider AOT build and execution | **Passed** | `6971819e` |

These counts retain their original execution sources. The accepted Office seal binds **755 source inputs and 5,020 runtime inputs** with no mismatch. Explicit continuity audits find **222 unchanged proofing/editor core paths**, **98 unchanged model-related inputs**, and **70 unchanged named quality inputs**. Four incoming Office implementation paths differ in the broad earlier engine maps; the final Office checks above cover those changes. The wider GECToR map differs only in the ODT writer. Historical executions are not relabeled as fresh runs at the accepted commit. The Python skip requires absent optional development-only converter dependencies. [Core continuity](proofing-continuity.json) · [Model/quality continuity](model-continuity.json)
''' + text[end:]
replace(
    'The [evidence archive](evidence.tar.xz), [member hashes](evidence-index.json), build/run receipts and comparison files preserve exact commands, failures and runtime identities.',
    'The [evidence archive](evidence.tar.xz), [member hashes](evidence-index.json), build/run receipts and comparison files preserve exact command output, failed validation attempts and runtime identities. Member payloads are byte-exact, including original infrastructure paths; adjust command paths when reproducing elsewhere. SDKs, caches, model/native binaries and AOT executables are excluded, with their identities retained in the receipts. The archive verifies every member without extraction.')
assert 'PENDING' not in text
out = workspace / 'quds_office_suite/docs/validation/german-proofing-next-20261117/README.md'
out.write_text(text)
print('Report written:', len(text.split()), 'words')
