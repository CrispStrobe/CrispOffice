"""Isolated evidence-archive contract controls; no real report is published."""

import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest


SOURCE = Path(__file__).resolve().parents[1] / "archive_evidence.py"
SPEC = importlib.util.spec_from_file_location("archive_evidence_controls", SOURCE)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class ArchiveControls(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(
            prefix="archive-controls-", dir=SOURCE.parent)
        self.addCleanup(self.temporary.cleanup)
        self.workspace = Path(self.temporary.name)
        self.repo = self.workspace / "quds_office_suite"
        self.repo.mkdir()
        for name in MODULE.VALIDATION_DIRS:
            (self.workspace / "validation" / name).mkdir(parents=True)
        (self.workspace / "runtime/setup").mkdir(parents=True)
        self.builder = self.workspace / MODULE.BUILDER_MEMBER
        shutil.copyfile(SOURCE, self.builder)
        self.log = self.workspace / "runtime/setup/failed-run.log"
        self.raw = "FAILED: retained /workspace/example source path\nGrüezi\n".encode()
        self.log.write_bytes(self.raw)
        (self.workspace / "validation/quality/receipt.json.gz").write_bytes(
            gzip.compress(b'{"completed":false}\n', mtime=0))
        (self.workspace / "validation/final-morphology/probe.js").write_text("// compiled JS\n")
        (self.workspace / "validation/final-morphology/probe.js.deps").write_text("source.dart\n")
        for relative in ["validation/quality/model.aot", "validation/quality/native.so",
                         "validation/quality/model.gguf"]:
            (self.workspace / relative).write_bytes(b"excluded binary")
        forbidden = self.workspace / "runtime/flutter"
        forbidden.mkdir()
        (forbidden / "sdk.log").write_bytes(b"SDK must not be visited")
        (self.workspace / "validation/quality/outside-link").symlink_to(self.log)

    def command(self, *arguments, repo=None):
        return subprocess.run(
            [sys.executable, str(self.builder), "--workspace", str(self.workspace),
             "--repo", str(repo or self.repo), *arguments],
            capture_output=True, text=True, check=False)

    def build(self):
        result = self.command("--build")
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_plan_never_creates_archive_and_excludes_binaries_sdk_links(self):
        result = self.command()
        self.assertEqual(result.returncode, 0, result.stderr)
        plan = json.loads(result.stdout)
        self.assertFalse(plan["archive_created"])
        self.assertIn(MODULE.BUILDER_MEMBER, plan["members"])
        self.assertIn("validation/final-morphology/probe.js.deps", plan["members"])
        self.assertEqual(len(plan["excluded"]), 4)
        self.assertFalse(any("flutter" in name for name in plan["members"]))
        self.assertFalse((self.repo / MODULE.OUTPUT_DIRECTORY).exists())

    def test_build_preserves_bytes_and_is_deterministic_with_normalized_headers(self):
        first = self.build()
        other = self.workspace / "other-repository"
        other.mkdir()
        second = self.command("--build", repo=other)
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertEqual(first["sha256"], json.loads(second.stdout)["sha256"])
        with tarfile.open(first["archive"], "r:xz") as package:
            self.assertEqual(package.extractfile("runtime/setup/failed-run.log").read(), self.raw)
        verified = self.command("--verify")
        self.assertEqual(verified.returncode, 0, verified.stderr)
        self.assertTrue(json.loads(verified.stdout)["verified"])

    def test_overwrite_is_rejected_without_changing_prior_archive(self):
        first = self.build()
        result = self.command("--build")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Refusing to overwrite", result.stderr)
        self.assertEqual(hashlib.sha256(Path(first["archive"]).read_bytes()).hexdigest(), first["sha256"])

    def test_member_hash_and_source_mutation_fail_closed(self):
        files, excluded, missing = MODULE.discover(self.workspace)
        members = MODULE.snapshot(files)
        self.log.write_bytes(self.raw + b"late mutation\n")
        with self.assertRaisesRegex(RuntimeError, "changed before packaging"):
            MODULE.build(self.workspace, self.repo, files, members, excluded, missing)
        self.assertFalse((self.repo / MODULE.OUTPUT_DIRECTORY / "evidence.tar.xz").exists())
        first = self.build()
        report = json.loads(Path(first["index"]).read_text())
        report["members"]["runtime/setup/failed-run.log"]["sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "byte/hash mismatch"):
            MODULE.verify_archive(Path(first["archive"]), report["members"])

    def test_required_missing_root_prevents_incomplete_publication(self):
        (self.workspace / "validation/accepted-final").rmdir()
        result = self.command("--build")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Required evidence roots are not ready", result.stderr)
        self.assertFalse((self.repo / MODULE.OUTPUT_DIRECTORY / "evidence.tar.xz").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
