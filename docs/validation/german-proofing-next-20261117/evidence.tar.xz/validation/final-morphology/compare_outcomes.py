#!/usr/bin/env python3
"""Compare every retained morphology outcome to the published f986fd03 archive.

No source or corpus writes. The comparison report is a fresh output file.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile


BASELINE = "f986fd031e4f984200c392e844ad83ae1ef5eb24"
FINAL_SOURCE = "c9bf20a6f35e6c4607b9377716968f84c3bc67bb"
ARCHIVE = "docs/validation/german-proofing-continuation-20261117/local-evidence.tar.xz"
INDEX = "docs/validation/german-proofing-continuation-20261117/evidence-index.json"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical_digest(value):
    return digest(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def records(rows):
    indexed = {}
    for row in rows:
        key = (row["id"], row["variant"])
        assert key not in indexed, f"Duplicate result identity: {key}"
        indexed[key] = row
    return indexed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    root, output = args.repo.resolve(), args.output_dir.resolve()
    index_bytes = subprocess.check_output(["git", "show", f"{BASELINE}:{INDEX}"], cwd=root)
    index = json.loads(index_bytes)
    archive = root / ARCHIVE
    archive_bytes = archive.read_bytes()
    assert digest(archive_bytes) == index["sha256"]
    assert len(archive_bytes) == index["bytes"]
    inventory = {entry["path"]: entry for entry in index["files"]}
    report = {
        "kind": "complete-morphology-outcome-comparison",
        "compared_at_utc": datetime.now(timezone.utc).isoformat(),
        "baseline_published_commit": BASELINE,
        "final_source_commit": FINAL_SOURCE,
        "archive": ARCHIVE,
        "archive_sha256": digest(archive_bytes),
        "archive_index_sha256": digest(index_bytes),
        "comparison_script_sha256": digest(Path(__file__).read_bytes()),
        "github_actions_used": False,
        "scope": "All fields of every core and review corpus outcome, including four prose variants and protected code, compared separately on VM and Node. This is deterministic writing-rule regression coverage, not population accuracy or the model quality panel.",
        "runs": {},
    }
    with tarfile.open(archive) as bundle:
        def retained(member):
            raw = bundle.extractfile(member).read()
            assert digest(raw) == inventory[member]["sha256"], member
            assert len(raw) == inventory[member]["bytes"], member
            return raw, json.loads(raw)

        for name, current_dir, historical, corpus_path in (
            ("core", output, "final/corpus", "tools/proofing/german_morphology_cases.json"),
            ("review", output / "review", "final/review-corpus", "tools/proofing/german_morphology_review_cases.json"),
        ):
            before_receipt_raw, before_receipt = retained(f"{historical}/receipt.json")
            receipt_raw = (current_dir / "receipt.json").read_bytes()
            receipt = json.loads(receipt_raw)
            assert receipt["status"] == "passed"
            assert receipt["source_head"] == FINAL_SOURCE
            assert not receipt["source_dirty_files"]
            for key in ("source_unchanged", "probe_unchanged", "runtimes_unchanged", "vm_node_semantically_equal"):
                assert receipt[key] is True, (name, key)
            assert all(command["exit_code"] == 0 for command in receipt["commands"])
            for key in ("corpus_sha256", "runner_sha256", "harness_sha256"):
                assert receipt[key] == before_receipt[key], (name, key)
            corpus_bytes = (root / corpus_path).read_bytes()
            assert digest(corpus_bytes) == receipt["corpus_sha256"]
            committed_inputs = {}
            for path, sha in receipt["source_inputs_sha256"].items():
                if path.startswith("dependency:"):
                    continue
                committed = subprocess.check_output(["git", "show", f"{FINAL_SOURCE}:{path}"], cwd=root)
                committed_inputs[path] = digest(committed) == sha
            assert all(committed_inputs.values())
            before_sources, after_sources = before_receipt["source_inputs_sha256"], receipt["source_inputs_sha256"]
            source_changes = [
                {"path": path, "before_sha256": before_sources.get(path), "after_sha256": after_sources.get(path)}
                for path in sorted(set(before_sources) | set(after_sources))
                if before_sources.get(path) != after_sources.get(path)
            ]
            run = {
                "corpus": corpus_path,
                "corpus_sha256": receipt["corpus_sha256"],
                "runner_sha256": receipt["runner_sha256"],
                "harness_sha256": receipt["harness_sha256"],
                "baseline_receipt_member": f"{historical}/receipt.json",
                "baseline_receipt_sha256": digest(before_receipt_raw),
                "current_receipt_sha256": digest(receipt_raw),
                "baseline_source_receipt_head": before_receipt["source_head"],
                "baseline_source_receipt_dirty_files": before_receipt["source_dirty_files"],
                "current_source_head": receipt["source_head"],
                "source_inputs_sha256": canonical_digest(receipt["source_inputs_sha256"]),
                "source_inputs_changed_since_baseline": source_changes,
                "current_inputs_bound_to_final_source": committed_inputs,
                "runtime": {key: receipt[key] for key in ("dart_version", "node_version", "runtime_dart_sha256", "runtime_node_sha256")},
                "baseline_runtime": {key: before_receipt[key] for key in ("dart_version", "node_version", "runtime_dart_sha256", "runtime_node_sha256")},
                "source_stable": True,
                "probe_stable": True,
                "runtimes_stable": True,
                "outcomes": {},
            }
            historical_outputs, current_outputs = {}, {}
            for runtime in ("vm", "node"):
                member = f"{historical}/{runtime}-results.json"
                old_raw, old = retained(member)
                new_raw = (current_dir / f"{runtime}-results.json").read_bytes()
                new = json.loads(new_raw)
                before, after = records(old["results"]), records(new["results"])
                assert before.keys() == after.keys(), (name, runtime)
                assert len(after) == len(json.loads(corpus_bytes)["cases"]) * 5
                changes = [
                    {"id": key[0], "variant": key[1], "before": before[key], "after": after[key]}
                    for key in sorted(before) if before[key] != after[key]
                ]
                run["outcomes"][runtime] = {
                    "baseline_member": member,
                    "baseline_sha256": digest(old_raw),
                    "current_file": str((current_dir / f"{runtime}-results.json").relative_to(output)),
                    "current_sha256": digest(new_raw),
                    "records_compared": len(after),
                    "changed_records": len(changes),
                    "changes": changes,
                    "before_summary": old["summary"],
                    "after_summary": new["summary"],
                    "byte_identical": old_raw == new_raw,
                    "entire_result_equal": old == new,
                }
                historical_outputs[runtime], current_outputs[runtime] = old, new
            run["baseline_vm_node_equal"] = historical_outputs["vm"] == historical_outputs["node"]
            run["current_vm_node_equal"] = current_outputs["vm"] == current_outputs["node"]
            assert run["baseline_vm_node_equal"] and run["current_vm_node_equal"]
            report["runs"][name] = run
    report["records_compared_per_runtime"] = sum(run["outcomes"]["vm"]["records_compared"] for run in report["runs"].values())
    report["changed_records_per_runtime"] = {
        runtime: sum(run["outcomes"][runtime]["changed_records"] for run in report["runs"].values())
        for runtime in ("vm", "node")
    }
    report["all_outcomes_unchanged"] = not any(report["changed_records_per_runtime"].values())
    report["passed"] = True
    with (output / "comparison.json").open("x") as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    print(json.dumps({key: report[key] for key in ("passed", "records_compared_per_runtime", "changed_records_per_runtime", "all_outcomes_unchanged")}, indent=2))


if __name__ == "__main__":
    main()
