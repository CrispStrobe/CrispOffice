#!/usr/bin/env python3
"""Independently reconstruct retained live German quality reports.

No Dart code, model inference, network request or repository write is performed.
Source comparisons use the supplied immutable Git commit, never the mutable
working tree. The only write is a fresh receipt specified by --output.
Optional local-asset verification hashes paths from runs.json without executing
the recorded commands. Omit that flag when only archived reports are present.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess


LANES = ("writing_only", "deterministic", "model_only", "combined")
PROVIDER_ORDER = {
    "writing_only": ["german-writing"],
    "deterministic": ["german-spelling", "german-writing"],
    "model_only": ["gector-de"],
    "combined": ["german-spelling", "german-writing", "gector-de"],
}
CORPORA = {
    "frozen": (
        "tools/proofing/german_model/cases.json",
        "f986fd031e4f984200c392e844ad83ae1ef5eb24",
    ),
    "prospective": (
        "tools/proofing/german_model/prospective_cases_20261117.json",
        "60c550b4d02e4433d15c3f4fc2e67e744ed95dda",
    ),
}
WORKSPACE_INPUTS = {".dart_tool/package_config.json", "pubspec.lock"}
PACK_MANIFEST = (
    "docs/validation/german-gector/2026-11-17-continuation/"
    "development-pack-manifest.json"
)


class AuditFailure(Exception):
    pass


class Checks:
    def __init__(self):
        self.count = 0

    def require(self, condition, label):
        self.count += 1
        if not condition:
            raise AuditFailure(label)

    def equal(self, actual, expected, label):
        self.require(actual == expected, label)


def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()


def digest_file(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def pin(path):
    path = Path(path)
    return {"file": path.name, "bytes": path.stat().st_size,
            "sha256": digest_file(path)}


def git(root, *arguments):
    result = subprocess.run(["git", *arguments], cwd=root, capture_output=True,
                            shell=False, check=False)
    if result.returncode:
        raise AuditFailure("Git read failed: " + " ".join(arguments[:2]))
    return result.stdout


def committed(root, sha, path):
    return git(root, "show", f"{sha}:{path}")


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"))


def conflict(a, b):
    if a["start"] == a["end"]:
        return b["start"] <= a["start"] <= b["end"]
    if b["start"] == b["end"]:
        return a["start"] <= b["start"] <= a["end"]
    return a["start"] < b["end"] and b["start"] < a["end"]


def declared_case(raw):
    # These two committed corpora use canonical de-DE/de-AT/de-CH only.
    locale = raw.get("locale", "de-DE")
    if locale not in {"de-DE", "de-AT", "de-CH"}:
        raise AuditFailure("Audit needs explicit normalization for a new locale.")
    value = {
        "id": raw["id"], "kind": raw["kind"], "input": raw["input"],
        "expected": raw.get("expected", raw["input"]), "locale": locale,
        "language": locale,
        "expected_model_status": "success" if locale == "de-DE" else "unsupported",
    }
    for name in ("category", "pair_id"):
        if raw.get(name) is not None:
            value[name] = raw[name]
    return value


def builder_constants(source):
    """Read literal target constants without importing/executing project code."""
    values = {}

    def literal(node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            return values[node.id]
        if isinstance(node, (ast.Tuple, ast.List)):
            return tuple(literal(item) for item in node.elts)
        raise ValueError("Not a literal build constant")

    for node in ast.parse(source).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target, ast.Name):
                try:
                    values[target.id] = literal(node.value)
                except (ValueError, KeyError):
                    pass
    return values


def verify_build(root, sha, folder, build, checks):
    builder_path = "tools/proofing/german_model/build_gector_aot.py"
    builder = committed(root, sha, builder_path)
    constants = builder_constants(builder.decode())
    entrypoint = constants["QUALITY_ENTRYPOINT"]
    fixed = constants["QUALITY_SOURCE_FILES"]
    directories = constants["QUALITY_SOURCE_DIRECTORIES"]
    checks.equal(constants["TARGETS"], ("provider", "incremental-quality"),
                 "Builder targets are the two known choices")
    runner = committed(root, sha, entrypoint).decode()
    contract = runner[runner.index("Future<Map<String, String>> _sources("):]
    fixed_match = re.search(r"final paths = <String>\[(.*?)\];", contract, re.S)
    dirs_match = re.search(r"for \(final directory in \[(.*?)\]\)", contract, re.S)
    checks.require(fixed_match is not None and dirs_match is not None,
                   "Committed runner has readable source-selection contract")
    checks.equal(tuple(re.findall(r"'([^']+)'", fixed_match.group(1))), fixed,
                 "Committed builder and runner fixed sources agree")
    checks.equal(tuple(re.findall(r"'([^']+)'", dirs_match.group(1))), directories,
                 "Committed builder and runner recursive sources agree")
    checks.require("'declared-corpus'" in contract,
                   "Runner binds its separate runtime corpus")
    selected = set(fixed)
    paths = git(root, "ls-tree", "-r", "--name-only", sha, "--", *directories)
    for path in paths.decode().splitlines():
        if path.endswith(".dart"):
            selected.add(path)
    checks.equal(set(build["source_files"]), selected,
                 "Build includes complete declared source closure")
    checks.equal(build["source_files"], build["source_files_after"],
                 "Build source snapshots match")
    checks.equal(build["dependency_inputs"], build["dependency_inputs_after"],
                 "Build dependency snapshots match")
    checks.equal(build["sdk_inputs"], build["sdk_inputs_after"],
                 "Build SDK snapshots match")
    for flag in ("completed", "passed", "source_stable", "dependencies_stable", "sdk_stable"):
        checks.equal(build[flag], True, "Build flag " + flag)
    checks.equal(build["target"], "incremental-quality", "Build selected quality target")
    checks.equal(build["compile"]["returncode"], 0, "Compilation succeeded")
    checks.equal(build["command"], [
        "<dart>", "compile", "aot-snapshot", "--packages=.dart_tool/package_config.json",
        entrypoint, "-o", "<staged-output>",
    ], "Build command uses fixed quality entrypoint")
    checks.equal(build["compiler"]["executable"], build["sdk_inputs"]["dart"],
                 "Compiler pin agrees with SDK snapshot")
    checks.equal(build["runtime"]["executable"], build["sdk_inputs"]["dartaotruntime"],
                 "AOT runtime pin agrees with SDK snapshot")
    source_bytes = committed(root, sha, entrypoint)
    checks.equal(build["source_entrypoint"], {
        "file": Path(entrypoint).name, "bytes": len(source_bytes),
        "sha256": digest_bytes(source_bytes),
    }, "Source entrypoint matches committed bytes")
    for path in sorted(selected - WORKSPACE_INPUTS):
        checks.equal(build["source_files"][path], digest_bytes(committed(root, sha, path)),
                     "Committed source pin: " + path)
    checks.equal(set(build["source_files"]) & WORKSPACE_INPUTS, WORKSPACE_INPUTS,
                 "Declared workspace configuration/lock inputs are bound")
    checks.equal(build["dependency_inputs"]["package_config"]["sha256"],
                 build["source_files"][".dart_tool/package_config.json"],
                 "Dependency and source package configuration pins agree")
    binary_name = build["runtime"]["entrypoint"]["file"]
    checks.equal(Path(binary_name).name, binary_name, "AOT name is a basename")
    binary = folder / binary_name
    if binary.exists():
        checks.equal(pin(binary), build["runtime"]["entrypoint"],
                     "Actual retained AOT artifact matches build pin")
    return {
        "builder_source_sha256": digest_bytes(builder),
        "runner_source_sha256": digest_bytes(source_bytes),
        "selected_source_count": len(selected),
        "tracked_sources_matching_commit": len(selected - WORKSPACE_INPUTS),
        "workspace_inputs": {name: build["source_files"][name] for name in sorted(WORKSPACE_INPUTS)},
        "workspace_input_scope": "Identical build/run pins; excluded from Git-tree comparison.",
        "resolved_package_count": len(build["dependency_inputs"]["packages"]),
        "resolved_dart_file_count": sum(p["dart_file_count"] for p in build["dependency_inputs"]["packages"].values()),
        "runtime": build["runtime"],
        "actual_aot_artifact_verified": binary.exists(),
        "source_dependency_sdk_stable": True,
    }


def reconstruct_lane(row, lane, outcome, checks, counts):
    label = row["id"] + "/" + lane
    results = outcome["results"]
    checks.equal([r["provider_id"] for r in results], PROVIDER_ORDER[lane],
                 label + ": provider coverage/order")
    counts["provider_results"] += len(results)
    statuses = [r["status"] for r in results]
    complete = "success" in statuses and all(s in {"success", "unsupported"} for s in statuses)
    unsupported = bool(statuses) and all(s == "unsupported" for s in statuses)
    source = row["input"].encode("utf-16-le")
    accepted, skipped, displayed = [], [], []
    for result in results:
        checks.require(result["status"] in {"success", "unsupported", "failed", "unavailable"},
                       label + ": known result status")
        if result["status"] != "success":
            checks.equal(result["findings"], [], label + ": unsuccessful result has no findings")
            continue
        for finding in result["findings"]:
            checks.equal(finding["provider_id"], result["provider_id"], label + ": finding provider")
            start = finding["start"] - row["start_offset"]
            end = finding["end"] - row["start_offset"]
            checks.require(0 <= start <= end <= len(source) // 2, label + ": source range")
            checks.equal(source[2 * start:2 * end].decode("utf-16-le"), finding["original"],
                         label + ": UTF-16 source-text identity")
            counts["source_spans_verified"] += 1
            for replacement in finding["replacements"]:
                replacement.encode("utf-16-le")
                counts["replacement_strings_validated"] += 1
            displayed.append(finding)
            if not complete:
                reason = "incomplete-report"
            elif not finding["replacements"]:
                reason = "no-replacement-advisory"
            elif any(conflict(previous, finding) for previous in accepted):
                reason = "overlap-with-earlier-projection"
            else:
                reason = None
            if reason is None:
                accepted.append(finding)
            else:
                skipped.append({**finding, "reason": reason})
    checks.equal(Counter(map(canonical, outcome["displayed_findings"])),
                 Counter(map(canonical, displayed)), label + ": displayed findings")
    checks.equal(outcome["projected_findings"], [{**f, "replacement_index": 0} for f in accepted],
                 label + ": accepted first-replacement projection")
    checks.equal(outcome["skipped_findings"], skipped, label + ": skipped findings and reasons")
    corrected = None
    if complete:
        projected = source
        for finding in sorted(accepted, key=lambda f: f["start"], reverse=True):
            start = finding["start"] - row["start_offset"]
            end = finding["end"] - row["start_offset"]
            projected = (projected[:2 * start] + finding["replacements"][0].encode("utf-16-le")
                         + projected[2 * end:])
            counts["projected_edits_reapplied"] += 1
        corrected = projected.decode("utf-16-le")
        counts["complete_projected_outcomes"] += 1
    else:
        counts["null_incomplete_outcomes"] += 1
    exact = complete and corrected == row["expected"]
    changed = corrected is not None and corrected != row["input"]
    flagged = bool(displayed)
    for key, expected in {
        "corrected": corrected, "complete": complete, "exact_expected": exact,
        "changed": changed, "flagged": flagged, "clean_report": complete and not flagged,
    }.items():
        checks.equal(outcome[key], expected, label + ": recomputed " + key)
    counts["lane_outcomes_reconstructed"] += 1
    return {"completed": complete, "exact": exact, "changed": changed, "flagged": flagged,
            "unsupported": unsupported, "failure": any(s in {"failed", "unavailable"} for s in statuses)}


def reconstruct_merge(row, checks, counts):
    deterministic = row["outcomes"]["deterministic"]
    model = row["outcomes"]["model_only"]
    accepted = list(deterministic["displayed_findings"])
    merged_results = list(deterministic["results"])
    accepted_model, suppressed_model = [], []
    for result in model["results"]:
        retained = []
        for finding in result["findings"]:
            if any(conflict(previous, finding) for previous in accepted):
                suppressed_model.append(finding)
            else:
                retained.append(finding)
                accepted.append(finding)
                accepted_model.append(finding)
        merged_results.append({**result, "findings": retained})
    checks.equal(row["outcomes"]["combined"]["results"], merged_results,
                 row["id"] + ": independently merged production results")
    checks.equal(row["accepted_model_findings"], accepted_model,
                 row["id"] + ": accepted model findings")
    checks.equal(Counter(map(canonical, row["suppressed_model_findings"])),
                 Counter(map(canonical, suppressed_model)), row["id"] + ": suppressed model findings")
    counts["production_merges_reconstructed"] += 1
    counts["accepted_model_findings"] += len(accepted_model)
    counts["suppressed_model_findings"] += len(suppressed_model)


def recompute_summary(rows):
    summary = {
        "case_count": len(rows),
        "error_count": sum(r["kind"] == "error" for r, c in rows),
        "clean_count": sum(r["kind"] == "clean" for r, c in rows),
        "lanes": {},
    }
    predicates = {
        "completed": lambda r, c: c["completed"],
        "completed_error": lambda r, c: r["kind"] == "error" and c["completed"],
        "completed_clean": lambda r, c: r["kind"] == "clean" and c["completed"],
        "exact_error": lambda r, c: r["kind"] == "error" and c["exact"],
        "changed_nonexact_error": lambda r, c: r["kind"] == "error" and c["changed"] and not c["exact"],
        "changed_clean": lambda r, c: r["kind"] == "clean" and c["changed"],
        "flagged_clean": lambda r, c: r["kind"] == "clean" and c["flagged"],
        "unchanged_clean": lambda r, c: r["kind"] == "clean" and c["completed"] and not c["changed"],
        "unflagged_clean": lambda r, c: r["kind"] == "clean" and c["completed"] and not c["flagged"],
        "unsupported_only": lambda r, c: c["unsupported"],
        "incomplete": lambda r, c: not c["completed"],
        "operational_failure": lambda r, c: c["failure"],
    }
    for lane in LANES:
        metrics = {}
        for key, predicate in predicates.items():
            ids = [r["id"] for r, c in rows if predicate(r, c[lane])]
            metrics[key + "_ids"] = ids
            metrics[key + "_count"] = len(ids)
        summary["lanes"][lane] = metrics

    def comparable(c):
        return all(c[lane]["completed"] for lane in ("deterministic", "model_only", "combined"))

    predicates = {
        "comparable": lambda r, c: comparable(c),
        "not_comparable": lambda r, c: not comparable(c),
        "added_exact_error": lambda r, c: comparable(c) and r["kind"] == "error" and not c["deterministic"]["exact"] and c["combined"]["exact"],
        "lost_exact_error": lambda r, c: comparable(c) and r["kind"] == "error" and c["deterministic"]["exact"] and not c["combined"]["exact"],
        "model_unique_exact_error": lambda r, c: comparable(c) and r["kind"] == "error" and c["model_only"]["exact"] and not c["deterministic"]["exact"],
        "new_changed_clean": lambda r, c: comparable(c) and r["kind"] == "clean" and not c["deterministic"]["changed"] and c["combined"]["changed"],
        "new_flagged_clean": lambda r, c: comparable(c) and r["kind"] == "clean" and not c["deterministic"]["flagged"] and c["combined"]["flagged"],
        "model_changed_clean": lambda r, c: r["kind"] == "clean" and c["model_only"]["changed"],
    }
    summary["incremental"] = {
        key + "_ids": [r["id"] for r, c in rows if predicate(r, c)]
        for key, predicate in predicates.items()
    }
    for kind in ("accepted_model", "suppressed_model"):
        summary["incremental"][kind + "_finding_count"] = sum(len(r[kind + "_findings"]) for r, c in rows)
    summary["operational_passed"] = all(
        not metric["failure"] and (metric["completed"] or metric["unsupported"])
        for r, c in rows for metric in c.values()
    )
    return summary


def classify_german(case_id, corrected):
    # Human review of observed initial outputs; match exact text so a later
    # new or fixed output never silently receives an old linguistic judgment.
    reviewed = {
        ("clean-quotes", 'Er sagte: „das stimmt.“'): (
            "incorrect_clean_edit", "Direct speech begins a sentence; lowering Das is incorrect."),
        ("clean-swiss-name", "Grütze, ich heisse André."): (
            "incorrect_clean_edit", "The Swiss greeting Grüezi is replaced with an unrelated noun."),
        ("prospective-relative-subject-clean", "Das Fahrrad, das im Hofe steht, gehört mir."): (
            "unnecessary_valid_variant", "Hof is correct; Hofe is a valid formal/older dative. The spelling flag and change are unnecessary."),
        ("prospective-relative-subject-error", "Das Fahrrad, das im Hofe steht, gehört mir."): (
            "grammatical_nonexact_output", "The model repairs dass to das. Hofe is grammatical but an unnecessary spelling change, which alone prevents exact-target credit."),
        ("prospective-relative-subject-error", "Das Fahrrad, dass im Hofe steht, gehört mir."): (
            "unresolved_error_and_unnecessary_variant", "The relative-pronoun error remains; Hof to Hofe is unnecessary, although Hofe itself is a valid dative."),
        ("accusative-article", "Sie hat ein roter Mantel."): (
            "incorrect_error_edit", "The object requires accusative einen roten Mantel; the nominative adjective change leaves an ungrammatical phrase."),
        ("participle", "Er hat das Buch genest."): (
            "incorrect_error_edit", "The spelling suggestion does not provide the required participle gelesen and is invalid in this construction."),
        ("prospective-participle-schreiben-error", "Sie hat den Brief beschreibt."): (
            "incorrect_error_edit", "The finite form beschreibt cannot supply the required participle after hat."),
        ("prospective-participle-finden-error", "Wir haben den Fehler befindet."): (
            "incorrect_error_edit", "The finite form befindet cannot supply the required participle after haben."),
    }
    return reviewed.get((case_id, corrected), (
        "requires_human_review", "This output differs from initially reviewed cases; review it separately."))


def triage(rows):
    result = []
    for row, calculated in rows:
        outcomes = []
        for lane in LANES:
            outcome, metric = row["outcomes"][lane], calculated[lane]
            if ((row["kind"] == "clean" and metric["flagged"]) or
                    (row["kind"] == "error" and metric["changed"] and not metric["exact"])):
                classification, explanation = classify_german(row["id"], outcome["corrected"])
                outcomes.append({"lane": lane, "corrected": outcome["corrected"],
                                 "classification": classification, "explanation": explanation,
                                 "rule_ids": [f["rule_id"] for f in outcome["displayed_findings"]]})
        if outcomes:
            result.append({"id": row["id"], "kind": row["kind"], "locale": row["locale"],
                           "input": row["input"], "expected": row["expected"], "outcomes": outcomes})
    return {
        "scope": "Changed clean controls and changed nonexact errors; not every unresolved error.",
        "complete_for_observed_triage": all(o["classification"] != "requires_human_review"
                                           for row in result for o in row["outcomes"]),
        "cases": result,
    }


def local_assets(manifest_run, report, checks):
    command = manifest_run["command"]
    checks.require(len(command) >= 4 and len(command[2:]) % 2 == 0,
                   "Recorded runtime command has name/value arguments")
    options = dict(zip(command[2::2], command[3::2]))
    checks.equal(len(options), len(command[2:]) // 2, "Runtime options not duplicated")
    checks.equal(pin(command[0]), report["runtime"]["executable"], "Actual Dart AOT runtime pin")
    checks.equal(pin(command[1]), report["runtime"]["entrypoint"], "Actual executed AOT snapshot pin")
    model, library = Path(options["--model"]), Path(options["--library"])
    checks.equal(digest_file(model), report["model"]["sha256"], "Actual model bytes hash")
    checks.equal(model.stat().st_size, report["model"]["bytes"], "Actual model byte size")
    checks.equal(digest_file(library), report["native_library_sha256"], "Actual native library hash")
    checks.equal(options["--model-sha256"], report["model"]["sha256"], "Model argument pin")
    checks.equal(options["--library-sha256"], report["native_library_sha256"], "Library argument pin")
    checks.equal(digest_file(options["--cases"]), report["cases_sha256"], "Actual runtime corpus")
    for name, digest in report["bundle_assets"].items():
        path = model if name == model.name else Path(options["--bundle-dir"]) / name
        checks.equal(digest_file(path), digest, "Actual verified bundle asset: " + name)
    return {"runtime": report["runtime"]["executable"],
            "aot": report["runtime"]["entrypoint"], "model": pin(model),
            "native_library": pin(library), "bundle_asset_count": len(report["bundle_assets"])}


def audit_panel(panel, root, sha, folder, build, run_record, pack, checks, verify_assets):
    path, freeze_sha = CORPORA[panel]
    corpus_bytes = committed(root, sha, path)
    freeze_bytes = committed(root, freeze_sha, path)
    checks.equal(corpus_bytes, freeze_bytes, panel + ": corpus unchanged from frozen commit")
    corpus = json.loads(corpus_bytes)
    raw = (folder / (panel + ".json")).read_bytes()
    report = json.loads(raw)
    expected = [declared_case(row) for row in corpus]
    checks.equal(len({r["id"] for r in corpus}), len(corpus), panel + ": corpus IDs unique")
    checks.equal(report["declared_cases"], expected, panel + ": declared corpus content")
    checks.equal([r["id"] for r in report["cases"]], [r["id"] for r in corpus],
                 panel + ": complete ordered case coverage")
    checks.equal(report["cases_sha256"], digest_bytes(corpus_bytes), panel + ": corpus hash")
    checks.equal(report["source_files"]["declared-corpus"], digest_bytes(corpus_bytes),
                 panel + ": runtime corpus source pin")
    checks.equal(report["source_files"], report["source_files_after"], panel + ": source stability")
    checks.equal({k: v for k, v in report["source_files"].items() if k != "declared-corpus"},
                 build["source_files"], panel + ": exact build/runtime source binding")
    checks.equal(report["runtime"]["entrypoint"], build["runtime"]["entrypoint"],
                 panel + ": executed AOT matches build")
    checks.equal(report["runtime"]["executable"], build["runtime"]["executable"],
                 panel + ": executed runtime matches build")
    checks.equal(report["runtime"]["product_mode"], True, panel + ": compiled product mode")
    checks.equal(report["runtime"]["checks_per_case"], 1, panel + ": one live check per input")
    checks.equal(report["runtime"]["native_threads"], 2, panel + ": native threads")
    checks.equal(report["live_native_provider"], True, panel + ": live provider declaration")
    model = pack["model"]
    checks.equal(report["model"], {
        "file": model["file"], "bytes": model["size_bytes"],
        "sha256": model["sha256"], "revision": model["revision"],
        "source_model_sha256": model["source_model_sha256"],
    }, panel + ": model matches committed development pack")
    checks.equal(report["native_library_sha256"], pack["native"]["sha256"],
                 panel + ": native library matches committed pack")
    checks.equal(report["bundle_assets"], {
        Path(f["path"]).name: f["sha256"] for f in pack["files"]
        if f["role"] in {"bundle", "model"}
    }, panel + ": complete pinned bundle closure")
    checks.equal(run_record["report_sha256"], digest_bytes(raw), panel + ": manifest report hash")
    checks.equal(run_record["log_sha256"], digest_file(folder / (panel + ".log")),
                 panel + ": manifest log hash")
    checks.equal(run_record["exit_code"], 0, panel + ": runtime exited successfully")
    checks.equal(run_record["corpus_sha256"], digest_bytes(corpus_bytes), panel + ": manifest corpus hash")
    counts, cooked = Counter(), []
    for row, declaration in zip(report["cases"], expected):
        for key, value in declaration.items():
            checks.equal(row[key], value, panel + "/" + row["id"] + ": declared " + key)
        checks.equal(set(row["outcomes"]), set(LANES), row["id"] + ": exactly four lanes")
        expected_statuses = {"german-spelling": "success", "german-writing": "success",
                             "gector-de": declaration["expected_model_status"]}
        checks.equal(row["expected_statuses"], expected_statuses, row["id"] + ": expected statuses")
        calculated = {
            lane: reconstruct_lane(row, lane, row["outcomes"][lane], checks, counts)
            for lane in LANES
        }
        reconstruct_merge(row, checks, counts)
        for lane in ("deterministic", "model_only"):
            for result in row["outcomes"][lane]["results"]:
                checks.equal(result["status"], expected_statuses[result["provider_id"]],
                             row["id"] + ": provider status contract")
        checks.equal(row["status_contract_passed"], True, row["id"] + ": status pass flag")
        cooked.append((row, calculated))
        counts["case_rows"] += 1
    summary = recompute_summary(cooked)
    summary["by_language"] = {
        language: recompute_summary([(r, c) for r, c in cooked if r["language"] == language])
        for language in sorted({r["language"] for r, c in cooked})
    }
    checks.equal(report["summary"], summary, panel + ": all recomputed summary metrics/lists")
    for flag in ("completed", "source_stable", "status_contract_passed", "operational_passed"):
        checks.equal(report[flag], True, panel + ": top-level flag " + flag)
    freeze_time = git(root, "show", "-s", "--format=%cI", freeze_sha).decode().strip()
    checks.require(datetime.fromisoformat(freeze_time) < datetime.fromisoformat(report["started_at_utc"]),
                   panel + ": corpus freeze predates execution")
    result = {
        "report_sha256": digest_bytes(raw), "report_bytes": len(raw),
        "log_sha256": digest_file(folder / (panel + ".log")),
        "corpus": {"path": path, "sha256": digest_bytes(corpus_bytes),
                   "freeze_commit": freeze_sha, "freeze_committed_at": freeze_time,
                   "unchanged_from_freeze": True},
        "run_started_at_utc": report["started_at_utc"],
        "run_finished_at_utc": report["finished_at_utc"],
        "reconstruction_counts": dict(sorted(counts.items())),
        "independently_recomputed_summary": summary,
        "linguistic_triage": triage(cooked),
        "build_source_runtime_corpus_pins_match": True,
        "local_assets_verified": False,
    }
    if verify_assets:
        result["local_assets"] = local_assets(run_record, report, checks)
        result["local_assets_verified"] = True
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--source-sha", required=True)
    parser.add_argument("--reports", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--verify-local-assets", action="store_true")
    args = parser.parse_args()
    if args.output.exists() or args.output.is_symlink():
        parser.error("Audit receipt must be a fresh destination.")
    if args.output.resolve().is_relative_to(args.source_root.resolve()):
        parser.error("Audit output must remain outside the repository.")
    checks = Checks()
    report = {
        "schema_version": 1,
        "kind": "independent-german-incremental-quality-audit",
        "audit_script_sha256": digest_file(Path(__file__)),
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "passed": False,
        "scope": "Independent Python reconstruction of retained live reports; no inference rerun.",
        "source_policy": "Use committed source blobs, never current mutable source files.",
        "span_policy": "UTF-16 range/text identity and valid scalar decoding; production services validate grapheme boundaries.",
        "interpretation": "Exact first-replacement projections are diagnostic; unsupported results are not clean successes. Subsequent tuning makes these development regressions, not new held-out accuracy evidence.",
        "panels": {},
    }
    input_paths = [args.reports / name for name in (
        "build.json", "runs.json", "frozen.json", "prospective.json", "frozen.log", "prospective.log")]
    try:
        before = {path.name: digest_file(path) for path in input_paths}
        report["input_receipt_hashes"] = before
        sha = git(args.source_root, "rev-parse", "--verify", args.source_sha + "^{commit}").decode().strip()
        report["source_commit"] = sha
        report["source_tree"] = git(args.source_root, "show", "-s", "--format=%T", sha).decode().strip()
        build = json.loads((args.reports / "build.json").read_text())
        runs = json.loads((args.reports / "runs.json").read_text())
        checks.equal(runs["source_head"], sha, "Manifest source equals declared immutable source")
        checks.equal(runs["build_sha256"], before["build.json"], "Manifest authenticates build receipt")
        checks.equal(runs["passed"], True, "Run manifest pass flag")
        records = {record["panel"]: record for record in runs["runs"]}
        checks.equal(set(records), set(CORPORA), "Manifest contains exactly both panels")
        checks.equal(len(records), len(runs["runs"]), "No duplicate manifest panels")
        report["build"] = verify_build(args.source_root, sha, args.reports, build, checks)
        pack_bytes = committed(args.source_root, sha, PACK_MANIFEST)
        pack = json.loads(pack_bytes)
        report["development_pack_manifest_sha256"] = digest_bytes(pack_bytes)
        for panel in CORPORA:
            report["panels"][panel] = audit_panel(
                panel, args.source_root, sha, args.reports, build, records[panel], pack,
                checks, args.verify_local_assets)
        totals = Counter()
        for panel in report["panels"].values():
            totals.update(panel["reconstruction_counts"])
        report["reconstruction_totals"] = dict(sorted(totals.items()))
        checks.equal({path.name: digest_file(path) for path in input_paths}, before,
                     "Original input reports/logs remain byte-identical after audit")
        report["input_reports_unchanged"] = True
        report["linguistic_review_complete_for_observed_triage"] = all(
            panel["linguistic_triage"]["complete_for_observed_triage"]
            for panel in report["panels"].values())
        report["passed"] = True
    except Exception as error:
        report["error_type"] = type(error).__name__
        report["error"] = str(error)
    report["checks_completed"] = checks.count
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"passed": report["passed"], "checks_completed": checks.count,
                      "totals": report.get("reconstruction_totals"),
                      "error": report.get("error")}, ensure_ascii=False))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
