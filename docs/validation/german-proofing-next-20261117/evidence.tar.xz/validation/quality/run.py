import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--runtime', type=Path, required=True)
parser.add_argument('--directory', type=Path, required=True)
args = parser.parse_args()
root, directory = args.root.resolve(), args.directory.resolve()
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
build = json.loads((directory / 'build.json').read_text())
assert build['passed'] and build['source_stable'] and build['dependencies_stable'] and build['sdk_stable']
assert digest(args.runtime) == build['runtime']['executable']['sha256']
assert digest(directory / 'quality.aot') == build['runtime']['entrypoint']['sha256']
receipt = {
    'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'build_sha256': digest(directory / 'build.json'),
    'command_scope': 'Two sequential compiled live quality runs; no replay, download, or CI.',
    'runs': [],
}
for name, corpus in [('frozen', 'cases.json'), ('prospective', 'prospective_cases_20261117.json')]:
    output = directory / (name + '.json')
    command = [str(args.runtime), str(directory / 'quality.aot'),
               '--source-root', str(root),
               '--cases', str(root / 'tools/proofing/german_model' / corpus),
               '--bundle-dir', os.environ['GECTOR_TEST_BUNDLE'],
               '--model', os.environ['GECTOR_TEST_MODEL'],
               '--model-sha256', os.environ['GECTOR_TEST_MODEL_SHA256'],
               '--library', os.environ['GECTOR_TEST_LIBRARY'],
               '--library-sha256', os.environ['GECTOR_TEST_LIBRARY_SHA256'],
               '--output', str(output)]
    started = time.monotonic()
    with (directory / (name + '.log')).open('wb') as stream:
        result = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=240, check=False)
    data = json.loads(output.read_text())
    sources = dict(data.get('source_files', {}))
    corpus_hash = sources.pop('declared-corpus', None)
    row = {'panel': name, 'command': command, 'exit_code': result.returncode,
           'elapsed_seconds': time.monotonic() - started, 'report_sha256': digest(output),
           'log_sha256': digest(directory / (name + '.log')),
           'operational_passed': data.get('operational_passed'),
           'source_stable': data.get('source_stable'),
           'build_sources_match': sources == build['source_files'],
           'build_runtime_match': data.get('runtime', {}).get('executable') == build['runtime']['executable'],
           'build_entrypoint_match': data.get('runtime', {}).get('entrypoint') == build['runtime']['entrypoint'],
           'corpus_sha256': corpus_hash}
    row['passed'] = result.returncode == 0 and all(row[k] for k in (
        'operational_passed', 'source_stable', 'build_sources_match', 'build_runtime_match', 'build_entrypoint_match'))
    receipt['runs'].append(row)
    receipt['passed'] = all(r['passed'] for r in receipt['runs'])
    (directory / 'runs.json').write_text(json.dumps(receipt, indent=2) + '\n')
    summary = data.get('summary', {}).get('by_language', {}).get('de-DE', {})
    print(json.dumps({'panel': name, 'passed': row['passed'], 'de_DE_lanes': {
        k: {m: v[m] for m in ('exact_error_count', 'completed_error_count', 'changed_clean_count', 'flagged_clean_count', 'completed_clean_count')}
        for k, v in summary.get('lanes', {}).items()},
        'incremental': summary.get('incremental')}), flush=True)
if not receipt['passed']:
    raise SystemExit(1)
