#!/usr/bin/env python3
"""Compare both immutable quality stages without modifying either input.

This comparison requires the independent reconstruction receipts and checks all
106 raw rows, ignoring only per-case timing observations. It permits precisely
the observed quote/Hof/Gruezi spelling-finding removals and rejects any other
substantive outcome change, new clean-case flag, or lost exact error correction.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


LANES = ("writing_only", "deterministic", "model_only", "combined")
EXPECTED_REMOVALS = {
    "frozen": {
        "clean-quotes": "Das",
        "clean-swiss-name": "Grüezi",
    },
    "prospective": {
        "prospective-relative-subject-error": "Hof",
        "prospective-relative-subject-clean": "Hof",
    },
}
EXPECTED_SOURCE_CHANGES = {
    "packages/quds_office_engine/lib/src/proofing/german_spelling.dart",
    "packages/quds_office_engine/lib/src/proofing/data/german_common_00.dart",
}


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode()


def identity(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--initial", type=Path, required=True)
    parser.add_argument("--final", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists() or args.output.is_symlink():
        parser.error("Comparison receipt must be a fresh file.")
    checks = 0

    def require(condition, label):
        nonlocal checks
        checks += 1
        if not condition:
            raise ValueError(label)

    report = {
        "schema_version": 1,
        "kind": "independent-initial-to-final-german-quality-comparison",
        "script_sha256": digest(__file__),
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "passed": False,
        "scope": "Exact comparison of every substantive case/lane field; only timing_ms is ignored.",
        "interpretation": "The final spelling fixes were informed by initial observations. These are development regressions, not new held-out accuracy evidence.",
        "panels": {},
    }
    inputs = [directory / name for directory in (args.initial, args.final)
              for name in ("build.json", "runs.json", "frozen.json", "prospective.json",
                           "frozen.log", "prospective.log")]
    inputs += [args.initial / "audit_initial.json", args.final / "audit_final.json"]
    try:
        original_hashes = {str(path): digest(path) for path in inputs}
        initial_audit = load(args.initial / "audit_initial.json")
        final_audit = load(args.final / "audit_final.json")
        initial_runs, final_runs = load(args.initial / "runs.json"), load(args.final / "runs.json")
        for audit, runs in ((initial_audit, initial_runs), (final_audit, final_runs)):
            require(audit["passed"] and audit["input_reports_unchanged"], "Independent audit passed")
            require(audit["source_commit"] == runs["source_head"], "Audit and run source pins agree")
        report["initial_source"] = initial_audit["source_commit"]
        report["qualified_final_source"] = final_audit["source_commit"]
        report["source_scope"] = "Applies only to these immutable sources; later integrated source needs explicit rebinding."
        report["initial_audit_sha256"] = digest(args.initial / "audit_initial.json")
        report["final_audit_sha256"] = digest(args.final / "audit_final.json")
        initial_build, final_build = load(args.initial / "build.json"), load(args.final / "build.json")
        require(initial_build["sdk_inputs"] == final_build["sdk_inputs"], "SDK inputs unchanged")
        dependencies_before = initial_build["dependency_inputs"]["packages"]
        dependencies_after = final_build["dependency_inputs"]["packages"]
        require(set(dependencies_before) == set(dependencies_after), "Resolved dependency set unchanged")
        report["changed_resolved_packages"] = sorted(
            name for name in dependencies_before if dependencies_before[name] != dependencies_after[name])
        require(report["changed_resolved_packages"] == ["quds_office_engine"],
                "Only the engine library changed in resolved package input closure")
        report["source_changes"] = {
            name: {"before_sha256": initial_build["source_files"].get(name),
                   "after_sha256": final_build["source_files"].get(name)}
            for name in sorted(set(initial_build["source_files"]) | set(final_build["source_files"]))
            if initial_build["source_files"].get(name) != final_build["source_files"].get(name)
        }
        require(set(report["source_changes"]) == EXPECTED_SOURCE_CHANGES,
                "Only intended spelling implementation/common-word source changed")
        totals = Counter()
        for panel in ("frozen", "prospective"):
            before, after = load(args.initial / (panel + ".json")), load(args.final / (panel + ".json"))
            require(digest(args.initial / (panel + ".json")) == initial_audit["panels"][panel]["report_sha256"],
                    panel + ": initial report bound to independent audit")
            require(digest(args.final / (panel + ".json")) == final_audit["panels"][panel]["report_sha256"],
                    panel + ": final report bound to independent audit")
            require(before["declared_cases"] == after["declared_cases"], panel + ": corpus declarations unchanged")
            require(before["cases_sha256"] == after["cases_sha256"], panel + ": corpus bytes unchanged")
            for field in ("model", "native_library_sha256", "bundle_assets", "projection_policy", "vocabulary"):
                require(before[field] == after[field], panel + ": unchanged " + field)
            require(before["runtime"]["executable"] == after["runtime"]["executable"],
                    panel + ": runtime executable unchanged")
            require([r["id"] for r in before["cases"]] == [r["id"] for r in after["cases"]],
                    panel + ": exact case coverage and order")
            comparison_rows, changed_ids, gained, lost, new_clean = [], [], [], [], []
            for old, new in zip(before["cases"], after["cases"]):
                case_id = old["id"]
                require({k: v for k, v in old.items() if k not in {"outcomes", "timing_ms"}} ==
                        {k: v for k, v in new.items() if k not in {"outcomes", "timing_ms"}},
                        panel + "/" + case_id + ": metadata/status/model-acceptance unchanged")
                lanes = {}
                changed_lanes = []
                for lane in LANES:
                    a, b = old["outcomes"][lane], new["outcomes"][lane]
                    changed = a != b
                    totals["lane_outcomes_compared"] += 1
                    totals["changed_lane_outcomes" if changed else "unchanged_lane_outcomes"] += 1
                    require([(r["provider_id"], r["status"], r["message"]) for r in a["results"]] ==
                            [(r["provider_id"], r["status"], r["message"]) for r in b["results"]],
                            case_id + "/" + lane + ": provider status/messages unchanged")
                    if lane in {"writing_only", "model_only"}:
                        require(not changed, case_id + "/" + lane + ": untouched lane")
                    if old["kind"] == "error":
                        if a["exact_expected"] and not b["exact_expected"]:
                            lost.append({"id": case_id, "lane": lane})
                        if not a["exact_expected"] and b["exact_expected"]:
                            gained.append({"id": case_id, "lane": lane})
                    if old["kind"] == "clean" and (
                            (not a["changed"] and b["changed"]) or
                            (not a["flagged"] and b["flagged"])):
                        new_clean.append({"id": case_id, "lane": lane})
                    lanes[lane] = {
                        "unchanged": not changed,
                        "before_outcome_sha256": identity(a),
                        "after_outcome_sha256": identity(b),
                        "before_corrected": a["corrected"], "after_corrected": b["corrected"],
                        "before_exact": a["exact_expected"], "after_exact": b["exact_expected"],
                        "before_flagged": a["flagged"], "after_flagged": b["flagged"],
                        "before_complete": a["complete"], "after_complete": b["complete"],
                    }
                    if changed:
                        changed_lanes.append(lane)
                        require(case_id in EXPECTED_REMOVALS[panel] and lane in {"deterministic", "combined"},
                                case_id + "/" + lane + ": intended case and lane")
                        expected_word = EXPECTED_REMOVALS[panel][case_id]
                        removed = [f for f in a["displayed_findings"] if f not in b["displayed_findings"]]
                        require(len(removed) == 1 and removed[0]["provider_id"] == "german-spelling"
                                and removed[0]["rule_id"] == "de.spelling.unknown"
                                and removed[0]["original"] == expected_word,
                                case_id + "/" + lane + ": exactly intended spelling finding removed")
                        finding = removed[0]
                        require(b["displayed_findings"] == [f for f in a["displayed_findings"] if f != finding],
                                case_id + "/" + lane + ": no other displayed finding changes")
                        expected_results = [
                            {**r, "findings": [f for f in r["findings"] if f != finding]}
                            for r in a["results"]
                        ]
                        require(b["results"] == expected_results, case_id + "/" + lane + ": only intended provider finding removed")
                        require(b["projected_findings"] == [
                            f for f in a["projected_findings"] if f != {**finding, "replacement_index": 0}],
                            case_id + "/" + lane + ": only intended projected finding removed")
                        require(b["skipped_findings"] == a["skipped_findings"],
                                case_id + "/" + lane + ": skipped findings unchanged")
                        expected_text = old["input"] if old["kind"] == "clean" or lane == "deterministic" else old["expected"]
                        require(b["corrected"] == expected_text, case_id + "/" + lane + ": expected corrected text")
                        lanes[lane]["removed_spelling_finding"] = finding
                if changed_lanes:
                    changed_ids.append(case_id)
                    require(changed_lanes == ["deterministic", "combined"], case_id + ": exactly two changed lanes")
                totals["case_rows_compared"] += 1
                totals["changed_case_rows" if changed_lanes else "unchanged_case_rows"] += 1
                comparison_rows.append({"id": case_id, "kind": old["kind"], "locale": old["locale"],
                                        "input": old["input"], "expected": old["expected"],
                                        "changed_lanes": changed_lanes, "lanes": lanes})
            require(set(changed_ids) == set(EXPECTED_REMOVALS[panel]), panel + ": all and only intended cases changed")
            require(not lost, panel + ": no exact error corrections lost")
            require(not new_clean, panel + ": no new clean edits or flags")
            expected_gains = [] if panel == "frozen" else [
                {"id": "prospective-relative-subject-error", "lane": "combined"}]
            require(gained == expected_gains, panel + ": exact error gain limited to restored Hof case")
            report["panels"][panel] = {
                "before_report_sha256": digest(args.initial / (panel + ".json")),
                "after_report_sha256": digest(args.final / (panel + ".json")),
                "corpus_sha256": before["cases_sha256"], "same_model_native_assets": True,
                "changed_case_ids": changed_ids, "new_exact_error_corrections": gained,
                "lost_exact_error_corrections": lost, "new_clean_edits_or_flags": new_clean,
                "final_deDE_counts": {
                    lane: {key: value for key, value in metrics.items() if key.endswith("_count")}
                    for lane, metrics in final_audit["panels"][panel]["independently_recomputed_summary"]["by_language"]["de-DE"]["lanes"].items()
                },
                "case_comparisons": comparison_rows,
                "remaining_linguistic_triage": final_audit["panels"][panel]["linguistic_triage"],
            }
        require({str(path): digest(path) for path in inputs} == original_hashes,
                "Both stages' original reports, logs, builds and audit receipts remain unchanged")
        report["input_evidence_unchanged"] = True
        report["comparison_totals"] = dict(sorted(totals.items()))
        report["passed"] = True
    except Exception as error:
        report["error_type"] = type(error).__name__
        report["error"] = str(error)
    report["checks_completed"] = checks
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"passed": report["passed"], "checks_completed": checks,
                      "totals": report.get("comparison_totals"), "error": report.get("error")}))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
