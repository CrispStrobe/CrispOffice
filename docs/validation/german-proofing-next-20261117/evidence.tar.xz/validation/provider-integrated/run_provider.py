#!/usr/bin/env python3
"""Run a sealed compiled native provider and preserve complete input receipts."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def pin(path: Path) -> dict:
    return {"file": path.name, "bytes": path.stat().st_size, "sha256": digest(path)}


def head(root: Path) -> str:
    return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("source-root", "dart", "aot", "build", "reference", "directory"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--source-sha", required=True)
    parser.add_argument("--segment-target-tokens", type=int, default=64)
    options = parser.parse_args()
    root = options.source_root.resolve()
    directory = options.directory.resolve()
    directory.mkdir(parents=True, exist_ok=True)
    output, log, receipt = (directory / name for name in ("provider.json", "provider.log", "run.json"))
    if any(path.exists() for path in (output, log, receipt)):
        raise SystemExit("Refusing to overwrite provider run evidence.")
    if head(root) != options.source_sha:
        raise SystemExit("Working tree HEAD differs from the sealed source commit.")
    module_path = root / "tools/proofing/german_model/build_gector_aot.py"
    committed_builder = subprocess.check_output(
        ["git", "show", options.source_sha + ":tools/proofing/german_model/build_gector_aot.py"], cwd=root)
    if hashlib.sha256(committed_builder).hexdigest() != digest(module_path):
        raise SystemExit("Build helper differs from sealed source.")
    spec = importlib.util.spec_from_file_location("sealed_provider_builder", module_path)
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    dart, aot = options.dart.resolve(), options.aot.resolve()
    runtime = dart.parent / "dartaotruntime"
    build = json.loads(options.build.read_text())
    if not all(build.get(key) for key in ("passed", "completed", "source_stable", "dependencies_stable", "sdk_stable")):
        raise SystemExit("A fully stable successful build receipt is required.")

    def snapshot() -> dict:
        return {"source_files": builder.source_snapshot(root),
                "dependency_inputs": builder.dependency_snapshot(root),
                "sdk_inputs": {name: builder.file_pin(path) for name, path in builder.sdk_files(dart).items()},
                "runtime": {"executable": pin(runtime), "entrypoint": pin(aot)},
                "source_head": head(root)}

    before = snapshot()
    for key in ("source_files", "dependency_inputs", "sdk_inputs", "runtime"):
        if before[key] != build[key]:
            raise SystemExit("Runtime inputs no longer match the completed build: " + key)
    mismatches, untracked = [], []
    for name, sha in before["source_files"].items():
        result = subprocess.run(["git", "show", options.source_sha + ":" + name], cwd=root,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        if result.returncode:
            untracked.append({"path": name, "sha256": sha})
        elif hashlib.sha256(result.stdout).hexdigest() != sha:
            mismatches.append(name)
    if mismatches or [item["path"] for item in untracked] != ["pubspec.lock"]:
        raise SystemExit("Selected source inputs do not bind to the sealed commit and retained workspace lockfile.")
    bundle = Path(os.environ["GECTOR_TEST_BUNDLE"]).resolve()
    model = Path(os.environ["GECTOR_TEST_MODEL"]).resolve()
    library = Path(os.environ["GECTOR_TEST_LIBRARY"]).resolve()
    model_sha, library_sha = os.environ["GECTOR_TEST_MODEL_SHA256"], os.environ["GECTOR_TEST_LIBRARY_SHA256"]
    if digest(model) != model_sha or digest(library) != library_sha:
        raise SystemExit("Explicit native artifact hashes differ.")
    reference = options.reference.resolve()
    if digest(reference) != "9d33a0be66e68284277bd3d9e0e0fe404936cf804e2e715a8999b7ece14155d8":
        raise SystemExit("Pinned F32 reference identity differs.")
    assets = {path.name: pin(path) for path in sorted(bundle.iterdir()) if path.is_file()}
    command = [str(runtime), str(aot), "--source-root", str(root),
               "--bundle-dir", str(bundle), "--model", str(model), "--model-sha256", model_sha,
               "--library", str(library), "--library-sha256", library_sha,
               "--reference", str(reference), "--segment-target-tokens", str(options.segment_target_tokens),
               "--output", str(output)]
    result_receipt = {
        "schema_version": 1, "kind": "sealed-native-provider-run", "completed": False, "passed": False,
        "source_sha": options.source_sha, "timestamp_utc": utc(), "command": command,
        "environment": {"CRISPEMBED_GECTOR": "1", "TMPDIR": os.environ.get("TMPDIR")},
        "host_coordination": "Team confirmed active compilations and tests finished before launch; other host activity is not controlled.",
        "host_load_before": list(os.getloadavg()), "logical_cpu_count": os.cpu_count(),
        "build": pin(options.build), "builder": pin(module_path), "script": pin(Path(__file__)),
        "reference": pin(reference), "model": pin(model), "native_library": pin(library), "bundle_assets": assets,
        "source_commit_binding": {"tracked_files": len(before["source_files"]) - len(untracked),
                                  "workspace_files": untracked, "mismatches": mismatches},
        "inputs_before": before,
    }
    with receipt.open("x", encoding="utf-8") as stream:
        json.dump(result_receipt, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    started = time.monotonic()
    environment = dict(os.environ, CRISPEMBED_GECTOR="1")
    try:
        with log.open("xb") as stream:
            result = subprocess.run(command, cwd=root, env=environment, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=240, check=False)
        result_receipt["exit_code"] = result.returncode
    except Exception as error:
        result_receipt["error"] = str(error)
    finally:
        result_receipt["elapsed_seconds"] = time.monotonic() - started
        result_receipt["finished_utc"] = utc()
        result_receipt["host_load_after"] = list(os.getloadavg())
        after = snapshot()
        result_receipt["inputs_after"] = after
        result_receipt["input_stability"] = {key: before[key] == after[key] for key in before}
        result_receipt["build_stable"] = pin(options.build) == result_receipt["build"]
        result_receipt["builder_stable"] = pin(module_path) == result_receipt["builder"]
        result_receipt["native_inputs_stable"] = (
            pin(model) == result_receipt["model"] and pin(library) == result_receipt["native_library"]
            and pin(reference) == result_receipt["reference"]
            and {path.name: pin(path) for path in sorted(bundle.iterdir()) if path.is_file()} == assets)
        if log.is_file():
            result_receipt["log"] = pin(log)
        if output.is_file():
            result_receipt["report"] = pin(output)
            data = json.loads(output.read_text())
            checks = {"report_completed": data.get("completed") is True,
                      "report_source_stable": data.get("source_stable") is True,
                      "report_operational_passed": data.get("operational_passed") is True,
                      "report_segmentation_passed": data.get("segmentation_operational_passed") is True,
                      "report_all_requested_passed": data.get("all_requested_checks_passed") is True,
                      "report_source_map_matches": data.get("source_files") == before["source_files"],
                      "report_runtime_matches": all(data.get("runtime", {}).get(k) == v for k, v in before["runtime"].items()),
                      "report_asset_map_matches": data.get("bundle_assets") == {name: item["sha256"] for name, item in assets.items()},
                      "report_reference_matches": data.get("reference_sha256") == result_receipt["reference"]["sha256"],
                      "report_library_matches": data.get("native_library_sha256") == library_sha}
            result_receipt["report_checks"] = checks
            result_receipt["passed"] = (result_receipt.get("exit_code") == 0 and all(checks.values())
                                        and all(result_receipt["input_stability"].values())
                                        and all(result_receipt[k] for k in ("build_stable", "builder_stable", "native_inputs_stable")))
        result_receipt["completed"] = True
        with receipt.open("w", encoding="utf-8") as stream:
            json.dump(result_receipt, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
    print(json.dumps({"passed": result_receipt["passed"], "exit_code": result_receipt.get("exit_code"),
                      "elapsed_seconds": result_receipt["elapsed_seconds"], "report": str(output)}))
    return 0 if result_receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
