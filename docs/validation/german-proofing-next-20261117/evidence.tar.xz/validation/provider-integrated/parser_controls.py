#!/usr/bin/env python3
"""Exercise argument rejection in a compiled provider without loading native assets."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time


def pin(path: Path) -> dict:
    return {"file": path.name, "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--aot", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--directory", type=Path, required=True)
    options = parser.parse_args()
    directory = options.directory.resolve()
    directory.mkdir(parents=True, exist_ok=True)
    output = directory / "parser-controls.json"
    if output.exists():
        raise SystemExit("Refusing to overwrite existing parser evidence.")
    build = json.loads(options.build.read_text())
    runtime, aot = options.runtime.resolve(), options.aot.resolve()
    before = {"executable": pin(runtime), "entrypoint": pin(aot)}
    if not build["passed"] or before != build["runtime"]:
        raise SystemExit("Build/runtime identity does not match.")
    root = options.source_root.resolve()
    cases = [
        ("nonnumeric-target", ["--segment-target-tokens", "invalid"], "must be between 2 and 512"),
        ("below-range-target", ["--segment-target-tokens", "1"], "must be between 2 and 512"),
        ("above-range-target", ["--segment-target-tokens", "513"], "must be between 2 and 512"),
        ("duplicate-target", ["--segment-target-tokens", "64", "--segment-target-tokens", "64"],
         "Unknown or duplicated option: segment-target-tokens"),
        ("unknown-option", ["--not-a-provider-option", "64"],
         "Unknown or duplicated option: not-a-provider-option"),
    ]
    rows = []
    for name, extra, expected in cases:
        unexpected = directory / (name + "-must-not-exist.json")
        if unexpected.exists():
            raise SystemExit("Unexpected preexisting control output.")
        # Every required option is present. Deliberately absent paths demonstrate
        # that invalid command-line input is rejected before any model/file load.
        command = [str(runtime), str(aot),
                   "--bundle-dir", "/not-used-by-parser-controls/bundle",
                   "--model", "/not-used-by-parser-controls/model",
                   "--model-sha256", "0" * 64,
                   "--library", "/not-used-by-parser-controls/library",
                   "--library-sha256", "0" * 64,
                   "--reference", "/not-used-by-parser-controls/reference",
                   "--source-root", str(root), "--output", str(unexpected)] + extra
        started = time.monotonic()
        result = subprocess.run(command, cwd=root, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=15, check=False)
        elapsed = time.monotonic() - started
        log = directory / (name + ".log")
        with log.open("xb") as stream:
            stream.write(result.stdout)
        decoded = result.stdout.decode("utf-8", errors="replace")
        rows.append({"id": name, "command": command, "exit_code": result.returncode,
                     "elapsed_seconds": elapsed, "expected_diagnostic": expected,
                     "diagnostic_present": expected in decoded,
                     "output_absent": not unexpected.exists(), "log": pin(log),
                     "passed": result.returncode != 0 and expected in decoded and not unexpected.exists()})
    after = {"executable": pin(runtime), "entrypoint": pin(aot)}
    receipt = {"schema_version": 1, "kind": "compiled-provider-cli-rejection-controls",
               "scope": "Five parser failures; no model loading, inference, or native timing.",
               "build": pin(options.build), "runtime": before, "runtime_stable": before == after,
               "source_scope": "Compiled build receipt, not the later working tree.",
               "controls": rows, "passed": all(row["passed"] for row in rows) and before == after}
    with output.open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"passed": receipt["passed"], "controls": len(rows), "output": str(output)}))
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
