#!/usr/bin/env python3
"""Reconstruct pinned provider evidence without inference or source mutations."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import statistics
import subprocess


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def pin(path):
    return {"file": path.name, "bytes": path.stat().st_size, "sha256": digest(path)}


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def units(text):
    return len(text.encode("utf-16-le")) // 2


class Audit:
    def __init__(self):
        self.assertions = 0
        self.results = 0
        self.findings = 0
        self.segments = 0

    def require(self, condition, label):
        self.assertions += 1
        if not condition:
            raise ValueError(label)

    def eq(self, actual, expected, label):
        self.require(actual == expected, label + ": value mismatch")

    def result(self, row, identity, source, offset=7, language="de-DE"):
        self.results += 1
        for key, expected in (("id", identity), ("input", source), ("start_offset", offset), ("language", language)):
            self.eq(row[key], expected, identity + "." + key)
        self.require(row["status"] in {"success", "failed", "unsupported", "unavailable", "cancelled"}, identity + ".status")
        encoded = source.encode("utf-16-le")
        boundaries, cursor = {0}, 0
        for scalar in source:
            cursor += units(scalar)
            boundaries.add(cursor)
        previous, previous_end, edits = -1, -1, []
        for finding in row["findings"]:
            self.findings += 1
            start, end = finding["start"] - offset, finding["end"] - offset
            self.require(start in boundaries and end in boundaries and start <= end, identity + ".UTF16 boundaries")
            self.require(start > previous and start >= previous_end, identity + ".ordered disjoint spans")
            self.eq(encoded[2 * start:2 * end].decode("utf-16-le"), finding["original"], identity + ".source span")
            self.require(finding["original"] != finding["replacement"], identity + ".changed finding")
            self.eq(finding["rule_id"], "gector.de.grammar", identity + ".rule")
            edits.append((start, end, finding["replacement"].encode("utf-16-le")))
            previous, previous_end = start, end
        actual = encoded
        for start, end, replacement in reversed(edits):
            actual = actual[:2 * start] + replacement + actual[2 * end:]
        self.eq(actual.decode("utf-16-le"), row["corrected"], identity + ".reconstructed correction")
        if row["status"] != "success":
            self.eq(row["findings"], [], identity + ".unsuccessful findings empty")
            self.eq(row["corrected"], source, identity + ".unsuccessful input intact")
            self.require(bool(row["message"]), identity + ".explicit status message")

    def measured(self, row, identity, text, language="de-DE"):
        self.result(row, identity, text, language=language)
        self.result(row["warmup"], identity + "-warmup", text, language=language)
        self.eq(row["stable_repeats"], True, identity + ".producer repeat stability")
        for key in ("status", "corrected", "findings"):
            self.eq(row[key], row["warmup"][key], identity + ".retained warmup equality")
        samples = row["timing"]["samples_ms"]
        self.eq(len(samples), 3, identity + ".sample count")
        self.require(all(isinstance(v, (int, float)) and math.isfinite(v) and v >= 0 for v in samples), identity + ".finite timing")
        expected = {"median_ms": statistics.median(samples), "p95_ms": sorted(samples)[-1], "maximum_ms": max(samples)}
        for key, value in expected.items():
            self.require(math.isclose(row["timing"][key], value, rel_tol=1e-12, abs_tol=1e-9), identity + "." + key)
        self.eq(row["elapsed_ms"], samples[0], identity + ".first timing")

    def partition(self, row, simple=False):
        identity, source = row["id"], row["input"]
        encoded = source.encode("utf-16-le")
        self.eq(row["source_code_units"], units(source), identity + ".source size")
        self.eq(row["source_coverage_complete"], True, identity + ".coverage flag")
        self.eq(row["initial_segment_count"], len(row["initial_segments"]), identity + ".segment count")
        self.require(1 <= row["initial_segment_count"] <= 32, identity + ".bounded segment count")
        cursor, tokens = 0, 0
        for segment in row["initial_segments"]:
            self.segments += 1
            self.eq(segment["start"], cursor, identity + ".contiguous source partition")
            self.require(cursor < segment["end"] <= units(source), identity + ".nonempty source segment")
            piece = encoded[2 * segment["start"]:2 * segment["end"]].decode("utf-16-le")
            self.require(2 <= segment["tokens"] <= 512, identity + ".native capacity")
            if simple:
                self.eq(segment["tokens"], simple_tokens(piece), identity + ".independent segment tokens")
                self.require(segment["tokens"] <= 64, identity + ".preferred target on splittable probe")
            cursor, tokens = segment["end"], tokens + segment["tokens"]
        self.eq(cursor, units(source), identity + ".complete coverage")
        self.eq(tokens, row["initial_model_tokens_total"], identity + ".actual total initial tokens")
        self.require(tokens <= 4096, identity + ".request token bound")
        if simple:
            self.eq(row["tokens_first_pass"], simple_tokens(source), identity + ".independent logical tokens")


PROBE_WORDS = {"Das", "Haus", "ist", "schön", ".", "Du", "geht", "heute", "nach", "Hause", "\x60", "😀"}


def simple_tokens(source):
    """Restricted independent count: each probe word has one cased WordPiece;
    the single-scalar backtick/emoji are unknowns. Strip one terminal period and
    add CLS/SEP. This is deliberately not a general tokenizer implementation."""
    view = source.rstrip()
    if view.endswith("."):
        view = view[:-1]
    words = re.findall(r"\w+(?:'\w+)?|[^\w\s]", view)
    if not set(words) <= PROBE_WORDS:
        raise ValueError("Unknown word in restricted probe token counter")
    return 2 + len(words)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("source-root", "directory", "bundle-dir", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--source-sha", required=True)
    options = parser.parse_args()
    root, directory, output = options.source_root.resolve(), options.directory.resolve(), options.output.resolve()
    if output.exists():
        raise SystemExit("Refusing to overwrite independent provider audit")
    audit = Audit()
    result = {
        "schema_version": 1, "kind": "independent-segmented-provider-evidence-audit", "passed": False,
        "source_sha": options.source_sha,
        "scope": "Raw retained findings, original UTF-16 partitions, timing samples, build/run input closure and CLI rejection controls.",
        "limits": [
            "Only warmup and first measured output are retained; stability of all repeats is reported by the producer.",
            "Repeated grammatical sentences establish bounded operational scaling, not representative quality or target-device performance.",
            "Independent WordPiece counting covers only the explicit small probe vocabulary."
        ]
    }
    try:
        build, run, report = (load(directory / name) for name in ("build-final.json", "run.json", "provider.json"))
        result["raw_inputs"] = {name: pin(directory / name) for name in ("build-final.json", "run.json", "provider.json", "provider.log")}
        audit.eq(run["source_sha"], options.source_sha, "run source")
        for key, name in (("build", "build-final.json"), ("report", "provider.json"), ("log", "provider.log")):
            audit.eq(run[key], pin(directory / name), "run " + key + " pin")
        audit.eq(run["exit_code"], 0, "native exit status")
        for key in ("passed", "completed", "source_stable", "dependencies_stable", "sdk_stable"):
            audit.eq(build[key], True, "build." + key)
        for key in ("passed", "completed", "build_stable", "builder_stable", "native_inputs_stable"):
            audit.eq(run[key], True, "run." + key)
        audit.require(all(run["input_stability"].values()), "run stability flags")
        audit.require(all(run["report_checks"].values()), "run cross-check flags")
        before, after = run["inputs_before"], run["inputs_after"]
        audit.eq(before, after, "raw full input snapshots before/after")
        audit.eq(before["source_head"], options.source_sha, "input source HEAD")
        for key in ("source_files", "dependency_inputs", "sdk_inputs", "runtime"):
            audit.eq(before[key], build[key], "build/runtime " + key)
        for key in ("source_files", "dependency_inputs", "sdk_inputs"):
            audit.eq(build[key], build[key + "_after"], "build before/after " + key)
        audit.eq(report["source_files"], before["source_files"], "reported source map")
        for key in ("executable", "entrypoint"):
            audit.eq(report["runtime"][key], build["runtime"][key], "runtime " + key + " identity")
        audit.eq(report["runtime"]["product_mode"], True, "AOT product mode")
        tracked, workspace = 0, []
        for name, sha in before["source_files"].items():
            process = subprocess.run(["git", "show", options.source_sha + ":" + name], cwd=root,
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            if process.returncode:
                workspace.append({"path": name, "sha256": sha})
            else:
                audit.eq(hashlib.sha256(process.stdout).hexdigest(), sha, "committed source " + name)
                tracked += 1
        audit.eq(workspace, run["source_commit_binding"]["workspace_files"], "workspace input inventory")
        audit.eq([item["path"] for item in workspace], ["pubspec.lock"], "known workspace exception")
        audit.eq(tracked, run["source_commit_binding"]["tracked_files"], "tracked sources")
        audit.eq(run["source_commit_binding"]["mismatches"], [], "source mismatch list")
        for key in ("model", "native_library", "reference"):
            report_sha = report["model"]["sha256"] if key == "model" else report[key + "_sha256"]
            audit.eq(report_sha, run[key]["sha256"], key + " identity")
        audit.eq(report["bundle_assets"], {name: item["sha256"] for name, item in run["bundle_assets"].items()}, "bundle identity inventory")
        tokenizer = options.bundle_dir / "tokenizer.json"
        audit.eq(digest(tokenizer), report["bundle_assets"]["tokenizer.json"], "probe tokenizer identity")
        vocabulary = load(tokenizer)["model"]["vocab"]
        expected_vocab = {"Das": 347, "Haus": 860, "ist": 215, "schön": 2602, ".": 566,
                          "Du": 840, "geht": 1125, "heute": 1181, "nach": 333, "Hause": 3873,
                          "\x60": None, "😀": None, "[UNK]": 101, "[CLS]": 102, "[SEP]": 103}
        for word, value in expected_vocab.items():
            audit.eq(vocabulary.get(word), value, "probe WordPiece " + word)
        result["independent_probe_vocabulary"] = {"tokenizer_sha256": digest(tokenizer), "tokens": expected_vocab}
        comparator_path = root / "tools/proofing/german_model/compare_guarded_provider.py"
        committed = subprocess.check_output(["git", "show", options.source_sha + ":tools/proofing/german_model/compare_guarded_provider.py"], cwd=root)
        audit.eq(digest(comparator_path), hashlib.sha256(committed).hexdigest(), "committed comparator")
        spec = importlib.util.spec_from_file_location("provider_evidence_comparator", comparator_path)
        comparator = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(comparator)
        corpus_path = root / "tools/proofing/german_model/cases.json"
        corpus = load(corpus_path)
        historical = comparator.compare(comparator.DEFAULT_BASELINE.read_bytes(), (directory / "provider.json").read_bytes(), corpus_path.read_bytes())
        audit.eq(historical["passed"], True, "strict historical frozen comparison")
        result["historical_comparison"] = historical
        config = report["decode_configuration"]
        audit.eq(config["mode"], "sentence-segments", "segmented mode")
        audit.eq(config["maximum_tokens_per_sequence"], 512, "native sequence maximum")
        audit.eq(config["maximum_text_code_units"], 32768, "text maximum")
        audit.eq(config["segmentation"], {"target_tokens": 64, "maximum_segments": 32,
                 "maximum_total_initial_tokens": 4096, "maximum_total_forward_tokens": 4096 * config["maximum_passes"]}, "segmentation contract")
        for row, original in zip(report["cases"], corpus, strict=True):
            audit.measured(row, original["id"], original["input"], original.get("locale", "de-DE"))
            audit.partition(row)
        for row, repeats in zip(report["long_complete_check_probes"], (12, 25, 51), strict=True):
            audit.measured(row, row["id"], " ".join(["Das Haus ist schön."] * repeats))
            audit.partition(row, simple=True)
            audit.eq(row["corrected"], row["input"], row["id"] + ".unchanged")
        for row in report["controls"]:
            audit.result(row, row["id"], row["input"], language=row["language"])
            audit.eq(row["passed"], True, row["id"] + ".passed")
        probes = report["segmented_long_complete_check_probes"]
        audit.eq([row["id"] for row in probes], ["segmented-repeated-sentences-up-to-640", "segmented-repeated-sentences-up-to-1280"], "segmented probe coverage")
        for row, budget, repeats in zip(probes, (640, 1280), (127, 255), strict=True):
            text = " ".join(["Das Haus ist schön."] * repeats)
            audit.measured(row, "segmented-repeated-sentences-up-to-" + str(budget), text)
            audit.partition(row, simple=True)
            audit.eq(row["logical_token_budget"], budget, row["id"] + ".budget")
            audit.require(512 < simple_tokens(text) <= budget < simple_tokens(text + " Das Haus ist schön."), row["id"] + ".maximal probe length")
            audit.eq(row["initial_segment_count"], math.ceil(repeats / 12), row["id"] + ".independent segment count")
            for key, expected in (("status", "success"), ("corrected", text), ("expected", text), ("matches_expected", True), ("exceeds_single_sequence_capacity", True)):
                audit.eq(row[key], expected, row["id"] + "." + key)
        sentence = "Du geht heute nach Hause."
        prefix = "😀 " + " ".join(["Das Haus ist schön."] * 120) + " "
        late = prefix + sentence
        protected = prefix + "\x60" + sentence + "\x60 Das Haus ist schön."
        too_long = sentence + " " + " ".join(["Haus"] * 600)
        long_sentence = " ".join(["Haus"] * 256) + "."
        too_many_tokens = " ".join([long_sentence] * (4096 // simple_tokens(long_sentence) + 1))
        too_many_segments = " ".join([" ".join(["Das Haus ist schön."] * 12)] * 33)
        late_start = 137 + units(late[:late.rindex("geht")])
        late_finding = {"start": late_start, "end": late_start + 4, "original": "geht", "replacement": "gehst", "rule_id": "gector.de.grammar"}
        specs = [
            ("segmented-late-correction-utf16-offset", late, "success", prefix + "Du gehst heute nach Hause.", [late_finding], None),
            ("segmented-protected-code", protected, "success", protected, [], None),
            ("segmented-late-capacity-fails-whole-request", too_long, "failed", too_long, [], "512 wordpieces"),
            ("segmented-total-token-cap-fails-whole-request", too_many_tokens, "failed", too_many_tokens, [], "4096 initial wordpieces"),
            ("segmented-segment-cap-fails-whole-request", too_many_segments, "failed", too_many_segments, [], "32 complete segments"),
            ("segmented-text-cap-fails-whole-request", "x" * 32769, "failed", "x" * 32769, [], "32768 UTF-16 units"),
        ]
        audit.eq([row["id"] for row in report["segmentation_controls"]], [spec[0] for spec in specs], "segmentation control coverage")
        for row, (identity, text, status, corrected, findings, rejection) in zip(report["segmentation_controls"], specs, strict=True):
            audit.result(row, identity, text, offset=137)
            for key, expected in (("status", status), ("expected_status", status), ("corrected", corrected),
                                  ("expected", corrected), ("findings", findings), ("expected_findings", findings),
                                  ("passed", True), ("planning_admitted", status == "success")):
                audit.eq(row[key], expected, identity + "." + key)
            if status == "success":
                audit.partition(row, simple=True)
                audit.require(row["tokens_first_pass"] > 512 and row["initial_segment_count"] > 1, identity + ".beyond single sequence")
            else:
                audit.require(rejection in row["planning_rejection"], identity + ".independent capacity reason")
                audit.require(row["planning_rejection"] in row["message"], identity + ".worker/planner rejection match")
                audit.require("initial_segments" not in row, identity + ".no admitted partition")
        for key in ("completed", "source_stable", "operational_passed", "segmentation_operational_passed", "all_requested_checks_passed"):
            audit.eq(report[key], True, "report." + key)
        parser_path = directory / "parser-controls-final/parser-controls.json"
        cli = load(parser_path)
        audit.eq(cli["runtime"], build["runtime"], "final compiled parser identity")
        audit.eq(cli["passed"], True, "compiled parser controls")
        audit.eq(len(cli["controls"]), 5, "compiled parser count")
        for row in cli["controls"]:
            log = parser_path.parent / row["log"]["file"]
            audit.eq(pin(log), row["log"], row["id"] + ".log pin")
            audit.require(row["exit_code"] != 0 and row["expected_diagnostic"] in log.read_text(), row["id"] + ".diagnostic")
            audit.eq(row["output_absent"], True, row["id"] + ".no output")
        result["parser_controls"] = {"receipt": pin(parser_path), "passed": True, "count": 5}
        errors = [row for row in report["cases"] if row["kind"] == "error" and row["language"] == "de-DE"]
        clean = [row for row in report["cases"] if row["kind"] == "clean" and row["language"] == "de-DE"]
        result["metrics"] = {
            "supported_errors": len(errors), "exact_fixes": sum(row["status"] == "success" and row["corrected"] == row["expected"] for row in errors),
            "supported_clean": len(clean), "changed_clean": sum(row["corrected"] != row["input"] for row in clean),
            "status_counts": dict(Counter(row["status"] for row in report["cases"])),
            "original_controls_passed": 8, "segmented_controls_passed": 6, "segmented_probes_passed": 2,
            "setup_ms": report["setup_ms"], "peak_process_rss_bytes": report["peak_process_rss_bytes"],
            "short_timing": report["warm_checks_up_to_64_wordpieces"], "engineering_budgets": report["engineering_budgets"],
            "probe_timings": [{key: row[key] for key in ("id", "tokens_first_pass", "initial_model_tokens_total", "initial_segment_count", "timing")}
                              for row in report["long_complete_check_probes"] + probes]
        }
        result["source_binding"] = {
            "tracked_sources": tracked, "workspace_sources": workspace,
            "resolved_packages": len(before["dependency_inputs"]["packages"]),
            "resolved_dart_files": sum(item["dart_file_count"] for item in before["dependency_inputs"]["packages"].values()),
            "sdk_pins": len(before["sdk_inputs"])
        }
        result["counts"] = {"assertions": audit.assertions, "reconstructed_results": audit.results,
                            "reconstructed_findings": audit.findings, "checked_source_segments": audit.segments,
                            "measured_rows_with_three_samples": 35, "samples_in_those_rows": 105}
        result["passed"] = True
    except Exception as error:
        result["error"] = type(error).__name__ + ": " + str(error)
        result["assertions_before_failure"] = audit.assertions
    result["audit_script"] = pin(Path(__file__))
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: result.get(key) for key in ("passed", "error", "counts", "source_binding")}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
