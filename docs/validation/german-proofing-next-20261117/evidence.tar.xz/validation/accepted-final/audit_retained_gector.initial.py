#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,subprocess
ROOT=Path('/workspace/scratch/52d8185c7137/quds_office_suite')
OLD=Path('/workspace/scratch/52d8185c7137/validation/integrated-final')
OUT=Path('/workspace/scratch/52d8185c7137/validation/accepted-final')
BASE='121f3be504a89e56bde40bda8f93f4e81d8c2503';HEAD='6971819edfb53ed40e97fc2b4cd436e89a39a648'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def committed(path):
 p=subprocess.run(['git','show',HEAD+':'+path],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 return hashlib.sha256(p.stdout).hexdigest() if p.returncode==0 else None
issues=[];groups={};allowed={'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart'}
for group in ['gector','gector_analysis']:
 d=OLD/'proofing'/group;r=json.loads((d/'receipt.json').read_text());before=json.loads((d/'inputs-before.json').read_text());after=json.loads((d/'inputs-after.json').read_text())
 if before!=after or r['status']!='passed':issues.append(group+' prior qualification invalid')
 changed=[p for p,h in before.items() if not (ROOT/p).is_file() or sha(ROOT/p)!=h]
 if set(changed)!=allowed:issues.append(group+' full-map exceptions differ from the sole unrelated ODT writer')
 model_paths=[p for p in before if p.startswith(('packages/quds_proofing_gector/','packages/quds_office_engine/lib/src/proofing/','tools/proofing/german_model/'))]
 model_drift=[p for p in model_paths if sha(ROOT/p)!=before[p] or committed(p)!=before[p]]
 if model_drift:issues.append(group+' proofing/provider/quality source drift')
 rb=json.loads(gzip.decompress((d/'runtime-before.json.gz').read_bytes()));ra=json.loads(gzip.decompress((d/'runtime-after.json.gz').read_bytes()))
 drift=[p for p,h in rb.items() if not Path(p).is_file() or sha(Path(p))!=h]
 if rb!=ra or drift:issues.append(group+' declared runtime/dependency/native fixture drift')
 if sha(d/r['log'])!=r['log_sha256']:issues.append(group+' historical log changed')
 groups[group]={'original_source_commit':BASE,'receipt_sha256':sha(d/'receipt.json'),'source_input_count':len(before),'full_old_map_identical':False,'full_map_exceptions':changed,'unchanged_model_related_inputs':len(model_paths),'model_related_differences':model_drift,'runtime_inputs':len(rb),'runtime_drift':drift,'freshly_rerun':False,'status':'passed_under_documented_source_scope'}
 if r.get('tests'):groups[group]['tests']={k:r['tests'][k] for k in ['passed','skipped','failed']}
quality_base=ROOT/'docs/validation/german-proofing-next-20261117/integrated-quality';quality={};union={}
for name in ['build.json.gz','frozen.json.gz','prospective.json.gz']:
 p=quality_base/name;raw=gzip.decompress(p.read_bytes());r=json.loads(raw);a=r['source_files'];b=r['source_files_after'];drift=[];tracked=0;workspace={}
 if a!=b or r.get('source_stable') is not True:issues.append(name+' original source map was not stable')
 for path,h in a.items():
  if path in union and union[path]!=h:issues.append(name+' source map disagrees with other quality report')
  union[path]=h
  if not (ROOT/path).is_file() or sha(ROOT/path)!=h:drift.append(path)
  if path in {'.dart_tool/package_config.json','pubspec.lock'}:workspace[path]=h
  else:
   tracked+=1
   if committed(path)!=h:drift.append(path+' (commit)')
 if drift:issues.append(name+' selected source differs from6971819')
 if name=='build.json.gz':
  if not r.get('passed') or not r.get('dependencies_stable') or not r.get('sdk_stable'):issues.append('Quality AOT build was not accepted')
 else:
  if not r.get('completed') or not r.get('operational_passed') or not r.get('status_contract_passed'):issues.append(name+' did not pass operational contract')
 quality[name]={'compressed_sha256':sha(p),'raw_sha256':hashlib.sha256(raw).hexdigest(),'selected_inputs':len(a),'tracked_matching_inputs':tracked,'workspace_inputs':workspace,'current_or_committed_differences':drift,'original_measurement_commit':BASE,'new_inference_run':False}
product_diff=git('diff','--name-only',BASE,HEAD,'--','packages','tools').splitlines()
expected={'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart','packages/quds_office_engine/test/odt_document_writer_test.dart','packages/quds_office_engine/test/odt_section_continuation_test.dart'}
if set(product_diff)!=expected:issues.append('Source delta is not the approved three-file ODF change')
report={'audited_at':datetime.now(timezone.utc).isoformat(),'original_source_commit':BASE,'accepted_source_commit':HEAD,'status':'passed' if not issues else 'failed','issues':issues,'product_source_diff':product_diff,'retained_gector_cohorts':groups,'retained_native_quality_reports':quality,'native_quality_unique_selected_inputs':len(union),'interpretation':'The121f GECToR194 execution remains identified by its original run. Its full conservative map changes only in the unrelated ODT writer, covered by fresh accepted ODF validation and full engine analysis. All declared provider/proofing/quality sources and runtime/native inputs are unchanged. The native incremental quality build/run reports have68 exact selected inputs, all identical at6971819; no old receipt is relabeled as a new inference run.'}
(OUT/'retained-gector-native-quality.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'issues':issues,'quality_selected_inputs':len(union),'gector_exceptions':{g:r['full_map_exceptions'] for g,r in groups.items()}},indent=2))
raise SystemExit(0 if report['status']=='passed' else 1)
