#!/usr/bin/env python3
from pathlib import Path
import importlib.util,json,subprocess,time
base=Path('/workspace/scratch/52d8185c7137/validation/final/proofing')
spec=importlib.util.spec_from_file_location('cohorts',base/'run_cohort.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=base/'gector_analysis';out.mkdir(exist_ok=False)
selected=json.loads((base/'gector/inputs-before.json').read_text());paths=[m.ROOT/p for p in selected]
def source():return {str(p.relative_to(m.ROOT)):m.sha(p) for p in paths}
before=source();m.save(out,'inputs-before.json',before)
runtime,roots=m.external_inputs();runtime_before={str(p):m.sha(p) for p in sorted(runtime)}
argv=[str(m.DART),'analyze','--fatal-infos','packages/quds_proofing_gector/lib','packages/quds_proofing_gector/test','packages/quds_proofing_gector/tool','tools/proofing/german_model/incremental_quality.dart','tools/proofing/german_model/run_incremental_quality.dart']
r={'started_at':m.now(),'source_head':m.git('rev-parse','HEAD'),'source_count':len(before),'source_policy':'Same complete explicit engine/legacy/GECToR library/test/tool/fixture and new external incremental quality helper/corpus inputs as the final GECToR test cohort.','runtime_inputs':m.savegz(out,'runtime-before.json.gz',runtime_before),'argv':argv,'cwd':str(m.ROOT),'status':'running'};m.save(out,'receipt.json',r)
log=out/'analysis.log';start=time.monotonic()
with log.open('wb') as f:
 try:p=subprocess.run(argv,cwd=m.ROOT,env=m.ENV,stdout=f,stderr=subprocess.STDOUT,timeout=600);code=p.returncode
 except subprocess.TimeoutExpired:code=124
after=source();m.save(out,'inputs-after.json',after);runtime_after={str(p):m.sha(p) for p in sorted(runtime)}
changes=[p for p,h in before.items() if after.get(p)!=h];runtime_changes=[p for p,h in runtime_before.items() if runtime_after.get(p)!=h]
r.update({'finished_at':m.now(),'source_head_after':m.git('rev-parse','HEAD'),'exit_code':code,'elapsed_seconds':time.monotonic()-start,'log':log.name,'log_sha256':m.sha(log),'source_changes':changes,'runtime_changes':runtime_changes,'runtime_inputs_after':m.savegz(out,'runtime-after.json.gz',runtime_after),'status':'passed' if code==0 and not changes and not runtime_changes else 'failed'});m.save(out,'receipt.json',r);print(json.dumps({k:r[k] for k in ['status','exit_code','elapsed_seconds','source_changes','runtime_changes']}),flush=True)
raise SystemExit(0 if r['status']=='passed' else 1)
