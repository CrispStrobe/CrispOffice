#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, time

ROOT=Path('/workspace/scratch/52d8185c7137/quds_office_suite')
OUT=Path('/workspace/scratch/52d8185c7137/validation/integrated-final/integration-node')
RUNTIME=Path('/workspace/scratch/52d8185c7137/runtime')
ENGINE=ROOT/'packages/quds_office_engine'
DART=RUNTIME/'flutter/bin/cache/dart-sdk/bin/dart'
ENV={**os.environ,'PUB_CACHE':str(RUNTIME/'pub-cache'),'TMPDIR':str(RUNTIME/'tmp'),'FLUTTER_ROOT':str(RUNTIME/'flutter'),'CI':'true','DART_SUPPRESS_ANALYTICS':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','XDG_CONFIG_HOME':str(RUNTIME/'config'),'XDG_CACHE_HOME':str(RUNTIME/'cache'),'XDG_DATA_HOME':str(RUNTIME/'data')}
selected=sorted(p for p in (ENGINE/'test').glob('*.dart') if p.name.startswith(('odt_','odf_','odp_')))
for name in ['word_comment_proofing_styles_test.dart','word_comment_test.dart','word_note_bookmark_edit_test.dart','word_section_clone_fidelity_test.dart','office_search_fidelity_test.dart']:
 selected.append(ENGINE/'test'/name)
excluded_native=[str(p.relative_to(ENGINE)) for p in selected if "import 'dart:io';" in p.read_text() and p.name!='odt_comment_fidelity_test.dart']
selected=sorted(p for p in set(selected) if str(p.relative_to(ENGINE)) not in excluded_native)

# Bind the full engine library, selected tests, activated lock, and key SDK inputs.
paths=sorted(set(list((ENGINE/'lib').rglob('*.dart'))+list((ROOT/'packages/legacy_doc_parser/lib').rglob('*.dart'))+selected+[ROOT/'pubspec.yaml',ROOT/'pubspec.lock',ROOT/'analysis_options.yaml',ENGINE/'pubspec.yaml',ENGINE/'analysis_options.yaml',ROOT/'packages/legacy_doc_parser/pubspec.yaml']))
paths=sorted(set(paths)|{ENGINE/'test/fixtures/zotero/word_document.xml'}|{p for sub in ['tool/proofing','third_party/proofing'] for p in (ENGINE/sub).rglob('*') if p.is_file() and '__pycache__' not in p.parts})
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def snapshot():return {str(p.relative_to(ROOT)):sha(p) for p in paths}
def save(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()

def parse_test(log):
 tests={};done={};errors=[];finished=None
 for line in log.read_text().split('\n'):
  if not line.strip():continue
  try:e=json.loads(line)
  except json.JSONDecodeError:continue
  if e.get('type')=='testStart': tests[e['test']['id']]=e['test']
  elif e.get('type')=='testDone':done[e['testID']]=e
  elif e.get('type')=='error':errors.append(e)
  elif e.get('type')=='done':finished=e
 substantive=[(t,done.get(i)) for i,t in tests.items() if not t.get('metadata',{}).get('hidden',False) and not done.get(i,{}).get('hidden',False) and not t['name'].startswith('loading ')]
 return {'started':len(substantive),'passed':sum(d is not None and d.get('result')=='success' and not d.get('skipped',False) for t,d in substantive),'skipped':sum(d is not None and d.get('skipped',False) for t,d in substantive),'failed':sum(d is not None and d.get('result')!='success' for t,d in substantive),'unfinished':sum(d is None for t,d in substantive),'errors':errors,'final_event':finished}

receipt={'started_at':datetime.now(timezone.utc).isoformat(),'source_head':git('rev-parse','HEAD'),'source_tree':git('rev-parse','HEAD^{tree}'),'scope':'All engine ODT/ODF/ODP prefixed test files, comment proofing and comment/note/bookmark/section preservation. Strict analysis of both ODF writers and selected tests. Local checks only.','test_files':[str(p.relative_to(ENGINE)) for p in selected],'excluded_native_test_files':excluded_native,'node_scope':'Portable ODF and preservation files only. Native-only fixture/environment helpers are excluded explicitly; comment fixtures have a dart.library.io guard.','commands':[],'status':'running','runtime':{'dart_version':subprocess.check_output([str(DART),'--version'],env=ENV,text=True).strip(),'dart_sha256':sha(DART),'dart_aotruntime_sha256':sha(DART.parent/'dartaotruntime'),'framework_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=RUNTIME/'flutter',text=True).strip()},'input_count':len(paths)}
before=snapshot();save('inputs-before.json',before);save('receipt.json',receipt)
commands=[('odf-vm',[str(DART),'test','--platform=node','--reporter','json','--concurrency','2',*[str(p.relative_to(ENGINE)) for p in selected]],900),('odf-analysis',[str(DART),'analyze','--fatal-infos','lib/src/word/serial/odt_document_writer.dart','lib/src/slide/serial/odp_presentation_writer.dart',*[str(p.relative_to(ENGINE)) for p in selected]],300)]
commands=commands[:1]
for name,argv,limit in commands:
 print('START '+name,flush=True);start=time.monotonic();log=OUT/(name+('.jsonl' if name=='odf-vm' else '.log'))
 with log.open('wb') as f:
  try:cp=subprocess.run(argv,cwd=ENGINE,env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=limit);code=cp.returncode
  except subprocess.TimeoutExpired:code=124
 entry={'name':name,'argv':argv,'cwd':str(ENGINE),'exit_code':code,'elapsed_seconds':time.monotonic()-start,'log':log.name,'log_sha256':sha(log)}
 if name=='odf-vm':entry['tests']=parse_test(log)
 receipt['commands'].append(entry);save('receipt.json',receipt);print(json.dumps(entry),flush=True)
after=snapshot();save('inputs-after.json',after)
changed=[p for p,h in before.items() if after.get(p)!=h]
receipt.update({'finished_at':datetime.now(timezone.utc).isoformat(),'head_after':git('rev-parse','HEAD'),'input_changes':changed,'status':'passed' if not changed and all(c['exit_code']==0 for c in receipt['commands']) and receipt['commands'][0]['tests']['failed']==0 and receipt['commands'][0]['tests']['unfinished']==0 else 'failed'})
save('receipt.json',receipt);print(json.dumps({'status':receipt['status'],'tests':receipt['commands'][0].get('tests'),'input_changes':changed}),flush=True)
raise SystemExit(0 if receipt['status']=='passed' else 1)
