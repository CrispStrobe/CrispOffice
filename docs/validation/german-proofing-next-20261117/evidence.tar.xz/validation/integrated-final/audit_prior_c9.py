#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,gzip,hashlib
ROOT=Path('/workspace/scratch/52d8185c7137/quds_office_suite')
PRIOR=Path('/workspace/scratch/52d8185c7137/validation/final')
OUT=Path('/workspace/scratch/52d8185c7137/validation/integrated-final')
OLD='c9bf20a6f35e6c4607b9377716968f84c3bc67bb';NEW='121f3be504a89e56bde40bda8f93f4e81d8c2503'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def blob(rev,path):
 p=subprocess.run(['git','show',rev+':'+path],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 return hashlib.sha256(p.stdout).hexdigest() if p.returncode==0 else None
all_changed=git('diff','--name-only',OLD,NEW).splitlines()
prior_seal=json.loads((PRIOR/'proofing/final-source-binding.json').read_text());cohorts={};issues=[]
for group in ['engine_vm','engine_node','editor']:
 d=PRIOR/'proofing'/group;r=json.loads((d/'receipt.json').read_text())
 expected_receipt=prior_seal['groups'][group]['receipt_sha256']
 if sha(d/'receipt.json')!=expected_receipt:issues.append(group+' historical receipt changed')
 before=json.loads((d/'inputs-before.json').read_text());after=json.loads((d/'inputs-after.json').read_text())
 if before!=after:issues.append(group+' historical source maps differ')
 current_changed=[]
 for path,h in before.items():
  if not (ROOT/path).is_file() or sha(ROOT/path)!=h:current_changed.append(path)
 runtime_before=json.loads(gzip.decompress((d/'runtime-before.json.gz').read_bytes()))
 runtime_after=json.loads(gzip.decompress((d/'runtime-after.json.gz').read_bytes()))
 if runtime_before!=runtime_after:issues.append(group+' historical runtime maps differ')
 runtime_drift=[p for p,h in runtime_before.items() if not Path(p).is_file() or sha(Path(p))!=h]
 if runtime_drift:issues.append(group+' declared runtime input drift')
 if sha(d/r['log'])!=r['log_sha256']:issues.append(group+' historical test log changed')
 cohorts[group]={'original_source_commit':OLD,'original_receipt_sha256':sha(d/'receipt.json'),'prior_tests':{k:r['tests'][k] for k in ['passed','skipped','failed']},'full_old_source_map_identical':not current_changed,'changed_paths_in_conservative_old_map':current_changed,'declared_runtime_inputs':len(runtime_before),'declared_runtime_drift':runtime_drift,'freshly_rerun':False}
old_paths=git('ls-tree','-r','--name-only',OLD).splitlines()
def selected(name):
 return name.startswith(('packages/quds_office_engine/lib/src/proofing/','packages/quds_office_engine/test/proofing/','packages/quds_office_editor/lib/','packages/legacy_doc_parser/lib/')) or ('hyphenation' in name and name.startswith('packages/quds_office_engine/lib/')) or name in {'packages/quds_office_engine/lib/quds_office_engine.dart','packages/quds_office_editor/pubspec.yaml','packages/quds_office_engine/pubspec.yaml','packages/legacy_doc_parser/pubspec.yaml','analysis_options.yaml','pubspec.yaml','packages/quds_office_editor/analysis_options.yaml','packages/quds_office_engine/analysis_options.yaml'}
core=[p for p in old_paths if selected(p)]
core+=list(json.loads((PRIOR/'proofing/editor/inputs-before.json').read_text()).keys()&{p for p in old_paths if p.startswith('packages/quds_office_editor/test/')})
core=sorted(set(core));core_diff=[]
for p in core:
 if blob(OLD,p)!=blob(NEW,p) or blob(NEW,p)!=sha(ROOT/p):core_diff.append(p)
if core_diff:issues.append('Previously qualified proofing/editor core files differ')
python_tools=sorted(p for p in old_paths if p.startswith('tools/proofing/german_model/') and p.endswith('.py'))
python_diff=[p for p in python_tools if blob(OLD,p)!=blob(NEW,p) or blob(NEW,p)!=sha(ROOT/p)]
shared=['tools/proofing/german_model/incremental_quality.dart','tools/proofing/german_model/run_incremental_quality.dart','tools/proofing/german_model/prospective_cases_20261117.json','tools/proofing/german_model/cases.json','packages/quds_proofing_gector/test/incremental_quality_test.dart']
shared_diff=[p for p in shared if blob(OLD,p)!=blob(NEW,p) or blob(NEW,p)!=sha(ROOT/p)]
if python_diff:issues.append('Original Python qualification/build tools differ')
if shared_diff:issues.append('Shared quality helper/corpus differs')
report={'audited_at':datetime.now(timezone.utc).isoformat(),'prior_source_commit':OLD,'integrated_source_commit':NEW,'status':'passed' if not issues else 'failed','issues':issues,'all_changed_paths':all_changed,'prior_cohorts':cohorts,'unchanged_proofing_editor_core':{'selected_paths':core,'count':len(core),'differences':core_diff},'original_python_tools':{'selected_paths':python_tools,'count':len(python_tools),'differences':python_diff},'shared_quality_files':{'paths':shared,'differences':shared_diff},'dependency_refresh':'setup/dependency-refresh.json','interpretation':'The historical c9 engine VM/Node602 and Flutter176 executions are preserved as historical. Their domain-specific proofing/editor files and declared runtime/dependency inputs are unchanged. Their broader conservative source maps contain incoming ODF implementation changes, explicitly enumerated here; this audit does not relabel old executions as fresh complete-tree121f runs. Fresh affected ODF/GECToR tests and whole-engine analysis provide the separate combined-source checks.'}
(OUT/'prior-c9-continuity.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'issues':issues,'core_paths':len(core),'python_tools':len(python_tools),'changed_conservative_paths':{g:c['changed_paths_in_conservative_old_map'] for g,c in cohorts.items()}},indent=2))
raise SystemExit(0 if report['status']=='passed' else 1)
