#!/usr/bin/env python3
from pathlib import Path
import importlib.util,json,subprocess,time
base=Path('/workspace/scratch/52d8185c7137/validation/integrated-final/proofing')
spec=importlib.util.spec_from_file_location('cohorts',base/'run_cohort.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=base/'strict_analysis';out.mkdir(exist_ok=False)
engine=m.ROOT/'packages/quds_office_engine';editor=m.ROOT/'packages/quds_office_editor'
inputs=set()
for sub in ['tool/proofing','third_party/proofing']:
 inputs.update(p for p in (engine/sub).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for p in engine.rglob('*'):
 if p.is_file() and p.suffix=='.dart' and not {'build','.dart_tool'}.intersection(p.parts):inputs.add(p)
for pkg in [editor,m.ROOT/'packages/legacy_doc_parser']:
 inputs.update(p for p in (pkg/'lib').rglob('*') if p.is_file())
inputs.update({m.ROOT/'analysis_options.yaml',m.ROOT/'pubspec.yaml',m.ROOT/'pubspec.lock',engine/'pubspec.yaml',engine/'analysis_options.yaml',editor/'pubspec.yaml',editor/'analysis_options.yaml',editor/'test/word_manual_proofing_test.dart'})
def source():return {str(p.relative_to(m.ROOT)):m.sha(p) for p in sorted(inputs)}
before=source();m.save(out,'inputs-before.json',before)
runtime,roots=m.external_inputs();runtime_before={str(p):m.sha(p) for p in sorted(runtime)}
r={'started_at':m.now(),'source_head':m.git('rev-parse','HEAD'),'source_count':len(before),'source_policy':'All engine authored Dart files including tests/tools/examples, complete editor and legacy dependency libraries, manual proofing regression and configuration/lock. Runtime map uses the same declared external libraries and executable scope as the test cohorts.','runtime_inputs':m.savegz(out,'runtime-before.json.gz',runtime_before),'commands':[],'status':'running'}
m.save(out,'receipt.json',r)
for name,cwd,argv in [('engine-full',engine,[str(m.DART),'analyze','--fatal-infos']),('editor-proofing',editor,[str(m.DART),'analyze','--fatal-infos','lib/src/proofing','test/word_manual_proofing_test.dart'])]:
 print('START '+name,flush=True);log=out/(name+'.log');start=time.monotonic()
 with log.open('wb') as f:
  try:p=subprocess.run(argv,cwd=cwd,env=m.ENV,stdout=f,stderr=subprocess.STDOUT,timeout=600);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 c={'name':name,'argv':argv,'cwd':str(cwd),'exit_code':code,'elapsed_seconds':time.monotonic()-start,'log':log.name,'log_sha256':m.sha(log)}
 r['commands'].append(c);m.save(out,'receipt.json',r);print(json.dumps(c),flush=True)
after=source();m.save(out,'inputs-after.json',after);runtime_after={str(p):m.sha(p) for p in sorted(runtime)}
changes=[p for p,h in before.items() if after.get(p)!=h];runtime_changes=[p for p,h in runtime_before.items() if runtime_after.get(p)!=h]
r.update({'finished_at':m.now(),'source_head_after':m.git('rev-parse','HEAD'),'source_changes':changes,'runtime_changes':runtime_changes,'runtime_inputs_after':m.savegz(out,'runtime-after.json.gz',runtime_after),'status':'passed' if all(c['exit_code']==0 for c in r['commands']) and not changes and not runtime_changes else 'failed'})
m.save(out,'receipt.json',r);print(json.dumps({'status':r['status'],'source_changes':changes,'runtime_changes':runtime_changes}),flush=True)
raise SystemExit(0 if r['status']=='passed' else 1)
