#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
ROOT=Path('/workspace/scratch/52d8185c7137/quds_office_suite')
BASE=Path('/workspace/scratch/52d8185c7137/validation/integrated-final')
REVISION='121f3be504a89e56bde40bda8f93f4e81d8c2503'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records=[('odf',BASE/'integration'),('odf_node',BASE/'integration-node'),*[(g,BASE/'proofing'/g) for g in ['strict_analysis','gector','gector_analysis']]]
source={};runtime={};issues=[];groups={};logs={}
for group,directory in records:
 r=json.loads((directory/'receipt.json').read_text())
 if r['status']!='passed':issues.append(group+' receipt is not passed')
 before=json.loads((directory/'inputs-before.json').read_text());after=json.loads((directory/'inputs-after.json').read_text())
 if before!=after:issues.append(group+' before/after source mismatch')
 for p,h in before.items():
  if p in source and source[p]!=h:issues.append(group+' source conflicts at '+p)
  source[p]=h
 if (directory/'runtime-before.json.gz').exists():
  rb=json.loads(gzip.decompress((directory/'runtime-before.json.gz').read_bytes()));ra=json.loads(gzip.decompress((directory/'runtime-after.json.gz').read_bytes()))
  if rb!=ra:issues.append(group+' before/after runtime mismatch')
  for p,h in rb.items():
   if p in runtime and runtime[p]!=h:issues.append(group+' runtime conflicts at '+p)
   runtime[p]=h
 cmds=r.get('commands',[r])
 for c in cmds:
  if c.get('exit_code')!=0:issues.append(group+' nonzero command')
  if c.get('log'):
   p=directory/c['log'];actual=sha(p)
   if actual!=c['log_sha256']:issues.append(group+' log hash mismatch')
   logs[str(p.relative_to(BASE))]=actual
 groups[group]={'receipt':str((directory/'receipt.json').relative_to(BASE)),'receipt_sha256':sha(directory/'receipt.json'),'source_inputs':len(before),'status':r['status']}
 if r.get('tests'):groups[group]['tests']={k:r['tests'][k] for k in ['passed','skipped','failed','unfinished']}
 elif group in {'odf','odf_node'}:groups[group]['tests']={k:r['commands'][0]['tests'][k] for k in ['passed','skipped','failed','unfinished']}
bindings={}
for p,h in sorted(source.items()):
 q='docs/validation/german-proofing-continuation-20261117/workspace-pubspec.lock' if p=='pubspec.lock' else p
 result=subprocess.run(['git','show',REVISION+':'+q],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 committed=hashlib.sha256(result.stdout).hexdigest() if result.returncode==0 else None
 if committed!=h:issues.append('Committed source mismatch: '+p)
 if not (ROOT/p).is_file() or sha(ROOT/p)!=h:issues.append('Current source mismatch: '+p)
 if q!=p:bindings[p]={'committed_path':q,'sha256':h}
for p,h in runtime.items():
 if not Path(p).is_file() or sha(Path(p))!=h:issues.append('Current declared runtime mismatch: '+p)
for name,mapping in [('final-source-inputs.json.gz',source),('final-runtime-inputs.json.gz',runtime)]:
 (BASE/'proofing'/name).write_bytes(gzip.compress((json.dumps(mapping,sort_keys=True,indent=2)+'\n').encode(),mtime=0))
record={'sealed_at':datetime.now(timezone.utc).isoformat(),'source_commit':REVISION,'source_tree':subprocess.check_output(['git','rev-parse',REVISION+'^{tree}'],cwd=ROOT,text=True).strip(),'status':'passed' if not issues else 'failed','source_inputs':len(source),'declared_runtime_inputs':len(runtime),'groups':groups,'issues':issues,'workspace_input_bindings':bindings,'raw_log_hashes':logs,'source_manifest':{'path':'final-source-inputs.json.gz','sha256':sha(BASE/'proofing/final-source-inputs.json.gz')},'runtime_manifest':{'path':'final-runtime-inputs.json.gz','sha256':sha(BASE/'proofing/final-runtime-inputs.json.gz')},'counting_policy':'Visible testDone success events, excluding hidden loading/setup/teardown lifecycle events. The portable Node ODF cohort repeats a subset of VM tests. Prior c9 engine proofing and Flutter cohorts remain historical and are audited separately for source/dependency equivalence. Cohorts overlap and are not an additive unique-test total.','limits':['Local runtime/source regression qualification; no CI queried or awaited.','Declared runtime map includes activated external package library files, package YAML, package config, runtime launchers/executables, and native fixture pack when used. It is not a complete OS/font/dynamic-library closure.','Native fixture execution is development validation, not distribution approval or intended-device qualification.','These are fresh affected-cohort executions at the integrated source. Earlier c9 proofing/Flutter evidence remains separate and is not relabeled as a rerun.']}
(BASE/'proofing/final-source-binding.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['status','source_commit','source_inputs','declared_runtime_inputs','issues','groups']},indent=2))
raise SystemExit(0 if record['status']=='passed' else 1)
