# Fresh runtime recovery for spelling closeout

This directory preserves runtime setup for source
`04be224b4a7f469476416ee86dc780cb6a1c0990`. It contains no SDK or dependency
binaries and no product test results.

`recovery-summary.json` records the new setup result. `current/` contains the
executed setup scripts, commands, logs, pinned package manifest, resolved lock,
and successful runtime receipt. `current-index.json` indexes those files by
size and SHA-256. The before/after source records cover all 3,638 checked-out
inputs under `packages/`, `apps/`, and `tools/`, plus root manifest/configuration.
Every input matched its immutable Git blob before setup and stayed unchanged.

The complete official Flutter 3.47.8 distribution was downloaded, verified
against the recorded SHA-256, and extracted. The installed Dart 3.13.7 and
Flutter tester executable hashes match the earlier qualification. All 162
hosted package archives were newly downloaded and verified against the pinned
manifest. Both workspace and Flutter-tools dependency graphs resolved offline
with enforced, unchanged lockfiles. The workspace contains 110 resolved
packages and all eleven copied manifests match the product checkout.

The SDK, package cache and temporary/configuration directories are under
`/workspace/scratch/ded03daba38b/runtime`. The separately resolved workspace is
`/workspace/scratch/ded03daba38b/spelling-validation`. Its production source,
tests and assets link to the unchanged Git checkout. No `.dart_tool` link was
created in the product checkout. `current/env.sh` records the setup environment.

`inherited-setup.tar.gz`, `inherited-index.json`, and `inherited/` preserve the
24-member prior setup bundle used to recover the reproducible scripts and
expected package hashes. Those historical logs are not new runtime executions.
`setup-provenance.json` records exact archive verification and the only script
adaptations: task/runtime/workspace paths and omission of the repository graph
symlink. The corrected package hash writer was used from the start, so the
historical newline correction did not recur.

All current setup process exits were zero. No product tests or GitHub Actions,
workflow, check or CI-status calls were part of runtime setup. The parent
qualification owns regression, isolated-baseline, portable and static results.
