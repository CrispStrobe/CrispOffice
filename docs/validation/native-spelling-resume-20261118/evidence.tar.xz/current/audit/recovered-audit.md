# Independent audit of recovered spelling evidence

The recovered archive is internally sound, and its raw streams support the
reported counts. It is an incremental checkpoint, not final qualification for
the later integrated source.

## What was independently verified

- The `evidence.tar.xz` archive is 831,628 bytes, SHA-256
  `bd9f1b566b8ac757e35a91edee3df3cafe4662e1d7946549954bd3548f9e28b9`.
  All 64 members match the saved index by size, SHA-256 and Git blob identity.
  Member names are unique, relative and regular files; extraction did not follow
  links or permit paths outside the audit directory.
- Reparsed raw events show 1,120 engine registrations in 30 suites and 183
  editor registrations in 14 suites. Every started event finishes exactly once,
  actual test process exits are zero, and there are no failed/skipped substantive
  cases, error events, layout diagnostics or unsuccessful completion events.
- The engine has eight repeated suite/name identities, each registered twice.
  They occur in two unchanged baseline grammar fixture files. The 1,303 total
  registrations represent 1,295 distinct named cases.
- The four new test files account for 41 distinct passing cases: 25 German
  projection, eight native identifier, five independent native review and three
  Word vocabulary cases. All four files are absent on the isolated baseline
  and unchanged from spelling checkpoint `f482b06f` through final product
  `04be224b`.
- Before/after source and environment records are equal. All 637 engine and
  621 editor source records match their recorded commit `fb1fd4dc`; all 5,716
  environment records per cohort are unchanged.
- The correction preserves the original executed runner, raw-event hashes and
  receipt. The original engine receipt says `failed` solely because its unique
  name guard rejects the eight repetitions; all test outcomes and the actual
  process exit already passed. The original editor receipt passed. No product
  test rerun is needed merely to correct this accounting.

## Remaining source and recovery gaps

The recovered full run does not bind to final product `04be224b` without a
qualification step. Two recorded editor library inputs changed after
`fb1fd4dc`: `word_zotero_dialog.dart` and `word_zotero_library.dart`. This is the
expected stored-details integration, and it justifies the planned fresh final
proofing run.

The saved regression runner's broad source scan covers each workspace member's
`lib/` and `assets/`, but omits 44 declared asset files: fourteen editor fonts
and two licenses, twenty-two editor templates, three example fonts and three
example notices/licenses. The final source binding should include every declared
Flutter asset and relevant member analysis/test configuration. This is a guard
coverage limitation, not an observed test failure. The selected 44 proofing
suites and two incoming stored-details suites contain no relative test imports;
no additional relative helper or Flutter test-configuration file was found.

The archive contains no final isolated-baseline, portable VM/native/JavaScript
or static-analysis receipts. The last session's narrative cannot substitute
for those missing artifacts. Preserve new actual exits, raw streams, identical
test/source bindings and any initial failed attempts when regenerating them.

## Incoming Zotero evidence

All sixteen indexed files under `zotero-offline-workflow-20261118` match their
saved fingerprints. An independent reparse gives 299 passing substantive cases
in 22 suites, plus 22 excluded lifecycle cases. Every one of the 321 starts
finishes exactly once; the actual process exit is zero. Twenty-two empty raw
lines accompanying Flutter notifications are whitespace, not parse errors.

All 554 recorded source inputs from qualified product `02da86d9` match final
spelling product `04be224b`. The recorded before/after source, dependency,
runtime and workspace digests agree, their canonical before hashes recompute,
and their changed-path lists are empty. The two stored-details suites contain
21 of the 299 cases. This evidence can be described as inherited qualification;
do not add it to a fresh overlapping Zotero cohort or the spelling test count.

## Closeout

Use the final 04be224b source for the new qualification, then seal the complete
archive, save it remotely and read back the complete bytes and member index.
The final report should distinguish recovered runs, newly executed final runs,
inherited Zotero evidence, the isolated baseline comparison and the portable
panel. Later concurrent branches remain outside this fixed product cutoff.

This audit ran no product tests, changed no product files and queried no
GitHub Actions, workflow, check or CI-status endpoint. The accompanying
`recovered-audit.json` contains the independently derived counts and bindings.

### Audit-script development note

The first audit-parser attempt rejected an empty line in the incoming Zotero
stream. It was corrected to count and ignore whitespace-only lines while still
rejecting any unexpected nonempty JSON record. No product result was changed
and no product test was executed by this audit.
