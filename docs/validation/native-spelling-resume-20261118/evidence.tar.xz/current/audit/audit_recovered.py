#!/usr/bin/env python3
"""Independently inspect saved spelling and incoming Zotero evidence.

This script reads exact Git objects and archived process records. It does not
execute product tests, query CI, or alter the product checkout.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import tarfile
import yaml

ROOT = Path('/workspace/scratch/ded03daba38b')
REPO = ROOT / 'quds_office_suite'
OUT = ROOT / 'independent-audit'
SAVED = REPO / 'docs/validation/native-spelling-resume-20261118'
EXTRACTED = OUT / 'recovered'
ZOTERO = REPO / 'docs/validation/zotero-offline-workflow-20261118'
FINAL = '04be224b4a7f469476416ee86dc780cb6a1c0990'
ORIGINAL = 'fb1fd4dc3edda824c3e043c035dbfad1f0fe0869'
BASELINE = '4dceb86e9fae51877bb5b7dc01e7a8bc721cb6ea'
SPELLING = 'f482b06fc47545c8b03124c30ea78f54e8e4b9e5'


def fingerprint(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def read(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


def git_tree(commit):
    result = {}
    for row in subprocess.check_output(['git', 'ls-tree', '-rz', commit], cwd=REPO).split(b'\0'):
        if row:
            meta, name = row.split(b'\t', 1)
            if meta.split()[1] == b'blob':
                result[name.decode()] = meta.split()[2].decode()
    return result


def events(path):
    data = path.read_bytes()
    lines = (gzip.decompress(data) if path.suffix == '.gz' else data).decode().splitlines()
    parsed, envelopes, blank_lines = [], [], []
    for number, line in enumerate(lines, 1):
        if not line.strip():
            blank_lines.append(number)
            continue
        obj = json.loads(line)
        if isinstance(obj, dict) and 'type' in obj:
            parsed.append(obj)
        elif isinstance(obj, list) and all(isinstance(v, dict) and 'event' in v for v in obj):
            envelopes.append({'line': number, 'value': obj})
        else:
            raise AssertionError(('Unexpected event record', number, obj))
    starts = [e['test'] for e in parsed if e['type'] == 'testStart']
    finishes = [e for e in parsed if e['type'] == 'testDone']
    suites = [e['suite'] for e in parsed if e['type'] == 'suite']
    assert len(starts) == len({t['id'] for t in starts})
    assert len(finishes) == len({t['testID'] for t in finishes})
    assert {t['id'] for t in starts} == {t['testID'] for t in finishes}
    assert len(suites) == len({s['id'] for s in suites})
    starts_by_id = {t['id']: t for t in starts}
    suites_by_id = {s['id']: s for s in suites}
    cases, excluded = [], []
    for finish in finishes:
        start = starts_by_id[finish['testID']]
        case = {'id': finish['testID'], 'name': start['name'],
                'suite': suites_by_id[start['suiteID']]['path'],
                'result': finish['result'], 'skipped': finish.get('skipped', False)}
        hidden = finish.get('hidden') or start['name'].endswith(('(setUpAll)', '(tearDownAll)'))
        (excluded if hidden else cases).append(case)
    assert all(c['result'] == 'success' and not c['skipped'] for c in cases + excluded)
    errors = [e for e in parsed if e['type'] == 'error']
    assert not errors
    diagnostic_words = ('overflowed', 'would not hit test', 'EXCEPTION CAUGHT')
    diagnostics = [e for e in parsed if e['type'] == 'print' and any(w in e.get('message', '') for w in diagnostic_words)]
    assert not diagnostics
    completion = [e for e in parsed if e['type'] == 'done']
    assert len(completion) == 1 and completion[0]['success'] is True
    identities = Counter((c['suite'], c['name']) for c in cases)
    return {'registered_tests': len(cases), 'distinct_named_cases': len(identities),
            'duplicate_registrations': len(cases) - len(identities),
            'duplicate_groups': [{'suite': s, 'name': n, 'registrations': c}
                                 for (s, n), c in sorted(identities.items()) if c > 1],
            'suites': len(suites), 'starts': len(starts), 'finishes': len(finishes),
            'excluded_lifecycle_events': len(excluded), 'flutter_envelopes': len(envelopes),
            'empty_lines': len(blank_lines),
            'passed': len(cases), 'failed': 0, 'skipped': 0, 'error_events': 0,
            'diagnostics': 0, 'completion': completion, 'cases': cases,
            'by_suite': dict(sorted(Counter(c['suite'] for c in cases).items()))}


def source_binding(records, tree):
    mismatches = [{'path': path, 'recorded': item['git_blob_sha1'], 'git_tree': tree.get(path)}
                  for path, item in records.items() if tree.get(path) != item['git_blob_sha1']]
    return {'input_count': len(records), 'mismatches': mismatches}


def main():
    OUT.mkdir(exist_ok=True)
    report = {'schema': 'quds.spelling_resume.recovered_independent_audit.v1',
              'generated_at_utc': datetime.now(timezone.utc).isoformat(),
              'product_commit': FINAL, 'original_regression_source_commit': ORIGINAL,
              'audit_script': fingerprint(Path(__file__).read_bytes()),
              'product_tests_executed_by_this_audit': 0, 'ci_endpoints_used': False}
    index = read(SAVED / 'evidence-index.json')
    assert fingerprint((SAVED / 'evidence.tar.xz').read_bytes()) == index['archive']
    with tarfile.open(SAVED / 'evidence.tar.xz') as archive:
        members = archive.getmembers()
        assert len(members) == len({m.name for m in members}) == index['member_count']
        assert {m.name for m in members} == set(index['members'])
        for member in members:
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            content = archive.extractfile(member).read()
            assert fingerprint(content) == index['members'][member.name]
            dest = EXTRACTED / member.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(content)
    report['archive'] = dict(index['archive'], members=index['member_count'], all_members_match=True)
    trees = {c: git_tree(c) for c in [FINAL, ORIGINAL, BASELINE, SPELLING]}
    regressions, all_cases = {}, []
    new_files = {
        'packages/quds_office_engine/test/proofing/german_spelling_projection_test.dart': 25,
        'packages/quds_office_editor/test/platform_spelling_identifiers_test.dart': 8,
        'packages/quds_office_editor/test/platform_spelling_identifier_review_test.dart': 5,
        'packages/quds_office_editor/test/platform_spelling_vocabulary_unicode_test.dart': 3,
    }
    for cohort in ['engine', 'editor']:
        path = EXTRACTED / 'regression' / cohort
        summary, executed = read(path / 'summary.json'), read(path / 'summary-at-execution.json')
        audit = events(path / 'events.jsonl.gz')
        cases = audit.pop('cases')
        assert cases == read(path / 'cases.json.gz')
        assert audit['registered_tests'] == summary['substantive_test_count'] == summary['results']['success']
        assert audit['distinct_named_cases'] == summary['distinct_named_test_count']
        assert audit['duplicate_groups'] == summary['duplicate_name_groups']
        assert audit['suites'] == summary['suite_count']
        assert len(summary['selected_files']) == audit['suites']
        assert all(summary['guards'].values())
        assert summary['actual_process_exit_code'] == executed['actual_process_exit_code'] == 0
        assert not summary['timed_out'] and summary['source_commit'] == ORIGINAL
        assert fingerprint((path / 'run_regressions_at_execution.py').read_bytes()) == executed['runner']
        assert fingerprint((path / 'events.jsonl.gz').read_bytes()) == summary['accounting_correction']['raw_events']
        before, after = read(path / 'source-before.json.gz'), read(path / 'source-after.json.gz')
        environment_before, environment_after = read(path / 'environment-before.json.gz'), read(path / 'environment-after.json.gz')
        assert before == after and environment_before == environment_after
        original_binding = source_binding(before, trees[ORIGINAL])
        assert not original_binding['mismatches']
        audit.update({'actual_process_exit_code': 0, 'source_before_after_equal': True,
                      'environment_before_after_equal': True, 'environment_input_count': len(environment_before),
                      'original_source_binding': original_binding,
                      'final_source_binding': source_binding(before, trees[FINAL]),
                      'original_receipt_status': executed['status'],
                      'original_false_guards': [k for k, v in executed['guards'].items() if not v],
                      'corrected_receipt_status': summary['status'], 'all_corrected_guards_true': True})
        regressions[cohort] = audit
        all_cases.extend(cases)
    report['recovered_regressions'] = regressions
    report['totals'] = {key: sum(r[key] for r in regressions.values()) for key in ['registered_tests', 'distinct_named_cases', 'duplicate_registrations', 'suites', 'passed', 'failed', 'skipped']}
    new_cases = {}
    for path, expected in new_files.items():
        cases = [c for c in all_cases if c['suite'].endswith('/' + path)]
        assert len(cases) == expected == len({c['name'] for c in cases})
        assert path not in trees[BASELINE]
        assert trees[FINAL][path] == trees[ORIGINAL][path] == trees[SPELLING][path]
        new_cases[path] = {'case_count': len(cases), 'absent_on_baseline': True,
                           'unchanged_since_spelling_checkpoint': True,
                           'cases': [c['name'] for c in cases]}
    report['new_spelling_cases'] = {'count': sum(v['case_count'] for v in new_cases.values()), 'files': new_cases}
    duplicate_files = {c['suite'].split('/validation-workspace/', 1)[1] for c in regressions['engine']['duplicate_groups']}
    assert all(trees[BASELINE][p] == trees[FINAL][p] for p in duplicate_files)
    report['legacy_duplicate_files'] = {'unchanged_since_baseline': True, 'paths': sorted(duplicate_files)}
    zotero_index = read(ZOTERO / 'index.json')
    for record in zotero_index['files']:
        assert fingerprint((ZOTERO / record['path']).read_bytes()) == {k: record[k] for k in ['bytes', 'sha256', 'git_blob_sha1']}
    zsummary, inputs = read(ZOTERO / 'editor/summary.json'), read(ZOTERO / 'editor/inputs.json.gz')
    zaudit = events(ZOTERO / 'editor/events.jsonl.gz')
    zaudit.pop('cases')
    assert zaudit['registered_tests'] == zsummary['tests']['passed'] == zsummary['tests']['substantive_cases']
    assert zaudit['suites'] == zsummary['tests']['suite_count']
    assert zsummary['actual_process_exit'] == 0 and not zsummary['timed_out']
    assert all(zsummary['guards'].values())
    assert inputs['before_sha256'] == inputs['after_sha256']
    assert all(not changes for changes in inputs['changed_paths'].values())
    for kind, values in inputs['before'].items():
        digest = hashlib.sha256(json.dumps(values, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        assert digest == inputs['before_sha256'][kind]
    binding = source_binding(inputs['before']['source'], trees[FINAL])
    assert not binding['mismatches']
    zaudit.update({'indexed_files_verified': len(zotero_index['files']),
                  'actual_process_exit_code': 0, 'all_summary_guards_true': True,
                  'before_after_receipt_hashes_equal': True, 'source_binding_to_final': binding,
                  'original_qualified_product': zotero_index['qualified_product'],
                  'new_stored_details_cases': sum(n for p, n in zaudit['by_suite'].items() if Path(p).name in ['word_zotero_stored_details_test.dart', 'word_zotero_stored_details_dialog_test.dart'])})
    report['inherited_zotero_qualification'] = zaudit
    missing_assets = []
    members = yaml.safe_load((REPO / 'pubspec.yaml').read_text())['workspace']
    for member in members:
        manifest = yaml.safe_load((REPO / member / 'pubspec.yaml').read_text())
        for asset in manifest.get('flutter', {}).get('assets', []):
            assert isinstance(asset, str), 'Inspect non-string asset declarations explicitly.'
            path = REPO / member / asset
            files = [path] if path.is_file() else sorted(p for p in path.rglob('*') if p.is_file())
            for file in files:
                if not file.relative_to(REPO / member).as_posix().startswith(('lib/', 'assets/')):
                    missing_assets.append(file.relative_to(REPO).as_posix())
    test_paths = set()
    for cohort in ['engine', 'editor']:
        test_paths.update(read(EXTRACTED / 'regression' / cohort / 'summary.json')['selected_files'])
    incoming_paths = ['packages/quds_office_editor/test/' + name for name in
                      ['word_zotero_stored_details_test.dart', 'word_zotero_stored_details_dialog_test.dart']]
    relative_imports = []
    for test in sorted(test_paths | set(incoming_paths)):
        source = (REPO / test).read_text()
        imports = re.findall(r'''(?:import|export|part)\s+['"]([^'"]+)['"]''', source)
        relative_imports.extend({'source': test, 'import': imported} for imported in imports if ':' not in imported)
    configs = sorted(str(p.relative_to(REPO)) for member in ['packages/quds_office_engine', 'packages/quds_office_editor']
                     for p in (REPO / member).rglob('flutter_test_config.dart'))
    assert not relative_imports and not configs
    report['runner_source_closure_review'] = {
        'selected_proofing_tests': len(test_paths), 'incoming_zotero_tests': len(incoming_paths),
        'selected_tests_use_only_dart_or_package_imports': True,
        'additional_relative_test_helpers_found': relative_imports, 'flutter_test_config_found': configs,
        'declared_asset_files_not_covered_by_old_lib_assets_scan': missing_assets,
        'recommendation': 'Bind every declared Flutter asset and relevant member analysis/test configuration before accepting final runs. The previous source snapshot remains an honest record of its narrower selected inputs.'}
    report['required_closeout'] = [
        'Rerun or otherwise qualify final proofing source because two recorded editor library inputs changed after fb1fd4dc.',
        'Recover missing isolated-baseline and three-target portable/static execution records; the archive does not contain them.',
        'Bind all newly accepted input snapshots to 04be224b, preserve actual exits/raw events and original failed attempts.',
        'Label recovered fb1fd4dc regression results and inherited 299-case Zotero results separately; do not add overlapping totals.',
        'Use 1,303 registrations, 1,295 distinct named cases and 41 new distinct spelling cases for this fixed proofing selection.',
        'After sealing, save remotely and verify retrieved archive bytes and indexed members before final ready PR publication.'
    ]
    report['status'] = 'passed_with_documented_final_source_gap'
    (OUT / 'recovered-audit.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'archive_members': report['archive']['members'],
                      'totals': report['totals'], 'new_spelling_cases': report['new_spelling_cases']['count'],
                      'zotero_passed': zaudit['passed'], 'zotero_source_inputs': binding['input_count'],
                      'zotero_new_stored_details_cases': zaudit['new_stored_details_cases']}, indent=2))


if __name__ == '__main__':
    main()
