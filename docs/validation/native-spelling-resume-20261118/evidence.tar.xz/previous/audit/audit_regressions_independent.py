#!/usr/bin/env python3
"""Independent replay of existing JSON events and source receipts; runs no tests."""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip, hashlib, json, re, subprocess

ROOT = Path('/workspace/scratch/d1e6a944d6fd')
REPO = ROOT / 'quds_office_suite'
BASELINE = '4dceb86e9fae51877bb5b7dc01e7a8bc721cb6ea'
PRIOR_MAIN = '1e07cb852766f8651815138785be74c64a09ddc0'
NEW_FILES = {
    'packages/quds_office_engine/test/proofing/german_spelling_projection_test.dart',
    'packages/quds_office_editor/test/platform_spelling_identifiers_test.dart',
    'packages/quds_office_editor/test/platform_spelling_identifier_review_test.dart',
    'packages/quds_office_editor/test/platform_spelling_vocabulary_unicode_test.dart',
}

def sha(data): return hashlib.sha256(data).hexdigest()
def read_json(path):
    data = path.read_bytes()
    if path.suffix == '.gz': data = gzip.decompress(data)
    return json.loads(data)
def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()
def relative_suite(suite):
    return str(Path(suite).relative_to(ROOT / 'validation-workspace'))

report = {'schema': 'quds.spelling_resume.independent_regression_audit.v1',
          'generated_at_utc': datetime.now(timezone.utc).isoformat(),
          'operation': 'Recount preserved raw events and compare preserved bindings with Git; no product reruns.',
          'cohorts': {}, 'legacy_duplicates': [], 'checks': {}}
all_cases = []
combined_source = {}
combined_environment = {}
for cohort in ('engine', 'editor'):
    output = ROOT / 'recovery/final' / cohort
    original = read_json(output / 'summary-at-execution.json')
    run = read_json(output / 'run.json')
    raw = gzip.decompress((output / 'events.jsonl.gz').read_bytes()).decode()
    events, envelopes = [], []
    for line in raw.splitlines():
        value = json.loads(line)
        if isinstance(value, list):
            assert all(isinstance(item, dict) and 'event' in item for item in value)
            envelopes.append(value)
        else:
            assert isinstance(value, dict) and 'type' in value
            events.append(value)
    starts_list = [e['test'] for e in events if e['type'] == 'testStart']
    finishes = [e for e in events if e['type'] == 'testDone']
    start_ids = Counter(e['id'] for e in starts_list)
    finish_ids = Counter(e['testID'] for e in finishes)
    assert start_ids == finish_ids and all(v == 1 for v in start_ids.values())
    starts = {e['id']: e for e in starts_list}
    suites_list = [e['suite'] for e in events if e['type'] == 'suite']
    suites = {e['id']: e for e in suites_list}
    assert len(suites) == len(suites_list)
    assert {relative_suite(e['path']) for e in suites.values()} == set(run['selected_files'])
    done = [e for e in events if e['type'] == 'done']
    assert len(done) == 1 and done[0]['success'] is True
    assert not [e for e in events if e['type'] == 'error']
    cases, excluded = [], []
    for finish in finishes:
        start = starts[finish['testID']]
        case = {'id': finish['testID'], 'name': start['name'],
                'suite': suites[start['suiteID']]['path'], 'result': finish['result'],
                'skipped': finish.get('skipped', False)}
        hidden = finish.get('hidden', False) or start['name'].endswith(('(setUpAll)', '(tearDownAll)'))
        (excluded if hidden else cases).append(case)
    assert cases == read_json(output / 'cases.json.gz')
    assert excluded == read_json(output / 'excluded-events.json')
    assert envelopes == read_json(output / 'machine-envelopes.json')
    assert len(cases) == original['substantive_test_count']
    assert all(c['result'] == 'success' and not c['skipped'] for c in cases)
    assert original['actual_process_exit_code'] == 0 and not original['timed_out']
    assert sha((output / 'run_regressions_at_execution.py').read_bytes()) == run['runner']['sha256']
    before = read_json(output / 'source-before.json.gz')
    after = read_json(output / 'source-after.json.gz')
    env_before = read_json(output / 'environment-before.json.gz')
    env_after = read_json(output / 'environment-after.json.gz')
    assert before == after and env_before == env_after
    tree = {}
    for line in subprocess.check_output(['git', 'ls-tree', '-rz', run['source_commit']], cwd=REPO).split(b'\0'):
        if line:
            meta, path = line.split(b'\t', 1)
            tree[path.decode()] = meta.split()[2].decode()
    for path, binding in before.items():
        actual = (REPO / path).read_bytes()
        assert sha(actual) == binding['sha256'] and len(actual) == binding['bytes']
        blob = hashlib.sha1(b'blob ' + str(len(actual)).encode() + b'\0' + actual).hexdigest()
        assert blob == binding['git_blob_sha1'] == tree[path]
        if path in combined_source: assert combined_source[path] == binding
        combined_source[path] = binding
    for path, binding in env_before.items():
        if path in combined_environment: assert combined_environment[path] == binding
        combined_environment[path] = binding
    counts = Counter((relative_suite(c['suite']), c['name']) for c in cases)
    groups = [{'suite': key[0], 'name': key[1], 'registrations': value}
              for key, value in sorted(counts.items()) if value > 1]
    report['cohorts'][cohort] = {
        'source_commit': run['source_commit'], 'suites': len(suites),
        'successful_registrations': len(cases), 'distinct_suite_name_cases': len(counts),
        'duplicate_registrations': len(cases) - len(counts), 'excluded_events': len(excluded),
        'original_wrapper_status': original['status'], 'child_process_exit_code': 0,
        'source_inputs_match_saved_commit': len(before), 'unchanged_environment_inputs': len(env_before),
        'start_and_finish_ids_one_to_one': True, 'raw_cases_and_summaries_match': True,
        'preserved_runner_hash_matches_execution_receipt': True,
        'duplicate_groups': groups,
    }
    report['legacy_duplicates'].extend(groups)
    all_cases.extend(cases)

# Independently establish repeated source AND expected fixture rows in unchanged files.
expected_groups = []
for filename in ('german_context_test.dart', 'german_release_context_test.dart'):
    path = 'packages/quds_office_engine/test/proofing/' + filename
    text = (REPO / path).read_text()
    section = text.split('const cases = <(String, String)>[', 1)[1].split('];', 1)[0]
    pairs = re.findall(r'\(\s*"([^"\\]*(?:\\.[^"\\]*)*)"\s*,\s*"([^"\\]*(?:\\.[^"\\]*)*)"\s*,?\s*\)', section)
    counts = Counter(pairs)
    current_blob = git('rev-parse', report['cohorts']['engine']['source_commit'] + ':' + path)
    assert current_blob == git('rev-parse', BASELINE + ':' + path) == git('rev-parse', PRIOR_MAIN + ':' + path)
    for (source, expected), count in sorted(counts.items()):
        if count > 1:
            assert count == 2 and source == expected
            expected_groups.append({'suite': path, 'name': 'context: ' + source, 'registrations': count})
report['checks']['legacy_duplicate_groups_exactly_match_frozen_source_rows'] = sorted(expected_groups, key=lambda x:(x['suite'],x['name'])) == sorted(report['legacy_duplicates'], key=lambda x:(x['suite'],x['name']))
assert report['checks']['legacy_duplicate_groups_exactly_match_frozen_source_rows']
assert len(expected_groups) == 8
report['checks']['legacy_fixture_files_identical_to_integrated_baseline_and_prior_main'] = True
all_ids = Counter((relative_suite(c['suite']), c['name']) for c in all_cases)
new_cases = [c for c in all_cases if relative_suite(c['suite']) in NEW_FILES]
assert len(new_cases) == 41 and len({(c['suite'],c['name']) for c in new_cases}) == 41
for path in NEW_FILES:
    assert subprocess.run(['git','cat-file','-e',BASELINE + ':' + path],cwd=REPO,stderr=subprocess.DEVNULL).returncode != 0
report['checks']['new_cases_are_41_unique_successful_registrations_from_four_new_files'] = True
report['counts'] = {'successful_registrations': len(all_cases), 'distinct_suite_name_cases': len(all_ids),
                    'duplicate_registrations': len(all_cases)-len(all_ids), 'new_unique_cases': len(new_cases),
                    'distinct_source_inputs': len(combined_source), 'distinct_environment_inputs':len(combined_environment)}
# Validate archived runtime/dependency hashes against actual files once for the combined guard.
for path, binding in combined_environment.items():
    actual = Path(path).read_bytes()
    assert len(actual) == binding['bytes'] and sha(actual) == binding['sha256'], path
report['checks']['all_recorded_runtime_dependency_files_still_match_before_after_bindings'] = True
report['checks']['cohorts_are_disjoint'] = len(set(c['suite'] for c in all_cases)) == sum(c['suites'] for c in report['cohorts'].values())
report['status'] = 'passed'
(ROOT/'recovery/audit/regression-independent-audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':report['status'],'counts':report['counts'],'checks':report['checks']},indent=2))
