#!/usr/bin/env python3
"""Read-only independent audit of the saved spelling comparison map."""
import base64
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess
import unicodedata
import zlib

ROOT = Path('/workspace/scratch/d1e6a944d6fd/quds_office_suite')
OUT = Path('/workspace/scratch/d1e6a944d6fd/recovery/review')
SOURCE = 'packages/quds_office_engine/lib/src/proofing/german_spelling.dart'
BASE = '4dceb86e9fae51877bb5b7dc01e7a8bc721cb6ea'
HEAD = 'f482b06fc47545c8b03124c30ea78f54e8e4b9e5'

def git_text(ref, path):
    return subprocess.check_output(['git', 'show', f'{ref}:{path}'], cwd=ROOT).decode('utf-8')

def mapping(source):
    block = source.split('const Map<String, String> composed', 1)[1].split('};', 1)[0]
    result = {}
    for left, right in re.findall(r"'([^']*)': '([^']*)'", block):
        key = re.sub(r'\\u([0-9a-fA-F]{4})', lambda m: chr(int(m[1], 16)), left)
        result[key] = right
    return result

def missing(characters, word_index, substitutions):
    absent = []
    for ch in sorted(characters):
        nfd = unicodedata.normalize('NFD', ch)
        if ch == nfd:
            continue
        actual = nfd
        for old, new in substitutions.items():
            actual = actual.replace(old, new)
        if actual != ch:
            absent.append({'character': ch, 'decomposition': nfd, 'occurrences': characters[ch], 'words': word_index[ch]})
    return absent

files = []
forms = []
words_by_char = collections.defaultdict(list)
counts = collections.Counter()
data = ROOT / 'packages/quds_office_engine/lib/src/proofing/data'
for p in sorted([*data.glob('german_standard_*.dart'), *data.glob('german_swiss_*.dart'), *data.glob('german_common_*.dart')]):
    raw = p.read_bytes()
    body = raw.decode('utf-8').split('<String>[', 1)[1].rsplit('];', 1)[0]
    chunk_counts = []
    for fragment in body.split(','):
        encoded = ''.join(re.findall(r"'([^']*)'", fragment))
        if not encoded:
            continue
        chunk = zlib.decompress(base64.b64decode(encoded, validate=True), -15).decode('utf-8')
        words = [word for word in chunk.splitlines() if word]
        forms.extend(words)
        chunk_counts.append(len(words))
        for word in words:
            counts.update(word)
            for ch in sorted(set(word)):
                if unicodedata.normalize('NFD', ch) != ch:
                    words_by_char[ch].append(word)
    files.append({'path': str(p.relative_to(ROOT)), 'sha256': hashlib.sha256(raw).hexdigest(), 'forms': sum(chunk_counts), 'chunk_counts': chunk_counts})

baseline = git_text(BASE, SOURCE)
final = git_text(HEAD, SOURCE)
result = {
  'schema': 'quds.native_spelling_resume.recovery_dictionary_audit.v1',
  'scope': 'Read-only decoded shipped standard, Swiss and common dictionaries; all single-character canonical decompositions compared to explicit source map. No claim of general NFC normalization or runtime execution.',
  'baseline': BASE,
  'source_head': HEAD,
  'source_sha256': hashlib.sha256(final.encode()).hexdigest(),
  'unicode_version': unicodedata.unidata_version,
  'dictionary_forms': len(forms),
  'unique_dictionary_forms': len(set(forms)),
  'decomposable_dictionary_characters': len(words_by_char),
  'baseline_missing': missing(counts, words_by_char, mapping(baseline)),
  'final_missing': missing(counts, words_by_char, mapping(final)),
  'shards': files,
  'new_mapping_entries': {key: value for key, value in mapping(final).items() if key not in mapping(baseline)},
}
output = OUT / 'dictionary-audit-recovery.json'
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('shards',)}, ensure_ascii=False, indent=2))
