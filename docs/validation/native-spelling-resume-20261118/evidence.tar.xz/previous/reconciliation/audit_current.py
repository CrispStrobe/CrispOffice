#!/usr/bin/env python3
"""Read only current captured refs against immutable integrated source."""
from pathlib import Path
import argparse
import collections
import datetime
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', required=True, type=Path, help='Local Git checkout with captured histories')
parser.add_argument('--data', type=Path, default=HERE, help='Directory holding captured JSON inputs and outputs')
args = parser.parse_args()
HERE = args.data.resolve()
REPO = args.repo.resolve()
TARGET = 'fb1fd4dc3edda824c3e043c035dbfad1f0fe0869'
SPELLING = 'f482b06fc47545c8b03124c30ea78f54e8e4b9e5'
PR_REVIEW = '3840e19ff949f5fc03ecf1ec30ab0a71f67e8c68'
PRIOR_PATH = 'docs/validation/zotero-continuation-20261118/reconciliation-final.json'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()

def ancestor(a, b=TARGET):
    p = subprocess.run(['git', 'merge-base', '--is-ancestor', a, b], cwd=REPO, capture_output=True, text=True)
    if p.returncode not in (0, 1):
        raise RuntimeError((a, b, p.returncode, p.stderr))
    return p.returncode == 0

prior_bytes = subprocess.check_output(['git', 'show', TARGET + ':' + PRIOR_PATH], cwd=REPO)
prior = json.loads(prior_bytes)
api_prior = (HERE / 'detail2.json').read_bytes()
assert json.loads(api_prior) == prior
prior_refs = {x['ref']: x for x in prior['local_refs']}
inventory = json.loads((HERE / 'current-inventory.json').read_text())
upstream_prs = json.loads((HERE / 'upstreamPulls.json').read_text())
refs = []
for prefix, key, kind in [('origin','forkBranches','fork_branch'), ('upstream','upstreamBranches','upstream_branch')]:
    for x in inventory[key]:
        refs.append({'ref': 'refs/remotes/' + prefix + '/' + x['name'], 'source_ref': 'refs/heads/' + x['name'], 'sha': x['commit']['sha'], 'kind': kind})
for x in inventory['forkPulls']:
    refs.append({'ref':'refs/remotes/origin/pr/' + str(x['number']), 'source_ref': 'refs/pull/' + str(x['number']) + '/head', 'sha':x['head'],'kind':'fork_pr_head'})
for x in upstream_prs:
    refs.append({'ref':'refs/remotes/upstream/pr/' + str(x['number']), 'source_ref': 'refs/pull/' + str(x['number']) + '/head', 'sha':x['head']['sha'],'kind':'upstream_pr_head'})
refs.sort(key=lambda x:x['ref'])
assert len({x['ref'] for x in refs}) == len(refs)
ancestry = {s: ancestor(s) for s in sorted({x['sha'] for x in refs})}
assert ancestor(prior['final_integration_commit'])
for x in refs:
    x['is_ancestor'] = ancestry[x['sha']]
    if x['is_ancestor']:
        x['classification'] = 'ancestor'
        continue
    p = prior_refs.get(x['ref'])
    if p is None or p['sha'] != x['sha']:
        x['classification'] = 'unreconciled'
        continue
    cls = p['classification']
    if cls not in ('unchanged-historical-merge-noop','unchanged-historical-merged-pr'):
        x['classification'] = 'unreconciled'
        continue
    evidence = {'path':PRIOR_PATH,'read_from_commit':TARGET,'entry_ref':x['ref'],'sha_unchanged':True,'previous_classification':cls, 'previous_integrated_commit':prior['final_integration_commit'], 'previous_integrated_commit_is_ancestor':True}
    if cls == 'unchanged-historical-merged-pr':
        landed = p['prior_evidence']['merged_pr']
        evidence['merged_pr'] = landed
        evidence['landed_commit_is_ancestor'] = ancestor(landed['merge_commit_sha'])
        assert evidence['landed_commit_is_ancestor']
    else:
        evidence['prior_trial_tree'] = p['prior_evidence']['prior_trial_tree']
        evidence['qualification'] = 'Original identical-tree trial is retained as historical evidence; no fresh merge trial was claimed.'
    x['classification'] = cls
    x['prior_evidence'] = evidence
current = {x['ref']:x for x in refs}
added = [x for x in refs if x['ref'] not in prior_refs]
changed = [{'ref':x['ref'],'previous_sha':prior_refs[x['ref']]['sha'],'current_sha':x['sha'],'current_is_ancestor':x['is_ancestor']} for x in refs if x['ref'] in prior_refs and prior_refs[x['ref']]['sha'] != x['sha']]
removed = [x for x in prior['local_refs'] if x['ref'] not in current]
non_ancestors = [x for x in refs if not x['is_ancestor']]
unreconciled = [x for x in refs if x['classification'] == 'unreconciled']
changed_files = git('diff','--name-status',SPELLING,TARGET).splitlines()
spelling_files = ['packages/quds_office_editor/lib/src/proofing/platform_spelling_provider.dart','packages/quds_office_engine/lib/src/proofing/german_spelling.dart','packages/quds_office_engine/tool/check_native_spelling.dart','packages/quds_office_engine/test/proofing/german_spelling_projection_test.dart','packages/quds_office_editor/test/platform_spelling_identifier_review_test.dart','packages/quds_office_editor/test/platform_spelling_identifiers_test.dart','packages/quds_office_editor/test/platform_spelling_vocabulary_unicode_test.dart']
bindings=[]
for path in spelling_files:
    a=git('rev-parse',SPELLING+':'+path);b=git('rev-parse',TARGET+':'+path)
    assert a == b
    bindings.append({'path':path,'spelling_blob':a,'integrated_blob':b,'unchanged':True})
counts={'refs':len(refs),'distinct_heads':len(ancestry),'by_kind':dict(collections.Counter(x['kind'] for x in refs)),'by_classification':dict(collections.Counter(x['classification'] for x in refs)),'exact_ancestor_refs':sum(x['is_ancestor'] for x in refs),'exact_ancestor_heads':sum(ancestry.values()),'historical_nonancestor_refs':len(non_ancestors),'historical_nonancestor_heads':len({x['sha'] for x in non_ancestors}),'unreconciled_refs':len(unreconciled)}
result={'schema_version':1,'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':'CrispStrobe/quds_office_suite','upstream':'MohammedAsaadAsaad/quds_office_suite','status':'all-observed-incoming-refs-accounted' if not unreconciled else 'unresolved','cutoff':{'captured_at':inventory['capturedAt'],'policy':'Fixed API inventory. Includes all enumerated fork/upstream branches and PR heads, including current work; excludes no observed named ref. No claim is made about later remote advances.','sources':inventory['sources'],'upstream_pr_url':'https://api.github.com/repos/MohammedAsaadAsaad/quds_office_suite/pulls?state=all&per_page=100&page=1'},'target_commit':TARGET,'target_tree':git('rev-parse',TARGET+'^{tree}'),'prior_reconciliation':{'path':PRIOR_PATH,'read_from_commit':TARGET,'git_blob':git('rev-parse',TARGET+':'+PRIOR_PATH),'sha256':hashlib.sha256(prior_bytes).hexdigest(),'prior_integration_commit':prior['final_integration_commit'],'prior_integration_is_ancestor':True},'counts':counts,'comparison_to_prior':{'added':added,'changed':changed,'removed':removed},'active_integration':{'spelling_resume_head':SPELLING,'spelling_resume_is_ancestor':ancestor(SPELLING),'spelling_to_target_commits_ahead':int(git('rev-list','--count',SPELLING+'..'+TARGET)),'review_pr_head':PR_REVIEW,'review_pr_head_is_ancestor':ancestor(PR_REVIEW),'review_branch_ref_head':TARGET,'review_ref_pr_mismatch':'Branches and exact git ref both report fb1fd4dc; PR162 metadata continues to report 3840e19f. Both exact objects are included ancestors.','recommended_action':'Fast-forward the spelling continuation from f482b06f to fb1fd4dc using an expected-head non-forced update, then add fresh qualification and final report checkpoints.','spelling_file_bindings':bindings,'changed_paths_from_spelling':changed_files},'refs':refs,'unreconciled':unreconciled,'method':{'ancestry':'git merge-base --is-ancestor per distinct captured head. Unexpected errors fail.','historical':'All 28 historical nonancestor refs retain prior names and exact SHAs. Nine distinct landed commits freshly checked as ancestors; prior identical-tree results retained with evidence chain.','remote_mutations_performed':False,'ref_index_checkout_mutations_performed':False,'github_actions_workflow_check_status_endpoints_queried':False},'limits':['This is read-only ancestry and source reconciliation, not fresh product validation.','PR metadata can differ from live branch refs; both observed SHAs are preserved.','Previous historical trial results are not represented as newly executed.']}
readback_path = HERE / 'spell-ref-after-integration.json'
if readback_path.exists():
    readback = json.loads(readback_path.read_text())
    assert readback['ref'] == 'refs/heads/codex/native-spelling-resume-20261118'
    assert readback['object']['sha'] == TARGET
    result['own_branch_integration_readback'] = {'before':SPELLING,'after':TARGET,'is_fast_forward':True,'reported_publishing_method':'Root publisher reported a successful non-forced update with expected_sha=f482b06fc47545c8b03124c30ea78f54e8e4b9e5.','independent_readback_path':readback_path.name,'independent_readback_sha256':hashlib.sha256(readback_path.read_bytes()).hexdigest(),'captured_inventory_preserved':'The fixed inventory preserves the original spelling head; this expected own update is recorded separately.'}
    result['active_integration']['recommended_action'] = 'Integration is complete and independently read back at fb1fd4dc; preserve incremental qualification and report checkpoints on the spelling continuation.'
(HERE/'resume-reconciliation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'counts':counts,'added_refs':[x['ref'] for x in added],'changed':changed,'removed':[x['ref'] for x in removed],'spelling_bindings':len(bindings),'target_tree':result['target_tree']},indent=2))
