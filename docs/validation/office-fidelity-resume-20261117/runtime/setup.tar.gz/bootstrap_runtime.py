#!/usr/bin/env python3
"""Install verified, unmodified Flutter 3.47.8 components for local testing."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import urllib.request
import zipfile

ROOT = Path('/workspace/scratch/25fc1d269a82/runtime')
SDK = ROOT / 'flutter-source'
REPO = ROOT.parent / 'quds_office_suite'
DOWNLOADS = ROOT.parent / 'runtime-downloads'
OUT = ROOT / 'setup'
PRIOR = REPO / 'docs/validation/text-rendering-continuation-20261116/runtime-resume/receipts'
ENGINE = 'cf636b1dfb818dd6a3ff16e390e93b1a036969c8'
FRAMEWORK = '737ba8f885dc774b53b442759999a312c9461e4e'
BASE = 'https://storage.googleapis.com/flutter_infra_release/flutter/'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()

def install(item):
    local = DOWNLOADS / item['name']
    if not local.exists():
        with urllib.request.urlopen(item['url'], timeout=60) as response, local.open('wb') as stream:
            shutil.copyfileobj(response, stream)
    checksum = digest(local)
    if item.get('sha256') and checksum != item['sha256']:
        raise ValueError('Archive checksum mismatch: ' + item['name'])
    target = SDK / item['target']
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(local) as archive:
        if archive.testzip():
            raise ValueError('CRC failure: ' + item['name'])
        for info in archive.infolist():
            dest = target / info.filename
            if not dest.resolve().is_relative_to(target.resolve()):
                raise ValueError('Unsafe member: ' + info.filename)
            archive.extract(info, target)
            if dest.is_file():
                dest.chmod((info.external_attr >> 16) & 0o777 or 0o644)
    result = {**item, 'sha256': checksum, 'bytes': local.stat().st_size}
    print('Installed ' + item['name'], flush=True)
    return result

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SDK, text=True).strip() == FRAMEWORK
for path in [OUT, DOWNLOADS] + [ROOT / x for x in ['tmp', 'config', 'cache', 'data', 'bin', 'pub-cache']]:
    path.mkdir(parents=True, exist_ok=True)
common = json.loads((PRIOR / 'common-install.json').read_text())['artifacts']
jobs = []
for item in common:
    name = item['url'].rsplit('/', 1)[1]
    target = 'bin/cache/pkg' if name in ['sky_engine.zip', 'flutter_gpu.zip'] else 'bin/cache/artifacts/engine/common'
    jobs.append({'url': item['url'], 'name': name, 'target': target, 'sha256': item['archive_sha256']})
engine = json.loads((PRIOR / 'engine-install.json').read_text())
jobs.append({'url': engine['url'], 'name': 'linux-x64-artifacts.zip', 'target': 'bin/cache/artifacts/engine/linux-x64', 'sha256': engine['archive_sha256']})
jobs.append({'url': BASE + ENGINE + '/dart-sdk-linux-x64.zip', 'name': 'flutter-dart-sdk-linux-x64.zip', 'target': 'bin/cache'})
font_version = (SDK / 'bin/internal/material_fonts.version').read_text().strip()
jobs.append({'url': 'https://storage.googleapis.com/' + font_version, 'name': 'material-fonts.zip', 'target': 'bin/cache/artifacts/material_fonts'})
jobs.append({'url': BASE + ENGINE + '/linux-x64/font-subset.zip', 'name': 'font-subset.zip', 'target': 'bin/cache/artifacts/engine/linux-x64'})
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
    receipt = {'components': list(pool.map(install, jobs))}
selected = json.loads((PRIOR / 'dart-selected-install.json').read_text())
for item in selected['files']:
    path = SDK / 'bin/cache' / item['path']
    if not path.is_file() or digest(path) != item['sha256']:
        raise ValueError('Pinned Dart member mismatch: ' + item['path'])
receipt['dart_prior_verified_members'] = len(selected['files'])
with urllib.request.urlopen(BASE + ENGINE + '/engine_stamp.json', timeout=60) as response:
    metadata = response.read()
assert hashlib.sha256(metadata).hexdigest() == '00adfb4cd85c87da165d9cccfcb6d238e34ada530fd12e3d458431b38ddd1e5b'
(SDK / 'bin/cache/engine_stamp.json').write_bytes(metadata)
for name in ['engine-dart-sdk.stamp', 'flutter_sdk.stamp', 'engine_stamp.stamp', 'font-subset.stamp']:
    (SDK / 'bin/cache' / name).write_text(ENGINE)
(SDK / 'bin/cache/material_fonts.stamp').write_text(font_version)
subprocess.run([str(SDK / 'bin/internal/update_engine_version.sh')], cwd=SDK, check=True)
env = dict(FLUTTER_ROOT=str(SDK), PUB_CACHE=str(ROOT / 'pub-cache'), TMPDIR=str(ROOT / 'tmp'), XDG_CONFIG_HOME=str(ROOT / 'config'), XDG_CACHE_HOME=str(ROOT / 'cache'), XDG_DATA_HOME=str(ROOT / 'data'), CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true')
(ROOT / 'env.sh').write_text('\n'.join('export ' + k + '=' + v for k, v in env.items()) + '\nexport PATH=' + str(SDK / 'bin') + ':"$PATH"\n')
receipt.update({'framework_revision': FRAMEWORK, 'engine_revision': ENGINE, 'method': 'Unmodified official Flutter git tag and engine release artifacts; stock bin/flutter launcher', 'github_actions_used': False})
(OUT / 'runtime-install.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='components'}), flush=True)
