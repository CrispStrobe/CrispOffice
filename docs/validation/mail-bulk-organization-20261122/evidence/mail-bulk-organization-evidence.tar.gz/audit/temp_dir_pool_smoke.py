import ctypes
import errno
import json
import os
from pathlib import Path
import stat
import tempfile

base = Path('/workspace/scratch/f1082e82ac57')
scope = base / 'tmp'
pool = base / 'temp-dir-pool'
manifest = json.loads((base / 'integration-audit/temp-dir-pool-manifest.json').read_text())
known = {(e['device'], e['inode']) for e in manifest['entries']}


def check_pool():
    children = list(pool.iterdir())
    assert len(children) == len(known), (len(children), len(known))
    assert all(not list(child.iterdir()) for child in children)
    assert {(p.stat().st_dev, p.stat().st_ino) for p in children} == known


def expected_error(code, action):
    try:
        action()
    except OSError as error:
        assert error.errno == code, (error.errno, code)
    else:
        raise AssertionError(f'Expected errno {code}')


check_pool()
libc = ctypes.CDLL(None, use_errno=True)
libc.mkdtemp.argtypes = [ctypes.c_char_p]
libc.mkdtemp.restype = ctypes.c_void_p
for index in range(40):
    pattern = ctypes.create_string_buffer(str(scope / 'pool-libc-XXXXXX').encode())
    result = libc.mkdtemp(pattern)
    assert result, ctypes.get_errno()
    folder = Path(pattern.value.decode())
    info = folder.stat()
    assert (info.st_dev, info.st_ino) in known
    assert stat.S_IMODE(info.st_mode) == 0o700
    marker = folder / 'marker'
    marker.write_text(f'actual-file-{index}')
    expected_error(errno.EEXIST, lambda: os.mkdir(folder))
    expected_error(errno.ENOTEMPTY, lambda: os.rmdir(folder))
    assert marker.read_text() == f'actual-file-{index}'
    marker.unlink()
    fd = os.open(folder, os.O_RDONLY | os.O_DIRECTORY)
    try:
        old_mask = os.umask(0o027)
        try:
            os.mkdir('nested', 0o777, dir_fd=fd)
        finally:
            os.umask(old_mask)
        assert stat.S_IMODE((folder / 'nested').stat().st_mode) == 0o750
        os.rmdir('nested', dir_fd=fd)
    finally:
        os.close(fd)
    os.rmdir(folder)
    assert not folder.exists()
    check_pool()

live = [Path(tempfile.mkdtemp(prefix='pool-unique-', dir=scope)) for _ in range(6)]
assert len({str(p) for p in live}) == 6
assert len({p.stat().st_ino for p in live}) == 6
for folder in live:
    folder.rmdir()
check_pool()

escape = scope / 'pool-scope-escape'
escape.symlink_to(base / 'integration-audit', target_is_directory=True)
outside = escape / 'pool-must-not-borrow'
try:
    expected_error(errno.ENOSPC, lambda: os.mkdir(outside))
    assert not outside.exists()
finally:
    escape.unlink()
check_pool()
print(json.dumps({'status': 'passed', 'repeated_libc_mkdtemp': 40,
                  'nested_mkdirat_unlinkat': 40, 'simultaneous_unique_dirs': 6,
                  'checks': ['known real directory inodes', 'EEXIST', 'ENOTEMPTY',
                             'regular file content', 'umask', 'canonical scope escape',
                             'all 13 donor inodes returned empty']}))
