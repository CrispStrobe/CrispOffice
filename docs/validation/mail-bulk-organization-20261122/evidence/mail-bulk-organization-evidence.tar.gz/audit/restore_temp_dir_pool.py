"""Restore borrowed empty SDK/cache directories after all test processes stop."""
import argparse
import json
import os
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apply', action='store_true')
args = parser.parse_args()
base = Path('/workspace/scratch/f1082e82ac57')
manifest = json.loads((base / 'integration-audit/temp-dir-pool-manifest.json').read_text())
pool = Path(manifest['pool'])
expected = {e['pool_name'] for e in manifest['entries']}
actual = {p.name for p in pool.iterdir()}
if actual != expected:
    raise SystemExit(f'Pool is not idle/complete: expected {sorted(expected)}, found {sorted(actual)}')
for entry in manifest['entries']:
    folder = pool / entry['pool_name']
    info = folder.stat()
    if (info.st_dev, info.st_ino) != (entry['device'], entry['inode']):
        raise SystemExit(f'Unexpected inode: {folder}')
    if any(folder.iterdir()):
        raise SystemExit(f'Refusing to move nonempty test directory: {folder}')
    if os.path.lexists(entry['source']):
        raise SystemExit(f'Refusing to replace existing original path: {entry["source"]}')
if os.path.lexists(manifest['pool_original']):
    raise SystemExit('Original pool-root path already exists')
if args.apply:
    for entry in manifest['entries']:
        folder = pool / entry['pool_name']
        folder.chmod(entry['mode'])
        os.rename(folder, entry['source'])
    pool.chmod(manifest['pool_original_mode'])
    os.rename(pool, manifest['pool_original'])
    print('Restored all 14 original empty SDK/cache directories and modes')
else:
    print('Pool is idle: all 13 donor inodes are present and empty; ready to restore')
