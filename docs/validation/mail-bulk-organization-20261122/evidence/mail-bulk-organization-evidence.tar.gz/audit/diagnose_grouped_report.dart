import 'dart:convert';
import 'dart:io';
import 'package:quds_office_engine/quds_office_automation.dart';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'file:///workspace/scratch/f1082e82ac57/quds_office_suite/packages/quds_office_engine/tool/macros/web_vba_word_cell_suffix_smoke.dart' as fixture;
import 'file:///workspace/scratch/f1082e82ac57/quds_office_suite/packages/quds_office_engine/tool/macros/web_vba_word_integer_arithmetic_smoke.dart' as grouped;

Object? expand(Object? value) {
  if (value is String && (value.startsWith('{') || value.startsWith('['))) {
    try { return expand(jsonDecode(value)); } on FormatException { return value; }
  }
  if (value is List) return value.map(expand).toList();
  if (value is Map) return value.map((key, entry) => MapEntry(key.toString(), expand(entry)));
  return value;
}

void diff(Object? before, Object? after, String path) {
  if (before is Map && after is Map) {
    for (final key in {...before.keys, ...after.keys}) { diff(before[key], after[key], '$path.$key'); }
  } else if (before is List && after is List) {
    if (before.length != after.length) { print(jsonEncode({'path':'$path.length','before':before.length,'after':after.length})); }
    for (var i=0; i<before.length && i<after.length; i++) { diff(before[i], after[i], '$path[$i]'); }
  } else if (before != after) {
    print(jsonEncode({'path':path,'before':before,'after':after}));
  }
}

Future<void> main() async {
  final source = File('/workspace/scratch/f1082e82ac57/quds_office_suite/packages/quds_office_engine/example/macros/word_grouped_report.bas').readAsStringSync();
  for (final macroEnabled in [false, true]) {
    final input = fixture.wordCellSuffixInput(macroEnabled: macroEnabled);
    final before = expand(jsonDecode(fixture.wordCellSuffixUntouched(input)));
    final session = OfficeMacroSession(input, format: OfficeMacroFormat.docx);
    await session.run(grouped.groupedReportSource(source));
    var bytes = session.bytes;
    for (var cycle=0; cycle<3; cycle++) {
      print('DOC${macroEnabled ? "M" : "X"} cycle=$cycle');
      diff(before, expand(jsonDecode(fixture.wordCellSuffixUntouched(bytes))), 'snapshot');
      if (cycle<2) bytes = WordSerializer().writeBytes(WordDeserializer().readBytes(bytes));
    }
  }
}
