import 'package:sqlite3/sqlite3.dart';

void main() {
  final database = sqlite3.openInMemory();
  print(database.select('SELECT sqlite_version() AS version'));
  database.close();
}
