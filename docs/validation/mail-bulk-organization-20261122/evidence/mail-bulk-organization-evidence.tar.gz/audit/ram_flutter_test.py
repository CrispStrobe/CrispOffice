#!/usr/bin/env python3
"""Run original Flutter widget tests using a kernel held in anonymous RAM.

This bypasses only flutter_tools' temporary-directory/build orchestration. The
original SDK frontend, patched platform, assertions, flutter_tester, test fonts,
test_core engine, and unmodified test sources are used. Suite file annotations,
flutter_test_config.dart, native hook discovery, plugin registration and project
asset bundling are not performed. Callers must check these do not apply and
provide a native asset mapping explicitly when the suite needs one. SDK Material
shaders are compiled by the pinned SDK's impellerc. Multiple files are scoped in
separate test groups but share one Dart isolate; prefer one file when isolation
or global setup matters. A passing exit requires exactly --expected real tests.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('tests', nargs='+')
parser.add_argument('--expected', type=int, required=True)
parser.add_argument('--cwd')
parser.add_argument('--native-assets')
parser.add_argument('--log')
args = parser.parse_args()
base = Path('/workspace/scratch/f1082e82ac57')
repo = base / 'quds_office_suite'
flutter = base / 'toolchains/flutter'
engine = flutter / 'bin/cache/artifacts/engine/linux-x64'
packages = repo / '.dart_tool/package_config.json'
assets = base / 'tmp'
tests = [(repo / item).resolve() for item in args.tests]
for test in tests:
    if not test.is_file():
        raise SystemExit(f'Missing test file: {test}')
if args.expected < 1:
    raise SystemExit('--expected must be positive')
log = open(args.log, 'w', encoding='utf-8') if args.log else None
fds = []
links = []


def emit(value):
    print(value, flush=True)
    if log:
        log.write(value + '\n')
        log.flush()


def run(command, strict_test_output=False, **kwargs):
    process = subprocess.Popen(
        [str(arg) for arg in command],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        **kwargs,
    )
    unexpected = []
    reported_failures = 0
    event_types = {'start', 'suite', 'group', 'testStart', 'testDone', 'print',
                   'error', 'done', 'allSuites', 'debug'}
    for line in process.stdout:
        line = line.rstrip('\n')
        emit(line)
        if strict_test_output and line.strip():
            completion = re.fullmatch(
                r'HARNESS completed=\d+ expected=\d+ assertions=(true|false) success=(true|false)',
                line,
            )
            if completion:
                continue
            try:
                event = json.loads(line)
                if not isinstance(event, dict) or event.get('type') not in event_types:
                    unexpected.append(line)
                elif (event.get('type') == 'error' or
                      (event.get('type') == 'done' and event.get('success') is False) or
                      (event.get('type') == 'testDone' and event.get('result') != 'success')):
                    reported_failures += 1
            except json.JSONDecodeError:
                unexpected.append(line)
    status = process.wait()
    if unexpected or reported_failures:
        emit(f'HARNESS unexpected_non_json_output_lines={len(unexpected)} '
             f'reported_failure_events={reported_failures}')
        return status or 1
    return status


def memory(name, data=b''):
    fd = os.memfd_create(name, 0)
    fds.append(fd)
    if data:
        os.write(fd, data)
    return f'/proc/{os.getpid()}/fd/{fd}', fd


try:
    # Existing-directory file writes work; creating directories fails ENOSPC.
    # This short symlink exposes the exact expected SDK asset paths.
    shader_link = assets / 'shaders'
    if shader_link.is_symlink() and os.readlink(shader_link) == '.':
        pass
    elif shader_link.exists() or shader_link.is_symlink():
        raise SystemExit(f'Refusing to replace existing path: {shader_link}')
    else:
        shader_link.symlink_to('.')
        links.append(shader_link)

    for name, area in [('ink_sparkle', 'material'), ('stretch_effect', 'widgets')]:
        shader_source = flutter / f'packages/flutter/lib/src/{area}/shaders/{name}.frag'
        shader_output = assets / f'{name}.frag'
        spirv = assets / f'{name}.frag.spirv'
        status = run([
            engine / 'impellerc', '--sksl', '--runtime-stage-vulkan', '--iplr',
            f'--sl={shader_output}', f'--spirv={spirv}',
            f'--input={shader_source}', '--input-type=frag',
            f'--include={shader_source.parent}', f'--include={engine / "shader_lib"}',
        ], cwd=repo)
        if status:
            raise SystemExit(status)
        if spirv.exists():
            spirv.unlink()
        emit(f'HARNESS stock_shader={name} bytes={shader_output.stat().st_size}')

    imports = '\n'.join(
        f"import '{test.as_uri()}' as suite{i};" for i, test in enumerate(tests)
    )
    declarations = '\n'.join(
        f"    group('suite{i}: {test.name}', suite{i}.main);"
        for i, test in enumerate(tests)
    )
    source = f'''// @dart = 3.8
import 'dart:async';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:test_core/src/direct_run.dart';
import 'package:test_core/src/runner/reporter/json.dart';
{imports}
Future<void> main() async {{
  var assertionsEnabled = false;
  assert(assertionsEnabled = true);
  if (!assertionsEnabled) throw StateError('Assertions must be enabled');
  final binding = TestWidgetsFlutterBinding.ensureInitialized();
  if (binding is! AutomatedTestWidgetsFlutterBinding) {{
    throw StateError('Automated binding required');
  }}
  int Function()? completedCount;
  final success = await directRunTests(() async {{
{declarations}
  }}, reporterFactory: (engine) {{
    completedCount = () => engine.liveTests.length;
    return JsonReporter.watch(engine, stdout, isDebugRun: false);
  }}, allowDuplicateTestNames: false);
  // Give uncaught asynchronous teardown errors a real event-loop turn after
  // the reporter's done event. This does not replace awaiting fixture cleanup.
  await Future<void>.delayed(const Duration(milliseconds: 250));
  final count = completedCount!();
  print('HARNESS completed=$count expected={args.expected} assertions=$assertionsEnabled success=$success');
  await stdout.flush();
  await stderr.flush();
  exit(success && count == {args.expected} ? 0 : 1);
}}
'''
    for test in tests:
        emit(f'HARNESS source={test} sha256={hashlib.sha256(test.read_bytes()).hexdigest()}')
    source_path, _ = memory('mail-widget-bootstrap', source.encode())
    kernel_path, kernel_fd = memory('mail-widget-kernel')
    fontconfig, _ = memory('mail-widget-fontconfig', (
        f'<fontconfig><dir>{flutter}/bin/cache/artifacts</dir>'
        '<cachedir>/var/cache/fontconfig</cachedir></fontconfig>'
    ).encode())
    command = [
        flutter / 'bin/cache/dart-sdk/bin/dartaotruntime',
        engine / 'frontend_server_aot.dart.snapshot',
        '--sdk-root', str(flutter / 'bin/cache/artifacts/engine/common/flutter_patched_sdk') + '/',
        '--target=flutter', '--no-print-incremental-dependencies',
        '-Ddart.vm.profile=false', '-Ddart.vm.product=false', '--enable-asserts',
        '--track-widget-creation', '--packages', packages,
        '--output-dill', kernel_path, '--verbosity=error',
    ]
    if args.native_assets:
        command.extend(['--native-assets', Path(args.native_assets).resolve().as_uri()])
    command.append('file://' + source_path)
    emit('HARNESS compiling original sources to anonymous RAM')
    status = run(command, cwd=repo)
    size = os.fstat(kernel_fd).st_size
    emit(f'HARNESS compiler_exit={status} kernel_bytes={size}')
    if status or size == 0:
        raise SystemExit(status or 2)
    env = dict(os.environ, FLUTTER_TEST='true', FONTCONFIG_FILE=fontconfig,
               APP_NAME='quds_office_studio')
    env.pop('UNIT_TEST_ASSETS', None)
    command = [
        engine / 'flutter_tester', '--disable-vm-service',
        f'--icu-data-file-path={engine / "icudtl.dat"}', '--enable-checked-mode',
        '--verify-entry-points', '--enable-software-rendering',
        '--skia-deterministic-rendering', '--non-interactive', '--use-test-fonts',
        '--disable-asset-fonts', f'--packages={packages}',
        f'--flutter-assets-dir={assets}', kernel_path,
    ]
    status = run(command, strict_test_output=True,
                 cwd=args.cwd or tests[0].parent.parent, env=env)
    emit(f'HARNESS flutter_tester_exit={status}')
    raise SystemExit(status)
finally:
    for link in reversed(links):
        link.unlink()
    for fd in fds:
        os.close(fd)
    if log:
        log.close()
