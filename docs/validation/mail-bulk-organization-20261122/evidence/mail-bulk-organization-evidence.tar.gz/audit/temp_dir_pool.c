#define _GNU_SOURCE
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/random.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>

/* Test infrastructure only. Never link or preload in a product process.
 * Reuses already-owned empty directory inodes when this workspace cannot
 * allocate new directories. Regular file I/O is never intercepted.
 * Recycling requires quiescent test-owned directories: this is not a general
 * replacement for the atomic semantics of rmdir against concurrent writers.
 */
#define SCOPE "/workspace/scratch/f1082e82ac57/tmp"
#define POOL "/workspace/scratch/f1082e82ac57/temp-dir-pool"
#define AUDIT "/workspace/scratch/f1082e82ac57/integration-audit/"
#define LIMIT 64

static pthread_once_t once = PTHREAD_ONCE_INIT;
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
static int enabled, pool_fd = -1, lock_fd = -1;
static dev_t devices[LIMIT];
static ino_t inodes[LIMIT];
static size_t inode_count;
static char *(*real_mkdtemp)(char *);

static void initialize(void) {
  real_mkdtemp = dlsym(RTLD_NEXT, "mkdtemp");
  const char *tmp = getenv("TMPDIR");
  const char *opt = getenv("QUDS_TEST_DIR_POOL");
  if (!tmp || strcmp(tmp, SCOPE) || !opt || strcmp(opt, "1")) return;
  FILE *list = fopen(AUDIT "temp-dir-pool-inodes.txt", "r");
  if (!list) return;
  unsigned long long dev, ino;
  while (inode_count < LIMIT && fscanf(list, "%llu %llu", &dev, &ino) == 2) {
    devices[inode_count] = (dev_t)dev;
    inodes[inode_count++] = (ino_t)ino;
  }
  fclose(list);
  if (!inode_count) return;
  pool_fd = open(POOL, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
  lock_fd = open(AUDIT "temp-dir-pool.lock", O_RDWR | O_CLOEXEC | O_NOFOLLOW);
  enabled = pool_fd >= 0 && lock_fd >= 0;
}

static int allowed(const struct stat *st) {
  if (!S_ISDIR(st->st_mode) || st->st_uid != geteuid()) return 0;
  for (size_t i = 0; i < inode_count; ++i)
    if (devices[i] == st->st_dev && inodes[i] == st->st_ino) return 1;
  return 0;
}

static int acquire(void) {
  if (pthread_mutex_lock(&mutex)) return 0;
  if (flock(lock_fd, LOCK_EX)) {
    pthread_mutex_unlock(&mutex);
    return 0;
  }
  return 1;
}

static void release(void) {
  int saved = errno;
  flock(lock_fd, LOCK_UN);
  pthread_mutex_unlock(&mutex);
  errno = saved;
}

/* Return an opened canonical parent only when wholly inside the test scope.
 * Reject path traversal, symlink escapes, '.'/'..', and the scope root itself.
 */
static int scoped_parent(int at, const char *path, char name[NAME_MAX + 1]) {
  if (!path || !*path) return -1;
  char full[PATH_MAX], parent[PATH_MAX], canonical[PATH_MAX];
  if (*path == '/') {
    if (strlen(path) >= sizeof(full)) return -1;
    strcpy(full, path);
  } else {
    char directory[PATH_MAX];
    if (at == AT_FDCWD) {
      if (!getcwd(directory, sizeof(directory))) return -1;
    } else {
      char fd_name[64];
      snprintf(fd_name, sizeof(fd_name), "/proc/self/fd/%d", at);
      ssize_t size = readlink(fd_name, directory, sizeof(directory) - 1);
      if (size < 0) return -1;
      directory[size] = '\0';
    }
    int size = snprintf(full, sizeof(full), "%s/%s", directory, path);
    if (size < 0 || (size_t)size >= sizeof(full)) return -1;
  }
  size_t length = strlen(full);
  while (length > 1 && full[length - 1] == '/') full[--length] = '\0';
  char *slash = strrchr(full, '/');
  if (!slash || !slash[1] || strlen(slash + 1) > NAME_MAX ||
      !strcmp(slash + 1, ".") || !strcmp(slash + 1, "..")) return -1;
  strcpy(name, slash + 1);
  if (slash == full) strcpy(parent, "/");
  else {
    *slash = '\0';
    strcpy(parent, full);
  }
  if (!realpath(parent, canonical)) return -1;
  const size_t prefix = strlen(SCOPE);
  if (strncmp(canonical, SCOPE, prefix) ||
      (canonical[prefix] != '\0' && canonical[prefix] != '/')) return -1;
  return open(canonical, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
}

/* 1 empty, 0 nonempty, -1 unreadable. Callers never treat unreadable as empty. */
static int empty_directory(int fd) {
  int copy = dup(fd);
  if (copy < 0) return -1;
  if (lseek(copy, 0, SEEK_SET) < 0) { close(copy); return -1; }
  DIR *dir = fdopendir(copy);
  if (!dir) { close(copy); return -1; }
  int result = 1;
  errno = 0;
  struct dirent *item;
  while ((item = readdir(dir))) {
    if (strcmp(item->d_name, ".") && strcmp(item->d_name, "..")) {
      result = 0;
      break;
    }
  }
  if (result && errno) result = -1;
  int saved = errno;
  closedir(dir);
  errno = saved;
  return result;
}

static int current_umask(mode_t *mask) {
  FILE *status = fopen("/proc/self/status", "r");
  if (!status) return 0;
  char line[256];
  unsigned int value;
  int found = 0;
  while (fgets(line, sizeof(line), status)) {
    if (sscanf(line, "Umask:\t%o", &value) == 1) {
      *mask = (mode_t)value;
      found = 1;
      break;
    }
  }
  fclose(status);
  return found;
}

static int borrow_directory(int at, const char *path, mode_t mode) {
  pthread_once(&once, initialize);
  if (!enabled) { errno = ENOSPC; return -1; }
  char name[NAME_MAX + 1];
  int parent = scoped_parent(at, path, name);
  if (parent < 0) { errno = ENOSPC; return -1; }
  struct stat parent_stat;
  mode_t mask;
  if (fstat(parent, &parent_stat) || !current_umask(&mask) || !acquire()) {
    close(parent); errno = ENOSPC; return -1;
  }
  mode_t target_mode = (mode & 01777) & ~mask;
  if (parent_stat.st_mode & S_ISGID) target_mode |= S_ISGID;
  gid_t target_group = (parent_stat.st_mode & S_ISGID) ? parent_stat.st_gid : getegid();
  int result = -1, saved = ENOSPC;
  for (size_t i = 0; i < inode_count; ++i) {
    char donor[64];
    snprintf(donor, sizeof(donor), "d_%llu", (unsigned long long)inodes[i]);
    int fd = openat(pool_fd, donor, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) continue;
    struct stat st;
    if (fstat(fd, &st) || !allowed(&st) || st.st_gid != target_group ||
        empty_directory(fd) != 1) { close(fd); continue; }
    if (fchmod(fd, target_mode) || futimens(fd, NULL)) {
      fchmod(fd, st.st_mode & 07777);
      close(fd);
      continue;
    }
    if (!syscall(SYS_renameat2, pool_fd, donor, parent, name, RENAME_NOREPLACE)) {
      result = 0;
      close(fd);
      break;
    }
    saved = errno;
    fchmod(fd, st.st_mode & 07777);
    close(fd);
    if (saved != ENOENT) break;
  }
  errno = saved;
  release();
  close(parent);
  errno = saved;
  return result;
}

int mkdirat(int at, const char *path, mode_t mode) {
  int result = (int)syscall(SYS_mkdirat, at, path, mode);
  if (result < 0 && errno == ENOSPC) return borrow_directory(at, path, mode);
  return result;
}

int mkdir(const char *path, mode_t mode) { return mkdirat(AT_FDCWD, path, mode); }

static int remove_directory(int at, const char *path) {
  pthread_once(&once, initialize);
  if (!enabled) return (int)syscall(SYS_unlinkat, at, path, AT_REMOVEDIR);
  char name[NAME_MAX + 1];
  int parent = scoped_parent(at, path, name);
  if (parent < 0) return (int)syscall(SYS_unlinkat, at, path, AT_REMOVEDIR);
  struct stat st;
  if (fstatat(parent, name, &st, AT_SYMLINK_NOFOLLOW) || !allowed(&st)) {
    close(parent);
    return (int)syscall(SYS_unlinkat, at, path, AT_REMOVEDIR);
  }
  if (!acquire()) { close(parent); return -1; }
  int fd = openat(parent, name, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
  int result = -1, saved = errno;
  if (fd >= 0) {
    struct stat opened;
    int empty = empty_directory(fd);
    if (fstat(fd, &opened) || opened.st_dev != st.st_dev || opened.st_ino != st.st_ino) {
      saved = EAGAIN;
    } else if (empty == 0) {
      saved = ENOTEMPTY;
    } else if (empty < 0) {
      saved = errno;
    } else {
      char destination[64];
      snprintf(destination, sizeof(destination), "d_%llu", (unsigned long long)st.st_ino);
      if (syscall(SYS_renameat2, parent, name, pool_fd, destination, RENAME_NOREPLACE)) {
        saved = errno;
      } else if (empty_directory(fd) != 1) {
        if (syscall(SYS_renameat2, pool_fd, destination, parent, name, RENAME_NOREPLACE)) {
          static const char message[] = "Directory pool detected concurrent writers; validation aborted; data retained in pool.\n";
          write(STDERR_FILENO, message, sizeof(message) - 1);
          _exit(125);
        }
        saved = ENOTEMPTY;
      } else {
        fchmod(fd, 0700);
        result = 0;
      }
    }
    close(fd);
  }
  errno = saved;
  release();
  close(parent);
  errno = saved;
  return result;
}

int rmdir(const char *path) { return remove_directory(AT_FDCWD, path); }

int unlinkat(int at, const char *path, int flags) {
  if (flags == AT_REMOVEDIR) return remove_directory(at, path);
  return (int)syscall(SYS_unlinkat, at, path, flags);
}

char *mkdtemp(char *pattern) {
  pthread_once(&once, initialize);
  if (!real_mkdtemp) { errno = ENOSYS; return NULL; }
  size_t length = strlen(pattern);
  int valid = length >= 6 && !strcmp(pattern + length - 6, "XXXXXX");
  char *result = real_mkdtemp(pattern);
  if (result || errno != ENOSPC || !valid || !enabled) return result;
  static const char alphabet[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  for (int attempt = 0; attempt < 1024; ++attempt) {
    unsigned char bytes[6];
    ssize_t got = getrandom(bytes, sizeof(bytes), 0);
    if (got != (ssize_t)sizeof(bytes)) { errno = ENOSPC; return NULL; }
    for (size_t i = 0; i < sizeof(bytes); ++i) pattern[length - 6 + i] = alphabet[bytes[i] % 62];
    if (!mkdir(pattern, 0700)) return pattern;
    if (errno != EEXIST) return NULL;
  }
  errno = EEXIST;
  return NULL;
}
