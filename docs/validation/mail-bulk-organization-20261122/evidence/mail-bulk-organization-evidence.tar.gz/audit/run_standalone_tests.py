import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/f1082e82ac57')
REPO = ROOT / 'quds_office_suite'
SUITES = {
    'core': ('quds_mail_core', [
        'mutation_receipt', 'sync_snapshot', 'sync_snapshot_reconciliation',
        'membership_observation', 'membership_commands', 'imap_sync_range', 'ews_identity',
    ]),
    'core_bulk': ('quds_mail_core', [
        'bulk_flags', 'bulk_flags_compatibility', 'bulk_flags_coordinator',
        'bulk_flags_journal', 'bulk_flags_provider_results',
    ]),
    'store': ('quds_mail_store', [
        'migration', 'imap_sync_range', 'move_identity_migration', 'membership_journal',
        'membership_observation_migration', 'move_identity_projection_safety', 'ews_store',
        'membership_reconciliation', 'membership_journal_migration',
        'saved_search_folder_migration', 'mailbox_views', 'move_identity_transition',
    ]),
    'store_memory': ('quds_mail_store', [
        'imap_sync_range', 'ews_store', 'saved_search_folder_migration',
    ]),
    'store_disk': ('quds_mail_store', [
        'migration', 'move_identity_migration', 'membership_journal',
        'membership_observation_migration', 'move_identity_projection_safety',
        'membership_reconciliation', 'membership_journal_migration',
        'mailbox_views', 'move_identity_transition',
    ]),
    'transport': ('quds_mail_transport', [
        'ews_configuration', 'imap_move_receipt', 'ews_provider',
        'native_membership_observation', 'ews_soap', 'ews_ntlm', 'ews_http',
    ]),
    'word': ('quds_office_engine', [
        'office_macro_word_cell_suffix', 'office_vba_word_cell_suffix_conformance',
        'office_vba_word_cell_suffix_integration',
    ]),
    'word_arithmetic': ('quds_office_engine', [
        'office_vba_integer_arithmetic', 'office_vba_word_integer_arithmetic_conformance',
    ]),
    'word_cli': ('quds_office_engine', [
        'office_vba_word_cell_suffix_integration',
        'office_vba_word_integer_arithmetic_integration',
    ]),
}
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')


def save(path, text):
    try:
        path.write_text(text)
    except OSError as error:
        print(f'Could not persist {path.name}: {error}', flush=True)


all_rows = []
for group in sys.argv[1:]:
    package, names = SUITES[group]
    if group == 'transport':
        print("NOT RUN: ews_unsupported_test.dart requires @TestOn('js'); this harness is VM only.", flush=True)
    rows = []
    for stem in names:
        name = stem + '_test.dart'
        source = REPO / 'packages' / package / 'test' / name
        source_sha256 = hashlib.sha256(source.read_bytes()).hexdigest()
        command = [
            str(ROOT / 'toolchains/flutter/bin/cache/dart-sdk/bin/dart'),
            '--enable-asserts',
            '--packages=' + str(REPO / '.dart_tool/package_config.json'),
            str(source),
        ]
        print(f'RUN {group}/{name}', flush=True)
        started = time.monotonic()
        result = subprocess.run(
            command, cwd=REPO / 'packages' / package, env=os.environ.copy(),
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=240,
        )
        output = ANSI.sub('', result.stdout)
        counts = re.findall(r'\+(\d+)(?:\s+~(\d+))?(?:\s+-(\d+))?:', output)
        count = counts[-1] if counts else ('0', '', '')
        row = {
            'group': group, 'file': name, 'exit_code': result.returncode,
            'passed': int(count[0]), 'skipped': int(count[1] or 0),
            'failed': int(count[2] or 0),
            'seconds': round(time.monotonic() - started, 2),
            'assertions_enabled': True,
            'source_sha256': source_sha256,
            'source_unchanged': hashlib.sha256(source.read_bytes()).hexdigest() == source_sha256,
            'harness': 'Pinned package:test standalone VM; library annotations are not parsed',
        }
        rows.append(row)
        all_rows.append(row)
        print(json.dumps(row), flush=True)
        if result.returncode:
            print(output, flush=True)
        elif output.strip():
            print(output.strip().splitlines()[-1], flush=True)
        save(ROOT / 'integration-audit' / f'{group}-{name}.log', output)
    save(ROOT / 'integration-audit' / f'{group}-standalone-summary.json', json.dumps(rows, indent=2))
    print(f'BATCH {group}: passed={sum(r["passed"] for r in rows)}, '
          f'failed={sum(r["failed"] for r in rows)}, '
          f'nonzero_suites={sum(r["exit_code"] != 0 for r in rows)}', flush=True)

print('RESULTS ' + json.dumps(all_rows), flush=True)
sys.exit(1 if any(row['exit_code'] or not row['source_unchanged'] for row in all_rows) else 0)
