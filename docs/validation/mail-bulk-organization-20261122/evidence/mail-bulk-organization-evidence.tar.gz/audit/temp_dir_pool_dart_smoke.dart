import 'dart:convert';
import 'dart:io';

import 'package:sqlite3/sqlite3.dart';

Future<void> main() async {
  var assertionsEnabled = false;
  assert(assertionsEnabled = true);
  if (!assertionsEnabled) throw StateError('Assertions must be enabled');
  const scope = '/workspace/scratch/f1082e82ac57/tmp';
  if (Directory.systemTemp.path != scope) {
    throw StateError('Expected the exact scoped temp directory');
  }
  for (var index = 0; index < 20; index += 1) {
    final directory = index.isEven
        ? await Directory.systemTemp.createTemp('pool-dart-')
        : Directory.systemTemp.createTempSync('pool-dart-');
    try {
      final nested = Directory('${directory.path}/nested');
      if (index.isEven) {
        await nested.create();
      } else {
        nested.createSync();
      }
      final path = '${nested.path}/mail.sqlite';
      final database = sqlite3.open(path);
      try {
        database.execute('PRAGMA journal_mode = WAL');
        database.execute('CREATE TABLE marker (id INTEGER PRIMARY KEY, value TEXT NOT NULL)');
        database.execute('INSERT INTO marker (id, value) VALUES (?, ?)', [index, 'round-$index']);
      } finally {
        database.close();
      }
      final reopened = sqlite3.open(path);
      try {
        final rows = reopened.select('SELECT id, value FROM marker');
        if (rows.length != 1 || rows.single['id'] != index || rows.single['value'] != 'round-$index') {
          throw StateError('Real SQLite data was not retained after close/reopen');
        }
        if (index == 0) {
          print(jsonEncode({'sqlite_version': reopened.select('SELECT sqlite_version() AS version').single['version']}));
        }
      } finally {
        reopened.close();
      }
      if (!await File(path).exists() || await File(path).length() == 0) {
        throw StateError('Expected a real SQLite file on disk');
      }
    } finally {
      if (index.isEven) {
        await directory.delete(recursive: true);
      } else {
        directory.deleteSync(recursive: true);
      }
    }
    if (await directory.exists()) throw StateError('Temporary directory survived deletion');
  }
  print(jsonEncode({
    'status': 'passed',
    'assertions_enabled': assertionsEnabled,
    'dart_temp_rounds': 20,
    'nested_directories': 20,
    'sqlite_wal_file_close_reopens': 20,
    'async_rounds': 10,
    'sync_rounds': 10,
  }));
}
