# Scoped temporary-directory validation

This environment could create and write ordinary files in existing directories,
but `mkdir` and `mkdtemp` failed with `ENOSPC`. A test-only directory pool reuses
13 already-owned, unused, empty SDK/cache directory inodes. The pool root is a
fourteenth existing empty directory. No repository source, test, lockfile, SDK
source content, or dependency content was modified for this fallback.

## Scope and implementation

`temp_dir_pool.c` is compiled into `libtemp_dir_pool.so` using GCC with
`-std=c11 -Wall -Wextra -Werror -O2 -fPIC -shared -ldl -pthread`.

It is inactive unless both `QUDS_TEST_DIR_POOL=1` and the exact
`TMPDIR=/workspace/scratch/f1082e82ac57/tmp` are set. It first attempts ordinary
`mkdir`/`mkdirat`; only `ENOSPC` can trigger borrowing. The canonical parent must
remain inside that exact temp directory, including after resolving symlinks.
The pool contains an explicit device/inode allowlist. Borrowing uses a
cross-process lock and `renameat2(RENAME_NOREPLACE)`, applies the requested mode
and current umask, and refreshes access/modification timestamps. `mkdtemp` retains
random unique names and mode 0700. Only known pool directory inodes are recycled.

Regular file creation, deletion, reading, writing, SQLite, and database locking
are not intercepted. Directory names refer to real filesystem directories.
Nonempty directories are rejected with `ENOTEMPTY`. Existing names retain
`EEXIST`. Unrecognized inodes and paths outside the scope use the normal syscall.

## Real smoke results

- GCC strict compilation: passed with no warnings.
- Forty actual libc `mkdtemp`/delete cycles: passed.
- Forty nested `mkdirat`/`unlinkat(AT_REMOVEDIR)` cycles: passed.
- Six simultaneously live directories: distinct real names and inodes.
- `EEXIST`, `ENOTEMPTY`, requested mode plus umask, unchanged regular-file
  content, and a symlink escape outside scope: passed.
- Twenty actual Dart `Directory.systemTemp.createTemp` and nested-directory
  cycles: passed, split between ten asynchronous and ten synchronous rounds.
- Twenty real SQLite WAL databases were written, closed, reopened, queried, and
  recursively deleted successfully. The exact pinned SQLite 3.9.1 package binary
  reports SQLite runtime 3.54.1. Dart assertions were enabled.
- All thirteen donor inodes returned empty to the pool after the smoke tests.

The runnable smoke sources are `temp_dir_pool_smoke.py` and
`temp_dir_pool_dart_smoke.dart`. The original inode/path/mode manifest is
`temp-dir-pool-manifest.json`.

## Use

For the RAM Flutter runner with its explicit native-assets mapping:

```sh
TMPDIR=/workspace/scratch/f1082e82ac57/tmp \
QUDS_TEST_DIR_POOL=1 \
LD_PRELOAD=/workspace/scratch/f1082e82ac57/integration-audit/libtemp_dir_pool.so \
python3 /workspace/scratch/f1082e82ac57/integration-audit/ram_flutter_test.py \
  --expected TEST_COUNT \
  --native-assets /workspace/scratch/f1082e82ac57/integration-audit/sqlite-native-assets.json \
  --log EXISTING_AUDIT_DIRECTORY/TEST_LOG \
  REPOSITORY_RELATIVE_TEST_PATH
```

Standalone Dart native tests additionally preload the verified
`libsqlite3-3.9.1-linux-x64.so`, separated from the pool library by a colon.

After all test processes stop, run `restore_temp_dir_pool.py` to verify that the
pool is idle. Run it with `--apply` to return all fourteen empty directories and
their original modes to their recorded SDK/cache paths. It refuses to overwrite
existing paths, restore nonempty folders, or proceed with missing/unrecognized
inodes.

## Limits

This fallback qualifies ordinary, quiescent, test-owned temporary fixtures. It
does **not** qualify concurrent writers racing `rmdir`, directory-handle use
after deletion, general filesystem semantics, filesystem capacity behavior, or
production packaging. Recycling by rename cannot reproduce `rmdir`'s atomic
empty-check against uncoordinated concurrent writers. The wrapper checks again
after moving and attempts rollback on a detected writer; irreconcilable races
abort the test process with exit 125 while retaining data in the pool.

The pool has thirteen concurrently available directory inodes. Tests must close
their database/background work and finish deleting files before directory
teardown. A changed pool inventory or any nonempty pool entry must be treated as
a failed/unfinished cleanup, not silently reused or deleted.

The RAM runner also waits 250 milliseconds on the real event loop after the
test engine finishes. It rejects unexpected non-JSON tester output and explicit
JSON failure events, even if a final success event or process exit zero appears.
Negative controls confirmed that both a late raw exception and a late JSON error
after a success event produce failure. This drain supplements properly awaited
fixture cleanup; it is not a substitute for it.
