# Initial provider/dialog validation attempts

This note records failed attempts observed in the tool output on 2026-11-22.
It is a reconstruction of the observed results, not a replacement raw log: the
initial RAM-run console output was not saved as a local log file. The final
passing run has its original JSONL log in
`integration-audit/widget-provider-dialog-ram.jsonl`.

## First RAM Flutter run

The original Flutter frontend successfully compiled a 159,668,384-byte kernel
to anonymous memory. The original Flutter tester executed all 37 intended
cases with assertions enabled and the automated widget binding. The process
exited 1: 33 cases passed and four failed.

One common-dialog case failed because the initial harness omitted the standard
SDK asset `shaders/ink_sparkle.frag`. The error was reported by the Flutter test
framework as an asset-not-found exception. The resolution was to compile both
stock SDK Material shaders with the pinned SDK's own `impellerc` and expose the
real compiled shader files as test assets. No application theme, platform
selection, test assertion, or SDK source was changed to avoid the shader.

The other three failures were the EWS, Graph, and Gmail variants of
`an old confirmation cannot enter a new session`. The test attempted to cast
the result of `find.byTooltip` to `IconButton`, but this SDK returns a
`RawTooltip` for that finder. The fixture was corrected to find the disconnect
`IconButton` by its logout icon. The actual stale-session behavior then executed
and passed in all three provider variants.

## Shader-output attempt

An intermediate attempt to send the stock shader compiler's output directly to
an anonymous-memory descriptor failed with `Could not write file to` the
descriptor path and exit 1. No widget tests ran in that attempt. The SDK shader
compiler requires ordinary filesystem output. Creating new files inside an
existing directory worked even though new directory creation failed with
`ENOSPC`, so the original compiler successfully wrote the 13,472-byte ink
sparkle shader and the 9,464-byte stretch-effect shader into the existing
workspace temp directory.

## Final observed run

After those infrastructure/fixture corrections, the original Flutter tester ran
the same 37 cases successfully: 12 dialog cases and 25 provider cases, with zero
skips and zero failures. The final JSONL log, source hashes, and validation
summary preserve that result. These attempts are repeated execution of the same
cases and must not be added together when reporting unique coverage.

The RAM harness was subsequently hardened for persistent SQLite host tests with
a 250-millisecond real-event-loop drain and rejection of late raw or JSON error
output. The ephemeral provider/dialog run predates that hardening; it used
memory-backed fixtures and its saved log contains no unclassified error output.
