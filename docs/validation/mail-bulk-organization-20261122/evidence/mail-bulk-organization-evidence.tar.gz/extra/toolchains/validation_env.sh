export FLUTTER_ROOT=/workspace/scratch/f1082e82ac57/toolchains/flutter
export PUB_CACHE=/workspace/scratch/f1082e82ac57/pub-cache
export TMPDIR=/workspace/scratch/f1082e82ac57/tmp
export XDG_CONFIG_HOME=/workspace/scratch/f1082e82ac57/toolchains/config
export CI=true
export FLUTTER_SUPPRESS_ANALYTICS=true
export DART_SUPPRESS_ANALYTICS=true
export PATH="$FLUTTER_ROOT/bin:$PATH"
