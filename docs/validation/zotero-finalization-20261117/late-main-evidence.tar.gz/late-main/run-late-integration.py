#!/usr/bin/env python3
"""Orchestrate only the bounded late sheet and actual-host reruns."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import signal
import subprocess
import time

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--quds-source',type=Path,required=True)
 p.add_argument('--host-source',type=Path,required=True)
 p.add_argument('--quds-commit',required=True)
 p.add_argument('--host-commit',required=True)
 p.add_argument('--runtime',type=Path,required=True)
 p.add_argument('--output',type=Path,required=True)
 a=p.parse_args();runtime=a.runtime.resolve();out=a.output.resolve();scripts=Path(__file__).resolve().parent
 out.mkdir(parents=True,exist_ok=True);assert not (out/'receipt.json').exists(),'Use a fresh output directory'
 setup=scripts/'service-setup/service-setup-receipt.json';graph=json.loads(setup.read_text());assert graph['status']=='passed'
 env=os.environ.copy();env.update(FLUTTER_ROOT=str(runtime/'flutter-sdk'),PUB_CACHE=str(runtime/'pub-cache'),
  TMPDIR=str(runtime/'tmp'),XDG_CONFIG_HOME=str(runtime/'config'),CI='true',DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true')
 receipt={'status':'running','quds_source_commit':a.quds_commit,'host_source_commit':a.host_commit,
  'prior_qualification':{'canonical_source':'5b05664357eead5ddc86922bab248224dbd4da6d',
   'host_source':'342b744a3cb66e3ee9387733ebcf8613cdb23a33','reported_tests':1128,
   'earlier_receipts_remain_bound_to_those_pins':True},
  'counts_are_overlapping_reruns_not_additive_unique_tests':True,'github_actions_used':False,
  'runner_sha256':sha(Path(__file__)),'service_setup_sha256':sha(setup),'cohorts':[]}
 def save():
  tmp=out/'receipt.json.tmp';tmp.write_text(json.dumps(receipt,indent=2)+'\n');tmp.replace(out/'receipt.json')
 commands=[('canonical',[os.sys.executable,str(scripts/'run-late-canonical.py'),'--source',str(a.quds_source.resolve()),
   '--source-commit',a.quds_commit,'--runtime',str(runtime),'--harness-root',str(runtime/'harness'),'--output',str(out/'canonical')],env),
  ('host',[os.sys.executable,str(scripts/'run-late-host.py'),'--repo',str(a.host_source.resolve()),'--harness',graph['harness'],
   '--quds-source',str(a.quds_source.resolve()),'--quds-commit',a.quds_commit,'--source-commit',a.host_commit,
   '--setup-receipt',str(setup),'--output',str(out/'host')],dict(env,PUB_CACHE=graph['pub_cache'],
    TMPDIR=str(scripts/'service-setup/tmp'),XDG_CONFIG_HOME=str(scripts/'service-setup/config')))]
 failure=None;save()
 for name,command,command_env in commands:
  log=out/(name+'-launcher.log');row={'name':name,'command':command,'status':'running','log':log.name,
   'runner_sha256':sha(Path(command[1])),'outer_timeout_seconds':8400};receipt['cohorts'].append(row);save()
  start=time.monotonic();proc=None
  try:
   with log.open('w') as stream:
    proc=subprocess.Popen(command,env=command_env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    row['pid']=proc.pid;save();print(json.dumps({'start':name,'pid':proc.pid}),flush=True)
    while proc.poll() is None:
     try:proc.wait(timeout=15)
     except subprocess.TimeoutExpired:
      row['elapsed_seconds']=round(time.monotonic()-start,3);row['log_bytes']=log.stat().st_size;save()
      print(json.dumps({'active':name,'seconds':row['elapsed_seconds'],'log_bytes':row['log_bytes']}),flush=True)
     if time.monotonic()-start>8400:raise TimeoutError(name)
   row['exit_code']=proc.returncode;assert proc.returncode==0,name+' failed'
   child=out/name/'receipt.json';child_data=json.loads(child.read_text());assert child_data['status']=='passed'
   row.update(status='passed',receipt=str(child.relative_to(out)),receipt_sha256=sha(child))
  except BaseException as e:
   failure=f'{type(e).__name__}: {e}';row.update(status='failed',error=failure)
   if proc is not None and proc.poll() is None:
    os.killpg(proc.pid,signal.SIGTERM)
    try:proc.wait(timeout=15)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=15)
  finally:
   row['elapsed_seconds']=round(time.monotonic()-start,3);row['log_sha256']=sha(log) if log.exists() else None;save()
  if failure:break
 receipt.update(status='passed' if failure is None and len(receipt['cohorts'])==2 else 'failed',error=failure)
 if receipt['status']=='passed':
  canonical=json.loads((out/'canonical/receipt.json').read_text());host=json.loads((out/'host/receipt.json').read_text())
  receipt['observed_rerun_counts']={'canonical_sheet':canonical['passed_tests'],'host_existing':host['passed_host_tests'],
   'host_document_service':host['passed_service_tests'],'host_python':host['passed_python_tests']}
 save();print(json.dumps({'status':receipt['status'],'observed_rerun_counts':receipt.get('observed_rerun_counts'),'error':failure}),flush=True)
 return 0 if receipt['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(main())
