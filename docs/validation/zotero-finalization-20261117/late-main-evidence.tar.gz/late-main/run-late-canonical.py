#!/usr/bin/env python3
"""Bounded sheet integration qualification at an immutable canonical source."""
from pathlib import Path
import argparse
import fcntl
import hashlib
import json
import os
import re
import signal
import subprocess
import time
import traceback
import types

TARGETS = [
 'packages/quds_office_engine/lib/src/sheet/serial/sheet_serial.dart',
 'packages/quds_office_engine/lib/src/sheet/styles/sml_styles.dart',
 'packages/quds_office_engine/test/sheet_save_cache_and_freeze_test.dart',
 'packages/quds_office_engine/test/sheet_style_namespace_fidelity_test.dart',
]
TESTS = ['test/sheet_save_cache_and_freeze_test.dart', 'test/sheet_style_namespace_fidelity_test.dart']
TIMEOUT = 600

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--source',type=Path,required=True)
 parser.add_argument('--source-commit',required=True)
 parser.add_argument('--runtime',type=Path,required=True)
 parser.add_argument('--harness-root',type=Path,required=True)
 parser.add_argument('--output',type=Path,required=True)
 args=parser.parse_args()
 source,runtime,harness,out=[p.resolve() for p in (args.source,args.runtime,args.harness_root,args.output)]
 out.mkdir(parents=True,exist_ok=True)
 assert not (out/'receipt.json').exists(),'Use a fresh output; prior receipts cannot be replaced'
 helper_path=Path(__file__).with_name('canonical-support.py')
 helper=types.ModuleType('frozen_canonical_support');helper.__file__=str(helper_path)
 exec(compile(helper_path.read_bytes(),str(helper_path),'exec'),helper.__dict__)
 helper.SOURCE=source;helper.TOOLCHAIN=runtime;helper.WORKSPACE=runtime.parent
 helper.HARNESSES=harness;helper.PUBLISHED_SOURCE=args.source_commit
 assert re.fullmatch('[0-9a-f]{40}',args.source_commit)
 tree=helper.git_text('rev-parse',args.source_commit+'^{tree}')
 assert helper.git_text('rev-parse','HEAD^{tree}')==tree
 sdk=runtime/'flutter-sdk';dart=str(sdk/'bin/cache/dart-sdk/bin/dart')
 version=json.loads((sdk/'bin/cache/flutter.version.json').read_text())
 assert version['frameworkRevision']=='737ba8f885dc774b53b442759999a312c9461e4e'
 assert version['engineRevision']=='cf636b1dfb818dd6a3ff16e390e93b1a036969c8'
 assert version['dartSdkVersion']=='3.13.7'
 for relative in ['lib','test']:
  assert (harness/'quds_office_engine'/relative).resolve()==source/'packages/quds_office_engine'/relative
 for path in TARGETS:assert (source/path).is_file(),path
 graph=helper.normalize_graph(harness/'quds_office_engine/.dart_tool/package_config.json')
 graphs={'engine':graph};before=helper.source_fingerprint()
 assert not before['untracked_paths'] and not helper.published_matches(before['sha256_by_path'])
 dependencies=helper.dependencies_fingerprint(graphs);inputs=helper.harness_inputs();fixtures=helper.fixture_inputs()
 receipt={'status':'running','scope':'bounded late sheet integration; overlapping rerun, not additive unique tests',
  'source_commit':args.source_commit,'source_tree':tree,'source_checkout':str(source),'runtime':version,
  'runtime_root':str(runtime),'harness_root':str(harness),'tests':TESTS,'analysis_and_format_targets':TARGETS,
  'runner_sha256':helper.sha(Path(__file__)),'frozen_support_sha256':helper.sha(helper_path),
  'source_file_count':before['files'],'dependency_file_count':dependencies['files'],
  'harness_inputs_before':inputs,'commands':[],'github_actions_used':False,
  'per_command_timeout_seconds':TIMEOUT,'heartbeat_seconds':15}
 def save(name,value):
  p=out/name;tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n');tmp.replace(p)
 def checkpoint():save('receipt.json',receipt)
 save('source-before.json',before);save('dependencies-before.json',dependencies);save('fixtures-before.json',fixtures)
 save('engine-analysis-package-config.json',graph);checkpoint()
 def stop(proc):
  if proc.poll() is not None:return
  try:os.killpg(proc.pid,signal.SIGTERM)
  except ProcessLookupError:return
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=10)
 def run(name,command,cwd,test=False):
  log=out/(name+'.log');start=time.monotonic();proc=None
  row={'name':name,'command':command,'cwd':str(cwd),'status':'running','log':log.name,'timeout_seconds':TIMEOUT}
  receipt['commands'].append(row);checkpoint();print(json.dumps({'start':name}),flush=True)
  try:
   with log.open('w') as stream:
    proc=subprocess.Popen(command,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    row['pid']=proc.pid;checkpoint()
    while proc.poll() is None:
     elapsed=time.monotonic()-start
     if elapsed>=TIMEOUT:
      row['timed_out']=True;stop(proc);raise TimeoutError(name)
     try:proc.wait(timeout=min(15,TIMEOUT-elapsed))
     except subprocess.TimeoutExpired:
      row['elapsed_seconds']=round(time.monotonic()-start,3);row['log_bytes']=log.stat().st_size
      checkpoint();print(json.dumps({'active':name,'seconds':row['elapsed_seconds']}),flush=True)
   row['exit_code']=proc.returncode
   assert proc.returncode==0,f'{name}: exit {proc.returncode}'
   if test:
    match=re.search(r'\+(\d+)(?:\s+~(\d+))?: All tests passed!',log.read_text())
    assert match and int(match[1])>0 and int(match[2] or 0)==0,'No complete zero-skip positive test result'
    row['passed_tests']=int(match[1]);row['skipped_tests']=int(match[2] or 0)
   row['status']='passed'
  except BaseException as error:
   if proc is not None:stop(proc)
   row['status']='failed';row['error']=f'{type(error).__name__}: {error}'
   row['exit_code']=proc.returncode if proc else None
   raise
  finally:
   row['elapsed_seconds']=round(time.monotonic()-start,3);row['log_sha256']=helper.sha(log) if log.exists() else None
   checkpoint();print(json.dumps({'finish':name,'status':row['status'],'seconds':row['elapsed_seconds']}),flush=True)
 config=source/'.dart_tool/package_config.json';previous=config.read_bytes() if config.exists() else None
 existed=config.parent.exists();failure=None
 try:
  run('sheet-tests',[dart,'test','--concurrency=2','--reporter','expanded',*TESTS],harness/'quds_office_engine',test=True)
  config.parent.mkdir(exist_ok=True);config.write_text(json.dumps(graph,indent=2)+'\n')
  run('sheet-strict-analysis',[dart,'analyze','--fatal-infos',*TARGETS],source)
  run('sheet-format',[dart,'format','--language-version=3.12','--output=none','--set-exit-if-changed',*TARGETS],source)
 except BaseException as error:
  failure=f'{type(error).__name__}: {error}';receipt['traceback']=traceback.format_exc()
 finally:
  if previous is None:
   config.unlink(missing_ok=True)
   if not existed and config.parent.exists() and not any(config.parent.iterdir()):config.parent.rmdir()
  else:config.write_bytes(previous)
  after=helper.source_fingerprint();deps_after=helper.dependencies_fingerprint(graphs)
  inputs_after=helper.harness_inputs();fixtures_after=helper.fixture_inputs()
  save('source-after.json',after);save('dependencies-after.json',deps_after);save('fixtures-after.json',fixtures_after)
  receipt.update(source_inputs_unchanged=before==after,dependencies_unchanged=dependencies==deps_after,
   harness_inputs_unchanged=inputs==inputs_after,harness_inputs_after=inputs_after,fixtures_unchanged=fixtures==fixtures_after,
   analyzer_config_restored=(config.read_bytes() if config.exists() else None)==previous,
   published_source_still_matches=not helper.published_matches(after['sha256_by_path']),head_at_completion=helper.git_text('rev-parse','HEAD'))
  gates=['source_inputs_unchanged','dependencies_unchanged','harness_inputs_unchanged','fixtures_unchanged','analyzer_config_restored','published_source_still_matches']
  passed=failure is None and len(receipt['commands'])==3 and all(r['status']=='passed' for r in receipt['commands']) and all(receipt[k] for k in gates)
  receipt.update(status='passed' if passed else 'failed',error=failure,passed_tests=receipt['commands'][0].get('passed_tests'))
  checkpoint()
 print(json.dumps({'status':receipt['status'],'passed_tests':receipt['passed_tests'],'error':failure}),flush=True)
 return 0 if receipt['status']=='passed' else 1

if __name__=='__main__':
 lock=Path(__file__).resolve().parents[1]/'canonical-final/qualification.lock'
 with lock.open('a+') as stream:
  fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
  raise SystemExit(main())
