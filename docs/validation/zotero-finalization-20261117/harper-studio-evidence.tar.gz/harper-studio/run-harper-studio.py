#!/usr/bin/env python3
"""Qualify Harper source mapping and Studio integration against an exact local pin."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import traceback
from urllib.parse import unquote, urljoin, urlparse

TIMEOUT = 600
HEARTBEAT = 15
LOCK_SHA256 = '344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130'
TESTS = ['test/harper_provider_test.dart', 'test/harper_source_text_test.dart', 'test/harper_source_contract_test.dart']
HARPER_TARGETS = ['lib/src/harper_provider.dart', 'lib/src/harper_source_text.dart',
                  'test/harper_source_contract_test.dart', 'test/harper_source_text_test.dart',
                  'test/harper_provider_test.dart']
STUDIO_TARGET = 'packages/quds_office_editor/example/lib/suite_workspace.dart'
LOCAL_PACKAGES = {
    'quds_office_suite': '',
    'legacy_doc_parser': 'packages/legacy_doc_parser',
    'quds_office_engine': 'packages/quds_office_engine',
    'quds_proofing_harper': 'packages/quds_proofing_harper',
    'quds_office_engine_example': 'packages/quds_office_engine/example',
    'quds_reports': 'packages/quds_reports',
    'quds_office_editor': 'packages/quds_office_editor',
    'quds_office_studio': 'packages/quds_office_editor/example',
    'quds_report_studio': 'apps/quds_report_studio',
}


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    temporary.replace(path)


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def git_text(repo, *args):
    return git(repo, *args).decode().strip()


def selected_source(path):
    parts = Path(path).parts
    if not parts or parts[0] == 'docs':
        return False
    return (
        Path(path).name in {'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'}
        or (len(parts) >= 4 and parts[0] in {'packages', 'apps'} and parts[2] in {'lib', 'test', 'fonts', 'assets', 'third_party'})
        or path.startswith('packages/quds_office_editor/example/lib/')
        or path.startswith('packages/quds_office_editor/example/test/')
        or path.startswith('packages/quds_office_engine/example/lib/')
    )


def source_snapshot(repo, pin):
    expected = {}
    for row in git(repo, 'ls-tree', '-r', '-z', pin).split(b'\0'):
        if row:
            meta, name = row.split(b'\t', 1)
            expected[name.decode()] = meta.split()[2].decode()
    untracked = [p.decode() for p in git(repo, 'ls-files', '--others', '--exclude-standard', '-z').split(b'\0') if p and selected_source(p.decode())]
    if untracked:
        raise ValueError(f'Untracked compiled source inputs: {untracked}')
    files = {}
    for row in git(repo, 'ls-files', '-z').split(b'\0'):
        if not row or not selected_source(row.decode()):
            continue
        path = row.decode()
        data = (repo / path).read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if expected.get(path) != blob:
            raise ValueError(f'Source differs from published Git blob: {path}')
        files[path] = {'sha256': digest(data), 'git_blob': blob}
    return files


def resolve(config, uri):
    parsed = urlparse(urljoin(config.as_uri(), uri))
    if parsed.scheme != 'file' or parsed.netloc not in {'', 'localhost'}:
        raise ValueError(f'Expected local dependency URI: {uri}')
    return Path(unquote(parsed.path)).resolve()


def setup_snapshot(workspace, repo, flutter):
    config = workspace / '.dart_tool/package_config.json'
    graph = json.loads(config.read_text())
    if graph['configVersion'] != 2:
        raise ValueError('Unsupported package graph')
    lock = workspace / 'pubspec.lock'
    if digest(lock.read_bytes()) != LOCK_SHA256:
        raise ValueError('The full workspace lock differs from the published lock')
    harness = {}
    for relative in ['.dart_tool/package_config.json', '.dart_tool/package_graph.json', 'pubspec.lock', 'analysis_options.yaml']:
        path = workspace / relative
        if path.is_file():
            harness[relative] = digest(path.read_bytes())
    for relative in LOCAL_PACKAGES.values():
        path = Path(relative) / 'pubspec.yaml'
        actual = (workspace / path).read_bytes()
        if actual != (repo / path).read_bytes():
            raise ValueError(f'Workspace production manifest differs: {path}')
        harness[str(path)] = digest(actual)
    dependencies = {}
    roots = {}
    mapped = json.loads(json.dumps(graph))
    observed_local = set()
    for entry in mapped['packages']:
        name = entry['name']
        root = resolve(config, entry['rootUri'])
        library = (root / entry.get('packageUri', 'lib/')).resolve()
        if name in LOCAL_PACKAGES:
            observed_local.add(name)
            expected = repo / LOCAL_PACKAGES[name]
            expected_library = expected / 'lib'
            if expected_library.is_dir() and (not library.is_dir() or not library.samefile(expected_library)):
                raise ValueError(f'{name} does not resolve to the actual canonical source')
            entry['rootUri'] = expected.as_uri() + '/'
        else:
            entry['rootUri'] = root.as_uri() + '/'
            for folder in ['lib', 'bin']:
                for path in sorted((root / folder).rglob('*')):
                    if path.is_file():
                        dependencies[f'{name}/{path.relative_to(root)}'] = digest(path.read_bytes())
            for filename in ['pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', 'LICENSE']:
                path = root / filename
                if path.is_file():
                    dependencies[f'{name}/{filename}'] = digest(path.read_bytes())
        roots[name] = {'root': str(root), 'library': str(library), 'language_version': entry.get('languageVersion')}
    if observed_local != set(LOCAL_PACKAGES):
        raise ValueError(f'Incomplete production workspace graph: {observed_local}')
    runtime = {}
    for relative in ['bin/cache/dart-sdk/bin/dart',
                     'bin/cache/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot',
                     'bin/cache/flutter_tools.snapshot',
                     'bin/cache/artifacts/engine/linux-x64/flutter_tester',
                     'bin/cache/artifacts/engine/common/flutter_patched_sdk/platform_strong.dill',
                     'bin/cache/flutter.version.json', 'bin/internal/engine.version']:
        runtime[relative] = digest((flutter / relative).read_bytes())
    return {'harness': harness, 'dependencies': dependencies, 'runtime': runtime, 'package_roots': roots}, mapped


def main():
    def interrupted(signum, frame):
        raise InterruptedError(f'Received signal {signum}')

    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', type=Path, required=True)
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo, workspace, output = (p.resolve() for p in (args.source_dir, args.workspace, args.output))
    flutter = Path(os.environ['FLUTTER_ROOT']).resolve()
    dart = str(flutter / 'bin/cache/dart-sdk/bin/dart')
    output.mkdir(parents=True, exist_ok=True)
    if (output / 'receipt.json').exists():
        raise ValueError('Use a fresh output directory; existing evidence cannot be overwritten')
    pin = args.source_commit
    if not re.fullmatch(r'[0-9a-f]{40}', pin) or git_text(repo, 'rev-parse', pin + '^{commit}') != pin:
        raise ValueError('Use an exact available 40-character published source commit')
    tree = git_text(repo, 'rev-parse', pin + '^{tree}')
    if git_text(repo, 'rev-parse', 'HEAD^{tree}') != tree:
        raise ValueError('Checkout tree differs from the qualified source pin')
    runtime = json.loads((flutter / 'bin/cache/flutter.version.json').read_text())
    if (runtime['frameworkRevision'], runtime['engineRevision'], runtime['dartSdkVersion']) != (
        '737ba8f885dc774b53b442759999a312c9461e4e', 'cf636b1dfb818dd6a3ff16e390e93b1a036969c8', '3.13.7'):
        raise ValueError('Unexpected Flutter/Dart runtime')
    before = source_snapshot(repo, pin)
    setup_before, graph = setup_snapshot(workspace, repo, flutter)
    save(output / 'source-before.json', before)
    save(output / 'dependencies-before.json', setup_before)
    save(output / 'analysis-package-config.json', graph)
    receipt = {'status': 'running', 'source_commit': pin, 'source_tree': tree,
               'started_utc': now(), 'runner_sha256': digest(Path(__file__).read_bytes()),
               'source_input_count': len(before), 'external_input_count': len(setup_before['dependencies']),
               'workspace_lock_sha256': LOCK_SHA256, 'runtime': runtime,
               'commands': [], 'harper_tests': TESTS, 'harper_analysis_targets': HARPER_TARGETS,
               'studio_analysis_target': STUDIO_TARGET, 'timeout_seconds': TIMEOUT,
               'heartbeat_seconds': HEARTBEAT, 'github_actions_used': False,
               'counts_from_prior_runs_reused': False,
               'scope': 'Three pure Dart Harper adapter/source-mapping suites using injected transport; strict Harper and Studio analysis/format on the exact production workspace graph. No native/Wasm acceptance or full application build.'}
    receipt_path = output / 'receipt.json'
    save(receipt_path, receipt)

    def run(name, command, cwd, test=False):
        log = output / (name + '.stdout.log')
        error_log = output / (name + '.stderr.log')
        row = {'name': name, 'command': command, 'cwd': str(cwd), 'status': 'running',
               'started_utc': now(), 'timeout_seconds': TIMEOUT, 'stdout': log.name, 'stderr': error_log.name}
        receipt['commands'].append(row)
        save(receipt_path, receipt)
        started = time.monotonic()
        process = None

        def stop():
            if process is None or process.poll() is not None:
                return
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                return
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(timeout=5)

        try:
            with log.open('w') as stdout, error_log.open('w') as stderr:
                process = subprocess.Popen(command, cwd=cwd, stdout=stdout, stderr=stderr, start_new_session=True)
                row['pid'] = process.pid
                print(json.dumps({'event': 'start', 'command': name}), flush=True)
                while process.poll() is None:
                    remaining = TIMEOUT - (time.monotonic() - started)
                    if remaining <= 0:
                        row['timed_out'] = True
                        stop()
                        raise TimeoutError(name)
                    try:
                        process.wait(timeout=min(HEARTBEAT, remaining))
                    except subprocess.TimeoutExpired:
                        row.update(last_heartbeat_utc=now(), elapsed_seconds=round(time.monotonic() - started, 3), stdout_bytes=log.stat().st_size)
                        save(receipt_path, receipt)
                        print(json.dumps({'event': 'heartbeat', 'command': name, 'elapsed_seconds': row['elapsed_seconds']}), flush=True)
            row['exit_code'] = process.returncode
            if process.returncode != 0:
                raise RuntimeError(f'{name} exited {process.returncode}')
            if test:
                match = re.search(r'\+(\d+)(?:\s+~(\d+))?: All tests passed!', log.read_text())
                if not match:
                    raise RuntimeError('Missing completed test success marker')
                row['passed_tests'] = int(match[1])
                row['skipped_tests'] = int(match[2] or 0)
                if row['skipped_tests']:
                    raise RuntimeError('Unexpected skipped Harper contract tests')
            row['status'] = 'passed'
        except BaseException as error:
            stop()
            row.update(status='failed', error=type(error).__name__ + ': ' + str(error))
            raise
        finally:
            row.update(finished_utc=now(), elapsed_seconds=round(time.monotonic() - started, 3),
                       stdout_sha256=digest(log.read_bytes()) if log.exists() else None,
                       stderr_sha256=digest(error_log.read_bytes()) if error_log.exists() else None)
            save(receipt_path, receipt)
            print(json.dumps({'event': 'finish', 'command': name, 'status': row['status'], 'exit_code': row.get('exit_code')}), flush=True)

    target = repo / '.dart_tool/package_config.json'
    original = target.read_bytes() if target.exists() else None
    original_parent = target.parent.exists()
    failure = None
    try:
        # Tests use the exact locked copied workspace. Analysis targets actual
        # canonical files, with the corresponding complete workspace graph.
        run('harper-tests', [dart, 'test', '--concurrency=2', '--reporter', 'expanded', *TESTS], workspace / LOCAL_PACKAGES['quds_proofing_harper'], test=True)
        target.parent.mkdir(exist_ok=True)
        target.write_text(json.dumps(graph, indent=2) + '\n')
        targets = [LOCAL_PACKAGES['quds_proofing_harper'] + '/' + x for x in HARPER_TARGETS]
        run('harper-analysis', [dart, 'analyze', '--fatal-infos', *targets], repo)
        run('harper-format', [dart, 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed', *targets], repo)
        run('studio-analysis', [dart, 'analyze', '--fatal-infos', STUDIO_TARGET], repo)
        run('studio-format', [dart, 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed', STUDIO_TARGET], repo)
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        receipt['error'] = failure
        receipt['traceback'] = traceback.format_exc()
    finally:
        if original is None:
            target.unlink(missing_ok=True)
            if not original_parent and target.parent.exists() and not any(target.parent.iterdir()):
                target.parent.rmdir()
        else:
            target.write_bytes(original)
        try:
            after = source_snapshot(repo, pin)
            setup_after, _ = setup_snapshot(workspace, repo, flutter)
            save(output / 'source-after.json', after)
            save(output / 'dependencies-after.json', setup_after)
            receipt['source_inputs_unchanged'] = before == after
            receipt['dependency_runtime_harness_inputs_unchanged'] = setup_before == setup_after
            receipt['analysis_config_restored'] = (target.read_bytes() if target.exists() else None) == original
            receipt['published_inputs_still_match'] = True
            if not all(receipt[x] for x in ['source_inputs_unchanged', 'dependency_runtime_harness_inputs_unchanged', 'analysis_config_restored']):
                raise RuntimeError('Input stability or analyzer restoration failed')
        except BaseException as error:
            failure = (failure + '; ' if failure else '') + type(error).__name__ + ': ' + str(error)
            receipt['finalization_error'] = traceback.format_exc()
        receipt.update(finished_utc=now(), status='passed' if failure is None and len(receipt['commands']) == 5 else 'failed', error=failure)
        receipt['passed_tests'] = sum(x.get('passed_tests', 0) for x in receipt['commands'] if x['status'] == 'passed')
        save(receipt_path, receipt)
    print(json.dumps({k: receipt.get(k) for k in ['status', 'passed_tests', 'source_inputs_unchanged', 'dependency_runtime_harness_inputs_unchanged', 'analysis_config_restored', 'error']}), flush=True)
    return 0 if receipt['status'] == 'passed' else 1


if __name__ == '__main__':
    output = Path(__file__).resolve().parent
    # Both runners temporarily install a canonical analysis graph. Fail fast
    # instead of racing, waiting, or letting one overwrite the other's graph.
    canonical_lock = output.parent / 'canonical-final/qualification.lock'
    canonical_lock.parent.mkdir(parents=True, exist_ok=True)
    with canonical_lock.open('a+') as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit('Canonical qualification is active; launch this cohort after it finishes.')
        try:
            raise SystemExit(main())
        except BaseException as error:
            if not isinstance(error, SystemExit) or error.code not in (None, 0):
                save(output / 'runner-error.json', {'recorded_utc': now(), 'error': type(error).__name__ + ': ' + str(error), 'traceback': traceback.format_exc()})
            raise
