# CrispCloud Zotero continuation: final host integration

## Published implementation

| Input | Identity |
| --- | --- |
| Published host implementation | `342b744a3cb66e3ee9387733ebcf8613cdb23a33` |
| Host implementation tree | `276d73be08e5e37ee467cce4ad196f5dde1eac04` |
| Canonical Quds source | `5b05664357eead5ddc86922bab248224dbd4da6d` |
| Initial published host checkpoint | `cf905f6ed686e75ef1a897d96179fe4e9cc7d5a6` |
| Integrated frozen host main | `e18e92c44e1b80d250469feed130615571d5845f` |
| Integrated PR #203 head | `a8edc699641da3e3b3f1452b5db59bec52a5717d` |
| Standalone parser pin | `4895712158127b2fc930d796e17035c3ca0dac62` |
| Managed source inventory | **2,521 files: 664 canonical Quds files and 1,857 standalone parser files** |

The final host commit retains the initial published checkpoint and PR #203 as
its two parents. The initial checkpoint retains the earlier recovery branch
and frozen main. Consequently, the Zotero recovery, ranked/average spreadsheet
changes and their documentation all remain in the delivered history.

## Incoming refs reconciled

The frozen local-ref snapshot contains **274 refs: 81 branch heads and 193 PR
heads**, observed at `2026-11-16T23:16:26.792563+00:00`. The original main was
`e18e92c44e1b80d250469feed130615571d5845f`. This is a bounded observation, not
a claim that remote refs stopped changing afterward.

Replaying that exact snapshot against the published final implementation
accounts for **214 actual ancestors and 60 exact whole-tree aliases to
ancestors**, with no unresolved incoming refs. Full tree equality is used for
the aliases; no patch-similarity assumption is needed. The original premerge
audit and the integrated replay are both retained.

Reproduce with local Git objects already present:

```sh
python audit_host_refs.py --repo /path/to/CrispCloud \
  --integrated-head 342b744a3cb66e3ee9387733ebcf8613cdb23a33 \
  --output host-integrated-audit-reproduced.json
```

## Host changes

Guarded sync adopts the combined canonical source, including the already
preserved Zotero optimizations, English hyphenation, proofing improvements and
ranked/average spreadsheet rules. It does not adopt the optional Harper
package into the host's managed boundary.

All six original embedded Office notices are now declared as production
assets and exposed through the existing Flutter license registry. The new
American English entry is explicitly labeled **LicenseRef-Kuiken-permissive**;
the British English entry is labeled **MIT**. Both assets contain the exact
pinned TeX source preambles. The canonical generator checks those bytes along
with the unchanged generated pattern data.

The existing two bundle tests now cover both English notices, their distinct
grants and exact source preambles. The existing sync regression also checks
their inclusion, excluded adjacent/wrong-package paths and refusal to
overwrite edited notices. These assertions do not increase the host or
Python test-case counts. The existing directory whitelist was sufficient;
its production boundary was not widened.

`packages/QUDS_FORKS.md` now identifies the final pin and 2,521-file inventory.
Earlier qualification totals keep their original source attribution.

## Source preservation and development checks

The final source and staged-index guard verified every managed path. All
**664 canonical-managed Git blob IDs match Quds**. The entire standalone
parser tree, all **14 unmanaged content differences**, the **six host-only
files**, and all **eight inherited executable modes** remain unchanged.
The prior strict diagnostic that also requires canonical executable modes
therefore remains false for the same inherited differences; no normalization
or weakened gate is claimed.

Before publication, the English source/notice generator check, all **nine
Office sync tests**, all **19 parser sync/verifier tests**, and whitespace
checks passed. The changed Dart files were formatted with the pinned runtime.
These development checks are not extra cases to add to a later complete host
qualification. Fresh Dart test and analyzer results belong to the separate
source-bound qualification receipt.

The independent, read-only harness linkage record verifies the four selected
test files and all six notice assets resolve to actual host files. It also
checks that `crisp_cloud`, the engine, editor, reports and parser libraries
resolve to the actual host source and that asset hashes match the managed
manifest. It executes no tests.

## Evidence identities

Direct Git push was unavailable in this environment, so the two local source
trees were published through the connected GitHub API. The
`publication-identity-map.json` record proves exact whole-tree equality
between each observed local checkpoint and its published counterpart.
Development receipts retain their original local commit identities; final
qualification uses the published implementation above. No source receipt is
silently reassigned to a different tree.

The complete audit, guard plans, preservation proof, development logs and
harness-linkage record are listed in `artifact-index.json` with SHA-256 hashes.
No GitHub Actions, workflow, job, artifact or CI-status query, wait or rerun
was used.
