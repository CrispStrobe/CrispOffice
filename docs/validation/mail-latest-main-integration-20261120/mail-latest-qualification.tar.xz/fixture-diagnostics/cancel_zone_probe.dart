import 'dart:async';
import 'dart:convert';
import 'package:fake_async/fake_async.dart';

Future<void> main() async {
  for (final controlled in [false, true]) {
    var cancelled = false;
    var completed = false;
    final async = FakeAsync();
    async.run((async) {
      final stream = controlled
          ? StreamController<List<int>>(
              onCancel: () async {
                cancelled = true;
              },
            ).stream
          : Stream<List<int>>.value([1]);
      Future<void> operation() async {
        await stream.listen(null).cancel();
      }
      operation().timeout(const Duration(seconds: 15)).then((_) {
        completed = true;
      });
      async.flushMicrotasks();
      print(jsonEncode({
        'controlled_cancel': controlled,
        'phase': 'fake_microtasks_only',
        'cancelled': cancelled,
        'completed': completed,
        'pending_timers': async.nonPeriodicTimerCount,
      }));
    });
    await Future<void>.delayed(Duration.zero);
    async.flushMicrotasks();
    print(jsonEncode({
      'controlled_cancel': controlled,
      'phase': 'after_real_microtask_turn',
      'cancelled': cancelled,
      'completed': completed,
      'pending_timers': async.nonPeriodicTimerCount,
    }));
  }
}
