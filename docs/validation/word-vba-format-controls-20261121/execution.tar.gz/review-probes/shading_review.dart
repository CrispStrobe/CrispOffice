import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;
const w = OfficeNamespaces.w;
WmlDocument fixture({bool alias = false}) {
  final package = OpcPackage.openBytes((DocxDocumentBuilder()..paragraph('Text')).build());
  final prefix = alias ? 'n' : 'w';
  package.getPart('/word/document.xml')!.writeText(
    '<$prefix:document xmlns:$prefix="$w" xmlns:x="urn:review">'
    '<$prefix:body><$prefix:p><$prefix:pPr ${alias ? 'xmlns:w="urn:review"' : ''}>'
    '${alias ? '<w:shd x:fill="foreign"/>' : ''}'
    '<$prefix:shd $prefix:val="clear" $prefix:fill="112233" x:token="keep"/>'
    '</$prefix:pPr><$prefix:r><$prefix:t>Text</$prefix:t></$prefix:r></$prefix:p>'
    '<$prefix:sectPr/></$prefix:body></$prefix:document>');
  package.getPart('/word/styles.xml')!.writeText(
    '<w:styles xmlns:w="$w"><w:style w:type="paragraph" w:default="1" w:styleId="Normal">'
    '<w:name w:val="Normal"/><w:pPr><w:shd w:val="clear" w:fill="112233"/>'
    '<w:spacing w:after="200"/></w:pPr></w:style></w:styles>');
  return WordDeserializer().read(package);
}
void shade(WmlDocument document, String color) => native.applyStep(document, {'op':'paragraphShading','paragraph':0,'color':color});
void style(WmlDocument document) => native.applyStep(document, {
  'op':'styleDefinition','style':'Normal','type':'paragraph','pPr':<String,Object?>{
    'shd':<String,Object?>{'val':'clear','fill':'FF0000'},
    'spacing':<String,Object?>{'after':'600'},
  }
});
void check(bool condition, String message) { if (!condition) throw StateError(message); }
void main() {
  final automatic = fixture();
  shade(automatic, 'auto');
  style(automatic);
  check(automatic.paragraphs.single.properties.shadingFill == null, 'refresh resurrected inherited fill');
  check(automatic.paragraphs.single.properties.spacingAfter == 30, 'refresh pinned inherited spacing');
  final reopened = WordDeserializer().readBytes(WordSerializer().writeBytes(automatic));
  check(reopened.paragraphs.single.properties.shadingFill == null, 'reopen resurrected inherited fill');
  check(reopened.paragraphs.single.properties.spacingAfter == 30, 'reopen pinned inherited spacing');
  final fixed = fixture();
  shade(fixed, '112233');
  style(fixed);
  check(fixed.paragraphs.single.properties.shadingFill == '112233', 'same value was not owned');
  check(fixed.paragraphs.single.properties.spacingAfter == 30, 'same-value shade pinned spacing');
  var aliases = fixture(alias: true);
  for (final color in ['ABCDEF','auto','010203']) {
    shade(aliases, color);
    final bytes = WordSerializer().writeBytes(aliases);
    final xml = XmlDocument.parse(OpcPackage.openBytes(bytes).getPart('/word/document.xml')!.readText());
    final ppr = xml.root!.firstChild('body',namespaceUri:w)!.firstChild('p',namespaceUri:w)!.firstChild('pPr',namespaceUri:w)!;
    final nativeShade = ppr.firstChild('shd',namespaceUri:w)!;
    final foreignShade = ppr.firstChild('shd',namespaceUri:'urn:review')!;
    check(nativeShade.getAttribute('fill',namespaceUri:w) == color, 'native fill incorrect');
    check(nativeShade.getAttribute('token',namespaceUri:'urn:review') == 'keep', 'foreign native-shade metadata lost');
    check(foreignShade.getAttribute('fill',namespaceUri:'urn:review') == 'foreign', 'foreign shade rebound');
    aliases = WordDeserializer().readBytes(bytes);
  }
  print(jsonEncode({'automaticStyleRefresh':true,'sameValueStyleRefresh':true,'sparseSpacingInheritance':true,'reboundPrefixRoundtrips':3}));
}
