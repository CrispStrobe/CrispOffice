import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/scratch/86ea302351d7')
repo = root / 'quds_office_suite'
engine = repo / 'packages/quds_office_engine'
out = root / 'validation-results'
build = root / 'toolchains/portable-build'
build.mkdir(exist_ok=True)
dart = root / 'toolchains/dart-sdk/bin/dart'
config = root / 'validation-workspace/.dart_tool/package_config.json'
env = os.environ.copy()
env.update(PUB_CACHE=str(root/'toolchains/pub-cache'), TMPDIR=str(root/'toolchains/tmp'), DART_SUPPRESS_ANALYTICS='true', CI='true')
entry = 'tool/macros/web_vba_office_layout_smoke.dart'
samples = {'WORD_TYPOGRAPHY_BAS_BASE64': 'example/macros/word_typography.bas', 'POWERPOINT_SLIDESHOW_BAS_BASE64': 'example/macros/powerpoint_slideshow.bas'}
defines = ['-D'+name+'='+base64.b64encode((engine/path).read_bytes()).decode() for name, path in samples.items()]
inputs = {path: hashlib.sha256((engine/path).read_bytes()).hexdigest() for path in [entry,*samples.values()]}
source = subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
tree = subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD^{tree}'],text=True).strip()
subprocess.run(['git','-C',str(repo),'diff','HEAD','--exit-code'],check=True)
js = build/'office-layout.js'
commands = [('vm',[str(dart),'--packages='+str(config),*defines,entry]),('compile-js',[str(dart),'compile','js','-O1','--packages='+str(config),*defines,entry,'-o',str(js)]),('javascript',['node','-e','globalThis.self = globalThis; require(process.argv[1])',str(js)])]
receipt = dict(commit=source,tree=tree,sample_inputs=inputs,node=subprocess.check_output(['node','--version'],text=True).strip(),stages=[])
for name,cmd in commands:
    start = time.time()
    with (out/('portable-'+name+'.stdout')).open('w') as stdout, (out/('portable-'+name+'.stderr')).open('w') as stderr:
        result = subprocess.run(cmd,cwd=engine,env=env,stdout=stdout,stderr=stderr)
    stage = dict(name=name,command=cmd,cwd=str(engine),exit_code=result.returncode,seconds=round(time.time()-start,3))
    receipt['stages'].append(stage)
    print(json.dumps({k:v for k,v in stage.items() if k not in ('command','cwd')}),flush=True)
    if result.returncode:
        print((out/('portable-'+name+'.stderr')).read_text(),flush=True)
        break
receipt['all_commands_passed'] = len(receipt['stages']) == 3 and all(s['exit_code'] == 0 for s in receipt['stages'])
receipt['vm_js_byte_equal'] = receipt['all_commands_passed'] and (out/'portable-vm.stdout').read_bytes() == (out/'portable-javascript.stdout').read_bytes()
receipt['tracked_sources_unchanged'] = subprocess.run(['git','-C',str(repo),'diff','HEAD','--exit-code'],stdout=subprocess.DEVNULL).returncode == 0
if receipt['vm_js_byte_equal']:
    receipt['canonical_output'] = json.loads((out/'portable-vm.stdout').read_text())
(out/'portable.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k != 'stages'},indent=2),flush=True)
raise SystemExit(0 if receipt['vm_js_byte_equal'] and receipt['tracked_sources_unchanged'] else 1)
