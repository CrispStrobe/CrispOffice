import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/86ea302351d7')
REPO = ROOT / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
OUT = ROOT / 'validation-results'
OUT.mkdir(exist_ok=True)

def hashes():
    paths = subprocess.check_output(['git', '-C', str(REPO), 'ls-files', 'packages/quds_office_engine/lib', 'packages/quds_office_engine/test', 'packages/quds_office_engine/tool', 'packages/quds_office_engine/example/macros', 'packages/quds_office_editor/fonts', 'packages/legacy_doc_parser/lib', 'packages/quds_office_engine/pubspec.yaml', 'packages/legacy_doc_parser/pubspec.yaml', 'pubspec.lock'], text=True).splitlines()
    return {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in paths if (REPO / p).is_file()}

parser = argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('tests', nargs='+')
args = parser.parse_args()
cmd = [str(ROOT / 'toolchains/dart-sdk/bin/dart'), '--packages=' + str(ROOT / 'validation-workspace/.dart_tool/package_config.json'), str(ROOT / 'toolchains/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'), '--compiler', 'source', '--concurrency=' + os.environ.get('VBA_TEST_CONCURRENCY', '1'), '--timeout=4x', '--reporter=json', *(['--fail-fast'] if os.environ.get('VBA_TEST_FAIL_FAST') == '1' else []), *args.tests]
env = os.environ.copy()
env.update(PUB_CACHE=str(ROOT / 'toolchains/pub-cache'), TMPDIR=str(ROOT / 'toolchains/tmp'), DART_SUPPRESS_ANALYTICS='true', CI='true')
before = hashes()
start = time.time()
head = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip()
with (OUT / (args.label + '.jsonl')).open('w') as stdout, (OUT / (args.label + '.stderr')).open('w') as stderr:
    result = subprocess.run(cmd, cwd=ENGINE, env=env, stdout=stdout, stderr=stderr)
events = []
for line in (OUT / (args.label + '.jsonl')).read_text().splitlines():
    try:
        events.append(json.loads(line))
    except ValueError:
        pass
test_names = {e['test']['id']: e['test']['name'] for e in events if e.get('type') == 'testStart'}
completed = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden')]
errors = [e for e in events if e.get('type') == 'error']
receipt = dict(command=cmd, cwd=str(ENGINE), commit=head, exit_code=result.returncode, duration_seconds=round(time.time()-start, 3), source_unchanged=before == hashes(), passed=sum(e.get('result') == 'success' and not e.get('skipped') for e in completed), failed=sum(e.get('result') in ('failure', 'error') for e in completed), skipped=sum(bool(e.get('skipped')) for e in completed), errors=[dict(test=test_names.get(e.get('testID')), error=e.get('error'), stackTrace=e.get('stackTrace')) for e in errors], runner_done=[e for e in events if e.get('type') == 'done'], source_hashes=before)
(OUT / (args.label + '.receipt.json')).write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k != 'source_hashes'}, indent=2), flush=True)
raise SystemExit(result.returncode)
