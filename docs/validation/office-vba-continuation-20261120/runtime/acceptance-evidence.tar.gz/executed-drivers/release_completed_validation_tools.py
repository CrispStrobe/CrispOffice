from pathlib import Path
import json
import shutil
import time

root = Path('/workspace/scratch/86ea302351d7')
source = '08020076b1552fef214d7625ace7ae087b70be88'
out = root / 'validation-results'
for attempt in range(1200):
    if (out / 'acceptance.receipt.json').exists():
        break
    try:
        analysis = json.loads((out/'final-analyze.receipt.json').read_text())
        portable = json.loads((out/'portable.receipt.json').read_text())
    except (OSError, ValueError):
        time.sleep(1)
        continue
    finished = analysis.get('commit') == source and analysis.get('exit_code') == 0 and portable.get('commit') == source and portable.get('vm_js_byte_equal') is True
    if finished and shutil.disk_usage(root).free < 64 * 1024 * 1024:
        removed = []
        # Only tools for already-completed stages, never the VM/kernel runtime
        # used by the still-running source-mode tests or any repository file.
        for name in ['analysis_server_aot.dart.snapshot','dart2js_aot.dart.snapshot']:
            path = root/'toolchains/dart-sdk/bin/snapshots'/name
            if path.is_file():
                size = path.stat().st_size
                path.unlink()
                removed.append(dict(path=str(path),bytes=size))
        build = root/'toolchains/portable-build'
        if build.is_dir():
            size = sum(p.stat().st_size for p in build.rglob('*') if p.is_file())
            shutil.rmtree(build)
            removed.append(dict(path=str(build),bytes=size))
        record = dict(source=source,reason='Release reproducible completed-stage SDK/build artifacts when shared filesystem free space falls below 64 MiB',removed=removed,free_bytes_after=shutil.disk_usage(root).free)
        (out/'capacity-release.json').write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps(record),flush=True)
        break
    time.sleep(1)
