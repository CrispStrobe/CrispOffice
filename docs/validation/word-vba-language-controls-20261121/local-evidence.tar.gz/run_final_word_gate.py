import hashlib, json, pathlib, subprocess, sys, time
root=pathlib.Path('/workspace/scratch/7839f72e56c1')
repo=root/'quds_office_suite'
engine=repo/'packages/quds_office_engine'
out=root/'.runtime/final-word-gate'
out.mkdir(parents=True,exist_ok=True)
selected={str(p.relative_to(engine)) for p in (engine/'test').glob('office_*test.dart') if 'vba' in p.name or 'macro' in p.name}
selected.update('test/'+name for name in [
 'word_comment_proofing_styles_test.dart','word_proofing_inheritance_test.dart',
 'word_proofing_language_test.dart','word_steps_vocabulary_test.dart',
 'word_style_introduction_test.dart','word_styles_layout_test.dart',
 'odt_document_reader_test.dart','odt_reader_styles_test.dart','odt_reader_table_preservation_test.dart',
 'odt_open_test.dart','odt_reader_guards_test.dart','office_isolate_open_test.dart',
 'odt_vba_language_roundtrip_test.dart',
 'odf_zotero_reference_marks_test.dart','odf_zotero_ownership_test.dart','odf_zotero_preferences_test.dart',
 'odf_zotero_resource_test.dart','odf_export_text_fidelity_test.dart',
 'word_zotero_document_data_test.dart','word_zotero_transfer_test.dart'])
selected=sorted(selected)
missing=[p for p in selected if not (engine/p).is_file()]
if missing:raise SystemExit('Missing selected tests: '+str(missing))
paths=set(engine/'lib'/p.relative_to(engine/'lib') for p in (engine/'lib').rglob('*.dart'))
paths.update(engine/p for p in selected)
paths.update((engine/'tool/macros').glob('*.dart'))
paths.update((engine/'example/macros').glob('*.bas'))
paths.update([engine/'pubspec.yaml',repo/'pubspec.yaml',repo/'pubspec.lock',repo/'.fvmrc'])
paths.update((repo/'packages/legacy_doc_parser/lib').rglob('*.dart'))
paths.update([repo/'packages/legacy_doc_parser/pubspec.yaml'])
fixture_root=root/'.runtime/engine_workspace/packages/quds_office_editor/fonts'
fixture_paths=sorted(p for p in fixture_root.iterdir() if p.is_file())
def fingerprint():
 result={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
 result.update({'externalFixture/quds_office_editor/fonts/'+p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in fixture_paths})
 return result
before=fingerprint()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
cmd=[str(root/'.runtime/test-engine'),*selected,'--concurrency=4','--reporter=json']
(out/'command.json').write_text(json.dumps({'gitHead':head,'command':cmd,'testFiles':selected,'sourceFiles':len(before)},indent=2)+'\n')
print(json.dumps({'event':'started','head':head,'testFiles':len(selected),'sourceFiles':len(before)}),flush=True)
started=time.time()
with (out/'tests.jsonl').open('w') as log, (out/'stderr.log').open('w') as err:
 result=subprocess.run(cmd,stdout=log,stderr=err)
after=fingerprint()
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
rows=[]
for line in (out/'tests.jsonl').read_text().splitlines():
 try:rows.append(json.loads(line))
 except ValueError:pass
done=[r for r in rows if r.get('type')=='testDone' and not r.get('hidden')]
errors=[r for r in rows if r.get('type')=='error']
summary={'gitHead':head,'exitCode':result.returncode,'elapsedSeconds':round(time.time()-started,3),'testFiles':len(selected),'passed':sum(r.get('result')=='success' and not r.get('skipped') for r in done),'failed':sum(r.get('result')!='success' for r in done),'skipped':sum(bool(r.get('skipped')) for r in done),'errorEvents':len(errors),'success':result.returncode==0 and before==after and all(r.get('result')=='success' for r in done),'sourceUnchanged':before==after,'changedSource':[p for p in before if before.get(p)!=after.get(p)],'runnerDone':[r for r in rows if r.get('type')=='done']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
if errors:print(json.dumps([{'testID':r.get('testID'),'error':r.get('error','')[:1200]} for r in errors]),flush=True)
sys.exit(0 if summary['success'] else 1)
