import gzip
import hashlib
import io
import json
import pathlib
import subprocess
import tarfile

ROOT = pathlib.Path('/workspace/scratch/7839f72e56c1')
REPO = ROOT / 'quds_office_suite'
RUNTIME = ROOT / '.runtime'
DEST = REPO / 'docs/validation/word-vba-language-controls-20261121'
DEST.mkdir(parents=True, exist_ok=True)

files = set()
root_names = [
    'runtime-provenance.json', 'fixture-provenance.json', 'pub-get-enforced.log', 'pub-get-subset.log',
    'smoke-word-language.jsonl', 'smoke-analyze.log',
    'language-compiler-initial.jsonl', 'language-compiler-corrected.jsonl',
    'language-source-integration.jsonl', 'language-integration-corrected.jsonl',
    'language-root-analyze.log', 'native-language-analyze.log',
    'native-language-final-tests.log', 'native-language-preservation-failed-tests.log',
    'native-language-regressions.log', 'native-language-tests.log',
    'run_final_word_gate.py', 'qualify_word_language_final.py',
    'assemble_word_evidence.py', 'odt_table_preservation.patch',
    'env.sh', 'run-dart', 'test-engine',
]
for name in root_names:
    path = RUNTIME / name
    if not path.is_file():
        raise SystemExit(f'Missing evidence: {path}')
    files.add(path)

directories = [
    'engine_workspace', 'mail_workspace', 'odt_workspace',
    'word-language-portability', 'word-language-portability-final',
    'word-language-portability-accepted', 'final-word-gate', 'final-word-gate-initial',
    'final-word-static', 'odt-frontier-qualification',
]
accepted = {'.json', '.jsonl', '.log', '.stdout', '.stderr', '.txt', '.md', '.py', '.patch', '.lock', '.yaml'}
for name in directories:
    directory = RUNTIME / name
    if not directory.is_dir():
        raise SystemExit(f'Missing evidence directory: {directory}')
    files.update(p for p in directory.iterdir() if p.is_file() and p.suffix in accepted)

# Include the actual accepted executable and its exact Node harness assembly.
for name in ['word-language-example.js', 'word-language-example.node.js']:
    path = RUNTIME / 'word-language-portability-accepted' / name
    if not path.is_file():
        raise SystemExit(f'Missing accepted portable artifact: {path}')
    files.add(path)

members = {}
archive = DEST / 'local-evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path in sorted(files):
                data = path.read_bytes()
                name = str(path.relative_to(RUNTIME))
                members[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))

with tarfile.open(archive, 'r:gz') as tar:
    extracted = {}
    for member in tar.getmembers():
        data = tar.extractfile(member).read()
        extracted[member.name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
if extracted != members:
    raise SystemExit('Archive round-trip mismatch')

manifest = {
    'qualifiedSourceCheckpoint': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    'archive': archive.name,
    'archiveBytes': archive.stat().st_size,
    'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'memberCount': len(members),
    'roundTripVerified': True,
    'members': members,
    'note': 'Earlier failed/interrupted attempts are retained separately. Use final-word-gate, final-word-static and word-language-portability-accepted for final acceptance; README explains other scopes.',
}
(DEST / 'evidence-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({key: value for key, value in manifest.items() if key != 'members'}, indent=2))
