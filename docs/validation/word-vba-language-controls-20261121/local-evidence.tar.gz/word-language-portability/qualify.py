import base64
import concurrent.futures
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/7839f72e56c1')
REPO = ROOT / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
RUNTIME = ROOT / '.runtime'
OUT = RUNTIME / 'word-language-portability'
CWD = RUNTIME / 'engine_workspace/packages/quds_office_engine'
OUT.mkdir(exist_ok=True)

def hashes():
    paths = [*ENGINE.joinpath('lib').rglob('*.dart'),
             *REPO.joinpath('packages/legacy_doc_parser/lib').rglob('*.dart'),
             ENGINE / 'example/macros/word_language_controls.bas',
             ENGINE / 'tool/macros/web_vba_word_language_controls_smoke.dart',
             ENGINE / 'test/office_vba_word_language_controls_test.dart']
    return {str(path.relative_to(REPO)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(paths)}

before = hashes()
(OUT / 'source-hashes-before.json').write_text(json.dumps(before, indent=2) + '\n')
source = (ENGINE / 'example/macros/word_language_controls.bas').read_bytes()
define = '-DWORD_LANGUAGE_CONTROLS_BAS_BASE64=' + base64.b64encode(source).decode('ascii')
runner = 'tool/macros/web_vba_word_language_controls_smoke.dart'
commands = {
    'vm': [str(RUNTIME / 'run-dart'), 'run', define, runner],
    'compile_js': [str(RUNTIME / 'run-dart'), 'compile', 'js', '--server-mode', '-O2',
                   define, runner, '-o', str(OUT / 'word-language-example.js')],
    'node': [shutil.which('node'), str(OUT / 'word-language-example.js')],
    'node_tests': [str(RUNTIME / 'test-engine'),
                   'test/office_vba_word_language_controls_test.dart',
                   '--platform=node', '--reporter=expanded', '--no-color',
                   '--file-reporter=json:' + str(OUT / 'node-compiler-tests.jsonl')],
}
(OUT / 'commands.json').write_text(json.dumps({'cwd':str(CWD), 'commands':commands}, indent=2)+'\n')

def run(name, command):
    start = time.monotonic()
    with (OUT / (name + '.stdout')).open('wb') as stdout, (OUT / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(command, cwd=CWD, stdout=stdout, stderr=stderr)
    status = {'exitCode': result.returncode, 'elapsedSeconds': round(time.monotonic()-start, 3)}
    print(name, json.dumps(status), flush=True)
    return status

statuses = {}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    jobs = {name: pool.submit(run, name, commands[name]) for name in ('vm', 'compile_js', 'node_tests')}
    for name, job in jobs.items():
        statuses[name] = job.result()
    if statuses['compile_js']['exitCode'] == 0:
        statuses['node'] = run('node', commands['node'])

after = hashes()
(OUT / 'source-hashes-after.json').write_text(json.dumps(after, indent=2)+'\n')
changed = [name for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)]
report = {'statuses': statuses, 'sourceFiles':len(before), 'changedSourceFiles':changed,
          'exampleSha256':hashlib.sha256(source).hexdigest(),
          'sourceManifestBeforeSha256':hashlib.sha256((OUT / 'source-hashes-before.json').read_bytes()).hexdigest(),
          'sourceManifestAfterSha256':hashlib.sha256((OUT / 'source-hashes-after.json').read_bytes()).hexdigest()}
if statuses.get('vm',{}).get('exitCode') == 0 and statuses.get('node',{}).get('exitCode') == 0:
    vm = json.loads((OUT / 'vm.stdout').read_text())
    js = json.loads((OUT / 'node.stdout').read_text())
    canonical = lambda value: (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))+'\n').encode('utf-8')
    vm_bytes, js_bytes = canonical(vm), canonical(js)
    (OUT / 'vm-receipt.canonical.json').write_bytes(vm_bytes)
    (OUT / 'node-receipt.canonical.json').write_bytes(js_bytes)
    report.update({'canonicalReceiptsIdentical':vm_bytes == js_bytes,
                   'vmReceiptSha256':hashlib.sha256(vm_bytes).hexdigest(),
                   'nodeReceiptSha256':hashlib.sha256(js_bytes).hexdigest(),
                   'rawReceiptsIdentical':(OUT/'vm.stdout').read_bytes() == (OUT/'node.stdout').read_bytes()})
(OUT / 'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report), flush=True)
if changed or any(s['exitCode'] for s in statuses.values()) or not report.get('canonicalReceiptsIdentical'):
    raise SystemExit(1)
