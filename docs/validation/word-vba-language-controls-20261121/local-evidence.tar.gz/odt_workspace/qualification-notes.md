# Captured native ODT reader qualification

Incoming source: `3b1625e58a50438d10652032ab8dc5cecc098e34`.

The six incoming package files were overlaid from exact Git blobs onto a frozen
copy of the then-current engine/parser source. Existing export/model files
matched the incoming branch base before overlay. Complete before/overlay and
final source hashes are retained. No source changed during the corrected gate.
The source copy includes the ongoing Word language-control work and is not
represented as a clean committed whole-tree snapshot.

## Review corrections

- Explicit table width was accepted without parsing or applying it; even an
  invalid length succeeded. The bounded correction requires a positive absolute
  width matching the supported fixed column grid within 0.00001 point. Distinct
  or malformed widths refuse import before publication.
- A descendant table style with no alignment reset inherited center alignment;
  a descendant row style with no keep-together reset its inherited setting.
  Both now retain inheritance and apply explicit values only.
- An explicit transparent cell background incorrectly retained the ancestor's
  red background. Transparency now clears it; omitted backgrounds still inherit.
- Nested used table-property content, duplicate property elements and unknown
  used structural-style attributes were ignored. They now refuse import.
  Validation is scoped to used style chains; an opaque unused style still imports.

The patch changes only the native ODT reader plus one new regression file.
The tests check DOCX save/reopen, exact acceptance/refusal boundaries, inherited
and explicit clearing behavior, and unused-style acceptance.

## Executed evidence

- Original incoming cohort: 360 passed, zero failed/skipped.
- First preservation regressions before the correction: 20 cases, 17 failed
  and 3 passed. These are retained as diagnostic evidence, not called green.
- Corrected focused suite: 21 passed, including unused-style acceptance.
- Corrected complete selected cohort: 381 passed across 10 files, zero
  failures/skips. Raw JSON and exact commands are retained.
- Targeted analysis is clean. Official Dart 3.13.7; 56 hosted packages match
  the repository lock versions and hashes exactly, with offline enforced-lock
  resolution. All execution uses the frozen scratch copy.

Ready to integrate the captured snapshot together with the correction patch as
this bounded headless native ODT reader/API slice, subject to the root's final
combined-source gate. This does not qualify an installed Office/LibreOffice/
Zotero host or claim the pending editor-loader integration has been delivered.
