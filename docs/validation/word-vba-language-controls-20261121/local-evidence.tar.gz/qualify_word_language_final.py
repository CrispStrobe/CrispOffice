import base64
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/7839f72e56c1')
REPO = ROOT / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
RUNTIME = ROOT / '.runtime'
OUT = RUNTIME / (sys.argv[1] if len(sys.argv) > 1 else 'word-language-portability-final')
PRIOR = RUNTIME / 'word-language-portability'
CWD = RUNTIME / 'engine_workspace/packages/quds_office_engine'
NODE = '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
PREAMBLE = RUNTIME / 'pub-cache/hosted/pub.dev/node_preamble-2.0.2/lib/preamble.min.js'
OUT.mkdir(exist_ok=False)

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def hashes():
    paths = [*ENGINE.joinpath('lib').rglob('*.dart'),
             *REPO.joinpath('packages/legacy_doc_parser/lib').rglob('*.dart'),
             ENGINE / 'example/macros/word_language_controls.bas',
             ENGINE / 'tool/macros/web_vba_word_language_controls_smoke.dart',
             ENGINE / 'test/office_vba_word_language_controls_test.dart']
    return {str(path.relative_to(REPO)): sha256(path.read_bytes())
            for path in sorted(paths)}

def save_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

before = hashes()
save_json(OUT / 'source-hashes-before.json', before)
source = (ENGINE / 'example/macros/word_language_controls.bas').read_bytes()
define = '-DWORD_LANGUAGE_CONTROLS_BAS_BASE64=' + base64.b64encode(source).decode('ascii')
runner = 'tool/macros/web_vba_word_language_controls_smoke.dart'
commands = {
    'vm': [str(RUNTIME / 'run-dart'), 'run', define, runner],
    'compile_js': [str(RUNTIME / 'run-dart'), 'compile', 'js', '--server-mode', '-O2',
                   define, runner, '-o', str(OUT / 'word-language-example.js')],
    'node': [NODE, str(OUT / 'word-language-example.node.js')],
}
save_json(OUT / 'commands.json', {
    'cwd': str(CWD), 'commands': commands,
    'nodePreamble': {
        'path': str(PREAMBLE), 'package': 'node_preamble', 'version': '2.0.2',
        'sha256': sha256(PREAMBLE.read_bytes()),
        'assembly': 'exact preamble bytes concatenated with exact compiled JS bytes',
        'provenance': 'Installed package:test 1.31.1 uses this exact minified preamble in its Node runner.'}})

def run(name):
    start = time.monotonic()
    with (OUT / (name + '.stdout')).open('wb') as stdout, (OUT / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(commands[name], cwd=CWD, stdout=stdout, stderr=stderr)
    status = {'exitCode': result.returncode, 'elapsedSeconds': round(time.monotonic()-start, 3)}
    save_json(OUT / (name + '.status.json'), status)
    print(name, json.dumps(status), flush=True)
    return status

statuses = {}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    jobs = {name: pool.submit(run, name) for name in ('vm', 'compile_js')}
    for name, job in jobs.items():
        statuses[name] = job.result()
if statuses['compile_js']['exitCode'] == 0:
    (OUT / 'word-language-example.node.js').write_bytes(PREAMBLE.read_bytes() + (OUT / 'word-language-example.js').read_bytes())
    statuses['node'] = run('node')

after = hashes()
save_json(OUT / 'source-hashes-after.json', after)
changed = [name for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)]
prior = json.loads((PRIOR / 'source-hashes-before.json').read_text())
compiler_inputs = [name for name in before if '/src/automation/' in name or name.endswith('/office_vba_word_language_controls_test.dart')]
compiler_changed = [name for name in compiler_inputs if prior.get(name) != before.get(name)]
events = [json.loads(line) for line in (PRIOR / 'node-compiler-tests.jsonl').read_text().splitlines()]
tests = [event for event in events if event.get('type') == 'testDone' and not event.get('hidden')]
done = [event for event in events if event.get('type') == 'done']
report = {
    'statuses': statuses, 'sourceFiles': len(before), 'changedSourceFiles': changed,
    'exampleSha256': sha256(source),
    'sourceManifestBeforeSha256': sha256((OUT / 'source-hashes-before.json').read_bytes()),
    'sourceManifestAfterSha256': sha256((OUT / 'source-hashes-after.json').read_bytes()),
    'dartVersion': subprocess.check_output([str(RUNTIME / 'run-dart'), '--version'], text=True).strip(),
    'nodeVersion': subprocess.check_output([NODE, '--version'], text=True).strip(),
    'nodeCompilerTests': {
        'priorEvidence': str(PRIOR / 'node-compiler-tests.jsonl'),
        'priorEvidenceSha256': sha256((PRIOR / 'node-compiler-tests.jsonl').read_bytes()),
        'visibleCompleted': len(tests),
        'succeeded': sum(event.get('result') == 'success' for event in tests),
        'doneEvents': done,
        'compilerAndTestSourceCount': len(compiler_inputs),
        'changedCompilerAndTestSourcesSinceNodeTest': compiler_changed,
    },
}
if all(status['exitCode'] == 0 for status in statuses.values()) and 'node' in statuses:
    vm = json.loads((OUT / 'vm.stdout').read_text())
    js = json.loads((OUT / 'node.stdout').read_text())
    canonical = lambda value: (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))+'\n').encode('utf-8')
    vm_bytes, js_bytes = canonical(vm), canonical(js)
    (OUT / 'vm-receipt.canonical.json').write_bytes(vm_bytes)
    (OUT / 'node-receipt.canonical.json').write_bytes(js_bytes)
    report.update({
        'canonicalReceiptsIdentical': vm_bytes == js_bytes,
        'rawReceiptsIdentical': (OUT/'vm.stdout').read_bytes() == (OUT/'node.stdout').read_bytes(),
        'vmReceiptSha256': sha256(vm_bytes), 'nodeReceiptSha256': sha256(js_bytes),
        'receipt': vm,
    })
save_json(OUT / 'qualification.json', report)
print(json.dumps({k: v for k, v in report.items() if k != 'receipt'}, ensure_ascii=False), flush=True)
if changed or compiler_changed or any(status['exitCode'] for status in statuses.values()) or not report.get('canonicalReceiptsIdentical') or len(tests) != 110 or not done[-1].get('success'):
    raise SystemExit(1)
