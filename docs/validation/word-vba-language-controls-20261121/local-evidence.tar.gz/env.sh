export PUB_CACHE=/workspace/scratch/7839f72e56c1/.runtime/pub-cache
export TMPDIR=/workspace/scratch/7839f72e56c1/.runtime/tmp
export DART_SUPPRESS_ANALYTICS=true
export PATH=/workspace/scratch/7839f72e56c1/.runtime/dart-sdk/bin:$PATH
