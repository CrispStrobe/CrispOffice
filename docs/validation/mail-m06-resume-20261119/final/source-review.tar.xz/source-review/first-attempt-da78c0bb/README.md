# First frozen source continuity: da78c0bb

Published commit `da78c0bb7bd9e119cc6697a5a476be3b388514c4`, tree `dc941cf5f80fff50a637b214aec96d51987518e9`, was independently read back through the immutable GitHub commit API. This report records source identity for the **first qualification attempt**. Root reported test-only strict-analysis issues in the store gate; this report does not claim final qualification passed. A repaired source will receive a separate report. No Dart/Flutter execution, fresh ref advertisement, or Actions query was performed here.

## Transport review binding

All **37 reviewed paths** match the published commit's Git blob, SHA-256 and byte length. Reviewed author commit: `cdcfe878f01263f52c935d9ae0a90e6113a07e3f`. Review manifest SHA-256: `5dc61c9d20bf2227236b489799b77c2765a24b04e8e7d6f8625e7186a0ebff48`. Exact results are in `transport-review-binding.json`.

## Office and other source continuity

The comparison baseline is the recorded successful Office gate's commit `479e1e038af0467b7f07b35d80bac9e4cc60a198`. Every selected Git entry is identical, including path, mode and object identity. The stronger non-excepted package/app selection also preserves existing Mail MIME/UI packages and their tests. All **4673** materialized selected files still match their SHA-256 values in the saved baseline input manifest.

| Exact selection name | Entries | Equal baseline/published canonical Git-manifest SHA-256 |
|---|---:|---|
| office_packages | 2486 | `97629101367464aebae3157e9531c0579ee32202275d7180b7dc28e368b0ad87` |
| non_mail_packages | 4496 | `ddbc9805f6ea76f0a6d1d2625355c82cdcea7f5ee601d80dcb589d30f2cab13e` |
| all_apps | 136 | `f447230e31aa2622e0975edf4ac787c5f839d9da7764b1a3ae6f6b8eb0bc6d45` |
| non_mail_packages_and_all_apps | 4632 | `7a68bca825c09484ef1944559744d8acc1df739373b1ef0f65eb5ac02ceb03cf` |
| all_non_excepted_packages_and_apps | 4673 | `0c11b125be06cf5f37e8496a786fa875377dbde6a2bd2f6204d8b48785e95d6e` |
| non_enough_mail_third_party | 0 | `4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945` |
| root_dependency_lock | 1 | `8957553ac205c541b63d56d08d42c991c5810c0e98c7fe27725e497a7aa573ee` |

Selection predicates and deterministic digest encoding are recorded in `source-continuity.json`; complete selected entries are in `protected-git-inputs.json`, with baseline/current file hashes in `protected-materialized-inputs.json`. The five previously protected Office blobs also match.

The root dependency lock `pubspec.lock` is byte-identical. SHA-256: `35d1ef372908f4ab278973355ec6a957cd3240bea115d615056c5b9e398df974`. This also matches the tested baseline gate's recorded workspace-lock hash.

## Declared source exceptions

| Exception | Changed paths | Reason |
|---|---:|---|
| durable_mail_flags | 13 | Scoped flags model and SQLite migration/repository implementation and tests; covered by the separate Mail core/store gate. |
| new_mail_transport | 21 | New M06 native transport package, documented limits, protocol/TLS tests and fixtures; covered by native/Node gates. |
| enough_mail_fork | 11 | Reviewed raw FETCH/parser/resource/lifecycle and TLS ownership changes; affected inherited protocol/MIME suites are included in the native/Node plans. |
| root_workspace_membership | 1 | Only adds packages/quds_mail_transport to the workspace member list; dependency lock is byte-identical. |

All changes within packages/, apps/, third_party/, pubspec.yaml and pubspec.lock fall within these explicit exceptions. `pubspec.yaml` changes only by adding the new transport workspace member. Exact before/after object identities are in `declared-source-exceptions.json`. Validation evidence/runners, Mail launcher tooling and other repository documentation are outside this product-source continuity comparison and have their own validation records.

## Actual failed gate retained

The actual FAIL execution and Mail receipt, core/store analysis diagnostics, and store test JSONL are copied in `failed-gate-evidence/`. `failed-gate-summary.json` records their hashes and the three failing checks. This first attempt is preserved separately from the repaired e734e3bd run.
