# Second frozen source attempt: e734e3bd

Published commit `e734e3bd14f6c802a1da1c05969bd51108890ded`, tree `23156965b7d6da2dc41326686d2ac4f5771972ee`, was independently read back through the immutable GitHub commit API. The exact parent is `da78c0bb7bd9e119cc6697a5a476be3b388514c4`. Source binding and static review are complete; this second qualification attempt failed during the process-timeout regression preflight. This report makes no passing acceptance claim. No Dart/Flutter execution, fresh ref advertisement, or Actions query was performed by this reviewer.

## Two reviewed test repairs

The entire commit delta contains only `packages/quds_mail_core/test/models_test.dart` and `packages/quds_mail_store/test/migration_test.dart`. The flags test now constructs a separate equal value and checks nonidentity, equality, matching hash codes, and set deduplication. This removes the duplicate-constant lint and strengthens the check against accidental constant canonicalization. The migration test hides Drift's `isNull` import; all four remaining uses are matcher assertions. No production, transport, TLS, schema, or migration implementation changed.

The exact patch and static findings are retained in `test-repair.patch` and `test-repair-review.json`. Targeted strict-analysis/formatting receipts report exit 0 and are copied in `test-repair-evidence/`. Full qualification remains separate.

## Reviewed-source binding

**35 of the original 37 author-reviewed paths are unchanged.** The two changed test paths received the explicit follow-up review above. All **37 effective reviewed paths** match this published commit's Git blob, SHA-256, and length. The effective manifest SHA-256 is `959c3707950810262181e795fe8e2be65e4dd8cef0f93ed17f4fbfa6f0fe2b93`; the original author manifest remains `5dc61c9d20bf2227236b489799b77c2765a24b04e8e7d6f8625e7186a0ebff48`. The two identities are deliberately recorded separately in `transport-review-binding.json`.

## Office and dependency continuity

The same source selections remain byte-identical to tested baseline `479e1e038af0467b7f07b35d80bac9e4cc60a198`: **4,496 non-Mail package entries**, **136 app entries**, or **4,632 combined**. The stronger selection additionally includes the unchanged existing Mail MIME/UI packages, totaling **4,673 entries**. All 4,673 materialized files match their SHA-256 values in the saved baseline input manifest. This includes **2,486 Office-package entries** and the five protected Office files.

The combined non-Mail package/app Git-manifest digest is `7a68bca825c09484ef1944559744d8acc1df739373b1ef0f65eb5ac02ceb03cf`. The stronger 4,673-entry selection digest is `0c11b125be06cf5f37e8496a786fa875377dbde6a2bd2f6204d8b48785e95d6e`. Exact selection predicates, counts, encoding and complete manifests are preserved in `source-continuity.json` and its referenced files.

The dependency lock remains byte-identical, SHA-256 `35d1ef372908f4ab278973355ec6a957cd3240bea115d615056c5b9e398df974`. The only root workspace manifest change since baseline is adding the new transport package. Native/Node plans and both root workspace files are unchanged by this test repair; their exact identities are in `workspace-and-plan-binding.json`. All 46 changed product-scope paths since baseline belong to explicitly declared Mail core/store, new transport, enough_mail fork, or workspace-membership exceptions.

## First-attempt failure retained

`../first-attempt-da78c0bb/` preserves the original source-continuity report and actual FAIL receipts. Its core analysis failed the duplicate-element lint; store analysis and migration-test compilation failed the ambiguous `isNull` import. Those records are not presented as passing evidence and are not replaced by the repaired run.

## Actual second-attempt failure retained

`failed-gate-summary.json` and `failed-gate-evidence/` preserve the Mail FAIL receipt and the ProcessLookupError diagnostic from the timeout regression. The test saw the child disappear during /proc stat read. The original two Dart test repairs remain valid, but this attempt did not pass preflight.
