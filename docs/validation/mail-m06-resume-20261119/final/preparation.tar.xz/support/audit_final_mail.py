#!/usr/bin/env python3
"""Read-only independent audit of the three final Mail evidence directories.

No Dart/build/dependency/GitHub operation is executed. Source content is checked
against the recorded Git commit; runtime content against the surviving files.
The only optional write is --output, outside all input trees.

Example:
  python3 verification/audit_final_mail.py --expected-source FULL_SHA \
      --output verification/final-evidence-audit.json
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys

sys.dont_write_bytecode = True
SHA256 = re.compile(r"[0-9a-f]{64}\Z")
SHA1 = re.compile(r"[0-9a-f]{40}\Z")
GATE = "docs/validation/document-review-notes-20261118/run_checks.py"
PARSERS = (GATE, "tools/mail/check_store.py", "tools/mail/check_reader.py")
SNAPSHOTS = ("source-before.json", "source-after.json",
             "environment-before.json", "environment-after.json")
MAIL_CHECKS = ("runtime", "runner-regressions", "locked-resolution",
               "core-analysis", "store-analysis", "format", "core-vm",
               "core-node", "store-vm", "portable-node", "browser-entry",
               "browser-worker", "whitespace")


class AuditError(Exception):
    pass


def require(condition, message):
    if not condition:
        raise AuditError(message)


def relative_name(value):
    require(isinstance(value, str) and bool(value), "Missing relative path")
    path = PurePosixPath(value)
    require(not path.is_absolute() and ".." not in path.parts
            and path.as_posix() == value, "Unsafe/noncanonical path: " + value)
    return value


def json_bytes(data):
    def no_duplicates(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result
    return json.loads(data, object_pairs_hook=no_duplicates)


class GitSource:
    """Stream Git blobs, checking their Git identity and SHA-256 content hash."""

    def __init__(self, repo, commit):
        self.repo, self.commit = repo, commit
        require(isinstance(commit, str) and SHA1.fullmatch(commit),
                "Source commit must be a full SHA-1")
        require(self.git("rev-parse", "--verify", commit + "^{commit}").decode().strip() == commit,
                "Source commit is unavailable")
        self.tree = self.git("rev-parse", commit + "^{tree}").decode().strip()
        self.entries = {}
        for row in self.git("ls-tree", "-r", "-z", "--full-tree", commit).split(b"\0"):
            if row:
                meta, name = row.split(b"\t", 1)
                mode, kind, blob = meta.decode().split()
                self.entries[name.decode()] = {"mode": mode, "kind": kind, "git_blob": blob}
        self.process = subprocess.Popen(
            ["git", "-C", str(repo), "cat-file", "--batch"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.hashes = {}

    def git(self, *args):
        return subprocess.check_output(["git", "-C", str(self.repo), *args],
                                       stderr=subprocess.PIPE)

    def blob_hash(self, name):
        relative_name(name)
        require(name in self.entries, "Input absent from source commit: " + name)
        entry = self.entries[name]
        require(entry["kind"] == "blob" and entry["mode"] in {"100644", "100755"},
                "Source input is not an ordinary Git file: " + name)
        blob = entry["git_blob"]
        if blob not in self.hashes:
            self.process.stdin.write((blob + "\n").encode())
            self.process.stdin.flush()
            header = self.process.stdout.readline().decode().strip().split()
            require(len(header) == 3 and header[:2] == [blob, "blob"],
                    "Cannot read Git blob: " + blob)
            size = int(header[2])
            sha1 = hashlib.sha1(f"blob {size}\0".encode())
            sha256 = hashlib.sha256()
            remaining = size
            while remaining:
                chunk = self.process.stdout.read(min(remaining, 1024 * 1024))
                require(chunk, "Truncated Git blob: " + blob)
                remaining -= len(chunk)
                sha1.update(chunk)
                sha256.update(chunk)
            require(self.process.stdout.read(1) == b"\n", "Invalid Git batch delimiter")
            require(sha1.hexdigest() == blob, "Git object identity mismatch: " + blob)
            self.hashes[blob] = sha256.hexdigest()
        return self.hashes[blob]

    def read(self, name):
        self.blob_hash(name)
        return self.git("cat-file", "blob", self.entries[name]["git_blob"])

    def close(self):
        self.process.stdin.close()
        self.process.wait(timeout=15)
        self.process.stdout.close()
        self.process.stderr.close()


class Audit:
    def __init__(self, repo, runtime):
        self.repo, self.runtime = repo, runtime
        self.failures, self.cases = [], []
        self.check_count = 0
        self.artifacts, self.file_cache, self.cohorts, self.manifests = {}, {}, {}, {}
        self.source = self.gate = self.store = None

    def check(self, condition, message):
        self.check_count += 1
        if not condition:
            self.failures.append(message)
        return bool(condition)

    def equal(self, actual, expected, message):
        return self.check(type(actual) is type(expected) and actual == expected, message)

    def section(self, name, action):
        try:
            return action()
        except Exception as error:
            self.failures.append(f"{name}: {type(error).__name__}: {error}")
            return None

    def file_hash(self, path):
        require(path.is_file(), "Missing/non-file input: " + str(path))
        before = path.stat()
        identity = (str(path), before.st_dev, before.st_ino, before.st_size,
                    before.st_mtime_ns, before.st_ctime_ns)
        if identity not in self.file_cache:
            with path.open("rb") as stream:
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
            # Reading may update atime, so compare the identity fields only.
            after = path.stat()
            require(identity[1:] == (after.st_dev, after.st_ino, after.st_size,
                                    after.st_mtime_ns, after.st_ctime_ns),
                    "Input changed while hashing: " + str(path))
            self.file_cache[identity] = digest
        return self.file_cache[identity]

    def verify_hash(self, path, expected, label):
        require(isinstance(expected, str) and SHA256.fullmatch(expected),
                "Invalid SHA-256: " + label)
        actual = self.file_hash(path)
        self.equal(actual, expected, "Hash mismatch: " + label)
        return actual

    def artifact(self, directory, name, expected=None):
        path = directory / relative_name(name)
        require(not path.is_symlink() and path.resolve().is_relative_to(directory.resolve()),
                "Redirected evidence artifact: " + str(path))
        digest = self.file_hash(path)
        if expected is not None:
            self.verify_hash(path, expected, str(path))
        self.artifacts[str(path)] = {
            "sha256": digest, "bytes": path.stat().st_size,
            "recorded_hash_verified": expected is not None}
        return path

    def read_artifact(self, directory, name, expected=None):
        return json_bytes(self.artifact(directory, name, expected).read_bytes())

    def bind_parsers(self):
        failures_before = len(self.failures)
        for name in PARSERS:
            self.verify_hash(self.repo / name, self.source.blob_hash(name), name)
        require(len(self.failures) == failures_before, "Refusing to import an unbound parser")
        sys.path.insert(0, str(self.repo / "tools/mail"))
        for name, path in (("check_store", self.repo / "tools/mail/check_store.py"),
                           ("mail_evidence_gate", self.repo / GATE)):
            spec = importlib.util.spec_from_file_location(name, path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            spec.loader.exec_module(module)
            if name == "check_store":
                self.store = module
            else:
                self.gate = module

    @staticmethod
    def recorded_root(record):
        config = Path(record["package_config"])
        require(config.is_absolute() and config.parts[-2:] == (".dart_tool", "package_config.json"),
                "Unexpected recorded package_config location")
        return config.parent.parent

    def relocate(self, name, old_repo, old_runtime):
        path = Path(name)
        require(path.is_absolute(), "Expected absolute runtime input: " + name)
        if path.is_relative_to(old_repo):
            return self.repo / path.relative_to(old_repo)
        if path.is_relative_to(old_runtime):
            return self.runtime / path.relative_to(old_runtime)
        return path

    def verify_optional(self, path, expected, label):
        if expected is None:
            self.check(not path.exists() and not path.is_symlink(),
                       "Expected absent input exists: " + label)
        else:
            self.verify_hash(path, expected, label)

    def add_cases(self, cohort, group, platform, cases, old_repo):
        local = Counter()
        for case in cases:
            require(case["result"] == "success" and case["skipped"] is False,
                    f"{cohort}/{group}: failed or skipped substantive case")
            path = Path(case["suite"])
            require(path.is_absolute() and path.is_relative_to(old_repo),
                    "Suite outside recorded repository: " + str(path))
            suite = path.relative_to(old_repo).as_posix()
            require(suite in self.source.entries, "Case suite absent from source: " + suite)
            local[(suite, case["name"])] += 1
            self.cases.append({"cohort": cohort, "group": group, "platform": platform,
                               "suite": suite, "name": case["name"]})
        duplicates = [list(key) for key, count in local.items() if count > 1]
        self.check(not duplicates, f"{cohort}/{group}: ambiguous duplicate names: {duplicates!r}")

    def audit_mail(self, directory, record):
        self.equal(record.get("status"), "PASS", "mail: receipt is not PASS")
        self.equal(record.get("source_unchanged"), True, "mail: source changed")
        self.equal(record.get("active_check"), None, "mail: unfinished check")
        self.equal(record.get("github_actions"), "NOT USED", "mail: Actions policy mismatch")
        self.check(bool(record.get("finished_utc")), "mail: missing completion time")
        self.check(not record.get("error") and not record.get("runtime_inputs_changed"),
                   "mail: runner recorded an error")
        before = record["source_before"]
        self.equal(record["source_after"], before, "mail: source snapshots differ")
        expected_paths = {".fvmrc", "analysis_options.yaml", "pubspec.yaml", "pubspec.lock",
                          "tools/mail/check_store.py", "tools/mail/check_reader.py",
                          "tools/mail/test_check_store.py"}
        for package in ("quds_mail_core", "quds_mail_store"):
            prefix = "packages/" + package + "/"
            expected_paths.add(prefix + "pubspec.yaml")
            expected_paths.update(
                name for name in self.source.entries
                if name.startswith(tuple(prefix + folder + "/" for folder in ("lib", "test", "tool")))
                and not {".dart_tool", "build", "__pycache__"}.intersection(PurePosixPath(name).parts))
        self.equal(set(before), expected_paths, "mail: incomplete/extra source bindings")
        for name, digest in before.items():
            self.equal(digest, self.source.blob_hash(name), "mail: source differs from commit: " + name)
        checks = record["checks"]
        self.equal([item["name"] for item in checks], list(MAIL_CHECKS),
                   "mail: incomplete/reordered checks")
        old_repo = Path(checks[0]["cwd"])
        require(old_repo.is_absolute(), "mail: missing absolute repository cwd")
        recorded_dart = Path(checks[0]["command"][0])
        require(recorded_dart.is_absolute() and recorded_dart.parts[-6:] ==
                ("flutter", "bin", "cache", "dart-sdk", "bin", "dart"),
                "mail: runtime command does not identify the pinned SDK Dart")
        old_runtime = recorded_dart.parents[5]
        inputs = record["direct_launcher_inputs_before"]
        require(isinstance(inputs, dict) and inputs, "mail: direct launcher bindings missing")
        self.equal(record["direct_launcher_inputs_after"], inputs, "mail: launcher snapshots differ")
        for name, digest in inputs.items():
            path = self.relocate(name, old_repo, old_runtime)
            self.check(not path.is_symlink(), "mail: redirected launcher/native input: " + name)
            self.verify_optional(path, digest, "mail direct input " + name)
        # This verified helper only reads configuration/mappings. Recompute the
        # complete set, including SQLite and every absent nearer mapping, so a
        # deleted input cannot disappear merely by editing both receipt maps.
        config, launcher, resolved_inputs = self.store.direct_launcher(self.repo)
        relocated_inputs = {
            str(self.relocate(name, old_repo, old_runtime)): digest
            for name, digest in inputs.items()}
        self.equal(relocated_inputs, resolved_inputs,
                   "mail: complete direct-launcher input set/content differs")
        require(launcher.is_relative_to(self.runtime), "mail: launcher outside verified runtime")
        retained = json_bytes((self.runtime / "retained-inputs.json").read_bytes())
        launcher_name = launcher.relative_to(self.runtime).as_posix()
        require(launcher_name in retained, "mail: launcher not in retained runtime manifest")
        self.verify_hash(launcher, retained[launcher_name]["sha256"], "mail: retained launcher")
        old_launcher = old_runtime / launcher_name
        prefix = [str(recorded_dart), "--disable-dart-dev",
                  "--packages=" + str(old_repo / config.relative_to(self.repo)),
                  str(old_launcher)]
        by_name = {item["name"]: item for item in checks}
        python = by_name["runner-regressions"]["command"][0]
        require(Path(python).is_absolute() and
                re.fullmatch(r"python(?:[0-9]+(?:\.[0-9]+)?)?", Path(python).name),
                "mail: regression command does not use an absolute Python executable")
        old_output = Path(by_name["browser-entry"]["command"][-1]).parent
        require(old_output.is_absolute(), "mail: compiler output path is not absolute")
        core, store = old_repo / "packages/quds_mail_core", old_repo / "packages/quds_mail_store"
        expected_commands = {
            "runtime": [str(recorded_dart), "--version"],
            "runner-regressions": [python, "-m", "unittest", "discover", "-s", "tools/mail",
                                   "-p", "test_check_store.py", "-v"],
            "locked-resolution": [str(recorded_dart), "pub", "get", "--enforce-lockfile", "--offline"],
            "core-analysis": [str(recorded_dart), "analyze", "--fatal-infos"],
            "store-analysis": [str(recorded_dart), "analyze", "--fatal-infos"],
            "format": [str(recorded_dart), "format", "--output=none", "--set-exit-if-changed",
                       str(core / "lib"), str(core / "test"), str(store / "lib"),
                       str(store / "test"), str(store / "tool")],
            "browser-entry": [str(recorded_dart), "compile", "js", "tool/browser_compile_probe.dart",
                              "-o", str(old_output / "browser-entry.js")],
            "browser-worker": [str(recorded_dart), "compile", "js", "tool/mail_store_worker.dart",
                               "-o", str(old_output / "browser-worker.js")],
            "whitespace": ["git", "diff", "--check", "HEAD"],
        }
        parsed_checks = []
        python_controls = None
        for item in checks:
            name = item["name"]
            self.equal(item.get("status"), "PASS", "mail/" + name + ": did not pass")
            self.equal(item.get("exit_code"), 0, "mail/" + name + ": nonzero exit")
            log = self.artifact(directory, item["log"], item["log_sha256"])
            if "tests" not in item:
                require(name in expected_commands, "mail: missing test summary for " + name)
                self.equal(item["command"], expected_commands[name], "mail/" + name + ": command differs")
                cwd = (core if name == "core-analysis" else store
                       if name in {"store-analysis", "browser-entry", "browser-worker"} else old_repo)
                self.equal(item["cwd"], str(cwd), "mail/" + name + ": cwd differs")
                if name == "runner-regressions":
                    # unittest exits zero for skipped tests too. Require its
                    # unqualified OK footer, not only the recorded exit code.
                    match = re.search(r"(?:^|\n)Ran ([0-9]+) tests? in [^\n]+\n\nOK\s*\Z",
                                      log.read_text(errors="replace"))
                    require(match and int(match.group(1)) > 0,
                            "mail: Python controls have skips/errors or an invalid/missing completion footer")
                    python_controls = int(match.group(1))
                continue
            strict = self.store.test_summary(log)
            self.equal(strict.get("valid"), True, "mail/" + name + ": invalid raw events")
            self.equal(item["tests"], {k: v for k, v in strict.items() if k != "cases"},
                       "mail/" + name + ": summary differs from raw events")
            self.equal(self.read_artifact(directory, item["case_list"]), strict,
                       "mail/" + name + ": cases differ from raw events")
            cwd = Path(item["cwd"])
            require(cwd.is_relative_to(old_repo), "mail: test cwd outside repository")
            package, command = cwd.relative_to(old_repo).as_posix(), item["command"]
            platform = command[command.index("--platform") + 1]
            requested = [arg for arg in command if arg.startswith("test/") and arg.endswith("_test.dart")]
            self.equal(platform, "node" if name in {"core-node", "portable-node"} else "vm",
                       "mail/" + name + ": wrong platform")
            self.equal(package, "packages/quds_mail_core" if name.startswith("core-") else "packages/quds_mail_store",
                       "mail/" + name + ": wrong cwd")
            all_suites = sorted(path[len(package) + 1:] for path in before
                                if path.startswith(package + "/test/") and path.endswith("_test.dart"))
            if name.startswith("core-"):
                self.equal(requested, [], "mail/" + name + ": default suite selection narrowed")
                requested = all_suites
            elif name == "store-vm":
                self.equal(requested, [path for path in all_suites if path != "test/browser_problem_test.dart"],
                           "mail/store-vm: suite selection differs")
            else:
                self.equal(requested, ["test/codec_test.dart", "test/platform_configuration_test.dart",
                                       "test/browser_problem_test.dart"], "mail/portable-node: suite selection differs")
            expected_command = prefix + (["--compiler=kernel"] if platform == "vm" else [])
            expected_command += ["--platform", platform, "--reporter", "json"]
            if name == "store-vm":
                expected_command += ["--concurrency=2", *requested]
            elif name == "portable-node":
                expected_command += requested
            self.equal(command, expected_command, "mail/" + name + ": test command differs")
            parsed = self.gate.parse_reporter(log, cwd, requested)
            self.check(self.gate.reporter_passed(parsed), "mail/" + name + ": suite accounting failed")
            self.equal(parsed["passed"], strict["passed"], "mail/" + name + ": parser counts disagree")
            self.add_cases("mail", name, platform, parsed["cases"], old_repo)
            parsed_checks.append({"name": name, "platform": platform, "passed": parsed["passed"],
                                  "suites": len(parsed["per_suite"])})
        self.equal(len(parsed_checks), 4, "mail: four test cohorts were not reparsed")
        compiler_artifacts = []
        for name in ("browser-entry", "browser-worker"):
            for suffix in (".js", ".js.map", ".js.deps"):
                path = directory / (name + suffix)
                if path.is_file() or suffix == ".js":
                    self.artifact(directory, path.name)
                    compiler_artifacts.append(path.name)
        self.cohorts["mail"] = {"directory": str(directory), "source_inputs": len(before),
                                "direct_runtime_inputs": len(inputs), "checks": len(checks),
                                "groups": parsed_checks, "compiler_output_inventory": compiler_artifacts,
                                "recorded_runtime_root": str(old_runtime),
                                "python_control_executable": python,
                                "python_control_test_executions": python_controls,
                                "browser_storage_exercised": False}
        self.manifests["mail"] = {"source": before, "direct_inputs": inputs}

    def source_snapshot(self, record, before, after, label):
        self.equal(before, after, label + ": source snapshots differ")
        self.equal(record["source_input_count"], len(before), label + ": source count differs")
        self.equal(record["materialized_source_inputs"], sum(row["materialized"] is True for row in before.values()),
                   label + ": materialized count differs")
        self.equal(record["sparse_source_omissions"], [name for name, row in before.items() if row["sparse_omission"]],
                   label + ": sparse omission list differs")
        for name, row in before.items():
            relative_name(name)
            require(name in self.source.entries, label + ": source not tracked: " + name)
            entry = self.source.entries[name]
            self.equal(row["git_blob"], entry["git_blob"], label + ": wrong Git blob: " + name)
            self.equal(row["mode"], entry["mode"], label + ": wrong Git mode: " + name)
            if row["materialized"] is True:
                self.equal(row["sparse_omission"], False, label + ": materialized source marked omitted: " + name)
                self.equal(row["sha256"], self.source.blob_hash(name), label + ": content mismatch: " + name)
            else:
                self.equal(row["materialized"], False, label + ": invalid materialized flag: " + name)
                self.equal(row["sparse_omission"], True, label + ": missing source not sparse: " + name)
                self.equal(row["sha256"], None, label + ": absent source has hash: " + name)
                self.check(not name.endswith((".dart", ".yaml", ".lock")),
                           label + ": executable/config input omitted: " + name)

    def environment_snapshot(self, record, before, after, label):
        self.equal(before, after, label + ": runtime snapshots differ")
        self.equal(record["runtime_input_count"], len(before), label + ": runtime count differs")
        old_repo = self.recorded_root(record)
        old_runtime = Path(record["runtime"]["flutterRoot"]).parent
        for name, digest in before.items():
            if name.startswith("runtime/"):
                path = self.runtime / relative_name(name.removeprefix("runtime/"))
            elif name.startswith("workspace/"):
                suffix = name.removeprefix("workspace/")
                path = self.repo / (".dart_tool/package_config.json" if suffix == "package_config.json"
                                    else ".dart_tool/native_assets.yaml" if suffix == "native_assets.yaml"
                                    else relative_name(suffix))
            elif name == "sdk/flutter_tools/package_config.json":
                path = self.runtime / "flutter/packages/flutter_tools/.dart_tool/package_config.json"
            elif name.startswith("additional/"):
                path = self.relocate(name.removeprefix("additional/"), old_repo, old_runtime)
            else:
                raise AuditError(label + ": unknown runtime namespace: " + name)
            if digest is None:
                self.check(name.startswith("workspace/") and name.endswith("native_assets.yaml"),
                           label + ": unexpected absent runtime input: " + name)
            self.verify_optional(path, digest, label + ": " + name)
        receipt = json_bytes((self.runtime / "runtime.json").read_bytes())
        self.verify_hash(self.runtime / "runtime.json", record["runtime_receipt_sha256"],
                         label + ": runtime receipt")
        self.equal(receipt.get("status"), "ready", label + ": runtime not ready")
        self.equal(receipt.get("archive", {}).get("verified"), True, label + ": SDK archive not verified")
        self.equal(receipt["runtime"], record["runtime"], label + ": runtime identity differs")
        self.equal(receipt["workspace_lock_sha256"], record["workspace_lock_sha256"], label + ": runtime lock differs")
        self.equal(record["workspace_lock_sha256"], self.source.blob_hash("pubspec.lock"), label + ": source lock differs")
        self.equal(before.get("workspace/pubspec.lock"), record["workspace_lock_sha256"], label + ": lock snapshot differs")
        self.equal(receipt.get("additional_inputs", {}), record["additional_runtime_inputs"],
                   label + ": additional inputs differ")
        retained = json_bytes((self.runtime / "retained-inputs.json").read_bytes())
        expected_names = {"runtime/" + name for name in retained}
        expected_names.update("runtime/" + name for name in (
            "runtime.json", "retained-inputs.json", "pub-cache-receipt.json", "cache-omissions.json",
            "archive-members.json", "env.sh", "bin/dart", "bin/flutter"))
        expected_names.update({"workspace/pubspec.lock", "workspace/package_config.json",
                               "sdk/flutter_tools/package_config.json", "workspace/native_assets.yaml"})
        expected_names.update("additional/" + name for name in record["additional_runtime_inputs"])
        for group in record["planned_groups"]:
            cwd = PurePosixPath(relative_name(group["cwd"]))
            while cwd != PurePosixPath("."):
                expected_names.add("workspace/" + str(cwd / ".dart_tool/native_assets.yaml"))
                cwd = cwd.parent
        self.equal(set(before), expected_names, label + ": runtime input selection differs")
        for name, metadata in retained.items():
            self.equal(before.get("runtime/" + name), metadata["sha256"], label + ": retained hash differs: " + name)
        for name, digest in record["additional_runtime_inputs"].items():
            self.equal(before.get("additional/" + name), digest, label + ": additional hash differs: " + name)
        for name, digest in receipt["executables_sha256"].items():
            path = self.runtime / "flutter" / Path(name).relative_to(Path(receipt["sdk"]))
            self.verify_hash(path, digest, label + ": pinned executable " + name)
        launcher = self.relocate(record["test_launcher"], old_repo, old_runtime)
        require(launcher.is_relative_to(self.runtime), label + ": launcher outside runtime")
        key = "runtime/" + launcher.relative_to(self.runtime).as_posix()
        require(key in before and key.removeprefix("runtime/") in retained,
                label + ": launcher not retained/bound")
        self.verify_hash(launcher, before[key], label + ": test launcher")
        if any(group.get("platform", "vm") == "node" for group in record["planned_groups"]):
            node = receipt["node_runtime"]
            self.equal(record["additional_runtime_inputs"].get(node["path"]), node["sha256"],
                       label + ": Node executable not bound")

    def audit_gate(self, label, directory, record):
        for key in ("success", "source_unchanged", "environment_unchanged", "source_head_unchanged",
                    "source_index_unchanged", "tracked_worktree_clean_before", "tracked_worktree_clean_after"):
            self.equal(record.get(key), True, label + ": " + key + " is not true")
        for key in ("source_mismatches", "environment_mismatches", "unexpected_native_mappings_after"):
            self.equal(record.get(key), [], label + ": " + key + " is nonempty/missing")
        self.equal(record.get("github_actions_queried_or_awaited"), False, label + ": Actions policy mismatch")
        self.check(bool(record.get("finished_at_utc")) and not record.get("runner_error"),
                   label + ": incomplete/error receipt")
        self.equal(record["source_tree"], self.source.tree, label + ": wrong source tree")
        require(set(record["manifest_sha256"]) == set(SNAPSHOTS), label + ": missing/extra snapshot hash")
        snapshots = {name: self.read_artifact(directory, name, record["manifest_sha256"][name])
                     for name in SNAPSHOTS}
        before = snapshots["source-before.json"]
        self.source_snapshot(record, before, snapshots["source-after.json"], label)
        self.environment_snapshot(record, snapshots["environment-before.json"], snapshots["environment-after.json"], label)
        plan_name = relative_name(record["plan"])
        self.equal(record["plan_sha256"], self.source.blob_hash(plan_name), label + ": committed plan hash differs")
        plan = json_bytes(self.source.read(plan_name))
        groups = plan["groups"]
        self.equal(record["planned_groups"], groups, label + ": groups differ from committed plan")
        require(isinstance(groups, list) and groups, label + ": empty plan")
        group_names = [group["name"] for group in groups]
        self.equal(len(set(group_names)), len(group_names), label + ": duplicate group names")
        changed = [name for name in self.source.git("diff", "--name-only", "--diff-filter=ACMRT", "-z",
                                                   record["source_base"], self.source.commit).decode().split("\0")
                   if name.endswith(".dart") and name.startswith(("packages/", "apps/"))]
        analysis = changed if plan.get("analysis", "changed") == "changed" else plan["analysis"]
        formatting = changed if plan.get("format", "changed") == "changed" else plan["format"]
        self.equal(record["analysis_files"], analysis, label + ": analysis selection differs")
        self.equal(record["formatted_files"], formatting, label + ": format selection differs")
        self.equal(record["whitespace_preserved_inputs"], plan.get("whitespace_preserved_inputs", []),
                   label + ": whitespace exceptions differ")
        requested = []
        for group in groups:
            if label in {"native", "node"}:
                self.equal(group.get("platform", "vm"), "node" if label == "node" else "vm",
                           label + ": wrong platform in " + group["name"])
            requested.extend((PurePosixPath(relative_name(group["cwd"])) / relative_name(name)).as_posix()
                             for name in group["tests"])
        self.equal(len(requested), len(set(requested)), label + ": repeated suite within plan")
        expected_inputs = {name for name in self.source.entries
                           if name.startswith(("packages/", "apps/", "third_party/"))
                           or ("/" not in name and PurePosixPath(name).suffix in {".yaml", ".lock"})}
        expected_inputs.update([plan_name, *PARSERS, *requested, *analysis, *formatting,
                                *plan.get("extra_inputs", [])])
        expected_inputs.update(row["path"] for row in record["whitespace_preserved_inputs"])
        self.equal(set(before), expected_inputs, label + ": source input selection differs")
        for item in record["whitespace_preserved_inputs"]:
            self.equal(self.source.entries[item["path"]]["git_blob"], item["git_blob"],
                       label + ": whitespace exception blob differs")
        old_repo = self.recorded_root(record)
        old_runtime = Path(record["runtime"]["flutterRoot"]).parent
        expected_runs = [*group_names, *(["analysis"] if analysis else []),
                         *(["format"] if formatting else []), "whitespace"]
        self.equal([row["name"] for row in record["runs"]], expected_runs, label + ": run list differs")
        parsed_groups, totals = [], Counter()
        group_map = {group["name"]: group for group in groups}
        for item in record["runs"]:
            name = item["name"]
            self.equal(item.get("accepted"), True, label + "/" + name + ": run not accepted")
            self.equal(item.get("exit_code"), 0, label + "/" + name + ": nonzero exit")
            self.check(not item.get("runner_error"), label + "/" + name + ": runner error")
            log = self.artifact(directory, item["log"], item["log_sha256"])
            compressed = self.artifact(directory, item["compressed_log"], item["compressed_log_sha256"])
            self.equal(gzip.decompress(compressed.read_bytes()), log.read_bytes(),
                       label + "/" + name + ": gzip/raw mismatch")
            if name not in group_map:
                if name == "analysis":
                    command = [str(old_runtime / "bin/dart"), "analyze", "--fatal-infos", "--fatal-warnings", *analysis]
                elif name == "format":
                    command = [str(old_runtime / "bin/dart"), "format", "--output=none", "--set-exit-if-changed", *formatting]
                elif name == "whitespace":
                    command = ["git", "diff", "--check", record["source_base"], self.source.commit, "--", ".",
                               *[":(exclude)" + row["path"] for row in record["whitespace_preserved_inputs"]]]
                else:
                    raise AuditError(label + ": unknown non-test run " + name)
                self.equal(item["command"], command, label + "/" + name + ": command differs")
                self.equal(item["cwd"], ".", label + "/" + name + ": non-root cwd")
                continue
            group = group_map[name]
            self.equal(item["cwd"], group["cwd"], label + "/" + name + ": cwd differs")
            command = self.gate.test_command(old_runtime, group, package_config=Path(record["package_config"]),
                                             test_entrypoint=Path(record["test_launcher"]))
            self.equal(item["command"], command, label + "/" + name + ": test command differs")
            parsed = self.gate.parse_reporter(log, old_repo / group["cwd"], group["tests"])
            self.check(self.gate.reporter_passed(parsed), label + "/" + name + ": raw reporter/coverage failed")
            for kind in ("cases", "errors"):
                self.equal(self.read_artifact(directory, item[kind + "_file"], item[kind + "_sha256"]), parsed[kind],
                           label + "/" + name + ": " + kind + " differ from raw events")
            for key, value in parsed.items():
                if key not in {"cases", "errors"}:
                    self.equal(item.get(key), value, label + "/" + name + ": recorded " + key + " differs")
            self.add_cases(label, name, group.get("platform", "vm"), parsed["cases"], old_repo)
            for key in ("passed", "failed", "skipped"):
                totals[key] += parsed[key]
            parsed_groups.append({"name": name, "platform": group.get("platform", "vm"),
                                  "passed": parsed["passed"], "suites": len(parsed["per_suite"])})
        for key in ("passed", "failed", "skipped"):
            self.equal(record[key], totals[key], label + ": aggregate " + key + " differs")
        self.equal(totals["failed"], 0, label + ": failed cases")
        self.equal(totals["skipped"], 0, label + ": skipped cases")
        self.cohorts[label] = {"directory": str(directory), "source_inputs": len(before),
                               "runtime_inputs": len(snapshots["environment-before.json"]),
                               "checks": len(record["runs"]), "groups": parsed_groups}
        self.manifests[label] = {"source": {name: row["sha256"] for name, row in before.items()},
                                 "environment": snapshots["environment-before.json"]}

    def counts(self):
        executions, scenarios = defaultdict(list), defaultdict(set)
        for case in self.cases:
            executions[(case["platform"], case["suite"], case["name"])].append(case["cohort"] + "/" + case["group"])
            scenarios[(case["suite"], case["name"])].add(case["platform"])
        return {
            "raw_successful_test_executions": len(self.cases),
            "unique_platform_suite_case_executions": len(executions),
            "repeated_same_platform_executions": len(self.cases) - len(executions),
            "unique_suite_case_scenarios_across_platforms": len(scenarios),
            "scenarios_exercised_on_multiple_platforms": sum(len(platforms) > 1 for platforms in scenarios.values()),
            "raw_by_cohort": dict(sorted(Counter(case["cohort"] for case in self.cases).items())),
            "raw_by_platform": dict(sorted(Counter(case["platform"] for case in self.cases).items())),
            "unique_by_platform": dict(sorted(Counter(key[0] for key in executions).items())),
            "unique_suites_across_platforms": len({case["suite"] for case in self.cases}),
            "repeated_same_platform_cases": [
                {"platform": key[0], "suite": key[1], "name": key[2], "occurrences": owners}
                for key, owners in sorted(executions.items()) if len(owners) > 1],
            "definition": (
                "Raw counts retain runtime executions. Coverage uses repository-relative suite and full test name; "
                "platform is retained only for execution coverage. Hidden/loading/setup/teardown events are excluded "
                "by the strict gate parser. Compiler probes and Python controls are not Dart test cases."),
        }


def main():
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=base.parent / "quds_office_suite")
    parser.add_argument("--runtime", type=Path, default=base.parent / "toolchains")
    parser.add_argument("--mail-dir", type=Path, default=base / "mail-final")
    parser.add_argument("--native-dir", type=Path, default=base / "native-final")
    parser.add_argument("--node-dir", type=Path, default=base / "node-final")
    parser.add_argument("--expected-source")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    audit = Audit(args.repo.resolve(), args.runtime.resolve())
    directories = {name: getattr(args, name + "_dir").resolve() for name in ("mail", "native", "node")}
    if args.output:
        output = args.output.resolve()
        require(not any(output == root or output.is_relative_to(root)
                        for root in [audit.repo, audit.runtime, *directories.values()]),
                "Output must be outside repository, runtime, and input evidence directories")
    records = {}
    for name, directory in directories.items():
        record = audit.section(name + " receipt", lambda name=name, directory=directory:
                               audit.read_artifact(directory, "receipt.json" if name == "mail" else "verification.json"))
        if record is not None:
            records[name] = record
    audit.equal(len(set(directories.values())), 3, "Cohorts must use distinct evidence directories")
    commits = {name: record.get("starting_commit" if name == "mail" else "source_commit")
               for name, record in records.items()}
    audit.equal(len(records), 3, "All three final receipts required")
    audit.check(bool(commits) and len(set(commits.values())) == 1, "Cohorts do not identify one common source commit")
    commit = args.expected_source or next(iter(commits.values()), None)
    for name, value in commits.items():
        audit.equal(value, commit, name + ": source differs from expected/frozen commit")
    if commit:
        audit.source = audit.section("Git source binding", lambda: GitSource(audit.repo, commit))
    if audit.source:
        audit.section("Parser binding", audit.bind_parsers)
        if audit.gate and audit.store:
            for name, record in records.items():
                if name == "mail":
                    audit.section("mail evidence", lambda: audit.audit_mail(directories[name], record))
                else:
                    audit.section(name + " evidence", lambda name=name, record=record:
                                  audit.audit_gate(name, directories[name], record))
        for first, second in (("mail", "native"), ("mail", "node"), ("native", "node")):
            if first in audit.manifests and second in audit.manifests:
                for kind in ("source", "environment"):
                    a, b = audit.manifests[first].get(kind, {}), audit.manifests[second].get(kind, {})
                    for name in a.keys() & b.keys():
                        audit.equal(a[name], b[name], f"{first}/{second}: shared {kind} differs: {name}")
        audit.section("Git reader cleanup", audit.source.close)
    audit.equal(set(audit.cohorts), {"mail", "native", "node"}, "Not every cohort completed the audit")
    success = not audit.failures
    result = {
        "status": "PASS" if success else "FAIL", "success": success,
        "audited_at_utc": datetime.now(timezone.utc).isoformat(),
        "auditor_sha256": audit.file_hash(Path(__file__)),
        "source_commit": commit, "source_tree": audit.source.tree if audit.source else None,
        "receipts_source_commits": commits, "checks_performed": audit.check_count,
        "cohorts": audit.cohorts, "counts": audit.counts(), "failures": audit.failures,
        "artifacts": audit.artifacts, "unique_materialized_files_hashed": len(audit.file_cache),
        "git_blobs_independently_hashed": len(audit.source.hashes) if audit.source else 0,
        "scope": {
            "tests_or_builds_executed": False, "github_actions_accessed": False,
            "source_binding": "Committed Git blobs, modes, selected inputs, and before/after snapshots; current checkout may be newer.",
            "runtime_binding": "Recorded manifests, retained runtime, additional executable/native inputs, and current materialized bytes.",
            "compiler_outputs": "Inventoried only: check_store records compile-log hashes but no original output hashes. Browser storage is not exercised.",
            "trust_limit": "Internal consistency and surviving artifact verification, not external signatures or independently executing the tests.",
        },
    }
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps({"status": result["status"], "source_commit": commit,
                          "counts": {key: value for key, value in result["counts"].items()
                                     if key not in {"repeated_same_platform_cases", "definition"}},
                          "failures": audit.failures[:12], "failure_count": len(audit.failures),
                          "output": str(args.output.resolve())}, indent=2))
    else:
        print(json.dumps(result, indent=2))
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
