"""Retain original final qualification evidence with an independently checkable index."""

from pathlib import Path
import argparse
import hashlib
import io
import json
import shutil
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pack(destination, source_commit, inputs, omitted=(), scope=None):
    members = []
    with tarfile.open(destination, "w:xz", preset=6) as archive:
        for source, name in sorted(inputs, key=lambda row: row[1]):
            data = source.read_bytes()
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
            members.append({"path": name, "bytes": len(data), "sha256": digest(data)})
    index = {
        "source_commit": source_commit,
        "archive": destination.name,
        "archive_bytes": destination.stat().st_size,
        "archive_sha256": digest(destination.read_bytes()),
        "members": members,
        "omitted_generated_compilation_outputs": list(omitted),
    }
    if scope is not None:
        index["scope"] = scope
    index_path = destination.with_suffix(".index.json")
    index_path.write_text(json.dumps(index, indent=2) + "\n")
    print(json.dumps({"archive": str(destination), "bytes": index["archive_bytes"], "members": len(members), "sha256": index["archive_sha256"]}), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--head", required=True)
    args = parser.parse_args()
    workspace = Path(__file__).resolve().parents[1]
    verification = workspace / "verification"
    repo = workspace / "quds_office_suite"
    target = repo / "docs/validation/mail-m06-resume-20261119/final"
    target.mkdir(exist_ok=True)
    execution = json.loads((verification / "final-execution.json").read_text())
    if execution["head"] != args.head or execution["status"] != "PASS":
        raise RuntimeError("A passing final execution receipt on the requested source is required")
    audit = json.loads((verification / "final-evidence-audit.json").read_text())
    if audit["source_commit"] != args.head or audit["status"] != "PASS":
        raise RuntimeError("The independent evidence audit must pass on the requested source")
    for name, receipt_name in (("mail-final", "receipt.json"), ("native-final", "verification.json"), ("node-final", "verification.json")):
        directory = verification / name
        inputs = []
        omitted = []
        for source in sorted(directory.rglob("*")):
            if not source.is_file():
                continue
            relative = source.relative_to(directory).as_posix()
            if relative.startswith(("browser-entry.js", "browser-worker.js")):
                data = source.read_bytes()
                omitted.append({"path": relative, "bytes": len(data), "sha256": digest(data), "reason": "Generated browser compilation output; exact compiler commands and results retained."})
            else:
                inputs.append((source, name + "/" + relative))
        inputs.append((verification / (name + ".log"), name + "/driver.log"))
        pack(target / (name + ".tar.xz"), args.head, inputs, omitted)
        shutil.copy2(directory / receipt_name, target / (name + "-" + receipt_name))
    preparation = verification / "final-preparation"
    inputs = [(source, "preparation/" + source.relative_to(preparation).as_posix()) for source in sorted(preparation.rglob("*")) if source.is_file()]
    inputs.extend((verification / name, "support/" + name) for name in ("final-execution.json", "run_final.py", "audit_final_mail.py", "package_final.py", "audit-controls.json", "final-evidence-audit.json", "runner-controls.log", "runtime-controls.log"))
    repair = verification / "test-repair"
    inputs.extend((source, "test-repair/" + source.name) for source in sorted(repair.iterdir()) if source.is_file())
    race_repair = verification / "runner-race-repair"
    inputs.extend((source, "runner-race-repair/" + source.name) for source in sorted(race_repair.iterdir()) if source.is_file())
    pack(target / "preparation.tar.xz", args.head, inputs)
    shutil.copy2(verification / "final-execution.json", target / "execution.json")
    shutil.copy2(verification / "final-evidence-audit.json", target / "evidence-audit.json")
    development = workspace / "transport-dev"
    inputs = [(source, "transport-development/" + source.name) for source in sorted(development.iterdir()) if source.is_file() and source.suffix in {".json", ".log"}]
    pack(target / "development.tar.xz", None, inputs, scope="Development diagnostics from multiple intermediate source states, including failed fixture/style attempts and later successful controls. These logs are historical and are not attributed collectively to the final source or counted as final acceptance. Exact final acceptance is in the three source-bound gate archives.")
    first_attempt = verification / "failed-da78c0bb-1"
    inputs, omitted = [], []
    for source in sorted(first_attempt.rglob("*")):
        if not source.is_file():
            continue
        relative = source.relative_to(first_attempt).as_posix()
        if source.name.startswith(("browser-entry.js", "browser-worker.js")):
            data = source.read_bytes()
            omitted.append({"path": relative, "bytes": len(data), "sha256": digest(data), "reason": "Generated browser compilation output; original command results retained."})
        else:
            inputs.append((source, "first-attempt/" + relative))
    pack(target / "first-attempt.tar.xz", "da78c0bb7bd9e119cc6697a5a476be3b388514c4", inputs, omitted, scope="Failed initial integrated store gate: strict flag-test lint and ambiguous migration-test import. Extended native/Node plans did not start. Retained separately from the repaired final source and its acceptance counts.")
    shutil.copy2(first_attempt / "mail-final/receipt.json", target / "first-attempt-mail-receipt.json")
    second_attempt = verification / "failed-e734e3bd-1"
    inputs = [(source, "second-attempt/" + source.relative_to(second_attempt).as_posix()) for source in sorted(second_attempt.rglob("*")) if source.is_file()]
    pack(target / "second-attempt.tar.xz", "e734e3bd14f6c802a1da1c05969bd51108890ded", inputs, scope="Failed tooling preflight: the killed child disappeared during /proc stat reading. No Dart product cohort started. A subsequent test-only observation fix handles reaping without changing process termination or Mail product behavior.")
    shutil.copy2(second_attempt / "mail-final/receipt.json", target / "second-attempt-mail-receipt.json")
    source_review = verification / "final-source-review"
    inputs = [(source, "source-review/" + source.relative_to(source_review).as_posix()) for source in sorted(source_review.rglob("*")) if source.is_file()]
    pack(target / "source-review.tar.xz", None, inputs, scope="Independent source-review and Office continuity records for final source " + args.head + " plus the separately identified earlier failed attempts. Each record carries its own source identity; these audits do not execute tests.")
    current_review = source_review / ("final-" + args.head[:8])
    for name in ("source-continuity.json", "transport-review-binding.json", "workspace-and-plan-binding.json", "runner-test-review.json", "published-readback.json"):
        shutil.copy2(current_review / name, target / name)


if __name__ == "__main__":
    main()
