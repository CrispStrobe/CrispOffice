"""Run the three integrated Mail gates sequentially on one clean source commit."""

from pathlib import Path
import argparse
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--head", required=True)
    args = parser.parse_args()
    workspace = Path(__file__).resolve().parents[1]
    repo = workspace / "quds_office_suite"
    runtime = workspace / "toolchains"
    output = workspace / "verification"

    def git(*arguments):
        return subprocess.check_output(["git", *arguments], cwd=repo, text=True).strip()

    if git("rev-parse", "HEAD") != args.head or git("status", "--porcelain"):
        raise RuntimeError("Final qualification requires the requested clean source HEAD")
    source_tree = git("rev-parse", "HEAD^{tree}")
    runner = "docs/validation/document-review-notes-20261118/run_checks.py"
    plan_root = "docs/validation/mail-m06-resume-20261119"
    common = [
        "--head", args.head,
        "--base", "faab20b96e4a51fd6e3cf1a80b1439c4a1b01b9c",
        "--runtime", str(runtime), "--command-timeout", "600",
    ]
    commands = [
        ("runner-controls", ["python3", "docs/validation/document-review-notes-20261118/test_run_checks.py"]),
        ("runtime-controls", ["python3", "docs/validation/document-review-notes-20261118/runtime/test_restore_runtime.py"]),
        ("mail-final", [
            "python3", "tools/mail/check_store.py",
            "--flutter-sdk", str(runtime / "flutter"),
            "--offline", "--direct-tests", "--command-timeout", "300",
            "--output", str(output / "mail-final"),
        ]),
        ("native-final", [
            "python3", runner, *common,
            "--plan", plan_root + "/native-test-plan.json",
            "--output", str(output / "native-final"),
        ]),
        ("node-final", [
            "python3", runner, *common,
            "--plan", plan_root + "/node-test-plan.json",
            "--output", str(output / "node-final"),
        ]),
    ]
    receipt = {
        "head": args.head, "tree": source_tree,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "RUNNING", "runs": [],
    }
    receipt_path = output / "final-execution.json"

    def save():
        receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")

    save()
    for name, command in commands:
        if (output / name).exists() or (output / (name + ".log")).exists():
            raise RuntimeError("Refusing to overwrite an existing gate: " + name)
        print("Starting " + name, flush=True)
        start = time.monotonic()
        with (output / (name + ".log")).open("w") as log:
            result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
        row = {
            "name": name, "command": command, "cwd": str(repo),
            "exit_code": result.returncode, "seconds": time.monotonic() - start,
            "log": str(output / (name + ".log")),
            "log_sha256": hashlib.sha256((output / (name + ".log")).read_bytes()).hexdigest(),
        }
        receipt["runs"].append(row)
        print(json.dumps(row), flush=True)
        if result.returncode:
            receipt["status"] = "FAIL"
            save()
            raise SystemExit(result.returncode)
        save()
    receipt["source_unchanged"] = (
        git("rev-parse", "HEAD") == args.head
        and git("rev-parse", "HEAD^{tree}") == source_tree
        and not git("status", "--porcelain")
    )
    receipt["status"] = "PASS" if receipt["source_unchanged"] else "FAIL"
    receipt["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps({key: value for key, value in receipt.items() if key != "runs"}), flush=True)
    raise SystemExit(0 if receipt["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
