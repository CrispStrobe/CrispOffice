from pathlib import Path
import json
root=Path('/workspace/scratch/a4ce103494d8')
repo=root/'quds_office_suite'
engine='packages/quds_office_engine'
editor='packages/quds_office_editor'
studio='packages/quds_office_editor/example'
extras=[
 'word_tree_test.dart',
 'word_structure_integrity_test.dart',
 'word_field_span_test.dart',
 'word_bibliography_fidelity_test.dart',
 'word_note_bookmark_edit_test.dart',
 'word_note_numbering_test.dart',
 'word_footnote_reference_test.dart',
 'word_table_test.dart',
 'word_table_grid_addressing_test.dart',
 'word_table_cell_border_roundtrip_test.dart',
 'word_table_nested_layout_test.dart',
 'word_table_vertical_merge_layout_test.dart',
 'word_table_direction_test.dart',
 'word_table_style_import_regression_test.dart',
 'word_table_style_precedence_test.dart',
 'word_package_preservation_test.dart',
 'word_content_control_fidelity_test.dart',
 'word_bookmark_fidelity_test.dart',
 'word_edit_integrity_test.dart',
 'odt_document_writer_test.dart',
 'odt_table_merge_test.dart',
 'odt_structure_fidelity_test.dart',
 'odt_inline_field_fidelity_test.dart',
 'odt_complex_field_fidelity_test.dart',
 'odt_note_fidelity_test.dart',
 'odt_bookmark_range_fidelity_test.dart',
 'odt_hyperlink_range_fidelity_test.dart',
]
def find(package,glob): return sorted(str(p.relative_to(repo/package)) for p in (repo/package/'test').glob(glob))
def cohort(name,package,runner,tests,concurrency):
 assert tests and len(tests)==len(set(tests))
 for p in tests: assert (repo/package/p).is_file(),p
 return {'name':name,'package':package,'runner':runner,'tests':tests,'concurrency':concurrency,'test_timeout':'2m','process_timeout_seconds':1200}
engine_tests=find(engine,'*zotero*test.dart')
editor_tests=find(editor,'word_zotero*test.dart')
cohorts=[cohort('engine-zotero',engine,'dart',engine_tests,2),cohort('engine-owner-fidelity',engine,'dart',['test/'+s for s in extras],2)]
for i in range(0,len(editor_tests),10):
 cohorts.append(cohort('editor-zotero-'+str(1+i//10),editor,'flutter',editor_tests[i:i+10],1))
cohorts.append(cohort('studio-zotero',studio,'flutter',find(studio,'studio_zotero*test.dart'),1))
all_paths=[c['package']+'/'+t for c in cohorts for t in c['tests']]
assert len(all_paths)==len(set(all_paths))
plan={'schema_version':1,'status':'prepared-not-executed','repo':str(repo),'workspace':str(root/'quds-validation'),'runtime':str(root/'runtime-setup'),'cohorts':cohorts,'approved_skips':[],'scope':{'engine_zotero_suites':len(engine_tests),'engine_owner_fidelity_suites':len(extras),'editor_zotero_suites':len(editor_tests),'studio_zotero_suites':len(cohorts[-1]['tests']),'total_suites':len(all_paths),'overlap':'Disjoint file populations; no case counted in more than one cohort.'},'source_binding':'All tracked repository Dart sources under packages and third_party, root and workspace manifests/lockfiles, analysis options, selected package test fixtures and engine BAS examples; docs excluded. Current path set and bytes must match frozen commit before and after every cohort.','execution':'Original test files in genuine package:test or flutter test; separate libraries/isolates as supplied by those runners. No rewritten tests or synthesized merged suites. Engine concurrency 2; Flutter concurrency 1 and sequential cohorts.','selection_rationale':{'engine-zotero':'Complete current Zotero engine population, including protocol, rendering, insertion, transfer and table-range regressions.','engine-owner-fidelity':'Word ownership/tree integrity; field/bookmark/note preservation; native table addressing/geometry/style and DOCX/ODT serializer fidelity that surrounds a table-cell paragraph splice.','editor-zotero':'Complete Zotero controller/UI population, including undo/redo, cancellation, stale state, selected sources and transfer.','studio-zotero':'Desktop transport and Zotero command/shortcut integration.'}}
(root/'cell-validation/selection.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(plan['scope'],indent=2))
