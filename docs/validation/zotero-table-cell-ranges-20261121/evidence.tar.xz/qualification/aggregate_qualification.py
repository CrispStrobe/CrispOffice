#!/usr/bin/env python3
"""Combine disjoint accepted executions; retain the earlier audit rejection."""
from pathlib import Path
import gzip,hashlib,json
root=Path(__file__).resolve().parent
plan=json.loads((root/'selection.json').read_text())
initial=root/'frozen-final'; resumed=root/'frozen-remaining'
correction=json.loads((root/'engine-corrected-audit.json').read_text())
resume_summary=json.loads((resumed/'summary.json').read_text())
assert correction['status']=='passed' and all(correction['guards'].values())
assert resume_summary['status']=='passed'
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
source=load(initial/'frozen-source.json.gz')
assert source==load(initial/'final-source.json.gz')==load(resumed/'frozen-source.json.gz')==load(resumed/'final-source.json.gz')
assert json.loads((initial/'environment-before.json').read_text())==json.loads((initial/'environment-after.json').read_text())==json.loads((resumed/'environment-before.json').read_text())==json.loads((resumed/'environment-after.json').read_text())
rows=[];selected=[];case_ids=set()
for cohort in plan['cohorts']:
 execution=initial if cohort['name']=='engine-zotero' else resumed
 folder=execution/cohort['name']
 summary=json.loads((folder/'summary.json').read_text())
 command=json.loads((folder/'command.json').read_text())
 assert summary['exit_code']==0
 if execution==initial:
  assert [k for k,v in summary['guards'].items() if not v]==['all_selected_suites_reported']
  accepted_audit='engine-corrected-audit.json'
 else:
  assert summary['status']=='passed' and all(summary['guards'].values())
  accepted_audit=str((folder/'summary.json').relative_to(root))
 assert command['selected_test_files']==[cohort['package']+'/'+p for p in cohort['tests']]
 assert summary['stdout_sha256']==hashlib.sha256((folder/'stdout.jsonl').read_bytes()).hexdigest()
 assert summary['stderr_sha256']==hashlib.sha256((folder/'stderr.log').read_bytes()).hexdigest()
 assert summary['stderr_bytes']==0
 assert source==load(folder/'source-before.json.gz')==load(folder/'source-after.json.gz')
 cases=load(folder/'cases.json.gz')
 assert len(cases)==summary['counts']['passed']
 assert all(c['result']=='success' and not c['skipped'] for c in cases)
 for c in cases:
  ident=(str(execution.relative_to(root)),cohort['name'],c['id'])
  assert ident not in case_ids
  case_ids.add(ident)
 selected.extend(command['selected_test_files'])
 rows.append({'name':cohort['name'],'suites':len(cohort['tests']),'passed':len(cases),'failed':0,'skipped':0,'json_errors':0,'stderr_bytes':0,'execution_directory':str(folder.relative_to(root)),'accepted_audit':accepted_audit,'original_tests_preserved':True})
assert len(selected)==len(set(selected))==plan['scope']['total_suites']==119
assert len(case_ids)==sum(row['passed'] for row in rows)
receipt={'status':'passed','source_map_sha256':correction['source_map_sha256'],'source_input_count':len(source),'source_unchanged_across_all_executions':True,'environment_unchanged_across_all_executions':True,'cohorts':rows,'totals':{'suites':len(selected),'passed':len(case_ids),'failed':0,'skipped':0,'json_errors':0,'stderr_bytes':0},'all_suite_populations_disjoint':True,'scope':plan['scope'],'selected_test_files':selected,'loading_setup_teardown_counted_as_cases':False,'development_smokes_and_portable_repeats_included':False,'audit_correction':{'original_rejection':'frozen-final/engine-zotero/summary.json','original_runner':'run_qualification_v1.py','correction_script':'reaudit_engine.py','corrected_audit':'engine-corrected-audit.json','tests_rerun_for_correction':False,'original_raw_events_unchanged':True},'resume_source_map_sha256':json.loads((resumed/'run.json').read_text())['source_map_sha256'],'runner_versions':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'run_qualification_v1.py',root/'run_qualification.py']},'aggregate_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(root/'qualification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'totals':receipt['totals'],'cohorts':rows},indent=2))
