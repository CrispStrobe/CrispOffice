"""Independently re-audit preserved engine events after relative-path correction."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,json,re
root=Path('/workspace/scratch/a4ce103494d8/cell-validation')
run=root/'frozen-final'; target=run/'engine-zotero'
plan=json.loads((run/'selection.json').read_text())
c=next(x for x in plan['cohorts'] if x['name']=='engine-zotero')
command=json.loads((target/'command.json').read_text()); cwd=Path(command['cwd'])
lines=(target/'stdout.jsonl').read_text().splitlines()
events=[json.loads(line) for line in lines if line.strip()]
started=[e['test'] for e in events if e.get('type')=='testStart']
starts={t['id']:t for t in started}
finished=[e for e in events if e.get('type')=='testDone']
finish=Counter(e['testID'] for e in finished)
suites=[e['suite'] for e in events if e.get('type')=='suite']
actual_paths=[]
for suite in suites:
 p=Path(suite['path'])
 actual_paths.append(str((p if p.is_absolute() else cwd/p).resolve()))
expected_paths=[str((cwd/p).resolve()) for p in c['tests']]
assert len(expected_paths)==len(set(expected_paths))==41
cases=[]
for end in finished:
 title=starts[end['testID']]['name']
 if end.get('hidden') or re.search(r'(?:^|\s)\(?setUpAll\)?$|(?:^|\s)\(?tearDownAll\)?$',title):continue
 cases.append({'id':end['testID'],'name':title,'result':end['result'],'skipped':end['skipped']})
terminal=[e for e in events if e.get('type')=='done']
errors=[e for e in events if e.get('type')=='error']
raw_pattern=re.compile(r'Unhandled\s+(?:exception|error)|Uncaught\s+(?:exception|error)|EXCEPTION CAUGHT BY|Segmentation fault|SIGSEGV|Exception caught by widgets library|^\[ERROR:|^Error:',re.I|re.M)
raw_messages=[e for e in events if e.get('type')=='print' and raw_pattern.search(str(e.get('message','')))]
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
source=load(run/'frozen-source.json.gz')
guards={
 'exit_zero':json.loads((target/'process-exit.json').read_text())['exit_code']==0,
 'no_timeout':json.loads((target/'process-exit.json').read_text())['timed_out'] is False,
 'one_successful_terminal':len(terminal)==1 and terminal[0]['success'] is True,
 'suite_paths_exact_after_resolving_relative_to_test_cwd':set(actual_paths)==set(expected_paths),
 'suite_ids_paths_unique':len(suites)==len({s['id'] for s in suites})==len(set(actual_paths))==41,
 'every_started_test_completed_once':len(starts)==len(started) and set(starts)==set(finish) and all(n==1 for n in finish.values()),
 'every_actual_case_passed':len(cases)>0 and all(c['result']=='success' and not c['skipped'] for c in cases),
 'no_json_errors':not errors,
 'no_raw_runtime_errors':not raw_messages,
 'empty_stderr':not (target/'stderr.log').read_text().strip(),
 'frozen_source_before_after_exact':source==load(target/'source-before.json.gz')==load(target/'source-after.json.gz')==load(run/'final-source.json.gz'),
 'environment_before_after_exact':json.loads((run/'environment-before.json').read_text())==json.loads((run/'environment-after.json').read_text()),
 'v1_runner_bytes_match_original_execution':hashlib.sha256((root/'run_qualification_v1.py').read_bytes()).hexdigest()==json.loads((run/'run.json').read_text())['runner_sha256'],
}
receipt={'status':'passed' if all(guards.values()) else 'failed','correction':'Audit-only correction: suite paths supplied by package:test are relative to the recorded test-process cwd. Original runner resolved them against its own cwd. Original raw events, process exit, source snapshots, rejection summary and v1 runner bytes remain unchanged. No tests rerun for this correction.','original_rejected_summary':'frozen-final/engine-zotero/summary.json','guards':guards,'passed_cases':len(cases),'selected_suites':len(expected_paths),'source_map_sha256':json.loads((run/'run.json').read_text())['source_map_sha256'],'stdout_sha256':hashlib.sha256((target/'stdout.jsonl').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((target/'stderr.log').read_bytes()).hexdigest(),'audit_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'suite_path_mapping':[{'reported':s['path'],'resolved':p} for s,p in zip(suites,actual_paths)],'terminal':terminal,'errors':errors,'raw_error_messages':raw_messages}
(root/'engine-corrected-audit.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'passed_cases':len(cases),'selected_suites':len(expected_paths),'failed_guards':[k for k,v in guards.items() if not v]}))
assert all(guards.values())
