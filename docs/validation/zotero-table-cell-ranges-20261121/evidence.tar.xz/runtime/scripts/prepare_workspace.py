from pathlib import Path
import hashlib,json,re,shutil,subprocess
root=Path('/workspace/scratch/a4ce103494d8')
source=root/'quds_office_suite'
workspace=root/'quds-validation'
runtime=root/'runtime-setup'
members=re.findall(r'^  - (\S+)\s*$',(source/'pubspec.yaml').read_text().split('\nworkspace:\n',1)[1],re.M)
workspace.mkdir(exist_ok=True)
for member in members:(workspace/member).mkdir(parents=True,exist_ok=True)
manifests=['pubspec.yaml']+[p+'/pubspec.yaml' for p in members]
for path in manifests:shutil.copy2(source/path,workspace/path)
skip={'.git','.dart_tool','build','pubspec.yaml','pubspec.lock','pubspec_overrides.yaml'}
links={}
for member in members:
 for child in (source/member).iterdir():
  target=workspace/member/child.name
  if child.name in skip:continue
  if target.exists() or target.is_symlink():
   if target.is_symlink():
    assert target.resolve()==child.resolve(),target
    links[str(target.relative_to(workspace))]=str(child)
   continue
  target.symlink_to(child,target_is_directory=child.is_dir())
  links[str(target.relative_to(workspace))]=str(child)
for name in ['analysis_options.yaml','third_party']:
 target=workspace/name
 if not target.exists():target.symlink_to(source/name,target_is_directory=(source/name).is_dir())
shutil.copy2(source/'pubspec.lock',workspace/'pubspec.lock')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'members':members,'manifests_sha256':{p:sha(source/p) for p in manifests},'links':links,'lock_source':str(source/'pubspec.lock'),'lock_sha256':sha(source/'pubspec.lock'),'workspace':str(workspace)}
(runtime/'setup/workspace-prepared.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'members':len(members),'live_links':len(links),'lock_sha256':receipt['lock_sha256'],'workspace':str(workspace)},indent=2))
