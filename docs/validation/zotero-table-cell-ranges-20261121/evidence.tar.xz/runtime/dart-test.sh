#!/usr/bin/env bash
set -euo pipefail
source /workspace/scratch/a4ce103494d8/runtime-setup/env.sh
exec /workspace/scratch/a4ce103494d8/runtime-setup/flutter-sdk/bin/cache/dart-sdk/bin/dart --packages=/workspace/scratch/a4ce103494d8/quds-validation/.dart_tool/package_config.json /workspace/scratch/a4ce103494d8/runtime-setup/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart "$@"
