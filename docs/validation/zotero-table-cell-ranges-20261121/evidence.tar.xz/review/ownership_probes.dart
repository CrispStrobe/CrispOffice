import 'dart:convert';
import 'dart:io';

import 'package:quds_office_engine/quds_office_engine.dart';

WmlParagraph p(String text) => WmlParagraph(inlines: [WmlRun(text: text)]);

final class Fixture {
  Fixture({bool nested = true, bool covariant = false}) {
    first = p('First remove');
    last = p('remove Last');
    leaf = WmlTableCell(
      blocks: covariant
          ? <WmlParagraph>[first, last]
          : <WmlBlock>[first, last],
    );
    row = WmlTableRow(cells: [leaf, WmlTableCell(blocks: [p('Neighbour')])]);
    table = WmlTable(grid: [100, 100], rows: [row]);
    outerCell = WmlTableCell(blocks: [table]);
    outerRow = WmlTableRow(cells: [outerCell]);
    outerTable = WmlTable(grid: [200], rows: [outerRow]);
    section = WmlSection(blocks: [nested ? outerTable : table]);
    document = WmlDocument(sections: [section]);
  }

  late final WmlParagraph first;
  late final WmlParagraph last;
  late final WmlTableCell leaf;
  late final WmlTableRow row;
  late final WmlTable table;
  late final WmlTableCell outerCell;
  late final WmlTableRow outerRow;
  late final WmlTable outerTable;
  late final WmlSection section;
  late final WmlDocument document;

  WordZoteroCitingSession session() => WordZoteroCitingSession(
    document: document,
    documentId: 'probe',
    insertionParagraph: first,
    insertionEndParagraph: last,
    insertionOffset: 6,
    insertionEndOffset: 6,
  );
}

void check(bool value, String reason) {
  if (!value) throw StateError(reason);
}

void stage(WordZoteroCitingSession session, [String html = '<p>New</p>']) {
  session.handle('Document.insertText', ['probe', html]);
  session.handle('Document.complete', ['probe']);
}

void refusal(void Function() action) {
  try {
    action();
  } on StateError {
    return;
  } on UnsupportedError {
    return;
  }
  throw StateError('The unsafe operation was accepted');
}

void main() {
  final results = <Map<String, Object>>[];
  void probe(String name, void Function() body) {
    try {
      body();
      results.add({'name': name, 'passed': true});
    } catch (error, stack) {
      results.add({'name': name, 'passed': false, 'error': '$error', 'stack': '$stack'});
    }
  }

  probe('nested leaf changes only its own paragraphs', () {
    final f = Fixture();
    final originalList = f.leaf.blocks;
    final neighbour = f.row.cells.last;
    final session = f.session();
    check(session.canInsertNoteText, 'Nested ordinary leaf must be supported');
    stage(session, '<p>New</p><p>Second</p>');
    session.apply();
    check(identical(f.leaf.blocks, originalList), 'Leaf list identity changed');
    check(identical(f.row.cells.last, neighbour), 'Neighbour identity changed');
    check(neighbour.blocks.single is WmlParagraph &&
        (neighbour.blocks.single as WmlParagraph).text == 'Neighbour', 'Neighbour changed');
    check(f.leaf.blocks.cast<WmlParagraph>().map((p) => p.text).join('|') ==
        'First New|Second Last', 'Unexpected replacement text');
    check(f.outerCell.blocks.single == f.table, 'Nested owner changed');
    final reopened = WordDeserializer().readBytes(WordSerializer().writeBytes(f.document));
    check(reopened.paragraphs.map((p) => p.text).join('|') ==
        'First New|Second Last|Neighbour', 'Nested DOCX reopen changed content');
  });

  final ownerMutations = <String, void Function(Fixture)>{
    'root section replaced': (f) {
      f.document.sections[0] = WmlSection(blocks: f.section.blocks);
    },
    'root block list replaced': (f) {
      f.section.blocks = List<WmlBlock>.of(f.section.blocks);
    },
    'outer table replaced': (f) {
      f.section.blocks[0] = WmlTable(grid: [200], rows: f.outerTable.rows);
    },
    'outer row replaced': (f) {
      f.outerTable.rows[0] = WmlTableRow(cells: f.outerRow.cells);
    },
    'outer cell replaced': (f) {
      f.outerRow.cells[0] = WmlTableCell(blocks: f.outerCell.blocks);
    },
    'inner table replaced': (f) {
      f.outerCell.blocks[0] = WmlTable(grid: [100, 100], rows: f.table.rows);
    },
    'leaf owner replaced': (f) {
      f.row.cells[0] = WmlTableCell(blocks: f.leaf.blocks);
    },
    'leaf block list replaced': (f) {
      f.leaf.blocks = List<WmlBlock>.of(f.leaf.blocks);
    },
  };
  for (final entry in ownerMutations.entries) {
    for (final when in ['before staging', 'after complete']) {
      probe('${entry.key} $when is stale despite unchanged flat flow', () {
        final f = Fixture();
        final session = f.session();
        if (when == 'after complete') stage(session);
        entry.value(f);
        refusal(() {
          if (when == 'before staging') stage(session);
          session.apply();
        });
        check(f.first.text == 'First remove' && f.last.text == 'remove Last',
            'Rejection changed selected text');
        check(!f.document.paragraphs.any((p) => p.text.contains('New')),
            'Rejection published inserted paragraphs');
      });
    }
  }

  probe('outer vertical continuation refuses nested leaf range', () {
    final f = Fixture();
    f.outerCell.vMerge = WmlVMerge.cont;
    check(!f.session().canInsertNoteText, 'Continuation ancestry was accepted');
  });

  probe('selected paragraphs also owned by a frame refuse', () {
    final f = Fixture(nested: false);
    f.section.blocks.add(WmlFrame(blocks: f.leaf.blocks));
    check(!f.session().canInsertNoteText, 'Skipped story alias was accepted');
  });

  probe('leaf list with a covariant paragraph element type accepts heading payload', () {
    final f = Fixture(nested: false, covariant: true);
    final session = f.session();
    check(session.canInsertNoteText, 'Ordinary covariant cell was rejected');
    stage(session, '<h2>Heading</h2><p>New</p>');
    session.apply();
    check(f.leaf.blocks.whereType<WmlParagraph>().map((p) => p.text).join('|') ==
        'First |Heading|New| Last', 'Covariant replacement did not retain fragments');
    check(f.row.cells.last.blocks.single is WmlParagraph, 'Neighbour was changed');
  });

  probe('incoming table refuses without changing existing leaf', () {
    final f = Fixture();
    final session = f.session();
    check(session.canInsertNoteText, 'Baseline target was rejected');
    refusal(() => stage(session, '<table><tr><td>New</td></tr></table>'));
    check(f.leaf.blocks.length == 2 && f.first.text == 'First remove' &&
        f.last.text == 'remove Last', 'Rejected incoming table changed existing cell');
  });

  stdout.writeln(jsonEncode({'probes': results.length,
    'passed': results.where((result) => result['passed'] == true).length,
    'results': results}));
  if (results.any((result) => result['passed'] == false)) exitCode = 1;
}
