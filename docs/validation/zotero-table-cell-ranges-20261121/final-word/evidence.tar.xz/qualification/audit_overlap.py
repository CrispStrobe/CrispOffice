#!/usr/bin/env python3
"""Audit the final Word-source replay without adding repeated case counts."""
from pathlib import Path
import argparse,collections,gzip,hashlib,json
parser=argparse.ArgumentParser();parser.add_argument('--run-name',required=True);args=parser.parse_args()
BASE=Path('/workspace/scratch/a4ce103494d8/cell-validation');CURRENT=BASE/'final-word'/args.run_name
repo=Path('/workspace/scratch/a4ce103494d8/quds_office_suite')
def read(p):return json.loads(p.read_text())
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def identities(folder):
 cmd=read(folder/'command.json');cwd=Path(cmd['cwd']);result=[]
 for c in packed(folder/'cases.json.gz'):
  assert c['result']=='success' and not c['skipped']
  path=Path(c['suite']);path=(path if path.is_absolute() else cwd/path).resolve()
  result.append((str(path.relative_to(repo)),c['name']))
 assert len(result)==len(set(result))
 return result
summary=read(CURRENT/'summary.json');binding=read(CURRENT/'source-commit-binding.json')
assert summary['status']=='passed' and summary['total_passed']==39 and summary['total_suites']==2
assert binding['all_recorded_inputs_match_commit'] and summary['source_unchanged'] and summary['environment_unchanged']
actual=identities(CURRENT/'engine-fidelity')
suites={p for p,n in actual}
assert suites=={'packages/quds_office_engine/test/word_table_grid_addressing_test.dart','packages/quds_office_engine/test/word_bookmark_fidelity_test.dart'}
original_plan=read(BASE/'selection.json');selected={c['package']+'/'+p for c in original_plan['cohorts'] for p in c['tests']}
assert len(selected)==119 and suites<=selected
original={c for c in identities(BASE/'frozen-remaining/engine-owner-fidelity') if c[0] in suites}
intermediate=set(identities(BASE/'combined-main/frozen-5289b90/engine-fidelity'))
assert set(actual)==original==intermediate and len(actual)==39
old_source=packed(BASE/'combined-main/frozen-5289b90/frozen-source.json.gz');new_source=packed(CURRENT/'frozen-source.json.gz')
changed=[p for p in sorted(set(old_source)|set(new_source)) if old_source.get(p)!=new_source.get(p)]
expected_changes=['packages/quds_office_engine/lib/src/automation/operations/word_header_footer_guard.dart','packages/quds_office_engine/test/office_macro_word_headers_footers_test.dart']
assert changed==expected_changes,changed
report={
 'status':'passed','frozen_commit':binding['commit'],'frozen_git_tree':binding['git_tree'],
 'source_input_count':summary['source_input_count'],'source_map_sha256':summary['source_map_sha256'],
 'source_unchanged':summary['source_unchanged'],'environment_unchanged':summary['environment_unchanged'],
 'actual_passed':summary['total_passed'],'failed':summary['total_failed'],'skipped':summary['total_skipped'],'suite_count':2,
 'case_counts_by_suite':dict(sorted(collections.Counter(p for p,n in actual).items())),
 'prior_overlap':{'original_119_suites':39,'intermediate_151_case_run':39,'all_suite_and_name_identities_match':True,'new_distinct_test_cases':0},
 'source_changes_since_5289b90':changed,'all_other_recorded_input_paths_and_bytes_identical':True,
 'scope':'Source-bound replay of two existing engine fidelity suites after the final Word guard changes. Original 2551 and intermediate 151 evidence remain separate and unchanged. No Studio or Mail tests were rerun in this cohort.',
 'runner_sha256':hashlib.sha256((BASE/'final-word/run_qualification.py').read_bytes()).hexdigest(),
 'summary_sha256':hashlib.sha256((CURRENT/'summary.json').read_bytes()).hexdigest(),
}
(BASE/'final-word/replay-qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
