#!/usr/bin/env python3
"""Run original test files and bind exact source bytes to retained raw events."""
from __future__ import annotations
import argparse, collections, datetime, gzip, hashlib, json, os, re, signal, subprocess, sys, time
from pathlib import Path

ROOT=Path('/workspace/scratch/a4ce103494d8')
BASE=ROOT/'cell-validation'/'final-word'
PLAN=BASE/'selection.json'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run-name',required=True)
parser.add_argument('--cohort',action='append',default=[])
args=parser.parse_args()
assert re.fullmatch(r'[A-Za-z0-9_.-]+',args.run_name)
plan=json.loads(PLAN.read_text())
repo=Path(plan['repo']); workspace=Path(plan['workspace']); runtime=Path(plan['runtime']); sdk=runtime/'flutter-sdk'
cohorts=[c for c in plan['cohorts'] if not args.cohort or c['name'] in args.cohort]
assert cohorts and (not args.cohort or set(args.cohort)=={c['name'] for c in cohorts})
out=BASE/args.run_name
out.mkdir(exist_ok=False)

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(x): return (json.dumps(x,sort_keys=True,separators=(',',':'))+'\n').encode()
def write(path,value): path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def packed(path,value): path.write_bytes(gzip.compress(canonical(value),mtime=0))
def head(): return subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
def record(path):
 b=path.read_bytes()
 return {'size':len(b),'sha256':sha(b),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'executable':bool(path.stat().st_mode&0o111)}
def source_snapshot():
 output=subprocess.check_output(['rg','--files','packages','third_party'],cwd=repo,text=True)
 paths=set()
 for p in output.splitlines():
  q=Path(p)
  if any(s in q.parts for s in ('.dart_tool','build','docs')): continue
  if q.suffix=='.dart' or q.name in ('pubspec.yaml','pubspec.lock','analysis_options.yaml') or '/test/fixtures/' in p or (p.startswith('packages/quds_office_engine/example/macros/') and q.suffix=='.bas'):
   paths.add(p)
 for p in ('pubspec.yaml','pubspec.lock','analysis_options.yaml'): 
  if (repo/p).is_file(): paths.add(p)
 return {p:record(repo/p) for p in sorted(paths)}
def environment_snapshot():
 paths={
  'workspace/package_config.json':workspace/'.dart_tool/package_config.json',
  'workspace/package_graph.json':workspace/'.dart_tool/package_graph.json',
  'workspace/pubspec.yaml':workspace/'pubspec.yaml',
  'workspace/pubspec.lock':workspace/'pubspec.lock',
  'runtime/env.sh':runtime/'env.sh',
  'runtime/dart-test.sh':runtime/'dart-test.sh',
  'sdk/flutter_tools/package_config.json':sdk/'packages/flutter_tools/.dart_tool/package_config.json',
  'sdk/flutter_tools/pubspec.lock':sdk/'packages/flutter_tools/pubspec.lock',
 }
 for p in ('bin/cache/dart-sdk/bin/dart','bin/cache/dart-sdk/bin/dartvm','bin/cache/dart-sdk/bin/dartaotruntime','bin/cache/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot','bin/cache/flutter_tools.snapshot','bin/cache/artifacts/engine/linux-x64/flutter_tester'):
  paths['sdk/'+p]=sdk/p
 for member in json.loads((runtime/'setup/workspace-prepared.json').read_text())['members']:
  paths['workspace/'+member+'/pubspec.yaml']=workspace/member/'pubspec.yaml'
 return {k:record(v) for k,v in sorted(paths.items()) if v.is_file()}

def audit(stdout,stderr,expected_tests,cwd):
 events=[]; invalid=[]
 for i,line in enumerate(stdout.read_text(errors='replace').splitlines(),1):
  if not line.strip(): continue
  try:
   value=json.loads(line)
   if not isinstance(value,dict): raise ValueError('not an event object')
   events.append(value)
  except (ValueError,json.JSONDecodeError): invalid.append({'line':i,'text':line})
 starts={}; duplicates=[]; suites={}; completions=[]
 for e in events:
  if e.get('type')=='testStart':
   t=e['test']; key=t['id']
   if key in starts: duplicates.append(key)
   starts[key]=t
  elif e.get('type')=='suite': suites[e['suite']['id']]=e['suite']
  elif e.get('type')=='done': completions.append(e)
 finishes=[e for e in events if e.get('type')=='testDone']
 finish_counts=collections.Counter(e['testID'] for e in finishes)
 cases=[]; excluded=[]
 for e in finishes:
  t=starts.get(e['testID'],{})
  s=suites.get(t.get('suiteID'),{})
  item={'id':e['testID'],'name':t.get('name'),'suite':s.get('path'),'result':e.get('result'),'skipped':bool(e.get('skipped'))}
  if e.get('hidden') or re.search(r'(?:^|\s)\(?setUpAll\)?$|(?:^|\s)\(?tearDownAll\)?$',t.get('name','')):
   item['reason']='hidden loading/setup/teardown event' if e.get('hidden') else 'suite setup/teardown event'
   excluded.append(item)
  else: cases.append(item)
 actual={str((Path(s['path']) if Path(s['path']).is_absolute() else cwd/s['path']).resolve()) for s in suites.values() if s.get('path')}
 expected={str((cwd/p).resolve()) for p in expected_tests}
 errors=[e for e in events if e.get('type')=='error']
 raw_pattern=re.compile(r'Unhandled\s+(?:exception|error)|Uncaught\s+(?:exception|error)|EXCEPTION CAUGHT BY|Segmentation fault|SIGSEGV|Exception caught by widgets library|^\[ERROR:|^Error:',re.I|re.M)
 raw_messages=[]
 for e in events:
  if e.get('type')=='print' and raw_pattern.search(str(e.get('message',''))): raw_messages.append(e)
 stderr_text=stderr.read_text(errors='replace')
 guards={
  'one_successful_terminal_event':len(completions)==1 and completions[0].get('success') is True,
  'all_selected_suites_reported':actual==expected,
  'no_duplicate_start_ids':not duplicates,
  'every_started_test_completed_once':set(starts)==set(finish_counts) and all(v==1 for v in finish_counts.values()),
  'all_cases_passed':bool(cases) and all(c['result']=='success' for c in cases),
  'no_unexplained_skips':not any(c['skipped'] for c in cases),
  'no_json_runtime_errors':not errors,
  'no_non_json_stdout':not invalid,
  'no_raw_runtime_error_messages':not raw_messages and not raw_pattern.search(stderr_text),
  'empty_stderr':not stderr_text.strip(),
 }
 return {'guards':guards,'counts':{'passed':sum(c['result']=='success' and not c['skipped'] for c in cases),'failed':sum(c['result']!='success' for c in cases),'skipped':sum(c['skipped'] for c in cases),'cases':len(cases),'suites':len(actual),'excluded_loading_setup_teardown':len(excluded),'json_errors':len(errors)},'cases':cases,'excluded_events':excluded,'errors':errors,'invalid_stdout':invalid,'raw_error_messages':raw_messages,'stderr_bytes':stderr.stat().st_size,'completion':completions,'missing_suites':sorted(expected-actual),'unexpected_suites':sorted(actual-expected),'events':len(events)}

env=dict(os.environ)
env.update({'PATH':str(sdk/'bin')+os.pathsep+env['PATH'],'PUB_CACHE':str(runtime/'pub-cache'),'FLUTTER_ROOT':str(sdk),'TMPDIR':str(runtime/'tmp'),'XDG_CONFIG_HOME':str(runtime/'config'),'XDG_DATA_HOME':str(runtime/'data'),'XDG_CACHE_HOME':str(runtime/'cache'),'DASH__SUPPRESS_ANALYTICS':'true','DART_SUPPRESS_ANALYTICS':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','CI':'true'})
source=source_snapshot(); environment=environment_snapshot(); started=now()
assert head()==plan['frozen_commit'], 'HEAD differs from authorized checkpoint'
git_inputs={}
for line in subprocess.check_output(['git','ls-tree','-r',plan['frozen_commit']],cwd=repo,text=True).splitlines():
 entry,path=line.split('\t',1); mode,kind,oid=entry.split()
 if kind=='blob': git_inputs[path]={'git_blob_sha1':oid,'executable':mode=='100755'}
commit_mismatches=[p for p,v in source.items() if git_inputs.get(p)!={'git_blob_sha1':v['git_blob_sha1'],'executable':v['executable']}]
write(out/'source-commit-binding.json',{'commit':plan['frozen_commit'],'git_tree':plan['frozen_git_tree'],'recorded_input_count':len(source),'all_recorded_inputs_match_commit':not commit_mismatches,'mismatches':commit_mismatches})
assert not commit_mismatches, 'Recorded source inputs differ from frozen Git tree'
packed(out/'frozen-source.json.gz',source); write(out/'environment-before.json',environment)
write(out/'selection.json',{**plan,'cohorts':cohorts})
write(out/'run.json',{'status':'running','started_utc':started,'source_head_at_start':head(),'source_map_sha256':sha(canonical(source)),'source_input_count':len(source),'runner_sha256':sha(Path(__file__).read_bytes()),'selection_sha256':sha(PLAN.read_bytes()),'source_scope':plan['source_binding'],'working_tree_status_at_start':subprocess.check_output(['git','status','--porcelain=v1'],cwd=repo,text=True),'environment':{k:env[k] for k in ('PUB_CACHE','FLUTTER_ROOT','TMPDIR','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_CACHE_HOME','DASH__SUPPRESS_ANALYTICS','DART_SUPPRESS_ANALYTICS','FLUTTER_SUPPRESS_ANALYTICS','CI')},'cohorts':[c['name'] for c in cohorts]})
results=[]
for c in cohorts:
 dest=out/c['name']; dest.mkdir(); cwd=workspace/c['package']; before=source_snapshot()
 packed(dest/'source-before.json.gz',before)
 if before!=source:
  write(dest/'summary.json',{'status':'not-run-source-changed','source_matches_freeze':False})
  print(json.dumps({'cohort':c['name'],'status':'not-run-source-changed'}),flush=True)
  results.append({'name':c['name'],'status':'failed','reason':'source changed before cohort'}); break
 if c['runner']=='dart':
  command=[str(runtime/'dart-test.sh'),'--reporter','json','--concurrency',str(c['concurrency']),'--timeout',c['test_timeout'],*c['tests']]
 else:
  command=[str(sdk/'bin/flutter'),'test','--no-pub','--reporter','json','--concurrency',str(c['concurrency']),'--timeout',c['test_timeout'],*c['tests']]
 info={'name':c['name'],'started_utc':now(),'command':command,'cwd':str(cwd),'source_head_before':head(),'source_map_sha256':sha(canonical(before)),'selected_test_files':[c['package']+'/'+p for p in c['tests']],'process_timeout_seconds':c['process_timeout_seconds']}
 write(dest/'command.json',info)
 print(json.dumps({'cohort':c['name'],'status':'started','suites':len(c['tests'])}),flush=True)
 begin=time.monotonic(); timeout=False
 with (dest/'stdout.jsonl').open('wb') as stdout,(dest/'stderr.log').open('wb') as stderr:
  process=subprocess.Popen(command,cwd=cwd,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  write(dest/'process.json',{'pid':process.pid,'started_utc':now()})
  try: code=process.wait(timeout=c['process_timeout_seconds'])
  except subprocess.TimeoutExpired:
   timeout=True; os.killpg(process.pid,signal.SIGTERM)
   try: code=process.wait(timeout=10)
   except subprocess.TimeoutExpired:
    os.killpg(process.pid,signal.SIGKILL); code=process.wait()
 elapsed=time.monotonic()-begin
 write(dest/'process-exit.json',{'exit_code':code,'timed_out':timeout,'elapsed_seconds':elapsed,'finished_utc':now()})
 after=source_snapshot(); packed(dest/'source-after.json.gz',after)
 report=audit(dest/'stdout.jsonl',dest/'stderr.log',c['tests'],cwd)
 report['guards'].update({'process_exit_zero':code==0,'no_process_timeout':not timeout,'source_matches_freeze_before':before==source,'source_matches_freeze_after':after==source})
 passed=all(report['guards'].values())
 packed(dest/'cases.json.gz',report.pop('cases')); packed(dest/'excluded-events.json.gz',report.pop('excluded_events'))
 summary={**info,**report,'status':'passed' if passed else 'failed','finished_utc':now(),'elapsed_seconds':elapsed,'exit_code':code,'source_head_after':head(),'stdout_sha256':sha((dest/'stdout.jsonl').read_bytes()),'stderr_sha256':sha((dest/'stderr.log').read_bytes())}
 write(dest/'summary.json',summary)
 results.append({'name':c['name'],'status':summary['status'],'counts':summary['counts'],'summary':c['name']+'/summary.json'})
 print(json.dumps(results[-1]),flush=True)
 if not passed:
  print(json.dumps({'failed_guards':[k for k,v in report['guards'].items() if not v],'errors':report['errors'],'raw_error_messages':report['raw_error_messages'],'stderr_bytes':report['stderr_bytes']}),flush=True)
  break
final_source=source_snapshot(); final_environment=environment_snapshot()
packed(out/'final-source.json.gz',final_source); write(out/'environment-after.json',final_environment)
accepted=len(results)==len(cohorts) and all(r['status']=='passed' for r in results) and final_source==source and final_environment==environment
summary={'status':'passed' if accepted else 'failed','started_utc':started,'finished_utc':now(),'source_head_at_end':head(),'source_map_sha256':sha(canonical(source)),'source_input_count':len(source),'source_unchanged':final_source==source,'environment_unchanged':final_environment==environment,'cohorts':results,'selected_cohort_count':len(cohorts),'completed_cohort_count':len(results),'total_passed':sum(r.get('counts',{}).get('passed',0) for r in results),'total_failed':sum(r.get('counts',{}).get('failed',0) for r in results),'total_skipped':sum(r.get('counts',{}).get('skipped',0) for r in results),'total_suites':sum(r.get('counts',{}).get('suites',0) for r in results),'counts_are_disjoint':True,'runtime_smokes_or_development_runs_included':False}
write(out/'summary.json',summary)
print(json.dumps({'final':summary}),flush=True)
sys.exit(0 if accepted else 1)
