#!/usr/bin/env python3
"""Cross-check supplemental actual cases against the original 119-suite record."""
from pathlib import Path
import collections, gzip, hashlib, json
BASE=Path('/workspace/scratch/a4ce103494d8/cell-validation')
CURRENT=BASE/'combined-main'/'frozen-5289b90'
repo=Path('/workspace/scratch/a4ce103494d8/quds_office_suite')
def read(p):return json.loads(p.read_text())
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def identities(folder):
 cmd=read(folder/'command.json'); cwd=Path(cmd['cwd']); result=[]
 for c in packed(folder/'cases.json.gz'):
  assert c['result']=='success' and not c['skipped']
  path=Path(c['suite']);path=(path if path.is_absolute() else cwd/path).resolve()
  result.append((str(path.relative_to(repo)),c['name']))
 assert len(result)==len(set(result)), 'duplicate suite/name case identities'
 return result
original=read(BASE/'qualification.json')
assert original['status']=='passed' and original['totals']['passed']==2551
prior=[]
for c in original['cohorts']:prior.extend(identities(BASE/c['execution_directory']))
assert len(prior)==2551 and len(set(prior))==2551
plan=read(BASE/'selection.json')
selected_original={c['package']+'/'+p for c in plan['cohorts'] for p in c['tests']}
assert len(selected_original)==119
summary=read(CURRENT/'summary.json'); assert summary['status']=='passed'
supplemental=[]; by_cohort={}
for c in summary['cohorts']:
 rows=identities(CURRENT/c['name']); by_cohort[c['name']]=rows;supplemental.extend(rows)
assert len(set(supplemental))==len(supplemental)==summary['total_passed']
expected_repeated_suites={
 'packages/quds_office_engine/test/word_table_grid_addressing_test.dart',
 'packages/quds_office_engine/test/word_bookmark_fidelity_test.dart',
 'packages/quds_office_editor/example/test/studio_zotero_citing_transport_test.dart',
 'packages/quds_office_editor/example/test/studio_zotero_shortcuts_test.dart',
}
assert expected_repeated_suites <= selected_original
repeated=set(prior)&set(supplemental)
expected={row for row in prior if row[0] in expected_repeated_suites}
assert repeated==expected and len(repeated)==72
assert set(by_cohort['engine-fidelity'])|set(by_cohort['studio-zotero'])==expected
new_regression=('packages/quds_office_editor/example/test/studio_saved_mail_test.dart','saved and account Mail views each expose one localized Close')
assert supplemental.count(new_regression)==1
binding=read(CURRENT/'source-commit-binding.json');assert binding['all_recorded_inputs_match_commit']
report={
 'status':'passed','frozen_commit':binding['commit'],'frozen_git_tree':binding['git_tree'],
 'source_input_count':summary['source_input_count'],'source_map_sha256':summary['source_map_sha256'],
 'source_unchanged':summary['source_unchanged'],'environment_unchanged':summary['environment_unchanged'],
 'suite_count':summary['total_suites'],'actual_passed':summary['total_passed'],'failed':summary['total_failed'],'skipped':summary['total_skipped'],
 'case_counts_by_suite':dict(sorted(collections.Counter(path for path,name in supplemental).items())),
 'original_population':{'selected_suites':119,'accepted_distinct_cases':2551,'cases_rechecked_here':72,'all_72_suite_and_name_identities_match':True,'selected_suite_paths_match_original_plan':True},
 'global_close_regression':{'suite':new_regression[0],'case':new_regression[1],'actual_successful_executions':1},
 'counting_limits':['The 72 repeated engine/Studio Zotero cases must not be added to the original2551 as new distinct cases.','The two Mail suites include pre-existing cases; only one new regression was added here. The Mail workspace suite also overlaps incoming Mail qualification, so no cross-archive distinct total is claimed.','Loading, setup and teardown events are excluded from case totals.'],
 'runner_sha256':hashlib.sha256((BASE/'combined-main/run_qualification.py').read_bytes()).hexdigest(),
 'original_qualification_sha256':hashlib.sha256((BASE/'qualification.json').read_bytes()).hexdigest(),
 'supplemental_summary_sha256':hashlib.sha256((CURRENT/'summary.json').read_bytes()).hexdigest(),
}
(BASE/'combined-main/supplemental-qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
