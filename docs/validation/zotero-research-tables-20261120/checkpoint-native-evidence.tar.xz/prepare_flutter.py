#!/usr/bin/env python3
import hashlib,json,tarfile,time,urllib.request
from pathlib import Path
ROOT=Path('/workspace/scratch/a17412353cf6/runtime')
URL='https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.47.8-stable.tar.xz'
EXPECTED='baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2'
class Hashed:
 def __init__(self,source):self.source=source;self.digest=hashlib.sha256();self.bytes=0
 def read(self,size=-1):
  data=self.source.read(size);self.digest.update(data);self.bytes+=len(data);return data
def wanted(name):
 if name.startswith('flutter/.git/'):return True
 if name.startswith('flutter/packages/'):return True
 if name.startswith('flutter/bin/cache/artifacts/engine/'):
  return any(name.startswith('flutter/bin/cache/artifacts/engine/'+prefix) for prefix in ['linux-x64/','common/'])
 if name.startswith('flutter/bin/cache/artifacts/'):return False
 if name.startswith('flutter/bin/cache/dart-sdk/'):return True
 if name.startswith('flutter/bin/cache/pkg/'):return True
 if name.startswith('flutter/bin/cache/'):
  return '/' not in name[len('flutter/bin/cache/'):]
 if name.startswith('flutter/bin/'):return True
 return name in ['flutter/version','flutter/LICENSE','flutter/README.md','flutter/pubspec.yaml','flutter/pubspec.lock','flutter/analysis_options.yaml']
start=time.monotonic();members=[];embedded=[];skipped=0
with urllib.request.urlopen(URL,timeout=120) as source:
 hashed=Hashed(source)
 with tarfile.open(fileobj=hashed,mode='r|xz') as bundle:
  for item in bundle:
   if not wanted(item.name):skipped+=1;continue
   if item.isdir():continue
   if not item.isfile():
    # SDK symlinks/hardlinks, if any, are restored by tar's data filter.
    bundle.extract(item,ROOT,filter='data');continue
   data=bundle.extractfile(item).read()
   sha=hashlib.sha256(data).hexdigest()
   if item.name.startswith('flutter/bin/cache/dart-sdk/'):
    relative=item.name[len('flutter/bin/cache/dart-sdk/'):]
    target=ROOT/'dart-sdk'/relative
    if target.exists():
     assert hashlib.sha256(target.read_bytes()).hexdigest()==sha,relative
    else:
     target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);target.chmod(item.mode)
    embedded.append({'path':relative,'sha256':sha,'bytes':len(data)})
    continue
   target=ROOT/item.name
   assert target.is_relative_to(ROOT)
   target.parent.mkdir(parents=True,exist_ok=True)
   target.write_bytes(data);target.chmod(item.mode)
   members.append({'path':item.name,'sha256':sha,'bytes':len(data)})
 while hashed.read(8*1024*1024):pass
 assert hashed.digest.hexdigest()==EXPECTED,hashed.digest.hexdigest()
(ROOT/'flutter/bin/cache/dart-sdk').symlink_to(ROOT/'dart-sdk',target_is_directory=True)
receipt={'url':URL,'archive_sha256':EXPECTED,'archive_bytes':hashed.bytes,
 'selected_members':members,'embedded_dart_members_verified':embedded,
 'skipped_members':skipped,'seconds':time.monotonic()-start,'substitutions':[]}
(ROOT/'flutter-sdk-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'ready':True,'seconds':receipt['seconds'],'selected':len(members),'dart_verified':len(embedded),'skipped':skipped}),flush=True)
