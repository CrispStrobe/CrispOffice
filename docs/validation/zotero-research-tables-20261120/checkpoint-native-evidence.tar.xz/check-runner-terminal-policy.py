from pathlib import Path
import subprocess,json,hashlib,os
root=Path('/workspace/scratch/a17412353cf6/runtime');out=root/'runner-terminal-policy';out.mkdir(exist_ok=True);layout=out/'layout/packages';tool=layout/'quds_office_editor/example/tool/incoming_reconciliation_acceptance.dart';tool.parent.mkdir(parents=True,exist_ok=True);(layout/'quds_mail_ui').mkdir(exist_ok=True);source=(root/'incoming_reconciliation_acceptance.dart').read_bytes();tool.write_bytes(source)
child=out/'synthetic_reporter.py';child.write_text('''#!/usr/bin/env python3
import os,json,sys
mode=os.environ['REPORTER_CASE']
print('Synthetic completion-policy control; no product tests execute here.')
if mode=='missing': print(json.dumps({'type':'start'}))
elif mode=='malformed': print('{"type":"done", invalid json}')
else:
 print(json.dumps({'type':'done','success':mode!='false'}))
 if mode=='duplicate': print(json.dumps({'type':'done','success':True}))
sys.exit(7 if mode=='nonzero' else 0)
''');child.chmod(0o755);receipts=[]
for mode,expected in [('success',0),('false',1),('missing',1),('duplicate',1),('malformed',1),('nonzero',7)]:
 command=[str(root/'dart-sdk/bin/dart'),str(tool)];env=dict(os.environ,FLUTTER_BIN=str(child),REPORTER_CASE=mode);run=subprocess.run(command,env=env,capture_output=True,text=True,timeout=30);(out/(mode+'.stdout')).write_text(run.stdout);(out/(mode+'.stderr')).write_text(run.stderr);receipts.append({'case':mode,'expectedExit':expected,'actualExit':run.returncode,'matched':run.returncode==expected,'command':command});assert run.returncode==expected,receipts[-1]
(out/'receipt.json').write_text(json.dumps({'scope':'Synthetic reporter control of replay-helper terminal-event policy only; not Flutter product test evidence','runnerSha256':hashlib.sha256(source).hexdigest(),'childSha256':hashlib.sha256(child.read_bytes()).hexdigest(),'cases':receipts},indent=2));print(json.dumps({'matched':len(receipts),'scope':'completion-policy only'}))
