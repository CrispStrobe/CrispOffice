from pathlib import Path
import urllib.request,tarfile,hashlib,json,time
root=Path('/workspace/scratch/a17412353cf6/runtime');url='https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.47.8-stable.tar.xz';expected='baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2'
class Hashed:
 def __init__(self,s):self.s=s;self.hash=hashlib.sha256();self.bytes=0
 def read(self,n=-1):
  data=self.s.read(n);self.hash.update(data);self.bytes+=len(data);return data
members=[];start=time.time()
with urllib.request.urlopen(url,timeout=120) as s:
 stream=Hashed(s)
 with tarfile.open(fileobj=stream,mode='r|xz') as t:
  for item in t:
   if not item.isfile() or not any(item.name.startswith(p) for p in ['flutter/bin/cache/artifacts/gradle_wrapper/','flutter/bin/cache/artifacts/material_fonts/']):continue
   target=root/item.name;data=t.extractfile(item).read();sha=hashlib.sha256(data).hexdigest();target.parent.mkdir(parents=True,exist_ok=True)
   if target.exists():assert hashlib.sha256(target.read_bytes()).hexdigest()==sha,item.name
   else:target.write_bytes(data);target.chmod(item.mode)
   members.append({'path':item.name,'sha256':sha,'bytes':len(data)})
 while stream.read(8*1024*1024):pass
 assert stream.hash.hexdigest()==expected
(root/'universal-artifacts-receipt.json').write_text(json.dumps({'url':url,'archiveSha256':expected,'archiveBytes':stream.bytes,'members':members,'seconds':time.time()-start},indent=2));print(json.dumps({'count':len(members),'seconds':time.time()-start}),flush=True)
