from pathlib import Path
import json,hashlib,collections,tarfile,platform,os,subprocess
root=Path('/workspace/scratch/a17412353cf6');runtime=root/'runtime';repo=root/'quds_office_suite';runs=runtime/'accepted-2d617-native';groups={};all_files={};total=collections.Counter()
for name in ['selection','catalog','selected-stores','native-mail','ews-reply','downloads-theme','reader']:
 d=runs/name;receipt=json.loads((d/'receipt.json').read_text());events=[]
 for line in (d/'tests.jsonl').read_text().splitlines():
  try:events.append(json.loads(line))
  except ValueError:pass
 suites={e['suite']['id']:e['suite']['path'] for e in events if e.get('type')=='suite'};tests={e['test']['id']:e['test'] for e in events if e.get('type')=='testStart'};file_counts={};hidden=0;visible=collections.Counter()
 for e in events:
  if e.get('type')!='testDone':continue
  if e.get('hidden'):hidden+=1;continue
  path=str(Path(suites[tests[e['testID']]['suiteID']]).relative_to(repo));counts=file_counts.setdefault(path,collections.Counter());key='skip' if e.get('skipped') else e['result'];counts[key]+=1;visible[key]+=1
 done=[e for e in events if e.get('type')=='done'];assert receipt['exit']==0 and receipt['jsonSuccess'] and len(done)==1 and done[0]['success'] and not receipt['interrupted'] and receipt['sourceHashesUnchanged'];assert set(visible)=={'success'},visible
 groups[name]={'counts':dict(visible),'hiddenLoadingOrSetupEntriesExcluded':hidden,'terminalEvents':len(done),'exit':receipt['exit'],'jsonSuccess':receipt['jsonSuccess'],'files':{p:dict(c) for p,c in file_counts.items()},'seconds':receipt['seconds'],'peakRssSumKB':receipt['peakRssSumKB']};total.update(visible)
 for p,c in file_counts.items():assert p not in all_files;all_files[p]=dict(c)
summary={'source':'2d617a31bce48a7312f31586f70f7472e3420406','groups':groups,'visibleTotals':dict(total),'originalFileCount':len(all_files),'perFile':all_files,'sourceFileCount':2214,'sourceManifestSha256':hashlib.sha256((runs/'source-manifest.json').read_bytes()).hexdigest(),'allProcessesExitZero':True,'allTerminalEventsSuccess':True,'allSourcesUnchanged':True,'sdk':'Flutter3.47.8 / Dart3.13.7','runner':'Standard Flutter test CLI, original files, concurrency1, seven sequential groups','excludedFromProductCounts':'Hidden loading/setup entries, all negative controls and the synthetic helper completion-policy checks','analysis':'Final analysis has not started; current-main reconciliation is pending.'};(runs/'summary.json').write_text(json.dumps(summary,indent=2))
environment={'platform':platform.platform(),'pythonVersion':platform.python_version(),'filesystemAvailableBytes':os.statvfs(root).f_bavail*os.statvfs(root).f_frsize,'environment':{k:os.environ.get(k) for k in ['TASK_ROOT','PUB_CACHE','TMPDIR','CI','DASH__SUPPRESS_ANALYTICS','FLUTTER_SUPPRESS_ANALYTICS']},'cgroup':{}}
for name in ['/proc/self/cgroup','/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory.current','/sys/fs/cgroup/memory.peak']:
 try:environment['cgroup'][name]=Path(name).read_text()
 except OSError as e:environment['cgroup'][name]={'unavailable':type(e).__name__}
(runtime/'runtime-environment.json').write_text(json.dumps(environment,indent=2))
files=[]
for p in runtime.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.py','.dart'] and p.name not in ['run-targeted-analysis.py','analysis-targets.json'] and not p.name.startswith('checkpoint-'):files.append(p)
for name in ['accepted-2d617-native','callback-controls-2d617','runner-terminal-policy']:
 files.extend(p for p in (runtime/name).rglob('*') if p.is_file())
files=sorted(set(files));manifest={'scope':'Native regression evidence and callback/tooling controls; product acceptance is only the seven standard Flutter CLI groups in accepted-2d617-native','source':summary['source'],'files':[{'path':str(p.relative_to(runtime)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]};manifest_file=runtime/'checkpoint-native-evidence-manifest.json';manifest_file.write_text(json.dumps(manifest,indent=2));files.append(manifest_file);archive=runtime/'checkpoint-native-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as t:
 for p in files:t.add(p,arcname=str(p.relative_to(runtime)),recursive=False)
metadata={'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files),'visibleCounts':dict(total),'originalFiles':len(all_files)};(runtime/'checkpoint-native-evidence.json').write_text(json.dumps(metadata,indent=2));print(json.dumps(metadata));print(json.dumps(summary['perFile'],indent=2))
