import subprocess,json,time,hashlib,os,signal,shutil,sys
from pathlib import Path
ROOT=Path('/workspace/scratch/a17412353cf6'); repo=ROOT/'quds_office_suite'; runtime=ROOT/'runtime'; output=runtime/'accepted-2d617-native'; output.mkdir(exist_ok=True)
names=[p for p in subprocess.check_output(['git','ls-files','--','*.dart'],cwd=repo,text=True).splitlines() if (repo/p).is_file()]
def hashes():return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in names}
def digest(data):return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':')).encode()).hexdigest()
before=hashes(); source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(); (output/'source-manifest.json').write_text(json.dumps(before,indent=2)); example=repo/'packages/quds_office_editor/example'
groups=[
 ('selection',example,['studio_credential_selection_test.dart','studio_credential_selection_race_test.dart']),
 ('catalog',example,['studio_mail_credentials_test.dart','studio_mail_accounts_test.dart','studio_mail_account_catalog_test.dart']),
 ('selected-stores',example,['studio_mail_account_stores_test.dart','studio_mail_selected_store_integration_test.dart']),
 ('native-mail',example,['studio_mail_test.dart']),
 ('ews-reply',example,['studio_mail_ews_test.dart','studio_mail_reply_test.dart']),
 ('downloads-theme',example,['studio_layout_theme_test.dart','studio_downloads_capture_test.dart','studio_downloads_layout_test.dart','studio_downloads_manager_test.dart']),
 ('reader',repo/'packages/quds_mail_ui',['body_presentation_test.dart','reader_theme_scroll_test.dart'])]
for index,(label,cwd,suites) in enumerate(groups):
 if index<int(sys.argv[1] if len(sys.argv)>1 else '0'):continue
 dest=output/label;dest.mkdir(exist_ok=True)
 assert not (dest/'receipt.json').exists(), 'Do not overwrite a completed gate'
 command=[str(runtime/'flutter/bin/flutter'),'test','--no-pub','--reporter=json','--concurrency=1',*['test/'+p for p in suites]]
 start=time.time();monitor=[];interrupted=False
 with (dest/'tests.jsonl').open('w') as stdout,(dest/'stderr.log').open('w') as stderr:
  process=subprocess.Popen(command,cwd=cwd,stdout=stdout,stderr=stderr,start_new_session=True)
  while process.poll() is None:
   rows=[]
   for line in subprocess.check_output(['ps','-eo','pid,ppid,rss,comm'],text=True).splitlines()[1:]:
    parts=line.split(maxsplit=3)
    if len(parts)==4:rows.append({'pid':int(parts[0]),'ppid':int(parts[1]),'rssKB':int(parts[2]),'name':parts[3]})
   ids={process.pid}
   while True:
    expanded=ids|{p['pid'] for p in rows if p['ppid'] in ids}
    if expanded==ids:break
    ids=expanded
   monitor.append({'elapsed':time.time()-start,'processes':[p for p in rows if p['pid'] in ids],'meminfo':Path('/proc/meminfo').read_text()})
   if time.time()-start>1200:
    interrupted=True;os.killpg(process.pid,signal.SIGINT)
    try:process.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL)
    break
   time.sleep(0.5)
  status=process.wait()
 after=hashes();events=[]
 for line in (dest/'tests.jsonl').read_text().splitlines():
  try:events.append(json.loads(line))
  except ValueError:pass
 done=[e for e in events if e.get('type')=='done'];success=bool(done and done[-1].get('success')); counts={}
 for e in events:
  if e.get('type')=='testDone' and not e.get('hidden'):
   k='skip' if e.get('skipped') else e.get('result');counts[k]=counts.get(k,0)+1
 receipt={'source':source,'group':label,'command':command,'cwd':str(cwd),'exit':status,'jsonSuccess':success,'counts':counts,'interrupted':interrupted,'seconds':time.time()-start,'sourceManifestBeforeSha256':digest(before),'sourceManifestAfterSha256':digest(after),'sourceHashesUnchanged':before==after,'sourceFileCount':len(before),'peakRssSumKB':max((sum(p['rssKB'] for p in row['processes']) for row in monitor),default=0)}
 (dest/'receipt.json').write_text(json.dumps(receipt,indent=2));(dest/'memory-monitor.json').write_text(json.dumps(monitor,indent=2));print(json.dumps(receipt),flush=True)
 if status!=0 or not success or before!=after:break
