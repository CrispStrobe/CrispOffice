#!/usr/bin/env python3
import os,json,sys
mode=os.environ['REPORTER_CASE']
print('Synthetic completion-policy control; no product tests execute here.')
if mode=='missing': print(json.dumps({'type':'start'}))
elif mode=='malformed': print('{"type":"done", invalid json}')
else:
 print(json.dumps({'type':'done','success':mode!='false'}))
 if mode=='duplicate': print(json.dumps({'type':'done','success':True}))
sys.exit(7 if mode=='nonzero' else 0)
