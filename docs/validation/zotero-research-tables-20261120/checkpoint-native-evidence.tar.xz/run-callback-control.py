from pathlib import Path
import subprocess,hashlib,json,time
root=Path('/workspace/scratch/a17412353cf6');repo=root/'quds_office_suite';example=repo/'packages/quds_office_editor/example';out=root/'runtime/callback-controls-2d617';out.mkdir(exist_ok=True)
relative='packages/quds_office_editor/example/test/studio_credential_selection_race_test.dart';target=repo/relative;accepted=target.read_bytes();old=subprocess.check_output(['git','show','0e84c635f9e4569d27e5ee76e020d2a88eda0458:'+relative],cwd=repo)
receipts=[]
try:
 for label,data in [('red-original-callback',old),('green-synchronous-callback',accepted)]:
  target.write_bytes(data);command=[str(root/'runtime/flutter/bin/flutter'),'test','--no-pub','--reporter=json','--concurrency=1','--plain-name','an open Mail dialog reloads an externally selected empty store','test/studio_credential_selection_race_test.dart'];start=time.time()
  with (out/(label+'.jsonl')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr: result=subprocess.run(command,cwd=example,stdout=stdout,stderr=stderr,timeout=600,start_new_session=True)
  events=[]
  for line in (out/(label+'.jsonl')).read_text().splitlines():
   try:events.append(json.loads(line))
   except ValueError:pass
  done=[e for e in events if e.get('type')=='done'];receipts.append({'label':label,'source':'2d617a31bce48a7312f31586f70f7472e3420406','path':relative,'testSha256':hashlib.sha256(data).hexdigest(),'testGitBlob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'command':command,'exit':result.returncode,'jsonSuccess':done[-1].get('success') if done else None,'seconds':time.time()-start})
  print(json.dumps(receipts[-1]),flush=True)
finally:
 target.write_bytes(accepted);(out/'receipts.json').write_text(json.dumps({'runs':receipts,'restoredExactly':target.read_bytes()==accepted,'note':'Negative control changes only the test callback. All production bytes are unchanged.'},indent=2))
