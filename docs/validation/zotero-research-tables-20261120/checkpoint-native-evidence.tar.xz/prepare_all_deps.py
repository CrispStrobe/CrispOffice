#!/usr/bin/env python3
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,io,json,tarfile,time,urllib.request,yaml
from pathlib import Path
ROOT=Path('/workspace/scratch/a17412353cf6/runtime');REPO=ROOT.parent/'quds_office_suite'
CACHE=ROOT/'pub-cache';HOST=CACHE/'hosted/pub.dev';HASH=CACHE/'hosted-hashes/pub.dev'
specs=yaml.safe_load((REPO/'pubspec.lock').read_text())['packages'];start=time.monotonic()
def install(pair):
 name,spec=pair
 if spec['source']!='hosted':return None
 key=name+'-'+spec['version'];target=HOST/key;stamp=HASH/(key+'.sha256');expected=spec['description']['sha256']
 assert spec['description']['url']=='https://pub.dev'
 if target.exists() and stamp.exists() and stamp.read_text()==expected:return {'name':name,'version':spec['version'],'sha256':expected,'status':'verified-cache'}
 url='https://pub.dev/api/archives/'+key+'.tar.gz'
 with urllib.request.urlopen(url,timeout=90) as source:data=source.read()
 actual=hashlib.sha256(data).hexdigest();assert actual==expected,(name,actual,expected)
 target.mkdir(parents=True,exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:archive.extractall(target,filter='data')
 stamp.write_text(actual)
 return {'name':name,'version':spec['version'],'sha256':expected,'status':'verified-download','archive_bytes':len(data)}
records=[]
with ThreadPoolExecutor(max_workers=8) as pool:
 for future in as_completed([pool.submit(install,pair) for pair in specs.items()]):
  result=future.result()
  if result:records.append(result)
receipt={'lock_sha256':hashlib.sha256((REPO/'pubspec.lock').read_bytes()).hexdigest(),'packages':sorted(records,key=lambda r:r['name']),'seconds':time.monotonic()-start,'substitutions':[]}
(ROOT/'dependencies-all.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'ready':True,'packages':len(records),'seconds':receipt['seconds']}),flush=True)
