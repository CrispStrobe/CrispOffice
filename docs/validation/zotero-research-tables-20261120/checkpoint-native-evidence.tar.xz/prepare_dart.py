#!/usr/bin/env python3
import hashlib,io,json,urllib.request,zipfile,time
from pathlib import Path
ROOT=Path('/workspace/scratch/a17412353cf6/runtime')
URL='https://storage.googleapis.com/dart-archive/channels/stable/release/3.13.7/sdk/dartsdk-linux-x64-release.zip'
EXPECTED='eb99aed266efbcb615c6ae21c12f52cfe935b9f208bccc5fea7f64c21e867229'
start=time.monotonic()
payload=io.BytesIO();digest=hashlib.sha256()
with urllib.request.urlopen(URL,timeout=120) as r:
 for chunk in iter(lambda:r.read(8*1024*1024),b''):
  digest.update(chunk);payload.write(chunk)
assert digest.hexdigest()==EXPECTED,digest.hexdigest()
print(json.dumps({'archive_verified':True,'bytes':payload.tell()}),flush=True)
members=[]
with zipfile.ZipFile(payload) as z:
 for item in z.infolist():
  target=ROOT/item.filename
  assert target.is_relative_to(ROOT)
  if item.is_dir():target.mkdir(parents=True,exist_ok=True);continue
  target.parent.mkdir(parents=True,exist_ok=True)
  content=z.read(item);target.write_bytes(content)
  mode=(item.external_attr>>16)&0o777
  if mode:target.chmod(mode)
  members.append({'path':item.filename,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()})
receipt={'url':URL,'archive_sha256':EXPECTED,'archive_bytes':payload.tell(),'members':members,'seconds':time.monotonic()-start,'substitutions':[]}
(ROOT/'dart-sdk-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'ready':True,'seconds':receipt['seconds'],'members':len(members)}),flush=True)
