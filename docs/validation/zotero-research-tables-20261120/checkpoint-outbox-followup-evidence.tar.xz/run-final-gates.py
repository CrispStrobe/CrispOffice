from pathlib import Path
import subprocess,json,time,hashlib,os,signal,sys,collections
import importlib.util
spec=importlib.util.spec_from_file_location('lf_audit',str(Path(__file__).with_name('audit-lf-jsonl.py')));lf_audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(lf_audit)
root=Path('/workspace/scratch/a17412353cf6');runtime=root/'runtime';repo=root/'quds_office_suite';source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();out=runtime/('final-gates-'+source[:8]);out.mkdir(exist_ok=True);plan=json.loads((runtime/'final-gates-plan.json').read_text());names=[p for p in subprocess.check_output(['git','ls-files','--','*.dart'],cwd=repo,text=True).splitlines() if (repo/p).is_file()]
def hashes():return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in names}
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
before=hashes();(out/'source-before.json').write_text(json.dumps(before,indent=2));(out/'plan.json').write_text(json.dumps(plan,indent=2))
for index,gate in enumerate(plan):
 if index<int(sys.argv[1] if len(sys.argv)>1 else '0'):continue
 d=out/gate['name'];d.mkdir(exist_ok=True);assert not (d/'receipt.json').exists(),'Do not overwrite a completed gate'
 start=time.time();memory=[];interrupted=False
 with (d/'tests.jsonl').open('w') as stdout,(d/'stderr.log').open('w') as stderr:
  process=subprocess.Popen(gate['command'],cwd=repo/gate['cwd'],stdout=stdout,stderr=stderr,start_new_session=True)
  while process.poll() is None:
   rows=[]
   for line in subprocess.check_output(['ps','-eo','pid,ppid,rss,comm'],text=True).splitlines()[1:]:
    p=line.split(maxsplit=3)
    if len(p)==4:rows.append({'pid':int(p[0]),'ppid':int(p[1]),'rssKB':int(p[2]),'name':p[3]})
   ids={process.pid}
   while True:
    found=ids|{p['pid'] for p in rows if p['ppid'] in ids}
    if found==ids:break
    ids=found
   memory.append({'elapsed':time.time()-start,'processes':[p for p in rows if p['pid'] in ids],'meminfo':Path('/proc/meminfo').read_text()})
   if time.time()-start>gate.get('timeout',1200):
    interrupted=True;os.killpg(process.pid,signal.SIGINT)
    try:process.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL)
    break
   time.sleep(0.5)
  status=process.wait()
 after=hashes();protocol=lf_audit.audit(d/'tests.jsonl');(d/'protocol-audit.json').write_text(json.dumps(protocol,indent=2));counts=protocol['visibleCounts'];success=status==0 and protocol['acceptedProtocol'] and not interrupted and before==after
 receipt={'source':source,'gate':gate['name'],'command':gate['command'],'cwd':str(repo/gate['cwd']),'exit':status,'terminalEventCount':protocol['terminalCount'],'jsonSuccess':protocol['terminalSuccess'],'counts':dict(counts),'protocolComplete':protocol['protocolComplete'],'protocolAccepted':protocol['acceptedProtocol'],'accepted':success,'interrupted':interrupted,'seconds':time.time()-start,'sourceFiles':len(before),'sourceBeforeSha256':digest(before),'sourceAfterSha256':digest(after),'sourceHashesUnchanged':before==after,'peakRssSumKB':max((sum(p['rssKB'] for p in row['processes']) for row in memory),default=0)};(d/'receipt.json').write_text(json.dumps(receipt,indent=2));(d/'memory-monitor.json').write_text(json.dumps(memory,indent=2));print(json.dumps(receipt),flush=True)
 if not success:break
