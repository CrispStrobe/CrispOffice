import json,sys,collections
from pathlib import Path
rows=[]
for line in Path(sys.argv[1]).read_text().splitlines():
 try: rows.append(json.loads(line))
 except ValueError: pass
suites={r['suite']['id']:r['suite']['path'] for r in rows if r.get('type')=='suite'}
tests={r['test']['id']:r['test'] for r in rows if r.get('type')=='testStart'}
counts=collections.Counter(); bySuite={}; errors=[]
for row in rows:
 if row.get('type')=='testDone':
  key='hidden' if row.get('hidden') else ('skipped' if row.get('skipped') else row['result']); counts[key]+=1
  test=tests.get(row['testID'],{}); path=suites.get(test.get('suiteID'),'unknown'); bySuite.setdefault(path,collections.Counter())[key]+=1
 if row.get('type')=='error': errors.append({'test':tests.get(row['testID'],{}).get('name'),'error':str(row.get('error'))[:1800],'errorChars':len(str(row.get('error'))),'stackTrace':row.get('stackTrace')})
print(json.dumps({'counts':dict(counts),'bySuite':bySuite,'done':[r for r in rows if r.get('type')=='done'],'errors':errors},indent=2))
