import subprocess,json,time,hashlib,os
from pathlib import Path
r=Path(os.environ['TASK_ROOT']); repo=r/'quds_office_suite'; e=repo/'packages/quds_office_editor'; out=r/'runtime/diagnosticb546-heap640'; out.mkdir(exist_ok=True)
files=sorted(repo.glob('packages/**/*.dart')); hashes={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
cmd=[str(r/'runtime/flutter/bin/flutter'),'test','--frontend-server-starter-path='+str(r/'runtime/frontend_heap_launcher.dart'),'--no-pub','--reporter=json','--concurrency=1','test/word_zotero_add_note_controller_test.dart']
start=time.time()
with (out/'flutter.jsonl').open('w') as stdout,(out/'flutter.stderr').open('w') as stderr: status=subprocess.run(cmd,cwd=e,stdout=stdout,stderr=stderr).returncode
receipt={'source':'b5463074086004219627dca938d650adc42aaafc plus format-b546.json','command':cmd,'cwd':str(e),'exit':status,'seconds':time.time()-start,'hashesBefore':hashes,'hashesAfter':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(out/'flutter-receipt.json').write_text(json.dumps(receipt,indent=2)); print(json.dumps({'flutterDiagnosticExit':status,'seconds':receipt['seconds']}))
