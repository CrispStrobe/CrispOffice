import 'dart:async';
import 'dart:io';

Future<void> main(List<String> args) async {
  final root = Platform.environment['TASK_ROOT']!;
  final process = await Process.start(
    '$root/runtime/dart-sdk/bin/dartaotruntime',
    [
      '--old_gen_heap_size=640',
      '$root/runtime/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot',
      ...args,
    ],
    mode: ProcessStartMode.inheritStdio,
  );
  final term = ProcessSignal.sigterm.watch().listen(process.kill);
  final interrupt = ProcessSignal.sigint.watch().listen(process.kill);
  final status = await process.exitCode;
  await term.cancel();
  await interrupt.cancel();
  exit(status < 0 ? 128 - status : status);
}
