import subprocess,json,time,hashlib,os
from pathlib import Path
r=Path(os.environ['TASK_ROOT']); repo=r/'quds_office_suite'; e=repo/'packages/quds_office_editor'; out=r/'runtime/diagnostic03de'; out.mkdir(exist_ok=True)
files=sorted(repo.glob('packages/**/*.dart')); hashes={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
cmd=[str(r/'runtime/flutter/bin/flutter'),'test','--no-pub','--reporter=json','--concurrency=1','test/word_zotero_add_note_controller_test.dart']
start=time.time()
with (out/'flutter.jsonl').open('w') as stdout,(out/'flutter.stderr').open('w') as stderr: status=subprocess.run(cmd,cwd=e,stdout=stdout,stderr=stderr).returncode
receipt={'source':'03de5b6ad9eff4666c8e0963d1a6b059417951ed plus formatter blobs in ffd01290ec32d70b089cf0b0b22b406ca736c3ae','command':cmd,'cwd':str(e),'exit':status,'seconds':time.time()-start,'hashesBefore':hashes,'hashesAfter':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(out/'flutter-receipt.json').write_text(json.dumps(receipt,indent=2)); print(json.dumps({'flutterDiagnosticExit':status,'seconds':receipt['seconds']}))
