import subprocess,json,time,hashlib,os
from pathlib import Path
r=Path(os.environ['TASK_ROOT']); repo=r/'quds_office_suite'; e=repo/'packages/quds_office_engine'; out=r/'runtime/accepted-e618-source'; out.mkdir(exist_ok=True)
files=sorted(repo.glob('packages/**/*.dart')); hashes={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}; (out/'source-before.json').write_text(json.dumps(hashes,indent=2))
cmd=[str(r/'runtime/dart-sdk/bin/dart'),'--packages='+str(r/'runtime/engine_package_config.json'),str(r/'runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),'--reporter=json','--concurrency=1','--compiler=source','tool/zotero/research_target_acceptance.dart']; start=time.time()
with (out/'engine.jsonl').open('w') as stdout,(out/'engine.stderr').open('w') as stderr: status=subprocess.run(cmd,cwd=e,stdout=stdout,stderr=stderr).returncode
receipt={'source':'e618dbe2d01a71e68a757aec8688b1c7a5540bdf','command':cmd,'cwd':str(e),'exit':status,'seconds':time.time()-start,'hashesBefore':hashes,'hashesAfter':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(out/'engine-receipt.json').write_text(json.dumps(receipt,indent=2)); print(json.dumps({'engineExit':status,'seconds':receipt['seconds']}))
