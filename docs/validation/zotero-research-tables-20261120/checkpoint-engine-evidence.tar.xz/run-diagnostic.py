import subprocess,json,time,hashlib,os
from pathlib import Path
r=Path(os.environ['TASK_ROOT']); repo=r/'quds_office_suite'; e=repo/'packages/quds_office_engine'; out=r/'runtime/diagnostic03de'; out.mkdir(exist_ok=True)
files=sorted(list(repo.glob('packages/*/lib/**/*.dart'))+list(e.glob('test/*.dart')))
hashes={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
cmd=[str(r/'runtime/dart-sdk/bin/dart'),'--packages='+str(r/'runtime/engine_package_config.json'),str(r/'runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),'--reporter=json','--concurrency=1','test/word_zotero_note_table_test.dart','test/word_zotero_note_tables_integration_test.dart','test/word_zotero_add_note_test.dart']
start=time.time()
with (out/'engine.jsonl').open('w') as stdout,(out/'engine.stderr').open('w') as stderr: status=subprocess.run(cmd,cwd=e,stdout=stdout,stderr=stderr).returncode
receipt={'source':'03de5b6ad9eff4666c8e0963d1a6b059417951ed plus formatter blobs in ffd01290ec32d70b089cf0b0b22b406ca736c3ae','command':cmd,'cwd':str(e),'exit':status,'seconds':time.time()-start,'hashesBefore':hashes,'hashesAfter':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(out/'engine-receipt.json').write_text(json.dumps(receipt,indent=2)); print(json.dumps({'engineDiagnosticExit':status,'seconds':receipt['seconds']}))
