#!/usr/bin/env python3
import hashlib,io,json,sys,tarfile,urllib.request,re,time,yaml
from pathlib import Path
ROOT=Path('/workspace/scratch/a17412353cf6/runtime')
REPO=ROOT.parent/'quds_office_suite'
CACHE=ROOT/'pub-cache'
HOST=CACHE/'hosted/pub.dev';HASH=CACHE/'hosted-hashes/pub.dev'
HOST.mkdir(parents=True,exist_ok=True);HASH.mkdir(parents=True,exist_ok=True)
lock=yaml.safe_load((REPO/'pubspec.lock').read_text())
specs=lock['packages'];done={};records=[];started=time.monotonic()
all_mode='--all' in sys.argv
pending=list(specs) if all_mode else ['test','lints','image','archive','characters','crypto']
def language(pub):
 constraint=str(pub.get('environment',{}).get('sdk','>=3.0.0'))
 match=re.search(r'(\d+)\.(\d+)',constraint)
 return '.'.join(match.groups()) if match else '3.0'
while pending:
 name=pending.pop()
 if name in done:continue
 spec=specs.get(name)
 if spec is None or spec['source']!='hosted':
  continue
 version=spec['version'];desc=spec['description'];expected=desc['sha256']
 assert desc['url']=='https://pub.dev'
 key=name+'-'+version;target=HOST/key;stamp=HASH/(key+'.sha256')
 if target.exists() and stamp.exists() and stamp.read_text()==expected:
  status='verified-cache';data_size=None
 else:
  url='https://pub.dev/api/archives/'+key+'.tar.gz'
  with urllib.request.urlopen(url,timeout=90) as source:data=source.read()
  actual=hashlib.sha256(data).hexdigest()
  assert actual==expected,(name,actual,expected)
  target.mkdir(parents=True,exist_ok=True)
  with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
   archive.extractall(target,filter='data')
  stamp.write_text(actual);status='verified-download';data_size=len(data)
 pub=yaml.safe_load((target/'pubspec.yaml').read_text())
 done[name]={'name':name,'rootUri':target.as_uri()+'/','packageUri':'lib/','languageVersion':language(pub)}
 records.append({'name':name,'version':version,'sha256':expected,'status':status,'archive_bytes':data_size})
 pending.extend(pub.get('dependencies',{}))
 print(json.dumps(records[-1]),flush=True)
for name in ['quds_office_engine','legacy_doc_parser']:
 target=REPO/'packages'/name
 pub=yaml.safe_load((target/'pubspec.yaml').read_text())
 done[name]={'name':name,'rootUri':target.as_uri()+'/','packageUri':'lib/','languageVersion':language(pub)}
config={'configVersion':2,'packages':sorted(done.values(),key=lambda v:v['name']),'generator':'verified-source-validation'}
(ROOT/'package_config.json').write_text(json.dumps(config,indent=2)+'\n')
receipt={'lock_sha256':hashlib.sha256((REPO/'pubspec.lock').read_bytes()).hexdigest(),'packages':records,'mode':'all' if all_mode else 'engine','seconds':time.monotonic()-started,'substitutions':[]}
(ROOT/('dependencies-all.json' if all_mode else 'dependencies-engine.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'ready':True,'packages':len(done),'seconds':receipt['seconds']}),flush=True)
