import subprocess,json,time,hashlib,os
from pathlib import Path
r=Path(os.environ['TASK_ROOT']); repo=r/'quds_office_suite'; e=repo/'packages/quds_office_engine'; out=r/'runtime/engine-controls-e618'; out.mkdir(exist_ok=True)
pairs={'lib/src/word/layout/word_layout.dart':'6f13777f04c8241ee1083cf583d7046b191412cd','lib/src/word/layout/word_incremental_layout.dart':'dc268e884f4e6ca834c5292335e1081e5fcea35c'}
original={p:(e/p).read_bytes() for p in pairs}; cmd=[str(r/'runtime/dart-sdk/bin/dart'),'--packages='+str(r/'runtime/engine_package_config.json'),str(r/'runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),'--reporter=json','--concurrency=1','--compiler=source','--name','removing a wrapping frame|foreign engine reuse','test/word_incremental_layout_test.dart']; receipts=[]
def run(label):
 before={p:hashlib.sha256((e/p).read_bytes()).hexdigest() for p in pairs}; start=time.time()
 with (out/(label+'.jsonl')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr: result=subprocess.run(cmd,cwd=e,stdout=stdout,stderr=stderr).returncode
 receipt={'label':label,'command':cmd,'exit':result,'seconds':time.time()-start,'sourceHashesBefore':before,'sourceHashesAfter':{p:hashlib.sha256((e/p).read_bytes()).hexdigest() for p in pairs},'testSha256':hashlib.sha256((e/'test/word_incremental_layout_test.dart').read_bytes()).hexdigest()}; receipts.append(receipt); print(json.dumps(receipt),flush=True)
try:
 for p,sha in pairs.items(): (e/p).write_bytes(subprocess.check_output(['git','cat-file','blob',sha],cwd=repo))
 run('red-original-e6f70bff')
finally:
 for p,data in original.items(): (e/p).write_bytes(data)
run('green-e618')
(out/'receipts.json').write_text(json.dumps({'acceptedSource':'e618dbe2d01a71e68a757aec8688b1c7a5540bdf','originalBlobSwaps':pairs,'runs':receipts,'restored':all((e/p).read_bytes()==b for p,b in original.items())},indent=2))
