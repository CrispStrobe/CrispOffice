import asyncio,json,hashlib,subprocess,time,os,signal,collections
from pathlib import Path
from urllib.parse import urljoin,urlparse,unquote
import yaml
ROOT=Path('/workspace/scratch/a17412353cf6');repo=ROOT/'quds_office_suite';runtime=ROOT/'runtime';sdk=runtime/'dart-sdk';source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();out=runtime/('analysis-'+source[:8]);out.mkdir(exist_ok=True)
relative=json.loads((runtime/'analysis-targets.json').read_text());files=[str((repo/p).resolve()) for p in relative];before={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in relative}
config=repo/'.dart_tool/package_config.json';config_data=json.loads(config.read_text());packages={p['name']:urljoin(config.as_uri(),p['rootUri']) for p in config_data['packages']};options={};plugins=[]
def inspect_options(path):
 path=path.resolve()
 if not path.is_file() or str(path) in options:return
 text=path.read_text();data=yaml.safe_load(text) or {};options[str(path)]={'sha256':hashlib.sha256(text.encode()).hexdigest(),'text':text}
 if data.get('plugins') or (isinstance(data.get('analyzer'),dict) and data['analyzer'].get('plugins')):plugins.append(str(path))
 include=data.get('include')
 if include:
  if include.startswith('package:'):
   name,tail=include[8:].split('/',1);target=Path(unquote(urlparse(urljoin(packages[name] if packages[name].endswith('/') else packages[name]+'/', 'lib/'+tail)).path))
  else:target=path.parent/include
  inspect_options(target)
for file in files:
 for parent in Path(file).parents:
  if parent==repo.parent:break
  if (parent/'analysis_options.yaml').exists():inspect_options(parent/'analysis_options.yaml');break
(out/'analysis-options.json').write_text(json.dumps({'files':options,'plugins':plugins},indent=2));assert not plugins,'Plugin diagnostics require normal CLI fallback'
(out/'source-before.json').write_text(json.dumps(before,indent=2));(out/'target-files.json').write_text(json.dumps(relative,indent=2))
command=[str(sdk/'bin/dartaotruntime'),str(sdk/'bin/snapshots/analysis_server_aot.dart.snapshot'),'--protocol=analyzer','--sdk',str(sdk),'--client-id=quds-validation','--suppress-analytics','--disable-server-feature-completion','--disable-server-feature-search','--disable-status-notification-debouncing','--disable-silent-analysis-exceptions']
provenance=json.loads((runtime/'dart-sdk-receipt.json').read_text());expected={p['path']:p['sha256'] for p in provenance['members']};executed={}
for p in command[:2]:
 file=Path(p);key='dart-sdk/'+str(file.relative_to(sdk));actual=hashlib.sha256(file.read_bytes()).hexdigest();assert expected[key]==actual;executed[key]=actual
async def main():
 started=time.time();pending={};connected=asyncio.Event();fatal=[];diagnostics={};monitor=[]
 process=await asyncio.create_subprocess_exec(*command,cwd=repo,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE,start_new_session=True,limit=16*1024*1024)
 outgoing=(out/'requests.jsonl').open('w');incoming=(out/'responses.jsonl').open('w');stderr=(out/'stderr.log').open('wb')
 async def read_stdout():
  while True:
   raw=await process.stdout.readline()
   if not raw:break
   text=raw.decode('utf-8');incoming.write(text);incoming.flush()
   try:event=json.loads(text)
   except ValueError:fatal.append({'malformed':text});continue
   if event.get('event')=='server.connected':connected.set()
   if event.get('event') in ['server.error','server.pluginError']:fatal.append(event)
   if 'id' in event:
    future=pending.pop(event['id'],None)
    if future is None:fatal.append({'unexpectedResponse':event})
    elif not future.done():future.set_result(event)
  for future in list(pending.values()):
   if not future.done():future.set_exception(RuntimeError('Server exited before response'))
 async def read_stderr():
  while True:
   raw=await process.stderr.read(65536)
   if not raw:break
   stderr.write(raw);stderr.flush()
 async def memory():
  while process.returncode is None:
   rss=None
   try:
    status=Path(f'/proc/{process.pid}/status').read_text();rss=next(line for line in status.splitlines() if line.startswith('VmRSS:'))
   except (FileNotFoundError,StopIteration):pass
   monitor.append({'elapsed':time.time()-started,'rss':rss,'meminfo':Path('/proc/meminfo').read_text()});await asyncio.sleep(1)
 tasks=[asyncio.create_task(read_stdout()),asyncio.create_task(read_stderr()),asyncio.create_task(memory())]
 async def request(ident,method,params=None):
  future=asyncio.get_running_loop().create_future();pending[ident]=future;value={'id':ident,'method':method}
  if params is not None:value['params']=params
  line=json.dumps(value);outgoing.write(line+'\n');outgoing.flush();process.stdin.write((line+'\n').encode());await process.stdin.drain();response=await asyncio.wait_for(future,180)
  if 'error' in response:raise RuntimeError(json.dumps(response))
  return response
 failure=None;status=None
 try:
  await asyncio.wait_for(connected.wait(),60)
  await request('subscriptions','server.setSubscriptions',{'subscriptions':['STATUS']})
  await request('roots','analysis.setAnalysisRoots',{'included':files,'excluded':[]})
  for index,file in enumerate(files):
   response=await request('get-'+str(index),'analysis.getErrors',{'file':file});errors=response.get('result',{}).get('errors');assert isinstance(errors,list),response;diagnostics[relative[index]]=errors;print(json.dumps({'file':relative[index],'diagnostics':len(errors)}),flush=True)
  await request('shutdown','server.shutdown');status=await asyncio.wait_for(process.wait(),30)
 except BaseException as error:
  failure=repr(error)
  if process.returncode is None:
   os.killpg(process.pid,signal.SIGTERM)
   try:status=await asyncio.wait_for(process.wait(),10)
   except asyncio.TimeoutError:os.killpg(process.pid,signal.SIGKILL);status=await process.wait()
 finally:
  await asyncio.gather(*tasks);outgoing.close();incoming.close();stderr.close()
 after={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in relative};severity=collections.Counter(e['severity'] for errors in diagnostics.values() for e in errors);complete=failure is None and not fatal and len(diagnostics)==len(files) and status==0 and before==after
 receipt={'source':source,'command':command,'method':'Official Dart Analysis Server legacy JSON protocol; analysis.getErrors per-file completion barrier','filesRequested':len(files),'filesCompleted':len(diagnostics),'diagnosticsBySeverity':dict(severity),'complete':complete,'failure':failure,'fatalNotifications':fatal,'processExit':status,'seconds':time.time()-started,'sourceHashesUnchanged':before==after,'executedRuntimeSha256':executed,'packageConfigSha256':hashlib.sha256(config.read_bytes()).hexdigest(),'pluginsConfigured':plugins}
 (out/'diagnostics.json').write_text(json.dumps(diagnostics,indent=2));(out/'memory-monitor.json').write_text(json.dumps(monitor,indent=2));(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
asyncio.run(main())
