import subprocess,json,time,hashlib,os,signal
from pathlib import Path
r=Path(os.environ['TASK_ROOT']); repo=r/'quds_office_suite'; e=repo/'packages/quds_office_editor'; out=r/'runtime/chrome-controls-4044'; out.mkdir(exist_ok=True); path=e/'example/lib/suite_workspace.dart'; original=path.read_bytes(); oldsha=subprocess.check_output(['git','rev-parse','ab8d42ec:packages/quds_office_editor/example/lib/suite_workspace.dart'],cwd=repo,text=True).strip(); assert oldsha.startswith('4595d8'); receipts=[]
def run(label,name):
 cmd=[str(r/'runtime/flutter/bin/flutter'),'test','--no-pub','--reporter=json','--concurrency=1','--name',name,'tool/zotero/research_target_acceptance.dart']; start=time.time(); before=hashlib.sha256(path.read_bytes()).hexdigest(); timedout=False
 with (out/(label+'.jsonl')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:
  p=subprocess.Popen(cmd,cwd=e,stdout=stdout,stderr=stderr)
  try: status=p.wait(timeout=180)
  except subprocess.TimeoutExpired:
   timedout=True; p.send_signal(signal.SIGINT); status=p.wait(timeout=20)
 receipt={'source':'40442e5e3b188386bc7a410efb92cab46bf68b82','label':label,'command':cmd,'exit':status,'timedOut':timedout,'seconds':time.time()-start,'workspaceBefore':before,'workspaceAfter':hashlib.sha256(path.read_bytes()).hexdigest()}; receipts.append(receipt); print(json.dumps(receipt),flush=True)
try:
 path.write_bytes(subprocess.check_output(['git','cat-file','blob',oldsha],cwd=repo)); run('red-original-workspace','studio_word_chrome_settle_test.dart')
finally:
 path.write_bytes(original)
run('green-chrome-and-image-guards','studio_word_chrome_settle_test.dart|image flow keeps')
(out/'receipts.json').write_text(json.dumps({'originalWorkspaceBlob':oldsha,'runs':receipts,'restored':path.read_bytes()==original},indent=2))
