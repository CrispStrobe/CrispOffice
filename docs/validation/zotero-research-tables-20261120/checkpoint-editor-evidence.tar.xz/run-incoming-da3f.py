import subprocess,json,time,hashlib,os,signal
from pathlib import Path
r=Path(os.environ['TASK_ROOT']); repo=r/'quds_office_suite'; e=repo/'packages/quds_office_editor/example'; out=r/'runtime/accepted-da3f-incoming'; out.mkdir(exist_ok=True)
files=[repo/p for p in subprocess.check_output(['git','ls-files','--','*.dart'],cwd=repo,text=True).splitlines() if (repo/p).is_file()]; hashes={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}; (out/'source-before.json').write_text(json.dumps(hashes,indent=2)); cmd=[str(r/'runtime/flutter/bin/flutter'),'test','--no-pub','--reporter=json','--concurrency=1','tool/incoming_reconciliation_acceptance.dart']; start=time.time(); monitor=[]
with (out/'flutter.jsonl').open('w') as stdout,(out/'flutter.stderr').open('w') as stderr:
 process=subprocess.Popen(cmd,cwd=e,stdout=stdout,stderr=stderr)
 while process.poll() is None:
  rows=[]
  for line in subprocess.check_output(['ps','-eo','pid,ppid,rss,comm'],text=True).splitlines()[1:]:
   parts=line.split(maxsplit=3)
   if len(parts)==4: rows.append({'pid':int(parts[0]),'ppid':int(parts[1]),'rssKB':int(parts[2]),'name':parts[3]})
  ids={process.pid}
  while True:
   expanded=ids|{p['pid'] for p in rows if p['ppid'] in ids}
   if expanded==ids: break
   ids=expanded
  monitor.append({'seconds':time.time()-start,'processes':[p for p in rows if p['pid'] in ids],'meminfo':Path('/proc/meminfo').read_text()})
  if time.time()-start>1200:
   process.send_signal(signal.SIGINT); process.wait(timeout=20); break
  time.sleep(0.5)
 result=process.wait()
receipt={'source':'da3f328224e9c04764d4e829a4bb65704940011c','command':cmd,'cwd':str(e),'exit':result,'seconds':time.time()-start,'hashesBefore':hashes,'hashesAfter':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'cgroupDirectoryPresent':Path('/sys/fs/cgroup').exists()}; (out/'receipt.json').write_text(json.dumps(receipt,indent=2)); (out/'memory-monitor.json').write_text(json.dumps(monitor,indent=2)); print(json.dumps({'exit':result,'seconds':receipt['seconds'],'peakRssSumKB':max(sum(p['rssKB'] for p in row['processes']) for row in monitor)}))
