export FLUTTER_ROOT='/workspace/scratch/76a795caf82b/runtime/flutter-sdk'
export PUB_CACHE='/workspace/scratch/76a795caf82b/runtime/pub-cache'
export TMPDIR='/workspace/scratch/76a795caf82b/runtime/tmp'
export XDG_CONFIG_HOME='/workspace/scratch/76a795caf82b/runtime/config'
export PATH="$FLUTTER_ROOT/bin:$PATH"
export CI=true FLUTTER_SUPPRESS_ANALYTICS=true DART_SUPPRESS_ANALYTICS=true
