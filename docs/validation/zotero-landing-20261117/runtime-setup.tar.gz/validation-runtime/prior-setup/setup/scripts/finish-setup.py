#!/usr/bin/env python3
"""Finish genuine SDK cache and enforce previously published test locks."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SDK = ROOT / 'flutter-sdk'
ENV = os.environ.copy()
ENV.update(FLUTTER_ROOT=str(SDK), PUB_CACHE=str(ROOT/'pub-cache'),
           TMPDIR=str(ROOT/'tmp'), XDG_CONFIG_HOME=str(ROOT/'config'),
           CI='true', FLUTTER_SUPPRESS_ANALYTICS='true', DART_SUPPRESS_ANALYTICS='true')
ENV['PATH'] = str(SDK/'bin')+os.pathsep+ENV['PATH']
DART = str(SDK/'bin/cache/dart-sdk/bin/dart')
TOOL = str(SDK/'bin/cache/flutter_tools.snapshot')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    harnesses = ['harness/quds_office_engine', 'harness/quds_office_editor',
                 'harness/quds_office_studio', 'crisp-host-harness']
    locks = {name: digest(ROOT/name/'pubspec.lock') for name in harnesses}
    receipt = {'commands': [], 'tests_run': False, 'production_files_modified': False,
               'lock_sha256_before': locks}
    def save():
        (ROOT/'current-setup-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    def run(name,args,cwd):
        path=ROOT/'logs'/f'{name}.log'
        started=time.monotonic()
        row={'name':name,'command':args,'cwd':str(cwd),'log':str(path), 'status':'running'}
        receipt['commands'].append(row); save()
        print(json.dumps({'start':name}),flush=True)
        with path.open('w') as stream:
            proc=subprocess.Popen(args,cwd=cwd,env=ENV,stdout=stream,stderr=subprocess.STDOUT)
            while proc.poll() is None:
                try: proc.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    print(json.dumps({'active':name,'seconds':round(time.monotonic()-started)}),flush=True)
                if time.monotonic()-started>600:
                    proc.terminate(); proc.wait(timeout=5)
                    raise RuntimeError(name+' exceeded 600 seconds')
        row.update(exit_code=proc.returncode,elapsed_seconds=round(time.monotonic()-started,3),
                   log_sha256=digest(path),status='passed' if proc.returncode==0 else 'failed')
        save(); print(json.dumps(row),flush=True)
        assert proc.returncode==0, name
    run('precache-linux',[DART,TOOL,'precache','--linux','--no-android','--no-ios','--no-web','--no-windows','--no-macos'],ROOT)
    for name in harnesses:
        run(name.replace('/','-')+'-pub-get',[DART,TOOL,'pub','get','--enforce-lockfile'],ROOT/name)
        assert digest(ROOT/name/'pubspec.lock')==locks[name],name+' lock changed'
    canonical=(ROOT/'workspace/quds_office_suite').resolve()
    example=ROOT/'harness/quds_office_engine/example'
    assert not example.is_symlink()
    example.mkdir(exist_ok=True)
    for name in ['pdf_widgets_invoice.dart','pdf_widgets_proposal.dart','pdf_widgets_report.dart']:
        source=canonical/'packages/quds_office_engine/example'/name
        destination=example/name
        if destination.is_symlink(): assert destination.resolve()==source
        else: destination.symlink_to(source)
    assert not (example/'pubspec.yaml').exists()
    version=json.loads((SDK/'bin/cache/flutter.version.json').read_text())
    assert version['frameworkRevision']=='737ba8f885dc774b53b442759999a312c9461e4e'
    assert version['engineRevision']=='cf636b1dfb818dd6a3ff16e390e93b1a036969c8'
    assert version['dartSdkVersion']=='3.13.7'
    assert version['frameworkVersion']=='3.47.8'
    metadata={}
    for name in harnesses:
        graph=json.loads((ROOT/name/'.dart_tool/package_config.json').read_text())
        assert graph['flutterRoot']==SDK.as_uri(),(name,graph.get('flutterRoot'))
        assert graph['flutterVersion']=='3.47.8'
        metadata[name]={'packages':len(graph['packages']),'sha256':digest(ROOT/name/'.dart_tool/package_config.json')}
    expected={
        'bin/cache/dart-sdk/bin/dart':'01e869e4af277734b02ab8898b870c6b00c9bec61bbcf9c923cd14de7ed85fbb',
        'bin/cache/artifacts/engine/linux-x64/flutter_tester':'800f4ca182df7dd2fb46a42dea5d76277b9dbc5e8cd2915e02bcbc978681b45f',
    }
    for name,value in expected.items(): assert digest(SDK/name)==value,(name,digest(SDK/name))
    receipt.update(status='passed',runtime=version,runtime_binaries_sha256=expected,
                   runtime_tool_snapshot_sha256=digest(SDK/'bin/cache/flutter_tools.snapshot'),
                   metadata=metadata,lock_sha256_after={name:digest(ROOT/name/'pubspec.lock') for name in harnesses})
    assert receipt['lock_sha256_before']==receipt['lock_sha256_after']
    save(); print('SETUP READY',flush=True)

if __name__=='__main__': main()
