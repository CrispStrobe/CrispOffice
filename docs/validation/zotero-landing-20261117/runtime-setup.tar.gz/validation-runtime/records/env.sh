export FLUTTER_ROOT='/workspace/scratch/9f398661059e/runtime/flutter-sdk'
export PUB_CACHE='/workspace/scratch/9f398661059e/runtime/pub-cache'
export TMPDIR='/workspace/scratch/9f398661059e/runtime/tmp'
export XDG_CONFIG_HOME='/workspace/scratch/9f398661059e/runtime/config'
export PATH="$FLUTTER_ROOT/bin:$FLUTTER_ROOT/bin/cache/dart-sdk/bin:$PATH"
export CI=true FLUTTER_SUPPRESS_ANALYTICS=true DART_SUPPRESS_ANALYTICS=true
