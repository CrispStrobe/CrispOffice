import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:test/test.dart';

const _textNs = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0';
const _tableNs = 'urn:oasis:names:tc:opendocument:xmlns:table:1.0';

Iterable<XmlElement> _elements(XmlElement node, String localName) sync* {
  if (node.localName == localName) yield node;
  for (final child in node.childElements) {
    yield* _elements(child, localName);
  }
}

String _text(XmlNode node) {
  if (node is XmlText) return node.text;
  if (node is! XmlElement) return '';
  if (node.namespaceUri == _textNs) {
    switch (node.localName) {
      case 's':
        return ' ' * int.parse(node.getAttribute('c') ?? '1');
      case 'tab':
        return '\t';
      case 'line-break':
        return '\n';
    }
  }
  return node.children.map(_text).join();
}

WmlParagraph _cachedField(String instruction, String visible) => WmlParagraph(
  inlines: [
    WmlRun(text: '  Before\t'),
    WmlFieldBoundary(kind: WmlFieldBoundaryKind.begin),
    WmlFieldBoundary(kind: WmlFieldBoundaryKind.instruction, text: instruction),
    WmlFieldBoundary(kind: WmlFieldBoundaryKind.separate),
    WmlRun(text: visible, properties: WmlRunProps(italic: true)),
    WmlFieldBoundary(kind: WmlFieldBoundaryKind.end),
    WmlBreak(WmlBreakType.textWrapping),
    WmlRun(text: 'After  '),
  ],
);

({String xml, XmlElement root}) _export(WmlDocument document) {
  final package = OpcPackage.openBytes(OdtDocumentWriter.writeBytes(document));
  final xml = package.getPart('/content.xml')!.readText();
  return (xml: xml, root: XmlDocument.parse(xml).root!);
}

void main() {
  test(
    'footnotes and endnotes preserve cached fields and authored whitespace',
    () {
      const footInstruction =
          ' ADDIN ZOTERO_ITEM CSL_CITATION {"citationID":"PRIVATE_FOOT"} ';
      const endInstruction =
          ' ADDIN ZOTERO_ITEM CSL_CITATION {"citationID":"PRIVATE_END"} ';
      final footParagraph = _cachedField(footInstruction, '(Foot 2026)');
      final endParagraph = _cachedField(endInstruction, '(End 2026)');
      final document = WmlDocument(
        footnotes: [
          WmlNote(id: 7, endnote: false, paragraphs: [footParagraph]),
        ],
        endnotes: [
          WmlNote(id: 7, endnote: true, paragraphs: [endParagraph]),
        ],
        sections: [
          WmlSection(
            blocks: [
              WmlParagraph(
                inlines: [
                  WmlRun(text: 'Main before '),
                  WmlRun(noteRefId: 7),
                  WmlRun(text: ' between '),
                  WmlRun(noteRefId: 7, noteRefEndnote: true),
                  WmlRun(text: ' after'),
                ],
              ),
            ],
          ),
        ],
      );
      final exported = _export(document);
      final notes = _elements(exported.root, 'note').toList();
      expect(notes, hasLength(2));
      final byClass = {
        for (final note in notes)
          note.getAttribute('note-class', namespaceUri: _textNs): note,
      };
      expect(byClass.keys, containsAll(['footnote', 'endnote']));
      expect(
        _text(byClass['footnote']!.firstChild('note-body')!),
        '  Before\t(Foot 2026)\nAfter  ',
      );
      expect(
        _text(byClass['endnote']!.firstChild('note-body')!),
        '  Before\t(End 2026)\nAfter  ',
      );
      expect(
        notes
            .map((note) => note.getAttribute('id', namespaceUri: _textNs))
            .toSet(),
        hasLength(2),
      );
      for (final note in notes) {
        expect(note.firstChild('note-citation')!.text, isNotEmpty);
        expect(_elements(note, 'tab'), hasLength(1));
        expect(_elements(note, 'line-break'), hasLength(1));
      }
      expect(exported.xml, isNot(contains('ADDIN ZOTERO_ITEM')));
      expect(exported.xml, isNot(contains('PRIVATE_FOOT')));
      expect(exported.xml, isNot(contains('PRIVATE_END')));
      expect(exported.xml, contains('Main'));
      expect(exported.xml, contains('after'));
      expect(
        footParagraph.inlines.whereType<WmlFieldBoundary>().map((e) => e.text),
        ['', footInstruction, '', ''],
      );
      expect(
        endParagraph.inlines.whereType<WmlFieldBoundary>().map((e) => e.text),
        ['', endInstruction, '', ''],
      );
      expect(_export(document).xml, exported.xml);
    },
  );

  test(
    'note lists and merged tables retain blocks and suppress field codes',
    () {
      final listFirst = _cachedField(
        'PRIVATE_LIST_FIELD',
        'Visible list citation',
      );
      listFirst.properties.numId = 11;
      listFirst.properties.listLabel = '1.';
      final listSecond = WmlParagraph(
        properties: WmlParagraphProps(numId: 11, listLabel: '2.'),
        inlines: [WmlRun(text: 'Second item')],
      );
      WmlTableCell cell(String value, WmlVMerge merge) => WmlTableCell(
        vMerge: merge,
        blocks: [
          WmlParagraph(inlines: [WmlRun(text: value)]),
        ],
      );
      final note = WmlNote(
        id: 4,
        endnote: true,
        blocks: [
          WmlParagraph(inlines: [WmlRun(text: 'Note before')]),
          listFirst,
          listSecond,
          WmlTable(
            grid: [72],
            rows: [
              WmlTableRow(cells: [cell('Visible anchor', WmlVMerge.restart)]),
              WmlTableRow(
                cells: [cell('Retained covered story', WmlVMerge.cont)],
              ),
            ],
          ),
          WmlParagraph(inlines: [WmlRun(text: 'Note after')]),
        ],
      );
      final exported = _export(
        WmlDocument(
          endnotes: [note],
          sections: [
            WmlSection(
              blocks: [
                WmlParagraph(
                  inlines: [WmlRun(noteRefId: 4, noteRefEndnote: true)],
                ),
              ],
            ),
          ],
        ),
      );
      final body = _elements(exported.root, 'note-body').single;
      expect(body.childElements.map((e) => e.localName), [
        'p',
        'list',
        'table',
        'p',
      ]);
      expect(_elements(body, 'list-item'), hasLength(2));
      expect(
        _text(_elements(body, 'list-item').first),
        contains('Visible list citation'),
      );
      final table = _elements(body, 'table').single;
      final anchor = table
          .childrenNamed('table-row', namespaceUri: _tableNs)
          .first
          .firstChild('table-cell')!;
      expect(anchor.getAttribute('number-rows-spanned'), '2');
      expect(
        _text(_elements(table, 'covered-table-cell').single),
        'Retained covered story',
      );
      expect(exported.xml, isNot(contains('PRIVATE_LIST_FIELD')));
      expect(note.blocks, hasLength(5));
      expect(listFirst.properties.numId, 11);
    },
  );
}
