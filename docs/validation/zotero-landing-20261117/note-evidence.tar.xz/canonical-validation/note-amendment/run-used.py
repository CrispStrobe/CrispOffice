#!/usr/bin/env python3
"""Qualify destination-main ODT notes against the accepted final ODF source."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback

CORE_PATH = Path(__file__).with_name('run_qualification.py')
SPEC = importlib.util.spec_from_file_location('full_qualification', CORE_PATH)
core = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(core)

BASE_SOURCE = 'f510060e35d580cbc361985a123927705c92ddc4'
PROBE_SOURCE = Path(__file__).with_name('odt_note_boundary_test.dart')
PROBE_TEST = 'qualification/odt_note_boundary_test.dart'
ALLOWED_DELTA = {
    'packages/quds_office_engine/README.md',
    'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart',
    'packages/quds_office_engine/test/odt_document_writer_test.dart',
}
TARGETS = sorted(p for p in ALLOWED_DELTA if p.endswith('.dart'))
TESTS = ['test/odt_document_writer_test.dart', 'test/odf_export_text_fidelity_test.dart',
         'test/odt_structure_fidelity_test.dart', 'test/odt_header_footer_fidelity_test.dart',
         'test/odt_paragraph_properties_test.dart', 'test/odt_table_merge_test.dart',
         'test/odf_covered_cell_extraction_test.dart', 'test/office_search_fidelity_test.dart']
PACKAGES = ['packages/legacy_doc_parser', 'packages/quds_office_engine',
            'packages/quds_proofing_harper', 'packages/quds_office_engine/example',
            'packages/quds_reports', 'packages/quds_office_editor',
            'packages/quds_office_editor/example', 'apps/quds_report_studio']


def prepare_workspace(repo, workspace, output):
    assert not workspace.exists(), 'Use a fresh isolated workspace; do not rebase the full-run graph.'
    workspace.mkdir(parents=True)
    for name in ('pubspec.yaml', 'analysis_options.yaml'):
        (workspace / name).write_bytes((repo / name).read_bytes())
    lock = 'docs/validation/proofing-20261116/integration-resume/workspace-pubspec.lock'
    lock_bytes = core.git(repo, 'show', core.git_text(repo, 'rev-parse', 'HEAD') + ':' + lock)
    assert core.digest(lock_bytes) == core.EXPECTED_LOCK
    (workspace / 'pubspec.lock').write_bytes(lock_bytes)
    excluded = {'.dart_tool', 'build', '.git', 'pubspec.lock', 'pubspec.yaml', 'pubspec_overrides.yaml'}
    manifests, links = {}, []
    for relative in PACKAGES:
        source, target = repo / relative, workspace / relative
        target.mkdir(parents=True, exist_ok=True)
        (target / 'pubspec.yaml').write_bytes((source / 'pubspec.yaml').read_bytes())
        manifests[relative + '/pubspec.yaml'] = core.sha(target / 'pubspec.yaml')
        for child in source.iterdir():
            if child.name in excluded or str(child.relative_to(repo)) in PACKAGES:
                continue
            dest = target / child.name
            dest.symlink_to(child, target_is_directory=child.is_dir())
            links.append({'path': str(dest.relative_to(workspace)), 'source': str(child)})
    probe = workspace / 'packages/quds_office_engine' / PROBE_TEST
    probe.parent.mkdir()
    probe.write_bytes(PROBE_SOURCE.read_bytes())
    (output / 'note-probe-used.dart').write_bytes(PROBE_SOURCE.read_bytes())
    receipt = {'probe_source': str(PROBE_SOURCE), 'probe_target': str(probe), 'probe_sha256': core.sha(probe),
               'workspace': str(workspace), 'source': str(repo), 'source_commit': core.git_text(repo, 'rev-parse', 'HEAD'),
               'source_package_manifests_copied_unchanged': manifests, 'links': links,
               'lock_source': core.git_text(repo, 'rev-parse', 'HEAD') + ':' + lock, 'lock_sha256': core.EXPECTED_LOCK,
               'existing_full_workspace_modified': False}
    core.save(output / 'workspace-setup.json', receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--flutter-root', type=Path, required=True)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--base-evidence', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo, runtime, workspace, base_evidence, output = (p.resolve() for p in
        (args.repo, args.flutter_root, args.workspace, args.base_evidence, args.output))
    assert core.git_text(repo, 'rev-parse', 'HEAD') == args.source_commit
    assert not core.git_text(repo, 'status', '--porcelain', '--untracked-files=no')
    assert not output.exists(), 'Never replace a prior attempt.'
    output.mkdir(parents=True)
    base_receipt = json.loads((base_evidence / 'receipt.json').read_text())
    assert base_receipt['all_passed'] and base_receipt['source_commit'] == BASE_SOURCE
    actual_delta = set(core.git_text(repo, 'diff', '--name-only', BASE_SOURCE, args.source_commit, '--', ':!docs/').splitlines())
    assert actual_delta == ALLOWED_DELTA, actual_delta
    old_entries, new_entries = core.git_entries(repo, BASE_SOURCE), core.git_entries(repo, args.source_commit)
    delta = {'base_source_commit': BASE_SOURCE, 'candidate_source_commit': args.source_commit,
             'base_accepted_receipt_sha256': core.sha(base_evidence / 'receipt.json'),
             'base_source_manifest_sha256': core.sha(base_evidence / 'source-before.json'),
             'changed_non_evidence_files': {p: {'before': old_entries[p], 'after': new_entries[p]} for p in sorted(actual_delta)},
             'only_changed_production_file': 'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart',
             'test_selection': TESTS, 'supplemental_test_selection': [PROBE_TEST],
             'analysis_and_format_targets': TARGETS, 'probe_sha256': core.sha(PROBE_SOURCE),
             'historical_full_run_test_counts_are_separate': True}
    core.save(output / 'source-delta.json', delta)
    setup = prepare_workspace(repo, workspace, output)
    dart, flutter = runtime / 'bin/cache/dart-sdk/bin/dart', runtime / 'bin/cache/flutter_tools.snapshot'
    receipt = {'status': 'running', 'started_utc': core.now(), 'source_commit': args.source_commit,
               'source_tree': core.git_text(repo, 'rev-parse', args.source_commit + '^{tree}'),
               'base_qualified_source_commit': BASE_SOURCE, 'source_delta_sha256': core.sha(output / 'source-delta.json'),
               'repo': str(repo), 'workspace': str(workspace), 'test_selection': TESTS,
               'supplemental_test_selection': [PROBE_TEST], 'expected_supplemental_tests': 2,
               'runner_sha256': core.sha(Path(__file__)), 'shared_helper_sha256': core.sha(CORE_PATH),
               'github_actions_queried_awaited_or_rerun': False, 'setup_commands': [], 'commands': []}
    core.save(output / 'receipt.json', receipt)
    (output / 'run-used.py').write_bytes(Path(__file__).read_bytes())
    (output / 'shared-helper-used.py').write_bytes(CORE_PATH.read_bytes())

    def command(name, argv, cwd, selected=None, setup_command=False, expected_count=None):
        directory = output / name
        directory.mkdir()
        item = {'name': name, 'command': [str(x) for x in argv], 'cwd': str(cwd),
                'started_utc': core.now(), 'status': 'running', 'timeout_seconds': 600}
        receipt['setup_commands' if setup_command else 'commands'].append(item)
        core.save(output / 'receipt.json', receipt)
        print(json.dumps({'event': 'start', 'name': name}), flush=True)
        start, timed_out = time.monotonic(), False
        with (directory / 'stdout').open('wb') as out, (directory / 'stderr').open('wb') as err:
            proc = subprocess.Popen(item['command'], cwd=cwd, stdout=out, stderr=err, start_new_session=True)
            while True:
                remaining = 600 - (time.monotonic() - start)
                try:
                    code = proc.wait(timeout=max(0, min(15, remaining)))
                    break
                except subprocess.TimeoutExpired:
                    if remaining > 0:
                        print(json.dumps({'event': 'heartbeat', 'name': name, 'seconds': round(time.monotonic() - start, 1)}), flush=True)
                        continue
                    timed_out = True
                    os.killpg(proc.pid, signal.SIGTERM)
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid, signal.SIGKILL)
                        proc.wait()
                    code = 124
                    break
        item.update({'exit_code': code, 'timed_out': timed_out, 'finished_utc': core.now(),
                     'duration_seconds': round(time.monotonic() - start, 3)})
        for stream in ('stdout', 'stderr'):
            data = (directory / stream).read_bytes()
            packed = gzip.compress(data, mtime=0)
            (directory / (stream + '.gz')).write_bytes(packed)
            item[stream] = str((directory / (stream + '.gz')).relative_to(output))
            item[stream + '_sha256'] = core.digest(data)
            item[stream + '_gzip_sha256'] = core.digest(packed)
            (directory / stream).unlink()
            if stream == 'stdout' and selected is not None:
                item['test_summary'] = core.test_summary(data, selected, True, cwd)
                if expected_count is not None:
                    item['test_summary']['expected_success_count'] = expected_count
                    item['test_summary']['passed'] = item['test_summary']['passed'] and item['test_summary']['substantive_success_count'] == expected_count
                core.save(directory / 'test-summary.json', item['test_summary'])
        item['status'] = 'passed' if code == 0 and (selected is None or item['test_summary']['passed']) else 'failed'
        core.save(output / 'receipt.json', receipt)
        print(json.dumps({'event': 'finish', 'name': name, 'status': item['status'], 'test_count': item.get('test_summary', {}).get('substantive_success_count')}), flush=True)
        if item['status'] != 'passed':
            raise RuntimeError(name + ' failed')

    command('locked-offline-resolution', [dart, flutter, 'pub', 'get', '--offline', '--enforce-lockfile'], workspace, setup_command=True)
    assert core.sha(workspace / 'pubspec.lock') == core.EXPECTED_LOCK
    for path, digest in setup['source_package_manifests_copied_unchanged'].items():
        assert core.sha(workspace / path) == digest
    graph = core.normalized_graph(workspace / '.dart_tool/package_config.json', repo)
    assert len(graph['packages']) == 108
    core.save(output / 'analysis-package-config.json', graph)
    old_source_map = json.loads((base_evidence / 'source-before.json').read_text())['files']
    source_before = core.source_snapshot(repo, args.source_commit)
    assert not source_before['commit_mismatches'] and not source_before['untracked_non_evidence_paths']
    assert set(old_source_map) == set(source_before['files'])
    unaffected = {p for p in old_source_map if p not in ALLOWED_DELTA}
    assert all(old_source_map[p] == source_before['files'][p] for p in unaffected)
    receipt['unchanged_non_evidence_files_from_previous_qualification'] = len(unaffected)
    receipt['unchanged_manifests_and_locked_versions'] = True
    probe = workspace / 'packages/quds_office_engine' / PROBE_TEST
    harness_paths = [Path(__file__), CORE_PATH, PROBE_SOURCE, probe, output / 'note-probe-used.dart',
                     output / 'run-used.py', output / 'shared-helper-used.py',
                     output / 'analysis-package-config.json', output / 'workspace-setup.json', output / 'source-delta.json',
                     base_evidence / 'receipt.json', base_evidence / 'source-before.json']

    def inputs():
        return {'source': core.source_snapshot(repo, args.source_commit), 'dependencies': core.dependency_snapshot(graph, repo),
                'runtime': core.runtime_snapshot(runtime), 'workspace': core.workspace_snapshot(workspace),
                'system': core.system_snapshot(), 'harness': {str(p.resolve()): core.sha(p) for p in harness_paths}}

    before = inputs()
    equivalence = {}
    for name in ('dependencies', 'runtime', 'system'):
        baseline_path = base_evidence / (name + '-before.json')
        baseline = json.loads(baseline_path.read_text())
        assert before[name] == baseline, name + ' must retain the accepted environment'
        equivalence[name] = {'equal': True, 'base_map_sha256': core.sha(baseline_path)}
    core.save(output / 'base-environment-equivalence.json', equivalence)
    receipt['accepted_base_environment_preserved'] = True
    for name, value in before.items():
        core.save(output / (name + '-before.json'), value)
    config = repo / '.dart_tool/package_config.json'
    original = config.read_bytes() if config.exists() else None
    original_parent = config.parent.exists()
    receipt['original_analyzer_config_sha256'] = core.digest(original) if original is not None else None
    if original is not None:
        (output / 'original-analysis-package-config.json').write_bytes(original)
    error = None
    try:
        config.parent.mkdir(exist_ok=True)
        config.write_text(json.dumps(graph, indent=2) + '\n')
        command('strict-analysis', [dart, 'analyze', '--fatal-infos', *TARGETS, probe], repo)
        command('format', [dart, 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed', *TARGETS, probe], repo)
        if original is None:
            config.unlink()
        else:
            config.write_bytes(original)
        command('odt-note-regressions', [dart, 'test', '--concurrency=2', '--reporter=json', *TESTS],
                workspace / 'packages/quds_office_engine', selected=TESTS)
        command('note-boundary-probes', [dart, 'test', '--concurrency=2', '--reporter=json', PROBE_TEST],
                workspace / 'packages/quds_office_engine', selected=[PROBE_TEST], expected_count=2)
    except BaseException as caught:
        error = caught
        core.save(output / 'runner-error.json', {'error': type(caught).__name__ + ': ' + str(caught), 'traceback': traceback.format_exc()})
    finally:
        if original is None:
            config.unlink(missing_ok=True)
            if not original_parent and config.parent.exists() and not any(config.parent.iterdir()):
                config.parent.rmdir()
        else:
            config.write_bytes(original)
        after = inputs()
        for name, value in after.items():
            core.save(output / (name + '-after.json'), value)
        receipt['input_integrity'] = {name + '_unchanged': before[name] == after[name] for name in before}
        receipt['analysis_config_restored'] = (config.read_bytes() if config.exists() else None) == original
        receipt['working_head_after'] = core.git_text(repo, 'rev-parse', 'HEAD')
        receipt['source_matches_frozen_commit'] = not after['source']['commit_mismatches'] and not after['source']['untracked_non_evidence_paths']
        receipt['substantive_success_count'] = sum(row.get('test_summary', {}).get('substantive_success_count', 0) for row in receipt['commands'])
        receipt['all_passed'] = (error is None and len(receipt['commands']) == 4 and len(receipt['setup_commands']) == 1
                                 and all(row['status'] == 'passed' for row in receipt['commands'] + receipt['setup_commands'])
                                 and all(receipt['input_integrity'].values()) and receipt['analysis_config_restored']
                                 and receipt['source_matches_frozen_commit'] and receipt['working_head_after'] == args.source_commit)
        receipt.update({'status': 'passed' if receipt['all_passed'] else 'failed', 'finished_utc': core.now()})
        core.save(output / 'receipt.json', receipt)
        print(json.dumps({key: receipt[key] for key in ('status', 'substantive_success_count', 'unchanged_non_evidence_files_from_previous_qualification', 'input_integrity', 'analysis_config_restored')}), flush=True)
    if not receipt['all_passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
