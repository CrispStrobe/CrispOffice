#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,datetime
B=Path(__file__).resolve().parents[1];R=B/'runtime';O=B/'validation-runtime'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={}
for p in [R/'runtime-download.json',R/'harper-workspace-setup.json',R/'harper-workspace-resolution.json',R/'env.sh',R/'flutter-tool',O/'bootstrap-current.py',O/'prepare-canonical-workspace.py',O/'resolve-canonical-workspace.py']:
 assert p.exists(),p
 files[str(p.relative_to(B))]={'bytes':p.stat().st_size,'sha256':sha(p)}
for p in sorted((R/'logs').glob('*.log')):files[str(p.relative_to(B))]={'bytes':p.stat().st_size,'sha256':sha(p)}
for p in sorted((O/'prior-setup/setup/scripts').glob('*.py')):files[str(p.relative_to(B))]={'bytes':p.stat().st_size,'sha256':sha(p)}
res=json.loads((R/'harper-workspace-resolution.json').read_text());assert res['status']=='passed'
source='docs/validation/zotero-finalization-20261117/setup-evidence.tar.gz'
blob=subprocess.check_output(['git','-C',str(B/'quds'),'rev-parse','9f2dbd81c2289a2285521e1491a9c860c4b59646:'+source],text=True).strip()
receipt={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','purpose':'Reconstructed exact official Flutter/Dart SDK and canonical locked test workspace; no application tests run in this setup task.','source_setup_archive':{'repo':'CrispStrobe/quds_office_suite','commit':'9f2dbd81c2289a2285521e1491a9c860c4b59646','path':source,'git_blob':blob},'runtime':json.loads((R/'runtime-download.json').read_text()),'canonical_graph':res,'source_repositories_modified':False,'sdk_tracked_status':subprocess.check_output(['git','-C',str(R/'flutter-sdk'),'status','--porcelain','--untracked-files=no'],text=True),'archive_download_log':str((O/'dart-download.log').relative_to(B)),'inputs':files}
assert receipt['sdk_tracked_status']==''
(O/'setup-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Recorded setup receipt:',O/'setup-receipt.json')
