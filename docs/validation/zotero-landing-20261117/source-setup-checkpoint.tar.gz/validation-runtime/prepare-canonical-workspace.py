#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess
BASE=Path(__file__).resolve().parents[1]
ROOT=BASE/'runtime'
QUDS=BASE/'quds'
TARGET=ROOT/'harper-workspace'
PACKAGES=['packages/legacy_doc_parser','packages/quds_office_engine','packages/quds_proofing_harper','packages/quds_office_engine/example','packages/quds_reports','packages/quds_office_editor','packages/quds_office_editor/example','apps/quds_report_studio']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not TARGET.exists(), 'Refuse to replace existing canonical workspace'
TARGET.mkdir()
LOCK='344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130'
source_lock=QUDS/'docs/validation/proofing-20261116/integration-resume/workspace-pubspec.lock'
assert sha(source_lock)==LOCK
for n in ['pubspec.yaml','analysis_options.yaml']:(TARGET/n).write_bytes((QUDS/n).read_bytes())
(TARGET/'pubspec.lock').write_bytes(source_lock.read_bytes())
excluded={'.dart_tool','build','.git','pubspec.lock','pubspec.yaml','pubspec_overrides.yaml'}
manifest={}
links=[]
for rel in PACKAGES:
 source=QUDS/rel
 target=TARGET/rel
 target.mkdir(parents=True,exist_ok=True)
 (target/'pubspec.yaml').write_bytes((source/'pubspec.yaml').read_bytes())
 manifest[rel+'/pubspec.yaml']=sha(target/'pubspec.yaml')
 for child in source.iterdir():
  if child.name in excluded or str(child.relative_to(QUDS)) in PACKAGES:continue
  dst=target/child.name
  dst.symlink_to(child,target_is_directory=child.is_dir())
  links.append({'path':str(dst.relative_to(TARGET)),'source':str(child)})
receipt={'source_commit_at_setup':subprocess.check_output(['git','-C',str(QUDS),'rev-parse','HEAD'],text=True).strip(),'root_manifest_sha256':sha(TARGET/'pubspec.yaml'),'root_analysis_options_sha256':sha(TARGET/'analysis_options.yaml'),'published_lock_source':str(source_lock),'published_lock_sha256':LOCK,'manifests_sha256':manifest,'source_links':links,'dependency_constraints_modified':False,'tests_run':False,'production_files_modified':False}
(ROOT/'harper-workspace-setup.json').write_text(json.dumps(receipt,indent=2)+'\n')
(ROOT/'env.sh').write_text('\n'.join([
f"export FLUTTER_ROOT='{ROOT/'flutter-sdk'}'",f"export PUB_CACHE='{ROOT/'pub-cache'}'",f"export TMPDIR='{ROOT/'tmp'}'",f"export XDG_CONFIG_HOME='{ROOT/'config'}'",'export PATH="$FLUTTER_ROOT/bin:$FLUTTER_ROOT/bin/cache/dart-sdk/bin:$PATH"','export CI=true FLUTTER_SUPPRESS_ANALYTICS=true DART_SUPPRESS_ANALYTICS=true','']))
print(json.dumps({'status':'prepared','workspace':str(TARGET),'lock':LOCK,'manifests':len(manifest)}))
