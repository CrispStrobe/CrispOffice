#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,subprocess,time
BASE=Path(__file__).resolve().parents[1]
ROOT=BASE/'runtime'
SDK=ROOT/'flutter-sdk'
W=ROOT/'harper-workspace'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
LOCK='344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130'
assert sha(W/'pubspec.lock')==LOCK
assert (ROOT/'runtime-download.json').exists()
E=os.environ.copy();E.update(FLUTTER_ROOT=str(SDK),PUB_CACHE=str(ROOT/'pub-cache'),TMPDIR=str(ROOT/'tmp'),XDG_CONFIG_HOME=str(ROOT/'config'),CI='true',FLUTTER_SUPPRESS_ANALYTICS='true',DART_SUPPRESS_ANALYTICS='true')
D=str(SDK/'bin/cache/dart-sdk/bin/dart');T=str(SDK/'bin/cache/flutter_tools.snapshot')
R={'status':'running','tests_run':False,'production_files_modified':False,'lock_sha256_before':LOCK,'commands':[]}
def save():(ROOT/'harper-workspace-resolution.json').write_text(json.dumps(R,indent=2)+'\n')
def run(name,args,cwd):
 log=ROOT/'logs'/f'{name}.log';start=time.monotonic();r={'name':name,'command':args,'cwd':str(cwd),'status':'running','log':str(log)}
 R['commands'].append(r);save();print('START',name,flush=True)
 with log.open('w') as stream:
  p=subprocess.Popen(args,cwd=cwd,env=E,stdout=stream,stderr=subprocess.STDOUT)
  while p.poll() is None:
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:print('ACTIVE',name,round(time.monotonic()-start),flush=True)
   if time.monotonic()-start>600:
    p.terminate();p.wait(timeout=5);raise RuntimeError('Resolver exceeded 600 seconds')
 r.update(exit_code=p.returncode,status='passed' if p.returncode==0 else 'failed',elapsed_seconds=round(time.monotonic()-start,3),log_sha256=sha(log));save();assert p.returncode==0,name
run('precache-linux',[D,T,'precache','--linux','--no-android','--no-ios','--no-web','--no-windows','--no-macos'],ROOT)
run('canonical-workspace-pub-get',[D,T,'pub','get','--enforce-lockfile'],W)
assert sha(W/'pubspec.lock')==LOCK
config=W/'.dart_tool/package_config.json';g=json.loads(config.read_text())
assert g['flutterRoot']==SDK.as_uri()
assert g['flutterVersion']=='3.47.8'
setup=json.loads((ROOT/'harper-workspace-setup.json').read_text())
for p,s in setup['manifests_sha256'].items():assert sha(W/p)==s,p
assert sha(W/'pubspec.yaml')==setup['root_manifest_sha256']
assert sha(W/'analysis_options.yaml')==setup['root_analysis_options_sha256']
tester=SDK/'bin/cache/artifacts/engine/linux-x64/flutter_tester'
assert sha(tester)=='800f4ca182df7dd2fb46a42dea5d76277b9dbc5e8cd2915e02bcbc978681b45f'
assert subprocess.check_output(['git','-C',str(SDK),'status','--porcelain','--untracked-files=no'],text=True)==''
R.update(status='passed',package_count=len(g['packages']),lock_sha256_after=sha(W/'pubspec.lock'),package_config_sha256=sha(config),manifest_inputs_unchanged=True,flutter_tester_sha256=sha(tester));save();print('CANONICAL WORKSPACE READY',flush=True)
