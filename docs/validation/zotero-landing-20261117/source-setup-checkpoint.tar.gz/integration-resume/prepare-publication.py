#!/usr/bin/env python3
"""Create an exact Git-data publication plan for an already committed tree.

The caller uploads unknown blobs, creates the exact tree and commit via the
authenticated GitHub connector, then advances only the expected branch head.
This script does not access credentials, mutate refs, or contact GitHub.
"""
import argparse
import base64
import json
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--repository', required=True)
    parser.add_argument('--head', default='HEAD')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()

    def raw(*arguments):
        return subprocess.check_output(['git', *arguments], cwd=args.repo)

    def git(*arguments):
        return raw(*arguments).decode().strip()

    head = git('rev-parse', args.head + '^{commit}')
    parents = git('show', '-s', '--format=%P', head).split()
    assert parents, 'Publication must preserve existing repository history'
    known = set()
    for parent in parents:
        for line in git('ls-tree', '-r', parent).splitlines():
            known.add(line.split()[2])
    entries, uploads = [], []
    for path in git('diff', '--name-only', '--no-renames', parents[0], head).splitlines():
        line = git('ls-tree', head, '--', path)
        if not line:
            entries.append({'path': path, 'mode': '100644', 'type': 'blob', 'sha': None})
            continue
        metadata, path = line.split('\t', 1)
        mode, object_type, sha = metadata.split()
        entries.append({'path': path, 'mode': mode, 'type': object_type, 'sha': sha})
        if sha not in known:
            uploads.append({'path': path, 'sha': sha,
                            'content': base64.b64encode(raw('cat-file', 'blob', sha)).decode()})
            known.add(sha)
    result = {'repo': args.repository, 'local_commit': head, 'parents': parents,
              'tree': git('rev-parse', head + '^{tree}'),
              'base_tree': git('rev-parse', parents[0] + '^{tree}'),
              'message': git('show', '-s', '--format=%B', head),
              'entries': entries, 'uploads': uploads}
    args.output.write_text(json.dumps(result))
    print(json.dumps({'local_commit': head, 'parents': parents, 'tree': result['tree'],
                      'entries': len(entries), 'uploads': [
                          {'path': item['path'], 'sha': item['sha'], 'base64_bytes': len(item['content'])}
                          for item in uploads]}, indent=2))


if __name__ == '__main__':
    main()
