#!/usr/bin/env python3
"""Verify frozen incoming refs by ancestry or exact complete-tree equivalence."""
import argparse
import collections
import datetime
import json
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--head', required=True)
    parser.add_argument('--snapshot', type=Path, action='append', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()

    def git(*arguments):
        return subprocess.check_output(['git', *arguments], cwd=args.repo,
                                       text=True).strip()

    head = git('rev-parse', args.head + '^{commit}')
    ancestors = dict(row.split() for row in git('log', '--format=%H %T', head).splitlines())
    by_tree = {}
    for commit, tree in ancestors.items():
        by_tree.setdefault(tree, commit)
    counts = collections.Counter()
    records = []
    for path in args.snapshot:
        snapshot = json.loads(path.read_text())
        for ref in snapshot['refs']:
            commit = ref['commit']
            tree = git('rev-parse', commit + '^{tree}')
            status = ('ancestor' if commit in ancestors else
                      'exact_tree' if tree in by_tree else 'outstanding')
            counts[status] += 1
            records.append({**ref, 'repository': snapshot['repository'],
                            'tree': tree, 'status': status,
                            'integrated_commit': commit if status == 'ancestor'
                            else by_tree.get(tree),
                            'captured_at': snapshot['observed_at']})
    summary = {key: counts[key] for key in ('ancestor', 'exact_tree', 'outstanding')}
    result = {'head': head, 'tree': git('rev-parse', head + '^{tree}'),
              'reviewed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'criterion': 'commit ancestry or exact complete Git tree equality with an ancestor',
              'snapshot_files': [p.name for p in args.snapshot],
              'counts': summary, 'refs': records, 'passed': not counts['outstanding']}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'refs'}, indent=2))
    if counts['outstanding']:
        print(json.dumps([r for r in records if r['status'] == 'outstanding'], indent=2))
        raise SystemExit(1)


if __name__ == '__main__':
    main()
