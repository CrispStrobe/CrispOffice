#!/usr/bin/env python3
"""Archive explicit closed evidence files and read every member back."""
import argparse
import datetime
import hashlib
import io
import json
from pathlib import Path
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--files', type=Path, required=True)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--index', type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    source = json.loads(args.files.read_text())
    names = source['files'] if isinstance(source, dict) else source
    assert names and all(isinstance(name, str) for name in names)
    members = []
    args.archive.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.archive.with_suffix(args.archive.suffix + '.tmp')
    with tarfile.open(temporary, 'w:xz', preset=6) as archive:
        for name in sorted(set(names)):
            path = (root / name).resolve()
            assert path.is_relative_to(root) and path.is_file(), name
            relative = str(path.relative_to(root))
            data = path.read_bytes()
            item = tarfile.TarInfo(relative)
            item.size = len(data)
            item.mode = 0o644
            item.mtime = 0
            archive.addfile(item, io.BytesIO(data))
            members.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
    with tarfile.open(temporary, 'r:xz') as archive:
        assert len(archive.getmembers()) == len(members)
        for member in members:
            assert sha(archive.extractfile(member['path']).read()) == member['sha256']
            assert sha((root / member['path']).read_bytes()) == member['sha256'], 'Input changed during packaging'
    temporary.replace(args.archive)
    result = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'archive': args.archive.name, 'bytes': args.archive.stat().st_size,
              'sha256': sha(args.archive.read_bytes()), 'format': 'tar.xz',
              'member_count': len(members), 'verified_readback': True,
              'members': members}
    args.index.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'members'}, indent=2))


if __name__ == '__main__':
    main()
