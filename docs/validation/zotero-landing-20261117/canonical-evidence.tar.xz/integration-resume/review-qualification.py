#!/usr/bin/env python3
"""Independently verify fresh qualification receipts, logs, sources and preservation.
No application tests are executed and no source/runtime files are modified.
"""
import argparse,collections,datetime,gzip,hashlib,json,os,re,subprocess
from pathlib import Path
from urllib.parse import unquote,urlparse
B=Path(__file__).resolve().parents[1]
Q=B/'quds';H=B/'crispcloud'
QS='837d06edbde08a2465e99cbbb15927ee4c87d8ac'
HS='96c514eb98f7ba596a385c8f60496bc6c5994307'
QM='6860985f0a33e0fdff26c4e661a1faaf213b6a46'
HB='fae07f9e84036328aee271b5c14cda6b082cfab4'
LOCK='344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130'
PRIVATE={'TrueType subsets without cmap get ToUnicode cmap for the host','JPEG with DCT SMask attaches softMaskJpeg for the host'}
CANON_COMMANDS=['engine-strict-analysis','editor-strict-analysis','harper-strict-analysis','format','engine-zotero','editor-zotero','engine-integration','editor-integration','harper-contract']
HOST_COMMANDS=['vendor-source','vendor-tracked','host-tests','service-tests','host-analysis','vendor-analysis','host-format','viewer-format','vendor-format','python-sync-verifier-tests','whitespace','vendor-tracked-final']
def read(p):return json.loads(Path(p).read_text())
def digest(b):return hashlib.sha256(b).hexdigest()
def sha(p):
 p=Path(p);return digest(os.readlink(p).encode() if p.is_symlink() else p.read_bytes())
def git(r,*args):return subprocess.check_output(['git','-C',str(r),*args])
def txt(r,*args):return git(r,*args).decode().strip()
def trees(r,c):
 out={}
 for row in git(r,'ls-tree','-rz',c).split(b'\0'):
  if not row:continue
  a,p=row.split(b'\t',1);mode,kind,blob=a.decode().split();out[p.decode()]={'mode':mode,'type':kind,'blob':blob}
 return out
QT=trees(Q,QS);HT=trees(H,HS)
def source_check(repo,entries,recorded,canonical=False):
 if canonical:
  expected={p for p,v in entries.items() if v['type']=='blob' and not p.startswith('docs/')}
  assert set(recorded['files'])==expected,'Canonical input coverage incomplete'
  assert not recorded['commit_mismatches'] and not recorded['untracked_non_evidence_paths']
  rows=recorded['files']
 else:rows=recorded
 for p,v in rows.items():
  f=repo/p;raw=os.readlink(f).encode() if f.is_symlink() else f.read_bytes()
  blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
  mode='120000' if f.is_symlink() else ('100755' if f.stat().st_mode&0o111 else '100644')
  assert entries[p]['blob']==blob and entries[p]['mode']==mode,p
  assert digest(raw)==(v['sha256'] if canonical else v),p
  if canonical:assert v['git_blob']==blob and v['git_mode']==mode,p
 untracked=txt(repo,'ls-files','--others','--exclude-standard').splitlines()
 active=[p for p in untracked if p.startswith(('lib/','packages/','test/','tool/'))]
 assert not active,active
 return {'verified_input_count':len(rows),'all_recorded_bytes_and_modes_match_immutable_commit':True,'untracked_execution_inputs':active}
def equal_maps(folder,names):
 out={}
 for n in names:
  a=read(folder/(n+'-before.json'));b=read(folder/(n+'-after.json'));assert a==b,n
  out[n]={'before_sha256':sha(folder/(n+'-before.json')),'after_sha256':sha(folder/(n+'-after.json')),'semantically_equal':True}
 return out

def static_review():
 old=read(B/'canonical-validation/run-1/plan.json');new=read(B/'canonical-validation/run-2/plan.json')
 amendment=read(B/'canonical-validation/scope-amendment.json')
 failed=read(B/'canonical-validation/run-1/receipt.json')
 assert failed['status']=='failed' and failed['raw_runner_success_total']==0 and failed['substantive_success_total']==0
 assert [r['name'] for r in failed['commands']]==CANON_COMMANDS[:4]
 assert [r['exit_code'] for r in failed['commands']]==[0,0,0,1]
 assert failed['analysis_config_restored'] and all(failed['input_integrity'].values())
 equal_maps(B/'canonical-validation/run-1',['source','dependencies','runtime','workspace','system','harness'])
 failed_logs=[]
 for r in failed['commands']:
  for stream in ['stdout','stderr']:
   p=B/'canonical-validation/run-1'/r[stream];packed=p.read_bytes();raw=gzip.decompress(packed)
   assert digest(raw)==r[stream+'_sha256'] and digest(packed)==r[stream+'_gzip_sha256']
  failed_logs.append({'name':r['name'],'exit_code':r['exit_code'],'logs_verified':True})
 base=trees(Q,QM);diagnostics=[]
 log=gzip.decompress((B/'canonical-validation/run-1/format/stdout.gz').read_bytes()).decode()
 paths=re.findall(r'^Changed (.+)$',log,re.M)
 assert len(paths)==4
 for p in paths:
  assert base[p]==QT[p],p
  diagnostics.append({'path':p,'git_entry':QT[p],'same_main_and_final_blob_and_mode':True})
 assert old['cohorts']==new['cohorts']
 assert old['analysis_and_format_targets']==new['analysis_targets']
 targets=set(new['format_targets'])
 changed={p for p in txt(Q,'diff','--name-only',QM,QS).splitlines() if p.endswith('.dart') and not p.startswith('docs/') and p in QT}
 assert changed<=targets and len(changed)==77 and len(targets)==81
 assert sum(map(len,new['analysis_targets'].values()))==123
 assert sha(B/'canonical-validation/run-1/run-used.py')==amendment['prior_runner_sha256']
 assert sha(B/'canonical-validation/run-2/run-used.py')==amendment['amended_runner_sha256']
 assert sha(B/'canonical-validation/run-1-to-run-2.patch')==amendment['runner_patch_sha256']
 preserved=read(B/'integration-resume/source-preservation.json');pt=trees(Q,preserved['baseline'])
 assert len(preserved['zotero_paths'])==50
 for row in preserved['zotero_paths']:assert pt[row['path']]==QT[row['path']],row['path']
 recovered='b4647f1c3aa60300116b27c3bce741b80ee39328';rt=trees(Q,recovered)
 for row in preserved['zotero_paths']:assert rt[row['path']]==QT[row['path']],row['path']
 manifest=json.loads(git(H,'show',HS+':tool/office_fidelity_manifest.json'))
 assert manifest['source_commit']==QS and len(manifest['files'])==2554
 basehost=trees(H,HB);bm=json.loads(git(H,'show',HB+':tool/office_fidelity_manifest.json'));basequds=trees(Q,bm['source_commit'])
 modes=[];canonical=0;parser=0
 for p,expected_hash in manifest['files'].items():
  raw=(H/p).read_bytes();assert digest(raw)==expected_hash,p
  assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==HT[p]['blob'],p
  if p.startswith('packages/legacy_doc_parser/'):parser+=1;continue
  canonical+=1;assert QT[p]['blob']==HT[p]['blob'],p
  if QT[p]['mode']!=HT[p]['mode']:
   assert basehost[p]['blob']==basequds[p]['blob'],p
   assert basehost[p]['mode']==HT[p]['mode'] and basequds[p]['mode']==QT[p]['mode'],p
   modes.append({'path':p,'host_mode':HT[p]['mode'],'canonical_mode':QT[p]['mode'],'baseline_host_blob':basehost[p]['blob'],'baseline_canonical_blob':basequds[p]['blob'],'already_managed_in_baseline':p in bm['files'],'inherited_verified':True})
 assert len(modes)==12 and canonical==697 and parser==1857
 assert len([p for p in modes if not p['already_managed_in_baseline']])==4
 final=read(B/'host-audit/final-preservation.json')
 assert final['passed'] and not final['failures']
 for r in final['host_customizations']+final['notices']:assert basehost[r['path']]==HT[r['path']],r['path']
 assert len(final['host_customizations'])==20 and len(final['notices'])==6
 assert git(H,'ls-tree',HB,'--','packages/legacy_doc_parser')==git(H,'ls-tree',HS,'--','packages/legacy_doc_parser')
 return {'format_scope_amendment':{'first_attempt':{'status':'failed','test_executions':0,'commands':failed_logs,'all_input_maps_unchanged':True,'analyzer_config_restored':True},'inherited_diagnostics':diagnostics,'strict_analysis_targets':123,'strict_analysis_and_test_cohorts_unchanged':True,'changed_existing_non_evidence_dart_paths':77,'amended_format_targets':81,'no_changed_dart_path_excluded':True,'scope_amendment_sha256':sha(B/'canonical-validation/scope-amendment.json'),'runner_patch_sha256':sha(B/'canonical-validation/run-1-to-run-2.patch')},'zotero_preservation':{'path_count':50,'baseline':preserved['baseline'],'original_recovered_source':recovered,'all_blobs_and_modes_unchanged':True},'host_preservation':{'baseline_host':HB,'baseline_canonical':bm['source_commit'],'managed_count':2554,'canonical_count':697,'parser_count':1857,'all_managed_content_hashes_verified':True,'host_customizations_unchanged':20,'notices_unchanged':6,'parser_subtree_unchanged':True,'all_mode_differences':modes,'mode_difference_count':12,'newly_managed_already_inherited_modes':4,'scope_correction':'Earlier eight-item list was incomplete for the expanded managed inventory; all twelve current mismatches are inherited from immutable baseline trees.'}}

def canonical_review(folder):
 r=read(folder/'receipt.json');assert r['status']=='passed' and r['all_passed'] and r['source_commit']==QS and r['working_head_after']==QS
 assert r['source_tree']==txt(Q,'rev-parse',QS+'^{tree}')
 assert [x['name'] for x in r['commands']]==CANON_COMMANDS
 assert all(r['input_integrity'].values()) and r['analysis_config_restored']
 plan=read(folder/'plan.json');assert sha(folder/'plan.json')==r['plan_sha256']
 assert sha(folder/'run-used.py')==r['runner_sha256']==sha(B/'canonical-validation/run_qualification.py')
 files=[(c['kind'],p) for c in plan['cohorts'].values() for p in c['tests']]
 assert len(files)==len(set(files))==144
 rows=[];total=0;exclusions=[]
 for c in r['commands']:
  assert c['status']=='passed' and c['exit_code']==0 and not c['timed_out'],c['name']
  content={}
  for s in ['stdout','stderr']:
   packed=(folder/c[s]).read_bytes();raw=gzip.decompress(packed)
   assert digest(raw)==c[s+'_sha256'] and digest(packed)==c[s+'_gzip_sha256'],c['name']
   content[s]=raw
  row={'name':c['name'],'exit_code':0,'stdout_sha256':digest(content['stdout']),'stderr_sha256':digest(content['stderr'])}
  if c['name'] in plan['cohorts']:
   events=[]
   for line in content['stdout'].decode().splitlines():
    try:v=json.loads(line)
    except ValueError:continue
    if isinstance(v,dict):events.append(v)
   done=[e for e in events if e.get('type')=='done'];assert len(done)==1 and done[0]['success']
   assert not [e for e in events if e.get('type')=='error']
   starts={e['test']['id']:e['test'] for e in events if e.get('type')=='testStart'}
   suites={e['suite']['id']:e['suite'] for e in events if e.get('type')=='suite'}
   finishes=[e for e in events if e.get('type')=='testDone' and not e.get('hidden')]
   assert len(finishes)==len({e['testID'] for e in finishes}),c['name']
   counts=collections.Counter(('skipped' if e.get('skipped') else e.get('result')) for e in finishes)
   assert set(counts)=={'success'},counts
   omitted=[]
   for e in finishes:
    t=starts[e['testID']];s=suites[t['suiteID']]
    if s['path'].endswith('/pdf_file_test.dart') and any(t['name']==n or t['name'].endswith(' '+n) for n in PRIVATE):
     omitted.append({'name':t['name'],'suite':s['path'],'test_id':e['testID']})
   if c['name']=='engine-integration':assert len(omitted)==2 and read(folder/'system-before.json')['/home/mohammed/Desktop/al_tahreer_profile.pdf'] is None
   else:assert not omitted
   actual=[unquote(urlparse(s['path']).path) if s['path'].startswith('file:') else s['path'] for s in suites.values()]
   selected=plan['cohorts'][c['name']]['tests']
   cwd=Path(c['cwd'])
   expected_paths={(cwd/p).resolve() for p in selected}
   observed_paths={(Path(p) if Path(p).is_absolute() else cwd/p).resolve() for p in actual}
   assert observed_paths==expected_paths,{'missing':sorted(map(str,expected_paths-observed_paths)),'unexpected':sorted(map(str,observed_paths-expected_paths))}
   rawcount=counts['success'];sub=rawcount-len(omitted)
   assert c['test_summary']['raw_success_count']==rawcount and c['test_summary']['substantive_success_count']==sub
   if c['name']=='engine-zotero':assert rawcount==390
   if c['name']=='editor-zotero':assert rawcount==186
   row.update(raw_success_count=rawcount,substantive_success_count=sub,excluded_optional_private_pdf_cases=omitted,test_file_count=len(selected),duplicate_terminal_test_ids=False,terminal_success=True)
   total+=sub;exclusions+=omitted
  rows.append(row)
 assert total==r['substantive_success_total'] and total+2==r['raw_runner_success_total']
 maps=equal_maps(folder,['source','dependencies','runtime','workspace','system','harness'])
 source=source_check(Q,QT,read(folder/'source-after.json'),True)
 for key in ['runtime','workspace','system','harness']:
  for p,s in read(folder/(key+'-after.json')).items():
   assert (sha(p) if Path(p).is_file() else None)==s,(key,p)
 dep=read(folder/'dependencies-after.json')
 for p,s in dep['sha256_by_path'].items():assert sha(p)==s,p
 cfg=Q/'.dart_tool/package_config.json'
 assert (sha(cfg) if cfg.exists() else None)==r['original_analyzer_config_sha256']
 assert sha(Path(r['test_workspace'])/'pubspec.lock')==LOCK
 return {'receipt_sha256':sha(folder/'receipt.json'),'source_commit':QS,'source_tree':r['source_tree'],'commands':rows,'command_count':9,'selected_disjoint_test_files':144,'qualified_test_passes':total,'raw_runner_successes':total+2,'excluded_private_pdf_cases':exclusions,'prior_attempt_passes_added':0,'input_maps':maps,'source_binding':source,'dependency_inputs_verified':len(dep['sha256_by_path']),'current_runtime_workspace_system_harness_hashes_match_records':True,'analyzer_config_restored':True}

def host_review(folder):
 r=read(folder/'receipt.json');assert r['status']=='passed' and r['source_commit']==HS and r['quds_commit']==QS
 assert r['implementation_tree']==txt(H,'rev-parse',HS+'^{tree}')
 assert [c['name'] for c in r['commands']]==HOST_COMMANDS and r['all_required_commands_completed']
 assert r['source_unchanged'] and r['dependencies_unchanged'] and r['analysis_config_restored'] and r['tracked_inputs_match_published_source_at_completion']
 assert sha(B/'host-audit/run-host-qualification.py')==r['reproduction_script_sha256']
 rows=[];cohorts={}
 for c in r['commands']:
  assert c['status']=='passed' and c['exit_code']==0 and not c['timed_out'] and not c['execution_error'],c['name']
  log=(folder/c['log']).read_bytes();assert digest(log)==c['log_sha256'],c['name']
  s=log.decode();row={'name':c['name'],'exit_code':0,'log_sha256':digest(log)}
  if c['name'] in ['host-tests','service-tests']:
   terminal=re.findall(r'\+(\d+)(?:\s+~(\d+))?(?:\s+-(\d+))?: All tests passed!',s)
   assert len(terminal)==1 and not int(terminal[0][1] or 0) and not int(terminal[0][2] or 0)
   count=int(terminal[0][0]);assert count==(41 if c['name']=='host-tests' else 39)
   row.update(test_passes=count,skips=0,terminal_success=True);cohorts[c['name']]=count
  if c['name']=='python-sync-verifier-tests':
   counts=re.findall(r'Ran (\d+) tests? in',s);assert counts==['28'] and re.search(r'^OK\s*$',s,re.M) and not re.search(r'\bskipped=',s)
   row.update(test_passes=28,skips=0,terminal_success=True);cohorts[c['name']]=28
  rows.append(row)
 assert cohorts=={'host-tests':41,'service-tests':39,'python-sync-verifier-tests':28}
 assert r['passed_host_tests']==41 and r['passed_service_tests']==39 and r['passed_python_tests']==28
 assert not set(r['tests'])&set(r['service_tests'])
 maps=equal_maps(folder,['source','dependencies']);source=source_check(H,HT,read(folder/'source-after.json'))
 dep=read(folder/'dependencies-after.json');h=Path(r['harness'])
 for k,s in dep['dependency_files'].items():
  if k.startswith('.dart_tool/') or k=='analysis_options.yaml':p=h/k
  else:
   name,rel=k.split('/',1);root=dep['package_roots'][name]
   p=Path(root['library'])/rel.removeprefix('lib/') if rel.startswith('lib/') else Path(root['root'])/rel
  assert digest(p.read_bytes())==s,k
 for name,v in dep['declarations'].items():
  p=h/name.removeprefix('harness/');assert digest(p.read_bytes())==v['sha256'],name
 for p,s in dep['runtime_files'].items():assert sha(B/'runtime/flutter-sdk'/p)==s,p
 cfg=H/'.dart_tool/package_config.json';assert (sha(cfg) if cfg.exists() else None)==r['analysis_config_before_sha256']
 return {'receipt_sha256':sha(folder/'receipt.json'),'source_commit':HS,'canonical_pin':QS,'source_tree':r['implementation_tree'],'commands':rows,'command_count':12,'test_cohorts':cohorts,'test_passes':108,'counts_overlap_historical_runs_not_added_as_unique':True,'input_maps':maps,'source_binding':source,'dependency_inputs_verified':len(dep['dependency_files']),'analyzer_config_restored':True,'limitations':r['limitations'],'viewer_analysis':r['viewer_analysis']}

def correction_review():
 correction=read(B/'canonical-validation/suite-path-correction.json')
 r=read(B/'canonical-validation/run-2/receipt.json');r2=read(B/'canonical-validation/run-2/plan.json');r3=read(B/'canonical-validation/run-3/plan.json')
 assert r['status']=='failed' and r['raw_runner_success_total']==390 and r['analysis_config_restored'] and all(r['input_integrity'].values())
 assert r2==r3,'Source or cohort/format scope changed in path correction'
 equal_maps(B/'canonical-validation/run-2',['source','dependencies','runtime','workspace','system','harness'])
 assert sha(B/'canonical-validation/run-2/run-used.py')==correction['before_runner_sha256']
 assert sha(B/'canonical-validation/run-3/run-used.py')==correction['after_runner_sha256']
 assert sha(B/'canonical-validation/run-2-to-run-3.patch')==correction['runner_patch_sha256']
 for c in r['commands']:
  for stream in ['stdout','stderr']:
   packed=(B/'canonical-validation/run-2'/c[stream]).read_bytes();raw=gzip.decompress(packed)
   assert digest(raw)==c[stream+'_sha256'] and digest(packed)==c[stream+'_gzip_sha256']
 c=next(x for x in r['commands'] if x['name']=='engine-zotero');assert c['exit_code']==0
 raw=gzip.decompress((B/'canonical-validation/run-2'/c['stdout']).read_bytes()).decode();events=[]
 for line in raw.splitlines():
  try:e=json.loads(line)
  except ValueError:continue
  if isinstance(e,dict):events.append(e)
 terminal=[e for e in events if e.get('type')=='done'];assert len(terminal)==1 and terminal[0]['success']
 finished=[e for e in events if e.get('type')=='testDone' and not e.get('hidden')]
 assert len(finished)==390 and len({e['testID'] for e in finished})==390 and all(e['result']=='success' and not e['skipped'] for e in finished)
 assert not [e for e in events if e.get('type')=='error']
 observed=[e['suite']['path'] for e in events if e.get('type')=='suite'];cwd=Path(c['cwd'])
 observed_paths={(Path(unquote(urlparse(p).path)) if p.startswith('file:') else (Path(p) if Path(p).is_absolute() else cwd/p)).resolve() for p in observed}
 expected={(cwd/p).resolve() for p in r2['cohorts']['engine-zotero']['tests']}
 assert observed_paths==expected and len(expected)==19
 return {'failed_attempt':'run-2','failure_type':'Reporter relative-path bookkeeping; terminal application cohort passed but whole qualification rejected.','raw_engine_passes':390,'terminal_success':True,'raw_reporter_suite_count':19,'all_observed_suite_identities_equal_selected_after_resolving_exact_command_cwd':True,'source_scope_analysis_format_test_plan_unchanged':True,'all_input_maps_unchanged':True,'analyzer_restored':True,'accepted_count_contribution':0,'patch_sha256':correction['runner_patch_sha256'],'amendment_sha256':sha(B/'canonical-validation/suite-path-correction.json')}

def supplemental_review():
 f=B/'host-audit/supplemental';r=read(f/'receipt.json')
 assert r['status']=='passed' and r['source_commit']==HS and r['canonical_source']==QS
 assert r['source_tree']==txt(H,'rev-parse',HS+'^{tree}') and r['exit_code']==0 and not r['timed_out']
 log=(f/r['log']).read_bytes();assert digest(log)==r['log_sha256']
 terminal=re.findall(rb'\+(\d+)(?:\s+~(\d+))?: All tests passed!',log)
 assert len(terminal)==1 and int(terminal[0][0])==2 and not int(terminal[0][1] or 0)
 assert r['passed_tests']==2 and r['skipped_tests']==0
 assert r['source_unchanged'] and r['dependencies_unchanged'] and r['tracked_inputs_match_source'] and r['probe_unchanged']
 assert sha(Path(r['probe_path']))==r['probe_sha256'] and sha(B/'host-audit/run-supplemental.py')==r['script_sha256']
 h=B/'host-audit/service-harness';assert (h/'probes/odt_writer_host_test.dart').resolve()==Path(r['probe_path'])
 assert (h/r['fixture_path']).resolve()==H/r['fixture_path']
 assert sha(H/r['fixture_path'])==r['fixture_sha256'] and HT[r['fixture_path']]['blob']==r['fixture_git_blob']
 maps=equal_maps(f,['source','dependencies'])
 assert read(f/'source-before.json')==read(B/'host-audit/qualification/source-after.json')
 assert read(f/'dependencies-before.json')==read(B/'host-audit/qualification/dependencies-after.json')
 return {'source_commit':HS,'canonical_pin':QS,'receipt_sha256':sha(f/'receipt.json'),'log_sha256':digest(log),'passed_tests':2,'skipped_tests':0,'terminal_success':True,'fixture_and_probe_bindings_verified':True,'input_maps':maps,'recorded_separately_from_required_host_108':True,'does_not_claim_ui_acceptance':True}

def main():
 p=argparse.ArgumentParser();p.add_argument('--static-only',action='store_true');a=p.parse_args()
 result={'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'independent-runtime-agent','method':'Read-only review; independent Git tree and byte hashing, JSON terminal event recount, command-log hash verification, test-file disjointness and input/config restoration checks. No application tests rerun.','source_pair':{'quds':QS,'host':HS},'static_checks':static_review()}
 if a.static_only:name='independent-static-review.json'
 else:
  result['canonical']=canonical_review(B/'canonical-validation/run-3')
  result['suite_path_correction']=correction_review()
  result['supplemental_odt_writer_to_host']=supplemental_review()
  result['host']=host_review(B/'host-audit/qualification')
  result['status']='passed';result['blocking_discrepancies']=[];name='independent-review.json'
 result['review_script_sha256']=sha(Path(__file__))
 (B/'integration-resume'/name).write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'output':name,'status':result.get('status','static checks passed'),'canonical_passes':result.get('canonical',{}).get('qualified_test_passes'),'host_passes':result.get('host',{}).get('test_passes')}))
if __name__=='__main__':main()
