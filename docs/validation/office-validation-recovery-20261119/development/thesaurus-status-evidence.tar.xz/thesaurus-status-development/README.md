# Thesaurus, proofing status and incoming Studio regression evidence

This directory preserves exact source-bound development observations after the
incoming main and PR199 integrations. It is not a frozen aggregate acceptance.
The original raw reporters, stderr, command receipts, relevant source copies,
strict analysis output and precise incoming-to-final diffs are retained.

| Record | Passed | Failed | Skipped |
| --- | ---: | ---: | ---: |
| Incoming thesaurus reset subset | 1 | 3 | 0 |
| Repaired full thesaurus VM suite | 28 | 0 | 0 |
| Repaired full thesaurus Node suite | 28 | 0 | 0 |
| Incoming Word summary subset | 1 | 1 | 0 |
| Repaired full Word proofing session suite | 33 | 0 | 0 |
| Incoming PR199 Studio language suite | 3 | 1 | 0 |
| Adjusted PR199 Studio language suite | 4 | 0 | 0 |

The thesaurus now checks its epoch both when optional relation-label loading
fails and after the complete relation-resolution await. Reset cannot publish
an obsolete ready result or replace the newer cached result. An unavailable
optional relation label still leaves the verified main entry usable.

Word summary completeness again requires every text snapshot's report to have
a successful checker. Existing ordinary-session counts already kept a mixed
supported/unsupported document partial; the demonstrated defect was the public
summary accepting supplied full-coverage counts that contradicted its reports.
Successful language-specific providers still complete their supported paragraphs,
and irrelevant unsupported-provider warnings remain hidden.

The incoming Studio suite's only failure expected the word `library` from the
host. Its assertion now matches the existing fixed public message, `Automatic
language detection is unavailable.` The host implementation was not changed.
The other model-hash, settings/routing/apply/undo and license assertions remain.

All five changed Dart targets pass analysis with fatal infos. Formatting and
whitespace checks pass. The final source bytes exactly match their successful
runtime runs; no post-run source adjustment was necessary. Receipts bind each
run to source hashes and its then-current integration HEAD. The thesaurus runs
preceded the secure-storage dependency extension but import no new plugin;
the Flutter runs used the completed extended runtime. Runtime preparation itself
is preserved separately by the integration owner.

Two raw stderr records contain an ordinary Flutter startup-lock wait while
independent package tests began concurrently. No raw record was rewritten, no
case was retried, and no GitHub Actions run, job, queue or status was queried or
awaited. No final aggregate, full-corpus, real-provider or installed-platform
acceptance is implied. Studio routing uses a controlled classifier; the missing
native-library case deliberately tests unavailability.
