#!/usr/bin/env python3
"""Strictly analyze the five changed targets, then check format and whitespace."""
import json, subprocess, sys
repo='/workspace/scratch/1db61dbeed56/quds_office_suite'
paths=[
 'packages/quds_office_engine/lib/src/thesaurus/office_thesaurus.dart',
 'packages/quds_office_engine/test/office_thesaurus_test.dart',
 'packages/quds_office_editor/lib/src/proofing/word_proofing.dart',
 'packages/quds_office_editor/test/word_proofing_session_test.dart',
 'packages/quds_office_editor/example/test/studio_language_id_test.dart',
]
commands=[['dart','analyze','--fatal-infos',path] for path in paths]
commands.extend([
 ['dart','format','--output=none','--set-exit-if-changed',*paths],
 ['git','diff','--check','--',*paths],
])
failed=False
for command in commands:
 print(json.dumps({'command':command}),flush=True)
 result=subprocess.run(command,cwd=repo)
 print(json.dumps({'exit_code':result.returncode}),flush=True)
 failed=failed or result.returncode!=0
sys.exit(int(failed))
