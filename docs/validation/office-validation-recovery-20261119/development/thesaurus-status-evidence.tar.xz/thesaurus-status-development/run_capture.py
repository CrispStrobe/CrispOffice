#!/usr/bin/env python3
"""Capture a focused command and its exact relevant source bytes."""
import argparse, datetime, hashlib, json, pathlib, subprocess
p=argparse.ArgumentParser()
p.add_argument('--label',required=True)
p.add_argument('--cwd',required=True)
p.add_argument('--source',action='append',default=[])
p.add_argument('command',nargs=argparse.REMAINDER)
a=p.parse_args()
if a.command and a.command[0]=='--': a.command=a.command[1:]
if not a.command: p.error('missing command')
out=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/workspace/scratch/1db61dbeed56/quds_office_suite')
base=out/a.label
for suffix in ['.stdout','.stderr','.receipt.json']:
    if pathlib.Path(str(base)+suffix).exists(): raise SystemExit('refusing to overwrite '+str(base)+suffix)
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def gitref(ref):
    r=subprocess.run(['git','rev-parse','--verify',ref],cwd=repo,capture_output=True,text=True)
    return r.stdout.strip() if r.returncode==0 else None
sources=[]
for rel in a.source:
    path=repo/rel
    data=path.read_bytes()
    copy=out/(a.label+'.source.'+path.name)
    copy.write_bytes(data)
    sources.append({'path':rel,'copy':copy.name,'before_sha256':hashlib.sha256(data).hexdigest()})
receipt={'label':a.label,'command':a.command,'cwd':a.cwd,'started_utc':stamp(),'head_at_start':gitref('HEAD'),'merge_head_at_start':gitref('MERGE_HEAD'),'sources':sources}
with pathlib.Path(str(base)+'.stdout').open('wb') as stdout, pathlib.Path(str(base)+'.stderr').open('wb') as stderr:
    result=subprocess.run(a.command,cwd=a.cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
receipt.update({'finished_utc':stamp(),'exit_code':result.returncode,'head_at_end':gitref('HEAD')})
for source in sources:
    source['after_sha256']=hashlib.sha256((repo/source['path']).read_bytes()).hexdigest()
    source['unchanged_during_run']=source['before_sha256']==source['after_sha256']
for suffix in ['.stdout','.stderr']:
    data=pathlib.Path(str(base)+suffix).read_bytes()
    receipt[suffix[1:]]={'file':a.label+suffix,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()}
pathlib.Path(str(base)+'.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
