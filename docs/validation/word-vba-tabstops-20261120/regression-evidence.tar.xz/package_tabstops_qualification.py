"""Preserve the completed, source-bound local Word/VBA qualification."""
from collections import Counter
from io import BytesIO
from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'quds_office_suite'
RUNTIME = ROOT / 'runtime'
DEST = REPO / 'docs/validation/word-vba-tabstops-20261120'
SOURCE = 'b5410b107a83f213e27c1476e766551b3f6cd6a4'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(name, value):
    (DEST / name).write_text(json.dumps(value, indent=2) + '\n')


summary = json.loads((RUNTIME / 'tabstops-parallel-gate/summary.json').read_text())
expected_files = json.loads((RUNTIME / 'word-tabstops-gate-files.json').read_text())
assert summary['source_commit'] == SOURCE
assert summary['complete'] and summary['inputs_unchanged']
assert summary['file_count'] == len(expected_files) == len(set(expected_files)) == 59
assert summary['failed_cases'] == summary['skipped_cases'] == 0
assert summary['passing_cases'] == summary['distinct_cases'] == len(summary['accepted_cases'])
assert set(summary['per_file_cases']) == set(expected_files)
assert all(group['accepted'] and group['exit_code'] == 0 for group in summary['groups'])
assert Counter(file for group in summary['groups'] for file in group['files']) == Counter(expected_files)
with gzip.open(RUNTIME / 'tabstops-parallel-gate/source-git-binding.json.gz', 'rt') as stream:
    binding = json.load(stream)
assert len(binding) == summary['input_entries'] == 1110
for name, entry in binding.items():
    assert digest((REPO / name).read_bytes()) == entry['sha256'], name

members = {}
for directory in ('tabstops-gate', 'tabstops-parallel-gate'):
    for path in sorted((RUNTIME / directory).rglob('*')):
        if path.is_file():
            members[str(path.relative_to(RUNTIME))] = path.read_bytes()
for name in (
    'run_word_tabstops_gate.py', 'run_word_tabstops_parallel_gate.py',
    'run-engine-tests.sh', 'run-engine-tests.before-boundary.sh',
    'run-engine-tests.boundary-guarded.sh',
    'stop-serial-gate-boundary.py', 'env.sh', 'environment.json',
    'word-tabstops-gate-files.json',
    'tabstops-gate-progress.log', 'tabstops-gate-runner.stderr',
    'tabstops-parallel-gate.log', 'tabstops-parallel-gate.stderr',
    'tabstops-engine-analysis.stdout', 'tabstops-engine-analysis.stderr',
    'tabstops-format.stdout', 'tabstops-format.stderr',
    'run-word-tabstops-portable.py',
    'evidence-review.json',
):
    members[name] = (RUNTIME / name).read_bytes()
members['package_tabstops_qualification.py'] = Path(__file__).read_bytes()
for path in (
    RUNTIME / 'validation-workspace/pubspec.yaml',
    RUNTIME / 'validation-workspace/pubspec.lock',
    RUNTIME / 'validation-workspace/.dart_tool/package_config.json',
    REPO / '.dart_tool/package_config.json',
):
    prefix = 'isolated-runtime/' if path.is_relative_to(RUNTIME) else 'checkout-runtime/'
    relative = path.relative_to(RUNTIME / 'validation-workspace') if path.is_relative_to(RUNTIME) else path.relative_to(REPO)
    members[prefix + str(relative)] = path.read_bytes()
archive = DEST / 'regression-evidence.tar.xz'
with tarfile.open(archive, 'w:xz', format=tarfile.PAX_FORMAT) as tar:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, BytesIO(data))
with tarfile.open(archive, 'r:xz') as tar:
    assert set(tar.getnames()) == set(members)
    for name, data in members.items():
        assert tar.extractfile(name).read() == data
receipt = {key: value for key, value in summary.items() if key != 'accepted_cases'}
receipt['archive'] = {
    'path': archive.name,
    'sha256': digest(archive.read_bytes()),
    'bytes': archive.stat().st_size,
    'members': {name: {'sha256': digest(data), 'bytes': len(data)}
                for name, data in sorted(members.items())},
}
receipt['counting'] = (
    'Counts only the eight accepted, disjoint groups from the final frozen-source '
    '59-file cohort. Hidden loading/setup events and all development or partial '
    'checkpoints are excluded. Original groups01/02 were independently re-audited '
    'and retained; the original group03 startup was stopped before Dart and is '
    'archived only as an excluded attempt.'
)
write_json('regression.json', receipt)
changed = subprocess.check_output([
    'git', 'diff', '--name-only', '49d0fe9966edff96e2cbda7e483a9ba8a689219a', SOURCE,
    '--', 'packages/quds_office_engine',
], cwd=REPO, text=True).splitlines()
dart_files = [name for name in changed if name.endswith('.dart')]
assert len(dart_files) == 9
format_output = (RUNTIME / 'tabstops-format.stdout').read_text()
format_errors = (RUNTIME / 'tabstops-format.stderr').read_text()
assert 'Formatted 9 files (0 changed)' in format_output and not format_errors
write_json('format.json', {
    'source_commit': SOURCE,
    'command': ['dart', 'format', '--language-version=3.12', '--output=none',
                '--set-exit-if-changed', *dart_files],
    'exit_code': 0, 'stdout': format_output, 'stderr': format_errors,
    'files': len(dart_files), 'changed': 0,
})
print(json.dumps({
    'source_commit': SOURCE,
    'files': summary['file_count'], 'passing_cases': summary['passing_cases'],
    'input_entries': len(binding), 'archive_bytes': archive.stat().st_size,
    'archive_members': len(members), 'archive_sha256': digest(archive.read_bytes()),
}, indent=2))
