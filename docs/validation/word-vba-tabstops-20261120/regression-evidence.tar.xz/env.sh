export QUDS_VALIDATION_ROOT=/workspace/scratch/02ca2ade0467/runtime/validation-workspace
export QUDS_DART_ROOT=/workspace/scratch/02ca2ade0467/runtime/dart-sdk
export PUB_CACHE=/workspace/scratch/02ca2ade0467/runtime/pub-cache
export TMPDIR=/workspace/scratch/02ca2ade0467/runtime/tmp
export PATH="$QUDS_DART_ROOT/bin:$PATH"
