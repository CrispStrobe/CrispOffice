from pathlib import Path
import datetime,json,os,signal,sys
root=Path('/workspace/scratch/02ca2ade0467')
expected=root/'runtime/run_word_tabstops_gate.py'
shell=os.getppid()
stat=Path('/proc')/str(shell)/'stat'
parts=stat.read_text().rsplit(')',1)[1].split()
parent=int(parts[1])
args=(Path('/proc')/str(parent)/'cmdline').read_bytes().rstrip(b'\0').split(b'\0')
args=[os.fsdecode(arg) for arg in args]
if len(args)!=4 or not Path(args[0]).name.startswith('python'):
 raise SystemExit(0)
parent_cwd=Path(os.readlink(Path('/proc')/str(parent)/'cwd'))
def resolve_arg(arg):
 p=Path(arg)
 return (p if p.is_absolute() else parent_cwd/p).resolve()
if resolve_arg(args[1])!=expected or resolve_arg(args[2])!=root/'quds_office_suite' or resolve_arg(args[3])!=root/'runtime':
 raise SystemExit(0)
receipt={'reason':'Authorized change from serial qualification to max two bounded runners; stopped before spawning next group Dart process.','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_pid':parent,'parent_cwd':str(parent_cwd),'exact_parent_command':args,'next_group_arguments':sys.argv[1:],'signal':'SIGTERM','native_test_process_started':False}
p=root/'runtime/tabstops-gate/stopped-at-boundary.json'
temporary=p.with_suffix('.pending')
with temporary.open('w') as f:
 json.dump(receipt,f,indent=2)
 f.write('\n')
 f.flush()
 os.fsync(f.fileno())
temporary.replace(p)
os.kill(parent,signal.SIGTERM)
raise SystemExit(85)
