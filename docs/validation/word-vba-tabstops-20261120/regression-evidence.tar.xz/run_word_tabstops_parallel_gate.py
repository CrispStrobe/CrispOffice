"""Complete one frozen 59-file cohort with two serial lanes and strict receipts."""
from __future__ import annotations

from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading
import time


ROOT = Path('/workspace/scratch/02ca2ade0467')
REPO = ROOT / 'quds_office_suite'
RUNTIME = ROOT / 'runtime'
SERIAL = RUNTIME / 'tabstops-gate'
OUT = RUNTIME / 'tabstops-parallel-gate'
SOURCE = 'b5410b107a83f213e27c1476e766551b3f6cd6a4'
FILES = json.loads((RUNTIME / 'word-tabstops-gate-files.json').read_text())
GROUPS = [FILES[index:index + 8] for index in range(0, len(FILES), 8)]
LOCK = threading.Lock()


def utc():
    return datetime.now(timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, data):
    temporary = path.with_name(path.name + '.new')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(path)


def compressed_json(path, data):
    with gzip.open(path, 'wt') as stream:
        json.dump(data, stream, sort_keys=True)


with gzip.open(SERIAL / 'inputs-before.json.gz', 'rt') as stream:
    BASELINE = json.load(stream)


def capture():
    result = {}
    for name in BASELINE:
        path = REPO / name
        content = path.read_bytes()
        result[name] = {
            'sha256': hashlib.sha256(content).hexdigest(),
            'bytes': len(content),
            'mode': '100755' if os.access(path, os.X_OK) else '100644',
        }
    return result


def source_binding():
    raw = subprocess.check_output(
        ['git', 'ls-tree', '-rz', '--full-tree', SOURCE], cwd=REPO)
    tree = {}
    for entry in raw.split(b'\0'):
        if not entry:
            continue
        metadata, name = entry.split(b'\t', 1)
        mode, kind, blob = metadata.decode().split()
        tree[os.fsdecode(name)] = (mode, kind, blob)
    binding = {}
    for name, expected in BASELINE.items():
        content = (REPO / name).read_bytes()
        blob = hashlib.sha1(
            b'blob ' + str(len(content)).encode() + b'\0' + content
        ).hexdigest()
        mode, kind, expected_blob = tree[name]
        if kind != 'blob' or expected_blob != blob or mode != expected['mode']:
            raise ValueError(f'Input does not match frozen Git source: {name}')
        if hashlib.sha256(content).hexdigest() != expected['sha256']:
            raise ValueError(f'Input changed since serial gate began: {name}')
        binding[name] = {**expected, 'git_mode': mode,
                         'git_type': kind, 'git_blob': blob}
    return binding


def audit_events(stdout, expected_files, exit_code):
    lines = stdout.read_text().splitlines()
    events = [json.loads(line) for line in lines if line.strip()]
    starts = [event for event in events if event.get('type') == 'start']
    dones = [event for event in events if event.get('type') == 'done']
    problems = []
    if exit_code != 0:
        problems.append(f'exit_code={exit_code}')
    if len(starts) != 1:
        problems.append(f'expected one runner start, found {len(starts)}')
    if len(dones) != 1 or not dones[0].get('success') or events[-1] != dones[0]:
        problems.append('missing unique successful final done event')
    errors = [event for event in events if event.get('type') == 'error']
    if errors:
        problems.append(f'{len(errors)} error events')
    suite_events = [event['suite'] for event in events
                    if event.get('type') == 'suite']
    suites = {suite['id']: Path(suite['path']).name for suite in suite_events}
    if len(suites) != len(suite_events):
        problems.append('duplicate suite IDs')
    if Counter(suites.values()) != Counter(expected_files):
        problems.append('suite files differ from exact group selection')
    declarations = [event['count'] for event in events
                    if event.get('type') == 'allSuites']
    if declarations != [len(expected_files)]:
        problems.append('runner suite count does not match exact selection')
    tests_list = [event['test'] for event in events
                  if event.get('type') == 'testStart']
    end_list = [event for event in events if event.get('type') == 'testDone']
    tests = {test['id']: test for test in tests_list}
    ends = {event['testID']: event for event in end_list}
    if len(tests) != len(tests_list) or len(ends) != len(end_list):
        problems.append('duplicate test start or completion IDs')
    if set(tests) != set(ends):
        problems.append('test starts and completions are not an exact pairing')
    cases = []
    occurrence = Counter()
    per_suite = Counter()
    for test in tests_list:
        end = ends.get(test['id'])
        if end is None:
            continue
        if end.get('result') != 'success' or end.get('skipped'):
            problems.append(f'unsuccessful or skipped test event {test["id"]}')
        if end.get('hidden'):
            continue
        file = suites[test['suiteID']]
        if test['name'].startswith('loading '):
            problems.append('loading test unexpectedly contributed visible case')
            continue
        occurrence[(file, test['name'])] += 1
        per_suite[test['suiteID']] += 1
        cases.append({'file': file, 'name': test['name'],
                      'occurrence': occurrence[(file, test['name'])]})
    roots = [event['group'] for event in events
             if event.get('type') == 'group'
             and event['group']['parentID'] is None]
    roots_by_suite = {group['suiteID']: group for group in roots}
    if len(roots) != len(suites) or set(roots_by_suite) != set(suites):
        problems.append('missing unique suite root test-count declarations')
    for suite_id, root in roots_by_suite.items():
        if root['testCount'] != per_suite[suite_id]:
            problems.append(f'visible case count mismatch for {suites[suite_id]}')
    if not cases:
        problems.append('no visible test cases')
    return {'accepted': not problems, 'problems': problems,
            'passing_cases': len(cases), 'cases': cases,
            'files': list(expected_files), 'errors': errors,
            'hidden_completions': sum(bool(end.get('hidden')) for end in end_list),
            'declared_cases': sum(root['testCount'] for root in roots),
            'stdout_sha256': sha(stdout)}


def group_record(group_index, lane):
    label = f'group-{group_index + 1:02d}'
    group = GROUPS[group_index]
    directory = OUT / lane
    directory.mkdir(exist_ok=True)
    before = capture()
    compressed_json(directory / f'{label}-inputs-before.json.gz', before)
    if before != BASELINE:
        raise ValueError(f'{label}: source changed before execution')
    command = [str(RUNTIME / 'run-engine-tests.sh'), '--reporter=json',
               *['test/' + name for name in group]]
    stdout = directory / f'{label}.jsonl'
    stderr = directory / f'{label}.stderr'
    start = time.monotonic()
    started = utc()
    print(lane, label, 'running', len(group), 'files', flush=True)
    with stdout.open('w') as output, stderr.open('w') as errors:
        process = subprocess.run(command, cwd=REPO, stdout=output, stderr=errors)
    after = capture()
    compressed_json(directory / f'{label}-inputs-after.json.gz', after)
    record = audit_events(stdout, group, process.returncode)
    record.update(label=label, lane=lane, command=command,
                  exit_code=process.returncode,
                  seconds=round(time.monotonic() - start, 3),
                  started_utc=started, finished_utc=utc(),
                  inputs_unchanged=before == after == BASELINE,
                  stderr_sha256=sha(stderr),
                  stdout=str(stdout.relative_to(RUNTIME)),
                  stderr=str(stderr.relative_to(RUNTIME)))
    record['accepted'] = record['accepted'] and record['inputs_unchanged']
    write_json(directory / f'{label}-receipt.json', record)
    with LOCK:
        PROGRESS['groups'].append({key: value for key, value in record.items()
                                   if key != 'cases'})
        write_json(OUT / 'progress.json', PROGRESS)
    print(lane, label, 'PASS' if record['accepted'] else 'FAIL',
          record['passing_cases'], 'cases', flush=True)
    if not record['accepted']:
        raise ValueError(f'{label}: acceptance failed: {record["problems"]}')
    return record


def lane(name, indices):
    return [group_record(index, name) for index in indices]


def import_serial():
    summary = json.loads((SERIAL / 'summary.json').read_text())
    if summary['source_commit'] != SOURCE:
        raise ValueError('Serial gate source binding changed')
    results = []
    for index in (0, 1):
        label = f'group-{index + 1:02d}'
        original = next(item for item in summary['groups'] if item['label'] == label)
        if not original['accepted']:
            raise ValueError(f'{label}: original receipt was not accepted')
        stdout = SERIAL / f'{label}.jsonl'
        stderr = SERIAL / f'{label}.stderr'
        checked = audit_events(stdout, GROUPS[index], original['exit_code'])
        if (not checked['accepted'] or checked['stdout_sha256'] != original['stdout_sha256']
                or sha(stderr) != original['stderr_sha256']):
            raise ValueError(f'{label}: independent acceptance failed')
        checked.update(label=label, lane='completed-original',
                       command=original['command'], exit_code=original['exit_code'],
                       seconds=original['seconds'], stderr_sha256=sha(stderr),
                       stdout=str(stdout.relative_to(RUNTIME)),
                       stderr=str(stderr.relative_to(RUNTIME)),
                       inputs_unchanged=True,
                       source_provenance='Original frozen before manifest plus exact Git binding and boundary after manifest')
        results.append(checked)
    return results


if OUT.exists():
    raise SystemExit('Refusing to replace an existing parallel gate directory')
OUT.mkdir()
if len(FILES) != 59 or len(set(FILES)) != len(FILES):
    raise SystemExit('Expected 59 unique selected files')
binding = source_binding()
compressed_json(OUT / 'source-git-binding.json.gz', binding)
before = capture()
compressed_json(OUT / 'inputs-before.json.gz', before)
if before != BASELINE:
    raise SystemExit('Source changed before parallel handoff')
PROGRESS = {'source_commit': SOURCE, 'source_tree': git('rev-parse', SOURCE + '^{tree}'),
            'started_utc': utc(), 'maximum_test_runners': 2,
            'completed_original_groups': [1, 2], 'lane_a_groups': [3, 5, 7],
            'lane_b_groups': [4, 6, 8], 'groups': [], 'complete': False}
write_json(OUT / 'progress.json', PROGRESS)
with ThreadPoolExecutor(max_workers=2) as pool:
    first = pool.submit(lane, 'lane-a', [2, 4, 6])
    # The original group02 is the second test runner until its verified parent
    # reaches the next wrapper call. The guard then signals only that parent.
    while not (SERIAL / 'stopped-at-boundary.json').exists():
        if first.done() and first.exception() is not None:
            raise first.exception()
        time.sleep(1)
    boundary = json.loads((SERIAL / 'stopped-at-boundary.json').read_text())
    if boundary.get('native_test_process_started') is not False:
        raise ValueError('Handoff did not stop before native test startup')
    wrapper = RUNTIME / 'run-engine-tests.sh'
    original_wrapper = (RUNTIME / 'run-engine-tests.before-boundary.sh').read_bytes()
    if b'stop-serial-gate-boundary.py' not in wrapper.read_bytes():
        raise ValueError('Guarded wrapper was unexpectedly modified')
    wrapper.write_bytes(original_wrapper)
    boundary_after = capture()
    compressed_json(OUT / 'serial-boundary-inputs-after.json.gz', boundary_after)
    if boundary_after != BASELINE:
        raise ValueError('Source changed across original serial execution')
    retained = import_serial()
    write_json(OUT / 'handoff.json', {
        'boundary': boundary, 'wrapper_restored_utc': utc(),
        'wrapper_sha256': sha(wrapper),
        'retained_original_groups': [item['label'] for item in retained],
        'retained_original_cases': sum(item['passing_cases'] for item in retained),
        'excluded_attempt': {'path': str((SERIAL / 'group-03.jsonl').relative_to(RUNTIME)),
                             'reason': 'Interrupted before Dart startup; no accepted prefix'},
        'source_inputs_unchanged': True,
    })
    print('handoff: retained groups01+02; restored wrapper; starting lane-b', flush=True)
    second = pool.submit(lane, 'lane-b', [3, 5, 7])
    accepted_groups = retained + first.result() + second.result()

accepted_groups.sort(key=lambda item: item['label'])
all_files = [file for item in accepted_groups for file in item['files']]
all_cases = [case for item in accepted_groups for case in item['cases']]
identities = [(case['file'], case['name'], case['occurrence']) for case in all_cases]
if Counter(all_files) != Counter(FILES) or len(set(identities)) != len(identities):
    raise ValueError('Final file or case partition is not unique and complete')
after = capture()
compressed_json(OUT / 'inputs-after.json.gz', after)
if after != BASELINE:
    raise ValueError('Source changed during final qualification')
source_binding()
summary = {
    'source_commit': SOURCE, 'source_tree': PROGRESS['source_tree'],
    'started_utc': json.loads((SERIAL / 'summary.json').read_text())['started_utc'],
    'finished_utc': utc(), 'complete': True, 'file_count': len(all_files),
    'passing_cases': len(all_cases), 'distinct_cases': len(set(identities)),
    'case_identity': ['file', 'full_test_name', 'occurrence_ordinal'],
    'failed_cases': 0, 'skipped_cases': 0, 'inputs_unchanged': True,
    'input_entries': len(BASELINE), 'maximum_test_runners': 2,
    'execution': 'Complete fresh execution of all 59 files on one frozen source; original groups01+02 retained, six disjoint groups in two serial lanes.',
    'groups': [{key: value for key, value in item.items() if key != 'cases'}
               for item in accepted_groups],
    'accepted_cases': all_cases,
    'per_file_cases': dict(sorted(Counter(case['file'] for case in all_cases).items())),
    'excluded_attempts': [
        {'stdout': 'tabstops-gate/group-03.jsonl',
         'reason': 'Original serial parent stopped at group boundary before Dart startup; no cases accepted.'},
    ],
}
write_json(OUT / 'summary.json', summary)
PROGRESS.update(complete=True, passing_cases=len(all_cases), finished_utc=utc())
write_json(OUT / 'progress.json', PROGRESS)
print('COMPLETE', len(all_files), 'files', len(all_cases), 'passing cases', flush=True)
