#!/usr/bin/env bash
set -euo pipefail
source /workspace/scratch/02ca2ade0467/runtime/env.sh
cd "$QUDS_VALIDATION_ROOT/packages/quds_office_engine"
exec "$QUDS_DART_ROOT/bin/dart" --old_gen_heap_size=512 --packages="$QUDS_VALIDATION_ROOT/.dart_tool/package_config.json" /workspace/scratch/02ca2ade0467/runtime/test-runner/test-runner.dill --compiler source --concurrency=1 --timeout=4x --fail-fast "$@"
