"""Run the scoped Word/VBA gate with exact input and complete-event records."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import os
import subprocess
import sys
import time

repo = Path(sys.argv[1]).resolve()
runtime = Path(sys.argv[2]).resolve()
out = runtime / 'tabstops-gate'
out.mkdir(exist_ok=True)
files = json.loads((runtime / 'word-tabstops-gate-files.json').read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inputs():
    names = git('ls-files', '--',
        'packages/quds_office_engine/lib',
        'packages/quds_office_engine/test',
        'packages/quds_office_engine/tool',
        'packages/quds_office_engine/example',
        'packages/quds_office_engine/pubspec.yaml',
        'packages/legacy_doc_parser/lib',
        'packages/legacy_doc_parser/pubspec.yaml',
        'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml').splitlines()
    result = {}
    for name in names:
        path = repo / name
        if path.is_file():
            result[name] = {'sha256': digest(path), 'bytes': path.stat().st_size,
                            'mode': '100755' if os.access(path, os.X_OK) else '100644'}
    return result

start_inputs = inputs()
with gzip.open(out / 'inputs-before.json.gz', 'wt') as handle:
    json.dump(start_inputs, handle, sort_keys=True)
summary = {
    'source_commit': git('rev-parse', 'HEAD'),
    'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'file_count': len(files), 'groups': [], 'accepted_cases': [],
    'input_entries': len(start_inputs), 'complete': False,
}

def save():
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')

save()
for group_index in range(0, len(files), 8):
    group = files[group_index:group_index + 8]
    label = f'group-{group_index // 8 + 1:02d}'
    stdout = out / f'{label}.jsonl'
    stderr = out / f'{label}.stderr'
    command = [str(runtime / 'run-engine-tests.sh'), '--reporter=json',
               *['test/' + name for name in group]]
    start = time.monotonic()
    print(label, 'running', len(group), 'files', flush=True)
    with stdout.open('w') as output, stderr.open('w') as errors:
        process = subprocess.run(command, cwd=repo, stdout=output, stderr=errors)
    events = [json.loads(line) for line in stdout.read_text().splitlines()
              if line.startswith('{')]
    suites = {event['suite']['id']: event['suite']['path'] for event in events
              if event.get('type') == 'suite'}
    starts = {event['test']['id']: event['test'] for event in events
              if event.get('type') == 'testStart'}
    ends = {event['testID']: event for event in events
            if event.get('type') == 'testDone'}
    accepted = []
    failures = []
    skips = []
    for test_id, end in ends.items():
        if end.get('hidden'):
            continue
        test = starts[test_id]
        item = {'file': str(Path(suites[test['suiteID']]).name), 'name': test['name']}
        if end.get('skipped'):
            skips.append(item)
        elif end.get('result') != 'success':
            failures.append(item)
        else:
            accepted.append(item)
    completed = any(event.get('type') == 'done' and event.get('success') is True
                    for event in events)
    errors = [event for event in events if event.get('type') == 'error']
    seen_files = {Path(path).name for path in suites.values()}
    missing = sorted(set(group) - seen_files)
    valid = (process.returncode == 0 and completed and not failures and not skips
             and not errors and not missing and bool(accepted))
    record = {'label': label, 'files': group, 'command': command,
              'exit_code': process.returncode, 'seconds': round(time.monotonic()-start, 3),
              'passing_cases': len(accepted), 'failures': failures, 'skips': skips,
              'errors': errors, 'missing_files': missing, 'complete': completed,
              'accepted': valid, 'stdout_sha256': digest(stdout), 'stderr_sha256': digest(stderr)}
    summary['groups'].append(record)
    if valid:
        summary['accepted_cases'].extend(accepted)
    save()
    print(label, 'PASS' if valid else 'FAIL', len(accepted), 'cases', flush=True)
    if not valid:
        raise SystemExit(1)

after = inputs()
with gzip.open(out / 'inputs-after.json.gz', 'wt') as handle:
    json.dump(after, handle, sort_keys=True)
summary['inputs_unchanged'] = after == start_inputs
summary['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
summary['complete'] = after == start_inputs
summary['passing_cases'] = len(summary['accepted_cases'])
summary['distinct_cases'] = len({(item['file'], item['name']) for item in summary['accepted_cases']})
save()
print('complete', summary['complete'], summary['passing_cases'], 'passing cases', flush=True)
if not summary['complete']:
    raise SystemExit(1)
