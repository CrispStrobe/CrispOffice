from pathlib import Path
import base64, hashlib, json, os, subprocess, time
root=Path('/workspace/scratch/02ca2ade0467')
runtime=root/'runtime'
repo=root/'quds_office_suite'
cwd=runtime/'validation-workspace/packages/quds_office_engine'
source=repo/'packages/quds_office_engine/example/macros/word_tabstops.bas'
driver=repo/'packages/quds_office_engine/tool/macros/web_vba_word_tabstops_smoke.dart'
encoded=base64.b64encode(source.read_bytes()).decode()
config=runtime/'validation-workspace/.dart_tool/package_config.json'
dart=runtime/'dart-sdk/bin/dart'
env=os.environ.copy()
env.update(PUB_CACHE=str(runtime/'pub-cache'),TMPDIR=str(runtime/'tmp'),PATH=str(dart.parent)+os.pathsep+env['PATH'])
result={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_bytes':source.stat().st_size,'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'attempts':[]}
commands=[('vm',[str(dart),'--old_gen_heap_size=512','--packages='+str(config),'-DWORD_TABSTOPS_BAS_BASE64='+encoded,'tool/macros/web_vba_word_tabstops_smoke.dart']),('js-compile',[str(dart),'compile','js','-O1','--packages='+str(config),'-DWORD_TABSTOPS_BAS_BASE64='+encoded,'-o',str(runtime/'word-tabstops-smoke.js'),'tool/macros/web_vba_word_tabstops_smoke.dart']),('js',[os.environ.get('CODEX_PRIMARY_RUNTIME_NODE','node'),'-e','globalThis.self = globalThis; require(process.argv[1]);',str(runtime/'word-tabstops-smoke.js')])]
for name,command in commands:
 start=time.monotonic()
 with (runtime/('word-tabstops-'+name+'.stdout')).open('w') as out, (runtime/('word-tabstops-'+name+'.stderr')).open('w') as err:
  process=subprocess.run(command,cwd=cwd,env=env,stdout=out,stderr=err)
 attempt={'name':name,'command':command,'exit_code':process.returncode,'seconds':round(time.monotonic()-start,3)}
 result['attempts'].append(attempt)
 (runtime/'word-tabstops-portable-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
 print(name,process.returncode,flush=True)
 if process.returncode: raise SystemExit(process.returncode)
def canonical(value):
 if isinstance(value,bool) or value is None or isinstance(value,str): return value
 if isinstance(value,int): return value
 if isinstance(value,float):
  if not (float('-inf')<value<float('inf')): raise ValueError('non-finite')
  return int(value) if value.is_integer() else value
 if isinstance(value,list): return [canonical(v) for v in value]
 if isinstance(value,dict): return {k:canonical(v) for k,v in value.items()}
 raise TypeError(type(value))
vm=json.loads((runtime/'word-tabstops-vm.stdout').read_text())
js=json.loads((runtime/'word-tabstops-js.stdout').read_text())
canonical_vm=json.dumps(canonical(vm),sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
canonical_js=json.dumps(canonical(js),sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
if canonical_vm!=canonical_js: raise AssertionError('VM/JS semantic mismatch')
result['canonical_equal']=True
result['canonical_sha256']=hashlib.sha256(canonical_vm).hexdigest()
result['raw_equal']=(runtime/'word-tabstops-vm.stdout').read_bytes()==(runtime/'word-tabstops-js.stdout').read_bytes()
(runtime/'word-tabstops-portable-canonical.json').write_bytes(canonical_vm+b'\n')
(runtime/'word-tabstops-portable-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print('canonical equal',flush=True)
