import 'dart:convert';
import 'dart:typed_data';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/quds_office_automation.dart';

const w = OfficeNamespaces.w;
const mc = 'http://schemas.openxmlformats.org/markup-compatibility/2006';
Uint8List fixture(String ppr, {String styles = ''}) {
  final p = OpcPackage.openBytes((DocxDocumentBuilder()..paragraph('text')).build());
  p.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="$w" xmlns:mc="$mc" xmlns:x="urn:probe"><w:body><w:p><w:pPr>$ppr</w:pPr><w:r><w:t>text</w:t></w:r></w:p><w:sectPr/></w:body></w:document>');
  if (styles.isNotEmpty) p.getPart('/word/styles.xml')!.writeText('<w:styles xmlns:w="$w" xmlns:mc="$mc" xmlns:x="urn:probe">$styles</w:styles>');
  return p.save();
}
List<num> positions(WmlDocument d) => d.paragraphs.single.properties.tabs.map((x) => x.position).toList();
void main() {
  final nested=WordDeserializer().readBytes(fixture('<w:tabs><w:tab w:pos="720" w:val="left"><w:tab w:pos="1080" w:val="right"/></w:tab><w:tab w:pos="1440" w:val="center"/></w:tabs>'));
  final before=positions(nested);
  OfficeOperationCatalog.apply(nested,'docx.tabStop',{'paragraph':0,'position':90});
  final reopened=WordDeserializer().readBytes(WordSerializer().writeBytes(nested));
  print(jsonEncode({'case':'nested-recognized-tab','before':before,'after':positions(reopened)}));

  final styled=WordDeserializer().readBytes(fixture('<w:pStyle w:val="Base"/>', styles:'<w:style w:type="paragraph" w:styleId="Base"><mc:AlternateContent><mc:Fallback><w:pPr><w:tabs><w:tab w:pos="720" w:val="left"/></w:tabs></w:pPr></mc:Fallback></mc:AlternateContent></w:style>'));
  Object? error;
  try {OfficeOperationCatalog.apply(styled,'docx.clearTabStops',{'paragraph':0});} catch(e) {error=e.toString();}
  final out=OpcPackage.openBytes(WordSerializer().writeBytes(styled));
  print(jsonEncode({'case':'mc-wrapped-style-properties','error':error,'positions':positions(styled),'document':out.getPart('/word/document.xml')!.readText(),'styles':out.getPart('/word/styles.xml')!.readText()}));
}
