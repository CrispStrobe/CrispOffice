from pathlib import Path
import hashlib,json,tarfile
ROOT=Path('/workspace/scratch/1a4f82921a71/padding-qualification')
RUNTIME=ROOT.parent/'toolchains'
OUT=ROOT/'delivery'
OUT.mkdir(exist_ok=True)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def write(p,value):p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

engine=json.loads((ROOT/'receipt.json').read_text())
converter=json.loads((ROOT/'converter/receipt.json').read_text())
binding=json.loads((ROOT/'checkpoint-binding.json').read_text())
manifest=json.loads((ROOT/'source-manifest.json').read_text())
assert engine['passed'] and engine['source_unchanged']
assert converter['status']=='passed' and converter['source_unchanged']
assert binding['passed'] and binding['manifest_sha256']==sha(ROOT/'source-manifest.json')
assert all(manifest.get(k)==v for k,v in converter['source_before'].items())
assert all(x['exit_code']==0 for x in converter['commands'])
assert len(converter['commands'])==6
assert engine['retained_completed_gates']==[]
assert engine['suite_count']==166
cohorts=json.loads((ROOT/'cohorts.json').read_text())
all_suites=[p for group in cohorts.values() for p in group]
assert len(all_suites)==len(set(all_suites))==166
assert max(map(len,cohorts.values()))<=12
counts=engine['counts']
visible={name:counts.get(source,0) for name,source in [('passed','success'),('failed','failure'),('errors','error'),('skipped','skipped')]}
assert visible['failed']==visible['errors']==visible['skipped']==0
expected=json.loads((ROOT/'converter/original/table-padding.expected.json').read_text())
fields=expected['model']['fields']
assert len(fields)==9 and all(x['canEdit'] for x in fields)

summary={'schema':1,'production_commit':binding['commit'],'production_tree':binding['tree'],'source_binding':{'matched_tracked_inputs':binding['matched_source_files'],'generated_package_graph_sha256':binding['excluded_generated_inputs']['.dart_tool/package_config.json'],'source_manifest_sha256':sha(ROOT/'source-manifest.json'),'all_engine_inputs_unchanged':engine['source_unchanged'],'all_converter_inputs_unchanged':converter['source_unchanged'],'converter_inputs_match_engine_manifest':True},'engine':{'suites':engine['suite_count'],'batches':len(engine['gates']),'max_suites_per_batch':12,'visible_tests':visible,'hidden_runner_successes':counts.get('hidden_success',0),'complete_runner_events':all(g['passed'] for g in engine['gates']),'earlier_attempts_included':False},'converter':{'fixture':'table-padding','active_fields':9,'outer_table_margins_points':[0,6,12],'nested_table_margin_points':3,'actual_libreoffice_saves':2,'intermediate_docx_save_reopen':True,'commands':6,'all_exit_codes_zero':True,'version':converter['libreoffice_version'],'renderer_or_installed_plugin_exercised':False}}
write(OUT/'summary.json',summary)
files={}
for p in sorted(ROOT.iterdir()):
 if p.is_file() and (p.suffix in ('.py','.json')):files[p.name]=p
for p in sorted((ROOT/'logs').glob('*.jsonl')):files[str(p.relative_to(ROOT))]=p
for sub in ['logs','original','saved1','reexported','saved2']:
 for p in sorted((ROOT/'converter'/sub).glob('*')):
  if p.is_file():files[str(p.relative_to(ROOT))]=p
for name in ['run_acceptance.py','receipt.json','source-before.json']:files['converter/'+name]=ROOT/'converter'/name
for name in ['runtime.json','bootstrap_runtime.py','pub-cache-receipt.json','trimmed-optional-runtime-assets.json','env.sh']:
 files['runtime/'+name]=RUNTIME/name
for name in ['flutter-tools-pub-get.log','workspace-pub-get.log','flutter-version.log']:
 files['runtime/logs/'+name]=RUNTIME/'logs'/name
for name in ['engine-test','flutter','dart']:files['runtime/bin/'+name]=RUNTIME/'bin'/name
files['summary.json']=OUT/'summary.json'
artifact_manifest={'schema':1,'files':{name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in sorted(files.items())}}
write(OUT/'artifacts-manifest.json',artifact_manifest)
files['artifacts-manifest.json']=OUT/'artifacts-manifest.json'
archive=OUT/'local-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
write(OUT/'archive.json',{'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(files),'uncompressed_bytes':sum(p.stat().st_size for p in files.values())})
print(json.dumps(summary,indent=2))
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive)}))
