#!/usr/bin/env python3
from pathlib import Path
import argparse
import collections
import hashlib
import json
import os
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/1a4f82921a71/padding-qualification')
REPO = ROOT.parent / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
RUNTIME = ROOT.parent / 'toolchains'


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def manifest():
    paths = set()
    for directory in [ENGINE / 'lib', ENGINE / 'test', REPO / 'packages/legacy_doc_parser/lib']:
        paths.update(p for p in directory.rglob('*') if p.is_file())
    paths.update([ENGINE / 'tool/zotero/odt_roundtrip_acceptance.dart', REPO / 'pubspec.lock', REPO / '.dart_tool/package_config.json'])
    return {str(p.relative_to(REPO)): digest(p) for p in sorted(paths)}


def summarize(path):
    suites, tests, totals, by_suite, errors = {}, {}, collections.Counter(), {}, []
    done, non_json = None, 0
    for line in path.read_text(errors='replace').splitlines():
        try:
            e = json.loads(line)
        except ValueError:
            non_json += 1
            continue
        kind = e.get('type')
        if kind == 'suite':
            s = e['suite']
            suite_path = Path(s['path'])
            suites[s['id']] = str(suite_path.relative_to(ENGINE)) if suite_path.is_absolute() else suite_path.as_posix()
        elif kind == 'testStart':
            t = e['test']
            tests[t['id']] = t
        elif kind == 'testDone':
            t = tests.get(e['testID'], {})
            s = suites.get(t.get('suiteID'), '(unknown suite)')
            counts = by_suite.setdefault(s, collections.Counter())
            if e.get('hidden', False):
                totals['hidden_' + e['result']] += 1
                counts['hidden_' + e['result']] += 1
            else:
                result = 'skipped' if e.get('skipped', False) else e['result']
                totals[result] += 1
                counts[result] += 1
        elif kind == 'error':
            errors.append({'test': tests.get(e.get('testID'), {}).get('name'), 'error': e.get('error'), 'stackTrace': e.get('stackTrace')})
        elif kind == 'done':
            done = e
    return {'runner_done': done, 'counts': dict(totals), 'suite_count': len(suites), 'per_suite': by_suite, 'errors': errors, 'non_json_lines': non_json}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    actual_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    if actual_head != args.expected_head:
        raise RuntimeError('Repository HEAD differs before qualification: ' + actual_head)
    cohorts = json.loads((ROOT / 'cohorts.json').read_text())
    before = manifest()
    prior = json.loads((ROOT / 'receipt.json').read_text()) if (ROOT / 'receipt.json').exists() else {}
    retained = [gate for gate in prior.get('gates', []) if gate.get('passed') and gate['name'] in cohorts]
    if retained and json.loads((ROOT / 'source-manifest.json').read_text()) != before:
        raise RuntimeError('Cannot retain completed gates after scoped input changes')
    write(ROOT / 'source-manifest.json', before)
    record = {'schema': 1, 'head': actual_head, 'source_manifest_sha256': digest(ROOT / 'source-manifest.json'), 'source_input_count': len(before), 'head_policy': 'Record HEAD before and after; byte-identical scoped inputs are authoritative across equivalent remote checkpoint alignment.', 'source_scope': ['all engine lib and test inputs', 'legacy_doc_parser lib', 'acceptance tool', 'workspace lock and package config'], 'runtime': {'dart_version': subprocess.check_output(['dart', '--version'], text=True).strip(), 'dart_binary_sha256': digest(RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'), 'engine_test_wrapper_sha256': digest(RUNTIME / 'bin/engine-test')}, 'resumed_from_head': prior.get('head'), 'retained_completed_gates': [g['name'] for g in retained], 'gates': retained}
    logdir = ROOT / 'logs'
    logdir.mkdir(exist_ok=True)
    for group, files in cohorts.items():
        if any(g['name'] == group for g in retained):
            print('RETAIN complete unchanged-source gate ' + group, flush=True)
            continue
        command = ['engine-test', '--concurrency=2', '--timeout=90s', '--reporter=json', *files]
        path = logdir / (group + '.jsonl')
        start = time.monotonic()
        print('START ' + group + ': ' + str(len(files)) + ' suites', flush=True)
        temporary = ROOT / 'temporary' / group
        temporary.mkdir(parents=True, exist_ok=True)
        gate_env = dict(os.environ, TMPDIR=str(temporary))
        with path.open('wb') as output:
            process = subprocess.Popen(command, cwd=ENGINE, env=gate_env, stdout=output, stderr=subprocess.STDOUT)
            try:
                while True:
                    try:
                        code = process.wait(timeout=20)
                        break
                    except subprocess.TimeoutExpired:
                        partial = summarize(path)
                        print(json.dumps({'running': group, 'seconds': round(time.monotonic() - start), 'counts': partial['counts']}), flush=True)
                        if time.monotonic() - start > 900:
                            process.terminate()
                            try:
                                process.wait(timeout=10)
                            except subprocess.TimeoutExpired:
                                process.kill()
                                process.wait()
                            code = 124
                            break
            except BaseException:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                raise
            finally:
                if process.poll() is not None:
                    shutil.rmtree(temporary)
        summary = summarize(path)
        summary.update({'name': group, 'command': command, 'cwd': str(ENGINE), 'temporary_directory': str(temporary), 'exit_code': code, 'seconds': round(time.monotonic() - start, 3), 'expected_suites': len(files), 'raw_log_sha256': digest(path)})
        summary['passed'] = code == 0 and summary['runner_done'] is not None and summary['runner_done'].get('success') is True and summary['suite_count'] == len(files)
        write(ROOT / (group + '-summary.json'), summary)
        record['gates'].append({k: summary[k] for k in ('name', 'command', 'cwd', 'temporary_directory', 'exit_code', 'seconds', 'expected_suites', 'suite_count', 'counts', 'raw_log_sha256', 'passed')})
        print(json.dumps({'finished': group, 'passed': summary['passed'], 'counts': summary['counts'], 'errors': summary['errors'][:3]}), flush=True)
        write(ROOT / 'receipt.json', record)
        if (ROOT / 'pause-after-batch').exists():
            current = manifest()
            record['status'] = 'paused_after_batch'
            record['paused_after_batch'] = group
            record['source_unchanged'] = current == before
            record['source_changes'] = [k for k in sorted(set(before) | set(current)) if before.get(k) != current.get(k)]
            record['head_after'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
            record['complete'] = False
            record['passed'] = False
            write(ROOT / 'receipt.json', record)
            print('PAUSED after completed batch ' + group, flush=True)
            raise SystemExit(75)
    after = manifest()
    record['source_unchanged'] = before == after
    record['source_changes'] = [k for k in sorted(set(before) | set(after)) if before.get(k) != after.get(k)]
    record['head_after'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    total = collections.Counter()
    for gate in record['gates']:
        total.update(gate['counts'])
    record['counts'] = dict(total)
    record['suite_count'] = sum(g['suite_count'] for g in record['gates'])
    record['passed'] = all(g['passed'] for g in record['gates']) and record['source_unchanged']
    write(ROOT / 'receipt.json', record)
    if not record['source_unchanged']:
        write(ROOT / 'source-manifest-after.json', after)
    print(json.dumps({'finished_all': True, 'passed': record['passed'], 'source_unchanged': record['source_unchanged'], 'counts': record['counts'], 'suites': record['suite_count']}), flush=True)
    raise SystemExit(0 if record['passed'] else 1)


if __name__ == '__main__':
    main()
