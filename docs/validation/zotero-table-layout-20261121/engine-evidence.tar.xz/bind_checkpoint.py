from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/workspace/scratch/1a4f82921a71/padding-qualification')
REPO=ROOT.parent/'quds_office_suite'
COMMIT='dd7d728e3dedcf7995586217431063f3bbed01a0'
EXPECTED_TREE='8762721e920f945928888ab329fdcccdb9c1e727'
manifest=json.loads((ROOT/'source-manifest.json').read_text())
tree=subprocess.check_output(['git','rev-parse',COMMIT+'^{tree}'],cwd=REPO,text=True).strip()
if tree!=EXPECTED_TREE:raise RuntimeError('Checkpoint tree differs')
entries={}
for entry in subprocess.check_output(['git','ls-tree','-r','-z',COMMIT],cwd=REPO).split(b'\0'):
 if not entry:continue
 meta,name=entry.split(b'\t',1)
 mode,kind,sha=meta.decode().split()
 if kind=='blob':entries[name.decode()]=sha
excluded=['.dart_tool/package_config.json']
missing=[name for name in manifest if name not in entries and name not in excluded]
mismatches=[];matched=0
process=subprocess.Popen(['git','cat-file','--batch'],cwd=REPO,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for name,digest in manifest.items():
 if name in excluded or name not in entries:continue
 process.stdin.write((entries[name]+'\n').encode());process.stdin.flush()
 header=process.stdout.readline().decode().split()
 if len(header)!=3 or header[1]!='blob':raise RuntimeError('Invalid blob response '+name)
 size=int(header[2]);actual=hashlib.sha256()
 while size:
  block=process.stdout.read(min(size,1024*1024))
  if not block:raise RuntimeError('Truncated blob '+name)
  actual.update(block);size-=len(block)
 if process.stdout.read(1)!=b'\n':raise RuntimeError('Invalid blob delimiter')
 if actual.hexdigest()==digest:matched+=1
 else:mismatches.append({'path':name,'tested_sha256':digest,'commit_sha256':actual.hexdigest()})
process.stdin.close()
process.wait()
receipt={'commit':COMMIT,'tree':tree,'manifest_sha256':hashlib.sha256((ROOT/'source-manifest.json').read_bytes()).hexdigest(),'matched_source_files':matched,'excluded_generated_inputs':{name:manifest[name] for name in excluded if name in manifest},'missing_from_commit':missing,'mismatches':mismatches,'passed':not missing and not mismatches}
(ROOT/'checkpoint-binding.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
if not receipt['passed']:raise SystemExit(1)
