from pathlib import Path
import hashlib, json, os, subprocess, time
ROOT=Path('/workspace/scratch/1a4f82921a71/padding-qualification/converter')
REPO=Path('/workspace/scratch/1a4f82921a71/quds_office_suite')
ENGINE=REPO/'packages/quds_office_engine'
TOOL=ENGINE/'tool/zotero/odt_roundtrip_acceptance.dart'
paths=sorted((ENGINE/'lib').rglob('*.dart'))+[TOOL,REPO/'pubspec.lock',REPO/'.dart_tool/package_config.json']
def hash_file(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(): return {str(p.relative_to(REPO)):hash_file(p) for p in paths}
record={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'libreoffice_version':subprocess.check_output(['soffice','--version'],text=True).strip(),'fixture':'table-padding','expected_active_fields':9,'renderer_exercised':False,'environment':{k:os.environ.get(k) for k in ('TMPDIR','FLUTTER_ROOT','PUB_CACHE','SAL_USE_VCLPLUGIN')},'source_before':manifest(),'commands':[]}
(ROOT/'source-before.json').write_text(json.dumps(record['source_before'],indent=2)+'\n')
for name in ('original','saved1','reexported','saved2','logs','profile1','profile2'): (ROOT/name).mkdir(exist_ok=True)
commands=[
 ('create',['dart',str(TOOL),'create',str(ROOT/'original'),'--fixture=table-padding']),
 ('libreoffice-save1',['soffice','-env:UserInstallation='+ (ROOT/'profile1').as_uri(),'--headless','--convert-to','odt:writer8','--outdir',str(ROOT/'saved1'),str(ROOT/'original/table-padding.odt')]),
 ('verify-save1',['dart',str(TOOL),'verify',str(ROOT/'saved1'),str(ROOT/'original'),'--fixture=table-padding']),
 ('docx-reexport',['dart',str(TOOL),'reexport',str(ROOT/'saved1'),str(ROOT/'original'),str(ROOT/'reexported'),'--fixture=table-padding']),
 ('libreoffice-save2',['soffice','-env:UserInstallation='+ (ROOT/'profile2').as_uri(),'--headless','--convert-to','odt:writer8','--outdir',str(ROOT/'saved2'),str(ROOT/'reexported/table-padding.odt')]),
 ('verify-save2',['dart',str(TOOL),'verify',str(ROOT/'saved2'),str(ROOT/'original'),'--fixture=table-padding'])]
try:
 for name,command in commands:
  print('START '+name,flush=True)
  started=time.monotonic()
  with (ROOT/'logs'/f'{name}.log').open('wb') as output:
   result=subprocess.run(command,cwd=ENGINE,env=os.environ,stdout=output,stderr=subprocess.STDOUT,timeout=120)
  record['commands'].append({'name':name,'command':command,'cwd':str(ENGINE),'exit_code':result.returncode,'seconds':round(time.monotonic()-started,3)})
  print('END '+name+' exit='+str(result.returncode),flush=True)
  print((ROOT/'logs'/f'{name}.log').read_text(errors='replace')[-5000:],flush=True)
  if result.returncode: raise RuntimeError(name+' failed')
 record['status']='passed'
except BaseException as e:
 record['status']='failed';record['error']=repr(e)
 raise
finally:
 record['source_head_after']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
 record['source_after']=manifest()
 record['source_unchanged']=record['source_before']==record['source_after']
 record['artifacts_sha256']={str(p.relative_to(ROOT)):hash_file(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and 'profile' not in str(p.relative_to(ROOT)) and p.name!='receipt.json'}
 (ROOT/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'status':record['status'],'source_unchanged':record['source_unchanged']}),flush=True)
