from pathlib import Path
import collections, hashlib, json, os, shutil, subprocess, time
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'quds_office_suite'
EDITOR = REPO / 'packages/quds_office_editor'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, value): p.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
def manifest():
    paths=set()
    for prefix in ('packages/quds_office_engine/lib','packages/quds_office_editor/lib','packages/quds_office_editor/example/lib','packages/legacy_doc_parser/lib'):
        paths.update(p for p in (REPO/prefix).rglob('*') if p.is_file())
    for pattern in ('test/word_zotero*_test.dart','test/word_odt*_test.dart','example/test/studio_*odt*_test.dart','example/test/studio_zotero*_test.dart'):
        paths.update(EDITOR.glob(pattern))
    paths.update(REPO/p for p in ['pubspec.lock','.dart_tool/package_config.json','pubspec.yaml','packages/quds_office_editor/pubspec.yaml','packages/quds_office_editor/example/pubspec.yaml'])
    return {str(p.relative_to(REPO)):digest(p) for p in sorted(paths)}
def summarize(log, cwd):
    suites, tests, cases, errors = {}, {}, [], []
    counts=collections.Counter(); done=None
    for line in log.read_text(errors='replace').splitlines():
        try: e=json.loads(line)
        except ValueError: continue
        kind=e.get('type')
        if kind=='suite':
            s=e['suite']; path=Path(s['path'])
            if not path.is_absolute(): path=cwd/path
            suites[s['id']]=str(path.relative_to(REPO))
        elif kind=='testStart': tests[e['test']['id']]=e['test']
        elif kind=='testDone':
            test=tests.get(e['testID'],{})
            result=('hidden_'+e['result']) if e.get('hidden') else ('skipped' if e.get('skipped') else e['result'])
            counts[result]+=1
            cases.append({'suite':suites.get(test.get('suiteID')),'name':test.get('name'),'result':result})
        elif kind=='error': errors.append(e)
        elif kind=='done': done=e
    return {'counts':dict(counts),'suite_count':len(suites),'cases':cases,'errors':errors,'done':done}
cohorts={
 'editor_zotero_odt': (EDITOR, sorted(set(EDITOR.glob('test/word_zotero*_test.dart'))|set(EDITOR.glob('test/word_odt*_test.dart')))),
 'studio_zotero_odt': (EDITOR/'example',sorted(set(EDITOR.glob('example/test/studio_*odt*_test.dart'))|set(EDITOR.glob('example/test/studio_zotero*_test.dart'))))}
start_sources=manifest();write(ROOT/'source-manifest.json',start_sources)
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'source_manifest_sha256':digest(ROOT/'source-manifest.json'),'source_scope':'Engine/editor/Studio/legacy parser production files, selected Dart tests, lock/config files','gates':[]}
for name,(cwd,files) in cohorts.items():
    for index in range(0,len(files),12):
        batch=files[index:index+12]; label=name+'_'+str(index//12+1)
        command=['flutter','test','--no-pub','--concurrency=2','--timeout=90s','--reporter=json',*[str(p.relative_to(cwd)) for p in batch]]
        log=ROOT/(label+'.jsonl'); started=time.monotonic()
        print('START '+label+' '+str(len(batch))+' suites',flush=True)
        temp=ROOT/'tmp'/label;temp.mkdir(parents=True,exist_ok=True)
        env=dict(os.environ,TMPDIR=str(temp))
        with log.open('wb') as out:
            proc=subprocess.Popen(command,cwd=cwd,stdout=out,stderr=subprocess.STDOUT,env=env)
            while True:
                try: code=proc.wait(timeout=20);break
                except subprocess.TimeoutExpired:
                    print(json.dumps({'running':label,'seconds':round(time.monotonic()-started),'counts':summarize(log,cwd)['counts']}),flush=True)
                    if time.monotonic()-started>900:
                        proc.terminate();code=proc.wait(timeout=20);break
        shutil.rmtree(temp)
        s=summarize(log,cwd)
        passed=code==0 and s['done'] is not None and s['done'].get('success') is True and len(batch)==s['suite_count'] and not s['errors']
        s.update({'name':label,'command':command,'cwd':str(cwd),'exit_code':code,'seconds':round(time.monotonic()-started,3),'expected_suites':len(batch),'passed':passed,'raw_sha256':digest(log)})
        write(ROOT/(label+'-summary.json'),s)
        record['gates'].append({k:s[k] for k in ['name','command','cwd','exit_code','seconds','expected_suites','suite_count','counts','passed','raw_sha256']})
        print(json.dumps({'finished':label,'passed':passed,'counts':s['counts'],'errors':s['errors'][:2]}),flush=True)
        write(ROOT/'receipt.json',record)
final_sources=manifest();record['source_unchanged']=start_sources==final_sources
record['source_changes']=[p for p in sorted(set(start_sources)|set(final_sources)) if start_sources.get(p)!=final_sources.get(p)]
record['head_after']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
record['passed']=record['source_unchanged'] and all(g['passed'] for g in record['gates'])
counts=collections.Counter()
for g in record['gates']: counts.update(g['counts'])
record['counts']=dict(counts);record['suite_count']=sum(g['suite_count'] for g in record['gates'])
write(ROOT/'receipt.json',record)
print(json.dumps({k:record[k] for k in ['passed','source_unchanged','counts','suite_count']}),flush=True)
raise SystemExit(0 if record['passed'] else 1)
