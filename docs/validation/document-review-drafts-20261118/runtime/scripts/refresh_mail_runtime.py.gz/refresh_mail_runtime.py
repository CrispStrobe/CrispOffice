#!/usr/bin/env python3
"""Resolve the observed Mail workspace additions from verified local archives."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import yaml

ROOT = Path('/workspace/scratch/4a0b7fce84dc/toolchains')
REPO = ROOT.parent / 'quds_office_suite'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    record_path = ROOT / 'runtime.json'
    record = json.loads(record_path.read_text())
    before = json.loads((ROOT / 'before-mail/runtime.json').read_text())
    receipts = json.loads((ROOT / 'before-mail/pub-cache-receipt.json').read_text())
    additions = json.loads((ROOT / 'mail-pub-cache-additions.json').read_text())
    new_receipts = receipts + additions
    if not (REPO / 'third_party/enough_mail/DEPENDENCIES.json').is_file():
        raise RuntimeError('Wait for the observed Mail source merge before resolving.')
    source = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip()
    mail_source = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', '86d6f507'], text=True).strip()
    subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', mail_source, source], check=True)
    update = {
        'started_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_commit': source,
        'source_tree': subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', source + '^{tree}'], text=True).strip(),
        'observed_mail_commit': mail_source,
        'previous_runtime_receipt_sha256': sha(ROOT / 'before-mail/runtime.json'),
        'previous_lock_sha256': sha(ROOT / 'before-mail/pubspec.lock'),
        'dependency_manifest_sha256': sha(REPO / 'third_party/enough_mail/DEPENDENCIES.json'),
        'new_archives': additions,
        'runs': [],
    }
    env = dict(os.environ)
    env.update(
        PUB_CACHE=str(ROOT / 'pub-cache'), FLUTTER_ROOT=str(ROOT / 'flutter'),
        CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true',
        DASH__SUPPRESS_ANALYTICS='true', XDG_CONFIG_HOME=str(ROOT / 'config'),
        XDG_CACHE_HOME=str(ROOT / 'cache'), XDG_DATA_HOME=str(ROOT / 'data'),
        TMPDIR=str(ROOT / 'tmp'), PATH=str(ROOT / 'bin') + os.pathsep + env.get('PATH', ''),
    )
    try:
        for name, arguments in [
            ('workspace-mail-pub-get', ['pub', 'get', '--offline']),
            ('workspace-mail-pub-enforce', ['pub', 'get', '--offline', '--enforce-lockfile']),
        ]:
            command = [str(ROOT / 'bin/dart'), *arguments]
            log = ROOT / 'logs' / (name + '.log')
            with log.open('wb') as stream:
                completed = subprocess.run(command, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=300)
            entry = dict(name=name, command=command, cwd=str(REPO), exit_code=completed.returncode, log=str(log), log_sha256=sha(log))
            update['runs'].append(entry)
            if completed.returncode:
                raise RuntimeError(name + ': ' + log.read_text(errors='replace')[-8000:])
        lock = yaml.safe_load((REPO / 'pubspec.lock').read_text())
        old_lock = yaml.safe_load((ROOT / 'before-mail/pubspec.lock').read_text())
        by_version = {(entry['name'], entry['version']): entry for entry in new_receipts}
        for name, package in lock['packages'].items():
            if package['source'] != 'hosted':
                continue
            receipt = by_version[(name, package['version'])]
            if package['description']['sha256'] != receipt['sha256'] or not receipt['verified']:
                raise RuntimeError('New lock is not archive-verified for ' + name)
        changed = {name: {'before': old_lock['packages'].get(name), 'after': package} for name, package in lock['packages'].items() if old_lock['packages'].get(name) != package}
        update['lock_changes'] = changed
        update['workspace_lock_sha256'] = sha(REPO / 'pubspec.lock')
        update['workspace_package_count'] = len(json.loads((REPO / '.dart_tool/package_config.json').read_text())['packages'])
        update['status'] = 'ready'
        update['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
        (ROOT / 'pub-cache-receipt.json').write_text(json.dumps(new_receipts, indent=2) + '\n')
        record.update(
            status='ready',
            workspace_lock_sha256=update['workspace_lock_sha256'],
            workspace_package_count=update['workspace_package_count'],
            hosted_archives_verified=len(new_receipts),
            dependency_updated_at_utc=update['finished_at_utc'],
        )
        record['runs'] = before['runs'] + update['runs']
        record['dependency_updates'] = [update]
        record_path.write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps({key: update[key] for key in ('status', 'source_commit', 'workspace_lock_sha256', 'workspace_package_count')}, indent=2))
        print(json.dumps({'changed_lock_packages': sorted(changed), 'verified_archive_count': len(new_receipts)}, indent=2))
    except BaseException as error:
        update.update(status='failed', error=repr(error), finished_at_utc=datetime.now(timezone.utc).isoformat())
        record.update(status='failed', dependency_update_error=repr(error))
        record_path.write_text(json.dumps(record, indent=2) + '\n')
        raise
    finally:
        (ROOT / 'mail-dependency-update.json').write_text(json.dumps(update, indent=2) + '\n')


if __name__ == '__main__':
    main()
