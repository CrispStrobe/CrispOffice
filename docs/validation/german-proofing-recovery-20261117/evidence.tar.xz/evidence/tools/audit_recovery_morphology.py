"""Compare every retained morphology outcome to the fresh VM/Node run."""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path('/workspace/scratch/c41432b95719/quds_office_suite')
FRESH = Path('/workspace/scratch/c41432b95719/recovery-morphology')
OUT = ROOT / 'docs/validation/german-proofing-recovery-20261117/evidence'
HISTORICAL = ROOT / 'docs/validation/german-proofing-next-20261117/evidence.tar.xz'
ISSUES = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def check(condition, label):
    if not condition:
        ISSUES.append(label)


def read(path):
    return json.loads(path.read_text())


def preserve(path, panel):
    data = path.read_bytes()
    destination = OUT / ('morphology-' + panel + '-' + path.name + '.gz')
    if destination.exists():
        raise RuntimeError('Refusing to overwrite ' + str(destination))
    destination.write_bytes(gzip.compress(data, mtime=0))
    return {'path': destination.name, 'uncompressed_bytes': len(data), 'uncompressed_sha256': digest(data), 'compressed_sha256': digest(destination.read_bytes())}


results = {}
with tarfile.open(HISTORICAL, 'r:xz') as archive:
    for panel in ('core', 'review'):
        historical_root = 'validation/final-morphology/' + ('review/' if panel == 'review' else '')
        prior_receipt = json.loads(archive.extractfile(historical_root + 'receipt.json').read())
        receipt = read(FRESH / panel / 'receipt.json')
        for flag in ('source_unchanged', 'probe_unchanged', 'runtimes_unchanged', 'vm_node_semantically_equal'):
            check(receipt[flag], panel + ': ' + flag)
        check(receipt['status'] == 'passed', panel + ': status')
        check(receipt['source_head'] == '8d6403021f797a05e9c9fc49052c3d19d3766844', panel + ': frozen source')
        check(not receipt['source_dirty_files'], panel + ': no dirty proofing sources')
        for key in ('corpus_sha256', 'runner_sha256', 'harness_sha256'):
            check(receipt[key] == prior_receipt[key], panel + ': unchanged ' + key)
        variants = {}
        deltas = {}
        for runtime in ('vm', 'node'):
            filename = runtime + '-results.json'
            fresh = read(FRESH / panel / filename)
            prior = json.loads(archive.extractfile(historical_root + filename).read())
            variants[runtime] = fresh
            check(len(fresh['results']) == len(prior['results']), panel + '/' + runtime + ': record count')
            changes = []
            for old, new in zip(prior['results'], fresh['results'], strict=True):
                identity = new['id'] + '/' + new['variant']
                for key in ('id', 'kind', 'area', 'scope', 'variant', 'language', 'text', 'expected', 'start_offset'):
                    check(old.get(key) == new.get(key), panel + '/' + runtime + '/' + identity + ': unchanged ' + key)
                check(new['complete'], panel + '/' + runtime + '/' + identity + ': complete')
                if old != new:
                    changes.append({'id': new['id'], 'variant': new['variant'], 'kind': new['kind'], 'text': new.get('text'), 'expected': new.get('expected'), 'before_applied': old.get('applied'), 'after_applied': new.get('applied'), 'before_exact': old.get('exact'), 'after_exact': new.get('exact'), 'before_findings': old['findings'], 'after_findings': new['findings']})
                check(not old.get('exact', False) or new.get('exact', False), panel + '/' + runtime + '/' + identity + ': exact nonregression')
                if new['kind'] in ('control', 'protection'):
                    check(not new['findings'], panel + '/' + runtime + '/' + identity + ': clean/protected control')
            base = [x for x in fresh['results'] if x['variant'] == 'base']
            counts = {'sentences': len(base), 'requests_recorded': len(fresh['results']), 'errors': sum(x['kind'] == 'error' for x in base), 'exact_errors': sum(x['kind'] == 'error' and x['exact'] for x in base), 'valid_controls': sum(x['kind'] == 'control' for x in base), 'flagged_controls': sum(x['kind'] == 'control' and bool(x['findings']) for x in base)}
            for key, value in counts.items():
                check(fresh['summary'][key] == value, panel + '/' + runtime + ': independent summary ' + key)
            for key in ('operational_failures', 'protection_failures', 'ignore_failures', 'recheck_failures'):
                check(fresh['summary'][key] == 0, panel + '/' + runtime + ': no ' + key)
            deltas[runtime] = {'records_compared': len(fresh['results']), 'changed_records': len(changes), 'changes': changes, 'summary': fresh['summary']}
        check(variants['vm'] == variants['node'], panel + ': exact cross-runtime outputs')
        retained = [preserve(FRESH / panel / name, panel) for name in ['receipt.json', 'vm-results.json', 'node-results.json', 'compile-js.log', 'package-config.json']]
        rebuilt = []
        for path in sorted((FRESH / panel).glob('morphology-probe.js*')):
            data = path.read_bytes()
            rebuilt.append({'filename': path.name, 'bytes': len(data), 'sha256': digest(data)})
        results[panel] = {'source': receipt['source_head'], 'historical_source': prior_receipt['source_head'], 'corpus_sha256': receipt['corpus_sha256'], 'runtimes': deltas, 'vm_node_identical': variants['vm'] == variants['node'], 'retained': retained, 'rebuildable_artifacts_not_copied': rebuilt}

report = {'schemaVersion': 1, 'kind': 'complete-recovery-morphology-outcome-comparison', 'scope': 'Every field of all existing core/review morphology outcome records, compared separately on VM and Node. Original corpus declarations, expected answers, variants, runner and harness unchanged. Rebuildable compiled JS, source map and dependency file are identified but excluded from copied evidence.', 'records_compared_per_runtime': sum(v['runtimes']['vm']['records_compared'] for v in results.values()), 'changed_records_per_runtime': sum(v['runtimes']['vm']['changed_records'] for v in results.values()), 'panels': results, 'issues': ISSUES, 'passed': not ISSUES}
destination = OUT / 'morphology-comparison.json'
if destination.exists():
    raise RuntimeError('Refusing to overwrite ' + str(destination))
destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': report['passed'], 'issues': ISSUES, 'records_compared_per_runtime': report['records_compared_per_runtime'], 'changed_records_per_runtime': report['changed_records_per_runtime'], 'panels': {k: {'summary': v['runtimes']['vm']['summary'], 'changes': v['runtimes']['vm']['changes']} for k, v in results.items()}}, ensure_ascii=False, indent=2))
raise SystemExit(bool(ISSUES))
