"""Verify fresh native quality outputs and compare unchanged regression panels."""
from __future__ import annotations

import copy
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/c41432b95719/quds_office_suite')
SCRATCH = Path('/workspace/scratch/c41432b95719/recovery-quality')
BEFORE = ROOT / 'docs/validation/german-proofing-next-20261117/integrated-quality'
OUT = ROOT / 'docs/validation/german-proofing-recovery-20261117/evidence'
SOURCE = '8d6403021f797a05e9c9fc49052c3d19d3766844'
ISSUES = []


def check(condition, label):
    if not condition:
        ISSUES.append(label)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


def preserve(source, name):
    data = source.read_bytes()
    destination = OUT / (name + '.gz')
    if destination.exists():
        raise RuntimeError('Refusing to overwrite ' + str(destination))
    destination.write_bytes(gzip.compress(data, mtime=0))
    return {'path': destination.name, 'uncompressed_bytes': len(data), 'uncompressed_sha256': digest(data), 'compressed_sha256': digest(destination.read_bytes())}


def project(case, outcome, label):
    if not outcome['complete']:
        check(outcome['corrected'] is None and not outcome['changed'] and not outcome['exact_expected'] and not outcome['clean_report'], label + ': incomplete is not success')
        check(not outcome['projected_findings'], label + ': incomplete has no projection')
        return None
    original = case['input'].encode('utf-16-le')
    spans = []
    for finding in outcome['projected_findings']:
        start = finding['start'] - case['start_offset']
        end = finding['end'] - case['start_offset']
        check(0 <= start <= end <= len(original) // 2, label + ': source bounds')
        check(original[start * 2:end * 2].decode('utf-16-le') == finding['original'], label + ': source span')
        check(finding['replacement_index'] == 0, label + ': first replacement')
        spans.append((start, end, finding['replacements'][0]))
    data = original
    for start, end, replacement in sorted(spans, reverse=True):
        data = data[:start * 2] + replacement.encode('utf-16-le') + data[end * 2:]
    result = data.decode('utf-16-le')
    check(result == outcome['corrected'], label + ': reconstructed projection')
    check(outcome['changed'] == (result != case['input']), label + ': changed flag')
    check(outcome['flagged'] == bool(outcome['displayed_findings']), label + ': displayed flag')
    check(outcome['exact_expected'] == (result == case['expected']), label + ': exact flag')
    return result


build = load(SCRATCH / 'quality-build.json')
for key in ('completed', 'passed', 'source_stable', 'dependencies_stable', 'sdk_stable'):
    check(build[key], 'build ' + key)
check(build['source_files'] == build['source_files_after'], 'build source seal')
check(build['dependency_inputs'] == build['dependency_inputs_after'], 'build dependency seal')
check(build['sdk_inputs'] == build['sdk_inputs_after'], 'build SDK seal')
check(digest((SCRATCH / 'quality.aot').read_bytes()) == build['runtime']['entrypoint']['sha256'], 'AOT output SHA-256')

source_binding = {'tracked_count': 0, 'workspace_only': {}}
for path, expected in build['source_files'].items():
    actual = digest((ROOT / path).read_bytes())
    check(actual == expected, 'current build source ' + path)
    stored = subprocess.run(['git', 'show', SOURCE + ':' + path], cwd=ROOT, capture_output=True)
    if stored.returncode == 0:
        source_binding['tracked_count'] += 1
        check(digest(stored.stdout) == expected, 'accepted source ' + path)
    else:
        source_binding['workspace_only'][path] = expected
check(set(source_binding['workspace_only']) == {'pubspec.lock', '.dart_tool/package_config.json'}, 'declared workspace-only inputs')

lanes = ('writing_only', 'deterministic', 'model_only', 'combined')
panels = {}
retained = {'build': preserve(SCRATCH / 'quality-build.json', 'incremental-quality-build-receipt.json')}
for panel, expected_rows in [('frozen', 30), ('prospective', 76)]:
    prior = load(BEFORE / (panel + '.json.gz'))
    current = load(SCRATCH / (panel + '.json'))
    retained[panel] = preserve(SCRATCH / (panel + '.json'), 'incremental-quality-' + panel + '-result.json')
    for key in ('completed', 'operational_passed', 'source_stable', 'status_contract_passed'):
        check(current[key], panel + ': ' + key)
    check(current['source_files'] == current['source_files_after'], panel + ': source seal')
    source = {k: v for k, v in current['source_files'].items() if k != 'declared-corpus'}
    check(source == build['source_files'], panel + ': build/run source identity')
    check(current['runtime']['executable'] == build['runtime']['executable'], panel + ': runtime executable')
    check(current['runtime']['entrypoint'] == build['runtime']['entrypoint'], panel + ': AOT executable')
    check(current['declared_cases'] == prior['declared_cases'], panel + ': unchanged declarations')
    check(current['cases_sha256'] == prior['cases_sha256'], panel + ': unchanged corpus hash')
    for key in ('model', 'native_library_sha256', 'bundle_assets'):
        check(current[key] == prior[key], panel + ': pinned asset identity ' + key)
    check(len(current['cases']) == expected_rows, panel + ': expected case rows')
    old_cases = {c['id']: c for c in prior['cases']}
    new_cases = {c['id']: c for c in current['cases']}
    check(old_cases.keys() == new_cases.keys(), panel + ': case identities')
    counts = {lane: {'exact_errors': 0, 'clean_flagged': 0, 'clean_changed': 0} for lane in lanes}
    delta = []
    added, lost = {lane: [] for lane in lanes}, {lane: [] for lane in lanes}
    for case in current['cases']:
        old = old_cases[case['id']]
        check(case['status_contract_passed'], panel + '/' + case['id'] + ': status contract')
        for lane in lanes:
            outcome = case['outcomes'][lane]
            text = project(case, outcome, panel + '/' + case['id'] + '/' + lane)
            if case['locale'] == 'de-DE':
                check(outcome['complete'], panel + '/' + case['id'] + '/' + lane + ': supported complete')
                if case['kind'] == 'error':
                    exact = text == case['expected']
                    counts[lane]['exact_errors'] += exact
                    old_exact = old['outcomes'][lane]['exact_expected']
                    if exact and not old_exact:
                        added[lane].append(case['id'])
                    if old_exact and not exact:
                        lost[lane].append(case['id'])
                elif case['kind'] == 'clean':
                    counts[lane]['clean_flagged'] += bool(outcome['displayed_findings'])
                    counts[lane]['clean_changed'] += text != case['input']
        check(case['outcomes']['model_only'] == old['outcomes']['model_only'], panel + '/' + case['id'] + ': unchanged model-only outcome')
        a, b = copy.deepcopy(old), copy.deepcopy(case)
        a.pop('timing_ms', None)
        b.pop('timing_ms', None)
        if a != b:
            delta.append({'id': case['id'], 'kind': case['kind'], 'locale': case['locale'], 'input': case['input'], 'expected': case['expected'], 'changed_lanes': {lane: {'before': old['outcomes'][lane]['corrected'], 'after': case['outcomes'][lane]['corrected'], 'before_exact': old['outcomes'][lane]['exact_expected'], 'after_exact': case['outcomes'][lane]['exact_expected']} for lane in lanes if old['outcomes'][lane] != case['outcomes'][lane]}})
    supported = [c for c in current['cases'] if c['locale'] == 'de-DE']
    for lane in lanes:
        check(not lost[lane], panel + ': no lost exact corrections in ' + lane)
        check(not counts[lane]['clean_flagged'] and not counts[lane]['clean_changed'], panel + ': no clean flags/changes in ' + lane)
    incremental_added = [c['id'] for c in supported if c['kind'] == 'error' and c['outcomes']['combined']['exact_expected'] and not c['outcomes']['deterministic']['exact_expected']]
    incremental_lost = [c['id'] for c in supported if c['kind'] == 'error' and c['outcomes']['deterministic']['exact_expected'] and not c['outcomes']['combined']['exact_expected']]
    check(not incremental_lost, panel + ': combined loses no deterministic correction')
    panels[panel] = {'rows': expected_rows, 'corpus_sha256': current['cases_sha256'], 'de_DE_errors': sum(c['kind'] == 'error' for c in supported), 'de_DE_clean': sum(c['kind'] == 'clean' for c in supported), 'counts': counts, 'new_exact_ids_since_prior': added, 'lost_exact_ids_since_prior': lost, 'model_added_exact_ids': incremental_added, 'model_lost_exact_ids': incremental_lost, 'changed_cases': delta, 'accepted_model_findings': sum(len(c['accepted_model_findings']) for c in supported), 'suppressed_model_findings': sum(len(c['suppressed_model_findings']) for c in supported)}

report = {'schemaVersion': 1, 'kind': 'independent-native-quality-recovery-comparison', 'source': SOURCE, 'historical_source': '121f3be504a89e56bde40bda8f93f4e81d8c2503', 'interpretation': 'Existing synthetic development regression inputs, unchanged declarations and expected answers. Fresh compiled native functional comparisons ran concurrently with unrelated local validation; timings are not used for performance claims.', 'source_binding': source_binding, 'retained': retained, 'panels': panels, 'issues': ISSUES, 'passed': not ISSUES}
out = OUT / 'incremental-quality-comparison.json'
if out.exists():
    raise RuntimeError('Refusing to overwrite ' + str(out))
out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
raise SystemExit(bool(ISSUES))
