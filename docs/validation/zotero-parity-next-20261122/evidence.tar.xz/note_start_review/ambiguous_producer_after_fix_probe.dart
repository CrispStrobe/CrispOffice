import 'dart:convert';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:test/test.dart';

const _text = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0';
const _style = 'urn:oasis:names:tc:opendocument:xmlns:style:1.0';
const _office = 'urn:oasis:names:tc:opendocument:xmlns:office:1.0';
const _meta = 'urn:oasis:names:tc:opendocument:xmlns:meta:1.0';
const _ns =
    'xmlns:office="$_office" xmlns:text="$_text" '
    'xmlns:style="$_style" xmlns:meta="$_meta"';
const _lower = ['i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix', 'x'];
const _offsetGenerator = 'CrispOffice Zotero ODT note-offsets/1';
const _libreOfficeGenerator =
    'LibreOfficeDev/26.8.0.0.alpha0\$Linux_X86_64 '
    'LibreOffice_project/2c87e51eeaa2b413ff4ae097b2705eea1995d8e5';

ZoteroCitation _citation(String id) => ZoteroCitation.fromJson({
  'citationID': id,
  'citationItems': [
    {
      'id': 'http://zotero.org/users/42/items/ABCD1234',
      'uris': ['http://zotero.org/users/42/items/ABCD1234'],
      'locator': '17–19',
      'label': 'page',
      'prefix': 'see ',
      'suffix': ' retained',
      'suppress-author': true,
      'itemData': {'id': 7, 'type': 'book', 'title': 'Über العربية 😀'},
    },
  ],
  'properties': {'plainCitation': '(Author, 17–19)'},
});

String _preferences({String fieldType = 'Field'}) => jsonEncode({
  'dataVersion': 4,
  'style': {
    'styleID': 'http://www.zotero.org/styles/chicago-fullnote-bibliography',
  },
  'prefs': {'fieldType': fieldType, 'noteType': 2},
  'futureData': {'retained': true},
});

WmlSectionSource _options(bool endnote, String properties) => WmlSectionSource(
  xml:
      '<w:sectPr xmlns:w="${OfficeNamespaces.w}">'
      '<w:${endnote ? 'endnotePr' : 'footnotePr'}>$properties'
      '</w:${endnote ? 'endnotePr' : 'footnotePr'}></w:sectPr>',
  values: const {},
);

WmlDocument _native({
  bool endnote = true,
  String? format,
  int count = 10,
  int? citedIndex,
  int? start,
  String extraProperties = '',
}) {
  final anchors = <WmlBlock>[];
  final notes = <WmlNote>[];
  for (var index = 0; index < count; index++) {
    final id = 17 + index * 7;
    anchors.add(
      WmlParagraph(
        inlines: [
          WmlRun(text: 'Before $index '),
          WmlRun(
            text: '$id',
            noteRefId: id,
            noteRefEndnote: endnote,
            properties: WmlRunProps(vertAlign: WmlVertAlign.superscript),
          ),
          WmlRun(text: ' after'),
        ],
      ),
    );
    final paragraph = WmlParagraph(inlines: [WmlRun(text: 'Note $index ')]);
    if (index == (citedIndex ?? count - 1)) {
      WordZotero.insertCitation(paragraph, _citation('citation-$index'));
    }
    notes.add(WmlNote(id: id, endnote: endnote, paragraphs: [paragraph]));
  }
  return WmlDocument(
    zoteroDocumentData: _preferences(),
    sections: [
      WmlSection(
        blocks: anchors,
        sourceProperties:
            format == null && start == null && extraProperties.isEmpty
            ? null
            : _options(
                endnote,
                '${format == null ? '' : '<w:numFmt w:val="$format"/>'}'
                '${start == null ? '' : '<w:numStart w:val="$start"/>'}'
                '$extraProperties',
              ),
      ),
    ],
    footnotes: endnote ? [] : notes,
    endnotes: endnote ? notes : [],
  );
}

XmlElement _xml(Uint8List bytes, String part) =>
    XmlDocument.parse(utf8.decode(ZipReader.fromBytes(bytes).read(part))).root!;

Iterable<XmlElement> _elements(XmlElement root, String local, String ns) sync* {
  if (root.localName == local && root.namespaceUri == ns) yield root;
  for (final child in root.childElements) {
    yield* _elements(child, local, ns);
  }
}

WmlDocument _docx(WmlDocument document) =>
    WordDeserializer().readBytes(WordSerializer().writeBytes(document));

String _state(WmlDocument document) => jsonEncode({
  'preferences': WordZoteroDocumentData.read(document),
  'sectionProperties': document.sections
      .map((section) => section.sourceProperties?.xml)
      .toList(),
  'paragraphs': [
    for (final paragraph in [
      ...document.paragraphs,
      for (final note in [...document.footnotes, ...document.endnotes])
        ...note.allParagraphs,
    ])
      {
        'text': paragraph.text,
        'field': paragraph.properties.fieldInstruction,
        'runs': [
          for (final run in paragraph.inlines.whereType<WmlRun>())
            {
              'text': run.text,
              'noteId': run.noteRefId,
              'endnote': run.noteRefEndnote,
              'custom': run.noteRefCustomMark,
              'field': run.fieldInstruction,
            },
        ],
      },
  ],
  'notes': [
    for (final note in [...document.footnotes, ...document.endnotes])
      {'id': note.id, 'endnote': note.endnote, 'text': note.text},
  ],
  'fields': WordZotero.fields(
    document,
  ).map((field) => field.instruction).toList(),
  'package': document.package == null
      ? null
      : {
          for (final part in document.package!.parts)
            part.uri: sha256
                .convert(document.package!.getPart(part.uri)!.readBytes())
                .toString(),
        },
});

void _unchangedAfterRefusal(WmlDocument document) {
  final before = _state(document);
  final package = document.package;
  final references = [
    for (final paragraph in document.paragraphs)
      ...paragraph.inlines.whereType<WmlRun>(),
  ];
  final cached = references.map((run) => run.text).toList();
  expect(
    () => OdtDocumentWriter.writeEditableZoteroBytes(document),
    throwsUnsupportedError,
  );
  expect(references.map((run) => run.text), cached);
  expect(_state(document), before);
  expect(document.package, same(package));
}

// Independently authored native ODF; this does not use Quds' ODT exporter.
Uint8List _odf({
  String format = 'i',
  List<String> labels = _lower,
  bool endnote = true,
  String extraConfiguration = '',
  String? generator,
  String? generatorMarkup,
  String? configurations,
}) {
  final kind = endnote ? 'endnote' : 'footnote';
  final mark = encodeXmlAttribute(
    'ZOTERO_ITEM CSL_CITATION ${jsonEncode(_citation('odf-note').toJson())} '
    'RNDabcdefghij',
  );
  final notes = StringBuffer();
  for (var index = 0; index < labels.length; index++) {
    notes.write(
      '<text:p>Anchor $index '
      '<text:note text:id="source-$index" text:note-class="$kind">'
      '<text:note-citation>${encodeXmlText(labels[index])}</text:note-citation>'
      '<text:note-body><text:p>Note $index ',
    );
    if (index == labels.length - 1) {
      notes.write(
        '<text:reference-mark-start text:name="$mark"/>'
        '(Author, 17–19)<text:reference-mark-end text:name="$mark"/>',
      );
    }
    notes.write('</text:p></text:note-body></text:note> after</text:p>');
  }
  final archive = ZipWriter();
  archive.addFile(
    'mimetype',
    utf8.encode('application/vnd.oasis.opendocument.text'),
    store: true,
  );
  archive.addFile(
    'content.xml',
    utf8.encode(
      '<office:document-content $_ns><office:body><office:text>'
      '$notes</office:text></office:body></office:document-content>',
    ),
  );
  archive.addFile(
    'styles.xml',
    utf8.encode(
      '<office:document-styles $_ns><office:styles>'
      '${configurations ?? '<text:notes-configuration text:note-class="$kind" style:num-format="$format" $extraConfiguration/>'}'
      '</office:styles></office:document-styles>',
    ),
  );
  archive.addFile(
    'meta.xml',
    utf8.encode(
      '<office:document-meta $_ns><office:meta>'
      '${generatorMarkup ?? (generator == null ? '' : '<meta:generator>${encodeXmlText(generator)}</meta:generator>')}'
      '<meta:user-defined meta:name="ZOTERO_PREF_1">'
      '${encodeXmlText(_preferences(fieldType: 'ReferenceMark'))}'
      '</meta:user-defined></office:meta></office:document-meta>',
    ),
  );
  return archive.close();
}

Future<void> main() async {
  for (final sample in [
    ('valid-libreoffice-empty-cache', '<meta:generator>$_libreOfficeGenerator</meta:generator>', false),
    ('ambiguous-libreoffice', '<meta:generator>$_libreOfficeGenerator</meta:generator><meta:wrapper><meta:generator>$_libreOfficeGenerator</meta:generator></meta:wrapper>', false),
    ('ambiguous-quds', '<meta:generator>$_offsetGenerator</meta:generator><meta:wrapper><meta:generator>$_offsetGenerator</meta:generator></meta:wrapper>', false),
    ('unknown-normative', '<meta:generator>Independent ODF producer/1.0</meta:generator>', true),
  ]) {
    var accepted = false;
    String? label;
    var activeFields = 0;
    String? error;
    try {
      final restored = await OdtDocumentReader.readBytes(_odf(generatorMarkup: sample.$2, labels: [''], extraConfiguration: 'text:start-value="1"'));
      accepted = true;
      label = WordNoteNumbering(restored).labelFor(restored.endnotes.single);
      activeFields = WordZotero.fields(restored).length;
    } catch (failure) {
      error = failure.toString();
    }
    print(jsonEncode({'case': sample.$1, 'markup': sample.$2, 'accepted': accepted, 'label': label, 'activeFields': activeFields, 'error': error}));
    if (accepted != sample.$3 || (accepted && (label != 'i' || activeFields != 1))) {
      throw StateError('Unexpected producer interpretation: ${sample.$1}');
    }
  }
}
