import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:quds_office_engine/quds_office_engine.dart';

const generator = 'CrispOffice Zotero ODT note-offsets/1';
const textNs = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0';
const styleNs = 'urn:oasis:names:tc:opendocument:xmlns:style:1.0';
const metaNs = 'urn:oasis:names:tc:opendocument:xmlns:meta:1.0';
const specifications = <String, List<Map<String, Object>>>{
  'mixed-starts': [
    {
      'kind': 'footnote',
      'ordinal': 1,
      'start': 8,
      'format': 'decimal',
      'label': '8',
      'cited': false,
    },
    {
      'kind': 'endnote',
      'ordinal': 1,
      'start': 9,
      'format': 'lowerRoman',
      'label': 'ix',
      'cited': false,
    },
    {
      'kind': 'footnote',
      'ordinal': 2,
      'start': 8,
      'format': 'decimal',
      'label': '9',
      'cited': true,
    },
    {
      'kind': 'endnote',
      'ordinal': 2,
      'start': 9,
      'format': 'lowerRoman',
      'label': 'x',
      'cited': true,
    },
    {
      'kind': 'footnote',
      'ordinal': 3,
      'start': 8,
      'format': 'decimal',
      'label': '10',
      'cited': true,
    },
    {
      'kind': 'endnote',
      'ordinal': 3,
      'start': 9,
      'format': 'lowerRoman',
      'label': 'xi',
      'cited': true,
    },
  ],
  'roman-boundary': [
    {
      'kind': 'endnote',
      'ordinal': 1,
      'start': 3998,
      'format': 'upperRoman',
      'label': 'MMMCMXCVIII',
      'cited': false,
    },
    {
      'kind': 'endnote',
      'ordinal': 2,
      'start': 3998,
      'format': 'upperRoman',
      'label': 'MMMCMXCIX',
      'cited': true,
    },
  ],
  'decimal-boundary': [
    {
      'kind': 'footnote',
      'ordinal': 1,
      'start': 32768,
      'format': 'decimal',
      'label': '32768',
      'cited': false,
    },
    {
      'kind': 'footnote',
      'ordinal': 2,
      'start': 32768,
      'format': 'decimal',
      'label': '32769',
      'cited': true,
    },
  ],
};

String stable(Object? value) {
  Object? sort(Object? value) {
    if (value is Map) {
      final keys = value.keys.map((e) => e.toString()).toList()..sort();
      return {for (final key in keys) key: sort(value[key])};
    }
    if (value is List) return value.map(sort).toList();
    return value;
  }

  return jsonEncode(sort(value));
}

void check(bool condition, String message) {
  if (!condition) throw StateError(message);
}

void eq(Object? actual, Object? expected, String message) {
  if (stable(actual) != stable(expected)) {
    throw StateError(
      '$message\nexpected=${stable(expected)}\nactual=${stable(actual)}',
    );
  }
}

String key(String name, Map<String, Object> spec) =>
    '$name-${spec['kind']}-${spec['ordinal']}';
String noteText(String name, Map<String, Object> spec) =>
    'Owner ${key(name, spec)} العربية Über 😀. ';
String citedText(String name, Map<String, Object> spec) =>
    '(Citation ${key(name, spec)}; 17–19)';
ZoteroCitation citation(String name, Map<String, Object> spec) =>
    ZoteroCitation.fromJson({
      'citationID': key(name, spec),
      'citationItems': [
        {
          'id': 'http://zotero.org/users/42/items/ABCD1234',
          'uris': ['http://zotero.org/users/42/items/ABCD1234'],
          'locator': '17–19',
          'label': 'page',
          'prefix': 'see ',
          'suffix': ' retained العربية',
          'suppress-author': true,
          'itemData': {
            'id': 'http://zotero.org/users/42/items/ABCD1234',
            'type': 'book',
            'title': 'Über العربية 😀',
          },
          'futureItemProperty': {
            'keep': [1, 2, 3],
          },
        },
      ],
      'properties': {
        'plainCitation': citedText(name, spec),
        'noteIndex': spec['ordinal'],
        'unsorted': true,
      },
      'futureCitationProperty': {'case': name, 'retained': true},
    });
Map<String, Object> preferences({String fieldType = 'Field'}) => {
  'dataVersion': 4,
  'style': {
    'styleID': 'http://www.zotero.org/styles/chicago-fullnote-bibliography',
    'locale': 'en-US',
  },
  'prefs': {
    'fieldType': fieldType,
    'noteType': 2,
    'automaticJournalAbbreviations': true,
  },
  'futureData': {'retained': true, 'label': 'العربية'},
};

WmlDocument build(String name) {
  final specs = specifications[name]!;
  final properties = StringBuffer('<w:sectPr xmlns:w="${OfficeNamespaces.w}">');
  for (final kind in ['footnote', 'endnote']) {
    final matching = specs.where((spec) => spec['kind'] == kind);
    if (matching.isEmpty) continue;
    final s = matching.first;
    properties.write(
      '<w:${kind}Pr><w:numFmt w:val="${s['format']}"/><w:numStart w:val="${s['start']}"/><w:numRestart w:val="continuous"/></w:${kind}Pr>',
    );
  }
  properties.write('</w:sectPr>');
  final blocks = <WmlBlock>[];
  final feet = <WmlNote>[];
  final ends = <WmlNote>[];
  for (final (index, spec) in specs.indexed) {
    final end = spec['kind'] == 'endnote';
    final id = 71 + index * 13;
    blocks.add(
      WmlParagraph(
        inlines: [
          WmlRun(text: 'Anchor ${key(name, spec)} '),
          WmlRun(
            text: '$id',
            noteRefId: id,
            noteRefEndnote: end,
            properties: WmlRunProps(vertAlign: WmlVertAlign.superscript),
          ),
          WmlRun(text: ' after.'),
        ],
      ),
    );
    final paragraph = WmlParagraph(
      inlines: [WmlRun(text: noteText(name, spec))],
    );
    if (spec['cited'] == true)
      WordZotero.insertCitation(paragraph, citation(name, spec));
    final note = WmlNote(id: id, endnote: end, paragraphs: [paragraph]);
    (end ? ends : feet).add(note);
  }
  return WmlDocument(
    zoteroDocumentData: jsonEncode(preferences()),
    sections: [
      WmlSection(
        blocks: blocks,
        sourceProperties: WmlSectionSource(
          xml: properties.toString(),
          values: const {},
        ),
      ),
    ],
    footnotes: feet,
    endnotes: ends,
  );
}

Object state(WmlDocument document) => {
  'data': WordZoteroDocumentData.read(document),
  'sections': document.sections.map((s) => s.sourceProperties?.xml).toList(),
  'paragraphs': [
    for (final p in [
      ...document.paragraphs,
      for (final n in [...document.footnotes, ...document.endnotes])
        ...n.allParagraphs,
    ])
      {
        'text': p.text,
        'field': p.properties.fieldInstruction,
        'runs': [
          for (final r in p.inlines.whereType<WmlRun>())
            {
              'text': r.text,
              'field': r.fieldInstruction,
              'noteId': r.noteRefId,
              'endnote': r.noteRefEndnote,
              'custom': r.noteRefCustomMark,
            },
        ],
      },
  ],
  'notes': [
    for (final n in [...document.footnotes, ...document.endnotes])
      {'id': n.id, 'endnote': n.endnote, 'text': n.text},
  ],
  'fields': WordZotero.fields(document).map((f) => f.instruction).toList(),
  'parts': document.package == null
      ? null
      : {
          for (final part in document.package!.parts)
            part.uri: sha256
                .convert(document.package!.getPart(part.uri)!.readBytes())
                .toString(),
        },
};

Map<String, Object?> verifyNative(String name, WmlDocument document) {
  final specs = specifications[name]!;
  final numbering = WordNoteNumbering(document);
  eq(numbering.notes.length, specs.length, '$name native note count');
  final fields = WordZotero.fields(document);
  eq(
    fields.length,
    specs.where((s) => s['cited'] == true).length,
    '$name native field count',
  );
  final notesReport = <Object>[];
  for (var i = 0; i < specs.length; i++) {
    final spec = specs[i];
    final note = numbering.notes[i];
    final auto = numbering.automaticNumberFor(note);
    eq(note.endnote, spec['kind'] == 'endnote', '$name note class at $i');
    eq(
      numbering.labelFor(note),
      spec['label'],
      '$name visible native label at $i',
    );
    eq(auto?.start, spec['start'], '$name native numStart at $i');
    eq(auto?.format, spec['format'], '$name native numFmt at $i');
    eq(auto?.restart, 'continuous', '$name native numRestart at $i');
    eq(
      auto?.number,
      (spec['start']! as int) + (spec['ordinal']! as int) - 1,
      '$name native number at $i',
    );
    eq(
      note.text,
      noteText(name, spec) +
          (spec['cited'] == true ? citedText(name, spec) : ''),
      '$name note contents at $i',
    );
    final owned = fields
        .where((f) => note.allParagraphs.contains(f.paragraph))
        .toList();
    eq(
      owned.length,
      spec['cited'] == true ? 1 : 0,
      '$name citation ownership at $i',
    );
    if (owned.isNotEmpty) {
      eq(
        owned.single.citation?.toJson(),
        citation(name, spec).toJson(),
        '$name complete citation metadata at $i',
      );
      eq(
        owned.single.cachedText,
        citedText(name, spec),
        '$name citation cached text at $i',
      );
    }
    notesReport.add({
      'owner': key(name, spec),
      'class': spec['kind'],
      'label': numbering.labelFor(note),
      'nativeId': note.id,
      'numStart': auto?.start,
      'numFmt': auto?.format,
      'number': auto?.number,
      'citations': owned.map((f) => f.citation?.citationId).toList(),
    });
  }
  final prefs =
      jsonDecode(WordZoteroDocumentData.read(document)) as Map<String, dynamic>;
  eq(prefs, preferences(), '$name preference preservation/Field adaptation');
  final before = stable(state(document));
  final session = WordZoteroCitingSession(document: document, documentId: name);
  final http = session.handle('Document.getFields', [name, 'Http'])! as List;
  final observed = <Object>[];
  for (final field in http.cast<Map>()) {
    final code = field['code']! as String;
    final metadata = jsonDecode(
      code.substring(code.indexOf('{'), code.lastIndexOf('}') + 1),
    ) as Map;
    check(field['noteIndex'] is int, '$name noteIndex must remain numeric');
    observed.add({
      'citationID': metadata['citationID'],
      'noteIndex': field['noteIndex'],
    });
  }
  eq(observed, [
    for (final spec in specs)
      if (spec['cited'] == true)
        {'citationID': key(name, spec), 'noteIndex': spec['ordinal']},
  ], '$name physical noteIndex and body citation order');
  session.assertUnchanged();
  eq(stable(state(document)), before, '$name read-only session changed source');
  return {'notes': notesReport, 'httpFields': observed, 'preferences': prefs};
}

Iterable<XmlElement> elements(XmlElement root, String local, String ns) sync* {
  if (root.localName == local && root.namespaceUri == ns) yield root;
  for (final child in root.childElements) yield* elements(child, local, ns);
}

XmlElement part(Uint8List bytes, String name) =>
    XmlDocument.parse(utf8.decode(ZipReader.fromBytes(bytes).read(name))).root!;
Map<String, Object?> verifyOdt(
  String name,
  Uint8List bytes, {
  required bool quds,
}) {
  final specs = specifications[name]!;
  final content = part(bytes, 'content.xml');
  final styles = part(bytes, 'styles.xml');
  final meta = part(bytes, 'meta.xml');
  final g = elements(meta, 'generator', metaNs).single.text;
  check(
    quds ? g == generator : g.startsWith('LibreOffice'),
    '$name unexpected generator $g',
  );
  final labels = elements(content, 'note-citation', textNs).toList();
  eq(
    labels.map((e) => e.text).toList(),
    specs.map((s) => s['label']).toList(),
    '$name independent ODT cached labels',
  );
  check(
    labels.every((e) => e.getAttribute('label', namespaceUri: textNs) == null),
    '$name custom fixed labels appeared',
  );
  final configs = <String, Object>{};
  for (final kind in ['footnote', 'endnote']) {
    final matching = specs.where((s) => s['kind'] == kind);
    if (matching.isEmpty) continue;
    final spec = matching.first;
    final config = elements(styles, 'notes-configuration', textNs).singleWhere(
      (e) => e.getAttribute('note-class', namespaceUri: textNs) == kind,
    );
    final value = config.getAttribute('start-value', namespaceUri: textNs);
    eq(
      value,
      '${(spec['start']! as int) - 1}',
      '$name $kind ODT zero-based offset',
    );
    final fmt = switch (spec['format']) {
      'lowerRoman' => 'i',
      'upperRoman' => 'I',
      _ => '1',
    };
    eq(
      config.getAttribute('num-format', namespaceUri: styleNs),
      fmt,
      '$name $kind ODT format',
    );
    configs[kind] = {'start-value': value!, 'num-format': fmt};
  }
  return {
    'generator': g,
    'labels': labels.map((e) => e.text).toList(),
    'configuration': configs,
  };
}

void writeJson(File file, Object value) => file.writeAsStringSync(
  '${const JsonEncoder.withIndent('  ').convert(value)}\n',
);
Future<void> main(List<String> args) async {
  final mode = args[0];
  final directory = Directory(args[1])..createSync(recursive: true);
  final quds = mode == 'create' || args.contains('--quds');
  final reports = <Object>[];
  for (final name in specifications.keys) {
    final original = File('${directory.path}/$name.odt');
    if (mode == 'create') {
      final initial = build(name);
      final sourceBytes = WordSerializer().writeBytes(initial);
      File('${directory.path}/$name.source.docx').writeAsBytesSync(sourceBytes);
      final source = WordDeserializer().readBytes(sourceBytes);
      final sourceExpected = verifyNative(name, source);
      final before = stable(state(source));
      final odt = OdtDocumentWriter.writeEditableZoteroBytes(source);
      eq(stable(state(source)), before, '$name export mutated original source');
      original.writeAsBytesSync(odt);
      writeJson(File('${directory.path}/$name.expected.json'), {
        'specifications': specifications[name],
        'source': sourceExpected,
        'originalStateSha256': sha256.convert(utf8.encode(before)).toString(),
        'sourceUnchanged': true,
      });
    }
    final bytes = original.readAsBytesSync();
    final beforeHash = sha256.convert(bytes).toString();
    final odtObserved = verifyOdt(name, bytes, quds: quds);
    final inventory = await OdfZotero.inspect(bytes);
    eq(
      inventory.fields.length,
      specifications[name]!.where((s) => s['cited'] == true).length,
      '$name ODF inventory field count',
    );
    check(
      inventory.fields.every((f) => f.isImportCandidate),
      '$name ODF references must remain import candidates',
    );
    var native = await OdtDocumentReader.readBytes(bytes);
    final imported = verifyNative(name, native);
    eq(
      sha256.convert(bytes).toString(),
      beforeHash,
      '$name native read mutated input bytes',
    );
    var docx = WordSerializer().writeBytes(native);
    File('${directory.path}/$name.reopened.docx').writeAsBytesSync(docx);
    native = WordDeserializer().readBytes(docx);
    final reopened = verifyNative(name, native);
    final repeated = <Object>[];
    for (var cycle = 1; cycle <= 2; cycle++) {
      final before = stable(state(native));
      final odt = OdtDocumentWriter.writeEditableZoteroBytes(native);
      eq(
        stable(state(native)),
        before,
        '$name re-export $cycle changed native source',
      );
      File('${directory.path}/$name.reexport-$cycle.odt').writeAsBytesSync(odt);
      final xml = verifyOdt(name, odt, quds: true);
      native = await OdtDocumentReader.readBytes(odt);
      verifyNative(name, native);
      docx = WordSerializer().writeBytes(native);
      File('${directory.path}/$name.reexport-$cycle.docx')
          .writeAsBytesSync(docx);
      native = WordDeserializer().readBytes(docx);
      repeated.add({
        'cycle': cycle,
        'odt': xml,
        'docxReopened': verifyNative(name, native),
      });
    }
    eq(
      sha256.convert(original.readAsBytesSync()).toString(),
      beforeHash,
      '$name original file changed',
    );
    final report = {
      'name': name,
      'result': 'PASS',
      'odt': odtObserved,
      'imported': imported,
      'docxReopened': reopened,
      'repeatedReexports': repeated,
      'inputFileUnchanged': true,
    };
    writeJson(File('${directory.path}/$name.observed.json'), report);
    reports.add(report);
    stdout.writeln('PASS $name $mode');
  }
  writeJson(File('${directory.path}/report.json'), {
    'result': 'PASS',
    'fixtures': reports,
    'uniqueFixtures': 3,
    'uniqueNotes': 10,
    'uniqueCitations': 6,
  });
}
