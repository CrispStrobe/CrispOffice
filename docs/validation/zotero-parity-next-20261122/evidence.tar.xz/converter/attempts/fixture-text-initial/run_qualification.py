from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,subprocess,time,traceback,zipfile,xml.etree.ElementTree as ET
ROOT=Path('/workspace/scratch/8a80441c4c60/validation/converter')
REPO=Path('/workspace/scratch/8a80441c4c60/quds_office_suite')
TOOLS=Path('/workspace/scratch/8a80441c4c60/toolchains')
DART=TOOLS/'bin/dart'
SOFFICE=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/program/soffice')
FIXTURE=ROOT/'note_start_fixtures.dart'
NAMES=['mixed-starts','roman-boundary','decimal-boundary']
OUT=ROOT/'accepted'
OUT.mkdir()
LOGS=OUT/'logs';LOGS.mkdir()
NS={'text':'urn:oasis:names:tc:opendocument:xmlns:text:1.0','style':'urn:oasis:names:tc:opendocument:xmlns:style:1.0','meta':'urn:oasis:names:tc:opendocument:xmlns:meta:1.0','w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
receipt={'startedUtc':datetime.now(timezone.utc).isoformat(),'commands':[],'scope':'Synthetic active Zotero ODT; two actual LibreOffice saves; Quds import and DOCX save/reopen; two Quds reexports per stage. No installed Zotero plugin, Microsoft Word execution or visual rendering claim.'}
def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(): (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def inputs():
    files=list((REPO/'packages/quds_office_engine/lib').rglob('*.dart'))
    files += [REPO/'pubspec.lock',REPO/'pubspec.yaml',REPO/'.dart_tool/package_config.json',REPO/'packages/quds_office_engine/pubspec.yaml',FIXTURE,ROOT/'run_qualification.py']
    return {str(p.relative_to(REPO)) if p.is_relative_to(REPO) else str(p):sha(p) for p in sorted(files)}
def run(name,argv,cwd=REPO):
    start=time.monotonic()
    out=LOGS/(name+'.stdout.log');err=LOGS/(name+'.stderr.log')
    print('START '+name,flush=True)
    with out.open('wb') as fo,err.open('wb') as fe:
        p=subprocess.run([str(a) for a in argv],cwd=cwd,stdout=fo,stderr=fe,timeout=180)
    record={'name':name,'argv':[str(a) for a in argv],'cwd':str(cwd),'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3),'stdout':str(out.relative_to(OUT)),'stderr':str(err.relative_to(OUT)),'stdoutSha256':sha(out),'stderrSha256':sha(err)}
    receipt['commands'].append(record);save()
    if p.returncode:
        raise RuntimeError(name+' failed:\n'+out.read_text(errors='replace')[-5000:]+'\n'+err.read_text(errors='replace')[-8000:])
    print('PASS '+name,flush=True)
    return out.read_text(errors='replace')
def xml_inventory(directory):
    report={}
    for name in NAMES:
        path=directory/(name+'.odt')
        with zipfile.ZipFile(path) as z:
            roots={p:ET.fromstring(z.read(p)) for p in ['content.xml','styles.xml','meta.xml']}
        content,styles,meta=(roots[p] for p in ['content.xml','styles.xml','meta.xml'])
        def attr(e,ns,key):return e.attrib.get('{'+NS[ns]+'}'+key)
        notes=[]
        for n in content.findall('.//text:note',NS):
            label=n.find('text:note-citation',NS)
            body=n.find('text:note-body',NS)
            fields=[]
            for m in body.findall('.//text:reference-mark-start',NS):
                code=attr(m,'text','name')
                packet=json.loads(code[code.index('{'):code.rindex('}')+1])
                fields.append(packet['citationID'])
            notes.append({'class':attr(n,'text','note-class'),'label':''.join(label.itertext()),'customLabel':attr(label,'text','label'),'ownerText':''.join(body.itertext()),'citationIDs':fields})
        config=[{'class':attr(n,'text','note-class'),'format':attr(n,'style','num-format'),'startValue':attr(n,'text','start-value')} for n in styles.findall('.//text:notes-configuration',NS)]
        report[name]={'generator':meta.find('.//meta:generator',NS).text,'notes':notes,'configuration':config}
    (directory/'independent-xml.json').write_text(json.dumps(report,indent=2)+'\n')
try:
    receipt['sourceCommit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
    receipt['sourceTree']=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=REPO,text=True).strip()
    before=inputs()
    (OUT/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
    receipt['dartVersion']=run('dart-version',[DART,'--version']).strip()
    receipt['libreOfficeVersion']=run('libreoffice-version',[SOFFICE,'-env:UserInstallation='+str((OUT/'version-profile').as_uri()),'--version']).strip()
    receipt['runtimeHashes']={'dart':sha(TOOLS/'flutter/bin/cache/dart-sdk/bin/dart'),'soffice.bin':sha(SOFFICE.with_name('soffice.bin'))}
    dart=[DART,'--packages='+str(REPO/'.dart_tool/package_config.json'),FIXTURE]
    original=OUT/'original'
    run('create-and-verify-original',dart+['create',original])
    xml_inventory(original)
    previous=original
    for cycle in [1,2]:
        output=OUT/('lo-save-'+str(cycle));output.mkdir()
        run('libreoffice-save-'+str(cycle),[SOFFICE,'-env:UserInstallation='+str((OUT/('profile-'+str(cycle))).as_uri()),'--headless','--convert-to','odt:writer8','--outdir',output]+[previous/(n+'.odt') for n in NAMES])
        missing=[n for n in NAMES if not (output/(n+'.odt')).is_file()]
        if missing: raise RuntimeError('LibreOffice did not produce: '+str(missing))
        xml_inventory(output)
        run('verify-save-'+str(cycle),dart+['verify',output])
        previous=output
    after=inputs()
    (OUT/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
    changed=[p for p in set(before)|set(after) if before.get(p)!=after.get(p)]
    receipt['sourceInputsUnchanged']=not changed
    receipt['changedInputPaths']=changed
    if changed:raise RuntimeError('Converter source inputs changed during qualification: '+str(changed))
    receipt.update(result='PASS',uniqueFixtures=3,uniqueNotes=10,uniqueActiveCitations=6,libreOfficeSaveCycles=2,odtImportAndDocxReopenStagesPerFixture=3,reexportCyclesPerStage=2)
except BaseException as e:
    receipt['result']='FAIL'
    receipt['error']=str(e)
    traceback.print_exc()
finally:
    receipt['finishedUtc']=datetime.now(timezone.utc).isoformat()
    receipt['artifactHashes']={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='receipt.json' and not any(part.startswith('profile-') or part=='version-profile' for part in p.relative_to(OUT).parts)}
    save()
    print(receipt['result'],flush=True)
    if receipt['result']!='PASS':raise SystemExit(1)
