from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib, importlib.util, io, json, os, shlex, subprocess, tarfile, time, urllib.request, yaml
ROOT = Path('/workspace/scratch/8a80441c4c60/toolchains')
REPO = ROOT.parent / 'quds_office_suite'
SDK = ROOT / 'flutter'
CACHE = ROOT / 'pub-cache'
LOGS = ROOT / 'logs'
for relative in ['logs', 'pub-cache/hosted/pub.dev', 'pub-cache/hosted-hashes/pub.dev', 'pub-cache/_temp', 'bin', 'tmp', 'config', 'data', 'cache']:
    (ROOT / relative).mkdir(parents=True, exist_ok=True)
spec=importlib.util.spec_from_file_location('prior_restore', REPO / 'docs/validation/document-review-notes-20261118/runtime/restore_runtime.py')
prior=importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
receipt={'started_at_utc':datetime.now(timezone.utc).isoformat(),'status':'restoring','source':str(REPO),'sdk':str(SDK),'runs':[]}
def sha(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def save(): (ROOT/'runtime.json').write_text(json.dumps(receipt,indent=2)+'\n')
def read_url(url):
    with urllib.request.urlopen(url,timeout=60) as r: return r.read()
try:
    lock_before=sha(REPO/'pubspec.lock')
    manifests={str(p.relative_to(REPO)):sha(p) for p in REPO.rglob('pubspec.yaml') if '.dart_tool' not in p.parts}
    receipt['workspace_lock_initial_sha256']=lock_before
    metadata=json.loads(read_url('https://storage.googleapis.com/flutter_infra_release/releases/releases_linux.json'))
    releases=[v for v in metadata['releases'] if v.get('version')=='3.47.8' and v.get('channel')=='stable' and v.get('dart_sdk_arch')=='x64']
    if not releases: releases=[v for v in metadata['releases'] if v.get('version')=='3.47.8' and v.get('channel')=='stable']
    release=releases[0]
    if release['hash']!='737ba8f885dc774b53b442759999a312c9461e4e' or release['sha256']!=prior.SDK_SHA256: raise RuntimeError('Official metadata differs from pinned runtime')
    (ROOT/'official-release.json').write_text(json.dumps(release,indent=2)+'\n')
    print('Streaming verified official Flutter 3.47.8 archive',flush=True)
    count=expanded=0
    last=time.monotonic()
    with urllib.request.urlopen(prior.SDK_URL,timeout=60) as response:
        reader=prior.DigestReader(response)
        with tarfile.open(fileobj=reader,mode='r|xz') as archive:
            for member in archive:
                if prior.selected(member.name) or member.name=='flutter/'+prior.NODE_COMPILER:
                    archive.extract(member,ROOT,filter='data')
                    count+=1
                    expanded+=member.size
                if time.monotonic()-last>20:
                    print(json.dumps({'downloaded_bytes':reader.total,'retained_bytes':expanded}),flush=True)
                    last=time.monotonic()
        while reader.read(8*1024**2): pass
        if reader.digest.hexdigest()!=prior.SDK_SHA256 or reader.total!=prior.SDK_BYTES: raise RuntimeError('Archive hash/size mismatch')
    receipt['archive']={'url':prior.SDK_URL,'sha256':prior.SDK_SHA256,'bytes':reader.total,'verified':True,'extracted_bytes':expanded,'selection':'VM Flutter tests, AOT analysis, Dart-to-JavaScript Node tests; no full native/web builds'}
    hashes=dict(prior.EXECUTABLES)
    hashes[prior.NODE_COMPILER]=prior.NODE_COMPILER_SHA256
    for relative,expected in hashes.items():
        if sha(SDK/relative)!=expected: raise RuntimeError('Executable mismatch: '+relative)
    receipt['executables_sha256']={str(SDK/k):v for k,v in hashes.items()}
    save()
    packages={}
    for lock in [SDK/'packages/flutter_tools/pubspec.lock',REPO/'pubspec.lock']:
        for name,item in yaml.safe_load(lock.read_text())['packages'].items():
            if item['source']!='hosted': continue
            info=item['description']
            if info['url']!='https://pub.dev': raise RuntimeError('Unexpected dependency host')
            key=name+'-'+item['version']
            val={'name':name,'version':item['version'],'sha256':info['sha256']}
            if key in packages and packages[key]!=val: raise RuntimeError('Conflicting package hashes')
            packages[key]=val
    def fetch(pair):
        key,info=pair
        url='https://pub.dev/api/archives/'+key+'.tar.gz'
        data=read_url(url)
        if hashlib.sha256(data).hexdigest()!=info['sha256']: raise RuntimeError('Package hash mismatch: '+key)
        target=CACHE/'hosted/pub.dev'/key
        target.mkdir(exist_ok=True)
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as bundle: bundle.extractall(target,filter='data')
        (CACHE/'hosted-hashes/pub.dev'/(key+'.sha256')).write_text(info['sha256'])
        return dict(info,url=url,bytes=len(data),verified=True)
    print('Restoring '+str(len(packages))+' hash-pinned package archives',flush=True)
    with ThreadPoolExecutor(max_workers=8) as pool: archives=list(pool.map(fetch,sorted(packages.items())))
    (ROOT/'pub-cache-receipt.json').write_text(json.dumps(archives,indent=2)+'\n')
    receipt['hosted_archives_verified']=len(archives)
    env=dict(os.environ,PUB_CACHE=str(CACHE),FLUTTER_ROOT=str(SDK),CI='true',DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true',DASH__SUPPRESS_ANALYTICS='true',XDG_CONFIG_HOME=str(ROOT/'config'),XDG_CACHE_HOME=str(ROOT/'cache'),XDG_DATA_HOME=str(ROOT/'data'),TMPDIR=str(ROOT/'tmp'))
    dart=SDK/'bin/cache/dart-sdk/bin/dart'
    flutter=ROOT/'bin/flutter'
    flutter.write_text('#!/bin/sh\nexec '+shlex.quote(str(dart))+' '+shlex.quote(str(SDK/'bin/cache/flutter_tools.snapshot'))+' --no-version-check "$@"\n')
    flutter.chmod(0o755)
    dw=ROOT/'bin/dart'
    dw.write_text('#!/bin/sh\nexec '+shlex.quote(str(dart))+' "$@"\n')
    dw.chmod(0o755)
    env['PATH']=str(ROOT/'bin')+os.pathsep+env.get('PATH','')
    keys=['PUB_CACHE','FLUTTER_ROOT','CI','DART_SUPPRESS_ANALYTICS','FLUTTER_SUPPRESS_ANALYTICS','DASH__SUPPRESS_ANALYTICS','XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','TMPDIR']
    (ROOT/'env.sh').write_text('\n'.join('export '+k+'='+shlex.quote(env[k]) for k in keys)+'\nexport PATH='+shlex.quote(str(ROOT/'bin'))+':"$PATH"\n')
    def run(name,cmd,cwd):
        print('START '+name,flush=True)
        log=LOGS/(name+'.log')
        with log.open('wb') as f: r=subprocess.run([str(x) for x in cmd],cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
        receipt['runs'].append({'name':name,'command':[str(x) for x in cmd],'cwd':str(cwd),'exit_code':r.returncode,'log':str(log),'log_sha256':sha(log)})
        save()
        if r.returncode: raise RuntimeError(name+': '+log.read_text(errors='replace')[-8000:])
        return log
    run('flutter-tools-pub-get',[dart,'pub','get','--offline','--enforce-lockfile'],SDK/'packages/flutter_tools')
    run('workspace-pub-get',[dart,'pub','get','--offline','--enforce-lockfile'],REPO)
    ver=run('flutter-version',[flutter,'--version','--machine'],REPO)
    receipt['runtime']=json.loads(ver.read_text())
    if receipt['runtime']['frameworkRevision']!='737ba8f885dc774b53b442759999a312c9461e4e' or receipt['runtime']['dartSdkVersion']!='3.13.7': raise RuntimeError('Runtime version mismatch')
    if sha(REPO/'pubspec.lock')!=lock_before: raise RuntimeError('Lock changed')
    if any(sha(REPO/k)!=v for k,v in manifests.items()): raise RuntimeError('Manifest changed')
    receipt['workspace_lock_sha256']=sha(REPO/'pubspec.lock')
    receipt['workspace_package_count']=len(prior.verified_workspace_packages(REPO)['resolved'])
    receipt['environment_script']=str(ROOT/'env.sh')
    receipt['status']='ready'
    print('READY '+str(ROOT/'env.sh'),flush=True)
except BaseException as e:
    receipt['status']='failed'
    receipt['error']=repr(e)
    raise
finally:
    receipt['finished_at_utc']=datetime.now(timezone.utc).isoformat()
    save()
