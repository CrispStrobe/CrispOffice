#!/usr/bin/env python3
"""Execute the audited residual Word/Zotero cohorts at the final remote source."""
import collections
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading
import time

BASE = Path('/workspace/scratch/03cd41fa0e7e')
REPO = BASE / 'quds_delivery'
OUT = BASE / 'runtime/word-zotero-delivery-qualification'
EXPECTED = 'c62338c65571aa399da5592455b651fa5c6a9317'
ENGINE = REPO / 'packages/quds_office_engine'
EDITOR = REPO / 'packages/quds_office_editor'
RT = BASE / 'runtime/toolchain'
FRT = BASE / 'runtime/flutter-toolchain'
DART = RT / 'dart-sdk/bin/dart'
FDART = FRT / 'flutter/bin/cache/dart-sdk/bin/dart'
FLUTTER = FRT / 'bin/flutter'
KERNEL = RT / 'test-runner/test-runner.dill'
CONFIG = REPO / '.dart_tool/package_config.json'
AUDIT_PATH = BASE / 'runtime/incoming-0a2-word-evidence-audit.json'
AUDIT_SHA = '0a030bf56e5b51080c960575230161d8123a1fe178d186a565bcabb60a923dd1'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


assert git('rev-parse', 'HEAD') == EXPECTED and not git('status', '--porcelain')
assert digest(AUDIT_PATH) == AUDIT_SHA
audit = json.loads(AUDIT_PATH.read_text())
assert audit['final_delivery_commit'] == EXPECTED
intersections = audit['historical_case_intersections']
categories = {
    'macro': dict(intersections['macro-rerun']['residual_files']),
    'native': dict(intersections['word-native-layout']['residual_files']),
    'editor-layout': dict(intersections['editor-native-layout']['residual_files']),
    'zotero-engine': dict(audit['zotero_residual_fresh_selection']['engine']['files']),
    'zotero-editor': dict(audit['zotero_residual_fresh_selection']['editor']['files']),
}
categories['native']['packages/quds_office_engine/test/word_header_picture_identity_test.dart'] = 13
assert [sum(v.values()) for v in categories.values()] == [663, 223, 96, 188, 143]
all_files = [path for group in categories.values() for path in group]
assert len(all_files) == len(set(all_files)) == 54
allowed_skips = {(str(Path('packages/quds_office_editor') / row['file']), row['name'])
    for row in intersections['editor-native-layout']['historical_skips']}
assert len(allowed_skips) == 8
for path in all_files:
    assert (REPO / path).is_file(), path
OUT.mkdir(parents=True, exist_ok=False)
for component in ['macro', 'engine', 'editor', 'format']:
    for kind in ['tmp', 'config', 'cache']:
        (OUT / (kind + '-' + component)).mkdir()


def env(component, flutter=False):
    result = dict(os.environ)
    result.update({'QUDS_VALIDATION_ROOT': str(REPO),
        'PUB_CACHE': str(FRT / 'pub-cache'), 'FLUTTER_ROOT': str(FRT / 'flutter'),
        'XDG_DATA_HOME': str(FRT / 'data'), 'TMPDIR': str(OUT / ('tmp-' + component)),
        'XDG_CONFIG_HOME': str(OUT / ('config-' + component)),
        'XDG_CACHE_HOME': str(OUT / ('cache-' + component)),
        'DART_SUPPRESS_ANALYTICS': 'true', 'FLUTTER_SUPPRESS_ANALYTICS': 'true',
        'DASH__SUPPRESS_ANALYTICS': 'true', 'CI': 'true',
        'PATH': str(FRT / 'bin' if flutter else DART.parent) + os.pathsep + os.environ['PATH']})
    return result


source_paths = git('ls-files', '--', ':(glob)packages/**/lib/**', ':(glob)packages/**/test/**',
    ':(glob)packages/**/fonts/**', ':(glob)packages/**/pubspec.yaml',
    ':(glob)packages/**/analysis_options.yaml', 'third_party/enough_mail/lib',
    'third_party/enough_mail/pubspec.yaml', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
    '.fvmrc', 'packages/quds_office_engine/tool', 'packages/quds_office_editor/tool/zotero').splitlines()
runtime_paths = [CONFIG, REPO / '.dart_tool/package_graph.json', DART, FDART, KERNEL,
    FLUTTER, FRT / 'flutter/bin/cache/flutter_tools.snapshot',
    FRT / 'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',
    DART.parent / 'snapshots/analysis_server_aot.dart.snapshot',
    FRT / 'runtime.json', RT / 'environment.json', AUDIT_PATH,
    BASE / 'runtime/quds-delivery-runtime-mapping.json',
    BASE / 'runtime/quds-delivery-native-assets.json',
    BASE / 'quds_final_integration/.dart_tool/package_config.json',
    BASE / 'quds_final_integration/.dart_tool/package_graph.json', Path(__file__)]


def source_snapshot():
    return {path: digest(REPO / path) for path in source_paths}


def runtime_snapshot():
    return {str(path): digest(path) for path in runtime_paths if path.exists()}


before, runtime_before = source_snapshot(), runtime_snapshot()
write('source-before.json', before)
write('runtime-before.json', runtime_before)
write('incoming-retention-audit.json', audit)
write('fresh-selection.json', categories)
report = {'started_utc': now(), 'source_head': EXPECTED, 'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'incoming_audit_sha256': AUDIT_SHA, 'source_files_hashed': len(before),
    'selection': categories, 'expected_editor_exclusions': [dict(file=p, name=n, reason='no paragraphs to edit') for p, n in sorted(allowed_skips)],
    'retained_scope': {'word_vm': {'passed': 946, 'files': 25, 'excluded_superseded_style_cases': 15},
        'word_node': {'passed': 758, 'files': 7}, 'fonts': {'passed': 9, 'files': 1},
        'zotero_engine': {'passed': 282, 'files': 6}, 'zotero_editor': {'passed': 114, 'files': 2}},
    'retention_note': 'Retained results are the independently audited incoming executions with explicit source/dependency bounds. They are not fresh executions on this local runtime. No cross-scope grand total is asserted.',
    'commands': [], 'test_groups': {}, 'fresh_categories': {},
    'dart_version': subprocess.check_output([DART, '--version'], text=True).strip(),
    'editor_dart_version': subprocess.check_output([FDART, '--version'], text=True).strip()}
lock = threading.Lock()


def run(name, command, cwd, environment):
    print('Starting ' + name, flush=True)
    start, started = time.monotonic(), now()
    stdout, stderr = OUT / (name + '.stdout.log'), OUT / (name + '.stderr.log')
    with stdout.open('w') as out, stderr.open('w') as err:
        result = subprocess.run([str(arg) for arg in command], cwd=cwd, env=environment, stdout=out, stderr=err)
    row = {'name': name, 'command': [str(arg) for arg in command], 'cwd': str(cwd),
        'started_utc': started, 'finished_utc': now(), 'exit_code': result.returncode,
        'seconds': round(time.monotonic() - start, 3), 'stdout': stdout.name,
        'stdout_sha256': digest(stdout), 'stderr': stderr.name, 'stderr_sha256': digest(stderr)}
    with lock:
        report['commands'].append(row)
        write('progress.json', report)
    print(f'Finished {name}: exit {result.returncode}', flush=True)
    if name == 'macro-tests':
        prefixes = ('arguments-cli-', 'vba-cli-test-', 'macro-cli-test-', 'macro-mcp-test-')
        remaining = [str(path.relative_to(REPO)) for path in ENGINE.iterdir()
            if path.is_dir() and path.name.startswith(prefixes)]
        write('macro-cleanup.json', {'finished_utc': now(), 'remaining_owned_cli_directories': remaining,
            'command_exit': result.returncode, 'cleanup_complete': not remaining})
        print('Macro CLI fixture cleanup: ' + ('complete' if not remaining else repr(remaining)), flush=True)
    return row


def parse(group, selected):
    command = next(row for row in report['commands'] if row['name'] == group)
    events = []
    for line in (OUT / command['stdout']).read_text().splitlines():
        if line.startswith('{'):
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    suites = {}
    for event in events:
        if event.get('type') == 'suite':
            path = Path(event['suite']['path'])
            path = path.resolve() if path.is_absolute() else (Path(command['cwd']) / path).resolve()
            suites[event['suite']['id']] = str(path.relative_to(REPO))
    starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    completions = [e for e in events if e.get('type') == 'testDone']
    done_ids = collections.Counter(e['testID'] for e in completions)
    occurrences = collections.Counter()
    cases = []
    for event in completions:
        if event.get('hidden'):
            continue
        test = starts[event['testID']]
        file = suites[test['suiteID']]
        occurrences[(file, test['name'])] += 1
        cases.append({'file': file, 'name': test['name'], 'occurrence': occurrences[(file, test['name'])],
            'result': event['result'], 'skipped': bool(event.get('skipped'))})
    write(group + '-cases.json', cases)
    passed = collections.Counter(row['file'] for row in cases if row['result'] == 'success' and not row['skipped'])
    skips = {(row['file'], row['name']) for row in cases if row['skipped']}
    expected_skips = allowed_skips if group == 'editor-tests' else set()
    status = {'passed': sum(passed.values()), 'failed': sum(row['result'] != 'success' for row in cases),
        'skipped': sum(row['skipped'] for row in cases), 'per_file_passed': dict(passed),
        'all_selected_files_executed': set(passed) == set(selected),
        'exact_expected_per_file_populations': dict(passed) == dict(selected),
        'exact_expected_exclusions': skips == expected_skips,
        'every_started_test_completed_once': set(starts) == set(done_ids) and all(n == 1 for n in done_ids.values()),
        'case_identities_unique': len({(r['file'], r['name'], r['occurrence']) for r in cases}) == len(cases),
        'reporter_errors': sum(e.get('type') == 'error' for e in events),
        'terminal_success': bool(events and events[-1].get('type') == 'done' and events[-1].get('success') is True)}
    return status, cases


macro = categories['macro']
engine_other = {**categories['native'], **categories['zotero-engine']}
editor = {**categories['editor-layout'], **categories['zotero-editor']}
prefix = [DART, '--old_gen_heap_size=768', f'--packages={CONFIG}', KERNEL,
    '--compiler', 'source', '--concurrency=1', '--timeout=4x', '--reporter=json']
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    jobs = [
        pool.submit(run, 'macro-tests', prefix + [str((REPO / p).relative_to(ENGINE)) for p in macro], ENGINE, env('macro')),
        pool.submit(run, 'native-zotero-engine-tests', prefix + [str((REPO / p).relative_to(ENGINE)) for p in engine_other], ENGINE, env('engine')),
        pool.submit(run, 'editor-tests', [FLUTTER, 'test', '--no-pub', '--concurrency=1', '--machine',
            *[str((REPO / p).relative_to(EDITOR)) for p in editor]], EDITOR, env('editor', True)),
    ]
    for job in jobs:
        job.result()
all_cases = []
for group, selected in [('macro-tests', macro), ('native-zotero-engine-tests', engine_other), ('editor-tests', editor)]:
    status, cases = parse(group, selected)
    report['test_groups'][group] = status
    all_cases.extend(cases)
for category, selected in categories.items():
    cases = [row for row in all_cases if row['file'] in selected]
    write(category + '-cases.json', cases)
    report['fresh_categories'][category] = {'passed': sum(r['result'] == 'success' and not r['skipped'] for r in cases),
        'failed': sum(r['result'] != 'success' for r in cases), 'skipped': sum(r['skipped'] for r in cases), 'files': len(selected)}
editor_analysis = sorted(set(editor) | {
    'packages/quds_office_editor/test/office_system_fonts_test.dart',
    'packages/quds_office_editor/tool/zotero/research_target_acceptance.dart'})
format_paths = sorted(set(git('diff', '--name-only', '80e240ec1f557c1ac7c170a8273de41dfaac0f20', 'HEAD', '--',
    'packages/quds_office_engine', 'packages/quds_office_editor/lib', 'packages/quds_office_editor/test',
    'packages/quds_office_editor/tool/zotero').splitlines()))
format_paths = [path for path in format_paths if path.endswith('.dart')]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    jobs = [pool.submit(run, 'engine-analysis', [DART, 'analyze', '--fatal-infos'], ENGINE, env('engine')),
        pool.submit(run, 'editor-analysis', [FDART, 'analyze', '--fatal-infos',
            *[str((REPO / p).relative_to(EDITOR)) for p in editor_analysis]], EDITOR, env('editor', True))]
    for job in jobs:
        job.result()
run('format', [FDART, 'format', '--output=none', '--set-exit-if-changed', *format_paths], REPO, env('format', True))
after, runtime_after = source_snapshot(), runtime_snapshot()
write('source-after.json', after)
write('runtime-after.json', runtime_after)
report['source_unchanged'] = before == after
report['runtime_unchanged'] = runtime_before == runtime_after
report['head_unchanged'] = EXPECTED == git('rev-parse', 'HEAD')
report['worktree_clean'] = not git('status', '--porcelain')
report['success'] = all(row['exit_code'] == 0 for row in report['commands']) and all(
    group['failed'] == group['reporter_errors'] == 0 and all(group[key] for key in
    ['all_selected_files_executed', 'exact_expected_per_file_populations', 'exact_expected_exclusions',
     'every_started_test_completed_once', 'case_identities_unique', 'terminal_success'])
    for group in report['test_groups'].values()) and all(report[key] for key in
    ['source_unchanged', 'runtime_unchanged', 'head_unchanged', 'worktree_clean'])
report['success_scope'] = 'Audited residual cohorts with exactly eight predeclared no-editable-paragraph editor exclusions. Exclusions are not counted as passes. Retained incoming results remain separately source/runtime attributed.'
report['finished_utc'] = now()
write('qualification.json', report)
print(json.dumps({'success': report['success'], 'fresh_categories': report['fresh_categories'],
    'source_unchanged': report['source_unchanged'], 'runtime_unchanged': report['runtime_unchanged']}), flush=True)
raise SystemExit(0 if report['success'] else 1)
