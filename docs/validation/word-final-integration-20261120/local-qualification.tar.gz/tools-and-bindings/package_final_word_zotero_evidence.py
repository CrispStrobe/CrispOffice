#!/usr/bin/env python3
"""Package sealed final Word/Zotero results in scratch; never edit the checkout."""
import collections
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

BASE = Path('/workspace/scratch/03cd41fa0e7e')
RUNTIME = BASE / 'runtime'
REPO = BASE / 'quds_delivery'
RUN = RUNTIME / 'word-zotero-delivery-qualification'
OUT = RUNTIME / 'word-final-integration-package'
ATTEMPT = RUNTIME / 'zotero-attempt-80e240ec-package'
HEAD = 'c62338c65571aa399da5592455b651fa5c6a9317'
TREE = 'd8e43e6f43b0726e8fefded52c185e387291916d'
AUDIT_SHA = '0a030bf56e5b51080c960575230161d8123a1fe178d186a565bcabb60a923dd1'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def data(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def load(path):
    return json.loads(Path(path).read_text())


receipt = load(RUN / 'qualification.json')
audit = load(RUNTIME / 'incoming-0a2-word-evidence-audit.json')
assert receipt['success'] is True and receipt['source_head'] == HEAD
assert receipt['source_tree'] == TREE and audit['final_delivery_commit'] == HEAD
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert sha((RUNTIME / 'incoming-0a2-word-evidence-audit.json').read_bytes()) == AUDIT_SHA
assert all(receipt[key] for key in ['source_unchanged', 'runtime_unchanged', 'head_unchanged', 'worktree_clean'])
for name, expected in [('macro', 663), ('native', 223), ('editor-layout', 96), ('zotero-engine', 188), ('zotero-editor', 143)]:
    assert receipt['fresh_categories'][name]['passed'] == expected
    assert receipt['fresh_categories'][name]['failed'] == 0
assert receipt['fresh_categories']['editor-layout']['skipped'] == 8
assert sum(row['skipped'] for row in receipt['fresh_categories'].values()) == 8
assert load(RUN / 'macro-cleanup.json')['cleanup_complete']
source_seal = load(RUN / 'source-before.json')
compiler_path = 'packages/quds_office_engine/lib/src/automation/office_vba_language.dart'
assert source_seal[compiler_path] == '41de865411b884d18c1097e9a80d68cd6bf1fb245e1844a46f72af05636f5ecd'
independent_final_path = RUNTIME / 'delivery-word-final-recount.json'
assert load(independent_final_path)['source_commit'] == HEAD
OUT.mkdir(exist_ok=False)

members = {}
for path in sorted(RUN.iterdir()):
    if path.is_file() and path.suffix in ('.json', '.log'):
        members['fresh/' + path.name] = path.read_bytes()
for filename in ['qualify_delivery_word_zotero.py', 'audit_incoming_0a2_word_evidence.py',
                 'incoming-0a2-word-evidence-audit.json', 'quds-delivery-runtime-mapping.json',
                 'quds-delivery-native-assets.json']:
    members['tools-and-bindings/' + filename] = (RUNTIME / filename).read_bytes()
for path in sorted(ATTEMPT.iterdir()):
    if path.is_file():
        members['historical-80e240ec-attempt/' + path.name] = path.read_bytes()
for filename in ['delivery-word-partial-recount.json', 'delivery-word-final-recount.json']:
    members['independent-review/' + filename] = (RUNTIME / filename).read_bytes()
members['independent-review/audit_delivery_word_receipt.py'] = (RUNTIME / 'audit_delivery_word_receipt.py').read_bytes()
members['tools-and-bindings/' + Path(__file__).name] = Path(__file__).read_bytes()

# These DOCX fixtures were bound by the clean start/end Git tree, not the
# package-only per-file before/after capture. Make that distinction explicit.
fixture_roots = ['docs/validation/word-native-layout-20261120/reference',
                 'docs/validation/word-line-boxes-20261120/reference']
fixtures = {}
for path in git('ls-files', '--', *fixture_roots).decode().splitlines():
    current = (REPO / path).read_bytes()
    committed = git('show', HEAD + ':' + path)
    assert current == committed, path
    fixtures[path] = {'bytes': len(current), 'sha256': sha(current), 'git_bytes_equal': True}
fixture_binding = {'source_commit': HEAD,
    'binding': 'Tracked fixture bytes equal immutable Git objects; clean start/end Git tree binds their use. These files are not claimed as members of the runner package-source before/after snapshot.',
    'files': fixtures}
members['tools-and-bindings/reference-fixture-git-binding.json'] = data(fixture_binding)

retained = {}
for key, rows in [('word-vm', audit['word']['raw_results']['vm']['case_identities']),
                  ('word-node', audit['word']['raw_results']['node']['case_identities']),
                  ('font', audit['font']['raw_results']['case_identities']),
                  ('zotero-engine', audit['zotero_engine']['case_identities']),
                  ('zotero-editor', audit['zotero_editor']['raw_results']['case_identities'])]:
    counter = collections.Counter()
    retained[key] = []
    for row in rows:
        if key == 'word-vm' and row['path'].endswith('/word_styles_layout_test.dart'):
            continue
        counter[(row['path'], row['name'])] += 1
        retained[key].append({'file': row['path'], 'name': row['name'],
            'occurrence': counter[(row['path'], row['name'])], 'result': 'success', 'skipped': False,
            'evidence': 'audited-incoming-' + key})
    members['accepted-identities/retained-' + key + '.json'] = data(retained[key])
assert [len(retained[k]) for k in ['word-vm', 'word-node', 'font', 'zotero-engine', 'zotero-editor']] == [946, 758, 9, 282, 114]
fresh = {key: [dict(row, evidence='fresh-c62338c6-' + key) for row in load(RUN / (key + '-cases.json'))]
    for key in receipt['fresh_categories']}
macro_overlap_files = set(audit['historical_case_intersections']['macro-rerun']['overlap_files'])
unions = {
    'affected-macro-runtime': fresh['macro'] + [r for r in retained['word-vm'] if r['file'] in macro_overlap_files],
    'word-native-layout': fresh['native'] + [r for r in retained['word-vm'] if not Path(r['file']).name.startswith('office_')],
    'editor-layout-and-fonts': fresh['editor-layout'] + retained['font'],
    'zotero-engine': fresh['zotero-engine'] + retained['zotero-engine'],
    'zotero-editor': fresh['zotero-editor'] + retained['zotero-editor'],
}
union_summary = {}
for key, rows in unions.items():
    assert len({(r['file'], r['name'], r['occurrence']) for r in rows}) == len(rows), key
    union_summary[key] = {'passed': sum(not r['skipped'] for r in rows),
        'skipped': sum(r['skipped'] for r in rows), 'files': len({r['file'] for r in rows}),
        'fresh_passed': sum(not r['skipped'] and r['evidence'].startswith('fresh-') for r in rows),
        'retained_passed': sum(not r['skipped'] and r['evidence'].startswith('audited-') for r in rows)}
    members['accepted-identities/' + key + '.json'] = data(rows)
assert [(union_summary[k]['passed'], union_summary[k]['files']) for k in unions] == [(709, 23), (398, 32), (105, 5), (470, 14), (257, 9)]
prior_macro_path = RUNTIME / 'word-main-qualification/macro-rerun-cases.json'
prior_overlap_path = RUNTIME / 'word-main-qualification/macro-case-overlap.json'
prior_macro, prior_overlap = load(prior_macro_path), load(prior_overlap_path)
assert sha(prior_macro_path.read_bytes()) == prior_overlap['fresh_macro_case_file_sha256']
prior_macro_ids = {(str(Path('packages/quds_office_engine') / r['file']), r['name'], r['occurrence']) for r in prior_macro}
final_macro_ids = {(r['file'], r['name'], r['occurrence']) for r in unions['affected-macro-runtime']}
assert prior_macro_ids == final_macro_ids and len(final_macro_ids) == 709
assert prior_overlap['all_fresh_macro_cases_are_prior_accepted_cases']
members['historical-macro-identity/prior-709-cases.json'] = prior_macro_path.read_bytes()
members['historical-macro-identity/prior-3598-overlap-proof.json'] = prior_overlap_path.read_bytes()
members['historical-macro-identity/final-union-proof.json'] = data({
    'source_commit': HEAD, 'cases': 709, 'exact_prior_709_identity_set': True,
    'prior_709_sha256': sha(prior_macro_path.read_bytes()),
    'historical_3598_corpus_sha256': prior_overlap['prior_accepted_corpus_sha256'],
    'source_attribution': '663 fresh cases and 46 independently audited incoming cases; no count added to historical corpus.'})

archive_refs = []
for row in audit['archives']:
    archive = (REPO / row['path']).read_bytes()
    assert len(archive) == row['bytes'] and sha(archive) == row['sha256']
    archive_refs.append(dict(row, copied_into_this_archive=False))
portable = {}
for key, row in audit['word']['portable'].items():
    assert sha((REPO / row['bas_path']).read_bytes()) == row['bas_sha256']
    assert row['vm_node_json_equal']
    portable[key] = {'bas_path': row['bas_path'], 'bas_sha256': row['bas_sha256'],
        'equal_vm_and_node_results': True, 'evidence': 'audited incoming execution',
        'operations': row['result']['example']['operations']}
failed_attempt = load(ATTEMPT / 'qualification.json')
assert failed_attempt['success'] is False
summary = {
    'schema_version': 1, 'accepted': True, 'source_commit': HEAD, 'source_tree': TREE,
    'finished_utc': receipt['finished_utc'],
    'scope': 'Fresh bounded residual execution plus independently audited incoming results, with eight named editor exclusions. No aggregate count across overlapping runtime/compiler/platform populations.',
    'fresh': receipt['fresh_categories'], 'retained': receipt['retained_scope'],
    'accepted_unions': union_summary, 'editor_exclusions': receipt['expected_editor_exclusions'],
    'historical_macro_population': {'cases': 3598, 'suites': 69, 'affected_runtime_subset': 709,
        'fresh_affected_subset': 663, 'retained_affected_subset': 46,
        'exact_709_historical_identity_set_verified': True,
        'add_reruns_or_node_results_to_historical_total': False},
    'strict_checks': {row['name']: {'exit_code': row['exit_code'], 'command': row['command'],
        'cwd': row['cwd'], 'stdout_sha256': row['stdout_sha256'], 'stderr_sha256': row['stderr_sha256']}
        for row in receipt['commands'] if row['name'] in ('engine-analysis', 'editor-analysis', 'format')},
    'source_binding': {'captured_source_files': receipt['source_files_hashed'],
        'source_runtime_head_unchanged': True, 'start_end_clean_tree': True,
        'compiler_sha256': source_seal[compiler_path],
        'compiler_unchanged_from_historical_macro_corpus': True,
        'incoming_word_production': {p: source_seal[p] for p in [
            'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
            'packages/quds_office_engine/lib/src/word/serial/word_deserializer.dart']},
        'reference_fixtures_bound_separately_to_git': len(fixtures),
        'fixture_manifest': 'archive:tools-and-bindings/reference-fixture-git-binding.json'},
    'runtimes': {'fresh_engine': receipt['dart_version'], 'fresh_editor_dart': receipt['editor_dart_version'],
        'fresh_flutter': '3.47.8', 'incoming_runtime_limit': audit['runtime_limit']},
    'incoming_audit_sha256': AUDIT_SHA, 'incoming_archive_references': archive_refs,
    'independent_final_recount': {'path': 'archive:independent-review/delivery-word-final-recount.json',
        'sha256': sha(independent_final_path.read_bytes())},
    'incoming_retention_limits': {'word': audit['word']['retention_limits'],
        'editor': audit['zotero_editor']['retention_limit'],
        'word_source_comparison': audit['word']['final_delivery_comparison'],
        'zotero_engine_source_comparison': audit['zotero_engine']['source_comparison'],
        'zotero_editor_source_comparison': audit['zotero_editor']['source_comparison_to_final_delivery'],
        'font_source_comparison': audit['font']['source_comparison']},
    'actual_bas_portable_examples': portable,
    'historical_80e240ec_attempt': {'source_commit': '80e240ec1f557c1ac7c170a8273de41dfaac0f20',
        'accepted': False, 'engine_passed': 470, 'editor_passed': 257,
        'collector_interruption': 'Both test commands succeeded; the initial collector resolved relative suite paths against the wrong cwd. The preserved continuation recounted original events using each command cwd without rerunning tests.',
        'remaining_failed_gate': 'Fatal-info engine analysis found curly_braces_in_flow_control_structures in zotero_citing_test.dart. Incoming main supplies the braces correction.',
        'archive': 'archive:historical-80e240ec-attempt/attempt-evidence.tar.gz'},
    'limitations': ['Eight image-only editing-equivalence fixtures have no editable paragraphs and remain excluded.',
        'Incoming retained executions used their archived runtime; they are not relabeled as fresh local runs.',
        'No installed Microsoft Word COM host or external Zotero/Word/LibreOffice acceptance was executed.',
        'No cryptographic DOCM signature validity after edits is claimed; existing edited w:ind group ownership remains unchanged.',
        'The historical macro corpus is not a new whole-corpus rerun. Mail is qualified in its separate report.'],
}

readme = '''# Final Word and Zotero integration qualification — 2026-11-20

The bounded Word/Zotero qualification is accepted at published commit
`c62338c65571aa399da5592455b651fa5c6a9317`, tree
`d8e43e6f43b0726e8fefded52c185e387291916d`. The [accepted summary](accepted-summary.json)
and [fresh receipt](qualification.json) distinguish new executions from incoming
results whose raw events and exact source inputs were independently audited.
Eight explicitly named editor exclusions remain exclusions, not passes.

## Source and integration decisions

This checkpoint reconciles incoming main
`0a2afc41bae4e719b77657a7e2d8d3e7ec02849b` with the earlier qualified Word/Mail
work. The final `word_layout.dart` and `word_deserializer.dart` are byte-identical
to that incoming main. They preserve inline header pictures, use actual
`WmlVisual` node identity and placement for duplicate projections, and include
incoming table/style and native fidelity corrections. The 13-case identity
suite distinguishes two projections of one node from distinct nodes that
share an image asset at the same position. Our 17-case style suite retains
the explicit color and bold-off regressions; the 41-case contained-text suite
retains the 31.2-point inner-content fixture and its exact glyph/roundtrip checks.

The historical VBA compiler remains unchanged. Incoming main also contains
the missing braces in the Zotero protocol test that blocked the earlier
strict-analysis attempt. The qualified Mail union has its own result package;
Mail cases are not counted here.

## Fresh results at the published checkpoint

| Fresh scope | Passing cases | Files | Exclusions |
| --- | ---: | ---: | ---: |
| Affected macro/runtime/CLI/MCP residual | 663 | 19 | 0 |
| Word native/layout residual | 223 | 16 | 0 |
| Editor layout consumers | 96 | 4 | 8 named no-paragraph cases |
| Zotero engine residual | 188 | 8 | 0 |
| Zotero editor residual | 143 | 7 | 0 |

All three test commands exited successfully with successful terminal reporter
events, exact expected file populations, and every started test completed
once. The whole engine strict analyzer and the selected editor tests/tools
analyzer passed with fatal infos enabled. Formatting was checked without
writing files. The receipt records exact commands, working directories,
durations, stdout/stderr hashes, runtime binaries and source seals.

The engine tests used Dart 3.14.1 and the pinned package:test runner. Editor
tests used Flutter 3.47.8 with Dart 3.13.7. Fresh tests read the pinned workspace
configuration without dependency resolution or shared SDK/cache changes.
Each command used a separate receipt-local temporary directory. CLI-created
fixture directories in the engine package were removed by normal test teardown.

## Retained incoming results and source boundaries

| Audited incoming scope | Retained passes | Files | Treatment |
| --- | ---: | ---: | --- |
| Word VM | 946 | 25 | The incoming 15-case style suite is superseded by our fresh 17-case suite |
| Word Node/dart2js | 758 | 7 | Separate platform execution; overlaps VM/compiler populations |
| Font loader | 9 | 1 | Includes the two new actual lowercase filename-alias fixtures |
| Zotero engine | 282 | 6 | 234 unchanged cases plus the superseding 48-case protocol rerun |
| Zotero editor | 114 | 2 | Exact relevant editor inputs; unrelated Mail changes explicitly excluded |

The frozen [incoming audit](incoming-retention-audit.json) verified 191 archive
members across the two incoming archives, all recorded member hashes, raw
terminal events and complete case identities. These executions retain their
original Dart 3.13.7/runtime attribution. They are not described as new runs on
our Dart 3.14.1 engine runtime.

The incoming Word evidence binds 492 tracked inputs to its executed Git
source. At the final checkpoint the differences are four Zotero helpers and
our expanded style test. The style test is rerun in full. The four helpers
serve citation/session/note operations, with no changed callers in the macro
and layout paths covered by the retained Word cohort; their Zotero behavior
is separately covered by the incoming publication evidence and fresh residuals.
All 430 tracked inputs of the retained Zotero engine scope match the final
source. All 27 font inputs match. The broader 1,010-input Zotero editor seal
differs only in four Mail implementation files. The editor library and relevant
Zotero tests/support have no references to those Mail implementations, and Mail
is separately qualified. Every difference and its hashes are in the audit.

The verified incoming archives remain in their original repository paths:

- `../mail-bulk-actions-20261120/evidence-final-main.tar.gz`
- `../mail-bulk-actions-20261120/evidence-publication.tar.gz`

Their exact sizes and SHA-256 values are in the accepted summary. They are
referenced rather than duplicated here. The three actual BAS examples retain
verified byte-identical input and equal VM/optimized-JavaScript results:
`word_line_spacing.bas`, `word_measurements.bas`, and
`word_named_measurements.bas`.
The font cases use controlled fixture directories, including the lowercase
aliases; they do not establish default installed-font discovery on every
operating system.

## Case identity and counting

| Accepted scope | Identity-preserving combination | Passing cases | Files |
| --- | --- | ---: | ---: |
| Previously affected macro/runtime subset | 663 fresh + 46 retained | 709 | 23 |
| Native/layout union | 223 fresh + 175 retained | 398 | 32 |
| Editor layout and fonts | 96 fresh + 9 retained | 105 | 5 |
| Zotero engine selection | 188 fresh + 282 retained | 470 | 14 |
| Zotero editor selection | 143 fresh + 114 retained | 257 | 9 |

The archive contains every case identity, source attribution, and occurrence
number for these unions. The native union includes the incoming new header,
table-style, border/style identity suites and the two added distinct-node
identity regressions. Its 398 cases replace the earlier narrower 312-case
native scope; they are not an additional 398 cases to add to it.

The 709 macro identities belong to the historical 3,598-case/69-suite macro
corpus. Neither these reruns, the retained compiler suites, nor the 758 Node
results are added to that historical total. This report makes no aggregate
count across the overlapping VM, Node, compiler, native and editor populations.

## Eight explicit editor exclusions

All eight are in `word_incremental_layout_equivalence_test.dart`, with exact
reason **`no paragraphs to edit`**. Their case-name prefix is
`incremental layout equals full layout fixture ` followed by the paths below.
These image-only fixtures provide no editable paragraphs for this harness;
the fixtures and expectations were not changed.

'''
for row in receipt['expected_editor_exclusions']:
    readme += '- `' + row['name'].removeprefix('incremental layout equals full layout fixture ') + '`\n'
readme += '''
## Source/runtime seals and external fixtures

The fresh runner's captured package source inputs, runtime binaries, package
configuration, immutable audit and old-worktree configuration matched before
and after execution. HEAD stayed at the published source, and the tree was
clean at both boundaries. The two tracked reference-fixture directories under
`docs/validation/word-native-layout-20261120/reference` and
`docs/validation/word-line-boxes-20261120/reference` were bound by that clean
Git tree, rather than by the package-only per-file seal. A separate manifest
in the archive compares every file in those directories byte-for-byte with
the immutable c62338c6 Git objects; it does not relabel them as before/after
snapshot members.

## Preserved earlier failed attempt

The nested `historical-80e240ec-attempt` evidence preserves the source
`80e240ec1f557c1ac7c170a8273de41dfaac0f20` attempt. Its 470 engine and 257 editor
cases passed, but the original collector then used the wrong working directory
to resolve relative suite paths. The preserved continuation recounted the
original raw streams using each recorded command's working directory, verified
source/runtime seals and ran the remaining checks. It did not rerun those tests.

That historical receipt remains `success=false`: strict engine analysis found
`curly_braces_in_flow_control_structures` at the protocol test's single-line
conditional. Incoming main supplied the braces correction. The old successful
test events are not presented as acceptance of the old checkpoint, nor counted
again on top of the final selected populations. Both collector scripts, the
interruption record, corrected recount, raw events and source/runtime seals
are preserved inside its deterministic nested archive.

## Boundaries and reproduction

This is local source/runtime qualification, not installed Microsoft Word COM
execution or fresh external Zotero/Word/LibreOffice acceptance. Existing
DOCM opaque-part preservation checks do not certify cryptographic signatures
after modification. Existing edited `w:ind` group ownership remains unchanged.
Zotero vertical merges, nested research tables and active ODT citation transfer
remain outside the supported contracts described in the usage guide.

The [evidence archive](local-qualification.tar.gz) contains the exact runner,
commands, raw stdout/stderr, case IDs, seals, independent incoming audit,
mapping records and preserved failed attempt. It excludes SDKs, caches,
compiled test assets and transient fixtures. [The manifest](receipt-manifest.json)
binds each archive member and each top-level receipt by SHA-256 and size.

To reproduce the fresh selection with the same dependency/runtime setup, use
the exact commands and per-command cwd in `qualification.json`; engine commands
run from `packages/quds_office_engine`, editor commands from
`packages/quds_office_editor`. The archived runner has session-specific absolute
paths and an immutable expected HEAD. Reproduction elsewhere requires explicit
path remapping and a new evidence directory, not overwriting these records.
No GitHub CI result was awaited or used as a gate.
'''

top = {'README.md': readme.encode(), 'accepted-summary.json': data(summary),
       'qualification.json': (RUN / 'qualification.json').read_bytes(),
       'incoming-retention-audit.json': (RUNTIME / 'incoming-0a2-word-evidence-audit.json').read_bytes()}

def archive_bytes():
    stream = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, contents in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(contents)
                info.mode = 0o644
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                tar.addfile(info, io.BytesIO(contents))
    return stream.getvalue()

archive = archive_bytes()
assert archive == archive_bytes()
top['local-qualification.tar.gz'] = archive
manifest = {'schema_version': 1, 'source_commit': HEAD,
    'deterministic_archive': {'path': 'local-qualification.tar.gz', 'bytes': len(archive),
        'sha256': sha(archive), 'members': len(members),
        'uncompressed_member_bytes': sum(map(len, members.values())),
        'ordering': 'lexical', 'tar_mtime': 0, 'gzip_mtime': 0, 'uid': 0, 'gid': 0,
        'repeated_serialization_equal': True},
    'top_level_files': {name: {'bytes': len(content), 'sha256': sha(content)} for name, content in top.items()},
    'archive_members': {name: {'bytes': len(content), 'sha256': sha(content)} for name, content in sorted(members.items())},
    'self_exclusion': 'This manifest does not hash itself.'}
top['receipt-manifest.json'] = data(manifest)
for name, contents in top.items():
    (OUT / name).write_bytes(contents)
with tarfile.open(OUT / 'local-qualification.tar.gz', 'r:gz') as tar:
    actual = {member.name: tar.extractfile(member).read() for member in tar if member.isfile()}
assert actual == members
print(json.dumps({'package': str(OUT), 'files': {name: len(content) for name, content in top.items()},
    'archive_sha256': sha(archive), 'archive_members': len(members), 'accepted_unions': union_summary}, indent=2))
