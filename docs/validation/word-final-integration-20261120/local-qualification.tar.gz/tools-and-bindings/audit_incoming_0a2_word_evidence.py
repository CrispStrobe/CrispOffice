"""Read-only audit of incoming Word/Zotero/font evidence and Git identities."""
from pathlib import Path
from collections import Counter
import base64
import hashlib
import json
import re
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/03cd41fa0e7e/quds_delivery')
OUT = Path('/workspace/scratch/03cd41fa0e7e/runtime/incoming-0a2-word-evidence-audit.json')
DOCS = ROOT / 'docs/validation/mail-bulk-actions-20261120'
MAIN = '0a2afc41bae4e719b77657a7e2d8d3e7ec02849b'
WORD_CHECKPOINT = '039b6e97cbbc01ce1d69c0bcf982fb7147643a3e'
DELIVERY = 'c62338c65571aa399da5592455b651fa5c6a9317'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_bytes(head, path):
    return subprocess.check_output(['git', 'show', f'{head}:{path}'], cwd=ROOT)


def dump(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def archive(name):
    manifest = json.loads((DOCS / f'{name}-manifest.json').read_text())
    target = DOCS / manifest['archive']['path']
    data = target.read_bytes()
    assert sha(data) == manifest['archive']['sha256']
    assert len(data) == manifest['archive']['bytes']
    with tarfile.open(target, 'r:gz') as tar:
        content = {m.name: tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
    assert len(content) == len(manifest['members'])
    assert set(content) == {m['path'] for m in manifest['members']}
    for item in manifest['members']:
        assert sha(content[item['path']]) == item['sha256'], item['path']
        assert len(content[item['path']]) == item['bytes'], item['path']
    return content, {
        'path': str(target.relative_to(ROOT)), 'sha256': sha(data),
        'bytes': len(data), 'members_verified': len(content),
    }


def source_comparison(inputs, head):
    changed = []
    runtime_only = []
    checked = 0
    for path, expected in inputs.items():
        if path.startswith('.dart_tool/') or '/build/' in path:
            runtime_only.append(path)
            continue
        actual = sha(git_bytes(head, path))
        checked += 1
        if actual != expected:
            changed.append({'path': path, 'expected': expected, 'actual': actual})
    return {'tracked_checked': checked, 'changes': changed, 'runtime_only': runtime_only}


def normalize_path(path, cwd):
    if '/quds_office_suite/' in path:
        return path.split('/quds_office_suite/', 1)[1]
    if path.startswith('packages/'):
        return path
    if '/packages/' in cwd:
        cwd = 'packages/' + cwd.split('/packages/', 1)[1]
    return str(Path(cwd) / path)


def json_cases(data, cwd):
    events = [json.loads(line) for line in data.splitlines() if line.strip()]
    suites = {e['suite']['id']: e['suite'] for e in events if e.get('type') == 'suite'}
    tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    completions = [e for e in events if e.get('type') == 'testDone']
    assert len(completions) == len(tests)
    assert len({e['testID'] for e in completions}) == len(completions)
    assert not any(e.get('type') == 'error' for e in events)
    terminal = [e for e in events if e.get('type') == 'done']
    assert len(terminal) == 1 and terminal[0]['success'] is True
    selected = [e for e in completions if not e.get('hidden', False)]
    assert all(e['result'] == 'success' and not e['skipped'] for e in selected)
    cases = [
        {'path': normalize_path(suites[tests[e['testID']]['suiteID']]['path'], cwd),
         'name': tests[e['testID']]['name']}
        for e in selected
    ]
    assert len({(c['path'], c['name']) for c in cases}) == len(cases)
    return {'passed': len(cases), 'failed': 0, 'skipped': 0,
            'per_file': dict(Counter(c['path'] for c in cases)),
            'case_identities': cases, 'terminal_success': True}


def checked_json_command(content, command, prefix):
    for stream in ['stdout', 'stderr']:
        assert sha(content[prefix + command[stream]]) == command[stream + '_sha256']
    assert command['exit_code'] == 0
    return json_cases(content[prefix + command['stdout']], command['cwd'])


final, final_integrity = archive('evidence-final-main')
publication, publication_integrity = archive('evidence-publication')
word = json.loads((DOCS / 'final-main-word-validation.json').read_text())
assert word['source_sha256_before'] == word['source_sha256_after']
assert word['status'] == 'PASS' and word['source_unchanged']
assert not source_comparison(word['source_sha256_before'], word['initial_head'])['changes']
word_results = {}
for command in word['commands']:
    for stream in ['stdout', 'stderr']:
        assert sha(final['validation/' + command[stream]]) == command[stream + '_sha256']
    assert command['exit_code'] == 0 and command['accepted']
    if command['label'] in ['vm', 'node']:
        word_results[command['label']] = checked_json_command(final, command, 'validation/')
        assert word_results[command['label']]['passed'] == command['tests']['passed']

portable = {}
for label, filename in [('line_spacing', 'word_line_spacing'),
                        ('measurements', 'word_measurements'),
                        ('named_measurements', 'word_named_measurements')]:
    command = next(c for c in word['commands'] if c['label'] == label + '-portable-vm')
    node = next(c for c in word['commands'] if c['label'] == label + '-portable-node')
    define = next(a for a in command['command'] if a.startswith('-D'))
    bas = base64.b64decode(define.split('=', 1)[1])
    path = f'packages/quds_office_engine/example/macros/{filename}.bas'
    assert bas == git_bytes(MAIN, path) == git_bytes(WORD_CHECKPOINT, path) == git_bytes(DELIVERY, path)
    vm_result = json.loads(final['validation/' + command['stdout']])
    node_result = json.loads(final['validation/' + node['stdout']])
    assert vm_result == node_result
    portable[label] = {'bas_path': path, 'bas_sha256': sha(bas),
                       'vm_node_json_equal': True, 'result': vm_result}

font = json.loads(final['runtime/records/final-main-font-receipt.json'])
assert font['inputs'] == font['inputs_after'] and font['success']
for step in font['steps']:
    assert step['exit_code'] == 0
    for stream in ['stdout', 'stderr']:
        assert sha(final['runtime/records/' + step[stream]]) == step[stream + '_sha256']
font_tests = checked_json_command(final, next(s for s in font['steps'] if s['name'] == 'tests'), 'runtime/records/')
assert font_tests['passed'] == 9
font_comparison = source_comparison(font['inputs'], DELIVERY)
assert not font_comparison['changes']
assert sha(final['configuration/.dart_tool/package_config.json']) == font['inputs']['.dart_tool/package_config.json']

engine_initial = json.loads(publication['history/runtime/records/publication-zotero-engine-validation-receipt.json'])
engine = json.loads(publication['runtime/records/publication-zotero-engine-followup-receipt.json'])
assert engine_initial['source_before'] == engine_initial['source_after']
assert engine['source_before'] == engine['source_after']
assert engine['all_passed'] and not engine_initial['all_passed']
assert engine['initial_receipt_sha256'] == sha(publication['history/runtime/records/publication-zotero-engine-validation-receipt.json'])
engine_comparison = source_comparison(engine['source_before'], DELIVERY)
assert not engine_comparison['changes']
engine_cases = []
followup_cases = []
for receipt, prefix, expected, container in [
    (engine_initial, 'history/runtime/records/', 282, engine_cases),
    (engine, 'runtime/records/', 48, followup_cases),
]:
    for command in receipt['commands']:
        raw = publication[prefix + Path(command['raw_log']).name]
        assert sha(raw) == command['log_sha256']
        if 'tests-vm' not in command['name']:
            continue
        assert command['exit_code'] == 0
        lines = raw.decode().splitlines()
        assert lines[-1].endswith(f'+{expected}: All tests passed!')
        observed_indices = []
        for line in lines:
            if not line.strip():
                continue
            match = re.match(r'^\d+:\d+ \+(\d+): (.*)$', line)
            assert match, line
            index, detail = int(match[1]), match[2]
            if detail.startswith('loading ') or detail == 'All tests passed!':
                continue
            observed_indices.append(index)
            if ': ' in detail and detail.startswith('test/'):
                path, name = detail.split(': ', 1)
            else:
                path, name = 'test/zotero_citing_test.dart', detail
            container.append({'path': normalize_path(path, command['cwd']), 'name': name})
        assert observed_indices == list(range(expected))
        assert len({(c['path'], c['name']) for c in container}) == expected
protocol_path = 'packages/quds_office_engine/test/zotero_citing_test.dart'
assert [c for c in engine_cases if c['path'] == protocol_path] == followup_cases

editor = json.loads(publication['runtime/records/publication-editor-receipt.json'])
assert editor['inputs'] == editor['inputs_after'] and editor['success']
for step in editor['steps']:
    assert step['exit_code'] == 0
    for stream in ['stdout', 'stderr']:
        assert sha(publication['runtime/records/' + step[stream]]) == step[stream + '_sha256']
editor_cases = checked_json_command(publication, next(s for s in editor['steps'] if s['name'] == 'tests'), 'runtime/records/')
assert editor_cases['passed'] == 114

report = {
    'purpose': 'Independent read-only archive, raw-event, BAS and immutable Git identity audit; no tests executed by this audit.',
    'incoming_main': MAIN, 'published_word_checkpoint': WORD_CHECKPOINT,
    'final_delivery_commit': DELIVERY,
    'audit_script_sha256': sha(Path(__file__).read_bytes()),
    'archives': [final_integrity, publication_integrity],
    'word': {
        'receipt': 'docs/validation/mail-bulk-actions-20261120/final-main-word-validation.json',
        'receipt_sha256': sha((DOCS / 'final-main-word-validation.json').read_bytes()),
        'accepted_working_source_matches_git': word['initial_head'],
        'source_inputs': len(word['source_sha256_before']),
        'main_comparison': source_comparison(word['source_sha256_before'], MAIN),
        'checkpoint_comparison': source_comparison(word['source_sha256_before'], WORD_CHECKPOINT),
        'final_delivery_comparison': source_comparison(word['source_sha256_before'], DELIVERY),
        'raw_results': word_results, 'portable': portable,
        'retention_limits': [
            'Four changed Zotero helpers are limited to citation/session/note-specific operations and are independently qualified in the publication receipts; they do not alter the macro/layout entrypoints used by the Word cohort.',
            'The current word_styles_layout_test.dart preserves two additional direct-format fixtures; rerun its entire17case suite rather than relabeling the incoming15case suite.',
            'The current13case identity suite and41case contained-text suite require fresh combined-source validation.',
            'VM961 and Node758 overlap; neither is a new count to add to historical accepted macro populations.',
        ],
    },
    'font': {'source_comparison': font_comparison, 'raw_results': font_tests,
             'archived_package_config_hash_verified': True,
             'scope': 'Nine loader tests including two real font alias/precedence cases. No installed Microsoft fonts or browser/WASM claim.'},
    'zotero_engine': {
        'source_comparison': engine_comparison,
        'initial_false_receipt_preserved': True,
        'initial282case_logs_verified': True,
        'followup48same_case_names_after_braces_verified': True,
        'accepted_count': 282, 'per_file': dict(Counter(c['path'] for c in engine_cases)),
        'case_identities': engine_cases,
        'consolidation': '234 unchanged cases plus48 superseding protocol cases, not330.',
    },
    'zotero_editor': {
        'source_comparison_to_main': source_comparison(editor['inputs'], MAIN),
        'source_comparison_to_word_checkpoint': source_comparison(editor['inputs'], WORD_CHECKPOINT),
        'source_comparison_to_final_delivery': source_comparison(editor['inputs'], DELIVERY),
        'raw_results': editor_cases,
        'retention_limit': 'The comparison manifest is intentionally broader than the two Zotero suites. Any Mail-only differences must remain separately qualified; editor library and Zotero test/support files have no quds_mail or studio_mail references.',
    },
    'runtime_limit': 'Incoming execution used its archived Dart3.13.7/package configuration. This audit verifies the archived configuration and immutable source; it is not a new execution on the local Dart3.14.1 environment.',
}
incoming_word_cases = {(c['path'], c['name']) for c in word_results['vm']['case_identities']}
incoming_font_cases = {(c['path'], c['name']) for c in font_tests['case_identities']}
intersections = {}
for group, package, incoming in [
    ('macro-rerun', 'quds_office_engine', incoming_word_cases),
    ('word-native-layout', 'quds_office_engine', incoming_word_cases),
    ('editor-native-layout', 'quds_office_editor', incoming_font_cases),
]:
    baseline_file = Path('/workspace/scratch/03cd41fa0e7e/runtime/word-main-qualification') / (group + '-cases.json')
    baseline = json.loads(baseline_file.read_text())
    cases = [(f'packages/{package}/' + c['file'], c['name']) for c in baseline if not c['skipped']]
    exact = [c for c in cases if c in incoming and c[0] != 'packages/quds_office_engine/test/word_styles_layout_test.dart']
    residual = [c for c in cases if c not in exact]
    intersections[group] = {
        'historical_population': len(cases),
        'incoming_exact_case_overlap_excluding_currently_expanded_style_file': len(exact),
        'overlap_files': dict(Counter(c[0] for c in exact)),
        'residual_count_before_identity_fixture_expansion': len(residual),
        'residual_files': dict(Counter(c[0] for c in residual)),
        'historical_skips': [c for c in baseline if c['skipped']],
    }
report['historical_case_intersections'] = intersections
zotero_baseline = json.loads(Path('/workspace/scratch/03cd41fa0e7e/runtime/zotero-main-qualification/qualification.json').read_text())
report['zotero_residual_fresh_selection'] = {}
for group, covered in [('engine', set(c['path'] for c in engine_cases)),
                       ('editor', set(editor_cases['per_file']))]:
    original = zotero_baseline['test_groups'][group]['per_file']
    residual = {path: values['passed'] for path, values in original.items() if path not in covered}
    report['zotero_residual_fresh_selection'][group] = {
        'files': residual, 'count': sum(residual.values()),
        'reason': 'These existing Zotero families execute the changed Word layout/deserializer but lack exact-source coverage in the audited incoming publication cohorts.',
    }
dump(OUT, report)
print(json.dumps({'output': str(OUT), 'sha256': sha(OUT.read_bytes()),
                  'word_vm': word_results['vm']['passed'], 'word_node': word_results['node']['passed'],
                  'font': font_tests['passed'], 'zotero_engine': len(engine_cases),
                  'zotero_editor': editor_cases['passed'], 'archives': report['archives']}, indent=2))
