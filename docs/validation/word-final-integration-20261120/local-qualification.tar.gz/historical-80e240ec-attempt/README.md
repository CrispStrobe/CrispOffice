# Historical Zotero attempt at 80e240ec

**This complete gate was not accepted.** The 14 engine suites passed all
470 cases and the nine editor suites passed all 257 cases, but strict
whole-engine analysis reported one informational missing-braces lint in
`test/zotero_citing_test.dart:582:15`. Because `--fatal-infos` was requested,
that analyzer command exited 1. Editor analysis and the 14-file format check
passed. No product test failed or was skipped.

The exact remote source was
`80e240ec1f557c1ac7c170a8273de41dfaac0f20`, tree
`88bb7bcbfaae64642a8274ecc7fb7998564e4d04`. All 2,682 captured source inputs,
captured runtime inputs and HEAD remained unchanged; the worktree was clean
at completion. The original raw qualification receipt remains `success=false`.

After both successful test processes finished, the original orchestration
script failed while resolving relative reporter suite paths against its own
working directory. The continuation resolved each path against its recorded
test command's working directory, preserved both original raw logs and the
original runner, verified the source/runtime bridge seals, and completed the
remaining analysis and format commands. It did not rerun the 727 cases.
An independent audit confirmed exact selected files, complete identities,
no duplicate/unfinished completions, successful terminal events and unchanged
raw hashes. The collector failure and its correction remain explicit in the
receipt rather than being presented as a product failure.

This archive preserves the exact original and continuation runners, raw test
and analyzer/format logs, corrected case identities, all source/runtime seals,
the runtime-mapping and gate plan, and the collector interruption. SDKs,
caches, build outputs and compiled artifacts are excluded. It is historical
evidence for the stated source, not acceptance of a later combined delivery.
No installed Zotero/Word/LibreOffice, live library or active ODT acceptance
was performed by this local gate. Historical Word and Mail counts are not
added to these 727 cases.
