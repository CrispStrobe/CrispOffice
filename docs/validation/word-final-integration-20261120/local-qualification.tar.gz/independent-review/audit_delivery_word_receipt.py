from pathlib import Path
from collections import Counter
import hashlib
import json
import subprocess
import tarfile

BASE = Path('/workspace/scratch/03cd41fa0e7e')
REPO = BASE / 'quds_delivery'
RECORDS = BASE / 'runtime/word-zotero-delivery-qualification'
TARGET = 'c62338c65571aa399da5592455b651fa5c6a9317'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def read(name):
    return json.loads((RECORDS / name).read_text())


def ids(rows):
    return {(r['path'], r['name'], r.get('occurrence', 1)) for r in rows}


def signature(values):
    return sha(json.dumps(sorted(values), separators=(',', ':')).encode())


receipt = read('qualification.json')
audit = read('incoming-retention-audit.json')
selection = read('fresh-selection.json')
assert receipt['source_head'] == TARGET and receipt['success']
assert sha((RECORDS / 'incoming-retention-audit.json').read_bytes()) == receipt['incoming_audit_sha256']
allowed = {(r['file'], r['name']) for r in receipt['expected_editor_exclusions']}
assert len(allowed) == 8
all_cases, groups = [], {}
for command in receipt['commands']:
    raw = (RECORDS / command['stdout']).read_bytes()
    assert sha(raw) == command['stdout_sha256']
    assert sha((RECORDS / command['stderr']).read_bytes()) == command['stderr_sha256']
    assert command['exit_code'] == 0
    if command['name'] not in ['macro-tests', 'native-zotero-engine-tests', 'editor-tests']:
        continue
    events, ignored = [], 0
    for line in raw.splitlines():
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            ignored += 1
            continue
        if isinstance(value, dict) and 'type' in value:
            events.append(value)
        else:
            ignored += 1
    suites = {e['suite']['id']: e['suite'] for e in events if e.get('type') == 'suite'}
    tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    completed = [e for e in events if e.get('type') == 'testDone']
    assert len(completed) == len(tests) == len({e['testID'] for e in completed})
    assert not any(e.get('type') == 'error' for e in events)
    terminal = [e for e in events if e.get('type') == 'done']
    assert len(terminal) == 1 and terminal[0]['success']
    cases, occurrences = [], Counter()
    for event in completed:
        if event.get('hidden'):
            continue
        test = tests[event['testID']]
        path = Path(suites[test['suiteID']]['path'])
        if not path.is_absolute():
            path = Path(command['cwd']) / path
        path = str(path.resolve().relative_to(REPO))
        occurrences[(path, test['name'])] += 1
        cases.append({'path': path, 'name': test['name'],
                      'occurrence': occurrences[(path, test['name'])],
                      'skipped': bool(event.get('skipped')), 'result': event['result']})
    assert all(c['result'] == 'success' for c in cases)
    skipped = {(c['path'], c['name']) for c in cases if c['skipped']}
    assert skipped == (allowed if command['name'] == 'editor-tests' else set())
    counts = dict(Counter(c['path'] for c in cases if not c['skipped']))
    categories = {'macro-tests': ['macro'], 'native-zotero-engine-tests': ['native', 'zotero-engine'],
                  'editor-tests': ['editor-layout', 'zotero-editor']}[command['name']]
    assert counts == {p: n for category in categories for p, n in selection[category].items()}
    groups[command['name']] = {'passed': sum(counts.values()), 'skipped': len(skipped),
                              'file_count': len(counts), 'per_file': counts, 'raw_sha256': sha(raw),
                              'ignored_non_reporter_lines': ignored, 'terminal_success': True,
                              'every_start_completed_once': True,
                              'repeated_case_names': [{'path': p, 'name': n, 'occurrences': count}
                                                     for (p, n), count in occurrences.items() if count > 1]}
    all_cases += cases

before, after = read('source-before.json'), read('source-after.json')
assert before == after and len(before) == 2831
for path, expected in before.items():
    assert sha(git('show', TARGET + ':' + path)) == expected == sha((REPO / path).read_bytes()), path
runtime_before, runtime_after = read('runtime-before.json'), read('runtime-after.json')
assert runtime_before == runtime_after
for path, expected in runtime_before.items():
    assert sha(Path(path).read_bytes()) == expected, path
assert git('rev-parse', 'HEAD').decode().strip() == TARGET
post_gate_status = git('status', '--porcelain').decode().splitlines()
assert all(line[3:].startswith('docs/') for line in post_gate_status), post_gate_status
assert receipt['head_unchanged'] and receipt['worktree_clean']
fixture_roots = ['docs/validation/word-native-layout-20261120/reference',
                 'docs/validation/word-line-boxes-20261120/reference']
fixtures = {}
for path in git('ls-files', '--', *fixture_roots).decode().splitlines():
    data = git('show', TARGET + ':' + path)
    assert data == (REPO / path).read_bytes()
    fixtures[path] = sha(data)
assert fixtures

fresh = {category: [c for c in all_cases if c['path'] in paths and not c['skipped']]
         for category, paths in selection.items()}
incoming = audit['word']['raw_results']['vm']['case_identities']
retained = [c for c in incoming if c['path'] != 'packages/quds_office_engine/test/word_styles_layout_test.dart']
assert len(retained) == 946
incoming_macro = [c for c in retained if Path(c['path']).name.startswith(('office_macro_', 'office_vba_'))]
incoming_native = [c for c in retained if c not in incoming_macro]
assert len(incoming_macro) == 771 and len(incoming_native) == 175
unions = {}
for category, prior, expected in [
    ('native', incoming_native, 398),
    ('editor-layout', audit['font']['raw_results']['case_identities'], 105),
    ('zotero-engine', audit['zotero_engine']['case_identities'], 470),
    ('zotero-editor', audit['zotero_editor']['raw_results']['case_identities'], 257),
]:
    new_ids, old_ids = ids(fresh[category]), ids(prior)
    assert not new_ids & old_ids
    whole = new_ids | old_ids
    assert len(whole) == expected
    unions[category] = {'fresh': len(new_ids), 'retained': len(old_ids), 'accepted': len(whole),
                        'case_identity_sha256': signature(whole)}

macro_archive = REPO / 'docs/validation/word-vba-unit-conversions-20261120/local-qualification.tar.gz'
with tarfile.open(macro_archive, 'r:gz') as tar:
    historical_macro = json.loads(tar.extractfile('final-word/accepted-test-cases.json').read())
    historical_source = json.loads(tar.extractfile('final-word/source-after.json').read())
historical_ids = {(str(Path('packages/quds_office_engine') / c['file']), c['name'], c['occurrence'])
                  for c in historical_macro}
assert len(historical_ids) == 3598
current_macro = ids(fresh['macro']) | ids(incoming_macro)
assert len(current_macro) == 1434 and current_macro <= historical_ids
macro_files = {path for path, _, _ in historical_ids}
assert len(macro_files) == 69
for path in macro_files:
    assert sha(git('show', TARGET + ':' + path)) == historical_source[path], path
old_native_macro = json.loads((BASE / 'runtime/word-main-qualification/macro-rerun-cases.json').read_text())
old709 = {(str(Path('packages/quds_office_engine') / c['file']), c['name'], c['occurrence'])
          for c in old_native_macro}
current709 = ids(fresh['macro']) | (ids(incoming_macro) & old709)
assert current709 == old709 and len(current709) == 709
unions['macro'] = {'historical_accepted_corpus': 3598, 'historical_suites': 69,
                   'all69test_files_match_qualified_manifest': True,
                   'fresh_native_dependent_cases': 663, 'incoming_exact_native_dependent_cases': 46,
                   'exact_original709case_union': True,
                   'incoming_plus_fresh_cases_within_historical_corpus': 1434,
                   'other_historical_cases': 2164, 'corpus_count_not_increased': True,
                   'occurrence_ids_preserve_three_expected_repeated_names': True}
node = ids(audit['word']['raw_results']['node']['case_identities'])
assert len(node) == 758 and node <= ids(incoming)
final = {'schema': 'quds-delivery-independent-final-recount/v1',
         'source_commit': TARGET, 'source_tree': receipt['source_tree'],
         'qualification_sha256': sha((RECORDS / 'qualification.json').read_bytes()),
         'incoming_audit_sha256': receipt['incoming_audit_sha256'],
         'auditor_sha256': sha(Path(__file__).read_bytes()),
         'commands_verified': [{k: c[k] for k in ['name', 'exit_code', 'stdout_sha256', 'stderr_sha256']}
                               for c in receipt['commands']],
         'raw_groups': groups, 'source_before_after_match': True,
         'source_inputs_verified_against_git_and_current': len(before),
         'runtime_before_after_and_current_match': True,
         'runtime_inputs_verified': len(runtime_before),
         'head_verified': True, 'clean_tree_at_gate_completion': receipt['worktree_clean'],
         'expected_post_gate_documentation_changes': post_gate_status,
         'reference_fixtures': {'binding': 'Clean start/end tree plus current bytes verified against immutable c623 Git; these reference files were outside the runner per-file before/after source seal.', 'files': fixtures},
         'accepted_union': unions,
         'node_rechecks': {'count': 758, 'all_cases_also_in_verified_incoming_vm': True,
                           'not_additional_logical_cases': True},
         'exact_editor_exclusions': [{'file': f, 'name': n, 'reason': 'no paragraphs to edit'}
                                    for f, n in sorted(allowed)],
         'success': True,
         'limits': ['No tests were executed by this reviewer.',
                    'Retained incoming results preserve their original source/runtime provenance; fresh local runs are separate.',
                    'Macro, native, editor and Zotero counts describe separate scopes; no cross-scope grand total is asserted.']}
output = BASE / 'runtime/delivery-word-final-recount.json'
output.write_text(json.dumps(final, indent=2, sort_keys=True) + '\n')
print(json.dumps({'record': str(output), 'sha256': sha(output.read_bytes()),
                  'source_inputs': len(before), 'runtime_inputs': len(runtime_before),
                  'reference_fixtures': len(fixtures), 'accepted_union': unions}, indent=2))
