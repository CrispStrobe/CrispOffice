#!/usr/bin/env python3
"""Qualify the test-only Word geometry correction and retain exact prior scope."""
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path('/workspace/scratch/03cd41fa0e7e')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--expected-head', required=True)
parser.add_argument('--repo', type=Path, default=BASE / 'quds_mail_integration')
parser.add_argument('--out', type=Path, default=BASE / 'runtime/word-main-followup')
args = parser.parse_args()
REPO = args.repo.resolve()
OUT = args.out.resolve()
PRIOR = BASE / 'runtime/word-main-qualification'
ENGINE = REPO / 'packages/quds_office_engine'
DART = BASE / 'runtime/toolchain/dart-sdk/bin/dart'
KERNEL = BASE / 'runtime/toolchain/test-runner/test-runner.dill'
CONFIG = REPO / '.dart_tool/package_config.json'
FIXTURE = 'packages/quds_office_engine/test/word_contained_text_wrap_test.dart'
TEST = 'test/word_contained_text_wrap_test.dart'


def git(*arguments):
    return subprocess.check_output(['git', '-C', str(REPO), *arguments], text=True).strip()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


assert git('rev-parse', 'HEAD') == args.expected_head, 'Unexpected source HEAD.'
assert not git('status', '--porcelain'), 'Require clean published source.'
prior = json.loads((PRIOR / 'qualification.json').read_text())
original_sources = json.loads((PRIOR / 'source-before.json').read_text())
original_native = json.loads((PRIOR / 'word-native-layout-cases.json').read_text())
original_editor = json.loads((PRIOR / 'editor-native-layout-cases.json').read_text())
original_macros = json.loads((PRIOR / 'macro-rerun-cases.json').read_text())
assert all(prior[key] for key in ['source_unchanged', 'runtime_unchanged',
    'source_head_unchanged', 'worktree_clean', 'compiler_unchanged',
    'automation_sources_unchanged', 'macro_test_sources_unchanged'])
assert len(original_macros) == 709
assert all(case['result'] == 'success' and not case['skipped'] for case in original_macros)
assert all(case['result'] == 'success' for case in original_editor)
assert sum(case['skipped'] for case in original_editor) == 8
assert all(row['portable_equal'] for row in prior['portable_examples'].values())
assert all(command['exit_code'] == 0 for command in prior['commands']
    if command['name'] != 'word-native-layout')
OUT.mkdir(parents=True, exist_ok=False)
for name in ['tmp', 'config', 'cache']:
    (OUT / name).mkdir()
environment = dict(os.environ)
environment.update({
    'QUDS_VALIDATION_ROOT': str(REPO),
    'QUDS_DART_ROOT': str(DART.parent.parent),
    'PUB_CACHE': str(BASE / 'runtime/toolchain/pub-cache'),
    'TMPDIR': str(OUT / 'tmp'),
    'XDG_CONFIG_HOME': str(OUT / 'config'),
    'XDG_CACHE_HOME': str(OUT / 'cache'),
    'DART_SUPPRESS_ANALYTICS': 'true',
    'CI': 'true',
    'PATH': str(DART.parent) + os.pathsep + os.environ['PATH'],
})


def snapshot():
    return {path: digest(REPO / path) for path in original_sources}


runtime_paths = [DART, KERNEL, CONFIG, REPO / '.dart_tool/package_graph.json',
    DART.parent / 'snapshots/analysis_server_aot.dart.snapshot', Path(__file__)]


def runtime_snapshot():
    return {str(path): digest(path) for path in runtime_paths if path.exists()}


before = snapshot()
runtime_before = runtime_snapshot()
changed_inputs = sorted(path for path in before if before[path] != original_sources[path])
engine_editor_delta = git('diff', '--name-only', prior['source_head'], 'HEAD', '--',
    'packages/quds_office_engine', 'packages/quds_office_editor').splitlines()
production_delta = git('diff', '--name-only', prior['source_head'], 'HEAD', '--',
    'packages/quds_office_engine/lib', 'packages/quds_office_editor/lib').splitlines()
assert changed_inputs == [FIXTURE], changed_inputs
assert engine_editor_delta == [FIXTURE], engine_editor_delta
assert not production_delta, production_delta
write('source-before.json', before)
write('runtime-before.json', runtime_before)
report = {
    'started_utc': now(), 'source_head': git('rev-parse', 'HEAD'),
    'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'prior_source_head': prior['source_head'],
    'prior_receipt': str(PRIOR / 'qualification.json'),
    'prior_receipt_sha256': digest(PRIOR / 'qualification.json'),
    'prior_receipt_success': prior['success'],
    'changed_captured_inputs': changed_inputs,
    'engine_editor_changed_paths': engine_editor_delta,
    'engine_editor_production_changed_paths': production_delta,
    'captured_source_count': len(before), 'commands': [],
    'selection_rationale': 'Only the contained-text wrapping fixture geometry changed. Rerun its whole 41-case suite; retain prior passing results only where production and test inputs are unchanged. Keep all original failures and editor skips visible.',
    'dart_version': subprocess.check_output([DART, '--version'], env=environment, text=True).strip(),
}


def run(name, command):
    print('Starting ' + name, flush=True)
    start = time.monotonic()
    started = now()
    stdout, stderr = OUT / (name + '.stdout.log'), OUT / (name + '.stderr.log')
    with stdout.open('w') as out, stderr.open('w') as err:
        result = subprocess.run([str(arg) for arg in command], cwd=ENGINE,
            env=environment, stdout=out, stderr=err)
    report['commands'].append({
        'name': name, 'command': [str(arg) for arg in command], 'cwd': str(ENGINE),
        'started_utc': started, 'finished_utc': now(),
        'seconds': round(time.monotonic() - start, 3), 'exit_code': result.returncode,
        'stdout': stdout.name, 'stdout_sha256': digest(stdout),
        'stderr': stderr.name, 'stderr_sha256': digest(stderr),
    })
    print(f'Finished {name}: exit {result.returncode}', flush=True)


run('contained-text-suite', [DART, '--old_gen_heap_size=768', f'--packages={CONFIG}',
    KERNEL, '--compiler', 'source', '--concurrency=1', '--timeout=4x', '--reporter=json', TEST])
run('fixture-analysis', [DART, 'analyze', '--fatal-infos', TEST])
run('fixture-format', [DART, 'format', '--output=none', '--set-exit-if-changed', TEST])
events = []
for line in (OUT / 'contained-text-suite.stdout.log').read_text().splitlines():
    if line.startswith('{'):
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            pass
suites = {e['suite']['id']: e['suite']['path'] for e in events if e.get('type') == 'suite'}
starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
occurrences = collections.Counter()
cases = []
for event in events:
    if event.get('type') != 'testDone' or event.get('hidden'):
        continue
    test = starts[event['testID']]
    path = Path(suites[test['suiteID']])
    file = str(path.relative_to(ENGINE) if path.is_absolute() else path)
    occurrences[(file, test['name'])] += 1
    cases.append({'file': file, 'name': test['name'],
        'occurrence': occurrences[(file, test['name'])],
        'result': event['result'], 'skipped': bool(event.get('skipped'))})
write('contained-text-cases.json', cases)
identity = lambda row: (row['file'], row['name'], row['occurrence'])
replaced = [case for case in original_native if case['file'] == TEST]
retained = [case for case in original_native if case['file'] != TEST]
report['focused_suite'] = {
    'passed': sum(case['result'] == 'success' and not case['skipped'] for case in cases),
    'failed': sum(case['result'] != 'success' for case in cases),
    'skipped': sum(case['skipped'] for case in cases),
    'terminal_success': bool(events and events[-1].get('type') == 'done' and events[-1].get('success') is True),
    'reporter_errors': sum(event.get('type') == 'error' for event in events),
    'same_case_identities_as_prior_file': collections.Counter(map(identity, cases)) == collections.Counter(map(identity, replaced)),
    'case_identities_unique': len(set(map(identity, cases))) == len(cases),
    'prior_replaced_cases': len(replaced),
    'prior_replaced_failed_cases': [case for case in replaced if case['result'] != 'success'],
}
accepted_native = [dict(case, evidence='cdd98460 frozen run') for case in retained]
accepted_native.extend(dict(case, evidence=report['source_head'] + ' focused follow-up') for case in cases)
write('accepted-native-cases.json', accepted_native)
report['accepted_scope'] = {
    'macro_rerun': {'passed': len(original_macros), 'files': 23,
        'evidence_retained_from': prior['source_head'],
        'additional_cases_to_add_to_historical_macro_corpus': 0},
    'native_layout': {'passed': sum(case['result'] == 'success' and not case['skipped'] for case in accepted_native),
        'failed': sum(case['result'] != 'success' for case in accepted_native),
        'skipped': sum(case['skipped'] for case in accepted_native),
        'files': len({case['file'] for case in accepted_native}),
        'retained_case_count': len(retained), 'superseding_case_count': len(cases)},
    'editor': {'passed': sum(case['result'] == 'success' and not case['skipped'] for case in original_editor),
        'failed': sum(case['result'] != 'success' for case in original_editor),
        'skipped': sum(case['skipped'] for case in original_editor), 'files': 5,
        'evidence_retained_from': prior['source_head'],
        'skip_reason': 'Eight existing image-only floating DOCX fixtures have no editable paragraphs; not counted as passes.'},
    'retained_analyzers': ['engine-analysis', 'editor-delta-analysis'],
    'retained_portable_examples': ['measurements', 'named-measurements'],
}
after = snapshot()
runtime_after = runtime_snapshot()
write('source-after.json', after)
write('runtime-after.json', runtime_after)
report['source_unchanged'] = before == after
report['runtime_unchanged'] = runtime_before == runtime_after
report['head_unchanged'] = report['source_head'] == git('rev-parse', 'HEAD')
report['worktree_clean'] = not git('status', '--porcelain')
report['original_failure_receipt_unchanged'] = report['prior_receipt_sha256'] == digest(PRIOR / 'qualification.json')
focused = report['focused_suite']
report['success'] = (
    all(command['exit_code'] == 0 for command in report['commands'])
    and focused['passed'] == 41 and focused['failed'] == 0 and focused['skipped'] == 0
    and focused['terminal_success'] and focused['reporter_errors'] == 0
    and focused['same_case_identities_as_prior_file'] and focused['case_identities_unique']
    and all(case['result'] == 'success' and not case['skipped'] for case in retained)
    and len(accepted_native) == 312
    and all(report[key] for key in ['source_unchanged', 'runtime_unchanged',
        'head_unchanged', 'worktree_clean', 'original_failure_receipt_unchanged']))
report['success_scope'] = 'This success flag qualifies the focused native fixture correction and unchanged-input retention. It does not turn the eight editor skips into passes or supersede the raw historical success=false receipt.'
report['finished_utc'] = now()
write('qualification.json', report)
print(json.dumps({'success': report['success'], 'focused_suite': focused,
    'accepted_scope': report['accepted_scope']}), flush=True)
raise SystemExit(0 if report['success'] else 1)
