#!/usr/bin/env python3
"""Qualify the affected Word/native delta at an already published clean HEAD."""
import argparse
import base64
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

BASE = Path('/workspace/scratch/03cd41fa0e7e')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, default=BASE / 'quds_mail_integration')
parser.add_argument('--out', type=Path, default=BASE / 'runtime/word-main-qualification')
parser.add_argument('--expected-head', required=True)
args = parser.parse_args()
REPO = args.repo.resolve()
OUT = args.out.resolve()
ENGINE = REPO / 'packages/quds_office_engine'
EDITOR = REPO / 'packages/quds_office_editor'
BASELINE = '85f4ef96ab4def73b68eccbc82105d89ae5f943b'
RUNTIME = BASE / 'runtime/toolchain'
FLUTTER_RUNTIME = BASE / 'runtime/flutter-toolchain'
DART = RUNTIME / 'dart-sdk/bin/dart'
KERNEL = RUNTIME / 'test-runner/test-runner.dill'
FLUTTER = FLUTTER_RUNTIME / 'bin/flutter'
CONFIG = REPO / '.dart_tool/package_config.json'
NODE = Path(shutil.which('node'))

MACRO_TESTS = [
    'office_macro_runtime_test.dart',
    'office_macro_cli_test.dart',
    'office_macro_mcp_test.dart',
    'office_vba_arguments_integration_test.dart',
    'office_macro_word_line_spacing_test.dart',
    'office_macro_word_list_format_test.dart',
    'office_macro_word_list_levels_test.dart',
    'office_macro_word_paragraph_controls_test.dart',
    'office_macro_word_revision_guard_test.dart',
    'office_macro_word_tab_stops_test.dart',
    'office_vba_word_cli_test.dart',
    'office_vba_word_format_integration_test.dart',
    'office_vba_word_integration_test.dart',
    'office_vba_word_line_spacing_integration_test.dart',
    'office_vba_word_list_levels_integration_test.dart',
    'office_vba_word_lists_integration_test.dart',
    'office_vba_word_measurements_integration_test.dart',
    'office_vba_word_named_measurements_integration_test.dart',
    'office_vba_word_paragraph_controls_integration_test.dart',
    'office_vba_word_paragraph_layout_integration_test.dart',
    'office_vba_word_tabstops_integration_test.dart',
    'office_vba_word_typography_integration_test.dart',
    'office_vba_word_unit_conversions_integration_test.dart',
]
NATIVE_TESTS = [
    'word_header_picture_identity_test.dart',
    'word_styles_layout_test.dart',
    'word_preserved_header_test.dart',
    'word_inline_picture_test.dart',
    'word_media_dedupe_test.dart',
    'word_layout_test.dart',
    'word_incremental_layout_test.dart',
    'word_incremental_layout_prefix_test.dart',
    'word_incremental_layout_differential_test.dart',
    'word_table_test.dart',
    'word_table_direction_test.dart',
    'word_table_grid_addressing_test.dart',
    'word_table_nested_layout_test.dart',
    'word_table_tall_frame_layout_test.dart',
    'word_table_tall_toc_layout_test.dart',
    'word_table_picture_pagination_test.dart',
    'word_native_presentation_test.dart',
    'word_fidelity_test.dart',
    'word_compatibility_fidelity_test.dart',
    'word_package_preservation_test.dart',
    'word_section_clone_fidelity_test.dart',
    'word_paragraph_mark_layout_test.dart',
    'word_line_box_fidelity_test.dart',
    'word_picture_distance_fidelity_test.dart',
    'word_frame_wrap_test.dart',
    'word_contained_text_wrap_test.dart',
]
EDITOR_TESTS = [
    'office_system_fonts_test.dart',
    'word_incremental_layout_equivalence_test.dart',
    'word_header_footer_navigation_test.dart',
    'word_inline_picture_history_test.dart',
    'word_page_layout_test.dart',
]


def git(*arguments):
    return subprocess.check_output(['git', '-C', str(REPO), *arguments], text=True).strip()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


assert git('rev-parse', 'HEAD') == args.expected_head, 'Unexpected source HEAD.'
assert not git('status', '--porcelain'), 'Require clean published source.'
for directory, names in [(ENGINE, MACRO_TESTS + NATIVE_TESTS), (EDITOR, EDITOR_TESTS)]:
    for name in names:
        assert (directory / 'test' / name).is_file(), name
assert len(MACRO_TESTS + NATIVE_TESTS) == len(set(MACRO_TESTS + NATIVE_TESTS))
OUT.mkdir(parents=True, exist_ok=False)
for name in ['tmp-engine', 'tmp-editor', 'config-engine', 'config-editor', 'cache-engine', 'cache-editor']:
    (OUT / name).mkdir()

engine_env = dict(os.environ)
engine_env.update({
    'QUDS_VALIDATION_ROOT': str(REPO),
    'QUDS_DART_ROOT': str(DART.parent.parent),
    'PUB_CACHE': str(RUNTIME / 'pub-cache'),
    'TMPDIR': str(OUT / 'tmp-engine'),
    'XDG_CONFIG_HOME': str(OUT / 'config-engine'),
    'XDG_CACHE_HOME': str(OUT / 'cache-engine'),
    'DART_SUPPRESS_ANALYTICS': 'true',
    'CI': 'true',
    'PATH': str(DART.parent) + os.pathsep + os.environ['PATH'],
})
editor_env = dict(os.environ)
editor_env.update({
    'PUB_CACHE': str(FLUTTER_RUNTIME / 'pub-cache'),
    'FLUTTER_ROOT': str(FLUTTER_RUNTIME / 'flutter'),
    'XDG_DATA_HOME': str(FLUTTER_RUNTIME / 'data'),
    'TMPDIR': str(OUT / 'tmp-editor'),
    'XDG_CONFIG_HOME': str(OUT / 'config-editor'),
    'XDG_CACHE_HOME': str(OUT / 'cache-editor'),
    'DART_SUPPRESS_ANALYTICS': 'true',
    'FLUTTER_SUPPRESS_ANALYTICS': 'true',
    'DASH__SUPPRESS_ANALYTICS': 'true',
    'CI': 'true',
    'PATH': str(FLUTTER_RUNTIME / 'bin') + os.pathsep + os.environ['PATH'],
})

source_paths = git('ls-files',
    'packages/quds_office_engine/lib', 'packages/quds_office_engine/test',
    'packages/quds_office_engine/tool/macros', 'packages/quds_office_engine/example/macros',
    'packages/legacy_doc_parser/lib', 'packages/legacy_doc_parser/pubspec.yaml',
    'packages/quds_office_editor/lib', 'packages/quds_office_editor/fonts',
    'packages/quds_office_editor/test/support',
    *['packages/quds_office_editor/test/' + name for name in EDITOR_TESTS],
    'packages/quds_office_engine/pubspec.yaml', 'packages/quds_office_editor/pubspec.yaml',
    'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.fvmrc').splitlines()
runtime_paths = [CONFIG, REPO / '.dart_tool/package_graph.json', DART, KERNEL,
    DART.parent / 'snapshots/dart2js_aot.dart.snapshot',
    DART.parent / 'snapshots/analysis_server_aot.dart.snapshot',
    FLUTTER, FLUTTER_RUNTIME / 'runtime.json',
    FLUTTER_RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart',
    FLUTTER_RUNTIME / 'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',
    RUNTIME / 'environment.json', Path(__file__)]


def source_snapshot():
    return {path: digest(REPO / path) for path in source_paths}


def runtime_snapshot():
    return {str(path): digest(path) for path in runtime_paths if path.exists()}


before = source_snapshot()
runtime_before = runtime_snapshot()
(OUT / 'source-before.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
(OUT / 'runtime-before.json').write_text(json.dumps(runtime_before, indent=2, sort_keys=True) + '\n')
production_changes = git('diff', '--name-only', BASELINE, 'HEAD', '--',
    'packages/quds_office_engine/lib', 'packages/quds_office_editor/lib').splitlines()
expected_changes = {
    'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
    'packages/quds_office_engine/lib/src/word/serial/word_deserializer.dart',
    'packages/quds_office_editor/lib/src/embed/office_system_fonts_io.dart',
}
compiler_path = 'packages/quds_office_engine/lib/src/automation/office_vba_language.dart'
baseline_compiler = hashlib.sha256(subprocess.check_output(
    ['git', '-C', str(REPO), 'show', BASELINE + ':' + compiler_path])).hexdigest()
report = {
    'started_utc': now(), 'source_head': git('rev-parse', 'HEAD'),
    'source_tree': git('rev-parse', 'HEAD^{tree}'), 'baseline_commit': BASELINE,
    'source_files_hashed': len(before), 'changed_production_paths': production_changes,
    'only_expected_production_changes': set(production_changes) == expected_changes,
    'compiler_sha256': before[compiler_path],
    'compiler_unchanged': before[compiler_path] == baseline_compiler,
    'automation_sources_unchanged': not git('diff', '--name-only', BASELINE, 'HEAD', '--',
        'packages/quds_office_engine/lib/src/automation'),
    'macro_test_sources_unchanged': not git('diff', '--name-only', BASELINE, 'HEAD', '--',
        'packages/quds_office_engine/test/office_macro*test.dart',
        'packages/quds_office_engine/test/office_vba*test.dart'),
    'commands': [], 'test_groups': {},
    'selection_rationale': {
        'macro-rerun': 'Native Word execution, saved DOCX/DOCM, CLI/MCP, policy/rollback and measurement integration depend on the changed deserializer. These are reruns within the previously accepted macro corpus, not new cases to add to its total.',
        'word-native-layout': 'Table/style import, explicit run precedence, picture/header/footer identity, preserved packages, continuous/incremental layout, paragraph lines and nested/table picture pagination depend on the changed Word modules. These are additional non-macro qualification cases.',
        'editor-native-layout': 'Installed-face discovery exercises the filename aliases with real font fixtures; editor layout/history/navigation verifies public consumers of the changed engine. No installed-host font or native Word-application claim is made.',
    },
    'test_files': {'macro-rerun': MACRO_TESTS, 'word-native-layout': NATIVE_TESTS,
                   'editor-native-layout': EDITOR_TESTS},
    'dart_version': subprocess.check_output([DART, '--version'], env=engine_env, text=True).strip(),
    'node_version': subprocess.check_output([NODE, '--version'], text=True).strip(),
}


def run(name, command, cwd=ENGINE, environment=engine_env):
    print('Starting ' + name, flush=True)
    start = time.monotonic()
    started = now()
    stdout = OUT / (name + '.stdout.log')
    stderr = OUT / (name + '.stderr.log')
    with stdout.open('w') as out_stream, stderr.open('w') as err_stream:
        result = subprocess.run([str(value) for value in command], cwd=cwd,
            env=environment, stdout=out_stream, stderr=err_stream)
    row = {'name': name, 'command': [str(value) for value in command],
        'cwd': str(cwd), 'started_utc': started, 'finished_utc': now(),
        'exit_code': result.returncode, 'seconds': round(time.monotonic() - start, 3),
        'stdout': stdout.name, 'stdout_sha256': digest(stdout),
        'stderr': stderr.name, 'stderr_sha256': digest(stderr)}
    report['commands'].append(row)
    (OUT / 'progress.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f'Finished {name}: exit {result.returncode}', flush=True)
    return result.returncode


def parse_tests(group, package):
    events = []
    for line in (OUT / (group + '.stdout.log')).read_text().splitlines():
        if line.startswith('{'):
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    suites = {event['suite']['id']: event['suite']['path'] for event in events if event.get('type') == 'suite'}
    starts = {event['test']['id']: event['test'] for event in events if event.get('type') == 'testStart'}
    finished = [event for event in events if event.get('type') == 'testDone' and not event.get('hidden')]
    occurrences = collections.Counter()
    identities = []
    per_file = {}
    for event in finished:
        test = starts[event['testID']]
        path = Path(suites[test['suiteID']])
        file = str(path.relative_to(package) if path.is_absolute() else path)
        key = (file, test['name'])
        occurrences[key] += 1
        identities.append({'file': file, 'name': test['name'], 'occurrence': occurrences[key],
            'result': event['result'], 'skipped': bool(event.get('skipped'))})
        counts = per_file.setdefault(file, {'passed': 0, 'failed': 0, 'skipped': 0})
        outcome = 'skipped' if event.get('skipped') else 'passed' if event['result'] == 'success' else 'failed'
        counts[outcome] += 1
    (OUT / (group + '-cases.json')).write_text(json.dumps(identities, indent=2) + '\n')
    report['test_groups'][group] = {
        'passed': sum(row['passed'] for row in per_file.values()),
        'failed': sum(row['failed'] for row in per_file.values()),
        'skipped': sum(row['skipped'] for row in per_file.values()),
        'file_count': len(per_file), 'per_file': per_file,
        'reporter_errors': sum(event.get('type') == 'error' for event in events),
        'terminal_success': bool(events and events[-1].get('type') == 'done' and events[-1].get('success') is True),
    }


test_prefix = [DART, '--old_gen_heap_size=768', f'--packages={CONFIG}', KERNEL,
    '--compiler', 'source', '--concurrency=1', '--timeout=4x', '--reporter=json']
for group, tests in [('macro-rerun', MACRO_TESTS), ('word-native-layout', NATIVE_TESTS)]:
    run(group, test_prefix + ['test/' + name for name in tests])
    parse_tests(group, ENGINE)
run('editor-native-layout', [FLUTTER, 'test', '--no-pub', '--concurrency=1', '--machine',
    *['test/' + name for name in EDITOR_TESTS]], cwd=EDITOR, environment=editor_env)
parse_tests('editor-native-layout', EDITOR)
run('engine-analysis', [DART, 'analyze', '--fatal-infos'])
run('editor-delta-analysis', [FLUTTER_RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart',
    'analyze', '--fatal-infos', 'lib/src/embed/office_system_fonts_io.dart',
    *['test/' + name for name in EDITOR_TESTS]], cwd=EDITOR, environment=editor_env)

report['portable_examples'] = {}
for label, basename, define_name in [
    ('measurements', 'word_measurements', 'WORD_MEASUREMENTS_BAS_BASE64'),
    ('named-measurements', 'word_named_measurements', 'WORD_NAMED_MEASUREMENTS_BAS_BASE64'),
]:
    example = ENGINE / f'example/macros/{basename}.bas'
    define = '-D' + define_name + '=' + base64.b64encode(example.read_bytes()).decode()
    driver = f'tool/macros/web_vba_{basename}_smoke.dart'
    javascript = OUT / (basename + '.js')
    result = {'example': str(example.relative_to(ENGINE)), 'example_sha256': digest(example),
        'driver': driver, 'driver_sha256': digest(ENGINE / driver), 'define': define_name}
    report['portable_examples'][label] = result
    run(label + '-vm', [DART, f'--packages={CONFIG}', define, driver])
    run(label + '-js-compile', [DART, 'compile', 'js', '-O2', f'--packages={CONFIG}', define,
        driver, '-o', javascript])
    run(label + '-js-node', [NODE, '-e', 'globalThis.self = globalThis; require(' + json.dumps(str(javascript)) + ');'])
    try:
        vm = json.loads((OUT / (label + '-vm.stdout.log')).read_text())
        js = json.loads((OUT / (label + '-js-node.stdout.log')).read_text())
        result.update({'vm_result': vm, 'node_result': js, 'portable_equal': vm == js})
    except (ValueError, OSError) as error:
        result.update({'portable_equal': False, 'parse_error': str(error)})

after = source_snapshot()
runtime_after = runtime_snapshot()
(OUT / 'source-after.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
(OUT / 'runtime-after.json').write_text(json.dumps(runtime_after, indent=2, sort_keys=True) + '\n')
report['source_unchanged'] = before == after
report['runtime_unchanged'] = runtime_before == runtime_after
report['source_head_unchanged'] = report['source_head'] == git('rev-parse', 'HEAD')
report['worktree_clean'] = not git('status', '--porcelain')
report['finished_utc'] = now()
report['success'] = (
    all(row['exit_code'] == 0 for row in report['commands'])
    and all(row['terminal_success'] and row['failed'] == 0 and row['skipped'] == 0
        and row['reporter_errors'] == 0 for row in report['test_groups'].values())
    and all(row['portable_equal'] for row in report['portable_examples'].values())
    and report['source_unchanged'] and report['runtime_unchanged']
    and report['source_head_unchanged'] and report['worktree_clean']
    and report['compiler_unchanged'] and report['automation_sources_unchanged']
    and report['macro_test_sources_unchanged']
    and report['only_expected_production_changes'])
(OUT / 'qualification.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'success': report['success'], 'test_groups': report['test_groups'],
    'source_unchanged': report['source_unchanged'], 'runtime_unchanged': report['runtime_unchanged']}), flush=True)
raise SystemExit(0 if report['success'] else 1)
