#!/usr/bin/env python3
"""Package the completed Word gates without changing source, config or refs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

BASE = Path('/workspace/scratch/03cd41fa0e7e')
REPO = BASE / 'quds_mail_integration'
RUNTIME = BASE / 'runtime'
TARGET = REPO / 'docs/validation/word-main-integration-20261120'
HISTORICAL = REPO / 'docs/validation/word-vba-unit-conversions-20261120'
FROZEN = RUNTIME / 'word-main-qualification'
FOLLOWUP = RUNTIME / 'word-main-followup-retry'
INITIAL_SHA = 'cdd98460c2eed261719c660351f11adc962e2ca5'
FINAL_SHA = 'cf25a0a3d80ee18d2550161af182bacc4e49d18f'
INCOMING_SHA = 'e975cec13b289fe067ef406cd3044701ecc44744'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def git_bytes(*arguments):
    return subprocess.check_output(['git', '-C', str(REPO), *arguments])


initial = json.loads((FROZEN / 'qualification.json').read_text())
followup = json.loads((FOLLOWUP / 'qualification.json').read_text())
overlap = json.loads((FROZEN / 'macro-case-overlap.json').read_text())
editor_cases = json.loads((FROZEN / 'editor-native-layout-cases.json').read_text())
native_cases = json.loads((FOLLOWUP / 'accepted-native-cases.json').read_text())
assert initial['source_head'] == INITIAL_SHA and initial['success'] is False
assert followup['source_head'] == FINAL_SHA and followup['success'] is True
assert git_bytes('rev-parse', 'HEAD').decode().strip() == FINAL_SHA
assert len(native_cases) == 312
assert all(case['result'] == 'success' and not case['skipped'] for case in native_cases)
assert len({(c['file'], c['name'], c['occurrence']) for c in native_cases}) == 312
assert overlap['matches_all_prior_cases_in_selected_files']
assert overlap['fresh_macro_rerun_cases'] == 709
assert overlap['prior_accepted_corpus_cases'] == 3598
exclusions = [dict(case, reason='no paragraphs to edit')
    for case in editor_cases if case['skipped']]
assert len(exclusions) == 8
initial_raw = (FROZEN / 'qualification.json').read_bytes()
followup_raw = (FOLLOWUP / 'qualification.json').read_bytes()
assert sha(initial_raw) == followup['prior_receipt_sha256']
assert sha(initial_raw) == '66edc44f8ced980ece429fd630a717202938248944bb511af3f7410bcca4ef6f'
assert sha(followup_raw) == '2ce88b1f2e075c4f0e3e724b0b0667bd4863d65f4a7abf37306536798311d7ea'

summary = {
    'schema_version': 1,
    'scope': 'Accepted affected Word qualification with explicit editor exclusions; not a universal zero-skip run.',
    'accepted_source_commit': FINAL_SHA, 'accepted_source_tree': followup['source_tree'],
    'frozen_run_commit': INITIAL_SHA, 'frozen_run_tree': initial['source_tree'],
    'incoming_main_commit': INCOMING_SHA,
    'completed_utc': followup['finished_utc'],
    'historical_macro_corpus': {'cases': 3598, 'suites': 69,
        'refreshed_cases': 709, 'refreshed_files': 23,
        'not_rerun_in_this_followup': 2889,
        'additional_cases_to_add_to_3598': 0,
        'exact_subset_identity_match': True},
    'accepted_native_layout': followup['accepted_scope']['native_layout'],
    'accepted_editor': dict(followup['accepted_scope']['editor'], exclusions=exclusions),
    'analysis': {'whole_engine': 'passed at cdd98460',
        'editor_font_source_and_five_selected_test_files': 'passed at cdd98460',
        'corrected_contained_text_fixture': 'passed at cf25a0a3',
        'fatal_infos': True},
    'portable_examples': {
        name: {'operations': result['vm_result']['example']['operations'],
            'example': result['example'], 'example_sha256': result['example_sha256'],
            'driver': result['driver'], 'driver_sha256': result['driver_sha256'],
            'byte_identical_bas_input': True, 'vm_and_optimized_javascript_equal': result['portable_equal']}
        for name, result in initial['portable_examples'].items()},
    'source_retention': {
        'captured_source_inputs': 1117,
        'frozen_source_runtime_head_unchanged': all(initial[k] for k in
            ['source_unchanged', 'runtime_unchanged', 'source_head_unchanged', 'worktree_clean']),
        'followup_source_runtime_head_unchanged': all(followup[k] for k in
            ['source_unchanged', 'runtime_unchanged', 'head_unchanged', 'worktree_clean']),
        'changed_captured_word_inputs': followup['changed_captured_inputs'],
        'known_test_only_changes_between_checkpoints': followup['engine_editor_changed_paths'],
        'engine_editor_production_changes_between_checkpoints': followup['engine_editor_production_changed_paths'],
        'compiler_sha256': initial['compiler_sha256'],
        'compiler_automation_and_macro_test_sources_unchanged_from_85f4ef96': all(initial[k] for k in
            ['compiler_unchanged', 'automation_sources_unchanged', 'macro_test_sources_unchanged']),
        'only_production_changes_from_85f4ef96': initial['changed_production_paths'],
    },
    'repair_regressions': {
        'header_visual_identity_and_placement': {'before_passed': 2, 'before_failed': 9,
            'after_passed': 11, 'sealed_frozen_run_passed': 11},
        'table_first_row_direct_format_precedence': {'before_passed': 0, 'before_failed': 2,
            'after_full_suite_passed': 17, 'sealed_frozen_run_passed': 17},
        'contained_text_fixture_geometry': {'initial_file_passed': 40, 'initial_file_failed': 1,
            'focused_file_passed': 41, 'focused_file_skipped': 0,
            'case_identities_unchanged': True, 'assertions_unchanged': True,
            'content_width_points': 31.2, 'old_outer_width_points': 42,
            'old_padding_points_each_side': 5.4, 'incoming_padding_points_each_side': 4.25},
    },
    'font_filename_aliases': {
        'new_lowercase_names': ['arial.ttf', 'arialbd.ttf', 'ariali.ttf', 'arialbi.ttf',
            'times.ttf', 'timesbd.ttf', 'timesi.ttf', 'timesbi.ttf'],
        'source_reviewed_and_statically_analyzed': True,
        'alias_specific_runtime_probe_run': False,
        'default_cross_platform_host_discovery_run': False,
        'existing_loader_fixture_coverage': 'Display-style filenames with licensed Liberation-based fixtures and synthetic family metadata.',
        'raw_initial_rationale_corrected_by': 'qualification-clarifications.md',
    },
    'raw_receipts': {
        'initial': {'path': 'initial-qualification.json', 'sha256': sha(initial_raw), 'success': False},
        'focused': {'path': 'focused-qualification.json', 'sha256': sha(followup_raw), 'success': True,
            'success_scope': followup['success_scope']},
        'original_false_receipt_preserved': True,
        'preflight_attempt': 'archive:preflight/preflight-failure.json; no product test started',
    },
    'runtimes': {'engine_dart': '3.14.1', 'editor_flutter': '3.47.8',
        'editor_dart': '3.13.7', 'node': initial['node_version']},
    'limitations': ['Eight editor image-only fixtures have no editable paragraphs and remain skipped.',
        'Historical macro, native and editor counts are separate; overlapping reruns are not added.',
        'No installed Microsoft Word host or COM execution is claimed.',
        'No validity claim is made for cryptographic DOCM signatures after modification.',
        'Existing edited w:ind group ownership is unchanged.'],
}

readme = '''# Word latest-main integration qualification — 2026-11-20

The affected Word follow-up is accepted at remote commit
`cf25a0a3d80ee18d2550161af182bacc4e49d18f`, with the eight editor exclusions
documented below. The [accepted summary](accepted-summary.json) combines a
frozen run at `cdd98460` with one test-only correction at `cf25a0a3`.
It preserves the original failed result and does not claim a universal
zero-skip run.

## Captured source

| Checkpoint | Commit | Tree |
| --- | --- | --- |
| Incoming main | e975cec13b289fe067ef406cd3044701ecc44744 | Recorded in source history |
| Frozen Word/native/editor run | cdd98460c2eed261719c660351f11adc962e2ca5 | aee18e93719bc51dcd94c003ac9dfab3c0851bdc |
| Test-only correction | cf25a0a3d80ee18d2550161af182bacc4e49d18f | 0780f20f27df62004404496d8e5c529c4bdccd87 |

Incoming main changed Word layout and deserialization and added eight editor
font filename aliases. Integration repaired two concrete regressions:
header-picture loss and first-row table styles overriding explicit run color
or bold-off formatting. The VBA compiler, automation sources and macro test
sources remained unchanged from the earlier `85f4ef96` checkpoint.

The only changes from the frozen run to the focused follow-up are the Word
contained-text test geometry and the unrelated Mail cached-host test formatter
cleanup. No engine or editor production file changed between those checkpoints.
All 1,117 captured source inputs and captured runtime inputs matched before
and after each run; each run also ended at its expected HEAD with a clean tree.

## Accepted results and counting

| Scope | Accepted result | Evidence treatment |
| --- | --- | --- |
| Affected macro/runtime/CLI/MCP integration | 709 passed across 23 files; no failures or skips | Exact subset of the historical 3,598-case macro corpus |
| Word native/layout | 312 passed across 26 files; no failures or skips | 271 unchanged cases plus the superseding 41-case suite |
| Editor consumers | 103 passed across 5 files; 8 explicitly skipped | No failed cases; skipped image-only editing scenarios are not passes |
| Strict analysis | Passed | Whole engine, editor font source and five editor test files, then corrected Word fixture; fatal infos enabled |
| Corrected fixture formatting | Passed | No formatter changes required |
| Actual word_measurements.bas | Passed on VM and optimized dart2js/Node | Byte-identical BAS input; equal eight-operation results |
| Actual word_named_measurements.bas | Passed on VM and optimized dart2js/Node | Byte-identical BAS input; equal thirteen-operation results |

The 709 refreshed macro identities match every historical case in the selected
23 files, with no added, missing or duplicate identities. They **must not be
added to 3,598**. The other 2,889 historical macro identities were not rerun in
this follow-up. The 312 native and 103 passing editor cases are separate
non-macro qualification scopes. The broader historical measurement acceptance
remains in the [measurement report](../word-vba-unit-conversions-20261120/README.md).

The [initial raw receipt](initial-qualification.json) remains `success=false`:
it recorded 709 macro passes, 311 native passes and one fixture failure, and
103 editor passes with eight skips. Its strict predicate rejects any failed
or skipped case. The [focused receipt](focused-qualification.json) passed all
41 cases in the corrected file, with exactly the same case identities, plus
strict analysis and formatting. Its success flag qualifies that correction
and unchanged-input retention; it does not turn editor skips into passes.

## Regressions reproduced and repaired

### Header and footer pictures

The incoming renderer could remove both projections of one shared visual,
drop distinct same-sized images, and discard legitimate body or header
pictures using dimension and payload-length guesses. The repair deduplicates
only the same visual at the same placement. Continuous sections carry the
recorded body-frame prefix and regenerate header/footer frames, avoiding
lossy filtering of body pictures afterward.

The new 11-case suite includes native DOCX roundtrips, header and footer
projections, equal-length distinct PNG payloads, separate placements, body
pictures near a header and continuous sections. Development reproduction
passed two cases and failed nine before the repair; all 11 passed afterward
and again in the sealed frozen run. An additional 18-case development layout
check is retained as corroboration and is not added to the accepted counts.

### Explicit first-row formatting

Two authored XML cases reproduced first-row table styles replacing explicit
custom/default-black text colors and explicit `w:b` values of `0` or `false`.
The small deserializer repair respects the existing direct-property markers
for `color` and `b`. Both cases failed before the repair; all 17 cases in the
whole style/layout suite passed afterward and in the frozen run.

Development evidence is labeled as such and is not substituted for the sealed
final run. The archive preserves its source hashes, raw failures, successful
reruns and incoming/final source snapshots.

### Contained Indic text fixture

The frozen run found one exact-line expectation in
`word_contained_text_wrap_test.dart` that assumed a 42-point outer cell with
5.4-point padding on each side: 31.2 points of content width. Incoming main's
intentional 4.25-point padding expands that same cell's text area to 33.5
points. The first line can then legitimately contain `A` plus the first
complete Indic conjunct. No codepoint or cluster ownership was lost.

The test-only correction defines a 31.2-point content width and derives the
outer grid as `contentWidth + 2 * LaidOutLine.tableCellPad`. It retains every
exact glyph-index, containment, text, direct-save, isolate-save and repeated
roundtrip assertion. The whole 41-case suite passed. The accepted native union
replaces all 41 prior cases from that file, including its original failure;
the other 271 native cases have unchanged production and test inputs.

## Eight explicit editor exclusions

All exclusions occur in `word_incremental_layout_equivalence_test.dart` and
emit the exact reason **`no paragraphs to edit`**. Their full case-name prefix
is `incremental layout equals full layout fixture `, followed by each exact
fixture path below. The files load but contain no editable paragraphs for
this editing-equivalence harness. They were not changed or counted as passes.

| Exact fixture path after the case-name prefix | Reason |
| --- | --- |
'''
for case in exclusions:
    prefix = 'incremental layout equals full layout fixture '
    assert case['name'].startswith(prefix)
    readme += '| ' + case['name'][len(prefix):] + ' | no paragraphs to edit |\n'
readme += '''
Full case names, files, occurrences and reasons are also in accepted-summary.json
and the raw editor events. The passing editor scope covers 66 incremental
equivalence scenarios, 19 header/footer navigation cases, ten page-layout
cases, seven font-loader cases and one inline-picture history case. No extra
image-only probe was run.

## Font alias coverage and other limits

The existing font-loader tests use display-style filenames such as Arial.ttf,
Arial Bold.ttf and Arial Italic.ttf, with licensed Liberation-based fixtures
and synthetic family metadata. They exercise metadata validation, limits,
precedence, rejection and fallback. The eight new lowercase entries
`arial.ttf`, `arialbd.ttf`, `ariali.ttf`, `arialbi.ttf`, `times.ttf`,
`timesbd.ttf`, `timesi.ttf` and `timesbi.ttf` were source-reviewed and
statically analyzed. No alias-specific runtime probe or default host discovery
on macOS, Windows or Linux is claimed.

The raw initial runner's selection-rationale sentence overstates alias-specific
fixture coverage. It is preserved verbatim for integrity; the
[qualification clarifications](qualification-clarifications.md) and this
report supply the correction.

No installed Microsoft Word host, live COM object model or full VBA
compatibility is claimed. DOCM tests retain opaque VBA bytes and the documented
native XML ownership boundaries; they do not validate cryptographic signatures
after modification. Existing replacement of an edited `w:ind` group is unchanged.

## Evidence, runtimes and reproduction

[local-qualification.tar.gz](local-qualification.tar.gz) contains the unmodified
frozen and focused receipts; all raw test, analyzer, formatter and portable
execution logs; case identities and the accepted native union; before/after
source/runtime seals; both repair reproductions; the exact executed Python
runners and environment scripts; and relevant pinned runtime metadata.
It also retains the follow-up runner's initial preflight rejection, which
stopped before any product test because its path allowlist omitted the already
authorized Mail formatter file. That scope assertion was corrected before
the successful run; no source or test expectation was altered for it.

The archive includes historical macro case identities to independently verify
the 709-case overlap. SDKs, package caches, test/build outputs, compiled kernels,
fonts and generated JavaScript bundles are excluded. Source snapshots and BAS
drivers are text inputs, not generated build outputs.

The [manifest](receipt-manifest.json) records the size and SHA-256 of every
uncompressed archived member and the archive itself. Members are sorted;
tar timestamps, ownership and modes are fixed; gzip timestamp and filename
are fixed. Two serializations were compared byte-for-byte when packaging.

Engine tests used Dart 3.14.1 and the pinned package:test 1.31.1 runner. Editor
tests used Flutter 3.47.8 / Dart 3.13.7. Portable JavaScript ran on Node
v24.22.3. The runtime records include SDK archive/executable hashes, the
workspace dependency resolution, package configuration, and the unchanged
repository lockfile. The earlier engine bootstrap is documented in the linked
measurement report.

To reproduce, use isolated checkouts at the two captured commits and rebuild
the pinned runtimes rather than modifying a shared worktree. Raw command arrays
record every executed argument and working directory. The archived scripts
retain their original absolute environment paths; remap those path constants
in a working copy when relocating the harness. Run `qualify_word_main.py` at
`cdd98460` first, using an empty output directory, then run
`qualify_word_main_followup.py` at `cf25a0a3` against that preserved first output.
The original frozen run is expected to retain the one fixture failure and eight
editor exclusions; the focused correction must pass all 41 cases without skips.
Both runners require a clean captured HEAD and seal their inputs before and
after execution. No GitHub Actions run, check status or workflow result was
awaited or used as a gate.
'''

TARGET.mkdir(parents=True, exist_ok=True)
loose = {
    'README.md': readme.encode(),
    'accepted-summary.json': json_bytes(summary),
    'initial-qualification.json': initial_raw,
    'focused-qualification.json': followup_raw,
    'qualification-clarifications.md': (FROZEN / 'qualification-clarifications.md').read_bytes(),
}
for name, data in loose.items():
    (TARGET / name).write_bytes(data)

members = {}


def add_file(name, path):
    assert name not in members, name
    members[name] = Path(path).read_bytes()


for prefix, directory in [('frozen-run', FROZEN), ('focused-followup', FOLLOWUP)]:
    for path in sorted(directory.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log', '.md'}:
            add_file(prefix + '/' + path.name, path)
for prefix, directory in [
    ('preflight', RUNTIME / 'word-main-followup'),
    ('development/header', RUNTIME / 'word-main-development'),
    ('development/table-format', RUNTIME / 'table-direct-format-review'),
]:
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.suffix in {'.json', '.jsonl', '.log', '.stderr', '.py'}:
            add_file(prefix + '/' + path.relative_to(directory).as_posix(), path)
for name in ['qualify_word_main.py', 'qualify_word_main_followup.py', 'package_word_main_evidence.py']:
    add_file('runners/' + name, RUNTIME / name)
for name, path in {
    'historical/accepted-macro-cases.json': RUNTIME / 'measurement-main-final-retry/accepted-test-cases.json',
    'historical/accepted-suite-union.json': HISTORICAL / 'accepted-suite-union.json',
    'historical/final-word-qualification.json': HISTORICAL / 'final-word-qualification.json',
    'runtime/engine/environment.json': RUNTIME / 'toolchain/environment.json',
    'runtime/engine/env.sh': RUNTIME / 'toolchain/env.sh',
    'runtime/flutter/runtime.json': RUNTIME / 'flutter-toolchain/runtime.json',
    'runtime/flutter/env.sh': RUNTIME / 'flutter-toolchain/env.sh',
    'runtime/flutter/workspace-resolution.json': RUNTIME / 'flutter-toolchain/mail-workspace-resolution.json',
    'runtime/package_config.json': REPO / '.dart_tool/package_config.json',
    'runtime/package_graph.json': REPO / '.dart_tool/package_graph.json',
    'inputs/pubspec.yaml': REPO / 'pubspec.yaml',
    'inputs/pubspec.lock': REPO / 'pubspec.lock',
    'inputs/engine-pubspec.yaml': REPO / 'packages/quds_office_engine/pubspec.yaml',
    'inputs/editor-pubspec.yaml': REPO / 'packages/quds_office_editor/pubspec.yaml',
}.items():
    add_file(name, path)
runtime_seal = json.loads((FROZEN / 'runtime-before.json').read_text())
for path in [REPO / '.dart_tool/package_config.json', REPO / '.dart_tool/package_graph.json',
        RUNTIME / 'qualify_word_main.py', RUNTIME / 'toolchain/environment.json',
        RUNTIME / 'flutter-toolchain/runtime.json']:
    assert sha(path.read_bytes()) == runtime_seal[str(path)], str(path)
for commit, paths in {
    INCOMING_SHA: ['packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
        'packages/quds_office_engine/lib/src/word/serial/word_deserializer.dart'],
    INITIAL_SHA: ['packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
        'packages/quds_office_engine/lib/src/word/serial/word_deserializer.dart',
        'packages/quds_office_engine/test/word_header_picture_identity_test.dart',
        'packages/quds_office_engine/test/word_styles_layout_test.dart',
        'packages/quds_office_engine/test/word_contained_text_wrap_test.dart'],
    FINAL_SHA: ['packages/quds_office_engine/test/word_contained_text_wrap_test.dart',
        'packages/quds_office_engine/example/macros/word_measurements.bas',
        'packages/quds_office_engine/example/macros/word_named_measurements.bas',
        'packages/quds_office_engine/tool/macros/web_vba_word_measurements_smoke.dart',
        'packages/quds_office_engine/tool/macros/web_vba_word_named_measurements_smoke.dart'],
}.items():
    for path in paths:
        members['source-snapshots/' + commit + '/' + path] = git_bytes('show', commit + ':' + path)
members['source-snapshots/cdd-to-cf25-test-only.patch'] = git_bytes('diff', INITIAL_SHA, FINAL_SHA, '--',
    'packages/quds_office_engine', 'packages/quds_office_editor')
members.update(loose)


def make_archive():
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', filename='', mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for name, data in sorted(members.items()):
                assert not name.startswith('/') and '..' not in Path(name).parts
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mtime = 0
                info.mode = 0o644
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                archive.addfile(info, io.BytesIO(data))
    return buffer.getvalue()


archive_data = make_archive()
assert archive_data == make_archive(), 'Archive serialization was not deterministic.'
archive_name = 'local-qualification.tar.gz'
(TARGET / archive_name).write_bytes(archive_data)
manifest = {
    'schema_version': 1, 'source_commit': FINAL_SHA,
    'archive': {'path': archive_name, 'bytes': len(archive_data), 'sha256': sha(archive_data)},
    'member_count': len(members),
    'uncompressed_bytes': sum(map(len, members.values())),
    'deterministic_serialization_verified': True,
    'format': 'Sorted PAX tar, mtime=0, uid/gid=0, empty owner names, mode=0644; gzip mtime=0 and empty filename.',
    'excludes': ['SDKs', 'package caches', 'build/test temporary outputs', 'compiled kernels', 'generated JavaScript', 'font binaries'],
    'members': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())],
    'loose_files': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(loose.items())],
}
(TARGET / 'receipt-manifest.json').write_bytes(json_bytes(manifest))
with tarfile.open(fileobj=io.BytesIO(archive_data), mode='r:gz') as archive:
    assert archive.getnames() == sorted(members)
    for member in archive.getmembers():
        assert member.isfile()
        assert archive.extractfile(member).read() == members[member.name]

historical_readme = HISTORICAL / 'README.md'
old = historical_readme.read_text()
start = old.index('## Latest-main native follow-up\n')
end = old.index('## Result and captured source\n', start)
replacement = '''## Latest-main native follow-up

The later intake of main at
`e975cec13b289fe067ef406cd3044701ecc44744` changes native Word layout and
deserialization, while the measurement compiler remains byte-identical. The
integration repairs header-picture identity/placement handling and preserves
explicit table-header run color and bold-off formatting. The accepted
[latest-main qualification](../word-main-integration-20261120/README.md) binds
the frozen run at `cdd98460c2eed261719c660351f11adc962e2ca5` and the test-only
correction at `cf25a0a3d80ee18d2550161af182bacc4e49d18f`.

That follow-up refreshes 709 macro cases already contained in the historical
3,598-case corpus; they are not added to that count. It accepts 312 native/layout
passes across 26 files by retaining 271 unchanged cases and replacing the
41-case contained-text suite after its geometry correction. Editor checks
passed 103 cases, with eight explicitly documented image-only fixtures skipped
because they have no editable paragraphs. Strict analysis and both actual
BAS examples on VM and optimized JavaScript passed. The eight lowercase font
filename aliases were source-reviewed and statically analyzed only.

The linked report preserves the initial false receipt, the successful focused
correction, exact case identities, source/runtime seals and coverage limits.
The historical numbers and receipts below remain bound to their stated earlier
source; they do not claim that native Word files stayed unchanged through this
later intake.

'''
historical_readme.write_text(old[:start] + replacement + old[end:])
new = historical_readme.read_text()
new_end = new.index('## Result and captured source\n', start)
assert new[:start] == old[:start] and new[new_end:] == old[end:]
print(json.dumps({'directory': str(TARGET), 'files': [
    {'path': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
    for path in sorted(TARGET.iterdir()) if path.is_file()],
    'archive_members': len(members), 'uncompressed_archive_bytes': manifest['uncompressed_bytes'],
    'only_historical_latest_main_section_changed': True}, indent=2))
