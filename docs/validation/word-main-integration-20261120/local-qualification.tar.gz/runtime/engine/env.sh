export QUDS_VALIDATION_ROOT=/workspace/scratch/03cd41fa0e7e/quds_office_suite
export QUDS_DART_ROOT=/workspace/scratch/03cd41fa0e7e/runtime/toolchain/dart-sdk
export PUB_CACHE=/workspace/scratch/03cd41fa0e7e/runtime/toolchain/pub-cache
export TMPDIR=/workspace/scratch/03cd41fa0e7e/runtime/toolchain/tmp
export XDG_CONFIG_HOME=/workspace/scratch/03cd41fa0e7e/runtime/toolchain/config
export XDG_CACHE_HOME=/workspace/scratch/03cd41fa0e7e/runtime/toolchain/cache
export DART_SUPPRESS_ANALYTICS=true
export PATH="$QUDS_DART_ROOT/bin:$PATH"
