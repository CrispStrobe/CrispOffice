import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('phase', choices=['before', 'after'])
args = parser.parse_args()
base = Path('/workspace/scratch/03cd41fa0e7e')
repo = base / 'quds_mail_integration'
runtime = base / 'runtime/toolchain'
out = Path(__file__).resolve().parent
phase = out / args.phase
phase.mkdir(parents=True, exist_ok=True)
tmp = phase / 'tmp'
tmp.mkdir(exist_ok=True)
env = os.environ.copy()
env.update({
    'QUDS_VALIDATION_ROOT': str(repo),
    'QUDS_DART_ROOT': str(runtime / 'dart-sdk'),
    'PUB_CACHE': str(runtime / 'pub-cache'),
    'TMPDIR': str(tmp),
    'XDG_CONFIG_HOME': str(runtime / 'config'),
    'XDG_CACHE_HOME': str(runtime / 'cache'),
    'DART_SUPPRESS_ANALYTICS': 'true',
    'PATH': str(runtime / 'dart-sdk/bin') + os.pathsep + env['PATH'],
})
cmd = [
    str(runtime / 'dart-sdk/bin/dart'),
    '--old_gen_heap_size=768',
    '--packages=' + str(repo / '.dart_tool/package_config.json'),
    str(runtime / 'test-runner/test-runner.dill'),
    '--compiler', 'source', '--concurrency=1', '--reporter=json',
    'test/word_styles_layout_test.dart',
]
if args.phase == 'before':
    cmd.extend(['--plain-name', 'first-row table style'])
paths = [
    'packages/quds_office_engine/lib/src/word/serial/word_deserializer.dart',
    'packages/quds_office_engine/test/word_styles_layout_test.dart',
]
def hashes():
    return {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in paths}
before = hashes()
start = time.time()
with (phase / 'stdout.jsonl').open('w') as stdout, (phase / 'stderr.log').open('w') as stderr:
    result = subprocess.run(cmd, cwd=repo / 'packages/quds_office_engine', env=env,
                            stdout=stdout, stderr=stderr)
events = []
for line in (phase / 'stdout.jsonl').read_text().splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        pass
tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
completed = []
for event in events:
    if event.get('type') != 'testDone':
        continue
    test = tests.get(event['testID'], {})
    if event.get('hidden'):
        continue
    completed.append({'name': test.get('name'), 'result': event.get('result'),
                      'skipped': event.get('skipped', False)})
receipt = {
    'scope': 'Development regression evidence only; concurrent disjoint layout edits are not sealed.',
    'phase': args.phase, 'command': cmd,
    'cwd': str(repo / 'packages/quds_office_engine'),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'exit_code': result.returncode, 'elapsed_seconds': round(time.time() - start, 3),
    'owned_source_before': before, 'owned_source_after': hashes(),
    'tests': completed,
    'case_counts': {
        'total': len(completed),
        'success': sum(t['result'] == 'success' and not t['skipped'] for t in completed),
        'failure': sum(t['result'] == 'failure' for t in completed),
        'skipped': sum(t['skipped'] for t in completed),
    },
    'done': [e for e in events if e.get('type') == 'done'],
    'errors': [e for e in events if e.get('type') == 'error'],
}
(phase / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(result.returncode)
