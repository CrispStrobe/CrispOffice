#!/usr/bin/env python3
"""Verify a publication/main head against the exact accepted newer-main delta."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import subprocess

REPORT = "docs/validation/office-main-sync-20261119/"
DOCUMENTS = {"README.md", "docs/roadmaps/mail/status.md", "docs/PROOFING.md", "docs/roadmaps/arabic-proofing.md"}


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "runtime", "outer", "independent-summary", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    for name in ("source", "target"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--reviewed-documents", type=Path)
    args = parser.parse_args()
    repo, runtime, outer = args.repo.resolve(), args.runtime.resolve(), args.outer.resolve()
    issues = []

    def check(condition: bool, message: str) -> None:
        if not condition:
            issues.append(message)

    def git(*values: str) -> bytes:
        return subprocess.check_output(["git", "--no-replace-objects", "-C", str(repo), *values])

    def read(path: Path):
        return json.loads(path.read_bytes())

    def tree(source: str):
        result = {}
        for entry in git("ls-tree", "-r", "-z", source).split(b"\0"):
            if entry:
                metadata, path = entry.split(b"\t", 1)
                mode, kind, blob = metadata.decode().split()
                result[path.decode()] = {"mode": mode, "kind": kind, "blob": blob}
        return result

    source = git("rev-parse", args.source + "^{commit}").decode().strip()
    target = git("rev-parse", args.target + "^{commit}").decode().strip()
    original, published = tree(source), tree(target)
    independent_raw = args.independent_summary.read_bytes()
    independent = json.loads(independent_raw)
    execution_raw = (outer / "execution.json").read_bytes()
    execution = json.loads(execution_raw)
    check(independent["passed"] is True and independent["source_commit"] == source, "Accepted exact-source independent delta qualification")
    check(execution["status"] == "PASS" and execution["source_commit"] == source and digest(execution_raw) == independent["outer_execution_sha256"], "Original execution is accepted, unchanged and bound to independent audit")
    for row in independent["runs"]:
        path = args.independent_summary.parent / row["audit_file"]
        check(digest(path.read_bytes()) == row["audit_sha256"] and read(path)["passed"] is True, "Original independent component receipt: " + row["name"])
    for name, expected in execution["manifest_sha256"].items():
        check(digest((outer / name).read_bytes()) == expected, "Original outer manifest hash: " + name)
    check(execution["source_unchanged"] is True and execution["runtime_unchanged"] is True, "Original completed outer source/runtime stability")
    manifests = {"outer": read(outer / "source-before.json")}
    runtime_manifests = {"outer": read(outer / "runtime-before.json")}
    check(manifests["outer"] == read(outer / "source-after.json") and runtime_manifests["outer"] == read(outer / "runtime-after.json"), "Original outer before/after evidence remains identical")
    original_product = {path for path in original if path.startswith(("packages/", "apps/", "third_party/", "tools/mail/", "tools/proofing/ayaspell/"))
                        or ("/" not in path and Path(path).suffix in {".yaml", ".lock"}) or path == ".fvmrc"}
    published_product = {path for path in published if path.startswith(("packages/", "apps/", "third_party/", "tools/mail/", "tools/proofing/ayaspell/"))
                         or ("/" not in path and Path(path).suffix in {".yaml", ".lock"}) or path == ".fvmrc"}
    check(original_product == published_product, "Exact original application/test/configuration/helper inventory")
    for label in ("native", "node"):
        gate = outer / label
        receipt = read(gate / "verification.json")
        check(receipt["success"] is True and receipt["source_commit"] == source, "Original accepted " + label + " execution source")
        for filename, expected in receipt["manifest_sha256"].items():
            check(digest((gate / filename).read_bytes()) == expected, label + ": manifest hash: " + filename)
        before, after = read(gate / "source-before.json"), read(gate / "source-after.json")
        check(before == after, label + ": original source manifests identical")
        manifests[label] = {path: row["sha256"] for path, row in before.items()}
        for path, row in before.items():
            check(original[path] == {"mode": row["mode"], "kind": "blob", "blob": row["git_blob"]}, label + ": original Git source identity: " + path)
        runtime_manifests[label] = read(gate / "environment-before.json")
        check(runtime_manifests[label] == read(gate / "environment-after.json"), label + ": original runtime manifests identical")
    bound = set().union(*(set(manifest) for manifest in manifests.values()))
    approved = {}
    review_hash = None
    if args.reviewed_documents is not None:
        review_raw = args.reviewed_documents.read_bytes()
        review = json.loads(review_raw)
        review_hash = digest(review_raw)
        check(review["source_commit"] == source, "Document review bound to exact qualification source")
        for row in review["documents"]:
            path = row["path"]
            check(path in DOCUMENTS and path not in approved, "Explicit distinct allowed Markdown path: " + path)
            check(bool(row.get("reason")), "Concrete reviewed document change reason: " + path)
            before = git("show", source + ":" + path)
            after = git("show", target + ":" + path)
            check(digest(before) == row["before_sha256"] and digest(after) == row["after_sha256"], "Exact reviewed before/after Markdown bytes: " + path)
            check(original[path]["mode"] == published[path]["mode"] == "100644" and published[path]["kind"] == "blob", "Regular Markdown mode retained: " + path)
            approved[path] = {**row, "before_blob": original[path]["blob"], "after_blob": published[path]["blob"],
                              "actual_diff_sha256": digest(git("diff", "--no-ext-diff", "--binary", source, target, "--", path)), "bound_input": path in bound}
    query = "".join(original[path]["blob"] + "\n" for path in sorted(bound)).encode()
    stream = io.BytesIO(subprocess.run(["git", "--no-replace-objects", "cat-file", "--batch"], cwd=repo, input=query, stdout=subprocess.PIPE, check=True).stdout)
    original_hashes = {}
    for path in sorted(bound):
        object_id, kind, size = stream.readline().decode().split()
        raw = stream.read(int(size))
        check(stream.read(1) == b"\n" and kind == "blob" and object_id == original[path]["blob"], "Complete immutable source object: " + path)
        original_hashes[path] = digest(raw)
    check(not stream.read(), "All immutable source objects consumed")
    gates = {}
    for label, manifest in manifests.items():
        altered = sorted(path for path in manifest if original.get(path) != published.get(path))
        unexpected = [path for path in altered if path not in approved]
        check(not unexpected, label + ": no unreviewed bound input changes")
        for path, expected in manifest.items():
            check(original_hashes[path] == expected, label + ": unchanged original qualification hash: " + path)
        gates[label] = {"inputs": len(manifest), "changed_bound_paths": altered, "unexpected_bound_changes": unexpected}
    materialized_mismatches = []
    for path in bound:
        expected = approved[path]["after_sha256"] if path in approved else original_hashes[path]
        current = repo / path
        if not current.is_file() or current.is_symlink() or digest(current.read_bytes()) != expected:
            materialized_mismatches.append(path)
    check(not materialized_mismatches, "Materialized qualified source matches publication target")

    def runtime_path(name: str) -> Path:
        if name.startswith("runtime/"):
            return runtime / name.removeprefix("runtime/")
        if name.startswith("additional/"):
            return Path(name.removeprefix("additional/"))
        if name.startswith("fixture/"):
            return Path(execution["fixture_root"]) / name.removeprefix("fixture/")
        if name == "python/executable":
            return Path(execution["python_executable"])
        if name in {"workspace/package_config.json", "workspace/package_graph.json", "workspace/native_assets.yaml"}:
            return repo / ".dart_tool" / name.removeprefix("workspace/")
        if name.startswith("workspace/"):
            return repo / name.removeprefix("workspace/")
        if name == "sdk/flutter_tools/package_config.json":
            return runtime / "flutter/packages/flutter_tools/.dart_tool/package_config.json"
        raise ValueError("Unknown runtime identity: " + name)

    runtime_cache, runtime_mismatches = {}, []
    for label, manifest in runtime_manifests.items():
        for name, expected in manifest.items():
            path = runtime_path(name)
            if path not in runtime_cache:
                runtime_cache[path] = digest(path.read_bytes()) if path.is_file() else None
            if runtime_cache[path] != expected or (expected is None and (path.exists() or path.is_symlink())):
                runtime_mismatches.append(label + ":" + name)
    check(not runtime_mismatches, "Actual accepted runtime/fixtures still match all original snapshots")
    changed = sorted(path for path in original.keys() | published.keys() if original.get(path) != published.get(path))
    unexpected_paths = [path for path in changed if path not in approved and not path.startswith(REPORT)]
    bad_entries = [path for path in changed if path not in published or published[path]["kind"] != "blob" or published[path]["mode"] not in {"100644", "100755"}]
    check(not unexpected_paths, "Publication changes confined to reviewed documents and report directory")
    check(not bad_entries, "No removal or redirect of source/evidence")
    ancestor = subprocess.run(["git", "--no-replace-objects", "merge-base", "--is-ancestor", source, target], cwd=repo).returncode == 0
    check(ancestor, "Qualified delta source is an ancestor of publication")
    bound_changes = sorted(path for path in bound if original.get(path) != published.get(path))
    result = {"passed": not issues, "issues": issues, "qualified_source": source, "qualified_source_tree": git("rev-parse", source + "^{tree}").decode().strip(),
              "checked_publication": target, "checked_publication_tree": git("rev-parse", target + "^{tree}").decode().strip(),
              "audited_at_utc": datetime.now(timezone.utc).isoformat(), "source_ancestor": ancestor,
              "original_execution_source_preserved": True, "original_delta_application_executions": independent["application_case_executions"],
              "original_delta_python_controls": independent["separate_python_controls"], "original_prior_qualification": independent["prior_qualification"],
              "distinct_bound_inputs": len(bound), "gates": gates, "all_bound_inputs_identical": not bound_changes,
              "approved_document_changes": list(approved.values()), "approved_document_receipt_sha256": review_hash,
              "application_tests_plans_configuration_unchanged": original_product == published_product and all(not row["unexpected_bound_changes"] for row in gates.values()),
              "materialized_input_mismatches": materialized_mismatches, "runtime_inputs_reverified_by_scope": {name: len(value) for name, value in runtime_manifests.items()},
              "runtime_input_mismatches": runtime_mismatches, "publication_changed_paths": changed, "unexpected_publication_paths": unexpected_paths,
              "nonregular_or_deleted_paths": bad_entries, "independent_summary_sha256": digest(independent_raw), "outer_execution_sha256": digest(execution_raw),
              "audit_script_sha256": digest(Path(__file__).read_bytes()), "new_application_tests_executed_by_audit": 0,
              "method": "Immutable Git mode/type/blob and SHA-256 continuity, unchanged original event-audit receipts, complete inventories and current runtime/fixture readback. Optional Markdown changes require exact reviewed source and before/after hashes. All run results retain their original source identities."}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("passed", "issues", "qualified_source", "checked_publication", "distinct_bound_inputs", "all_bound_inputs_identical", "application_tests_plans_configuration_unchanged")}, indent=2))
    return int(bool(issues))


if __name__ == "__main__":
    raise SystemExit(main())
