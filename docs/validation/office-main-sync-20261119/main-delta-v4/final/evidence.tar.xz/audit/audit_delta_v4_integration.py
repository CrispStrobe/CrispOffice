#!/usr/bin/env python3
"""Independently recount the second main delta; preserve every prior source identity."""
from __future__ import annotations

import argparse
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import plistlib
import re
import subprocess
import sys

PRIOR = "0669ac119da05f5eb777c8cfdbce32e0261df647"
MAIN = "9160eb0dba211225c85242114989631c0d14fb72"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def raw_sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "outer", "runtime", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    for name in ("source", "driver", "native-plan", "node-plan"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    repo, outer, runtime, output = (getattr(args, key).resolve() for key in ("repo", "outer", "runtime", "output"))
    if output.exists() and any(output.iterdir()):
        raise RuntimeError("Use a new audit output directory and preserve earlier attempts")
    output.mkdir(parents=True, exist_ok=True)
    helper = Path(__file__).resolve().parent / "audit_delta_gate.py"
    issues, invocations, inventory, groups = [], [], [], []
    details = {}

    def check(condition: bool, message: str) -> None:
        if not condition:
            issues.append(message)

    def git(*values: str) -> bytes:
        return subprocess.check_output(["git", "--no-replace-objects", "-C", str(repo), *values])

    def frozen(path: str, source: str | None = None) -> bytes:
        return git("show", (source or args.source) + ":" + path)

    def read(path: Path) -> dict:
        return json.loads(path.read_bytes())

    record = read(outer / "execution.json")
    try:
        check(record["status"] == "PASS" and bool(record.get("finished_at_utc")), "Complete successful outer execution")
        check(record["source_commit"] == args.source and record["source_tree"] == git("rev-parse", args.source + "^{tree}").decode().strip(), "Outer exact source/tree identity")
        check(record["source_base"] == MAIN and record["prior_qualified_source"] == PRIOR, "Explicit old source and incoming main identities")
        check(record["prior_application_cases_added_to_delta"] == record["prior_python_controls_added_to_delta"] == 0, "Prior results are not counted in this delta")
        check(record["rejected_attempts_added_to_delta"] == 0 and record["rejected_attempt_sources"] == ["aea5d91af0083bc088d599ed767188f0bb071195", "c0c71a26e014cadda7a1f42244e710509dea5f6c", "fce543dedb1217804f67de088ef9c287e8a2edca", "26df787326f58a002b62241b7feb52acff089f2f"], "Rejected attempts remain separate")
        check(record["github_actions_queried_or_awaited"] is False, "No hosted CI dependence")
        check(all(record[key] is True for key in ("source_unchanged", "runtime_unchanged", "source_head_unchanged", "tracked_worktree_clean_after")), "Outer source/runtime stability")
        check(git("rev-parse", "HEAD").decode().strip() == args.source and not git("status", "--porcelain=v1", "--untracked-files=no").strip(), "Current source is exact and clean")
        for filename, expected in record["manifest_sha256"].items():
            check(sha(outer / filename) == expected, "Outer manifest hash: " + filename)
        source_before, source_after = (read(outer / ("source-" + phase + ".json")) for phase in ("before", "after"))
        runtime_before, runtime_after = (read(outer / ("runtime-" + phase + ".json")) for phase in ("before", "after"))
        check(source_before == source_after and runtime_before == runtime_after, "Exact before/after fingerprint equality")
        tree = {}
        for entry in git("ls-tree", "-r", "-z", args.source).split(b"\0"):
            if entry:
                metadata, path = entry.split(b"\t", 1)
                mode, kind, blob = metadata.decode().split()
                tree[path.decode()] = {"mode": mode, "kind": kind, "blob": blob}
        plans = {name: json.loads(frozen(path)) for name, path in (("native", args.native_plan), ("node", args.node_plan))}
        for filename in ("README.md", "delta-native-plan.json", "delta-node-plan.json", "fixture-plan.json", "proposal-manifest.json", "reviewed-source-overrides.json", "run-delta-validation.py", "verify-delta-continuity.py"):
            path = "docs/validation/office-main-sync-20261119/main-delta-v3/" + filename
            check(frozen(path) == frozen(path, "26df787326f58a002b62241b7feb52acff089f2f"), "Rejected v3 plan bytes remain unchanged: " + path)
        for label in ("native", "node"):
            previous = json.loads(frozen("docs/validation/office-main-sync-20261119/main-delta-v3/delta-" + label + "-plan.json", "26df787326f58a002b62241b7feb52acff089f2f"))
            old_selection = {(group["cwd"] + "/" + name, group.get("platform", "vm")) for group in previous["groups"] for name in group["tests"]}
            new_selection = {(group["cwd"] + "/" + name, group.get("platform", "vm")) for group in plans[label]["groups"] for name in group["tests"]}
            check(old_selection == new_selection, "Complete rejected v3 suite/platform selection is repeated exactly: " + label)
        report_directory = str(Path(args.driver).parent)
        fixture_plan_path = report_directory + "/fixture-plan.json"
        continuity_script = report_directory + "/verify-delta-continuity.py"
        fixture_plan = json.loads(frozen(fixture_plan_path))
        required = {args.driver, args.native_plan, args.node_plan, fixture_plan_path, continuity_script}
        expected_source = {name for name in tree if name.startswith(("packages/", "apps/", "third_party/", "tools/mail/", "tools/proofing/ayaspell/"))
                           or ("/" not in name and Path(name).suffix in {".yaml", ".lock"}) or name == ".fvmrc"}
        expected_source |= required | set(plans["native"]["extra_inputs"]) | set(plans["node"]["extra_inputs"])
        expected_source.add("docs/validation/document-review-notes-20261118/run_checks.py")
        check(set(source_before) == expected_source, "Complete outer source inventory")
        query = "".join(tree[path]["blob"] + "\n" for path in sorted(source_before)).encode()
        batch = subprocess.run(["git", "--no-replace-objects", "cat-file", "--batch"], input=query, stdout=subprocess.PIPE, check=True, cwd=repo).stdout
        stream = io.BytesIO(batch)
        for path in sorted(source_before):
            object_id, kind, size = stream.readline().decode().strip().split()
            raw = stream.read(int(size))
            check(stream.read(1) == b"\n" and kind == "blob" and object_id == tree[path]["blob"], "Immutable source object read: " + path)
            check(raw_sha(raw) == source_before[path] == sha(repo / path), "Immutable/current source bytes: " + path)
        check(not stream.read(), "No unread source object data")
        changed_dart = set()
        for base in (PRIOR, MAIN):
            check(subprocess.run(["git", "--no-replace-objects", "merge-base", "--is-ancestor", base, args.source], cwd=repo).returncode == 0, "Required ancestor: " + base)
            changed_dart.update(path.decode() for path in git("diff", "--name-only", "--diff-filter=ACMRT", "-z", base, args.source).split(b"\0")
                                if path.endswith(b".dart") and path.startswith((b"packages/", b"apps/", b"third_party/")))
        check(changed_dart <= set(plans["native"]["analysis"]) and changed_dart <= set(plans["native"]["format"]), "Strict checks cover changed Dart against both sources")
        runtime_receipt = read(runtime / "runtime.json")
        check(sha(runtime / "runtime.json") == record["runtime_receipt_sha256"], "Original runtime receipt hash")
        retained = read(runtime / "retained-inputs.json")
        runtime_paths = {"runtime/" + name: runtime / name for name in retained}
        for name in ("runtime.json", "retained-inputs.json", "pub-cache-receipt.json", "cache-omissions.json", "archive-members.json", "env.sh", "bin/dart", "bin/flutter"):
            runtime_paths["runtime/" + name] = runtime / name
        runtime_paths.update({"additional/" + name: Path(name) for name in runtime_receipt["additional_inputs"]})
        fixture_root = Path(record["fixture_root"])
        runtime_paths.update({"fixture/" + name: fixture_root / name for name in fixture_plan["files"]})
        runtime_paths["python/executable"] = Path(record["python_executable"])
        runtime_paths["sdk/flutter_tools/package_config.json"] = runtime / "flutter/packages/flutter_tools/.dart_tool/package_config.json"
        runtime_paths.update({"workspace/" + name: repo / ".dart_tool" / name for name in ("package_config.json", "package_graph.json")})
        check(set(runtime_before) == set(runtime_paths), "Complete outer runtime/fixture inventory")
        for name, path in runtime_paths.items():
            check(sha(path) == runtime_before.get(name), "Actual runtime/fixture bytes: " + name)
        for name, row in retained.items():
            check(runtime_before["runtime/" + name] == row["sha256"] and (runtime / name).stat().st_size == row["bytes"], "Original retained runtime identity: " + name)
        stable = read(outer / "runtime-pre-resolution.json")
        check(stable == {name: value for name, value in runtime_before.items() if name not in {"workspace/package_config.json", "workspace/package_graph.json"}}, "Only declared workspace files added after offline resolution")
        expected_env = {name: str(fixture_root / relative) for name, relative in fixture_plan["environment_paths"].items()}
        expected_env.update(fixture_plan["literal_environment"])
        check(record["native_environment"] == expected_env and expected_env["QUDS_HUNSPELL_LIVE_DOWNLOAD"] == "1", "Full native/live fixture environment")
        for path, expected in fixture_plan["source_bindings"].items():
            check(raw_sha(frozen(path)) == source_before[path] == expected, "Compiled fixture/catalog source identity: " + path)
        for name, row in fixture_plan["files"].items():
            check(sha(fixture_root / name) == row["sha256"] and (fixture_root / name).stat().st_size == row["bytes"], "Frozen native fixture file: " + name)
        native_build = read(fixture_root / "native-build-receipt.json")
        shim_build = read(fixture_root / "lifecycle-shim-build-receipt.json")
        download = read(fixture_root / "dictionary-download-receipt.json")
        check(native_build["status"] == "PASS" and native_build["exit_code"] == 0 and native_build["inputs_unchanged"] is True, "Native build provenance result")
        check(native_build["artifact"]["sha256"] == fixture_plan["files"]["native/libquds_proofing_hunspell.so"]["sha256"], "Exact real native library build artifact")
        check(shim_build["status"] == "PASS" and shim_build["exit_code"] == 0 and shim_build["artifact_sha256"] == fixture_plan["files"]["native/libhunspell_lifecycle_shim.so"]["sha256"], "Exact lifecycle-counter build artifact")
        check(shim_build["source_sha256"] == raw_sha(frozen("packages/quds_proofing_hunspell/test/support/hunspell_lifecycle_shim.cpp")), "Compiled lifecycle source equals current source")
        check(download["status"] == "PASS" and len(download["files"]) == 8 and download["catalog_sha256"] == raw_sha(frozen("packages/quds_proofing_hunspell/lib/src/hunspell_catalog.dart")), "Eight dictionary files bound to current pinned catalog")
        for row in download["files"]:
            expected = fixture_plan["files"]["dictionary/" + row["file"]]
            check(row["status"] == "PASS" and row["sha256"] == row["expected_sha256"] == expected["sha256"] and row["bytes"] == row["expected_bytes"] == expected["bytes"], "Verified pinned dictionary artifact: " + row["file"])
        names = ["locked-workspace-resolution", "delta-continuity", "bundle-controls", "packaging-controls", "native", "node", "hunspell-browser-compile"]
        check([row["name"] for row in record["runs"]] == names, "Exact complete delta command inventory/order")
        runs = {row["name"]: row for row in record["runs"]}
        for name, row in runs.items():
            check(row["exit_code"] == 0 and row["accepted"] is True and row["cwd"] == str(repo), "Accepted command and directory: " + name)
            check(sha(outer / row["log"]) == row["log_sha256"], "Command log hash: " + name)
            if "receipt" in row:
                check(sha(outer / row["receipt"]) == row["receipt_sha256"], "Child receipt binding: " + name)
        check(runs["locked-workspace-resolution"]["command"] == [str(runtime / "bin/dart"), "pub", "get", "--offline", "--enforce-lockfile"], "Exact direct Dart offline locked resolver")
        continuity = read(outer / "continuity.json")
        check(continuity["passed"] is True and continuity["source_commit"] == args.source, "Accepted exact-source continuity receipt")
        prior_summary = read(outer / "prior-independent-summary.json")
        check(prior_summary["passed"] is True and prior_summary["source_commit"] == PRIOR and prior_summary["application_case_executions"] == 1372 and prior_summary["separate_python_controls"] == 90, "Preserved original independent qualification")
        check(prior_summary["runtime_receipt_sha256"] == sha(runtime / "runtime.json"), "Original runtime receipt remains unchanged")
        original_runtime = read(outer / "prior-runtime-before.json")
        changes = sorted(name for name, original in original_runtime.items() if runtime_before.get(name) != original)
        check(changes == ["workspace/package_config.json"], "Only original runtime change is the declared workspace mapping")
        old_dart = set(path.decode() for path in git("ls-tree", "-r", "--name-only", "-z", PRIOR).split(b"\0") if path.endswith(b".dart") and path.startswith((b"packages/", b"apps/", b"third_party/")))
        changed_existing = sorted(old_dart & set(path.decode() for path in git("diff", "--name-only", "-z", PRIOR, args.source).split(b"\0")))
        overrides_path = report_directory + "/reviewed-source-overrides.json"
        override_raw = frozen(overrides_path)
        override_data = json.loads(override_raw)
        check(override_data["status"] == "REVIEWED" and override_data["prior_qualified_source"] == PRIOR
              and override_data["incoming_main_source"] == MAIN, "Exact reviewed source override scope")
        overrides = {}
        for row in override_data["paths"]:
            path = row["path"]
            check(path not in overrides and bool(row.get("reason"))
                  and (path == ".github/workflows/crispoffice-binaries.yml"
                       or (path.startswith(("packages/quds_office_engine/", "packages/quds_office_editor/", "packages/quds_proofing_hunspell/", "tools/proofing/ayaspell/", "docs/"))
                           and Path(path).suffix in {".dart", ".yaml", ".md", ".py", ".cpp"})),
                  "Scoped explicit source override: " + path)
            check(raw_sha(frozen(path)) == row["after_sha256"], "Exact reviewed resulting source bytes: " + path)
            if row.get("incoming_sha256") is not None:
                check(raw_sha(frozen(path, MAIN)) == row["incoming_sha256"], "Exact reviewed incoming source bytes: " + path)
            overrides[path] = row
        prior_paths = set(path.decode() for path in git("ls-tree", "-r", "--name-only", "-z", PRIOR).split(b"\0") if path)
        main_paths = set(path.decode() for path in git("ls-tree", "-r", "--name-only", "-z", MAIN).split(b"\0") if path)
        deleted = {path for path in prior_paths - main_paths if path.startswith("packages/quds_office_editor/example/assets/al_tahreer/")
                   or path == "packages/quds_office_editor/example/lib/al_tahreer_sample.dart"}
        check(len(deleted) == 36 and not (deleted & set(tree)), "Exact incoming retirement of 35 assets and one sample source")
        for path in changed_existing:
            if path in deleted:
                check(path not in tree, "Retired source remains absent: " + path)
            elif path in overrides:
                check(raw_sha(frozen(path)) == overrides[path]["after_sha256"], "Reviewed changed original Dart path: " + path)
            else:
                check(frozen(path) == frozen(path, MAIN), "Exact incoming changed original Dart path: " + path)
        latest_paths = {path.decode() for path in git("diff", "--name-only", "-z", "b655b8a37fddc874bd42a453c371eed6253e82d8", MAIN).split(b"\0")
                        if path.startswith((b"packages/", b"apps/", b"third_party/"))}
        for path in sorted(latest_paths - deleted):
            if path not in overrides:
                check(frozen(path) == frozen(path, MAIN), "All latest incoming Arabic/Studio work retained exactly unless reviewed: " + path)
        for path in sorted(set(tree) - prior_paths):
            if path.startswith(("packages/", "apps/", "third_party/")) and path not in overrides:
                check(path in main_paths and frozen(path) == frozen(path, MAIN),
                      "Every added product path equals incoming main or an exact reviewed override: " + path)
        old_graph, new_graph = read(outer / "prior-resolution/.dart_tool/package_graph.json"), read(outer / "package_graph.json")
        old_nodes, new_nodes = ({row["name"]: row for row in graph["packages"]} for graph in (old_graph, new_graph))
        expected_studio = dict(old_nodes["quds_office_studio"])
        expected_studio["dependencies"] = sorted(expected_studio["dependencies"] + ["quds_mail_core", "quds_mail_mime", "quds_mail_ui", "quds_proofing_hunspell", "url_launcher"])
        check(new_nodes.get("quds_office_studio") == expected_studio, "Exact Studio graph addition of the three Mail packages, Hunspell and the existing URL launcher")
        check(set(new_nodes) - set(old_nodes) == {"quds_proofing_hunspell"} and set(old_nodes) <= set(new_nodes)
              and all(new_nodes.get(name) == row for name, row in old_nodes.items() if name != "quds_office_studio"),
              "Every other prior dependency graph node unchanged")
        check(frozen("packages/quds_office_editor/example/pubspec.yaml") == frozen("packages/quds_office_editor/example/pubspec.yaml", MAIN), "Exact incoming Studio package dependency/assets manifest")
        preserved_fixes = ["packages/quds_mail_transport/" + path for path in ("lib/src/cursor.dart", "lib/src/native/provider.dart", "test/cursor_test.dart", "test/host_store_integration_test.dart", "test/uid_discovery_test.dart")]
        check(all(frozen(path) == frozen(path, PRIOR) for path in preserved_fixes), "All five original Mail cursor fix paths preserved")
        details.update(reviewed_source_overrides=list(overrides.values()), reviewed_override_file_sha256=raw_sha(override_raw),
                       intentionally_removed_prior_paths=sorted(deleted), changed_dependency_graph_nodes={"quds_office_studio": {"before": old_nodes["quds_office_studio"], "after": new_nodes.get("quds_office_studio")}})
        for path in (args.driver, args.native_plan, args.node_plan, continuity_script, fixture_plan_path):
            check(path in source_before and raw_sha(frozen(path)) == source_before[path], "Frozen qualification input: " + path)
        python_run = runs["bundle-controls"]
        check(Path(python_run["command"][0]).resolve() == Path(record["python_executable"])
              and python_run["command"][1:] == ["-B", "-m", "unittest", "discover", "-s", "tools/proofing/ayaspell", "-p", "test_build_bundle*.py", "-v"],
              "Exact verbose bundle control command and canonical bound interpreter")
        raw = (outer / python_run["log"]).read_bytes()
        rows = re.findall(r"^(test\S+) \(([^)]+)\) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$", raw.decode(), re.MULTILINE)
        terminal = re.findall(rb"Ran (\d+) tests? in [^\n]+\n\s*\nOK\s*$", raw)
        check(len(terminal) == 1 and int(terminal[0]) == len(rows) == 17, "Exact seventeen successful verbose Python identities")
        expected = {}
        control_paths = ["tools/proofing/ayaspell/" + name for name in ("test_build_bundle.py", "test_build_bundle_incoming.py", "test_build_bundle_reproducibility.py")]
        for path in control_paths:
            for cls in ast.parse(frozen(path)).body:
                if isinstance(cls, ast.ClassDef):
                    for method in cls.body:
                        if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)) and method.name.startswith("test"):
                            expected[Path(path).stem + "." + cls.name + "." + method.name] = path + "::" + cls.name + "." + method.name
        check(len(rows) == len({owner for _, owner, _ in rows}) and all(result == "ok" and owner.endswith("." + method) for method, owner, result in rows), "Distinct successful Python cases")
        check({owner for _, owner, _ in rows} == set(expected), "Exact frozen Python AST case inventory")
        python_details = {"passed_cases": len(rows), "case_identities": [expected[owner] for _, owner, _ in rows if owner in expected], "raw_log_sha256": raw_sha(raw), "frozen_sources": control_paths}
        packaging_run = runs["packaging-controls"]
        check(Path(packaging_run["command"][0]).resolve() == Path(record["python_executable"])
              and packaging_run["command"][1:] == ["-B", "-m", "unittest", "discover", "-s", "packages/quds_proofing_hunspell/tool", "-p", "test_build.py", "-v"],
              "Exact verbose offline packaging control command and bound interpreter")
        packaging_raw = (outer / packaging_run["log"]).read_bytes()
        packaging_rows = re.findall(r"^(test\S+) \(([^)]+)\) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$", packaging_raw.decode(), re.MULTILINE)
        packaging_terminal = re.findall(rb"Ran (\d+) tests? in [^\n]+\n\s*\nOK\s*$", packaging_raw)
        check(len(packaging_terminal) == 1 and int(packaging_terminal[0]) == len(packaging_rows) == 4,
              "Exact four successful verbose offline packaging identities")
        packaging_path = "packages/quds_proofing_hunspell/tool/test_build.py"
        packaging_expected = {}
        for cls in ast.parse(frozen(packaging_path)).body:
            if isinstance(cls, ast.ClassDef):
                for method in cls.body:
                    if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)) and method.name.startswith("test"):
                        packaging_expected["test_build." + cls.name + "." + method.name] = packaging_path + "::" + cls.name + "." + method.name
        check(len(packaging_rows) == len({owner for _, owner, _ in packaging_rows})
              and all(result == "ok" and owner.endswith("." + method) for method, owner, result in packaging_rows),
              "Distinct successful packaging controls")
        check({owner for _, owner, _ in packaging_rows} == set(packaging_expected), "Exact frozen packaging AST inventory")
        check(frozen("packages/quds_proofing_hunspell/tool/build.py") == frozen("packages/quds_proofing_hunspell/tool/build.py", MAIN),
              "Packaging builder remains the exact incoming implementation")
        packaging_details = {"passed_cases": len(packaging_rows),
                             "case_identities": [packaging_expected[owner] for _, owner, _ in packaging_rows if owner in packaging_expected],
                             "raw_log_sha256": raw_sha(packaging_raw), "frozen_sources": [packaging_path, "packages/quds_proofing_hunspell/tool/build.py"]}
        details["python_controls"] = {"passed_cases": len(rows) + len(packaging_rows),
                                      "bundle": python_details, "packaging": packaging_details}
        for label in ("native", "node"):
            old_plan = json.loads(frozen("docs/validation/office-main-sync-20261119/main-delta-v2/delta-" + label + "-plan.json",
                                        "c0c71a26e014cadda7a1f42244e710509dea5f6c"))
            old_selection = {(group["cwd"] + "/" + name, group.get("platform", "vm")) for group in old_plan["groups"] for name in group["tests"]}
            new_selection = {(group["cwd"] + "/" + name, group.get("platform", "vm")) for group in plans[label]["groups"] for name in group["tests"]}
            check(old_selection <= new_selection, "Every rejected v2 suite/platform is retained: " + label)
        for label, plan_path in (("native", args.native_plan), ("node", args.node_plan)):
            plan = plans[label]
            targets = [{"path": str(Path(group["cwd"]) / name), "platform": group.get("platform", "vm"), "gate": label} for group in plan["groups"] for name in group["tests"]]
            audit_file, audit_log = output / (label + "-audit.json"), output / (label + "-audit.log")
            command = [sys.executable, str(helper), "--repo", str(repo), "--gate", str(outer / label), "--runtime", str(runtime), "--source", args.source,
                       "--plan", plan_path, "--expected-suites", str(len(targets)), "--workspace-resolution", str(outer / "continuity.json"), "--output", str(audit_file)]
            with audit_log.open("wb") as stream:
                process = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
            audit = read(audit_file) if audit_file.is_file() else {"passed": False}
            check(process.returncode == 0 and audit.get("passed") is True, label + ": independent raw/source/runtime audit")
            invocations.append({"name": label, "command": command, "exit_code": process.returncode, "audit_file": audit_file.name,
                                "audit_sha256": sha(audit_file) if audit_file.is_file() else None, "log_sha256": sha(audit_log)})
            inventory.extend(targets)
            groups.extend({"gate": label, **group} for group in audit.get("groups", []))
            details[label] = audit
            expected_command = [record["python_executable"], "-B", str(repo / "docs/validation/document-review-notes-20261118/run_checks.py"), "--head", args.source, "--base", MAIN,
                                "--runtime", str(runtime), "--plan", str(repo / plan_path), "--output", str(outer / label), "--command-timeout"]
            actual_command = runs[label]["command"]
            check(Path(actual_command[0]).resolve() == Path(record["python_executable"])
                  and actual_command[1:-1] == expected_command[1:] and int(actual_command[-1]) > 0,
                  label + ": exact child command and canonical bound interpreter")
        native_cases = read(outer / "native/checks/hunspell-native-cases.json")
        studio_cases = read(outer / "native/checks/studio-main-merge-vm-cases.json")
        for name in ("citation commands stay inactive in other Studio applications",
                     "narrow Arabic comments stay below the editor",
                     "narrow Arabic reply suggestions remain usable with larger text"):
            check(sum(row["name"] == name for row in studio_cases) == 1,
                  "Rejected v2 Studio case actually reran exactly once: " + name)
        names_seen = [row["name"] for row in native_cases]
        check("live download from the pinned Hugging Face revision" in names_seen, "Live pinned-download case actually completed")
        # These two source files declare static literal test names. Match every
        # declaration to one actual same-suite case, accepting the group prefix
        # added by package:test. Refuse a dynamic/concatenated declaration rather
        # than silently estimating its count or relying on a previous source's
        # fixed eight/four totals.
        native_declarations = []
        for filename in ("hunspell_native_lifecycle_test.dart", "hunspell_native_test.dart"):
            path = "packages/quds_proofing_hunspell/test/" + filename
            text = frozen(path).decode()
            declared = re.findall(r"\btest\s*\(\s*(['\"])(.*?)\1\s*,", text, re.DOTALL)
            test_calls = re.findall(r"\btest\s*\(", text)
            names = [name for _, name in declared]
            cases = [row["name"] for row in native_cases if row["suite"].endswith("/test/" + filename)]
            check(len(names) == len(test_calls) == len(cases) and len(names) == len(set(names)), path + ": complete distinct static-name declaration count")
            for name in names:
                check(sum(case == name or case.endswith(" " + name) for case in cases) == 1, path + ": exactly one actual declared case: " + name)
            check(all(sum(case == name or case.endswith(" " + name) for name in names) == 1 for case in cases), path + ": no undeclared or ambiguous completed case")
            native_declarations.append({"path": path, "sha256": raw_sha(frozen(path)), "declared_literal_names": names, "actual_case_names": cases})
        details["native_declaration_inventory"] = native_declarations
        for name, value in record["browser_compile_outputs"].items():
            check(sha(outer / name) == value["sha256"] and (outer / name).stat().st_size == value["bytes"] > 0, "Browser compile artifact: " + name)
        check("hunspell-browser.js" in record["browser_compile_outputs"], "Compiled browser executable exists")
        check(runs["hunspell-browser-compile"]["command"] == [str(runtime / "bin/dart"), "compile", "js", "-O2", "packages/quds_proofing_hunspell/tool/web_compile_check.dart", "-o", str(outer / "hunspell-browser.js")], "Exact browser compile command and source")
        for name in ("DebugProfile.entitlements", "Release.entitlements"):
            value = plistlib.loads(frozen("packages/quds_office_editor/example/macos/Runner/" + name))
            check(all(value.get(key) is True for key in ("com.apple.security.app-sandbox", "com.apple.security.network.client", "com.apple.security.files.user-selected.read-write")), "Static macOS entitlement set: " + name)
        details.update(outer_source_inputs_reverified=len(source_before), outer_runtime_inputs_reverified=len(runtime_before), fixture_inputs_reverified=len(fixture_plan["files"]),
                       changed_prior_runtime_inputs=changes, preserved_original_fix_paths=preserved_fixes, changed_existing_dart_paths=changed_existing,
                       continuity_receipt_sha256=sha(outer / "continuity.json"), prior_independent_summary_sha256=sha(outer / "prior-independent-summary.json"))
    except Exception as error:
        import traceback
        traceback.print_exc()
        issues.append("Independent audit could not complete: " + repr(error))
    duplicates = [{"path": path, "platform": platform, "count": count} for (path, platform), count in Counter((row["path"], row["platform"]) for row in inventory).items() if count != 1]
    check(not duplicates, "No repeated suite/platform executions in the delta")
    summary = {"passed": not issues, "issues": issues, "source_commit": args.source, "source_tree": record.get("source_tree"),
               "audited_at_utc": datetime.now(timezone.utc).isoformat(), "method": "Independent raw JSON event lifecycles, exact Python AST/log identities, immutable/current source bytes, complete runtime/fixture inventories and explicit prior/current workspace accounting. No application tests executed by this audit.",
               "application_case_executions": sum(group["passed"] for group in groups), "suite_platform_executions": len(inventory),
               "distinct_test_files": len({row["path"] for row in inventory}), "suite_platform_inventory": inventory, "groups": groups,
               "failed": sum(group["failed"] for group in groups), "skipped": sum(group["skipped"] for group in groups),
               "duplicate_suite_platform_executions": duplicates, "separate_python_controls": details.get("python_controls", {}).get("passed_cases", 0),
               "prior_qualification": {"source_commit": PRIOR, "application_executions": 1372, "separate_python_controls": 90, "application_cases_added_to_delta": 0, "python_controls_added_to_delta": 0},
               "development_cases_added_to_delta": 0, "rejected_aea5_application_cases_added_to_delta": 0, "rejected_aea5_python_controls_added_to_delta": 0, "rejected_c0c_application_cases_added_to_delta": 0, "rejected_c0c_python_controls_added_to_delta": 0, "rejected_fce_guard_application_cases_added_to_delta": 0, "rejected_fce_guard_python_controls_added_to_delta": 0, "rejected_26df_application_cases_added_to_delta": 0, "rejected_26df_python_controls_added_to_delta": 0, "github_actions": "NOT QUERIED OR AWAITED", "runs": invocations,
               "outer_execution_sha256": sha(outer / "execution.json"), "runtime_receipt_sha256": sha(runtime / "runtime.json"),
               "audit_script_sha256": sha(Path(__file__)), "helper_sha256": {helper.name: sha(helper)}, "details": details}
    (output / "independent-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({key: summary[key] for key in ("passed", "issues", "source_commit", "application_case_executions", "suite_platform_executions", "distinct_test_files", "separate_python_controls", "failed", "skipped")}, indent=2))
    return int(bool(issues))


if __name__ == "__main__":
    raise SystemExit(main())
