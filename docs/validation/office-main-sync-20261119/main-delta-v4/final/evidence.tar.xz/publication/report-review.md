# Report-only proposals for frozen `5c18db77`

Reviewed source: `5c18db77505f876bf70bf7e89c49e8c3b617e0d4`.
Only the parent validation report `README.md` and `main-reconciliation.md`
are proposed. Both complete files and their exact source copies are in this
scratch directory. No live repository, product, runtime, fixture, historical
archive, or frozen v3/v4 plan was edited by this proposal preparation.

## Changes and evidence boundaries

- Name the exact integrated source and directly captured main `9160eb0d`.
  Local ancestry checks confirm that both `26df7873` and `9160eb0d` are ancestors
  of the frozen source. Source freeze does not establish final remote-main
  inclusion.
- Retain all four rejected attempts. The completed `26df7873` attempt remains
  rejected despite 634 native application successes and 21 separately counted
  Python successes. Its sole strict-analysis diagnostic prevented Node tests
  and browser compilation. The new preservation subtree links the original
  audit, raw evidence and verified archive; none of those counts enters an
  accepted total.
- Point current qualification and replay to the fresh v4 plan, keeping its
  acceptance pending. Preserve original v3 proposals and attempts as historical
  inputs. The original eight v3 proposal files are outside this patch.
- Retain the original `0669ac11` qualification, source/runtime inventories,
  publisher controls and replay under their original identity. The 5,051-input
  original outer envelope and separate 5,052-input post-publication baseline
  each keep their actual scope.
- Describe implemented native/web dictionary hosts and explicit setup,
  including native private-data persistence and web session-only bytes.
  Keep installed-platform launch, actual browser Wasm-worker execution,
  persistent web downloads and linguistic acceptance outside the local claims.
- Describe the 9160 Settings helper and neutral module-label integration,
  preserving stronger prior assertions, single toggles, the repaired footer,
  and Notes behavior. The 552 preserved assertion-call texts are a static
  source inventory, never executed tests. Workflow inspection is static;
  no GitHub Actions were accessed.

The separate `docs/PROOFING.md` correction is already included in the frozen
source at SHA-256
`a75e980ce25e44e554a5ce83ec2a2ff63af5d195206c5948a9b352bd540e6d05`.
This patch makes no guide change. The old `report-26df-review` proposals and
their metadata are preserved unchanged as historical review evidence.

## Patch and receipt

- `report-corrections.patch`: only the two report files, relative to the
  exact frozen source.
- `proposal-manifest.json`: exact source/tree, before/after hashes, individual
  and combined patch hashes, reasons and read-only validation results.
- `before/`: exact original Git blobs used for patch checking.
- `source/`: complete proposed report files.

The patch passes forward application checking against the exact source copies
and reverse checking against the proposed copies. Those are static patch
checks; no application/Python test, analysis, formatting, remote read, or CI
operation was run.

## Required final publication fill-in

After the v4 independent audit completes, replace the pending-acceptance
sentences in both reports with the exact result and source-bound evidence
links. Fill application executions, separately counted Python controls,
suite/file counts, strict coverage and source/runtime inventories only from
that audit. Preserve all historical and rejected rows and keep the original
1,372/90 baseline separate.

Record verified publication and remote-main identities separately from the
qualified source. This scratch proposal deliberately supplies no guessed
accepted counts, completion time, publication commit, or final remote-main
claim. Root owns those final report-only edits and publication verification.
