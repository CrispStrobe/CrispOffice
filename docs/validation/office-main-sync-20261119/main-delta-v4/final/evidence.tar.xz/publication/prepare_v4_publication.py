#!/usr/bin/env python3
"""Prepare exact, independently accepted v4 evidence for remote publication."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess


def read(path: Path):
    return json.loads(path.read_bytes())


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path: Path, value: object) -> None:
    if path.exists():
        raise FileExistsError(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("workspace", "repo", "outer", "audit", "reviews", "ref-audit", "spec"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--source", required=True)
    a = p.parse_args()
    root, repo = a.workspace.resolve(), a.repo.resolve()
    outer, audit = a.outer.resolve(), a.audit.resolve()
    report = Path("docs/validation/office-main-sync-20261119/main-delta-v4")

    def git(*v: str) -> str:
        return subprocess.check_output(["git", "--no-replace-objects", *v], cwd=repo, text=True).strip()

    record, summary = read(outer / "execution.json"), read(audit / "independent-summary.json")
    assert git("rev-parse", "HEAD") == a.source
    assert record["status"] == "PASS" and summary["passed"] is True and not summary["issues"]
    assert record["source_commit"] == summary["source_commit"] == a.source
    assert record["source_tree"] == summary["source_tree"] == git("rev-parse", a.source + "^{tree}")
    assert summary["failed"] == summary["skipped"] == 0
    assert summary["github_actions"] == "NOT QUERIED OR AWAITED"
    for path, expected in read(outer / "source-after.json").items():
        assert sha(repo / path) == expected, path

    refs = read(a.ref_audit)
    assert refs["passed"] is True and refs["checked_head"] == a.source
    assert refs["checked_tree"] == record["source_tree"]
    assert refs["all_captured_refs_accounted_for"] is True
    assert refs["all_historical_equivalences_verified"] is True
    reviews = read(a.reviews)
    assert reviews["source_commit"] == a.source
    assert reviews["application_qualification_case_contribution"] == 0
    assert reviews["python_qualification_case_contribution"] == 0
    assert len(reviews["members"]) == reviews["member_count"]
    for row in reviews["members"]:
        f = Path(row["original"])
        assert f.stat().st_size == row["bytes"] and sha(f) == row["sha256"], f

    final_members = []
    for label, directory in (("raw", outer), ("audit", audit)):
        for path in sorted(directory.rglob("*")):
            if path.is_file():
                assert not path.is_symlink(), path
                final_members.append({"path": label + "/" + path.relative_to(directory).as_posix(),
                                      "original": str(path.resolve())})
    extra = {
        "raw/outer-validation.log": root / "main-delta/v4-final-validation.log",
        "audit/audit_delta_v4_integration.py": root / "audit-review/audit_delta_v4_integration.py",
        "audit/audit_delta_gate.py": root / "audit-review/audit_delta_gate.py",
        "audit/verify_delta_publication.py": root / "audit-review/verify_delta_publication.py",
        "reconciliation/final-source-audit.json": a.ref_audit.resolve(),
        "publication/prepare_v4_publication.py": Path(__file__).resolve(),
        "publication/package_publication_evidence.py": root / "import-review/package_publication_evidence.py",
        "publication/verify_publication_archives.py": root / "import-review/verify_publication_archives.py",
        "publication/report-proposal-manifest.json": root / "arabic-review/report-v4-review/proposal-manifest.json",
        "publication/report-corrections.patch": root / "arabic-review/report-v4-review/report-corrections.patch",
        "publication/report-review.md": root / "arabic-review/report-v4-review/REVIEW.md",
    }
    for name, original in extra.items():
        assert original.is_file() and not original.is_symlink(), original
        final_members.append({"path": name, "original": str(original)})
    assert len({row["path"] for row in final_members}) == len(final_members)

    spec = {"schema": 1, "source_commit": a.source, "archives": [
        {"name": "Accepted final v4 qualification",
         "archive": (report / "final/evidence.tar.xz").as_posix(),
         "index": (report / "final/evidence.index.json").as_posix(),
         "scope": "Original accepted raw application/Python events, outputs, immutable source/runtime envelopes, independent recounts, fixed-capture reconciliation and replay/audit tools. Earlier source and rejected attempt counts are excluded.",
         "source_commit": a.source, "members": final_members},
        {"name": "Preserved final integration reviews",
         "archive": (report / "reviews/evidence.tar.xz").as_posix(),
         "index": (report / "reviews/evidence.index.json").as_posix(),
         "scope": reviews["scope"] + " Every original historical/development/failure label remains unchanged; zero qualification contribution.",
         "source_commit": a.source,
         "members": [{"path": row["path"], "original": row["original"]} for row in reviews["members"]]},
    ]}
    write(a.spec, spec)
    copies = {
        "final/execution.json": outer / "execution.json",
        "final/independent-summary.json": audit / "independent-summary.json",
        "final/continuity.json": outer / "continuity.json",
        "final/reconciliation.json": a.ref_audit,
        "final/packet-selection.json": a.spec,
        "reviews/selection.json": a.reviews,
    }
    for name, original in copies.items():
        dest = repo / report / name
        if dest.exists():
            raise FileExistsError(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(original, dest)
        assert sha(dest) == sha(original)
    compact = {key: summary[key] for key in (
        "passed", "source_commit", "source_tree", "application_case_executions",
        "suite_platform_executions", "distinct_test_files", "failed", "skipped",
        "separate_python_controls", "groups", "prior_qualification",
        "development_cases_added_to_delta", "github_actions")}
    compact.update(started_at_utc=record["started_at_utc"], finished_at_utc=record["finished_at_utc"],
                   source_inputs=summary["details"]["outer_source_inputs_reverified"],
                   runtime_inputs=summary["details"]["outer_runtime_inputs_reverified"],
                   fixture_inputs=summary["details"]["fixture_inputs_reverified"],
                   independent_summary_sha256=sha(audit / "independent-summary.json"),
                   original_execution_sha256=sha(outer / "execution.json"))
    write(repo / report / "final/summary.json", compact)
    print(json.dumps({"source": a.source, "spec": str(a.spec),
                      "qualification_archive_members": len(final_members),
                      "review_archive_members": len(reviews["members"])}))


if __name__ == "__main__":
    main()
