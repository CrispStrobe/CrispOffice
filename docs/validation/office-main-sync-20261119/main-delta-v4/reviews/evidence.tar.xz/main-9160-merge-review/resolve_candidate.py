#!/usr/bin/env python3
"""Resolve the immutable two-parent merge in a separate scratch Git index."""
from __future__ import annotations
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT / "merge-repo"
OURS = "26df787326f58a002b62241b7feb52acff089f2f"
INCOMING = "9160eb0dba211225c85242114989631c0d14fb72"
AUTO = (ROOT / "merge-tree-output.txt").read_text().splitlines()[0]
PREFIX = "packages/quds_office_editor/example/"
PATHS = json.loads((ROOT / "incoming-paths.json").read_text())


def git(*args: str, data: bytes | None = None) -> bytes:
    return subprocess.check_output(["git", *args], cwd=REPO, input=data)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def assertions(text: str) -> Counter:
    """Extract original assertion call bytes for a preservation check."""
    result = Counter()
    for match in re.finditer(r"\bexpect(?:Later)?\(", text):
        depth = 1
        quote = None
        escaped = False
        index = match.end()
        while depth and index < len(text):
            char = text[index]
            if quote:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == quote:
                    quote = None
            elif char in "\"'":
                quote = char
            elif char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            index += 1
        assert depth == 0
        result[text[match.start():index]] += 1
    return result


def tree(ref: str) -> dict:
    result = {}
    for row in git("ls-tree", "-r", "-z", "--full-tree", ref).split(b"\0"):
        if row:
            info, path = row.split(b"\t", 1)
            result[path.decode()] = info.decode()
    return result


def main() -> None:
    assert len(PATHS) == 11
    files = []
    checks = []
    for path in PATHS:
        if path in [".github/workflows/crispoffice-binaries.yml", PREFIX + "lib/suite_workspace.dart"]:
            data = (ROOT / "auto-merge" / path).read_bytes()
            decision = "Accept clean three-way merge; preserves reviewed local fixes and new incoming delta."
        else:
            data = (ROOT / "incoming" / path).read_bytes()
            decision = "Use incoming selector/shared-helper changes; prior assertion calls and proofing isolation verified below."
        if path == PREFIX + "test/support/studio_settings.dart":
            old = b"  await tester.tap(find.widgetWithText(TextButton, 'Close'));\n"
            new = b"  await tester.tap(\n    find.descendant(\n      of: find.byType(AlertDialog),\n      matching: find.widgetWithText(TextButton, 'Close'),\n    ),\n  );\n"
            assert data.count(old) == 1
            data = data.replace(old, new, 1)
            decision = "Retain incoming enable-only/Arabic-cycle helper and assertions; retain prior dialog-scoped Close finder."
        assert b"<<<<<<<" not in data and b">>>>>>>" not in data
        out = ROOT / "candidate" / path
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        old_path = ROOT / "ours" / path
        ours = old_path.read_bytes() if old_path.exists() else None
        incoming = (ROOT / "incoming" / path).read_bytes()
        if path.startswith(PREFIX + "test/") and ours is not None:
            before_calls = assertions(ours.decode())
            after_calls = assertions(data.decode())
            missing = before_calls - after_calls
            assert not missing, (path, list(missing))
            checks.append({"path": path, "original_assertion_calls": sum(before_calls.values()),
                           "candidate_assertion_calls": sum(after_calls.values()),
                           "all_original_assertion_calls_preserved": True})
        files.append({"path": path, "original": str(out), "bytes": len(data), "sha256": sha(data),
                      "ours_sha256": sha(ours) if ours is not None else None,
                      "incoming_sha256": sha(incoming), "decision": decision})

    workspace = (ROOT / "candidate" / (PREFIX + "lib/suite_workspace.dart")).read_text()
    old_workspace = (ROOT / "ours" / (PREFIX + "lib/suite_workspace.dart")).read_text()
    def region(text: str, start: str, end: str) -> str:
        return text[text.index(start):text.index(end, text.index(start))]
    assert region(workspace, "  Widget _reviewStrip()", "  Widget _statusBar()") == region(old_workspace, "  Widget _reviewStrip()", "  Widget _statusBar()")
    assert "      _lengthUnit,\n      _showNotes,\n" in workspace
    assert "Flexible(flex: 3, child: _reviewStrip())" in workspace
    isolation = []
    for name in ["studio_comment_draft_proofing_test.dart", "studio_comment_keyboard_review_test.dart", "studio_comment_review_test.dart"]:
        path = PREFIX + "test/" + name
        text = (ROOT / "candidate" / path).read_text()
        assert text.count("await enableStudioSetting(tester, 'Show comments');") == 1
        assert text.index("controller.proofing.enabled = false;") < text.index("await enableStudioSetting(tester, 'Show comments');")
        assert "find.byTooltip('Settings')" not in text
        isolation.append(path)
    zotero = (ROOT / "candidate" / (PREFIX + "test/studio_zotero_shortcuts_test.dart")).read_text()
    assert zotero.count("await enableStudioSetting(tester, 'Show notes');") == 1
    assert "find.byTooltip('Settings')" not in zotero

    git("read-tree", AUTO)
    for row in files:
        blob = git("hash-object", "-w", "--stdin", data=Path(row["original"]).read_bytes()).decode().strip()
        git("update-index", "--add", "--cacheinfo", "100644", blob, row["path"])
        row["merged_blob"] = blob
    merged_tree = git("write-tree").decode().strip()
    before_tree = tree(OURS)
    after_tree = tree(merged_tree)
    changed = sorted(path for path in set(before_tree) | set(after_tree) if before_tree.get(path) != after_tree.get(path))
    assert changed == sorted(PATHS), changed
    unchanged = sorted(set(before_tree) - set(PATHS))
    assert all(after_tree.get(path) == before_tree[path] for path in unchanged)
    preserved = [PREFIX + "test/" + name for name in ["studio_settings_test.dart", "studio_review_status_test.dart", "studio_mail_test.dart", "studio_hunspell_web_cancellation_test.dart", "studio_shots_test.dart"]]
    assert all(after_tree[path] == before_tree[path] for path in preserved)
    patch = git("diff", "--binary", OURS, merged_tree)
    (ROOT / "merge-from-26df.patch").write_bytes(patch)
    receipt = {"schema": 1, "status": "MERGE_CANDIDATE_READY_FOR_QUALIFICATION",
               "parents": [OURS, INCOMING], "merge_base": git("merge-base", OURS, INCOMING).decode().strip(),
               "automatic_merge_tree": AUTO, "resolved_tree": merged_tree,
               "changed_paths": changed, "changed_path_count": len(changed),
               "unchanged_original_tree_entries": len(unchanged),
               "every_path_outside_incoming_delta_unchanged_from_26df": True,
               "review_strip_byte_identical_to_26df": True,
               "notes_cache_key_retained": True, "footer_flexible_parent_retained": True,
               "prior_new_suites_and_harness_blobs_preserved": [{"path": path, "tree_entry": before_tree[path]} for path in preserved],
               "original_assertion_call_preservation": checks,
               "proofing_isolated_before_modal_setup": isolation,
               "one_enable_only_call_per_affected_pane_setup": True,
               "additional_test_helper_resolution": "Close finder stays scoped to AlertDialog, retaining prior locator precision; incoming before/after switch assertions and Arabic final-language assertion retained.",
               "tests_run": 0, "format_or_analysis_runtime_invocations": 0,
               "shared_repo_worktree_ref_or_index_writes": False, "shared_runtime_writes": False,
               "ci_queries_or_runs": 0, "qualification_case_contribution": 0,
               "limitations": "Formatting, analysis and affected Studio tests are deferred until the frozen 26df gate/audit completes."}
    (ROOT / "merge-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    manifest = {"schema": 1, "parents": [OURS, INCOMING], "resolved_tree": merged_tree,
                "scope": "Merge only the incoming eleven paths while retaining every other reviewed 26df blob; no tests or shared-runtime writes.",
                "files": files}
    (ROOT / "candidate-files.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"manifest": str(ROOT / "candidate-files.json"), "manifest_sha256": sha((ROOT / "candidate-files.json").read_bytes()),
                      "resolved_tree": merged_tree, "changed_paths": len(changed), "unchanged_tree_entries": len(unchanged),
                      "assertion_calls_preserved": sum(c["original_assertion_calls"] for c in checks)}, indent=2))


if __name__ == "__main__":
    main()
