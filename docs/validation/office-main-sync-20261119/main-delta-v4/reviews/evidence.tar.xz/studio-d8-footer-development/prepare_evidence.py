#!/usr/bin/env python3
"""Account existing logs and freeze a bounded evidence inventory; no tests."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
APP = ROOT / "isolated/packages/quds_office_editor/example"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def account(name: str, expected_pass: int, expected_fail: int, exit_code: int) -> dict:
    path = ROOT / name
    starts = {}
    completions = {}
    suites = {}
    errors = []
    final = []
    for line_number, line in enumerate(path.read_text().splitlines(), 1):
        event = json.loads(line)
        kind = event["type"]
        if kind == "testStart":
            case = event["test"]
            assert case["id"] not in starts
            starts[case["id"]] = case
        elif kind == "testDone":
            assert event["testID"] not in completions
            completions[event["testID"]] = event
        elif kind == "suite":
            suite = event["suite"]
            assert suite["id"] not in suites
            suites[suite["id"]] = suite
        elif kind == "error":
            errors.append(event)
        elif kind == "done":
            final.append(event)
    assert set(starts) == set(completions)
    assert len(final) == 1 and final[0]["success"] == (expected_fail == 0)
    visible = {key: value for key, value in completions.items() if not value.get("hidden")}
    passed = [key for key, value in visible.items() if value["result"] == "success"]
    failed = [key for key, value in visible.items() if value["result"] != "success"]
    assert len(passed) == expected_pass and len(failed) == expected_fail
    assert not any(value.get("skipped") for value in visible.values())
    if expected_fail == 0:
        assert errors == []
    assert {e["testID"] for e in errors} <= set(failed)
    result = {"log": name, "log_sha256": sha(path.read_bytes()), "exit_code": exit_code,
              "status": "PASS_DEVELOPMENT" if not expected_fail else "EXPECTED_RED_FAILURES",
              "all_lines_json": True, "non_json_lines": 0,
              "starts": len(starts), "completions": len(completions),
              "duplicate_completions": 0, "unfinished": 0,
              "visible_passed": len(passed), "visible_failed": len(failed), "skipped": 0,
              "error_events": len(errors), "terminal_success": final[0]["success"],
              "cases": [{"name": starts[key]["name"], "result": value["result"],
                         "suite_path": suites[starts[key]["suiteID"]]["path"]}
                        for key, value in visible.items()]}
    (ROOT / name.replace(".jsonl", "-accounting.json")).write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    manifest_path = ROOT / "final-files.json"
    manifest = json.loads(manifest_path.read_text())
    for row in manifest["files"]:
        data = Path(row["original"]).read_bytes()
        assert len(data) == row["bytes"] and sha(data) == row["sha256"]
        relative = row["path"].removeprefix("packages/quds_office_editor/example/")
        assert data == (APP / relative).read_bytes()
    assert (ROOT / "red-source/test/studio_review_status_test.dart").read_bytes() == (ROOT / "final-source/test/studio_review_status_test.dart").read_bytes()
    runs = [account("status-red.jsonl", 0, 7, 1), account("narrow-red.jsonl", 0, 1, 1), account("green.jsonl", 9, 0, 0)]
    analysis = json.loads((ROOT / "analysis-summary.json").read_text())
    assert len(analysis) == 2 and all(row["exit_code"] == 0 for row in analysis)
    context = ROOT / "context"
    context.mkdir(exist_ok=True)
    for name in ["package_config.json", "package_graph.json"]:
        shutil.copyfile(APP / ".dart_tool" / name, context / name)
    shutil.copyfile(APP / "pubspec.yaml", context / "pubspec.yaml")
    for name in ["studio_compact_navigation_test.dart", "studio_comment_draft_proofing_test.dart"]:
        shutil.copyfile(APP / "test" / name, context / name)
    commands = [
        {"log": "status-red.jsonl", "args": ["test/studio_review_status_test.dart"]},
        {"log": "narrow-red.jsonl", "args": ["--name", "narrow", "test/studio_compact_navigation_test.dart", "test/studio_comment_draft_proofing_test.dart"]},
        {"log": "green.jsonl", "args": ["test/studio_review_status_test.dart", "test/studio_compact_navigation_test.dart", "test/studio_comment_draft_proofing_test.dart", "--name", "footer|compact PDF navigation|narrow Arabic reply"]},
    ]
    for command in commands:
        command["command"] = [str(ROOT.parent / "quds-runtime/bin/flutter"), "test", "--no-pub", "--concurrency=1", "--reporter=json", *command.pop("args")]
        command["cwd"] = str(APP)
    receipt = {"schema": 1, "status": "PASS_DEVELOPMENT_RED_GREEN_AND_STATIC_ANALYSIS",
               "incoming_main": manifest["incoming_main"], "base_reviewed_source": manifest["base_reviewed_source"],
               "scope": manifest["scope"], "final_source_manifest_sha256": sha(manifest_path.read_bytes()),
               "expected_red": "All seven new public controller/provider cases failed on the incoming d8 workspace. The pre-existing 390px Arabic/1.4x case also failed with RenderFlex overflow of 204px.",
               "green": "Seven status cases plus the pre-existing compact PDF navigation and narrow Arabic reply cases passed with strict JSON-only reporting.",
               "state_coverage": ["Unavailable provider with zero findings in English/German/Arabic", "Ordinary pass with manual providers skipped, then explicit full pass", "Paused live checking after complete clean results", "Typing debounce scheduled after editing", "Real pending provider request, then successful completion"],
               "proofing_state_injection": "Only public controller/session/provider APIs; no summary injection or production test hooks.",
               "ui_scope": "Incoming footer placement and compact chrome retained; only new review strip bounded after an observed narrow-layout failure.",
               "runs": runs, "commands": commands, "strict_analysis": analysis,
               "formatting": "Both final files were processed by the pinned formatter before the GREEN run; final copies equal the analyzed/tested bytes.",
               "red_and_green_test_bytes_identical": True,
               "patch_check_exit": 0,
               "application_qualification_case_contribution": 0,
               "python_qualification_case_contribution": 0,
               "runtime_or_fixture_edits_by_this_agent": False,
               "repository_worktree_or_index_writes_by_this_agent": False,
               "git_operation": "Fetched origin main only, then inspected immutable commits; no other ref inventory or remote mutation.",
               "ci_queries_or_runs": 0,
               "boundaries": "These are isolated development runs. Parent final frozen gate independently qualifies its full selected suites. No desktop GUI, OS packaging or live browser checks occurred."}
    (ROOT / "development-receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    selected = [
        "prepare_isolated.py", "prepare_evidence.py", "isolated-inputs.json", "final-files.json", "footer-status-fix.patch",
        "development-receipt.json", "analysis-summary.json", "suite_workspace-analysis.log", "studio_review_status_test-analysis.log",
        "format.log", "status-test-format.log", "final-format.log", "patch-check.log",
        "status-red.jsonl", "narrow-red.jsonl", "green.jsonl", "status-red-accounting.json", "narrow-red-accounting.json", "green-accounting.json",
        "red-source/lib/suite_workspace.dart", "red-source/lib/studio_chrome.dart", "red-source/test/studio_review_status_test.dart",
        "final-source/lib/suite_workspace.dart", "final-source/test/studio_review_status_test.dart",
        "context/package_config.json", "context/package_graph.json", "context/pubspec.yaml",
        "context/studio_compact_navigation_test.dart", "context/studio_comment_draft_proofing_test.dart",
    ]
    members = []
    for relative in selected:
        path = ROOT / relative
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        members.append({"path": "studio-d8-footer-development/" + relative, "original": str(path), "bytes": len(data), "sha256": sha(data)})
    inventory = {"schema": 1, "scope": "Bounded d8 footer correctness/layout development evidence; RED failures preserved and GREEN observations separate from final qualification.",
                 "required_member_count": len(members), "required_bytes": sum(row["bytes"] for row in members),
                 "qualification_cases": 0, "required_members": members,
                 "excluded": "47MB materialized source/assets, generated builds, caches, initial notes-only draft, duplicate raw originals and final-gate outputs."}
    (ROOT / "evidence-inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
    print(json.dumps({"inventory": str(ROOT / "evidence-inventory.json"), "members": len(members), "bytes": inventory["required_bytes"], "sha256": sha((ROOT / "evidence-inventory.json").read_bytes())}, indent=2))


if __name__ == "__main__":
    main()
