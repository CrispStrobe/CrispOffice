#!/usr/bin/env python3
"""Materialize immutable source/assets for isolated Studio development."""
from __future__ import annotations
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
from urllib.parse import urljoin

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "quds_office_suite"
DEST = ROOT / "isolated"
BASE = "fce543dedb1217804f67de088ef9c287e8a2edca"
LATEST = "d8b7f1c4a576f727a0901c555dc327562dfff2b2"
APP = "packages/quds_office_editor/example"
rows = []
for commit, paths in [
    (BASE, ["analysis_options.yaml", "packages/quds_office_engine/lib", "packages/quds_office_engine/pubspec.yaml", "packages/quds_office_engine/analysis_options.yaml",
            "packages/quds_office_editor/lib", "packages/quds_office_editor/pubspec.yaml", "packages/quds_office_editor/analysis_options.yaml",
            "packages/quds_office_editor/fonts", "packages/quds_office_editor/templates", "packages/quds_office_editor/assets"]),
    (LATEST, [APP + "/lib", APP + "/pubspec.yaml", APP + "/analysis_options.yaml", APP + "/assets", APP + "/fonts"]),
    (BASE, [APP + "/test/studio_compact_navigation_test.dart", APP + "/test/studio_comment_draft_proofing_test.dart"]),
]:
    archive = subprocess.check_output(["git", "archive", commit, *paths], cwd=REPO)
    with tarfile.open(fileobj=io.BytesIO(archive)) as stream:
        for member in stream.getmembers():
            if member.isdir():
                continue
            assert member.isfile() and not member.name.startswith("/") and ".." not in Path(member.name).parts
            data = stream.extractfile(member).read()
            target = DEST / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            rows.append({"commit": commit, "path": member.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

configuration_path = REPO / ".dart_tool/package_config.json"
config = json.loads(configuration_path.read_text())
for package in config["packages"]:
    package["rootUri"] = urljoin(configuration_path.parent.as_uri() + "/", package["rootUri"])
    if package["name"] in ["quds_office_engine", "quds_office_editor", "quds_office_studio"]:
        relative = APP if package["name"] == "quds_office_studio" else "packages/" + package["name"]
        package["rootUri"] = (DEST / relative).as_uri()
tool = DEST / APP / ".dart_tool"
tool.mkdir(exist_ok=True)
(tool / "package_config.json").write_text(json.dumps(config, indent=2) + "\n")
shutil.copyfile(REPO / ".dart_tool/package_graph.json", tool / "package_graph.json")
(ROOT / "isolated-inputs.json").write_text(json.dumps({"base": BASE, "latest": LATEST, "files": rows}, indent=2) + "\n")
print(json.dumps({"files": len(rows), "bytes": sum(row["bytes"] for row in rows), "app": str(DEST / APP)}))
