#!/usr/bin/env python3
"""Static review receipts; no builds, app tests, network or repository writes."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "quds_office_suite"
COMMIT = "00014577265d1f95d4c016159029510d3a10804b"
PREVIOUS = "be641457c8c7d1acc25091b31c87c73eaa3c9c2a"
PREFIX = "packages/quds_office_editor/example/"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_git(commit: str, path: str) -> bytes:
    return subprocess.check_output(["git", "show", f"{commit}:{path}"], cwd=REPO)


def getter(source: bytes, name: str) -> str:
    match = re.search(r"String get " + re.escape(name) + r"\s*=>\s*(.*?);", source.decode(), re.S)
    assert match, name
    return " ".join(match[1].split())


def main() -> None:
    strings_path = PREFIX + "lib/studio_strings.dart"
    previous = read_git(PREVIOUS, strings_path)
    latest = read_git(COMMIT, strings_path)
    selectors = ["appTitle", "documents", "spreadsheets", "presentations", "pdf", "mail",
                 "settings", "close", "languageLabel", "showComments", "showNotes",
                 "mailTitle", "openMessage", "fullView", "compactView"]
    unchanged = []
    for name in selectors:
        assert getter(previous, name) == getter(latest, name), name
        unchanged.append({"getter": name, "value_expression": getter(latest, name), "unchanged": True})
    workspace = (ROOT / "source/lib/suite_workspace.dart").read_text()
    required = ["StudioLanguage _language = StudioLanguage.en;",
                "var _showNotes = false;", "var _showComments = false;",
                "var _showOutline = false;", "var _showRibbonGroupLabels = false;",
                "StudioLanguage.en => StudioLanguage.de,",
                "StudioLanguage.de => StudioLanguage.ar,",
                "StudioLanguage.ar => StudioLanguage.en,",
                "_t('Review', StudioStrings.de('Review'), 'مراجعة')"]
    for marker in required:
        assert marker in workspace, marker

    format_command = [str(ROOT.parent / "quds-runtime/bin/dart"), "format", "--output=none",
                      "--set-exit-if-changed", "lib/studio_strings.dart", "lib/crisp_office_sample.dart"]
    result = subprocess.run(format_command, cwd=ROOT / "source", capture_output=True)
    (ROOT / "other-incoming-format.log").write_bytes(result.stdout + result.stderr)
    assert result.returncode == 0
    patch_command = ["git", "apply", "--check", str(ROOT / "latest-main-overlay.patch")]
    patch = subprocess.run(patch_command, cwd=ROOT / "originals", capture_output=True)
    (ROOT / "patch-check.log").write_bytes(patch.stdout + patch.stderr)
    assert patch.returncode == 0
    macos = read_git(COMMIT, PREFIX + "macos/Runner/Configs/AppInfo.xcconfig")
    assert b"PRODUCT_NAME = quds_office_studio\n" in macos
    workflow = (ROOT / "source/.github/workflows/crispoffice-binaries.yml").read_text()
    assert workflow.count("working-directory: packages/quds_office_editor/example") == 9
    assert "tags: ['crispoffice-v*']" in workflow
    assert "workflow_dispatch:" in workflow

    receipt = {"schema": 1, "status": "PASS_STATIC_SOURCE_REVIEW", "incoming_main": COMMIT,
               "comparison_main": PREVIOUS, "reviewed_selector_getters": unchanged,
               "preserved_default_and_cycle_markers": required,
               "selectors_need_additional_changes": False,
               "format_command": format_command, "format_exit": result.returncode,
               "patch_command": patch_command, "patch_exit": patch.returncode,
               "macos_product_path_matches_committed_name": True,
               "workflow_notes": [
                   "All five build commands use the example application directory after the one-line correction.",
                   "Manual and tag-only triggers are preserved; ordinary branch pushes do not match this workflow.",
                   "Source compilation and platform packaging are not executed by this review.",
                   "Optional Hunspell build/inclusion is not present in this workflow and is not qualified here."],
               "application_tests_run": 0, "ci_queries_or_runs": 0,
               "inputs": [{"commit": c, "path": p, "bytes": len(d), "sha256": digest(d)}
                          for c, p, d in [(PREVIOUS, strings_path, previous),
                                          (COMMIT, strings_path, latest),
                                          (COMMIT, PREFIX + "macos/Runner/Configs/AppInfo.xcconfig", macos)]]}
    (ROOT / "label-and-workflow-review.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": receipt["status"], "unchanged_selector_getters": len(unchanged),
                      "format_exit": result.returncode, "patch_exit": patch.returncode}))


if __name__ == "__main__":
    main()
