#!/usr/bin/env python3
"""Build a narrow scratch-only overlay from an immutable incoming commit."""
from __future__ import annotations

import datetime
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "quds_office_suite"
COMMIT = "00014577265d1f95d4c016159029510d3a10804b"
PREFIX = "packages/quds_office_editor/example/"
DART = ROOT.parent / "quds-runtime/bin/dart"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def original(path: str) -> bytes:
    data = subprocess.check_output(["git", "show", f"{COMMIT}:{path}"], cwd=REPO)
    destination = ROOT / "originals" / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    return data


def format_file(path: Path, name: str) -> dict:
    before = path.read_bytes()
    command = [str(DART), "format", str(path)]
    result = subprocess.run(command, cwd=ROOT / "source", capture_output=True)
    (ROOT / name).write_bytes(result.stdout + result.stderr)
    if result.returncode:
        raise RuntimeError(f"format failed: {name}")
    after = path.read_bytes()
    return {"command": command, "exit_code": result.returncode,
            "before_sha256": sha(before), "after_sha256": sha(after),
            "changed": before != after, "log": str(ROOT / name)}


def main() -> None:
    workspace_path = PREFIX + "lib/suite_workspace.dart"
    workspace_original = original(workspace_path)
    baseline = ROOT / "source/baseline/suite_workspace.dart"
    baseline.parent.mkdir(parents=True, exist_ok=True)
    baseline.write_bytes(workspace_original)
    format_baseline = format_file(baseline, "baseline-format.log")
    formatted_baseline = baseline.read_bytes()

    marker = b"      _lengthUnit,\n    );\n"
    replacement = b"      _lengthUnit,\n      _showNotes,\n    );\n"
    assert workspace_original.count(marker) == 1
    workspace_candidate = ROOT / "source/lib/suite_workspace.dart"
    workspace_candidate.write_bytes(workspace_original.replace(marker, replacement, 1))
    format_workspace = format_file(workspace_candidate, "workspace-format.log")
    assert workspace_candidate.read_bytes().replace(replacement, marker, 1) == formatted_baseline

    workflow_path = ".github/workflows/crispoffice-binaries.yml"
    workflow_original = original(workflow_path)
    old = b"      - name: Build macOS\n        run: flutter build macos --release\n"
    new = b"      - name: Build macOS\n        working-directory: packages/quds_office_editor/example\n        run: flutter build macos --release\n"
    assert workflow_original.count(old) == 1
    workflow_candidate = ROOT / "source" / workflow_path
    workflow_candidate.parent.mkdir(parents=True, exist_ok=True)
    workflow_candidate.write_bytes(workflow_original.replace(old, new, 1))
    assert workflow_candidate.read_bytes().replace(new, old, 1) == workflow_original

    rows = []
    for path, candidate, before, meaning in [
        (workspace_path, workspace_candidate, workspace_original,
         "One _showNotes cache-key member; one pinned-formatter-only command-layout hunk."),
        (workflow_path, workflow_candidate, workflow_original,
         "One working-directory entry for the macOS build step; all triggers and other bytes preserved."),
    ]:
        data = candidate.read_bytes()
        rows.append({"path": path, "original": str(candidate), "bytes": len(data),
                     "sha256": sha(data), "incoming_before_sha256": sha(before),
                     "format_only": False, "scope": meaning})

    incoming_checks = []
    for filename in ("studio_about.dart", "studio_de_strings.dart"):
        path = PREFIX + "lib/" + filename
        before = original(path)
        candidate = ROOT / "source/lib" / filename
        candidate.write_bytes(before)
        result = format_file(candidate, filename.removesuffix(".dart") + "-format.log")
        incoming_checks.append({"path": path, **result})
        if result["changed"]:
            data = candidate.read_bytes()
            rows.append({"path": path, "original": str(candidate), "bytes": len(data),
                         "sha256": sha(data), "incoming_before_sha256": sha(before),
                         "format_only": True, "scope": "Pinned formatter only."})

    patch = ""
    for row in rows:
        before = (ROOT / "originals" / row["path"]).read_text()
        after = Path(row["original"]).read_text()
        patch += "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                            fromfile="a/" + row["path"], tofile="b/" + row["path"]))
    (ROOT / "latest-main-overlay.patch").write_text(patch)
    manifest = {"schema": 1, "incoming_main": COMMIT,
                "scope": "Minimal notes cache-key retention and macOS build working directory correction; preserve all incoming localization, About, layout, icons, defaults and other workflow steps.",
                "files": rows}
    (ROOT / "workspace-files.json").write_text(json.dumps(manifest, indent=2) + "\n")
    receipt = {"schema": 1, "at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "incoming_main": COMMIT, "status": "PASS_STATIC_OVERLAY_CHECKS",
               "workspace_semantic_delta": "Candidate minus the one _showNotes cache-key entry equals pinned-formatted original byte for byte.",
               "workspace_baseline_format": format_baseline,
               "workspace_format": format_workspace,
               "incoming_new_dart_format_checks": incoming_checks,
               "workflow_delta": "Removing the single added working-directory line reconstructs the original workflow byte for byte.",
               "workflow_trigger_boundary": "Manual workflow_dispatch and crispoffice-v* tag pushes only; no ordinary branch-push trigger.",
               "workflow_execution_boundary": "Static source inspection only; no workflow/check/status endpoint queries, Actions execution or artifact-build validation.",
               "optional_hunspell_packaging_boundary": "Workflow builds Flutter apps, without invoking the optional native/Wasm Hunspell builder; bundled-engine availability is not established.",
               "application_tests_run": 0,
               "source_repo_edits": False,
               "runtime_or_fixture_edits": False,
               "files_manifest_sha256": sha((ROOT / "workspace-files.json").read_bytes()),
               "patch_sha256": sha((ROOT / "latest-main-overlay.patch").read_bytes())}
    (ROOT / "static-overlay-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"manifest": str(ROOT / "workspace-files.json"), "files": rows,
                      "new_dart_format": incoming_checks}, indent=2))


if __name__ == "__main__":
    main()
