from pathlib import Path
import subprocess,json,os,hashlib
b=Path(__file__).resolve().parent
rows=json.loads((b/'candidate-files.json').read_text())
analysis=[]
for row in rows:
 p=b/'source'/row['path']
 package=b/'source'/'packages'/Path(row['path']).parts[1]
 command=['/workspace/scratch/79e6ad9e4046/quds-runtime/bin/dart','analyze','--fatal-infos',str(p.relative_to(package))]
 result=subprocess.run(command,cwd=package,capture_output=True,text=True)
 log=b/'analysis'/Path(row['path']).with_suffix('.log')
 log.parent.mkdir(parents=True,exist_ok=True)
 log.write_text(result.stdout+result.stderr)
 analysis.append({'path':row['path'],'command':command,'cwd':str(package),'exit_code':result.returncode,'log':str(log.relative_to(b)),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 (b/'analysis-summary.json').write_text(json.dumps(analysis,indent=2)+'\n')
 if result.returncode: print(row['path'],result.returncode,result.stdout,result.stderr,flush=True)
print(json.dumps({'targets':len(analysis),'passed':sum(r['exit_code']==0 for r in analysis)}),flush=True)
raise SystemExit(any(r['exit_code'] for r in analysis))
