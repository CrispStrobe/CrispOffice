"""Build the bounded v3 evidence selection without executing product code."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess


BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
REPO = ROOT / "quds_office_suite"
PREVIEW = "b0245f8cccbbe83db8fbe81b9d650a6b18d30a02"
INCOMING = "be641457c8c7d1acc25091b31c87c73eaa3c9c2a"
FROZEN = "c0c71a26e014cadda7a1f42244e710509dea5f6c"
PINNED_RECEIPTS = {
    "receipt.json": "7b66f4234b3393a2aa4534b941c3d526c7280dd922efee45edf4f60d6b122517",
    "candidate-files.json": "7b57bcee0928312ef02ce28ca566b9eb763b3bd3a210b8818c9d262c4c908fe2",
    "word-routing-and-merge.patch": "eea6a90d0529261c4d8347d6157839d23fd0a7b2d6c05ab7e7dc2d798c1aa423",
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", *args], cwd=REPO)


def source_binding(commit: str, path: str) -> dict:
    data = git("show", f"{commit}:{path}")
    return {
        "commit": commit,
        "path": path,
        "git_blob": git("rev-parse", f"{commit}:{path}").decode().strip(),
        "sha256": sha(data),
        "bytes": len(data),
        "url": f"https://github.com/CrispStrobe/quds_office_suite/blob/{commit}/{path}",
    }


def main() -> None:
    for name, expected in PINNED_RECEIPTS.items():
        assert sha((BASE / name).read_bytes()) == expected, name

    candidates = json.loads((BASE / "candidate-files.json").read_text())
    red_sources = json.loads((BASE / "red-inputs.json").read_text())
    before = []
    for row in red_sources:
        path = row["path"]
        original = (BASE / "red-source" / path).read_bytes()
        assert sha(original) == row["sha256"], path
        assert git("show", f"{PREVIEW}:{path}") == original, path
        binding = source_binding(INCOMING, path)
        assert binding["sha256"] == row["sha256"], path
        before.append(binding)
    assert len(before) == 9

    prefixes = ["analysis_options.yaml"]
    for package in ["quds_office_engine", "quds_office_editor"]:
        prefixes.extend(
            f"packages/{package}/{part}"
            for part in ["lib", "test", "pubspec.yaml", "analysis_options.yaml"]
        )
    prefixes.extend(
        f"packages/quds_office_editor/{part}"
        for part in ["fonts", "templates", "assets"]
    )
    differences = git(
        "diff", "--name-only", INCOMING, PREVIEW, "--", *prefixes
    ).decode().splitlines()
    overlays = []
    for path in differences:
        binding = source_binding(FROZEN, path)
        assert git("show", f"{FROZEN}:{path}") == git(
            "show", f"{PREVIEW}:{path}"
        ), path
        overlays.append(binding)
    assert len(overlays) == 4
    source_count = len(
        git("ls-tree", "-r", "--name-only", PREVIEW, "--", *prefixes)
        .decode()
        .splitlines()
    )
    assert source_count == 2114

    existing_test = source_binding(
        INCOMING,
        "packages/quds_office_engine/test/proofing/office_proofing_merge_test.dart",
    )
    merge_test = next(
        row for row in candidates if row["path"] == existing_test["path"]
    )
    assert existing_test["sha256"] == merge_test["before_sha256"]

    configuration = []
    for package in ["quds_office_engine", "quds_office_editor"]:
        for name in ["package_config.json", "package_graph.json", "native_assets.yaml"]:
            path = BASE / "source" / "packages" / package / ".dart_tool" / name
            assert path.is_file() and not path.is_symlink(), path
            configuration.append(
                {
                    "member": str(path.relative_to(ROOT)),
                    "sha256": sha(path.read_bytes()),
                    "bytes": path.stat().st_size,
                }
            )

    mapping = {
        "schema": 1,
        "status": "ALL_BEFORE_SOURCES_BOUND_TO_PUBLISHED_COMMITS",
        "original_preview_tree": PREVIEW,
        "original_receipts_unchanged": PINNED_RECEIPTS,
        "nine_before_sources": before,
        "existing_merge_test_before": existing_test,
        "original_materialization": {
            "base_commit": INCOMING,
            "selected_prefixes": prefixes,
            "tracked_file_count": source_count,
            "overlays_from_published_frozen_commit": overlays,
            "proof": "The complete selected-prefix diff from be641 to the original preview contains exactly these four paths; each preview blob equals its c0c blob. The nine edited source baselines all equal be641 directly.",
            "t1_evidence": "The four Arabic overlay blobs and their prior regression evidence are already preserved by published history and the 3bbb packet. They are referenced here, not duplicated.",
        },
        "configuration": configuration,
        "replay": [
            "Materialize the selected prefixes from be641 and overlay exactly the four listed c0c blobs. This reconstructs all 2,114 originally materialized tracked files without requiring the unpublished b0245 tree.",
            "Use the pinned runtime and dependency identities from the governing qualification. Restore the included package configuration, package graph and native-assets metadata in each isolated package. Historical absolute paths must be remapped to the corresponding restored workspace/runtime roots; preserve package names, language versions and dependency identities.",
            "For RED, install the three final candidate test files from candidate-files.json, leaving the nine application source files at their mapped be641 baselines. The source/test paths outside the twelve candidate files remain at the reconstructed preview. Run engine-red and editor-red commands recorded in receipt.json; the expected results are 9 engine and 7 editor failures.",
            "For GREEN, overlay all twelve final candidate files and verify their hashes from candidate-files.json. Run engine-green-vm, engine-green-node and editor-green from receipt.json. Their 36 + 36 + 39 executions are development evidence, separate from the final frozen qualification.",
            "The absolute paths embedded in original raw logs and receipts describe the actual recorded run. Do not rewrite those original artifacts during replay.",
        ],
    }
    mapping_path = BASE / "replay-mapping.json"
    mapping_path.write_text(json.dumps(mapping, indent=2) + "\n")

    members = [
        BASE / name
        for name in [
            "base.json",
            "candidate-files.json",
            "red-inputs.json",
            "receipt.json",
            "word-routing-and-merge.patch",
            "engine-red.jsonl",
            "editor-red.jsonl",
            "engine-green-vm.jsonl",
            "engine-green-node.jsonl",
            "editor-green.jsonl",
            "analysis-summary.json",
            "analyze_candidate.py",
            "format.log",
            "replay-mapping.json",
            "prepare_evidence.py",
        ]
    ]
    for row in candidates:
        path = Path(row["scratch"])
        assert path == BASE / "source" / row["path"]
        assert sha(path.read_bytes()) == row["sha256"], row["path"]
        members.append(path)
    analysis = json.loads((BASE / "analysis-summary.json").read_text())
    assert len(analysis) == 12
    for row in analysis:
        path = BASE / row["log"]
        assert sha(path.read_bytes()) == row["sha256"] and row["exit_code"] == 0
        members.append(path)
    members.extend(ROOT / row["member"] for row in configuration)
    review = ROOT / "arabic-review/studio-v3-cross-review.json"
    assert sha(review.read_bytes()) == (
        "ec21cd3e7cfcffa5c4dcd24e9e553defe9b8c01c0951aa2639bf7efe84151ea3"
    )
    members.append(review)
    members = sorted(members)
    assert len(members) == len(set(members))
    for path in members:
        assert path.is_file() and not path.is_symlink(), path
        assert str(path.relative_to(ROOT)).startswith("arabic-review/")

    rows = [
        {
            "path": str(path.relative_to(ROOT)),
            "bytes": path.stat().st_size,
            "sha256": sha(path.read_bytes()),
        }
        for path in members
    ]
    output = ROOT / "arabic-review/v3-word-evidence-members.json"
    output.write_text(json.dumps([row["path"] for row in rows], indent=2) + "\n")
    selection = {
        "schema": 1,
        "member_count": len(rows),
        "total_bytes": sum(row["bytes"] for row in rows),
        "member_list": str(output.relative_to(ROOT)),
        "member_list_sha256": sha(output.read_bytes()),
        "members": rows,
        "excluded": [
            "The full 2,114-file materialized workspace; only the twelve reviewed final candidate files are selected.",
            "Build output, caches, temporary files and unrelated package configuration; only the six exact engine/editor launcher metadata files are selected.",
            "Nine redundant red-source copies, which map exactly to publicly reachable be641 blobs.",
            "Previously published T1 source/evidence from the 3bbb packet; four c0c source overlays are referenced in replay-mapping.json.",
            "Original remote Studio development output and its materialized workspace; this packet includes only the independent Studio v3 source-review receipt.",
        ],
    }
    (ROOT / "arabic-review/v3-word-evidence-selection.json").write_text(
        json.dumps(selection, indent=2) + "\n"
    )
    for name, expected in PINNED_RECEIPTS.items():
        assert sha((BASE / name).read_bytes()) == expected, name
    print(
        json.dumps(
            {
                "member_list": str(output),
                "count": len(rows),
                "bytes": selection["total_bytes"],
                "sha256": selection["member_list_sha256"],
                "before_sources_on_be641": len(before),
                "c0c_overlay_sources": len(overlays),
            }
        )
    )


if __name__ == "__main__":
    main()
