import '../../xml/namespaces.dart';
import '../../xml/xml_node.dart';
import '../properties/wml_properties.dart';

/// Sparse source properties and effective values must remain separate: writing
/// inherited values as direct formatting would prevent subsequent style edits.
abstract final class WordPropertyIo {
  static Map<String, String> runValues(WmlRunProps r) => {
    'rStyle': '${r.styleId}',
    'rFonts': '${r.asciiFont}|${r.csFont}',
    'b': '${r.bold}',
    'i': '${r.italic}',
    'strike': '${r.strike}',
    'smallCaps': '${r.smallCaps}',
    'color': r.color,
    'sz': '${r.fontSizeHalfPoints}',
    'highlight': '${r.highlight}',
    'u': '${r.underline}',
    'vertAlign': '${r.vertAlign}',
    'lang': '${r.proofingLanguage}',
    'langBidi': '${r.complexScriptLanguage}',
    'noProof': '${r.noProof}',
  };
  static Map<String, String> paragraphValues(WmlParagraphProps p) => {
    'pStyle': '${p.styleId}',
    'jc': '${p.justification}',
    'spacing':
        '${p.spacingBefore}|${p.spacingAfter}|${p.lineSpacing}|${p.lineSpacingRule}',
    'ind':
        '${p.indent.left}|${p.indent.right}|${p.indent.firstLine}|${p.indent.hanging}',
    'keepLines': '${p.keepTogether}',
    'pageBreakBefore': '${p.pageBreakBefore}',
    'numPr': '${p.numId ?? (p.numberingSuppressed ? 0 : null)}|${p.ilvl}',
    'outlineLvl': '${p.headingLevel}',
    'bidi': '${p.rightToLeft}',
    'rPr': '${p.proofingLanguage}',
    'suppressAutoHyphens': '${p.suppressAutoHyphens}',
    'framePr': '${p.dropCapLines}',
    'shd': '${p.shadingFill}',
    'pBdr': '${p.borderColor}',
    'tabs': p.tabs
        .map((t) => '${t.position}|${t.alignment}|${t.leader}')
        .join(','),
  };
  static XmlElement parse(String? xml, String name) =>
      xml == null || xml.isEmpty
      ? XmlElement(
          localName: name,
          prefix: 'w',
          namespaceUri: OfficeNamespaces.w,
        )
      : XmlDocument.parse(xml).root!;

  static XmlElement preserve(
    XmlElement generated,
    String source,
    Map<String, String> imported,
    Map<String, String> current,
  ) {
    final XmlElement result = parse(source, generated.localName);
    for (final String key in current.keys) {
      if (current[key] == imported[key]) continue;
      if (key == 'lang' || key == 'langBidi' || key == 'rPr') {
        // Each language slot owns one attribute. Preserve the other native
        // languages and unrelated paragraph-mark formatting.
        if (key == 'lang' || key == 'langBidi') {
          final attribute = key == 'langBidi' ? 'bidi' : 'val';
          mergeLanguage(
            result,
            generated.firstChild('lang')?.getAttribute(attribute),
            attribute: attribute,
          );
        } else {
          var marker = result.firstChild(
            'rPr',
            namespaceUri: OfficeNamespaces.w,
          );
          final value = generated
              .firstChild('rPr')
              ?.firstChild('lang')
              ?.getAttribute('val');
          if (marker == null && value != null) {
            marker = XmlElement(
              localName: 'rPr',
              prefix: 'w',
              namespaceUri: OfficeNamespaces.w,
            );
            result.addChild(marker);
          }
          if (marker != null) mergeLanguage(marker, value);
        }
        continue;
      }
      result.children.removeWhere(
        (n) =>
            n is XmlElement &&
            (n.localName == key || key == 'sz' && n.localName == 'szCs'),
      );
      final List<XmlElement> replacement = generated.childrenNamed(key);
      if (replacement.isNotEmpty) {
        for (final n in replacement) {
          result.addChild(n.copy());
        }
      } else if (const {
        'strike',
        'keepLines',
        'pageBreakBefore',
        'bidi',
      }.contains(key)) {
        result.addChild(
          XmlElement(localName: key, prefix: 'w')
            ..setAttribute('val', '0', prefix: 'w'),
        );
      } else if (const {'u', 'highlight', 'vertAlign'}.contains(key)) {
        result.addChild(
          XmlElement(localName: key, prefix: 'w')..setAttribute(
            'val',
            key == 'vertAlign' ? 'baseline' : 'none',
            prefix: 'w',
          ),
        );
      }
    }
    result.children.removeWhere(
      (n) => n is XmlElement && n.localName == 'sectPr',
    );
    for (final n in generated.childrenNamed('sectPr')) {
      result.addChild(n.copy());
    }
    orderChildren(result);
    return result;
  }

  /// Change the owned language attribute while preserving native metadata.
  static void mergeLanguage(
    XmlElement runProperties,
    String? language, {
    String attribute = 'val',
  }) {
    var lang = runProperties.firstChild(
      'lang',
      namespaceUri: OfficeNamespaces.w,
    );
    if (lang == null && language != null && language.isNotEmpty) {
      lang = XmlElement(
        localName: 'lang',
        prefix: 'w',
        namespaceUri: OfficeNamespaces.w,
      )..setAttribute('w', OfficeNamespaces.w, prefix: 'xmlns');
      runProperties.addChild(lang);
    }
    if (lang == null) return;
    if (language == null || language.isEmpty) {
      lang.attributes.removeWhere(
        (a) => a.localName == attribute && a.namespaceUri == OfficeNamespaces.w,
      );
      if (lang.attributes.every((a) => a.prefix == 'xmlns')) {
        runProperties.children.remove(lang);
      }
    } else {
      lang.setAttribute('w', OfficeNamespaces.w, prefix: 'xmlns');
      lang.setAttribute(
        attribute,
        language,
        prefix: 'w',
        namespaceUri: OfficeNamespaces.w,
      );
    }
    orderChildren(runProperties);
  }

  /// Canonical OOXML property order for sparse style and direct property edits.
  static void orderChildren(XmlElement element) {
    const runOrder = [
      'rStyle',
      'rFonts',
      'b',
      'bCs',
      'i',
      'iCs',
      'caps',
      'smallCaps',
      'strike',
      'dstrike',
      'outline',
      'shadow',
      'emboss',
      'imprint',
      'noProof',
      'snapToGrid',
      'vanish',
      'webHidden',
      'color',
      'spacing',
      'w',
      'kern',
      'position',
      'sz',
      'szCs',
      'highlight',
      'u',
      'effect',
      'bdr',
      'shd',
      'fitText',
      'vertAlign',
      'rtl',
      'cs',
      'em',
      'lang',
      'eastAsianLayout',
      'specVanish',
      'oMath',
      'rPrChange',
    ];
    const paragraphOrder = [
      'pStyle',
      'keepNext',
      'keepLines',
      'pageBreakBefore',
      'framePr',
      'widowControl',
      'numPr',
      'suppressLineNumbers',
      'pBdr',
      'shd',
      'tabs',
      'suppressAutoHyphens',
      'kinsoku',
      'wordWrap',
      'overflowPunct',
      'topLinePunct',
      'autoSpaceDE',
      'autoSpaceDN',
      'bidi',
      'adjustRightInd',
      'snapToGrid',
      'spacing',
      'ind',
      'contextualSpacing',
      'mirrorIndents',
      'suppressOverlap',
      'jc',
      'textDirection',
      'textAlignment',
      'textboxTightWrap',
      'outlineLvl',
      'divId',
      'cnfStyle',
      'rPr',
      'sectPr',
      'pPrChange',
    ];
    final order = switch (element.localName) {
      'rPr' => runOrder,
      'pPr' => paragraphOrder,
      'tblPr' => [
        'tblStyle',
        'tblpPr',
        'tblOverlap',
        'bidiVisual',
        'tblStyleRowBandSize',
        'tblStyleColBandSize',
        'tblW',
        'jc',
        'tblCellSpacing',
        'tblInd',
        'tblBorders',
        'shd',
        'tblLayout',
        'tblCellMar',
        'tblLook',
        'tblCaption',
        'tblDescription',
        'tblPrChange',
      ],
      'tcPr' => [
        'cnfStyle',
        'tcW',
        'gridSpan',
        'hMerge',
        'vMerge',
        'tcBorders',
        'shd',
        'noWrap',
        'tcMar',
        'textDirection',
        'tcFitText',
        'vAlign',
        'hideMark',
        'headers',
        'cellIns',
        'cellDel',
        'cellMerge',
        'tcPrChange',
      ],
      'style' => [
        'name',
        'aliases',
        'basedOn',
        'next',
        'link',
        'autoRedefine',
        'hidden',
        'uiPriority',
        'semiHidden',
        'unhideWhenUsed',
        'qFormat',
        'locked',
        'personal',
        'personalCompose',
        'personalReply',
        'rsid',
        'pPr',
        'rPr',
        'tblPr',
        'trPr',
        'tcPr',
        'tblStylePr',
      ],
      _ => <String>[],
    };
    int rank(XmlNode n) {
      final i = n is XmlElement ? order.indexOf(n.localName) : -1;
      return i < 0 ? order.length : i;
    }

    element.children.sort((a, b) => rank(a).compareTo(rank(b)));
  }
}
