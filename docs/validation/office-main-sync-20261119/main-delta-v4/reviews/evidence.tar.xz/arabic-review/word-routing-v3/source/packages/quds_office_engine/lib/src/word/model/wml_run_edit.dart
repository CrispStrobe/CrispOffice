import '../properties/wml_properties.dart';
import 'wml_clone.dart';
import 'wml_document.dart';
import 'word_bookmarks.dart';
import 'word_content_controls.dart';
import 'word_field_spans.dart';

/// Split and format [WmlRun] spans inside a paragraph.
abstract final class WmlRunEdit {
  /// propsAt API.
  static WmlRunProps propsAt(WmlParagraph paragraph, int index) {
    var offset = 0;
    WmlRunProps last = WmlRunProps();
    for (final WmlInline inline in paragraph.inlines) {
      if (inline is! WmlRun) {
        continue;
      }
      last = inline.properties;
      final int end = offset + inline.text.length;
      if (index < end) {
        return inline.properties;
      }
      offset = end;
    }
    return last;
  }

  /// splitAt API.
  static void splitAt(WmlParagraph paragraph, int index) {
    if (normalizeRange(paragraph, index, index).start != index) return;
    var offset = 0;
    for (int i = 0; i < paragraph.inlines.length; i++) {
      final WmlInline inline = paragraph.inlines[i];
      if (inline is! WmlRun) {
        continue;
      }
      final int end = offset + inline.text.length;
      if (index > offset && index < end) {
        // Note marks and cached inline field results are indivisible.
        if (inline.isAtomic) return;
        final int local = index - offset;
        paragraph.inlines.replaceRange(i, i + 1, <WmlInline>[
          WmlRun(
            text: inline.text.substring(0, local),
            properties: inline.properties.copy(),
            hyperlink: inline.hyperlink,
            commentIds: List<int>.from(inline.commentIds),
            noteRefId: inline.noteRefId,
            inlineVisual: inline.inlineVisual,
            noteRefEndnote: inline.noteRefEndnote,
            noteRefCustomMark: inline.noteRefCustomMark,
            fieldInstruction: inline.fieldInstruction,
            fieldLocked: inline.fieldLocked,
            fieldDirty: inline.fieldDirty,
          ),
          WmlRun(
            text: inline.text.substring(local),
            properties: inline.properties.copy(),
            hyperlink: inline.hyperlink,
            commentIds: List<int>.from(inline.commentIds),
            noteRefId: inline.noteRefId,
            inlineVisual: inline.inlineVisual,
            noteRefEndnote: inline.noteRefEndnote,
            noteRefCustomMark: inline.noteRefCustomMark,
            fieldInstruction: inline.fieldInstruction,
            fieldLocked: inline.fieldLocked,
            fieldDirty: inline.fieldDirty,
          ),
        ]);
        return;
      }
      offset = end;
    }
  }

  /// Moves the actual tail, including zero-width source markup, to a new
  /// paragraph. End markers at the boundary stay with the preceding content;
  /// a start marker and the following boundary packet stay with the tail.
  ///
  /// Inline-only wrappers cannot span paragraphs. Rejecting their split before
  /// changing either list keeps undo history and export structure intact.
  static List<WmlInline> splitParagraphInlines(
    WmlParagraph paragraph,
    int index,
  ) {
    RangeError.checkValueInInterval(index, 0, paragraph.text.length, 'index');
    final range = normalizeRange(paragraph, index, index);
    if (range.start != index || range.end != index) {
      throw ArgumentError('A paragraph cannot split an atomic text token.');
    }
    WordContentControls.assertCanSplit(paragraph, index);
    final leftControls = <WmlContentControlData>{
      for (final span in WordContentControls.spans(paragraph))
        if (span.end < index || (span.end == index && span.start < span.end))
          span.control,
    };
    final starts = <String, int>{};
    final emptyBookmarks = <String>{};
    var position = 0;
    for (final WmlInline inline in paragraph.inlines) {
      if (inline is WmlRun) position += inline.text.length;
      if (inline is WmlBookmarkBoundary) {
        final id = WordBookmarks.canonicalId(inline.id);
        if (inline.isStart) {
          starts[id] = position;
        } else if (starts[id] == position) {
          emptyBookmarks.add(id);
        }
      }
    }
    splitAt(paragraph, index);
    final citationSide = <WmlInline, bool>{
      for (final span in WordFieldSpans.zoteroCitations(paragraph))
        for (var i = span.first; i <= span.last; i++)
          paragraph.inlines[i]: span.end <= index,
    };
    position = 0;
    final head = <WmlInline>[];
    final tail = <WmlInline>[];
    for (final inline in paragraph.inlines) {
      final onLeft =
          citationSide[inline] ??
          (inline is WmlRun
              ? position + inline.text.length <= index
              : inline is WmlContentControlBoundary
              ? leftControls.contains(inline.control)
              : inline is WmlBookmarkBoundary &&
                    !inline.isStart &&
                    !emptyBookmarks.contains(
                      WordBookmarks.canonicalId(inline.id),
                    )
              ? position <= index
              : position < index);
      (onLeft ? head : tail).add(inline);
      if (inline is WmlRun) position += inline.text.length;
    }
    paragraph.inlines
      ..clear()
      ..addAll(head);
    return tail;
  }

  /// applyRange API.
  static void applyRange(
    WmlParagraph paragraph,
    int start,
    int end,
    void Function(WmlRunProps props) update,
  ) {
    if (start > end) {
      final int swap = start;
      start = end;
      end = swap;
    }
    final int length = paragraph.text.length;
    start = start.clamp(0, length);
    end = end.clamp(0, length);
    if (start == end) {
      if (paragraph.inlines.whereType<WmlRun>().isEmpty) {
        final WmlRunProps props = WmlRunProps();
        update(props);
        paragraph.inlines.add(WmlRun(properties: props));
      }
      return;
    }
    final range = normalizeRange(paragraph, start, end);
    start = range.start;
    end = range.end;
    splitAt(paragraph, end);
    splitAt(paragraph, start);
    var offset = 0;
    for (final WmlInline inline in paragraph.inlines) {
      if (inline is! WmlRun) {
        continue;
      }
      final int runEnd = offset + inline.text.length;
      if (((offset >= start && runEnd <= end) ||
              (inline.isAtomic && offset < end && runEnd > start)) &&
          inline.text.isNotEmpty) {
        update(inline.properties);
      }
      offset = runEnd;
    }
    coalesce(paragraph);
  }

  /// replaceRange API.
  static void replaceRange(
    WmlParagraph paragraph,
    int start,
    int end,
    String insert, {
    int? styleSource,
  }) {
    final range = normalizeRange(paragraph, start, end);
    start = range.start;
    end = range.end;
    WordContentControls.assertCanEdit(paragraph, start, end);
    final removedCitationMarkers = <WmlInline>{
      if (start < end)
        for (final span in WordFieldSpans.zoteroCitations(paragraph))
          if (start <= span.start && end >= span.end)
            for (var i = span.first; i <= span.last; i++)
              if (paragraph.inlines[i] is WmlFieldBoundary)
                paragraph.inlines[i],
    };
    final int length = paragraph.text.length;
    if (styleSource != null) {
      RangeError.checkValueInInterval(
        styleSource,
        0,
        length - 1,
        'styleSource',
      );
    }
    final styleIndex = styleSource ?? (start == length ? start - 1 : start);
    final WmlRunProps props = propsAt(paragraph, styleIndex);
    final List<int> commentIds = _commentIdsAt(paragraph, styleIndex);
    if (start == end &&
        (WordContentControls.hasInlineControls(paragraph) ||
            WordFieldSpans.zoteroCitations(paragraph).isNotEmpty)) {
      if (insert.isNotEmpty) {
        insertRuns(paragraph, start, <WmlRun>[
          WmlRun(
            text: insert,
            properties: props.copy(),
            commentIds: List<int>.from(commentIds),
          ),
        ]);
      }
      return;
    }
    splitAt(paragraph, end);
    splitAt(paragraph, start);
    final List<WmlInline> next = <WmlInline>[];
    var offset = 0;
    var inserted = false;
    for (final WmlInline inline in paragraph.inlines) {
      if (inline is! WmlRun) {
        if (!removedCitationMarkers.contains(inline)) next.add(inline);
        continue;
      }
      final int runEnd = offset + inline.text.length;
      final bool inside = offset >= start && runEnd <= end;
      if (inside) {
        if (!inserted) {
          if (insert.isNotEmpty) {
            next.add(
              WmlRun(
                text: insert,
                properties: props.copy(),
                commentIds: List<int>.from(commentIds),
              ),
            );
          }
          inserted = true;
        }
      } else {
        if (!inserted && offset >= end) {
          if (insert.isNotEmpty) {
            next.add(
              WmlRun(
                text: insert,
                properties: props.copy(),
                commentIds: List<int>.from(commentIds),
              ),
            );
          }
          inserted = true;
        }
        next.add(inline);
      }
      offset = runEnd;
    }
    if (!inserted && insert.isNotEmpty) {
      next.add(
        WmlRun(
          text: insert,
          properties: props.copy(),
          commentIds: List<int>.from(commentIds),
        ),
      );
    }
    paragraph.inlines
      ..clear()
      ..addAll(next);
    if (paragraph.inlines.whereType<WmlRun>().isEmpty) {
      paragraph.inlines.add(WmlRun(properties: props.copy()));
    }
    coalesce(paragraph);
  }

  /// Bounds for an edit that cannot split a note mark or inline field result.
  ///
  /// A nonempty selection touching an atomic field includes the whole result. A
  /// collapsed caret inside a result moves after it, just as
  /// [insertRuns] does. Callers can use these bounds for undo and selection.
  static ({int start, int end}) normalizeRange(
    WmlParagraph paragraph,
    int start,
    int end, {
    bool protectZoteroCitations = true,
  }) {
    if (start > end) {
      final int swap = start;
      start = end;
      end = swap;
    }
    final int length = paragraph.text.length;
    start = start.clamp(0, length);
    end = end.clamp(0, length);
    final bool collapsed = start == end;
    final citations = protectZoteroCitations
        ? WordFieldSpans.zoteroCitations(paragraph)
        : const <WmlZoteroEditSpan>[];
    for (final span in citations) {
      if (!span.canEdit && span.touches(start, end)) {
        throw UnsupportedError(
          'This Zotero citation has locked, nested, malformed or unsupported '
          'field content. Resolve or unlink it before editing its text.',
        );
      }
    }
    for (final span in citations) {
      if (collapsed && start > span.start && start < span.end) {
        return (start: span.end, end: span.end);
      }
      if (!collapsed && span.touches(start, end)) {
        if (start > span.start) start = span.start;
        if (end < span.end) end = span.end;
      }
    }
    var offset = 0;
    for (final WmlRun run in paragraph.inlines.whereType<WmlRun>()) {
      final int runEnd = offset + run.text.length;
      if (run.isAtomic) {
        if (collapsed && start > offset && start < runEnd) {
          return (start: runEnd, end: runEnd);
        }
        if (!collapsed && start < runEnd && end > offset) {
          if (start > offset) start = offset;
          if (end < runEnd) end = runEnd;
        }
      }
      offset = runEnd;
    }
    return (start: start, end: end);
  }

  /// extractRuns API.
  static List<WmlRun> extractRuns(WmlParagraph paragraph, int start, int end) {
    if (start > end) {
      final int swap = start;
      start = end;
      end = swap;
    }
    final int length = paragraph.text.length;
    start = start.clamp(0, length);
    end = end.clamp(0, length);
    if (start == end) {
      return <WmlRun>[];
    }
    final List<WmlRun> out = <WmlRun>[];
    var offset = 0;
    for (final WmlInline inline in paragraph.inlines) {
      if (inline is! WmlRun) {
        continue;
      }
      final int runEnd = offset + inline.text.length;
      final int from = start > offset ? start : offset;
      final int to = end < runEnd ? end : runEnd;
      if (to > from) {
        out.add(
          WmlRun(
            text: inline.isAtomic
                ? inline.text
                : inline.text.substring(from - offset, to - offset),
            properties: inline.properties.copy(),
            hyperlink: inline.hyperlink,
            commentIds: List<int>.from(inline.commentIds),
            noteRefId: inline.noteRefId,
            inlineVisual: inline.inlineVisual,
            noteRefEndnote: inline.noteRefEndnote,
            noteRefCustomMark: inline.noteRefCustomMark,
            fieldInstruction: inline.fieldInstruction,
            fieldLocked: inline.fieldLocked,
            fieldDirty: inline.fieldDirty,
          ),
        );
      }
      offset = runEnd;
    }
    return out;
  }

  /// insertRuns API.
  static void insertRuns(WmlParagraph paragraph, int index, List<WmlRun> runs) {
    insertInlines(paragraph, index, runs);
  }

  /// Inserts native inline content without discarding source boundary tokens.
  static void insertInlines(
    WmlParagraph paragraph,
    int index,
    List<WmlInline> inlines,
  ) {
    if (inlines.isEmpty) {
      return;
    }
    index = normalizeRange(paragraph, index, index).start;
    WordContentControls.assertCanEdit(paragraph, index, index);
    splitAt(paragraph, index);
    var offset = 0;
    final controlIndex = WordContentControls.insertionIndex(paragraph, index);
    var insertAt = controlIndex ?? paragraph.inlines.length;
    for (int i = 0; i < paragraph.inlines.length; i++) {
      if (controlIndex != null) break;
      final WmlInline inline = paragraph.inlines[i];
      if (inline is! WmlRun) {
        continue;
      }
      if (offset >= index) {
        insertAt = i;
        break;
      }
      offset += inline.text.length;
      insertAt = i + 1;
    }
    for (final span in WordFieldSpans.zoteroCitations(paragraph)) {
      if (insertAt > span.first && insertAt <= span.last) {
        insertAt = index <= span.start ? span.first : span.last + 1;
      }
    }
    paragraph.inlines.insertAll(insertAt, WmlClone.inlines(inlines));
    coalesce(paragraph);
  }

  /// coalesce API.
  static void coalesce(WmlParagraph paragraph) {
    if (paragraph.inlines.length < 2) {
      return;
    }
    final List<WmlInline> next = <WmlInline>[];
    for (final WmlInline inline in paragraph.inlines) {
      if (inline is WmlRun &&
          next.isNotEmpty &&
          next.last is WmlRun &&
          _sameRun(next.last as WmlRun, inline)) {
        (next.last as WmlRun).text += inline.text;
      } else {
        next.add(inline);
      }
    }
    paragraph.inlines
      ..clear()
      ..addAll(next);
  }

  static List<int> _commentIdsAt(WmlParagraph paragraph, int index) {
    var offset = 0;
    List<int> last = const <int>[];
    for (final WmlInline inline in paragraph.inlines) {
      if (inline is! WmlRun) {
        continue;
      }
      last = inline.commentIds;
      final int end = offset + inline.text.length;
      if (index < end) {
        return List<int>.from(inline.commentIds);
      }
      offset = end;
    }
    return List<int>.from(last);
  }

  static bool _sameRun(WmlRun a, WmlRun b) {
    return !a.isAtomic &&
        !b.isAtomic &&
        _sameProps(a.properties, b.properties) &&
        _sameLink(a.hyperlink, b.hyperlink) &&
        _sameInts(a.commentIds, b.commentIds);
  }

  static bool _sameLink(WmlHyperlink? a, WmlHyperlink? b) {
    if (a == null || b == null) return a == b;
    return a.anchor == b.anchor && a.url == b.url && a.file == b.file;
  }

  static bool _sameValues(Map<String, String>? a, Map<String, String>? b) {
    if (identical(a, b)) return true;
    if (a == null || b == null || a.length != b.length) return false;
    return a.entries.every((entry) => b[entry.key] == entry.value);
  }

  static bool _sameInts(List<int> a, List<int> b) {
    if (a.length != b.length) {
      return false;
    }
    for (int i = 0; i < a.length; i++) {
      if (a[i] != b[i]) {
        return false;
      }
    }
    return true;
  }

  static bool _sameProps(WmlRunProps a, WmlRunProps b) {
    // Equal visible formatting is insufficient: source XML retains properties
    // such as script-specific language and direction extensions.
    // Import baselines and explicit defaults also affect subsequent export.
    return a.styleId == b.styleId &&
        a.sourcePropertiesXml == b.sourcePropertiesXml &&
        _sameValues(a.importedValues, b.importedValues) &&
        a.explicitProperties.length == b.explicitProperties.length &&
        a.explicitProperties.containsAll(b.explicitProperties) &&
        a.bold == b.bold &&
        a.italic == b.italic &&
        a.underline == b.underline &&
        a.strike == b.strike &&
        a.smallCaps == b.smallCaps &&
        a.color == b.color &&
        a.highlight == b.highlight &&
        a.fontSizeHalfPoints == b.fontSizeHalfPoints &&
        a.asciiFont == b.asciiFont &&
        a.csFont == b.csFont &&
        a.vertAlign == b.vertAlign &&
        a.proofingLanguage == b.proofingLanguage &&
        a.complexScriptLanguage == b.complexScriptLanguage &&
        a.complexScript == b.complexScript &&
        a.noProof == b.noProof;
  }
}
