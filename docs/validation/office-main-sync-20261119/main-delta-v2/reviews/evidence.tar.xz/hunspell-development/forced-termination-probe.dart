import 'dart:convert';
import 'dart:ffi';

import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_proofing_hunspell/quds_proofing_hunspell.dart';

OfficeProofingRequest request(String text) => OfficeProofingRequest(
  documentId: 'forced-termination',
  blockId: 'paragraph',
  revision: 1,
  language: 'ar',
  text: text,
);

Future<void> main(List<String> args) async {
  final library = DynamicLibrary.open(args.single);
  final live = library.lookupFunction<Int32 Function(), int Function()>(
    'quds_hunspell_test_live_handles',
  );
  final closed = library.lookupFunction<Int32 Function(), int Function()>(
    'quds_hunspell_test_closed_handles',
  );
  final provider = HunspellProofingProvider(
    bundle: ayaspellArabic,
    dictionary: const HunspellDictionaryFiles(affPath: 'a', dicPath: 'd'),
    nativeLibraryPath: args.single,
    timeout: const Duration(milliseconds: 100),
  );
  final ready = await provider.check(request('هذا'));
  if (ready.status != OfficeProofingStatus.success || live() != 1) {
    throw StateError('Fixture dictionary did not open.');
  }
  final watch = Stopwatch()..start();
  final failed = await provider.check(request('تعليق'));
  await provider.dispose();
  final disposedAfter = watch.elapsedMilliseconds;
  final liveAfterDispose = live();
  while (live() != 0 && watch.elapsed < const Duration(seconds: 10)) {
    await Future<void>.delayed(const Duration(milliseconds: 20));
  }
  final record = {
    'status': failed.status == OfficeProofingStatus.failed &&
            disposedAfter < 2900 &&
            liveAfterDispose == 1 &&
            live() == 0 &&
            closed() == 1
        ? 'PASS'
        : 'FAIL',
    'request_status': failed.status.name,
    'dispose_ms': disposedAfter,
    'live_handles_after_bounded_dispose': liveAfterDispose,
    'live_handles_after_finalization': live(),
    'closed_handles': closed(),
    'finalization_ms': watch.elapsedMilliseconds,
    'scope': 'A 3-second native call exceeds the 2-second shutdown deadline. '
        'The worker is terminated, and the finalizer closes the handle only '
        'after the in-progress FFI call can finish. Development control only.',
  };
  print(jsonEncode(record));
  if (record['status'] != 'PASS') throw StateError('Forced cleanup failed.');
}
