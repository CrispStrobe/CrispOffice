#!/usr/bin/env python3
"""Fetch only immutable dictionary catalog entries and verify every byte pin."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import urllib.request


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--catalog", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    catalog = args.catalog.read_bytes()
    text = catalog.decode()
    repository = re.search(r"repository: '([^']+)'", text).group(1)
    revision = re.search(r"revision: '([0-9a-f]{40})'", text).group(1)
    pins = re.findall(r"HunspellArtifact\(\s*'([A-Za-z0-9._-]+)',\s*'([0-9a-f]{64})',\s*(\d+),", text)
    if len(pins) != 8 or len({name for name, _, _ in pins}) != 8:
        raise ValueError("Expected exactly eight immutable AyaSpell file pins")
    args.output.mkdir(parents=True, exist_ok=True)
    def fetch(pin):
        name, expected_sha, count = pin
        expected_bytes = int(count)
        url = f"https://huggingface.co/{repository}/resolve/{revision}/{name}"
        row = {"file": name, "url": url, "expected_bytes": expected_bytes, "expected_sha256": expected_sha, "started_at_utc": datetime.now(timezone.utc).isoformat()}
        try:
            with urllib.request.urlopen(url, timeout=40) as response:
                data = response.read(expected_bytes + 1)
                row.update(http_status=response.status, response_url=response.url)
            actual_sha = hashlib.sha256(data).hexdigest()
            row.update(bytes=len(data), sha256=actual_sha)
            if len(data) != expected_bytes or actual_sha != expected_sha:
                raise ValueError("Downloaded content does not match catalog")
            (args.output / name).write_bytes(data)
            row["status"] = "PASS"
        except Exception as error:
            row.update(status="FAIL", error=repr(error))
        row["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        return row
    with ThreadPoolExecutor(max_workers=4) as executor:
        records = list(executor.map(fetch, pins))
    report = {"status": "PASS" if all(r["status"] == "PASS" for r in records) else "FAIL", "catalog": str(args.catalog.resolve()), "catalog_sha256": hashlib.sha256(catalog).hexdigest(), "repository": repository, "revision": revision, "files": records, "scope": "Read-only downloads of pinned dictionary data and notices for native qualification; no model upload, no mutable revision, and no application acceptance claim."}
    receipt = args.output.parent / "dictionary-download-receipt.json"
    receipt.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "files": [{"file": r["file"], "status": r["status"], "error": r.get("error")} for r in records]}))
    if report["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
