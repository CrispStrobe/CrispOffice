#!/usr/bin/env python3
"""Recount retained Hunspell development probes without folding them into acceptance."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--runtime", required=True, type=Path)
    parser.add_argument("--review", required=True, type=Path)
    args = parser.parse_args()
    repo, runtime, review = args.repo.resolve(), args.runtime.resolve(), args.review.resolve()
    sys.dont_write_bytecode = True
    runner_path = repo / "docs/validation/document-review-notes-20261118/run_checks.py"
    spec = importlib.util.spec_from_file_location("development_accounting", runner_path)
    assert spec is not None and spec.loader is not None
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    package = review / "source/packages/quds_proofing_hunspell"
    suites = {
        "lifecycle-red": ["test/hunspell_native_lifecycle_test.dart"],
        "lifecycle-green": ["test/hunspell_native_lifecycle_test.dart", "test/hunspell_provider_test.dart"],
        "provider-node-green": ["test/hunspell_provider_test.dart"],
        "actual-native-green": ["test/hunspell_native_test.dart"],
    }
    runs = {}
    accounting_blockers = []
    for name, tests in suites.items():
        log = review / (name + ".jsonl")
        parsed = runner.parse_reporter(log, package, tests)
        (review / (name + "-accounting.json")).write_text(json.dumps(parsed, indent=2) + "\n")
        passed = runner.reporter_passed(parsed)
        runs[name] = {
            "log": log.name, "log_sha256": sha(log), "tests": tests,
            "observed_exit_code": 1 if name == "lifecycle-red" else 0,
            "passed": parsed["passed"], "failed": parsed["failed"], "skipped": parsed["skipped"],
            "strict_reporter_passed": passed,
            "platform": "node" if "node" in name else "vm",
            "strict_event_accounting": parsed["strict_event_accounting"],
        }
        if name == "lifecycle-red":
            if parsed["failed"] != 1 or parsed["passed"] != 0 or parsed["skipped"] != 0:
                raise ValueError("The retained RED is not the expected one-failure reproduction")
        elif not passed:
            accounting_blockers.append({"run": name, "accounting": parsed["strict_event_accounting"]})
    source_manifest = json.loads((review / "native-disposal-files.json").read_text())
    for row in source_manifest["files"]:
        current = Path(row["scratch"])
        if sha(current) != row["sha256"]:
            raise ValueError("The reviewed source changed after the patch was prepared: " + row["path"])
        destination = review / "lifecycle-green-source" / row["path"]
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(current.read_bytes())
    forced = json.loads((review / "forced-termination-probe.log").read_text())
    if forced["status"] != "PASS":
        raise ValueError("Forced-termination probe did not pass")
    if "No issues found!" not in (review / "lifecycle-analysis.log").read_text() or "(0 changed)" not in (review / "lifecycle-format.log").read_text():
        raise ValueError("Strict analysis or formatting success is missing")
    evidence_files = [
        "native-build-receipt.json", "native-build.log", "dictionary-download-receipt.json",
        "lifecycle-shim-build-receipt.json", "lifecycle-shim-build.log", "lifecycle-red-receipt.json",
        "native-disposal-files.json", "native-disposal-fix.patch", "patch-check.log",
        "lifecycle-analysis.log", "lifecycle-format.log", "package_config.json",
        "forced-termination-probe.dart", "forced-termination-probe.log", "forced-termination-shim.cpp",
    ]
    report = {
        "schema": 1, "status": "DEVELOPMENT_RESULTS_RECORDED",
        "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
        "incoming_source": "b655b8a37fddc874bd42a453c371eed6253e82d8",
        "scope": "Development probes of the isolated modified Hunspell package with pinned workspace/runtime dependencies. These results are separate from the frozen merged-source acceptance gate and all earlier application totals.",
        "defect": "Disposal killed the Dart isolate without closing its C++ dictionary handle. Awaiting repeated provider disposal could also return before the original cleanup completed.",
        "repair": "Graceful native close/ack, shared disposal completion, and a Finalizable native dictionary owner with a retained NativeFinalizer callback for exceptional termination.",
        "runs": runs,
        "strict_accounting_blockers": accounting_blockers,
        "native_reporter_boundary": "The real native file's eight assertions passed, but native stderr from its intentional missing-dictionary case creates three malformed JSON reporter lines. This run is not strict qualification evidence and must not be reported as a clean gate. Parent notified before final publication.",
        "actual_native_environment": {"QUDS_HUNSPELL_TEST_LIBRARY": str(review / "native/libquds_proofing_hunspell.so"), "QUDS_HUNSPELL_TEST_DICTIONARY": str(review / "dictionary"), "QUDS_HUNSPELL_LIVE_DOWNLOAD": "1"},
        "lifecycle_environment": {"QUDS_HUNSPELL_LIFECYCLE_LIBRARY": str(review / "native/libhunspell_lifecycle_shim.so")},
        "forced_termination_probe": forced,
        "source_manifest": source_manifest,
        "analysis_and_format": {"observed_exit_codes": [0, 0], "dart_paths": [row["path"] for row in source_manifest["files"] if row["path"].endswith(".dart")]},
        "evidence_sha256": {name: sha(review / name) for name in evidence_files},
        "native_artifacts_sha256": {str(path): sha(path) for path in sorted((review / "native").glob("*.so"))},
        "runtime_receipt_sha256": sha(runtime / "runtime.json"),
        "runtime_environment_sha256": sha(runtime / "env.sh"),
        "reporter_accounting_sha256": sha(runner_path),
        "collector_sha256": sha(Path(__file__)),
        "unperformed_scope": ["CMake invocation", "WebAssembly engine build or execution", "macOS build/signing/runtime", "independent Arabic linguistic acceptance"],
        "github_actions_accessed": False,
    }
    (review / "development-receipt.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "runs": {name: {key: value[key] for key in ("passed", "failed", "skipped", "strict_reporter_passed")} for name, value in runs.items()}, "forced_termination": forced["status"]}))


if __name__ == "__main__":
    main()
