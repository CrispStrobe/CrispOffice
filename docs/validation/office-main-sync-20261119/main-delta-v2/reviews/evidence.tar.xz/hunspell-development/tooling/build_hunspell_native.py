#!/usr/bin/env python3
"""Verify committed Hunspell subset sources, then build their Linux C ABI directly."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--source", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    repo, output = args.repo.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    def git(*values: str) -> bytes:
        return subprocess.check_output(["git", "-C", str(repo), *values])
    source = git("rev-parse", "--verify", args.source + "^{commit}").decode().strip()
    package_path = "packages/quds_proofing_hunspell"
    package = output / "source" / package_path
    rows = git("ls-tree", "-r", "-z", source, "--", package_path).split(b"\0")
    source_files = []
    for row in rows:
        if not row:
            continue
        metadata, path_bytes = row.split(b"\t", 1)
        mode, kind, oid = metadata.decode().split()
        path = path_bytes.decode()
        if mode not in {"100644", "100755"} or kind != "blob":
            raise ValueError("Nonregular committed package input: " + path)
        data = git("cat-file", "blob", oid)
        target = output / "source" / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        source_files.append({"path": path, "git_blob": oid, "mode": mode, "bytes": len(data), "sha256": sha(data)})
    manifest_bytes = (package / "licenses/manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    archive_path = package / "licenses" / manifest["source_bundle"]["file"]
    archive_bytes = archive_path.read_bytes()
    if sha(archive_bytes) != manifest["source_bundle"]["sha256"]:
        raise ValueError("Committed source bundle SHA mismatch")
    expected = {"hunspell-1.7.2/src/hunspell/" + name: value for name, value in manifest["component"]["compiled_files"].items()}
    expected.update({"hunspell-1.7.2/" + name: value for name, value in manifest["notices"].items()})
    actual, archive_members = [], []
    upstream = output / "verified-upstream"
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:gz") as archive:
        verified = []
        for member in archive:
            name = member.name
            path = PurePosixPath(name)
            if path.is_absolute() or ".." in path.parts or not member.isfile() or member.issparse() or name not in expected:
                raise ValueError("Unexpected source bundle member: " + name)
            stream = archive.extractfile(member)
            assert stream is not None
            data = stream.read()
            if sha(data) != expected[name]:
                raise ValueError("Source member SHA mismatch: " + name)
            actual.append(name)
            archive_members.append({"path": name, "bytes": len(data), "sha256": sha(data)})
            verified.append((name, data))
        if set(actual) != set(expected) or len(actual) != len(set(actual)):
            raise ValueError("Source bundle member set differs from manifest")
    # Materialize only after the entire archive and exact membership are verified.
    for name, data in verified:
        target = upstream / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    cmake = (package / "native/CMakeLists.txt").read_text()
    units = re.findall(r"\$\{H\}/([A-Za-z0-9_]+\.cxx)", cmake)
    if len(units) != 10 or len(set(units)) != 10 or set(units) != {name for name in manifest["component"]["compiled_files"] if name.endswith(".cxx")}:
        raise ValueError("The ten CMake translation units do not match the manifest")
    include = upstream / "hunspell-1.7.2/src/hunspell"
    adapter = package / "native/src/quds_hunspell.cpp"
    target = output / "native/libquds_proofing_hunspell.so"
    target.parent.mkdir(parents=True, exist_ok=True)
    compiler = Path("/usr/bin/c++").resolve()
    command = [str(compiler), "-std=c++14", "-fPIC", "-fvisibility=hidden", "-DHUNSPELL_STATIC", "-shared", "-O2", "-I" + str(include), str(adapter), *[str(include / name) for name in units], "-o", str(target)]
    inputs = {str(path): sha(path.read_bytes()) for path in [adapter, package / "native/CMakeLists.txt", package / "licenses/manifest.json", *[include / name for name in manifest["component"]["compiled_files"]]]}
    receipt = {
        "status": "BUILDING", "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_commit": source, "source_tree": git("rev-parse", source + "^{tree}").decode().strip(),
        "source_files": source_files, "license_manifest_sha256": sha(manifest_bytes),
        "source_bundle_sha256": sha(archive_bytes), "archive_members": archive_members,
        "exact_archive_members_verified_before_extraction": True,
        "compiler": {"path": str(compiler), "sha256": sha(compiler.read_bytes()), "version": subprocess.check_output([str(compiler), "--version"], text=True), "target": subprocess.check_output([str(compiler), "-dumpmachine"], text=True).strip()},
        "command": command, "translation_units": units, "inputs_before": inputs,
        "scope": "Direct Linux shared-library compilation from the exact ten committed CMake translation units and MIT adapter, using the verified committed Hunspell subset archive. This is not execution of CMake, a macOS/iOS build, or WebAssembly qualification. No repository changes, remote inventories, or hosted CI.",
    }
    receipt_path = output / "native-build-receipt.json"
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    with (output / "native-build.log").open("wb") as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    receipt.update(exit_code=result.returncode, finished_at_utc=datetime.now(timezone.utc).isoformat(), log_sha256=sha((output / "native-build.log").read_bytes()))
    receipt["inputs_unchanged"] = all(sha(Path(path).read_bytes()) == value for path, value in inputs.items())
    if result.returncode == 0:
        receipt["artifact"] = {"path": str(target), "bytes": target.stat().st_size, "sha256": sha(target.read_bytes())}
        receipt["dynamic_dependencies"] = subprocess.check_output(["ldd", str(target)], text=True)
    receipt["status"] = "PASS" if result.returncode == 0 and receipt["inputs_unchanged"] else "FAIL"
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in ("status", "source_commit", "exit_code", "artifact") if key in receipt}))
    if receipt["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
