#!/usr/bin/env python3
"""Verify the incoming Arabic proofing archive and original source identities."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile


PAIRS = [
    (
        'docs/validation/office-main-completion-20261119/release/arabic-proofing.tar.xz',
        'docs/validation/office-main-completion-20261119/release/arabic-proofing.index.json',
    ),
]
COLLECT = {
    'accepted-ba7c1e26/verification.json',
    'accepted-ba7c1e26/source-before.json',
    'accepted-ba7c1e26/source-after.json',
    'accepted-ba7c1e26/environment-before.json',
    'accepted-ba7c1e26/environment-after.json',
    'attempt-05582479/verification.json',
    'independent-audit/arabic-final-audit.log',
}
ACCEPTED = 'ba7c1e26cdc409915e04eba49dd1f1c002280cf8'



def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_path(name: object) -> bool:
    if not isinstance(name, str) or not name or '\\' in name or '\x00' in name or ':' in name:
        return False
    path = PurePosixPath(name)
    return not path.is_absolute() and '..' not in path.parts and path.as_posix() == name


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--source', default='b559f6c764fbfac143f593e89ddc1096ad8b5c4e')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    source = subprocess.check_output(['git', 'rev-parse', args.source], cwd=repo, text=True).strip()
    issues: list[str] = []
    reports = []

    def require(condition: bool, message: str) -> bool:
        if not condition:
            issues.append(message)
        return condition

    for archive_name, index_name in PAIRS:
        archive = repo / archive_name
        index_path = repo / index_name
        data = archive.read_bytes()
        index_bytes = index_path.read_bytes()
        index = json.loads(index_bytes)
        blobs = []
        for path, actual in [(archive_name, data), (index_name, index_bytes)]:
            original = subprocess.check_output(['git', 'show', f'{source}:{path}'], cwd=repo)
            blob = subprocess.check_output(['git', 'rev-parse', f'{source}:{path}'], cwd=repo, text=True).strip()
            actual_blob = subprocess.check_output(['git', 'hash-object', '--stdin'], cwd=repo, input=actual).decode().strip()
            same = require(actual == original and actual_blob == blob, f'{path}: changed from incoming Git blob')
            blobs.append({'path': path, 'source_blob': blob, 'current_blob': actual_blob,
                          'sha256': sha256(actual), 'bytes': len(actual), 'unchanged': same})

        require(len(data) == index['bytes'], f'{archive_name}: archive size differs from index')
        require(sha256(data) == index['sha256'], f'{archive_name}: archive SHA-256 differs from index')
        entries = index['members']
        expected = {}
        for entry in entries:
            name = entry['path']
            require(safe_path(name), f'{archive_name}: unsafe indexed path {name!r}')
            require(name not in expected, f'{archive_name}: duplicate indexed path {name!r}')
            require(type(entry['bytes']) is int and entry['bytes'] >= 0,
                    f'{archive_name}: invalid indexed member size {name!r}')
            require(isinstance(entry['sha256'], str) and bool(re.fullmatch(r'[0-9a-f]{64}', entry['sha256'])),
                    f'{archive_name}: invalid indexed member digest {name!r}')
            expected[name] = entry
        if 'member_count' in index:
            require(index['member_count'] == len(entries), f'{archive_name}: index member_count differs')

        observed = []
        actual_names = []
        historical = {}
        documents = {}
        with tarfile.open(archive, 'r:xz') as stream:
            for member in stream:
                name = member.name
                require(safe_path(name), f'{archive_name}: unsafe archive path {name!r}')
                require(name not in actual_names, f'{archive_name}: duplicate archive member {name!r}')
                actual_names.append(name)
                regular = require(member.isfile(), f'{archive_name}: nonregular archive member {name!r}')
                require(not member.mode & 0o6000, f'{archive_name}: privileged mode on member {name!r}')
                entry = expected.get(name)
                require(entry is not None, f'{archive_name}: unindexed member {name!r}')
                if not regular or entry is None:
                    continue
                same_size = require(member.size == entry['bytes'], f'{archive_name}: size mismatch for {name!r}')
                if not same_size:
                    continue
                extracted = stream.extractfile(member)
                assert extracted is not None
                digest = hashlib.sha256()
                consumed = 0
                collected = [] if name in COLLECT else None
                for chunk in iter(lambda: extracted.read(1024 * 1024), b''):
                    consumed += len(chunk)
                    digest.update(chunk)
                    if collected is not None:
                        collected.append(chunk)
                actual_hash = digest.hexdigest()
                require(consumed == member.size, f'{archive_name}: truncated member {name!r}')
                same_hash = require(actual_hash == entry['sha256'], f'{archive_name}: hash mismatch for {name!r}')
                observed.append({'path': name, 'bytes': consumed, 'sha256': actual_hash,
                                 'regular_file': regular, 'size_matches': same_size, 'hash_matches': same_hash})
                if collected is not None:
                    documents[name] = json.loads(b''.join(collected))

        accepted = documents['accepted-ba7c1e26/verification.json']
        attempt = documents['attempt-05582479/verification.json']
        independent = documents['independent-audit/arabic-final-audit.log']
        accepted_tree = subprocess.check_output(
            ['git', 'rev-parse', ACCEPTED + '^{tree}'], cwd=repo, text=True).strip()
        require(index['accepted_source'] == ACCEPTED, 'Index accepted source identity differs')
        for label, value in [('accepted', accepted), ('independent', independent)]:
            require(value['source_commit'] == ACCEPTED, label + ': accepted source identity differs')
            require(value['source_tree'] == accepted_tree, label + ': accepted source tree differs')
        require(accepted['success'] is True, 'Archived accepted run is not successful')
        require(independent['passed'] is True and not independent['issues'], 'Archived independent audit is not clean')
        require(accepted['passed'] == independent['actual_dart_flutter_cases'] == index['accepted_application_cases'] == 179,
                'Historical accepted case identities differ')
        require(accepted['failed'] == accepted['skipped'] == independent['failed'] == independent['skipped'] == 0,
                'Historical accepted receipt includes failed/skipped cases')
        require(independent['gate_receipt_sha256'] == expected['accepted-ba7c1e26/verification.json']['sha256'],
                'Historical independent audit is not bound to the accepted receipt')
        require(attempt['success'] is False, 'Earlier failed attempt lost its unsuccessful identity')
        attempt_tree = subprocess.check_output(
            ['git', 'rev-parse', attempt['source_commit'] + '^{tree}'], cwd=repo, text=True).strip()
        require(attempt['source_tree'] == attempt_tree, 'Earlier attempt tree identity differs')
        require(index['earlier_attempt_and_development_added_to_accepted_total'] == 0,
                'Index adds earlier attempt/development counts')
        require(index['earlier_mail_836_and_python_78_included_in_this_total'] is False,
                'Index conflates earlier Mail/Python totals')
        for label in ['source', 'environment']:
            require(documents['accepted-ba7c1e26/' + label + '-before.json'] ==
                    documents['accepted-ba7c1e26/' + label + '-after.json'],
                    'Historical accepted ' + label + ' manifests differ')
        plan = accepted['plan']
        plan_bytes = subprocess.check_output(['git', 'show', ACCEPTED + ':' + plan], cwd=repo)
        require(sha256(plan_bytes) == accepted['plan_sha256'] == independent['plan_sha256'],
                'Original accepted plan Git blob hash differs')
        source_manifest = documents['accepted-ba7c1e26/source-before.json']
        git_tree = {}
        for entry in subprocess.check_output(['git', 'ls-tree', '-rz', ACCEPTED], cwd=repo).split(b'\x00'):
            if not entry:
                continue
            header, name = entry.split(b'\t', 1)
            mode, kind, blob = header.decode().split()
            git_tree[name.decode()] = (mode, kind, blob)
        verified_hashes = {}
        child = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=repo,
                                 stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        assert child.stdin is not None and child.stdout is not None
        try:
            for name, identity in source_manifest.items():
                require(safe_path(name), 'Unsafe historical source path ' + repr(name))
                expected_entry = git_tree.get(name)
                if not require(expected_entry is not None, 'Missing historical source path ' + name):
                    continue
                mode, kind, git_blob = expected_entry
                require(mode == identity['mode'] and git_blob == identity['git_blob'],
                        'Historical source mode/Git blob differs: ' + name)
                if not identity.get('sha256'):
                    continue
                if git_blob not in verified_hashes:
                    child.stdin.write((git_blob + '\n').encode())
                    child.stdin.flush()
                    header = child.stdout.readline().decode().split()
                    require(len(header) == 3 and header[1] == 'blob', 'Nonblob source input: ' + name)
                    remaining = int(header[2])
                    digest = hashlib.sha256()
                    while remaining:
                        chunk = child.stdout.read(min(remaining, 1024 * 1024))
                        if not chunk:
                            raise RuntimeError('Truncated Git object: ' + name)
                        remaining -= len(chunk)
                        digest.update(chunk)
                    require(child.stdout.read(1) == b'\n', 'Malformed Git object boundary: ' + name)
                    verified_hashes[git_blob] = digest.hexdigest()
                require(verified_hashes[git_blob] == identity['sha256'],
                        'Historical source SHA-256 differs: ' + name)
        finally:
            child.stdin.close()
            child.stdout.close()
            child.wait()
        require(child.returncode == 0, 'Git source reader failed')
        require(len(source_manifest) == independent['source_inputs_reverified'] == accepted['source_input_count'],
                'Historical source input count differs')
        historical = {
            'accepted_source': ACCEPTED,
            'accepted_tree': accepted_tree,
            'accepted_application_cases': accepted['passed'],
            'accepted_suite_count': independent['unique_suites'],
            'source_inputs_reverified_against_original_git': len(source_manifest),
            'unique_source_blob_sha256_values_checked': len(verified_hashes),
            'source_and_environment_manifests_equal': True,
            'accepted_plan': plan,
            'accepted_plan_sha256': sha256(plan_bytes),
            'earlier_attempt': {'source_commit': attempt['source_commit'], 'source_tree': attempt_tree,
                                'success': attempt['success'], 'passed_assertions': attempt['passed'],
                                'added_to_accepted_total': 0},
            'independent_audit': {'passed': independent['passed'],
                                  'gate_receipt_sha256': independent['gate_receipt_sha256'],
                                  'archive_member': 'independent-audit/arabic-final-audit.log'},
        }

        require(set(actual_names) == set(expected), f'{archive_name}: exact member inventory differs')
        require(len(actual_names) == len(entries), f'{archive_name}: exact member count differs')
        reports.append({
            'archive': archive_name,
            'index': index_name,
            'archive_bytes': len(data),
            'archive_sha256': sha256(data),
            'index_sha256': sha256(index_bytes),
            'indexed_archive_label': index['archive'],
            'archive_label_note': ('The index retains its original archive basename; content is bound by exact bytes/hash and unchanged Git blobs.'
                                   if index['archive'] != archive.name else None),
            'member_count': len(observed),
            'exact_inventory': set(actual_names) == set(expected) and len(actual_names) == len(entries),
            'blobs': blobs,
            'members': observed,
            'historical_identity_only': historical,
        })

    report = {
        'audited_at_utc': datetime.now(timezone.utc).isoformat(),
        'incoming_source': source,
        'script_sha256': sha256(Path(__file__).read_bytes()),
        'method': 'Read-only archive/index and Git-blob validation. No archive extraction to disk or execution of archived programs/tests.',
        'archives_checked': len(reports),
        'members_checked': sum(item['member_count'] for item in reports),
        'archive_and_index_blobs_checked': sum(len(item['blobs']) for item in reports),
        'fresh_application_tests_run': 0,
        'fresh_python_controls_run': 0,
        'historical_counts_added_to_current_totals': 0,
        'archives': reports,
        'issues': issues,
        'passed': not issues,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in ['passed', 'archives_checked', 'members_checked', 'archive_and_index_blobs_checked', 'issues']}, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
