#!/usr/bin/env python3
"""Verify two imported historical evidence archives without extracting/running them."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile


PAIRS = [
    (
        'docs/validation/office-current-reconciliation-20261119/native/native-qualification.tar.xz',
        'docs/validation/office-current-reconciliation-20261119/native/native-qualification.tar.index.json',
    ),
    (
        'docs/validation/office-main-integration-20261119/socket-final/arabic-controls-evidence.tar.xz',
        'docs/validation/office-main-integration-20261119/socket-final/arabic-controls-evidence.index.json',
    ),
]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_path(name: object) -> bool:
    if not isinstance(name, str) or not name or '\\' in name or '\x00' in name or ':' in name:
        return False
    path = PurePosixPath(name)
    return not path.is_absolute() and '..' not in path.parts and path.as_posix() == name


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--source', default='b655b8a37fddc874bd42a453c371eed6253e82d8')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    source = subprocess.check_output(['git', 'rev-parse', args.source], cwd=repo, text=True).strip()
    issues: list[str] = []
    reports = []

    def require(condition: bool, message: str) -> bool:
        if not condition:
            issues.append(message)
        return condition

    for archive_name, index_name in PAIRS:
        archive = repo / archive_name
        index_path = repo / index_name
        data = archive.read_bytes()
        index_bytes = index_path.read_bytes()
        index = json.loads(index_bytes)
        blobs = []
        for path, actual in [(archive_name, data), (index_name, index_bytes)]:
            original = subprocess.check_output(['git', 'show', f'{source}:{path}'], cwd=repo)
            blob = subprocess.check_output(['git', 'rev-parse', f'{source}:{path}'], cwd=repo, text=True).strip()
            actual_blob = subprocess.check_output(['git', 'hash-object', '--stdin'], cwd=repo, input=actual).decode().strip()
            same = require(actual == original and actual_blob == blob, f'{path}: changed from incoming Git blob')
            blobs.append({'path': path, 'source_blob': blob, 'current_blob': actual_blob,
                          'sha256': sha256(actual), 'bytes': len(actual), 'unchanged': same})

        require(len(data) == index['bytes'], f'{archive_name}: archive size differs from index')
        require(sha256(data) == index['sha256'], f'{archive_name}: archive SHA-256 differs from index')
        entries = index['members']
        expected = {}
        for entry in entries:
            name = entry['path']
            require(safe_path(name), f'{archive_name}: unsafe indexed path {name!r}')
            require(name not in expected, f'{archive_name}: duplicate indexed path {name!r}')
            require(type(entry['bytes']) is int and entry['bytes'] >= 0,
                    f'{archive_name}: invalid indexed member size {name!r}')
            require(isinstance(entry['sha256'], str) and bool(re.fullmatch(r'[0-9a-f]{64}', entry['sha256'])),
                    f'{archive_name}: invalid indexed member digest {name!r}')
            expected[name] = entry
        if 'member_count' in index:
            require(index['member_count'] == len(entries), f'{archive_name}: index member_count differs')

        observed = []
        actual_names = []
        historical = {}
        with tarfile.open(archive, 'r:xz') as stream:
            for member in stream:
                name = member.name
                require(safe_path(name), f'{archive_name}: unsafe archive path {name!r}')
                require(name not in actual_names, f'{archive_name}: duplicate archive member {name!r}')
                actual_names.append(name)
                regular = require(member.isfile(), f'{archive_name}: nonregular archive member {name!r}')
                require(not member.mode & 0o6000, f'{archive_name}: privileged mode on member {name!r}')
                entry = expected.get(name)
                require(entry is not None, f'{archive_name}: unindexed member {name!r}')
                if not regular or entry is None:
                    continue
                same_size = require(member.size == entry['bytes'], f'{archive_name}: size mismatch for {name!r}')
                if not same_size:
                    continue
                extracted = stream.extractfile(member)
                assert extracted is not None
                digest = hashlib.sha256()
                consumed = 0
                collected = [] if name in ['native/verification.json', 'combined-review.json', 'offline-controls-receipt.json'] else None
                for chunk in iter(lambda: extracted.read(1024 * 1024), b''):
                    consumed += len(chunk)
                    digest.update(chunk)
                    if collected is not None:
                        collected.append(chunk)
                actual_hash = digest.hexdigest()
                require(consumed == member.size, f'{archive_name}: truncated member {name!r}')
                same_hash = require(actual_hash == entry['sha256'], f'{archive_name}: hash mismatch for {name!r}')
                observed.append({'path': name, 'bytes': consumed, 'sha256': actual_hash,
                                 'regular_file': regular, 'size_matches': same_size, 'hash_matches': same_hash})
                if collected is not None:
                    value = json.loads(b''.join(collected))
                    if name == 'native/verification.json':
                        historical[name] = {key: value.get(key) for key in ['source_commit', 'source_tree', 'passed', 'failed', 'skipped']}
                    else:
                        result = value.get('result', {})
                        historical[name] = {
                            key: value.get(key) for key in ['selected_builder_commit', 'complementary_test_commit', 'selected_builder_sha256', 'inputs_unchanged'] if key in value
                        }
                        historical[name]['original_recorded_result'] = {key: result.get(key) for key in ['tests_run', 'failures', 'errors', 'skipped', 'successful']}

        require(set(actual_names) == set(expected), f'{archive_name}: exact member inventory differs')
        require(len(actual_names) == len(entries), f'{archive_name}: exact member count differs')
        reports.append({
            'archive': archive_name,
            'index': index_name,
            'archive_bytes': len(data),
            'archive_sha256': sha256(data),
            'index_sha256': sha256(index_bytes),
            'indexed_archive_label': index['archive'],
            'archive_label_note': ('The index retains its original archive basename; content is bound by exact bytes/hash and unchanged Git blobs.'
                                   if index['archive'] != archive.name else None),
            'member_count': len(observed),
            'exact_inventory': set(actual_names) == set(expected) and len(actual_names) == len(entries),
            'blobs': blobs,
            'members': observed,
            'historical_identity_only': historical,
        })

    report = {
        'audited_at_utc': datetime.now(timezone.utc).isoformat(),
        'incoming_source': source,
        'script_sha256': sha256(Path(__file__).read_bytes()),
        'method': 'Read-only archive/index and Git-blob validation. No archive extraction to disk or execution of archived programs/tests.',
        'archives_checked': len(reports),
        'members_checked': sum(item['member_count'] for item in reports),
        'archive_and_index_blobs_checked': sum(len(item['blobs']) for item in reports),
        'fresh_application_tests_run': 0,
        'fresh_python_controls_run': 0,
        'historical_counts_added_to_current_totals': 0,
        'archives': reports,
        'issues': issues,
        'passed': not issues,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in ['passed', 'archives_checked', 'members_checked', 'archive_and_index_blobs_checked', 'issues']}, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
