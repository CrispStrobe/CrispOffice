#!/usr/bin/env python3
"""Independently account for the pre-test fce543de continuity rejection."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/79e6ad9e4046')
REPO = ROOT / 'quds_office_suite'
GATE = ROOT / 'main-delta/v3-final-checks'
SOURCE = 'fce543dedb1217804f67de088ef9c287e8a2edca'
MAIN = '00014577265d1f95d4c016159029510d3a10804b'
issues = []


def check(value, message):
    if not value:
        issues.append(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(name):
    return json.loads((GATE / name).read_bytes())


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(REPO), *args])


record = read('execution.json')
continuity = read('continuity.json')
check(record['source_commit'] == SOURCE and record['status'] == 'FAIL' and bool(record.get('finished_at_utc')),
      'Complete rejected exact-source attempt')
check(record['source_tree'] == git('rev-parse', SOURCE + '^{tree}').decode().strip(), 'Immutable source tree')
check([r['name'] for r in record['runs']] == ['locked-workspace-resolution', 'delta-continuity'], 'Only two pre-test commands ran')
check([r['exit_code'] for r in record['runs']] == [0, 1], 'Resolver success and continuity rejection')
for row in record['runs']:
    check(sha((GATE / row['log']).read_bytes()) == row['log_sha256'], 'Original log identity: ' + row['name'])
    if 'receipt' in row:
        check(sha((GATE / row['receipt']).read_bytes()) == row['receipt_sha256'], 'Original receipt identity: ' + row['name'])
for name, digest in record['manifest_sha256'].items():
    check(sha((GATE / name).read_bytes()) == digest, 'Original manifest hash: ' + name)
check(continuity['passed'] is False and continuity['issues'] == [
    'Exact Studio dependency graph addition of three Mail packages and the Hunspell workspace package'
], 'Sole recorded guard failure')
check(all(record[k] is True for k in ['source_unchanged', 'runtime_unchanged', 'source_head_unchanged', 'tracked_worktree_clean_after']),
      'Original complete source/runtime/head/worktree stability')
before, after = read('source-before.json'), read('source-after.json')
runtime_before, runtime_after = read('runtime-before.json'), read('runtime-after.json')
check(before == after and runtime_before == runtime_after, 'Exact before/after source and runtime envelopes')
objects = {}
for entry in git('ls-tree', '-r', '-z', SOURCE).split(b'\0'):
    if entry:
        metadata, name = entry.split(b'\t', 1)
        mode, kind, object_id = metadata.decode().split()
        objects[name.decode()] = (kind, object_id)
request = ''.join(objects[name][1] + '\n' for name in sorted(before)).encode()
result = subprocess.run(['git', '--no-replace-objects', '-C', str(REPO), 'cat-file', '--batch'],
                        input=request, stdout=subprocess.PIPE, check=True).stdout
stream = io.BytesIO(result)
for name in sorted(before):
    object_id, kind, size = stream.readline().decode().split()
    raw = stream.read(int(size))
    check(stream.read(1) == b'\n' and (kind, object_id) == objects[name] and kind == 'blob', 'Immutable object: ' + name)
    check(sha(raw) == before[name], 'Frozen source bytes: ' + name)
check(not stream.read(), 'All immutable source objects consumed')
for absent in ['bundle-controls.log', 'packaging-controls.log', 'native', 'node', 'hunspell-browser-compile.log']:
    check(not (GATE / absent).exists(), 'No test/build stage started: ' + absent)
old_graph, new_graph = read('prior-resolution/.dart_tool/package_graph.json'), read('package_graph.json')
old_nodes, new_nodes = ({row['name']: row for row in value['packages']} for value in (old_graph, new_graph))
old_studio, new_studio = old_nodes['quds_office_studio'], new_nodes['quds_office_studio']
added = sorted(set(new_studio['dependencies']) - set(old_studio['dependencies']))
check(added == ['quds_mail_core', 'quds_mail_mime', 'quds_mail_ui', 'quds_proofing_hunspell', 'url_launcher'],
      'Exact five incoming Studio dependency additions')
expected_studio = dict(old_studio, dependencies=sorted(old_studio['dependencies'] + added))
check(new_studio == expected_studio, 'No additional Studio node changes')
check(set(new_nodes) - set(old_nodes) == {'quds_proofing_hunspell'}
      and set(old_nodes) <= set(new_nodes)
      and all(new_nodes[name] == row for name, row in old_nodes.items() if name != 'quds_office_studio'),
      'Only optional workspace node added; all other old graph rows exact')
old_config, new_config = read('prior-resolution/.dart_tool/package_config.json'), read('package_config.json')
old_rows, new_rows = ({row['name']: row for row in value['packages']} for value in (old_config, new_config))
check(len(old_rows) == 131 and len(new_rows) == 132 and set(new_rows) - set(old_rows) == {'quds_proofing_hunspell'}
      and all(new_rows.get(name) == row for name, row in old_rows.items()), 'All131 prior mappings exact; only Hunspell added')
manifest_path = 'packages/quds_office_editor/example/pubspec.yaml'
manifest = git('show', MAIN + ':' + manifest_path)
check(manifest == git('show', SOURCE + ':' + manifest_path) and b'  url_launcher: ^6.3.1\n' in manifest,
      'Extra existing dependency is explicitly declared by exact incoming manifest')
report = {'audit_checks_passed': not issues, 'issues': issues, 'recorded_failure_confirmed': not issues,
          'accepted_qualification': False, 'source_commit': SOURCE, 'source_tree': record['source_tree'],
          'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'attempt_status': record['status'],
          'failure': 'The continuity expectation omitted the already-resolved url_launcher dependency explicitly added by incoming main. The guard rejected the attempt before any tests.',
          'application_cases_executed': 0, 'python_controls_executed': 0, 'application_cases_added_to_final_totals': 0,
          'python_controls_added_to_final_totals': 0, 'source_inputs_bound_to_immutable_commit': len(before),
          'source_snapshots_equal': before == after, 'runtime_snapshots_equal': runtime_before == runtime_after,
          'runtime_inputs_in_stable_envelope': len(runtime_before), 'studio_graph_before': old_studio,
          'studio_graph_after': new_studio, 'exact_added_existing_dependencies': added,
          'workspace_before_count': len(old_rows), 'workspace_after_count': len(new_rows),
          'incoming_manifest_source': MAIN, 'incoming_manifest_sha256': sha(manifest),
          'outer_execution_sha256': sha((GATE / 'execution.json').read_bytes()),
          'continuity_receipt_sha256': sha((GATE / 'continuity.json').read_bytes()),
          'audit_script_sha256': sha(Path(__file__).read_bytes()),
          'method': 'Read-only original receipt/log/manifest binding, immutable Git source recount and exact original/current dependency graph comparison. No application or Python test executed by this audit.'}
path = ROOT / 'main-delta/v3-guard-failed-attempt-audit.json'
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['audit_checks_passed', 'issues', 'application_cases_executed', 'python_controls_executed', 'source_inputs_bound_to_immutable_commit']}, indent=2))
raise SystemExit(int(bool(issues)))
