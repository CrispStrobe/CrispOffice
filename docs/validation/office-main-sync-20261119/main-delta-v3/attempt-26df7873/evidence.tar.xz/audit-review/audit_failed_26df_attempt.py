#!/usr/bin/env python3
"""Document the rejected 26df v3 attempt without treating visible successes as accepted."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "outer", "output"):
        p.add_argument("--" + name, type=Path, required=True)
    a = p.parse_args()
    outer = a.outer.resolve()
    issues = []
    def check(value, message):
        if not value:
            issues.append(message)
    def read(path):
        return json.loads(path.read_bytes())
    receipt = read(outer / "execution.json")
    source = receipt["source_commit"]
    check(source == "26df787326f58a002b62241b7feb52acff089f2f" and receipt["status"] == "FAIL", "Exact rejected source and status")
    check([r["name"] for r in receipt["runs"]] == ["locked-workspace-resolution", "delta-continuity", "bundle-controls", "packaging-controls", "native"], "Exact stopped attempt command inventory")
    check(not (outer / "node").exists() and not list(outer.glob("hunspell-browser.js*")), "Node and browser outputs absent")
    for name, expected in receipt["manifest_sha256"].items():
        check(sha((outer / name).read_bytes()) == expected, "Outer manifest hash: " + name)
    before, after = (read(outer / ("source-" + phase + ".json")) for phase in ("before", "after"))
    runtime_before, runtime_after = (read(outer / ("runtime-" + phase + ".json")) for phase in ("before", "after"))
    check(before == after and runtime_before == runtime_after, "Recorded source/runtime before and after unchanged")
    check(all(receipt[k] is True for k in ("source_unchanged", "runtime_unchanged", "source_head_unchanged", "tracked_worktree_clean_after")), "Recorded frozen-source guards passed")
    names = sorted(before)
    proc = subprocess.run(["git", "--no-replace-objects", "cat-file", "--batch"], cwd=a.repo,
                          input="".join(source + ":" + name + "\n" for name in names).encode(), stdout=subprocess.PIPE, check=True)
    stream = io.BytesIO(proc.stdout)
    for name in names:
        _, kind, size = stream.readline().decode().split()
        raw = stream.read(int(size))
        check(stream.read(1) == b"\n" and kind == "blob" and sha(raw) == before[name], "Immutable frozen source binding: " + name)
    check(not stream.read(), "Complete immutable source object stream")
    gate = outer / "native"
    native = read(gate / "verification.json")
    check(native["success"] is False and native["source_commit"] == source, "Native gate rejected on exact source")
    for name, expected in native["manifest_sha256"].items():
        check(sha((gate / name).read_bytes()) == expected, "Native manifest hash: " + name)
    check(read(gate / "source-before.json") == read(gate / "source-after.json") and read(gate / "environment-before.json") == read(gate / "environment-after.json"), "Native source/runtime manifests identical")
    groups, malformed_all, case_inventory, strict_commands, reporter_errors = [], [], [], [], []
    for run in native["runs"]:
        raw = (gate / run["log"]).read_bytes()
        check(sha(raw) == run["log_sha256"], "Native command log hash: " + run["name"])
        if not run["log"].endswith(".jsonl"):
            strict_commands.append({"name": run["name"], "exit_code": run["exit_code"], "accepted": run["accepted"], "raw_sha256": sha(raw), "log": run["log"]})
            continue
        events, malformed = [], []
        for number, line in enumerate(raw.decode().splitlines(), 1):
            value = line.strip()
            for prefix in ("Running build hooks...", "Running link hooks..."):
                if value.startswith(prefix):
                    value = value[len(prefix):].lstrip()
            if not value:
                continue
            try:
                events.append(json.loads(value))
            except json.JSONDecodeError:
                malformed.append({"group": run["name"], "line": number, "text": value})
        starts_rows = [e["test"] for e in events if e["type"] == "testStart"]
        ends_rows = [e for e in events if e["type"] == "testDone"]
        starts = {row["id"]: row for row in starts_rows}
        ends = {row["testID"]: row for row in ends_rows}
        check(len(starts_rows) == len(starts) and len(ends_rows) == len(ends) and set(starts) == set(ends), "Complete distinct raw lifecycle IDs: " + run["name"])
        check(sum(e["type"] == "start" for e in events) == sum(e["type"] == "done" for e in events) == 1 and events[-1]["type"] == "done"
              and events[-1]["success"] == (run["failed"] == 0), "Reporter terminal result agrees with recorded failures: " + run["name"])
        reporter_errors.extend({"group": run["name"], **e} for e in events if e["type"] == "error")
        visible = []
        for test_id, end in ends.items():
            start = starts[test_id]
            check(end.get("skipped") is False, "No skipped raw lifecycle: " + start["name"])
            if end.get("hidden") or start["name"].startswith("loading ") or re.search(r"(?:^| )\((?:setUpAll|tearDownAll)\)$", start["name"]):
                continue
            visible.append({"id": test_id, "name": start["name"], "suite_id": start["suiteID"], "result": end.get("result")})
        passed = sum(row["result"] == "success" for row in visible)
        failed = sum(row["result"] != "success" for row in visible)
        check(passed == run["passed"] and failed == run["failed"] and run["skipped"] == 0, "Independent visible result counts agree: " + run["name"])
        malformed_all.extend(malformed)
        case_inventory.extend({"group": run["name"], **row} for row in visible)
        groups.append({"name": run["name"], "visible_successes": passed, "failed": failed, "skipped": 0,
                       "strict_gate_accepted": run["accepted"], "malformed_reporter_lines": len(malformed), "raw_sha256": sha(raw)})
    check(sum(row["visible_successes"] for row in groups) == native["passed"] == 634, "Exactly634 visible successes remain rejected-attempt evidence")
    check(sum(row["failed"] for row in groups) == native["failed"] == 0 and len(case_inventory) == 634, "No failed visible cases among634 completions")
    check(not malformed_all and not reporter_errors, "No malformed reporter lines or reporter error events")
    check(len(groups) == 6 and all(row["strict_gate_accepted"] for row in groups), "All six application groups passed before the static rejection")
    check({row["name"] for row in strict_commands if not row["accepted"]} == {"analysis"}, "Only strict analysis rejected")
    analysis_raw = (gate / "checks/analysis.log").read_text()
    diagnostics = [line.strip() for line in analysis_raw.splitlines() if re.search(r"^\s*(?:info|warning|error) - ", line)]
    check(len(diagnostics) == 1 and diagnostics[0] == "info - packages/quds_office_engine/lib/quds_office_engine.dart:120:1 - Sort directive sections alphabetically. Try sorting the directives. - directives_ordering", "Exact sole export-order diagnostic")
    check(analysis_raw.rstrip().endswith("1 issue found."), "No unaccounted analysis diagnostic")
    changed_format_paths = []
    python_groups = []
    for label, expected in (("bundle-controls", 17), ("packaging-controls", 4)):
        controls = (outer / (label + ".log")).read_bytes()
        rows = re.findall(rb"^test\S+ \([^)]+\) \.\.\. ok$", controls, re.MULTILINE)
        terminal = re.findall(rb"Ran (\d+) tests in [^\n]+\n\s*\nOK\s*$", controls)
        check(len(rows) == expected and len(terminal) == 1 and int(terminal[0]) == expected, "Exact successful verbose controls: " + label)
        python_groups.append({"name": label, "passed": len(rows), "raw_sha256": sha(controls)})
    for row in receipt["runs"]:
        check(sha((outer / row["log"]).read_bytes()) == row["log_sha256"], "Original outer command log: " + row["name"])
        if "receipt" in row:
            check(sha((outer / row["receipt"]).read_bytes()) == row["receipt_sha256"], "Original child receipt binding: " + row["name"])
    result = {"audit_checks_passed": not issues, "issues": issues, "source_commit": source, "source_tree": receipt["source_tree"],
              "audited_at_utc": datetime.now(timezone.utc).isoformat(), "recorded_failure_confirmed": not issues,
              "accepted_qualification": False, "attempt_status": "FAIL", "failure": "All native case events succeeded, but strict analysis rejected one incoming export-order diagnostic. The complete attempt remains rejected; Node and browser stages did not run.",
              "visible_application_successes": 634, "failed_application_case_events": 0, "skipped_application_case_events": 0,
              "groups": groups, "malformed_reporter_lines": malformed_all, "case_inventory": case_inventory,
              "failed_cases": [row for row in case_inventory if row["result"] != "success"], "raw_reporter_errors": reporter_errors,
              "strict_commands": strict_commands, "formatting_required_paths": changed_format_paths,
              "analysis_diagnostics": diagnostics, "python_groups": python_groups,
              "separate_python_successes_in_rejected_attempt": 21,
              "application_cases_added_to_final_totals": 0, "python_controls_added_to_final_totals": 0,
              "node_started": False, "browser_compile_started": False, "source_inputs_bound_to_immutable_commit": len(before),
              "source_snapshots_equal": before == after, "runtime_snapshots_equal": runtime_before == runtime_after,
              "runtime_inputs_in_stable_envelope": len(runtime_before), "outer_execution_sha256": sha((outer / "execution.json").read_bytes()),
              "native_receipt_sha256": sha((gate / "verification.json").read_bytes()), "audit_script_sha256": sha(Path(__file__).read_bytes()),
              "method": "Read-only raw valid-event recount with explicit malformed-line inventory, original receipt and snapshot hashes, immutable source object verification. The rejected attempt remains unchanged and contributes zero to accepted totals."}
    a.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("audit_checks_passed", "issues", "recorded_failure_confirmed", "accepted_qualification", "visible_application_successes", "application_cases_added_to_final_totals")}, indent=2))
    return int(bool(issues))


if __name__ == "__main__":
    raise SystemExit(main())
