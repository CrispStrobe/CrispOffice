#!/usr/bin/env python3
"""Independently verify retained import archives without extracting members."""

from __future__ import annotations

import argparse
import datetime
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

MAIL_PREFIX = 'docs/validation/mail-m06-resume-20261119/final'
SOCKET_PREFIX = 'docs/validation/office-main-integration-20261119/socket-final'
MAIL_ORIGINAL = '700e5a35ce5f96e7abd1dc92d1a00d2110d40649'
SOCKET_ORIGINAL = 'c1dc63f934f81e22a41bafd98df1abf22ee6a053'


def git(repo: Path, *args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(repo), *args])


def blob(repo: Path, commit: str, path: str) -> bytes:
    return git(repo, 'show', f'{commit}:{path}')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True, help='Repository checkout with the retained imported Git objects.')
    parser.add_argument('--source', required=True, help='Integration commit/ref to resolve once and audit.')
    parser.add_argument('--output', type=Path, required=True, help='Directory for archive-audit.json.')
    args = parser.parse_args()
    repo = args.repo.resolve()
    output = args.output.resolve()
    source = git(repo, 'rev-parse', args.source + '^{commit}').decode().strip()
    errors: list[str] = []
    archives = []
    paths = git(repo, 'ls-tree', '-r', '--name-only', source, '--', MAIL_PREFIX).decode().splitlines()
    index_paths = sorted(p for p in paths if p.endswith('.tar.index.json'))
    if len(index_paths) != 8:
        errors.append(f'Expected 8 Mail archive indexes, found {len(index_paths)}')
    index_paths.append(f'{SOCKET_PREFIX}/upgrade-cleanup-evidence.index.json')
    total_members = 0

    for index_path in index_paths:
        index_bytes = blob(repo, source, index_path)
        index = json.loads(index_bytes)
        original = MAIL_ORIGINAL if index_path.startswith(MAIL_PREFIX) else SOCKET_ORIGINAL
        archive_path = str(PurePosixPath(index_path).parent / index['archive'])
        archive_bytes = blob(repo, source, archive_path)
        archive_hash = sha(archive_bytes)
        expected_hash = index.get('archive_sha256', index.get('sha256'))
        expected_size = index.get('archive_bytes', index.get('bytes'))
        checks = {
            'archive_sha256_matches_index': archive_hash == expected_hash,
            'archive_size_matches_index': len(archive_bytes) == expected_size,
            'index_identical_to_original_import': index_bytes == blob(repo, original, index_path),
            'archive_identical_to_original_import': archive_bytes == blob(repo, original, archive_path),
            'worktree_index_matches_frozen_source': (repo / index_path).read_bytes() == index_bytes,
            'worktree_archive_matches_frozen_source': (repo / archive_path).read_bytes() == archive_bytes,
        }
        expected_members = index['members']
        expected_by_name = {m['path']: m for m in expected_members}
        checks['unique_index_member_paths'] = len(expected_by_name) == len(expected_members)
        member_records = []
        source_bindings = []
        actual_names = []
        with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:xz') as tf:
            for member in tf.getmembers():
                actual_names.append(member.name)
                safe = not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
                if not member.isfile() or not safe:
                    errors.append(f'{archive_path}: unsafe or nonregular member {member.name}')
                    continue
                expected = expected_by_name.get(member.name)
                if expected is None:
                    errors.append(f'{archive_path}: unindexed member {member.name}')
                    continue
                stream = tf.extractfile(member)
                assert stream is not None
                data = stream.read()
                record = {
                    'path': member.name,
                    'bytes': len(data),
                    'sha256': sha(data),
                    'matches_index': len(data) == expected['bytes'] and sha(data) == expected['sha256'],
                }
                if not record['matches_index']:
                    errors.append(f'{archive_path}: member mismatch {member.name}')
                member_records.append(record)
                if index_path.startswith(SOCKET_PREFIX) and member.name.startswith('after/'):
                    source_path = member.name.removeprefix('after/')
                    matches = data == blob(repo, source, source_path)
                    source_bindings.append({'member': member.name, 'source_path': source_path, 'matches_frozen_source': matches})
                    if not matches:
                        errors.append(f'{archive_path}: after-source mismatch {source_path}')
        checks['unique_archive_member_paths'] = len(actual_names) == len(set(actual_names))
        checks['exact_member_path_set'] = set(actual_names) == set(expected_by_name)
        checks['all_indexed_members_verified'] = len(member_records) == len(expected_members)
        for key, ok in checks.items():
            if not ok:
                errors.append(f'{archive_path}: {key}')
        total_members += len(member_records)
        archives.append({
            'index': index_path,
            'index_sha256': sha(index_bytes),
            'archive': archive_path,
            'archive_bytes': len(archive_bytes),
            'archive_sha256': archive_hash,
            'original_import_commit': original,
            'historical_qualified_source': index.get('source_commit'),
            'checks': checks,
            'member_count': len(member_records),
            'members': member_records,
            'source_bindings': source_bindings,
        })

    mail_evidence = json.loads(blob(repo, source, f'{MAIL_PREFIX}/evidence-audit.json'))
    mail_execution = json.loads(blob(repo, source, f'{MAIL_PREFIX}/execution.json'))
    final_source = '71edec2de364805113d18e0f1d7edbb1f00467e5'
    receipt_checks = {
        'saved_execution_source_is_historical_71ed': mail_execution['head'] == final_source,
        'saved_evidence_source_is_historical_71ed': mail_evidence['source_commit'] == final_source,
        'saved_source_trees_agree': mail_execution['tree'] == mail_evidence['source_tree'],
        'saved_execution_reports_pass': mail_execution['status'] == 'PASS',
        'saved_evidence_reports_pass_without_failures': mail_evidence['status'] == 'PASS' and mail_evidence['failures'] == [],
        'saved_cohort_sum_matches_631': sum(mail_evidence['counts']['raw_by_cohort'].values()) == mail_evidence['counts']['raw_successful_test_executions'] == 631,
    }
    for key, ok in receipt_checks.items():
        if not ok:
            errors.append(key)

    report = {
        'schema': 1,
        'status': 'PASS' if not errors else 'FAIL',
        'audited_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'frozen_integration_source': source,
        'frozen_tree': git(repo, 'rev-parse', source + '^{tree}').decode().strip(),
        'auditor_sha256': sha(Path(__file__).read_bytes()),
        'archive_count': len(archives),
        'mail_archive_count': len(archives) - 1,
        'total_members_verified': total_members,
        'mail_members_verified': sum(a['member_count'] for a in archives if a['index'].startswith(MAIL_PREFIX)),
        'socket_cleanup_members_verified': sum(a['member_count'] for a in archives if a['index'].startswith(SOCKET_PREFIX)),
        'receipt_metadata_checks': receipt_checks,
        'archives': archives,
        'failures': errors,
        'scope': {
            'archive_bytes_and_members_rehashed': True,
            'git_import_identity_checked': True,
            'archived_after_source_matched_to_frozen_integration': True,
            'archive_members_extracted_to_disk': False,
            'raw_application_test_events_recounted': False,
            'original_runtime_or_workspace_reconstructed': False,
            'tests_or_builds_executed': False,
            'github_actions_accessed': False,
            'qualification_counts': '631 is recorded historical evidence at 71edec2d; this audit is not a new application test execution.',
        },
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / 'archive-audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['status', 'frozen_integration_source', 'archive_count', 'total_members_verified', 'mail_members_verified', 'socket_cleanup_members_verified', 'failures']}))
    if errors:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
