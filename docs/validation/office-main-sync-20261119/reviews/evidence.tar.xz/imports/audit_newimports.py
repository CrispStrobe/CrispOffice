#!/usr/bin/env python3
"""Independently hash the three late captured import archives without extraction."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile


SOCKET = "docs/validation/office-main-integration-20261119/socket-final"
UID = "docs/validation/mail-uid-pagination-20261119/runtime"
SOCKET_IMPORT = "cd430b2229ff81e3d486c9ed95c80e92a41fe8af"
UID_IMPORT = "5fcdf726694b5356d8fb85fb8e01a715e0fadc0c"
SOCKET_SOURCE = "ac1e4c8c788ea608402c2260488235c0189efcba"
SPECS = (
    (f"{SOCKET}/qualification-evidence", SOCKET_IMPORT, 57),
    (f"{SOCKET}/capture-evidence", SOCKET_IMPORT, 1),
    (f"{UID}/restore-evidence", UID_IMPORT, 12),
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--source", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--previous-audit", type=Path)
    args = parser.parse_args()
    repo, output = args.repo.resolve(), args.output.resolve()

    def git(*argv: str) -> bytes:
        return subprocess.check_output(["git", "-C", str(repo), *argv])

    source = git("rev-parse", "--verify", args.source + "^{commit}").decode().strip()

    def blob(ref: str, path: str) -> bytes:
        return git("show", ref + ":" + path)

    errors: list[str] = []
    archives = []
    retained: dict[str, bytes] = {}

    def check_all(scope: str, checks: dict[str, bool]) -> None:
        for name, valid in checks.items():
            if not valid:
                errors.append(scope + ": " + name)

    for prefix, original, expected_count in SPECS:
        index_path, archive_path = prefix + ".index.json", prefix + ".tar.xz"
        index_bytes, archive_bytes = blob(source, index_path), blob(source, archive_path)
        index = json.loads(index_bytes)
        expected_members = index["members"]
        expected_by_path = {row["path"]: row for row in expected_members}
        checks = {
            "archive_sha256_matches_index": sha(archive_bytes) == index.get("archive_sha256", index.get("sha256")),
            "archive_size_matches_index": len(archive_bytes) == index.get("archive_bytes", index.get("bytes")),
            "index_identical_to_original_import": index_bytes == blob(original, index_path),
            "archive_identical_to_original_import": archive_bytes == blob(original, archive_path),
            "worktree_index_matches_frozen_source": (repo / index_path).read_bytes() == index_bytes,
            "worktree_archive_matches_frozen_source": (repo / archive_path).read_bytes() == archive_bytes,
            "unique_index_member_paths": len(expected_by_path) == len(expected_members),
            "expected_member_count": len(expected_members) == expected_count,
        }
        members, names = [], []
        with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:xz") as archive:
            for member in archive.getmembers():
                names.append(member.name)
                safe = not PurePosixPath(member.name).is_absolute() and ".." not in PurePosixPath(member.name).parts
                if not safe or not member.isfile():
                    errors.append(archive_path + ": unsafe or nonregular member " + member.name)
                    continue
                expected = expected_by_path.get(member.name)
                if expected is None:
                    errors.append(archive_path + ": unindexed member " + member.name)
                    continue
                stream = archive.extractfile(member)
                assert stream is not None
                data = stream.read()
                row = {
                    "path": member.name,
                    "bytes": len(data),
                    "sha256": sha(data),
                    "matches_index": len(data) == expected["bytes"] and sha(data) == expected["sha256"],
                }
                members.append(row)
                if not row["matches_index"]:
                    errors.append(archive_path + ": member mismatch " + member.name)
                if member.name in {"store/receipt.json", "focused/verification.json", "runtime.json"}:
                    retained[member.name] = data
        checks.update(
            unique_archive_member_paths=len(names) == len(set(names)),
            exact_member_path_set=set(names) == set(expected_by_path),
            all_indexed_members_verified=len(members) == len(expected_members),
        )
        check_all(archive_path, checks)
        archives.append({
            "index": index_path,
            "index_sha256": sha(index_bytes),
            "archive": archive_path,
            "archive_bytes": len(archive_bytes),
            "archive_sha256": sha(archive_bytes),
            "original_import_commit": original,
            "historical_qualified_source_recorded_by_index": index.get("source_commit"),
            "checks": checks,
            "member_count": len(members),
            "members": members,
        })

    focused = json.loads(retained["focused/verification.json"])
    store = json.loads(retained["store/receipt.json"])
    runtime = json.loads(retained["runtime.json"])
    socket_review = json.loads(blob(source, f"{SOCKET}/socket_final_review.json"))
    historical_checks = {
        "focused_receipt_identical_to_published_historical_receipt": retained["focused/verification.json"] == blob(source, f"{SOCKET}/verification.json"),
        "store_receipt_identical_to_published_historical_receipt": retained["store/receipt.json"] == blob(source, f"{SOCKET}/store-receipt.json"),
        "runtime_receipt_identical_to_published_historical_receipt": retained["runtime.json"] == blob(source, f"{UID}/runtime.json"),
        "socket_qualification_index_records_ac1": archives[0]["historical_qualified_source_recorded_by_index"] == SOCKET_SOURCE,
        "focused_receipt_records_ac1_source_and_tree": focused["source_commit"] == SOCKET_SOURCE and focused["source_tree"] == git("rev-parse", SOCKET_SOURCE + "^{tree}").decode().strip(),
        "store_receipt_records_ac1_source": store["starting_commit"] == SOCKET_SOURCE,
        "focused_receipt_records_433_passing_without_failures_or_skips": focused["success"] is True and focused["passed"] == 433 and focused["failed"] == 0 and focused["skipped"] == 0,
        "store_receipt_records_pass": store["status"] == "PASS",
        "historical_review_retains_separate_632_execution_scope": socket_review["qualified_source"] == SOCKET_SOURCE and socket_review["counts"]["core_store_executions"] == 199 and socket_review["counts"]["focused_executions"] == 433 and socket_review["counts"]["total_executions"] == 632,
        "historical_runtime_receipt_records_ready_verified_archive": runtime["status"] == "ready" and runtime["archive"]["verified"] is True,
    }
    check_all("historical receipt metadata", historical_checks)

    previous = None
    if args.previous_audit:
        previous_path = args.previous_audit.resolve()
        previous_bytes = previous_path.read_bytes()
        previous_report = json.loads(previous_bytes)
        previous_checks = {
            "previous_audit_passed_without_failures": previous_report["status"] == "PASS" and previous_report["failures"] == [],
            "previous_scope_is_nine_archives_and_235_members": previous_report["archive_count"] == 9 and previous_report["total_members_verified"] == 235,
        }
        continuity = []
        for row in previous_report["archives"]:
            checks = {
                "index_bytes_unchanged_since_previous_audit": sha(blob(source, row["index"])) == row["index_sha256"],
                "archive_bytes_unchanged_since_previous_audit": sha(blob(source, row["archive"])) == row["archive_sha256"],
            }
            check_all(row["archive"] + " inherited continuity", checks)
            continuity.append({"index": row["index"], "archive": row["archive"], "checks": checks})
        check_all("previous audit", previous_checks)
        previous = {
            "audit": str(previous_path),
            "audit_sha256": sha(previous_bytes),
            "audited_integration_source": previous_report["frozen_integration_source"],
            "archive_count": previous_report["archive_count"],
            "members_previously_verified": previous_report["total_members_verified"],
            "checks": previous_checks,
            "continuity_to_frozen_source": continuity,
            "prior_members_rehashed_again_in_this_extension": False,
        }

    report = {
        "schema": 1,
        "status": "PASS" if not errors else "FAIL",
        "audited_at_utc": datetime.now(timezone.utc).isoformat(),
        "frozen_integration_source": source,
        "frozen_tree": git("rev-parse", source + "^{tree}").decode().strip(),
        "auditor_sha256": sha(Path(__file__).read_bytes()),
        "new_archive_count": len(archives),
        "new_members_verified": sum(a["member_count"] for a in archives),
        "archives": archives,
        "historical_receipt_metadata_checks": historical_checks,
        "historical_qualification_source": SOCKET_SOURCE,
        "historical_socket_qualification_executions": 632,
        "historical_uid_runtime_application_qualification_source": None,
        "historical_uid_runtime_scope": "Environment restoration evidence imported by 5fcdf726; its path-based receipt does not establish a new application qualification commit.",
        "previous_audit": previous,
        "combined_archive_count": len(archives) + (previous["archive_count"] if previous else 0),
        "combined_verified_member_count": sum(a["member_count"] for a in archives) + (previous["members_previously_verified"] if previous else 0),
        "failures": errors,
        "scope": {
            "new_archive_bytes_and_members_rehashed": True,
            "original_import_identity_checked": True,
            "historical_source_identities_preserved": True,
            "archive_members_extracted_to_disk": False,
            "raw_application_test_events_recounted": False,
            "original_runtime_or_workspace_reconstructed": False,
            "application_tests_or_builds_executed": False,
            "new_branch_inventories_captured": False,
            "github_actions_accessed": False,
            "qualification_counts": "632 remains historical evidence at ac1e4c8c. This is an import byte-integrity audit, not a new product acceptance run.",
        },
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "newimports-audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({name: report[name] for name in ("status", "frozen_integration_source", "new_archive_count", "new_members_verified", "combined_archive_count", "combined_verified_member_count", "failures")}))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
