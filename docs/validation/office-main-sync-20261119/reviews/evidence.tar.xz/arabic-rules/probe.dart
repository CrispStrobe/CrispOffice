import 'dart:convert';
import 'arabic_writing_rules.dart';
import 'package:quds_office_engine/src/proofing/office_proofing.dart';
Future<void> main() async {
  for (final text in <String>['ذهب ا\u0655لى البيت.', 'xالى y', 'الىbar', 'fooو هو', 'ذهبَ الَى السوق.', 'لان الحديد بالحرارة.']) {
    final result = await ArabicWritingRulesProvider().check(OfficeProofingRequest(documentId: 'probe', blockId: 'p', revision: 1, text: text, language: 'ar'));
    print(jsonEncode({'text':text, 'findings': [for (final f in result.findings) {'rule':f.ruleId,'text':f.originalText,'replacement':f.replacements,'start':f.start,'end':f.end}]}));
  }
}
