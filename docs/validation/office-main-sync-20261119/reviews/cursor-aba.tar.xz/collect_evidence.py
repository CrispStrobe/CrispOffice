#!/usr/bin/env python3
"""Recount retained cursor-regression development runs and bind source bytes."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo, runtime, output = args.repo.resolve(), args.runtime.resolve(), args.output.resolve()
    base = '0d0805492f0ef7c97489054c0695637aa300cb3d'
    runner_path = repo / 'docs/validation/document-review-notes-20261118/run_checks.py'
    spec = importlib.util.spec_from_file_location('qualified_runner', runner_path)
    assert spec is not None and spec.loader is not None
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    package = repo / 'packages/quds_mail_transport'
    plans = {
        'red': ['test/host_store_integration_test.dart'],
        'green-vm': ['test/cursor_test.dart', 'test/uid_discovery_test.dart', 'test/host_store_integration_test.dart'],
        'green-node': ['test/cursor_test.dart'],
    }
    runs = {}
    for name, files in plans.items():
        log = output / (name + '.jsonl')
        result = runner.parse_reporter(log, package, files)
        (output / (name + '-accounting.json')).write_text(json.dumps(result, indent=2) + '\n')
        runs[name] = {
            'observed_process_exit': 1 if name == 'red' else 0,
            'log': log.name,
            'log_sha256': sha(log.read_bytes()),
            'requested_suites': files,
            'platform': 'node' if name == 'green-node' else 'vm',
            'passed': result['passed'], 'failed': result['failed'], 'skipped': result['skipped'],
            'reporter_success': result['reporter_success'],
            'accepted_by_strict_runner': runner.reporter_passed(result),
            'errors': result['errors'],
        }
    if runs['red']['failed'] != 1 or runs['red']['passed'] != 0:
        raise RuntimeError('Expected exactly one reproduced failure in the red run')
    if not all(runs[name]['accepted_by_strict_runner'] for name in ['green-vm', 'green-node']):
        raise RuntimeError('Green runs did not pass strict accounting')
    changed = [
        'packages/quds_mail_transport/lib/src/cursor.dart',
        'packages/quds_mail_transport/lib/src/native/provider.dart',
        'packages/quds_mail_transport/test/cursor_test.dart',
        'packages/quds_mail_transport/test/uid_discovery_test.dart',
        'packages/quds_mail_transport/test/host_store_integration_test.dart',
        'packages/quds_mail_transport/README.md',
        'packages/quds_mail_transport/CHANGELOG.md',
    ]
    green_sources = {}
    for name in changed:
        data = (repo / name).read_bytes()
        path = output / 'green-source' / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        green_sources[name] = {'sha256': sha(data), 'bytes': len(data)}
    red_sources = {}
    for path in sorted((output / 'red-source').rglob('*')):
        if not path.is_file():
            continue
        name = path.relative_to(output / 'red-source').as_posix()
        data = path.read_bytes()
        recorded = {'sha256': sha(data), 'bytes': len(data)}
        if '/lib/' in name:
            original = subprocess.check_output(['git', '-C', str(repo), 'show', base + ':' + name])
            recorded['matches_base_git_blob'] = data == original
            if data != original:
                raise RuntimeError('Red product source does not match base: ' + name)
        red_sources[name] = recorded
    analysis = (output / 'analysis.log').read_bytes()
    formatting = (output / 'format.log').read_bytes()
    if b'No issues found!' not in analysis or b'(0 changed)' not in formatting:
        raise RuntimeError('Strict analysis/format output missing expected success')
    report = {
        'status': 'REPRODUCED_AND_FIXED',
        'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'base_commit_for_red_product_source': base,
        'scope': 'Development regression evidence only. Final frozen-source qualification is run separately by the integration owner; these counts are not added to final acceptance.',
        'defect': 'Completed sweeps reused an identical cursor, allowing a stale complete page to pass value-only CAS and restore an expunged UID or older flags.',
        'repair': 'v3 cursor carries a per-page revision. v1/v2 decode as revision zero; every returned page increments it across completion, emptiness and UIDVALIDITY resets.',
        'maximum_revision': 9007199254740991,
        'exhaustion': 'invalidInput before credential access or protocol work; no wrap or rounding.',
        'runs': runs,
        'analysis': {'observed_process_exit': 0, 'log_sha256': sha(analysis), 'dart_files': changed[:5]},
        'format': {'observed_process_exit': 0, 'log_sha256': sha(formatting), 'dart_files': changed[:5]},
        'red_source': red_sources,
        'green_source': green_sources,
        'runtime_receipt_sha256': sha((runtime / 'runtime.json').read_bytes()),
        'runtime_environment_sha256': sha((runtime / 'env.sh').read_bytes()),
        'workspace_package_config_sha256': sha((repo / '.dart_tool/package_config.json').read_bytes()),
        'event_accounting_runner_sha256': sha(runner_path.read_bytes()),
        'collector_sha256': sha(Path(__file__).read_bytes()),
        'github_actions_accessed': False,
    }
    (output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'runs': {name: {k: row[k] for k in ['passed', 'failed', 'skipped', 'accepted_by_strict_runner']} for name,row in runs.items()}}))


if __name__ == '__main__':
    main()
