#!/usr/bin/env python3
"""Combine independently audited executions without counting platform repeats twice as files."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--source', required=True)
    p.add_argument('--audit-directory', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    issues = []
    groups, suites, identities, audits = [], [], set(), []
    for label in ['vm', 'node']:
        path = a.audit_directory / (label + '-audit-' + a.source[:8] + '.json')
        result = json.loads(path.read_text())
        if result.get('passed') is not True or result['source_commit'] != a.source:
            issues.append(label + ': unsuccessful or inconsistent audit')
        plan = json.loads(subprocess.check_output(['git', '--no-replace-objects', 'show', a.source + ':' + result['plan']], cwd=a.repo))
        for group in plan['groups']:
            suites.extend({'gate': label, 'path': (Path(group['cwd']) / test).as_posix(), 'platform': group.get('platform', 'vm')} for test in group['tests'])
        groups.extend({'gate': label, **group} for group in result['groups'])
        identities.add(result['verified_runtime_recovery']['receipt_sha256'])
        audits.append({'gate': label, 'audit': path.name, 'sha256': sha(path), 'source_inputs': result['source_inputs_reverified'], 'runtime_inputs': result['runtime_inputs_reverified'], 'audit_script_sha256': result['audit_script_sha256']})
    duplicate = [{'path': path, 'platform': platform, 'count': count} for (path, platform), count in Counter((x['path'], x['platform']) for x in suites).items() if count != 1]
    if duplicate:
        issues.append('duplicate suite/platform executions')
    if len(identities) != 1:
        issues.append('inconsistent runtime receipt')
    path = a.audit_directory / ('python-audit-' + a.source[:8] + '.json')
    support = json.loads(path.read_text())
    if support.get('passed') is not True or support['source_commit'] != a.source:
        issues.append('Python controls not accepted or source differs')
    result = {'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': a.source, 'source_tree': subprocess.check_output(['git', '--no-replace-objects', 'rev-parse', a.source + '^{tree}'], cwd=a.repo, text=True).strip(), 'method': 'Combine independently recounted source-bound VM/Node events and separate Python controls. No application tests executed by audit; historical and development runs excluded.', 'audit_script_sha256': sha(__file__), 'gates': audits, 'groups': groups, 'application_case_executions': sum(g['passed'] for g in groups), 'suite_platform_executions': len(suites), 'distinct_test_files': len({s['path'] for s in suites}), 'suite_platform_inventory': suites, 'duplicate_suite_platform_executions': duplicate, 'failed': sum(g['failed'] for g in groups), 'skipped': sum(g['skipped'] for g in groups), 'runtime_receipt_sha256': sorted(identities), 'separate_python_controls': support['passed_python_controls'], 'python_audit': {'path': path.name, 'sha256': sha(path), 'source_inputs': support['source_inputs_reverified'], 'audit_script_sha256': support['audit_script_sha256']}, 'historical_cases_added': 0, 'development_cases_added': 0, 'github_actions': 'NOT QUERIED OR AWAITED', 'issues': issues, 'passed': not issues}
    a.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ['source_commit', 'application_case_executions', 'suite_platform_executions', 'distinct_test_files', 'separate_python_controls', 'failed', 'skipped', 'passed', 'issues']}, indent=2))
    return bool(issues)


if __name__ == '__main__':
    raise SystemExit(main())
