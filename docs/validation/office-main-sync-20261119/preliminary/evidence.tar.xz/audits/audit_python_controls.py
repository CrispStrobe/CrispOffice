#!/usr/bin/env python3
"""Independently recount three source-bound Python qualification control groups."""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--source', required=True)
    p.add_argument('--gate', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    issues = []
    def check(value, text):
        if not value:
            issues.append(text)
    def frozen(path):
        return subprocess.check_output(['git', '--no-replace-objects', 'show', args.source + ':' + path], cwd=args.repo)
    receipt_raw = (args.gate / 'receipt.json').read_bytes()
    receipt = json.loads(receipt_raw)
    check(receipt['source_commit'] == args.source, 'exact execution source')
    check(receipt['success'] is True and bool(receipt.get('finished_at_utc')), 'complete accepted receipt')
    check(receipt['source_before'] == receipt['source_after'] and receipt['source_unchanged'] is True and receipt['head_unchanged'] is True, 'stable execution inputs')
    expected_sources = {
        'tools/mail/check_store.py', 'tools/mail/check_reader.py', 'tools/mail/test_check_store.py',
        'docs/validation/document-review-notes-20261118/run_checks.py',
        'docs/validation/document-review-notes-20261118/test_run_checks.py',
        'docs/validation/document-review-notes-20261118/runtime/restore_runtime.py',
        'docs/validation/document-review-notes-20261118/runtime/test_restore_runtime.py',
    }
    check(set(receipt['source_before']) == expected_sources, 'complete expected source scope')
    for path, expected in receipt['source_before'].items():
        check(sha(frozen(path)) == sha((args.repo / path).read_bytes()) == expected, 'immutable/materialized source binding: ' + path)
    check(sha(Path(receipt['python_executable']).read_bytes()) == receipt['python_sha256'], 'Python executable binding')
    expected_groups = [
        ('store-launcher', 'tools/mail', 'test_check_store.py'),
        ('qualification-runner', 'docs/validation/document-review-notes-20261118', 'test_run_checks.py'),
        ('runtime-replay', 'docs/validation/document-review-notes-20261118/runtime', 'test_restore_runtime.py'),
    ]
    check([g['name'] for g in receipt['groups']] == [g[0] for g in expected_groups], 'exact group inventory and order')
    reports = []
    all_ids = []
    for group, (name, directory, filename) in zip(receipt['groups'], expected_groups, strict=True):
        expected_command = [receipt['python_executable'], '-B', '-m', 'unittest', 'discover', '-s', directory, '-p', filename, '-v']
        check(group['command'] == expected_command, name + ': exact unittest command')
        check(group['exit_code'] == 0 and group['success'] is True, name + ': accepted process exit')
        raw = (args.gate / group['log']).read_bytes()
        check(sha(raw) == group['sha256'], name + ': raw log hash')
        rows = re.findall(r'^(test\S+) \(([^)]+)\) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$', raw.decode(), re.MULTILINE)
        ids = [owner for method, owner, result in rows]
        check(len(ids) == len(set(ids)) and all(result == 'ok' for method, owner, result in rows), name + ': distinct successful raw cases')
        check(all(owner.endswith('.' + method) for method, owner, result in rows), name + ': raw method/owner agreement')
        terminal = re.findall(rb'Ran (\d+) tests? in [^\n]+\n\s*\nOK\s*$', raw)
        check(len(terminal) == 1 and int(terminal[0]) == len(rows) == group['tests'], name + ': exact raw terminal count')
        module = Path(filename).stem
        syntax = ast.parse(frozen(directory + '/' + filename))
        definitions = {module + '.' + cls.name + '.' + method.name for cls in syntax.body if isinstance(cls, ast.ClassDef) for method in cls.body if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)) and method.name.startswith('test')}
        check(set(ids) == definitions, name + ': all frozen test definitions executed exactly once')
        all_ids.extend(name + '::' + case_id for case_id in ids)
        reports.append({'name': name, 'passed_cases': len(rows), 'raw_log_sha256': sha(raw), 'exact_frozen_definition_inventory': set(ids) == definitions, 'case_ids': ids})
    count = sum(g['passed_cases'] for g in reports)
    check(count == receipt['tests'] and len(all_ids) == len(set(all_ids)), 'aggregate count and unique identities')
    result = {'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': args.source, 'method': 'Independent verbose-log recount, exact frozen AST test definitions, immutable Git/current source hashes and current Python executable hash. No tests executed; no repository parser imported.', 'audit_script_sha256': sha(Path(__file__).read_bytes()), 'receipt_sha256': sha(receipt_raw), 'source_inputs_reverified': len(receipt['source_before']), 'groups': reports, 'passed_python_controls': count, 'issues': issues, 'passed': not issues}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['source_commit', 'source_inputs_reverified', 'passed_python_controls', 'passed', 'issues']}, indent=2))
    return bool(issues)


if __name__ == '__main__':
    raise SystemExit(main())
