#!/usr/bin/env python3
"""Combine original application execution with separately qualified incoming controls."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--application-summary', type=Path, required=True)
    p.add_argument('--python-audit', type=Path, required=True)
    p.add_argument('--bundle-audit', type=Path, required=True)
    p.add_argument('--continuity-audit', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    app = json.loads(a.application_summary.read_text())
    python = json.loads(a.python_audit.read_text())
    bundle = json.loads(a.bundle_audit.read_text())
    continuity = json.loads(a.continuity_audit.read_text())
    issues = []
    if not all(x.get('passed') is True for x in [app, python, bundle, continuity]):
        issues.append('at least one component audit unsuccessful')
    if app['source_commit'] != python['source_commit'] or app['source_commit'] != continuity['application_execution_source'] or bundle['source_commit'] != continuity['bundle_execution_source']:
        issues.append('component execution identities differ')
    control_ids = [case for group in python['groups'] for case in group['case_ids']] + bundle['case_ids']
    if len(control_ids) != len(set(control_ids)):
        issues.append('duplicate Python test identity')
    result = {'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'checked_target': continuity['checked_target'], 'checked_target_tree': continuity['checked_target_tree'], 'application_execution_source': app['source_commit'], 'python_controls_execution_source': python['source_commit'], 'bundle_execution_source': bundle['source_commit'], 'original_execution_identities_preserved': True, 'application_case_executions': app['application_case_executions'], 'suite_platform_executions': app['suite_platform_executions'], 'distinct_application_test_files': app['distinct_test_files'], 'application_groups': app['groups'], 'failed_application_cases': app['failed'], 'skipped_application_cases': app['skipped'], 'separate_python_controls': python['passed_python_controls'] + bundle['passed_python_controls'], 'python_groups': [{'name': group['name'], 'passed': group['passed_cases']} for group in python['groups']] + [{'name': 'ayaspell-offline-bundle', 'passed': bundle['passed_python_controls'], 'test_files': bundle['test_files']}], 'distinct_qualified_input_paths': continuity['distinct_qualified_input_paths'], 'original_gate_inputs_unchanged_in_target': continuity['passed'], 'application_gate_input_changes': continuity['application_gate_input_changes'], 'runtime_receipt_sha256': app['runtime_receipt_sha256'], 'audit_script_sha256': sha(__file__), 'component_audits': [{'path': path.name, 'sha256': sha(path)} for path in [a.application_summary, a.python_audit, a.bundle_audit, a.continuity_audit]], 'historical_cases_added': 0, 'development_cases_added': 0, 'new_application_tests_executed_by_audit': 0, 'scope': 'Local qualification and exact input continuity only. The bounded remote ref-accounting report is separate.', 'github_actions': 'NOT QUERIED OR AWAITED', 'issues': issues, 'passed': not issues}
    a.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['checked_target', 'application_execution_source', 'bundle_execution_source', 'application_case_executions', 'suite_platform_executions', 'distinct_application_test_files', 'separate_python_controls', 'distinct_qualified_input_paths', 'passed', 'issues']}, indent=2))
    return bool(issues)


if __name__ == '__main__':
    raise SystemExit(main())
