#!/usr/bin/env python3
"""Verify qualified input scopes and immutable identities in a later publication."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--app-source', required=True)
    p.add_argument('--bundle-source', required=True)
    p.add_argument('--target', required=True)
    p.add_argument('--checks-root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    issues, gates, union = [], {}, set()
    def check(value, message):
        if not value:
            issues.append(message)
    def git(*words):
        return subprocess.check_output(['git', '--no-replace-objects', *words], cwd=a.repo)
    def tree(commit):
        entries = {}
        for row in git('ls-tree', '-r', '-z', commit).split(b'\0'):
            if row:
                meta, path = row.split(b'\t', 1)
                mode, kind, blob = meta.decode().split()
                entries[path.decode()] = {'mode': mode, 'type': kind, 'git_blob': blob}
        return entries
    original_tree, bundle_tree, target_tree = tree(a.app_source), tree(a.bundle_source), tree(a.target)
    for label in ['vm', 'node']:
        directory = a.checks_root / label
        raw = (directory / 'source-before.json').read_bytes()
        after_raw = (directory / 'source-after.json').read_bytes()
        manifest = json.loads(raw)
        receipt_raw = (directory / 'verification.json').read_bytes()
        receipt = json.loads(receipt_raw)
        check(receipt['source_commit'] == a.app_source and receipt['success'] is True, label + ': original execution identity')
        check(raw == after_raw and sha(raw) == receipt['manifest_sha256']['source-before.json'] == receipt['manifest_sha256']['source-after.json'], label + ': stable original manifest binding')
        plan_name = receipt['plan']
        plan = json.loads(git('show', a.app_source + ':' + plan_name))
        selected = {path for path in target_tree if path.startswith(('packages/', 'apps/', 'third_party/'))}
        selected.update(path for path in target_tree if '/' not in path and Path(path).suffix in {'.yaml', '.lock'})
        selected.update([plan_name, 'docs/validation/document-review-notes-20261118/run_checks.py', 'tools/mail/check_store.py', 'tools/mail/check_reader.py'])
        selected.update(receipt['analysis_files'])
        selected.update(receipt['formatted_files'])
        selected.update(plan.get('extra_inputs', []))
        selected.update(row['path'] for row in plan.get('whitespace_preserved_inputs', []))
        selected.update((Path(group['cwd']) / path).as_posix() for group in plan['groups'] for path in group['tests'])
        bad = []
        for path, bound in manifest.items():
            expected = {'mode': bound['mode'], 'type': 'blob', 'git_blob': bound['git_blob']}
            if original_tree.get(path) != expected or target_tree.get(path) != expected:
                bad.append(path)
        added, removed = sorted(selected - set(manifest)), sorted(set(manifest) - selected)
        check(not bad and not added and not removed, label + ': original exact scope or immutable inputs changed')
        gates[label] = {'execution_source': a.app_source, 'bound_inputs': len(manifest), 'receipt_sha256': sha(receipt_raw), 'source_manifest_sha256': sha(raw), 'mismatched_paths': bad, 'added_scoped_paths': added, 'removed_scoped_paths': removed, 'passed': not bad and not added and not removed}
        union.update(manifest)
    application_bound_paths = set(union)
    for label, source, source_tree in [('python-controls', a.app_source, original_tree), ('python-bundle', a.bundle_source, bundle_tree)]:
        receipt_raw = (a.checks_root / label / 'receipt.json').read_bytes()
        receipt = json.loads(receipt_raw)
        check(receipt['source_commit'] == source and receipt['success'] is True and receipt['source_before'] == receipt['source_after'], label + ': accepted original identity and stable input scope')
        bad = []
        for path, expected in receipt['source_before'].items():
            if source_tree.get(path) != target_tree.get(path) or sha(git('show', source + ':' + path)) != expected or sha(git('show', a.target + ':' + path)) != expected:
                bad.append(path)
        check(not bad, label + ': immutable inputs changed')
        gates[label] = {'execution_source': source, 'bound_inputs': len(receipt['source_before']), 'receipt_sha256': sha(receipt_raw), 'mismatched_paths': bad, 'passed': not bad}
        union.update(receipt['source_before'])
    support = ['docs/validation/document-review-notes-20261118/runtime/native_asset_smoke.dart']
    support_bad = [path for path in support if original_tree.get(path) != target_tree.get(path)]
    check(not support_bad, 'runtime native smoke source changed')
    union.update(support)
    ancestors = {}
    for source in [a.app_source, a.bundle_source]:
        ancestors[source] = subprocess.run(['git', '--no-replace-objects', 'merge-base', '--is-ancestor', source, a.target], cwd=a.repo).returncode == 0
    check(all(ancestors.values()), 'original execution commits must remain ancestors')
    changed = git('diff', '--name-only', a.app_source, a.target).decode().splitlines()
    result = {'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'checked_target': a.target, 'checked_target_tree': git('rev-parse', a.target + '^{tree}').decode().strip(), 'application_execution_source': a.app_source, 'bundle_execution_source': a.bundle_source, 'method': 'Exact frozen Git mode/type/blob comparisons, source SHA-256 checks and current target scope reconstruction against the original execution manifests. Original execution sources are preserved, not relabeled.', 'audit_script_sha256': sha(Path(__file__).read_bytes()), 'gates': gates, 'runtime_smoke_source_mismatches': support_bad, 'original_execution_ancestry': ancestors, 'distinct_qualified_input_paths': len(union), 'changed_paths_since_application_execution': changed, 'application_gate_input_changes': sorted(set(changed) & application_bound_paths), 'new_application_test_executions': 0, 'issues': issues, 'passed': not issues}
    a.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['checked_target', 'distinct_qualified_input_paths', 'original_execution_ancestry', 'passed', 'issues']}, indent=2))
    return bool(issues)


if __name__ == '__main__':
    raise SystemExit(main())
