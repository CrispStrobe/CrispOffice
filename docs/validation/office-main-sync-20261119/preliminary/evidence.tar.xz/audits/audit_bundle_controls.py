#!/usr/bin/env python3
"""Independently recount source-bound offline AyaSpell controls."""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--source', required=True)
    p.add_argument('--gate', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    issues = []
    def check(value, text):
        if not value:
            issues.append(text)
    def git(*words):
        return subprocess.check_output(['git', '--no-replace-objects', *words], cwd=args.repo)
    def frozen(path):
        return git('show', args.source + ':' + path)
    receipt_raw = (args.gate / 'receipt.json').read_bytes()
    receipt = json.loads(receipt_raw)
    check(receipt['source_commit'] == args.source, 'exact execution source')
    check(receipt['success'] is True and receipt['exit_code'] == 0 and bool(receipt.get('finished_at_utc')), 'complete successful process receipt')
    check(receipt['source_before'] == receipt['source_after'] and receipt['source_unchanged'] is True and receipt['head_unchanged'] is True, 'stable execution inputs')
    prefix = 'tools/proofing/ayaspell/'
    expected_sources = {prefix + name for name in ['build_bundle.py', 'test_build_bundle.py', 'test_build_bundle_incoming.py']}
    check(set(receipt['source_before']) == expected_sources, 'complete expected source scope')
    for path, expected in receipt['source_before'].items():
        check(sha(frozen(path)) == sha((args.repo / path).read_bytes()) == expected, 'immutable/materialized source binding: ' + path)
    check(sha(Path(receipt['python_executable']).read_bytes()) == receipt['python_sha256'], 'Python executable binding')
    expected_command = [receipt['python_executable'], '-B', '-m', 'unittest', 'discover', '-s', 'tools/proofing/ayaspell', '-p', 'test_build_bundle*.py', '-v']
    check(receipt['command'] == expected_command, 'exact offline unittest command')
    raw = (args.gate / receipt['log']).read_bytes()
    check(sha(raw) == receipt['log_sha256'], 'raw log hash')
    rows = re.findall(r'^(test\S+) \(([^)]+)\) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$', raw.decode(), re.MULTILINE)
    ids = [owner for method, owner, result in rows]
    check(len(ids) == len(set(ids)) and all(result == 'ok' for method, owner, result in rows), 'distinct successful raw cases')
    check(all(owner.endswith('.' + method) for method, owner, result in rows), 'raw method/owner agreement')
    terminal = re.findall(rb'Ran (\d+) tests? in [^\n]+\n\s*\nOK\s*$', raw)
    check(len(terminal) == 1 and int(terminal[0]) == len(rows) == receipt['tests'], 'exact raw terminal count')
    expected_test_files = {'test_build_bundle.py', 'test_build_bundle_incoming.py'}
    check({p.name for p in (args.repo / prefix).glob('test_build_bundle*.py')} == expected_test_files, 'exact materialized discovered test files')
    frozen_files = git('ls-tree', '--name-only', args.source + ':' + prefix.rstrip('/')).decode().splitlines()
    check({name for name in frozen_files if re.fullmatch(r'test_build_bundle.*\.py', name)} == expected_test_files, 'exact frozen discovered test files')
    definitions = set()
    by_file = {}
    for filename in sorted(expected_test_files):
        module = Path(filename).stem
        syntax = ast.parse(frozen(prefix + filename))
        found = {module + '.' + cls.name + '.' + method.name for cls in syntax.body if isinstance(cls, ast.ClassDef) for method in cls.body if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)) and method.name.startswith('test')}
        definitions.update(found)
        by_file[filename] = len(found)
    check(set(ids) == definitions, 'all frozen test definitions executed exactly once')
    check(receipt['network_or_publication'] is False, 'recorded local-only execution boundary')
    result = {'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': args.source, 'method': 'Independent verbose-log recount, exact frozen AST/discovery inventories, immutable Git/current source hashes and current Python executable hash. No tests, downloads or publications executed by audit.', 'audit_script_sha256': sha(Path(__file__).read_bytes()), 'receipt_sha256': sha(receipt_raw), 'source_inputs_reverified': len(receipt['source_before']), 'test_files': by_file, 'case_ids': ids, 'passed_python_controls': len(rows), 'raw_log_sha256': sha(raw), 'issues': issues, 'passed': not issues}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['source_commit', 'source_inputs_reverified', 'test_files', 'passed_python_controls', 'passed', 'issues']}, indent=2))
    return bool(issues)


if __name__ == '__main__':
    raise SystemExit(main())
