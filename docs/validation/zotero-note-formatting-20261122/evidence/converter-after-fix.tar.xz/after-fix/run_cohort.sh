#!/usr/bin/env bash
set -euo pipefail
source /workspace/scratch/eba1aedcc131/toolchains/env.sh
cd /workspace/scratch/eba1aedcc131/validation/converter-after-fix
python - <<'PY'
import subprocess,json
from pathlib import Path
repo=Path('/workspace/scratch/eba1aedcc131/quds_office_suite')
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'tracked_status':subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=no'],cwd=repo,text=True)}
Path('source-head-before.json').write_text(json.dumps(record,indent=2)+'\n')
PY
python capture_inputs.py inputs-before.json > inputs-before.log
dart --packages=/workspace/scratch/eba1aedcc131/quds_office_suite/.dart_tool/package_config.json fixture.dart generate original > generate.log 2> generate.stderr
python - <<'PY'
import json
from pathlib import Path
initial=Path('/workspace/scratch/eba1aedcc131/validation/converter/original')
results={kind:json.loads(Path(f'original/{kind}.expected.json').read_text())==json.loads((initial/f'{kind}.expected.json').read_text()) for kind in ['body','footnote','cell']}
Path('expected-snapshot-comparison.json').write_text(json.dumps(results,indent=2)+'\n')
if not all(results.values()):raise SystemExit('Regenerated expected snapshots differ from frozen before-fix expectations; primary cohort stopped.')
PY
python convert.py > convert.log 2> convert.stderr
python check_native.py > native-check.log 2> native-check.stderr
python check_xml.py > xml-check.log 2> xml-check.stderr
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 geometry_probe.py > geometry-results.log 2> geometry-results.stderr
python capture_inputs.py inputs-after.json > inputs-after.log
python - <<'PY'
import subprocess,json
from pathlib import Path
repo=Path('/workspace/scratch/eba1aedcc131/quds_office_suite')
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'tracked_status':subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=no'],cwd=repo,text=True)}
Path('source-head-after.json').write_text(json.dumps(record,indent=2)+'\n')
PY
python summarize.py > summary.log
cat summary.log
