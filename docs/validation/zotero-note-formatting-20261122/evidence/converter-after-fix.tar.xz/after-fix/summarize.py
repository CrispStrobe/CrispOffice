from pathlib import Path
from collections import Counter
import json,hashlib,re

root=Path(__file__).resolve().parent
native=json.loads((root/'native-results.json').read_text())
xml=json.loads((root/'xml-results.json').read_text())
conversion=json.loads((root/'conversion-results.json').read_text())
before=json.loads((root/'inputs-before.json').read_text())
after=json.loads((root/'inputs-after.json').read_text())
changed=[key for key in before.keys()|after.keys() if before.get(key)!=after.get(key)]
geometry=json.loads((root/'geometry-results.json').read_text())
centers={r['label']:(r['markers']['TAIL'][0][0]+r['markers']['TAIL'][0][2])/2 for r in geometry}
initial=root.parent/'converter'/'original'
expected_identical={kind:json.loads((root/'original'/f'{kind}.expected.json').read_text())==json.loads((initial/f'{kind}.expected.json').read_text()) for kind in ['body','footnote','cell']}

def exact_native_content(r):
    # Preserve the strict native verdict. This is a separately named component
    # score that classifies the existing explicit field-boundary edit guard.
    return r['status'] in ('passed','different') and all(re.fullmatch(r'/fields/[01]/editable=false, expected true',f) for f in r.get('findings',[]))

summary={
 'phase':'after-direction-io-fix',
 'converter_version':(root/'converter-version.txt').read_text().strip(),
 'input_count':len(before),
 'changed_inputs':changed,
 'expected_snapshots_identical_to_before_fix':expected_identical,
 'input_manifest_sha256':hashlib.sha256((root/'inputs-before.json').read_bytes()).hexdigest(),
 'successful_save_operations':sum(r['exit_code']==0 and o['exists'] for r in conversion for o in r['outputs']),
 'strict_native_verdicts':dict(Counter(r['status'] for r in native)),
 'strict_xml_verdicts':dict(Counter(r['status'] for r in xml)),
 'docx_native_content_format_and_metadata':{'passed':sum(exact_native_content(r) for r in native if r['file'].endswith('.docx')),'total':sum(r['file'].endswith('.docx') for r in native),'scope':'Existing fixture snapshot: story text; selected paragraph direction, alignment, physical indent, and heading level; empty paragraph format; foreground/highlight; field data/story ownership/balanced markers; preferences. Excludes only the separately reported editable flag; strict native assertions remain unchanged. This is not complete typography, spacing, or pagination qualification.'},
 'docx_editability':{'original_passed':sum(r['status']=='passed' for r in native if r['file'].startswith('original/') and r['file'].endswith('.docx')),'converted_guarded':sum(r['status']=='different' and exact_native_content(r) for r in native if not r['file'].startswith('original/') and r['file'].endswith('.docx'))},
 'odt_native_reopen':dict(Counter(r['status'] for r in native if r['file'].endswith('.odt'))),
 'xml_color_and_highlight':{'passed':sum(r['status']!='error' and not any(f.startswith('colors/') for f in r.get('findings',[])) for r in xml),'total':len(xml)},
 'xml_fields_and_preferences':{'passed':sum(r['status']!='error' and not any(f.startswith(('field_metadata/','field_metadata:','preferences/','Citation owner')) for f in r.get('findings',[])) for r in xml),'total':len(xml)},
 'centered_rtl_tail_geometry':{'centers_points':centers,'original_docx_vs_odt_difference':abs(centers['original-docx']-centers['original-odt']),'cycle_docx_vs_odt_difference':abs(centers['cycle-docx']-centers['original-odt']),'tolerance_points':0.5,'passed':abs(centers['original-docx']-centers['original-odt'])<0.5 and abs(centers['cycle-docx']-centers['original-odt'])<0.5},
 'retained_limits':['LibreOffice adds field-boundary run properties; existing opaqueMetadata guard prevents native field editing while retaining valid data.','LibreOffice-saved ODTs trigger existing outline-style guards.'],
 'word_or_zotero_plugin_acceptance':False,
}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
