from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,time

root=Path(__file__).resolve().parent
dart='/workspace/scratch/eba1aedcc131/toolchains/flutter/bin/cache/dart-sdk/bin/dart'
configuration='/workspace/scratch/eba1aedcc131/quds_office_suite/.dart_tool/package_config.json'
command=[dart,'compile','kernel','--packages='+configuration,str(root/'fixture.dart'),'-o',str(root/'fixture.dill')]
compiled=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
(root/'compile.log').write_bytes(compiled.stdout)
if compiled.returncode:raise SystemExit(compiled.returncode)
paths=[p for d in ['original','odt-cycle-1','odt-cycle-2','docx-cycle-1','docx-cycle-2'] for p in sorted((root/d).glob('*')) if p.suffix in ('.odt','.docx')]
def run(path):
    command=[dart,str(root/'fixture.dill'),'check',str(path),str(root/'original'/f'{path.stem}.expected.json')]
    completed=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
    label=path.parent.name+'-'+path.name
    (root/(label+'.native.json')).write_bytes(completed.stdout)
    (root/(label+'.native.stderr')).write_bytes(completed.stderr)
    try:result=json.loads(completed.stdout)
    except Exception:result={'file':str(path),'status':'runner-error','stderr':completed.stderr.decode(errors='replace')}
    return {'file':str(path.relative_to(root)),'command':command,'exit_code':completed.returncode,**{k:v for k,v in result.items() if k in ('status','error','findings')}}
with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,paths))
(root/'native-results.json').write_text(json.dumps(results,indent=2)+'\n')
for result in results:print(json.dumps(result))
