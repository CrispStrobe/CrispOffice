from pathlib import Path
import json,re,zipfile,xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
O='urn:oasis:names:tc:opendocument:xmlns:office:1.0'
T='urn:oasis:names:tc:opendocument:xmlns:text:1.0'
S='urn:oasis:names:tc:opendocument:xmlns:style:1.0'
F='urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0'
TAB='urn:oasis:names:tc:opendocument:xmlns:table:1.0'
M='urn:oasis:names:tc:opendocument:xmlns:meta:1.0'
C='http://schemas.openxmlformats.org/officeDocument/2006/custom-properties'
q=lambda namespace,name:f'{{{namespace}}}{name}'
palette={'yellow':'FFFF00','green':'00FF00','cyan':'00FFFF','magenta':'FF00FF','blue':'0000FF','red':'FF0000','darkBlue':'000080','darkCyan':'008080','darkGreen':'008000','darkMagenta':'800080','darkRed':'800000','darkYellow':'808000','darkGray':'808080','lightGray':'C0C0C0','black':'000000','white':'FFFFFF'}

def text_of(element,odt=False):
    if odt:
        def collect(e):
            if e.tag==q(T,'note'):return ''
            if e.tag==q(T,'s'):return ' '*int(e.get(q(T,'c'),'1'))
            if e.tag==q(T,'tab'):return '\t'
            if e.tag==q(T,'line-break'):return '\n'
            return (e.text or '')+''.join(collect(child)+(child.tail or '') for child in e)
        return collect(element).strip()
    return ''.join(e.text or '' for e in element.iter(q(W,'t'))).strip()

def ancestors(element,parents):
    while element in parents:
        element=parents[element]
        yield element

def length(value):
    if value is None:return 0.0
    match=re.fullmatch(r'([+-]?[0-9]+(?:\.[0-9]+)?)(in|cm|mm|pt|pc)',value)
    if not match:raise ValueError('unrecognized length '+value)
    return float(match[1])*{'in':72,'cm':72/2.54,'mm':72/25.4,'pt':1,'pc':12}[match[2]]

def metadata(instruction):
    found=re.search(r'CSL_CITATION\s+',instruction)
    return None if not found else json.JSONDecoder().raw_decode(instruction[found.end():])[0]

def check_equal(expected,actual,path,findings):
    if isinstance(expected,dict) and isinstance(actual,dict):
        for key,value in expected.items():check_equal(value,actual.get(key),path+'/'+str(key),findings)
    elif isinstance(expected,list) and isinstance(actual,list):
        if len(expected)!=len(actual):findings.append(f'{path}: length {len(actual)} expected {len(expected)}')
        for i,(a,b) in enumerate(zip(expected,actual)):check_equal(a,b,path+'/'+str(i),findings)
    elif isinstance(expected,(float,int)) and not isinstance(expected,bool) and isinstance(actual,(float,int)):
        if abs(expected-actual)>0.02:findings.append(f'{path}: {actual!r} expected {expected!r}')
    elif expected!=actual:findings.append(f'{path}: {actual!r} expected {expected!r}')

def check_docx(bundle,expected):
    styles=ET.fromstring(bundle.read('word/styles.xml'))
    by_name={e.get(q(W,'styleId')):e for e in styles.findall(q(W,'style'))}
    def read_props(container,kind):
        e=container.find(q(W,kind)) if container is not None else None
        return {} if e is None else {child.tag:dict(child.attrib) for child in e}
    defaults=styles.find(q(W,'docDefaults'))
    def style_props(name,kind,seen=()):
        if not name or name not in by_name or name in seen:return {}
        e=by_name[name]
        parent=e.find(q(W,'basedOn'))
        result=style_props(parent.get(q(W,'val')) if parent is not None else None,kind,seen+(name,))
        for key,attrs in read_props(e,kind).items():result.setdefault(key,{}).update(attrs)
        return result
    def props(element,kind,base=None):
        result={} if base is None else {k:dict(v) for k,v in base.items()}
        direct=element.find(q(W,kind))
        named=direct.find(q(W,'pStyle' if kind=='pPr' else 'rStyle')) if direct is not None else None
        for key,attrs in style_props(named.get(q(W,'val')) if named is not None else None,kind).items():result.setdefault(key,{}).update(attrs)
        for key,attrs in read_props(element,kind).items():result.setdefault(key,{}).update(attrs)
        return result
    def val(properties,name,default=None):return properties.get(q(W,name),{}).get(q(W,'val'),default)
    def para_style(p):
        default=read_props(defaults.find(q(W,'pPrDefault')),'pPr') if defaults is not None else {}
        properties=props(p,'pPr',default)
        bidi=properties.get(q(W,'bidi'))
        rtl=bidi is not None and bidi.get(q(W,'val'),'1') not in ('0','false','off')
        align=val(properties,'jc','left')
        align={'both':'justify','start':'right' if rtl else 'left','end':'left' if rtl else 'right'}.get(align,align)
        indent=properties.get(q(W,'ind'),{})
        # OOXML left/right are transitional aliases of logical start/end.
        # Physical indentation depends on paragraph bidi, even before LO save.
        before=float(indent.get(q(W,'start'),indent.get(q(W,'left'),0)))/20
        after=float(indent.get(q(W,'end'),indent.get(q(W,'right'),0)))/20
        left=after if rtl else before
        right=before if rtl else after
        outline=val(properties,'outlineLvl')
        return {'rtl':rtl,'alignment':align,'left':left,'right':right,'heading':None if outline is None or int(outline)>5 else int(outline)+1}
    paragraphs=[];colors={};fields=[]
    for part in ['word/document.xml','word/footnotes.xml']:
        if part not in bundle.namelist():continue
        document=ET.fromstring(bundle.read(part));parents={c:p for p in document.iter() for c in p}
        for p in document.iter(q(W,'p')):
            lineage=list(ancestors(p,parents))
            kind='footnote' if part.endswith('footnotes.xml') else ('cell' if any(e.tag==q(W,'tc') for e in lineage) else 'body')
            text=text_of(p)
            paragraphs.append(dict(text=text,kind=kind,**para_style(p)))
            instruction=''.join(e.text or '' for e in p.iter(q(W,'instrText')))
            for simple in p.iter(q(W,'fldSimple')):instruction+=' '+simple.get(q(W,'instr'),'')
            decoded=metadata(instruction)
            if decoded is not None:fields.append({'metadata':decoded,'kind':kind})
            pprops=p.find(q(W,'pPr'));pstyle=pprops.find(q(W,'pStyle')) if pprops is not None else None
            base=style_props(pstyle.get(q(W,'val')) if pstyle is not None else None,'rPr')
            for run in p.iter(q(W,'r')):
                text=text_of(run)
                for marker in expected['colors']:
                    if marker not in text:continue
                    properties=props(run,'rPr',base)
                    highlight=val(properties,'highlight')
                    background=palette.get(highlight)
                    if background is None:
                        background=properties.get(q(W,'shd'),{}).get(q(W,'fill'))
                        if background in ('auto','none'):background=None
                    colors[marker]={'color':val(properties,'color','000000').upper(),'highlight':background.upper() if background else None}
    custom=ET.fromstring(bundle.read('docProps/custom.xml'))
    chunks={int(e.get('name')[12:]):''.join(e.itertext()) for e in custom.findall(q(C,'property')) if (e.get('name') or '').startswith('ZOTERO_PREF_')}
    preferences=json.loads(''.join(chunks[k] for k in sorted(chunks)))
    return paragraphs,colors,fields,preferences

def check_odt(bundle,expected):
    content=ET.fromstring(bundle.read('content.xml'))
    starts=[e.get(q(T,'name')) for e in content.iter(q(T,'reference-mark-start')) if metadata(e.get(q(T,'name'),'')) is not None]
    ends=[e.get(q(T,'name')) for e in content.iter(q(T,'reference-mark-end')) if metadata(e.get(q(T,'name'),'')) is not None]
    if starts!=ends or len(starts)!=2:raise ValueError('Zotero reference-mark pairs are not exactly two balanced ordered ranges')
    style_doc=ET.fromstring(bundle.read('styles.xml'))
    styles={}
    defaults={}
    for document in [style_doc,content]:
        for e in document.iter(q(S,'style')):styles[(e.get(q(S,'family')),e.get(q(S,'name')))]=e
        for e in document.iter(q(S,'default-style')):defaults[e.get(q(S,'family'))]=e
    def style_props(family,name,seen=(),include_defaults=True):
        result={}
        default=defaults.get(family) if include_defaults else None
        if default is not None:
            for child in default:result.update(child.attrib)
        key=(family,name)
        if key not in styles or key in seen:return result
        e=styles[key];parent=e.get(q(S,'parent-style-name'))
        if parent:result.update(style_props(family,parent,seen+(key,),False))
        for child in e:result.update(child.attrib)
        return result
    def para_style(p):
        properties=style_props('paragraph',p.get(q(T,'style-name')))
        rtl=properties.get(q(S,'writing-mode'),'lr-tb')=='rl-tb'
        align=properties.get(q(F,'text-align'),'start')
        align={'start':'right' if rtl else 'left','end':'left' if rtl else 'right'}.get(align,align)
        # ODF 1.4 part 3 20.440 explicitly defines margin-left as the right
        # margin in right-to-left layout. These are logical paragraph margins.
        before=length(properties.get(q(F,'margin-left')))
        after=length(properties.get(q(F,'margin-right')))
        return {'rtl':rtl,'alignment':align,'left':after if rtl else before,'right':before if rtl else after,'heading':int(p.get(q(T,'outline-level'))) if p.tag==q(T,'h') else None}
    parents={c:p for p in content.iter() for c in p};paragraphs=[];colors={};fields=[]
    for p in content.iter():
        if p.tag not in (q(T,'p'),q(T,'h')):continue
        lineage=list(ancestors(p,parents))
        kind='footnote' if any(e.tag==q(T,'note-body') for e in lineage) else ('cell' if any(e.tag==q(TAB,'table-cell') for e in lineage) else 'body')
        paragraphs.append(dict(text=text_of(p,True),kind=kind,**para_style(p)))
        for e in p.iter(q(T,'reference-mark-start')):
            if next((a for a in ancestors(e,parents) if a.tag in (q(T,'p'),q(T,'h'))),None) is not p:continue
            decoded=metadata(e.get(q(T,'name'),''))
            if decoded is not None:fields.append({'metadata':decoded,'kind':kind})
        base=style_props('paragraph',p.get(q(T,'style-name')))
        for node in p.iter():
            chain=[]
            for a in ([] if node is p else ancestors(node,parents)):
                if a is p:break
                if a.tag in (q(T,'p'),q(T,'h')):break
                chain.append(a)
            else:
                if node is not p:continue
            if node is not p and next((a for a in ancestors(node,parents) if a.tag in (q(T,'p'),q(T,'h'))),None) is not p:continue
            for marker in expected['colors']:
                if marker not in (node.text or ''):continue
                properties=dict(base)
                for owner in list(reversed(chain))+[node]:
                    if owner.tag==q(T,'span'):properties.update(style_props('text',owner.get(q(T,'style-name')),include_defaults=False))
                background=properties.get(q(F,'background-color'))
                colors[marker]={'color':properties.get(q(F,'color'),'#000000').lstrip('#').upper(),'highlight':background.lstrip('#').upper() if background and background!='transparent' else None}
    meta=ET.fromstring(bundle.read('meta.xml'))
    chunks={int(e.get(q(M,'name'))[12:]):''.join(e.itertext()) for e in meta.iter(q(M,'user-defined')) if (e.get(q(M,'name')) or '').startswith('ZOTERO_PREF_')}
    preferences=json.loads(''.join(chunks[k] for k in sorted(chunks)))
    return paragraphs,colors,fields,preferences

reports=[]
for directory in ['original','odt-cycle-1','odt-cycle-2','docx-cycle-1','docx-cycle-2']:
    for path in sorted((root/directory).glob('*')):
        if path.suffix not in ('.odt','.docx'):continue
        expected=json.loads((root/'original'/f'{path.stem}.expected.json').read_text())
        if path.suffix=='.odt':expected['preferences']['prefs']['fieldType']='ReferenceMark'
        report={'file':str(path.relative_to(root))}
        try:
            with zipfile.ZipFile(path) as bundle:
                paragraphs,colors,fields,preferences=(check_docx if path.suffix=='.docx' else check_odt)(bundle,expected)
            findings=[];selected={}
            for marker,wanted in expected['paragraphs'].items():
                candidates=[p for p in paragraphs if marker in p['text'] and p['kind']==expected['kind']]
                if len(candidates)!=1:findings.append(f'{marker}: {len(candidates)} paragraph owners')
                else:selected[marker]=candidates[0];check_equal(wanted,candidates[0],marker,findings)
            empty=[p for p in paragraphs if not p['text'] and p['kind']==expected['kind']]
            for wanted in expected['empty']:
                if not any(all((abs(p[k]-v)<0.02 if isinstance(v,(int,float)) and not isinstance(v,bool) else p[k]==v) for k,v in wanted.items()) for p in empty):findings.append('Formatted empty paragraph missing: '+str(wanted))
            check_equal(expected['colors'],colors,'colors',findings)
            check_equal([f['metadata'] for f in expected['fields']],[f['metadata'] for f in fields],'field_metadata',findings)
            if any(f['kind']!=expected['kind'] for f in fields):findings.append('Citation owner changed')
            check_equal(expected['preferences'],preferences,'preferences',findings)
            report.update(status='passed' if not findings else 'different',findings=findings,paragraphs=selected,colors=colors,fields=fields,preferences=preferences)
        except Exception as error:report.update(status='error',error=repr(error))
        reports.append(report)
(root/'xml-results.json').write_text(json.dumps(reports,indent=2,ensure_ascii=False)+'\n')
for report in reports:print(json.dumps({k:v for k,v in report.items() if k in ('file','status','findings','error')},ensure_ascii=False))
