import 'dart:convert';
import 'dart:io';

import 'package:quds_office_engine/quds_office_engine.dart';

const id = 'note-format-converter';
const html =
    '<h2 dir="ltr" data-indent="1" style="text-align:center">'
    '<span style="color:#123456">HEADING</span></h2>'
    '<p dir="rtl" data-indent="2" '
    'style="padding-right:80px;text-align:justify">'
    '<span style="color:rgb(18,52,86);background-color:rgb(250,230,150)">'
    'نص عربي RTL_COLOUR</span> '
    '<a href="https://www.zotero.org/?FIRST1">old first</a></p>'
    '<p dir="ltr" data-indent="1" '
    'style="padding-left:40px;text-align:left">'
    '<span style="color:#246;background-color:#cde">Latin LTR_COLOUR</span> '
    '<a href="https://www.zotero.org/?SECOND2">old second</a></p>'
    '<p dir="ltr" data-indent="3" '
    'style="padding-left:120px;text-align:right"></p>'
    '<p dir="rtl" data-indent="1" '
    'style="padding-right:40px;text-align:center">TAIL</p>';

Object? call(
  WordZoteroCitingSession session,
  String command, [
  List<Object?> args = const [],
]) => session.handle(command, [id, ...args]);

WmlDocument generate(String kind) {
  var paragraph = WmlParagraph(inlines: [WmlRun(text: 'Before chosen After')]);
  final document = WmlDocument(
    sections: [
      WmlSection(
        blocks: [
          if (kind == 'cell')
            WmlTable(
              grid: [320, 100],
              rows: [
                WmlTableRow(
                  cells: [
                    WmlTableCell(width: 320, blocks: [paragraph]),
                    WmlTableCell(
                      width: 100,
                      blocks: [
                        WmlParagraph(inlines: [WmlRun(text: 'Untouched cell')]),
                      ],
                    ),
                  ],
                ),
              ],
            )
          else
            paragraph,
          WmlParagraph(inlines: [WmlRun(text: 'Unrelated body')]),
        ],
      ),
    ],
  );
  final noteType = kind == 'footnote' ? 1 : 0;
  if (noteType == 1) {
    paragraph = WordNotes.editableParagraphs(
      WordNotes.insert(
        document,
        document.paragraphs.last,
        endnote: false,
        text: 'Before chosen After',
      ),
    ).first;
  }
  final session = WordZoteroCitingSession(
    document: document,
    documentId: id,
    insertionParagraph: paragraph,
    insertionOffset: 7,
    insertionEndOffset: 13,
  );
  call(session, 'Document.setDocumentData', [
    jsonEncode({
      'dataVersion': 4,
      'sessionID': id,
      'zoteroVersion': '10.0',
      'style': {
        'styleID': noteType == 1
            ? 'http://www.zotero.org/styles/chicago-note-bibliography'
            : 'http://www.zotero.org/styles/apa',
        'locale': 'ar',
      },
      'prefs': {'fieldType': 'Http', 'noteType': noteType},
    }),
  ]);
  final temporary =
      call(session, 'Document.insertField', ['Http', noteType]) as Map;
  call(session, 'Field.delete', [temporary['id']]);
  call(session, 'Document.insertText', [html]);
  final fields = call(session, 'Document.convertPlaceholdersToFields', [
    ['SECOND2', 'FIRST1'],
    noteType,
    'Http',
  ]) as List;
  for (var i = 0; i < fields.length; i++) {
    final field = fields[i] as Map;
    final citationId = i == 0 ? 'SECOND2' : 'FIRST1';
    final citation = ZoteroCitation(
      citationId: citationId,
      plainCitation: '($citationId)',
      noteIndex: field['noteIndex'] as int,
      items: [
        ZoteroCitationItem.fromCsl(
          itemData: {
            'id': citationId,
            'type': 'book',
            'title': 'Source $citationId',
          },
          uris: [
            'http://zotero.org/users/42/items/${i == 0 ? 'EFGH5678' : 'ABCD1234'}',
          ],
          locator: '12–14',
          label: 'page',
        ),
      ],
    );
    call(session, 'Field.setCode', [
      field['id'],
      'ITEM CSL_CITATION ${jsonEncode(citation.toJson())}',
    ]);
    call(session, 'Field.setText', [field['id'], '<i>($citationId)</i>', true]);
  }
  call(session, 'Document.complete');
  session.apply();
  return document;
}

List<WmlParagraph> story(WmlDocument document, String kind) {
  if (kind == 'footnote')
    return document.footnotes.single.allParagraphs.toList();
  if (kind == 'cell') {
    final table = document.sections.single.blocks.whereType<WmlTable>().single;
    return WordTree.paragraphs(table.rows.single.cells.first.blocks).toList();
  }
  return document.paragraphs.toList();
}

Map<String, Object?> snapshot(WmlDocument document, String kind) {
  final paragraphs = story(document, kind);
  final fields = WordZotero.fields(document);
  final selected = <String, Object?>{};
  for (final key in ['HEADING', 'RTL_COLOUR', 'LTR_COLOUR', 'TAIL']) {
    final p = paragraphs.singleWhere((p) => p.text.contains(key));
    selected[key] = {
      'text': p.text.trim(),
      'rtl': p.properties.rightToLeft,
      'alignment': p.properties.justification.name,
      'left': p.properties.indent.left,
      'right': p.properties.indent.right,
      'heading': p.properties.headingLevel,
    };
  }
  final empty = paragraphs.where((p) => p.text.isEmpty).toList();
  final colors = <String, Object?>{};
  for (final key in ['HEADING', 'RTL_COLOUR', 'LTR_COLOUR']) {
    final r = paragraphs
        .expand((p) => p.inlines)
        .whereType<WmlRun>()
        .singleWhere((r) => r.text.contains(key));
    colors[key] = {
      'color': r.properties.color,
      'highlight': r.properties.highlight,
    };
  }
  final data = jsonDecode(WordZoteroDocumentData.read(document));
  return {
    'kind': kind,
    'paragraphs': selected,
    'text': paragraphs.map((p) => p.text.trim()).toList(),
    'empty': empty
        .map(
          (p) => {
            'rtl': p.properties.rightToLeft,
            'alignment': p.properties.justification.name,
            'left': p.properties.indent.left,
            'right': p.properties.indent.right,
          },
        )
        .toList(),
    'colors': colors,
    'fields': fields
        .map(
          (f) => {
            'metadata': f.citation!.toJson(),
            'text': f.cachedText,
            'editable': f.canEdit,
            'in_target_story': paragraphs.contains(f.paragraph),
          },
        )
        .toList(),
    'preferences': data,
    'balanced': WordFieldSpans.unbalanced(document).isEmpty,
  };
}

void compare(
  Object? expected,
  Object? actual,
  String path,
  List<String> findings,
) {
  if (expected is Map && actual is Map) {
    for (final key in expected.keys)
      compare(expected[key], actual[key], '$path/$key', findings);
  } else if (expected is List && actual is List) {
    if (expected.length != actual.length)
      findings.add(
        '$path length ${actual.length}, expected ${expected.length}',
      );
    for (var i = 0; i < expected.length && i < actual.length; i++)
      compare(expected[i], actual[i], '$path/$i', findings);
  } else if (expected is num && actual is num) {
    if ((expected - actual).abs() > 0.02)
      findings.add('$path=$actual, expected $expected');
  } else if (expected != actual) {
    findings.add('$path=$actual, expected $expected');
  }
}

Future<void> main(List<String> args) async {
  if (args.first == 'generate') {
    final directory = Directory(args[1])..createSync(recursive: true);
    for (final kind in ['body', 'footnote', 'cell']) {
      final document = generate(kind);
      final expected = snapshot(document, kind);
      File('${directory.path}/$kind.expected.json').writeAsStringSync(
        '${const JsonEncoder.withIndent('  ').convert(expected)}\n',
      );
      File('${directory.path}/$kind.docx')
          .writeAsBytesSync(WordSerializer().writeBytes(document));
      File(
        '${directory.path}/$kind.odt',
      ).writeAsBytesSync(OdtDocumentWriter.writeEditableZoteroBytes(document));
      print(jsonEncode({'generated': kind}));
    }
    return;
  }
  final input = File(args[1]);
  final expected = jsonDecode(File(args[2]).readAsStringSync()) as Map;
  final report = <String, Object?>{'file': args[1], 'kind': expected['kind']};
  try {
    final document = input.path.endsWith('.odt')
        ? await OdtDocumentReader.readBytes(input.readAsBytesSync())
        : WordDeserializer().readBytes(input.readAsBytesSync());
    final actual = snapshot(document, expected['kind'] as String);
    final findings = <String>[];
    compare(expected, actual, '', findings);
    report.addAll({
      'status': findings.isEmpty ? 'passed' : 'different',
      'findings': findings,
      'actual': actual,
    });
  } catch (error, stack) {
    report.addAll({'status': 'refused', 'error': '$error', 'stack': '$stack'});
  }
  print(const JsonEncoder.withIndent('  ').convert(report));
}
