from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,subprocess,time

root=Path(__file__).resolve().parent
soffice='/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice'
results=[]
for extension,filter_name in [('odt','writer8'),('docx','Office Open XML Text')]:
    inputs=root/'original'
    for cycle in (1,2):
        output=root/f'{extension}-cycle-{cycle}'
        output.mkdir(exist_ok=True)
        profile=root/f'profile-{extension}-{cycle}'
        command=[soffice,f'-env:UserInstallation={profile.as_uri()}','--headless','--convert-to',f'{extension}:{filter_name}','--outdir',str(output),*[str(inputs/f'{kind}.{extension}') for kind in ['body','footnote','cell']]]
        started=time.time()
        completed=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
        log=root/f'{extension}-cycle-{cycle}.log'
        log.write_bytes(completed.stdout)
        expected=[output/f'{kind}.{extension}' for kind in ['body','footnote','cell']]
        results.append({'command':command,'exit_code':completed.returncode,'seconds':time.time()-started,'log':log.name,'outputs':[{'file':str(p.relative_to(root)),'exists':p.exists(),'bytes':p.stat().st_size if p.exists() else 0} for p in expected]})
        print(json.dumps(results[-1]),flush=True)
        if completed.returncode or not all(p.exists() for p in expected):break
        inputs=output
(root/'conversion-results.json').write_text(json.dumps(results,indent=2)+'\n')
