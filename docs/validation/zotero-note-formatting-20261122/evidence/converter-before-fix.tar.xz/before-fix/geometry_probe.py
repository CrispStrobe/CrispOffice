from pathlib import Path
import subprocess,json
import fitz
root=Path(__file__).resolve().parent
soffice='/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice'
reports=[]
for label,source in [('original-docx','original/body.docx'),('original-odt','original/body.odt'),('cycle-docx','docx-cycle-2/body.docx')]:
 output=root/'pdf-probe'/label;output.mkdir(parents=True,exist_ok=True)
 cmd=[soffice,'--headless',f'-env:UserInstallation={root.as_uri()}/profile-pdf-{label}','--convert-to','pdf','--outdir',str(output),str(root/source)]
 result=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
 record={'label':label,'source':source,'command':cmd,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
 pdf=output/'body.pdf'
 if pdf.exists():
  doc=fitz.open(pdf)
  record['page_rect']=list(doc[0].rect)
  record['markers']={marker:[list(r) for page in doc for r in page.search_for(marker)] for marker in ['HEADING','TAIL','LTR_COLOUR','RTL_COLOUR','Before']}
 reports.append(record)
(root/'geometry-results.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports,indent=2))
