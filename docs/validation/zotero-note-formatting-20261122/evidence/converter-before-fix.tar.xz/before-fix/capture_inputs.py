from pathlib import Path
import hashlib,json,sys

root=Path('/workspace/scratch/eba1aedcc131')
repo=root/'quds_office_suite'
runtime=root/'toolchains'
files=[]
for base in [repo/'packages/quds_office_engine/lib',repo/'packages/legacy_doc_parser/lib',runtime/'pub-cache/hosted/pub.dev',runtime/'flutter/bin/cache/dart-sdk/lib',runtime/'flutter/bin/cache/dart-sdk/bin']:
    files.extend(p for p in base.rglob('*') if p.is_file())
files += [repo/'pubspec.yaml',repo/'pubspec.lock',repo/'.dart_tool/package_config.json',repo/'packages/quds_office_engine/pubspec.yaml',repo/'packages/legacy_doc_parser/pubspec.yaml',Path(__file__).resolve().parent/'fixture.dart']
result={}
for path in sorted(set(files)):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024*1024),b''):digest.update(block)
    result[str(path.relative_to(root))]={'bytes':path.stat().st_size,'sha256':digest.hexdigest()}
target=Path(__file__).resolve().parent/sys.argv[1]
target.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'file':str(target),'inputs':len(result)}))
