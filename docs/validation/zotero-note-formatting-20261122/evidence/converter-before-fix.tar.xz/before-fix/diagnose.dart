import 'dart:convert';
import 'dart:io';
import 'package:quds_office_engine/quds_office_engine.dart';

void main(List<String> args) {
  final document = WordDeserializer().readBytes(File(args.single).readAsBytesSync());
  final fields = WordZotero.fields(document);
  print(const JsonEncoder.withIndent('  ').convert({
    'file': args.single,
    'fields': [for (final field in fields) {
      'id': field.citation?.citationId,
      'valid': field.isValid,
      'editable': field.canEdit,
      'native_editable': field.canEditNativeResult,
      'locked': field.locked,
      'nested': field.nested,
      'opaque_metadata': field.opaqueMetadata,
      'paragraph_count': field.paragraphs.length,
      'boundaries': [for (final boundary in field.paragraph.inlines.whereType<WmlFieldBoundary>()) {
        'kind': boundary.kind.name,
        'source_xml': boundary.sourceXml,
        'run_properties_xml': boundary.runPropertiesXml,
      }],
    }],
  }));
}
