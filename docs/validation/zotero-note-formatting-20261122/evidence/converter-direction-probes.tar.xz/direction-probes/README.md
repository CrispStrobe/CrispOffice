# Direction semantics probes

These are separately named interoperability probes for the actual installed LibreOffice converter, not replacements for the three main note-format fixtures.

`alignment_probe.py` produces the eight combinations of paragraph bidi=false/true and jc=left/right/start/end without indentation, then records PDF bounding boxes. They establish the logical direction-dependent interpretation of all four justification names.

`indent_alias_probe.py` tests contradictory left/start and right/end aliases (30 pt versus 60 pt), in both XML attribute orders and both directions. The PDF centers show that this LibreOffice build uses the legacy alias in every combination. The observation is specific to this consumer; the cited specification sections do not define conflicting-alias precedence.

`source-notes.json` contains primary specification references with paraphrases, and `converter-version.txt` identifies the exact development build. The original/generated DOCX, actual PDFs, and exact commands/results are preserved. No production source was changed for these probes.
