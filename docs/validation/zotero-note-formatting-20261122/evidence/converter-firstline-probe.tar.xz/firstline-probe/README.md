# First-line and hanging indent inheritance probe

This separately named raw-OOXML probe resolves a concrete paragraph-formatting IO question for the exact installed LibreOffice converter. It does not replace any of the three primary Zotero fixtures.

Each paragraph has two short lines so the measured first-line x position minus the continuation-line x position isolates its first-line offset. Paragraph styles supply either hanging=180 (9 pt) or firstLine=240 (12 pt). Direct firstLine=0 or hanging=0 clears the opposite inherited value. A direct nonzero firstLine or hanging replaces the opposite inherited value. The controls verify the style values themselves.

The two additional same-node cases show a consumer-specific trap: firstLine=240+hanging=0 gives +12 pt, whereas firstLine=0+hanging=180 gives 0 pt in this build. This is a result from the retained input and PDF; it should not be generalized to every application or arbitrary attribute combination.

The source generator, exact command, input DOCX, actual PDF, raw bounding boxes, and converter version are preserved. No production code was modified for this probe.
