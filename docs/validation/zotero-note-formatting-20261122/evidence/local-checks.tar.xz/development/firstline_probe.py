import zipfile,xml.etree.ElementTree as ET,subprocess,json
from pathlib import Path
import fitz
root=Path('/workspace/scratch/eba1aedcc131/validation/firstline-semantics-probe');root.mkdir(exist_ok=True)
source=Path('/workspace/scratch/eba1aedcc131/validation/converter/original/body.docx')
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main';Q=lambda n:'{'+W+'}'+n
ET.register_namespace('w',W)
cases=[('BASE_HANG','ProbeHanging',{}),('BASE_FIRST','ProbeFirstLine',{}),('HANG_FIRST_ZERO','ProbeHanging',{'firstLine':'0'}),('FIRST_HANG_ZERO','ProbeFirstLine',{'hanging':'0'}),('HANG_FIRST_240','ProbeHanging',{'firstLine':'240'}),('HANG_FIRST_240_RESET','ProbeHanging',{'firstLine':'240','hanging':'0'}),('FIRST_HANG_180','ProbeFirstLine',{'hanging':'180'}),('FIRST_HANG_180_RESET','ProbeFirstLine',{'firstLine':'0','hanging':'180'})]
with zipfile.ZipFile(source) as z:
 document=ET.fromstring(z.read('word/document.xml'));body=document.find(Q('body'));sect=body.find(Q('sectPr'))
 for child in list(body):body.remove(child)
 styles=ET.fromstring(z.read('word/styles.xml'))
 for name,attr,value in [('ProbeHanging','hanging','180'),('ProbeFirstLine','firstLine','240')]:
  style=ET.SubElement(styles,Q('style'),{Q('type'):'paragraph',Q('styleId'):name})
  ET.SubElement(style,Q('name'),{Q('val'):name});pp=ET.SubElement(style,Q('pPr'))
  ET.SubElement(pp,Q('ind'),{Q('left'):'720',Q(attr):value})
 for label,sty,attrs in cases:
  p=ET.SubElement(body,Q('p'));pp=ET.SubElement(p,Q('pPr'))
  ET.SubElement(pp,Q('pStyle'),{Q('val'):sty});ET.SubElement(pp,Q('bidi'),{Q('val'):'0'})
  if attrs:ET.SubElement(pp,Q('ind'),{Q(k):v for k,v in attrs.items()})
  r=ET.SubElement(p,Q('r'));ET.SubElement(r,Q('t')).text=label+'_FIRST'
  ET.SubElement(r,Q('br'));ET.SubElement(r,Q('t')).text=label+'_NEXT'
 body.append(sect)
 with zipfile.ZipFile(root/'firstline.docx','w',zipfile.ZIP_DEFLATED) as out:
  for name in z.namelist():out.writestr(name,ET.tostring(document) if name=='word/document.xml' else ET.tostring(styles) if name=='word/styles.xml' else z.read(name))
soffice='/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice'
cmd=[soffice,'--headless',f'-env:UserInstallation={root.as_uri()}/profile','--convert-to','pdf','--outdir',str(root),str(root/'firstline.docx')]
r=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
report={'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'cases':[]}
doc=fitz.open(root/'firstline.pdf')
for label,sty,attrs in cases:
 rects={suffix:[list(rect) for page in doc for rect in page.search_for(label+'_'+suffix)] for suffix in ('FIRST','NEXT')}
 report['cases'].append({'label':label,'style':sty,'direct':attrs,'rectangles':rects,'first_line_minus_next_x':rects['FIRST'][0][0]-rects['NEXT'][0][0]})
(root/'results.json').write_text(json.dumps(report,indent=2)+'\n')
for case in report['cases']:print(json.dumps({k:case[k] for k in ['label','style','direct','first_line_minus_next_x']}))
