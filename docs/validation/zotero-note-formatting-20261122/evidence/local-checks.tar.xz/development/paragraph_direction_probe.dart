import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';

void main() {
  final reports = <Map<String, Object?>>[];
  for (final direction in ['', ' dir="ltr"', ' dir="rtl"']) {
    final document = WmlDocument.empty();
    final session = WordZoteroCitingSession(
      document: document,
      documentId: 'probe',
      insertionParagraph: document.paragraphs.first,
    );
    session.handle('Document.insertText', [
      'probe',
      '<p$direction style="text-align:right">ABC (123) مرحبا</p>',
    ]);
    session.handle('Document.complete', ['probe']);
    session.apply();
    final paragraph = document.paragraphs.single;
    final line = WordLayoutEngine(font: null).layout(document).pages.first.lines.first;
    reports.add({
      'direction': direction,
      'rightToLeft': paragraph.properties.rightToLeft,
      'baseLevel': paragraph.properties.bidiBaseLevel,
      'visualCodePoints': line.glyphs.map((g) => g.glyph.codePoint).toList(),
      'visualText': String.fromCharCodes(line.glyphs.map((g) => g.glyph.codePoint)),
    });
  }
  print(jsonEncode(reports));
}
