import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';

OpcPackage fixture(String properties, String styles) {
  final package=OpcPackage.openBytes((DocxDocumentBuilder()..paragraph('probe')).build());
  package.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="${OfficeNamespaces.w}"><w:body><w:p><w:pPr>$properties</w:pPr><w:r><w:t>probe</w:t></w:r></w:p><w:sectPr/></w:body></w:document>');
  package.getPart('/word/styles.xml')!.writeText('<w:styles xmlns:w="${OfficeNamespaces.w}">$styles</w:styles>');
  return package;
}
Map<String,Object?> values(WmlParagraph p)=>{'rtl':p.properties.rightToLeft,'left':p.properties.indent.left,'right':p.properties.indent.right,'firstLine':p.properties.indent.firstLine,'hanging':p.properties.indent.hanging,'justification':p.properties.justification.name};
void main() {
 final reset=WordDeserializer().read(fixture('<w:pStyle w:val="Base"/>','<w:style w:type="paragraph" w:styleId="Base"><w:pPr><w:bidi/><w:ind w:left="1200" w:right="300" w:firstLine="240"/></w:pPr></w:style>'));
 reset.paragraphs.single.properties.indent=reset.paragraphs.single.properties.indent.copyWith(firstLine:0,hanging:0);
 final resetSaved=WordSerializer().write(reset);
 print(jsonEncode({'probe':'inherited-firstline-reset','beforeSave':values(reset.paragraphs.single),'afterReopen':values(WordDeserializer().readBytes(resetSaved.save()).paragraphs.single),'documentXml':resetSaved.getPart('/word/document.xml')!.readText()}));
 final changed=WordDeserializer().read(fixture('<w:pStyle w:val="Derived"/>','<w:style w:type="paragraph" w:styleId="Base"><w:pPr><w:bidi/></w:pPr></w:style><w:style w:type="paragraph" w:styleId="Derived"><w:basedOn w:val="Base"/><w:pPr><w:ind w:left="900" w:right="240"/><w:jc w:val="start"/></w:pPr></w:style>'));
 final index=changed.styles.indexWhere((s)=>s.id=='Derived');
 final s=changed.styles[index];
 changed.styles[index]=WmlStyle(id:s.id,name:s.name,nameAr:s.nameAr,headingLevel:s.headingLevel,justification:s.justification,bold:s.bold,italic:s.italic,fontSizePoints:14,color:s.color,spacingBefore:s.spacingBefore,spacingAfter:s.spacingAfter,font:s.font,csFont:s.csFont,basedOn:s.basedOn,numId:s.numId,ilvl:s.ilvl,indent:s.indent);
 final saved=WordSerializer().write(changed);
 print(jsonEncode({'probe':'derived-rtl-font-size-style-edit','beforeSave':values(changed.paragraphs.single),'afterReopen':values(WordDeserializer().readBytes(saved.save()).paragraphs.single),'stylesXml':saved.getPart('/word/styles.xml')!.readText()}));
}
