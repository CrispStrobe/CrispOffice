import zipfile,xml.etree.ElementTree as ET,subprocess,json
from pathlib import Path
import fitz
root=Path('/workspace/scratch/eba1aedcc131/validation/direction-semantics-probe')
source=Path('/workspace/scratch/eba1aedcc131/validation/converter/original/body.docx')
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main';Q=lambda n:'{'+W+'}'+n
ET.register_namespace('w',W)
labels=[]
with zipfile.ZipFile(source) as z:
 document=ET.fromstring(z.read('word/document.xml'));body=document.find(Q('body'));sect=body.find(Q('sectPr'))
 for child in list(body):body.remove(child)
 for rtl in (False,True):
  for side,logical in [('left','start'),('right','end')]:
   for reverse in (False,True):
    label=f'{side.upper()}_{"REV" if reverse else "FWD"}_{"RTL" if rtl else "LTR"}';labels.append(label)
    p=ET.SubElement(body,Q('p'));pp=ET.SubElement(p,Q('pPr'))
    ET.SubElement(pp,Q('bidi'),{Q('val'):'1' if rtl else '0'})
    ET.SubElement(pp,Q('jc'),{Q('val'):'center'})
    attrs=[(Q(side),'600'),(Q(logical),'1200')]
    if reverse:attrs.reverse()
    ET.SubElement(pp,Q('ind'),dict(attrs))
    r=ET.SubElement(p,Q('r'));t=ET.SubElement(r,Q('t'));t.text=label
 body.append(sect)
 with zipfile.ZipFile(root/'indent-alias.docx','w',zipfile.ZIP_DEFLATED) as out:
  for name in z.namelist():out.writestr(name,ET.tostring(document) if name=='word/document.xml' else z.read(name))
soffice='/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice'
cmd=[soffice,'--headless',f'-env:UserInstallation={root.as_uri()}/profile-alias','--convert-to','pdf','--outdir',str(root),str(root/'indent-alias.docx')]
r=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
report={'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
doc=fitz.open(root/'indent-alias.pdf')
report['markers']={label:[{'rect':list(rect),'center_x':(rect.x0+rect.x1)/2} for page in doc for rect in page.search_for(label)] for label in labels}
(root/'indent-alias-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
