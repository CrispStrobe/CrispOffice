#!/usr/bin/env python3
"""Final formatting/static gate only; no tests or checkout modifications."""
import concurrent.futures
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
ROOT = Path('/workspace/scratch/eba1aedcc131/quds_office_suite')
OUT = Path('/workspace/scratch/eba1aedcc131/validation/final')
EXPECTED = '6f74d11b857deaa43981e8a7eb72157cd6bd518e'
ACTIVATION = Path('/workspace/scratch/eba1aedcc131/toolchains/env.sh')
RUNNER = ROOT / 'docs/validation/zotero-note-formatting-20261122/run_checks.py'
prior = json.loads((OUT / 'static-checks.json').read_text())
files = prior['changed_dart_files']
pins = prior['pin_and_lock_paths']

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

spec = importlib.util.spec_from_file_location('input_manifest_only', RUNNER)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
index = Path(git('rev-parse', '--git-path', 'index'))
if not index.is_absolute():
    index = ROOT / index

def snapshot(label):
    inputs = runner.inputs()
    pending = git('status', '--porcelain=v1')
    statuses = pending.splitlines()
    source_status = [line for line in statuses if not line[3:].startswith('docs/')]
    doc_status = [line for line in statuses if line[3:].startswith('docs/')]
    value = {
        'utc': now(), 'head': git('rev-parse', 'HEAD'),
        'tree': git('rev-parse', 'HEAD^{tree}'),
        'index_sha256': sha(index), 'working_tree_status': statuses,
        'documentation_status': doc_status, 'non_documentation_status': source_status,
        'changed_dart_sha256': {p: sha(ROOT / p) for p in files},
        'pins_sha256': {p: sha(ROOT / p) for p in pins},
        'resolution_sha256': {p: sha(ROOT / p) for p in ['.dart_tool/package_config.json', '.dart_tool/package_graph.json'] if (ROOT / p).is_file()},
        'activation_sha256': sha(ACTIVATION), 'runner_sha256': sha(RUNNER),
        'input_count': len(inputs),
        'inputs_sha256': hashlib.sha256(json.dumps(inputs, sort_keys=True).encode()).hexdigest(),
    }
    (OUT / f'static-final-inputs-{label}.json').write_text(json.dumps(inputs, indent=2) + '\n')
    (OUT / f'static-final-state-{label}.json').write_text(json.dumps(value, indent=2) + '\n')
    return value, inputs

before, inputs_before = snapshot('before')
if before['head'] != EXPECTED or before['non_documentation_status']:
    raise SystemExit(f'Unexpected source precondition: {before["head"]}, {before["non_documentation_status"]}')
current_changed = subprocess.check_output(
    ['git', 'diff', '--name-only', '--diff-filter=ACMR', '-z', prior['initial_main'], EXPECTED, '--', '*.dart'], cwd=ROOT,
).decode().strip('\0').split('\0')
same_files = current_changed == files
if not same_files:
    raise SystemExit('Changed Dart file set differs from the frozen 70-file scope')
dart = shutil.which('dart')
commands = {
    'analysis': [dart, 'analyze', '--fatal-infos', '--fatal-warnings', *files],
    'format': [dart, 'format', '--output=none', '--set-exit-if-changed', *files],
}

def run(name, command):
    stdout = OUT / f'static-final-{name}.stdout.log'
    stderr = OUT / f'static-final-{name}.stderr.log'
    receipt = {'argv': command, 'shell_command': shlex.join(command),
        'activation': f'source {shlex.quote(str(ACTIVATION))}', 'cwd': str(ROOT),
        'started_utc': now(), 'started_unix': time.time(),
        'stdout_path': str(stdout), 'stderr_path': str(stderr)}
    with stdout.open('w') as sout, stderr.open('w') as serr:
        try:
            result = subprocess.run(command, cwd=ROOT, stdout=sout, stderr=serr, timeout=900)
            receipt['exit_code'] = result.returncode
        except subprocess.TimeoutExpired:
            receipt.update({'exit_code': 124, 'timed_out': True})
    receipt.update({'finished_utc': now(), 'finished_unix': time.time(),
        'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr)})
    (OUT / f'static-final-{name}.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'check': name, 'exit_code': receipt['exit_code']}), flush=True)
    return receipt

results = {}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    tasks = {pool.submit(run, name, command): name for name, command in commands.items()}
    for task in concurrent.futures.as_completed(tasks):
        results[tasks[task]] = task.result()

after, inputs_after = snapshot('after')
changes = [p for p in sorted(inputs_before.keys() | inputs_after.keys()) if inputs_before.get(p) != inputs_after.get(p)]
checks = {
    'same_70_file_scope': same_files and len(files) == 70,
    'head_unchanged': before['head'] == after['head'] == EXPECTED,
    'tree_unchanged': before['tree'] == after['tree'],
    'index_unchanged': before['index_sha256'] == after['index_sha256'],
    'source_working_tree_clean_before_after': not before['non_documentation_status'] and not after['non_documentation_status'],
    'source_inputs_unchanged': not changes,
    'pins_and_locks_unchanged': before['pins_sha256'] == after['pins_sha256'],
    'resolution_unchanged': before['resolution_sha256'] == after['resolution_sha256'],
    'activation_unchanged': before['activation_sha256'] == after['activation_sha256'],
    'runner_unchanged': before['runner_sha256'] == after['runner_sha256'],
}
report = {
    'task': 'final required formatting and strict-analysis gate only',
    'expected_source_commit': EXPECTED, 'initial_main': prior['initial_main'],
    'prior_receipt_retained': str(OUT / 'static-checks.json'),
    'prior_receipt_sha256': sha(OUT / 'static-checks.json'),
    'formatter_normalization_proof': str(OUT / 'formatter-normalization/receipt.json'),
    'changed_dart_count': len(files), 'changed_dart_files': files,
    'commands': results, 'before': before, 'after': after,
    'invariants': checks, 'changed_inputs': changes,
    'documentation_note': 'Parent may edit documentation/evidence concurrently. Documentation working-tree changes are recorded independently and excluded from source instability.',
    'tests_run': False, 'source_edits_made': False, 'remote_queries_made': False,
    'accepted': all(checks.values()) and all(result['exit_code'] == 0 for result in results.values()),
}
(OUT / 'static-checks-final.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'accepted': report['accepted'], 'invariants': checks, 'source_changes': changes,
    'documentation_changes_before': len(before['documentation_status']),
    'documentation_changes_after': len(after['documentation_status']),
    'report': str(OUT / 'static-checks-final.json')}), flush=True)
raise SystemExit(0 if report['accepted'] else 1)
