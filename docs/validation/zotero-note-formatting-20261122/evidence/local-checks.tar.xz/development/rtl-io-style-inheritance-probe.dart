import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'rtl-io-review-probe.dart' as probe;

WmlStyle replace(WmlStyle s, {String? basedOn})=>WmlStyle(id:s.id,name:s.name,nameAr:s.nameAr,headingLevel:s.headingLevel,justification:s.justification,bold:s.bold,italic:s.italic,fontSizePoints:14,color:s.color,spacingBefore:s.spacingBefore,spacingAfter:s.spacingAfter,font:s.font,csFont:s.csFont,basedOn:basedOn??s.basedOn,numId:s.numId,ilvl:s.ilvl,indent:s.indent);
void main() {
 final document=WordDeserializer().read(probe.fixture('<w:pStyle w:val="Derived"/>','<w:style w:type="paragraph" w:styleId="BaseRTL"><w:pPr><w:bidi/><w:ind w:left="1000" w:right="300"/></w:pPr></w:style><w:style w:type="paragraph" w:styleId="BaseLTR"><w:pPr><w:bidi w:val="0"/><w:ind w:left="700" w:right="400"/></w:pPr></w:style><w:style w:type="paragraph" w:styleId="Derived"><w:basedOn w:val="BaseRTL"/><w:pPr><w:ind w:left="900"/><w:jc w:val="start"/></w:pPr></w:style>'));
 final index=document.styles.indexWhere((s)=>s.id=='Derived');document.styles[index]=replace(document.styles[index],basedOn:'BaseLTR');
 final saved=WordSerializer().write(document);
 print(jsonEncode({'probe':'partial-indent-base-change','afterReopen':probe.values(WordDeserializer().readBytes(saved.save()).paragraphs.single),'stylesXml':saved.getPart('/word/styles.xml')!.readText()}));
 final foreign=WordDeserializer().read(probe.fixture('<w:pStyle w:val="Derived"/>','<e:style xmlns:e="urn:example:opaque" e:styleId="Derived"><e:payload>keep me</e:payload></e:style><w:style w:type="paragraph" w:styleId="Derived"><w:pPr><w:bidi/><w:ind w:left="900" w:right="240"/><w:jc w:val="start"/></w:pPr></w:style>'));
 final at=foreign.styles.indexWhere((s)=>s.id=='Derived');foreign.styles[at]=replace(foreign.styles[at]);
 final output=WordSerializer().write(foreign);
 print(jsonEncode({'probe':'foreign-style-id-collision','stylesXml':output.getPart('/word/styles.xml')!.readText()}));
}
