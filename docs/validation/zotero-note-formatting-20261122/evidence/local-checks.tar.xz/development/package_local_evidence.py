"""Package source-bound local reporters and review evidence, excluding checkouts."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent / 'quds_office_suite'
DEST = ROOT / 'docs/validation/zotero-note-formatting-20261122/evidence'


def main():
    selected = {}
    suffixes = {'.json', '.jsonl', '.stderr', '.stdout', '.log', '.txt', '.md', '.dart', '.py', '.tsv'}
    for path in BASE.iterdir():
        if path.is_file() and path.suffix in suffixes:
            selected['development/' + path.name] = path
    final = BASE / 'final'
    for path in final.rglob('*'):
        if path.is_file():
            selected['final/' + path.relative_to(final).as_posix()] = path
    for label, directory in [
        ('golden-initial-main', BASE / 'baseline-main-3f3cb850/packages/quds_office_editor/test/failures'),
        ('golden-targeted-update', BASE / 'color-fidelity-after'),
    ]:
        for path in directory.glob('office_fidelity_word_*.png'):
            selected[label + '/' + path.name] = path
    for name in ['paragraph-review-test.jsonl', 'paragraph-review-test.stderr']:
        path = BASE.parent / name
        if path.is_file():
            selected['development/' + name] = path
    for path in (BASE.parent / 'toolchains/logs').glob('*.log'):
        selected['runtime/' + path.name] = path
    index = {
        'scope': 'Final frozen-source tests plus separately labeled development, incoming-head and review evidence; repeated runs are not additive.',
        'members': {
            name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
            for name, path in sorted(selected.items())
        },
    }
    DEST.mkdir(exist_ok=True)
    index_bytes = (json.dumps(index, indent=2) + '\n').encode()
    index_path = DEST / 'local-checks-index.json'
    index_path.write_bytes(index_bytes)
    archive = DEST / 'local-checks.tar.xz'
    with tarfile.open(archive, 'w:xz', preset=9) as output:
        for name, path in sorted(selected.items()):
            data = path.read_bytes()
            item = tarfile.TarInfo(name)
            item.size, item.mtime, item.mode = len(data), 0, 0o644
            output.addfile(item, io.BytesIO(data))
        item = tarfile.TarInfo('INDEX.json')
        item.size, item.mtime, item.mode = len(index_bytes), 0, 0o644
        output.addfile(item, io.BytesIO(index_bytes))
    print(json.dumps({'archive': str(archive), 'members': len(selected) + 1, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
