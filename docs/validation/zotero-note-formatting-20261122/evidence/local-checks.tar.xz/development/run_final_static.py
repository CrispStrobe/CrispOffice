#!/usr/bin/env python3
"""Read-only frozen-source acceptance; all outputs live outside the checkout."""
import concurrent.futures
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/eba1aedcc131/quds_office_suite')
OUT = Path('/workspace/scratch/eba1aedcc131/validation/final')
BASE = '3f3cb8508663dde917e913867908dbfd6c3efcf0'
EXPECTED = 'd68df6d625d7f81163c502ed46dcfd97a806e95a'
RUNNER = ROOT / 'docs/validation/zotero-note-formatting-20261122/run_checks.py'
ACTIVATION = Path('/workspace/scratch/eba1aedcc131/toolchains/env.sh')
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
OUT.mkdir(parents=True, exist_ok=True)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

spec = importlib.util.spec_from_file_location('frozen_acceptance_runner', RUNNER)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)

changed = subprocess.check_output(
    ['git', 'diff', '--name-only', '--diff-filter=ACMR', '-z', BASE, EXPECTED, '--', '*.dart'],
    cwd=ROOT,
).decode().strip('\0').split('\0')
changed = [p for p in changed if p]
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
pins = sorted({
    p for p in tracked if p and (
        p in {'.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'}
        or (p.startswith(('packages/', 'apps/', 'third_party/'))
            and '/doc/' not in p and '/docs/' not in p
            and Path(p).name in {'pubspec.yaml', 'pubspec.lock', 'Cargo.lock', 'rust-toolchain.toml', 'Podfile.lock'})
    )
})
index = Path(git('rev-parse', '--git-path', 'index'))
if not index.is_absolute():
    index = ROOT / index

def snapshot(label):
    inputs = runner.inputs()
    inputs[str(RUNNER.relative_to(ROOT))] = sha(RUNNER)
    value = {
        'utc': now(),
        'head': git('rev-parse', 'HEAD'),
        'tree': git('rev-parse', 'HEAD^{tree}'),
        'status': git('status', '--porcelain=v1'),
        'index_sha256': sha(index),
        'changed_dart_sha256': {p: sha(ROOT / p) for p in changed},
        'pins_sha256': {p: sha(ROOT / p) for p in pins},
        'resolution_sha256': {p: sha(ROOT / p) for p in ['.dart_tool/package_config.json', '.dart_tool/package_graph.json'] if (ROOT / p).exists()},
        'runner_sha256': sha(RUNNER),
        'activation_sha256': sha(ACTIVATION),
        'input_count': len(inputs),
        'inputs_sha256': hashlib.sha256(json.dumps(inputs, sort_keys=True).encode()).hexdigest(),
    }
    (OUT / f'static-inputs-{label}.json').write_text(json.dumps(inputs, indent=2) + '\n')
    (OUT / f'static-state-{label}.json').write_text(json.dumps(value, indent=2) + '\n')
    return value, inputs

before, before_inputs = snapshot('before')
if before['head'] != EXPECTED or before['status']:
    raise SystemExit(f'Frozen source precondition failed: {before["head"]} {before["status"]!r}')

dart = shutil.which('dart')
flutter = shutil.which('flutter')
if not dart or not flutter:
    raise SystemExit('Activate the pinned runtime before this script')

commands = {
    'studio': [sys.executable, str(RUNNER), '--cohort', 'studio', '--output', str(OUT)],
    'analysis': [dart, 'analyze', '--fatal-infos', '--fatal-warnings', *changed],
    'format': [dart, 'format', '--output=none', '--set-exit-if-changed', *changed],
}

def run(name, command):
    stdout = OUT / f'static-{name}.stdout.log'
    stderr = OUT / f'static-{name}.stderr.log'
    result = {
        'name': name, 'argv': command, 'cwd': str(ROOT),
        'shell_activation': f'source {shlex.quote(str(ACTIVATION))}',
        'shell_command': shlex.join(command),
        'started_utc': now(), 'started_unix': time.time(),
        'stdout_path': str(stdout), 'stderr_path': str(stderr),
    }
    with stdout.open('w') as sout, stderr.open('w') as serr:
        try:
            process = subprocess.run(command, cwd=ROOT, stdout=sout, stderr=serr, timeout=900)
            result['exit_code'] = process.returncode
        except subprocess.TimeoutExpired:
            result.update({'exit_code': 124, 'timed_out': True})
    result.update({
        'finished_utc': now(), 'finished_unix': time.time(),
        'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr),
    })
    (OUT / f'static-{name}.receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'check': name, 'exit_code': result['exit_code'], 'stdout': str(stdout), 'stderr': str(stderr)}), flush=True)
    return result

results = {}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    pending = {pool.submit(run, name, command): name for name, command in commands.items()}
    for future in concurrent.futures.as_completed(pending):
        results[pending[future]] = future.result()

after, after_inputs = snapshot('after')
changed_inputs = [p for p in sorted(before_inputs.keys() | after_inputs.keys()) if before_inputs.get(p) != after_inputs.get(p)]
pin_diff = git('diff', '--name-only', BASE, EXPECTED, '--', *pins)
checks = {
    'head_unchanged': before['head'] == after['head'] == EXPECTED,
    'tree_unchanged': before['tree'] == after['tree'],
    'working_tree_clean_before_after': before['status'] == after['status'] == '',
    'index_unchanged': before['index_sha256'] == after['index_sha256'],
    'source_inputs_unchanged': not changed_inputs,
    'pins_and_locks_unchanged': before['pins_sha256'] == after['pins_sha256'],
    'resolution_unchanged': before['resolution_sha256'] == after['resolution_sha256'],
    'activation_unchanged': before['activation_sha256'] == after['activation_sha256'],
    'runner_unchanged': before['runner_sha256'] == after['runner_sha256'],
}
studio_receipt = json.loads((OUT / 'studio.receipt.json').read_text())
report = {
    'task': 'frozen source studio cohort and all-changed-Dart static acceptance',
    'initial_main': BASE, 'expected_source_commit': EXPECTED,
    'changed_dart_count': len(changed), 'changed_dart_files': changed,
    'runtime': {'dart': dart, 'flutter': flutter, 'activation': str(ACTIVATION)},
    'commands': results, 'before': before, 'after': after,
    'invariants': checks, 'changed_inputs': changed_inputs,
    'pin_and_lock_paths': pins,
    'pin_and_lock_changes_since_initial_main': pin_diff.splitlines(),
    'studio_receipt': str(OUT / 'studio.receipt.json'),
    'studio_accepted': studio_receipt['accepted'],
    'accepted': all(checks.values()) and all(r['exit_code'] == 0 for r in results.values()) and studio_receipt['accepted'],
}
(OUT / 'static-checks.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'accepted': report['accepted'], 'changed_dart_count': len(changed), 'invariants': checks, 'pin_changes_since_initial_main': pin_diff.splitlines(), 'report': str(OUT / 'static-checks.json')}), flush=True)
raise SystemExit(0 if report['accepted'] else 1)
