import datetime, hashlib, json, os, pathlib, subprocess, sys, time
root=pathlib.Path('/workspace/scratch/7efafb699daf/quds_office_suite')
base=pathlib.Path('/workspace/scratch/7efafb699daf/zotero-local-results/late-mail')
kind=sys.argv[1]
if kind not in ('core','studio','focused','host','quit'): raise SystemExit('Expected core, studio or focused')
output=base/(sys.argv[2] if len(sys.argv)>2 else kind)
output.mkdir(parents=True,exist_ok=True)
plan=json.loads((base/'test-plan.json').read_text())
selected=plan[kind if kind in ('core','focused','host','quit') else 'flutter']
package='packages/quds_mail_core' if kind=='core' else 'packages/quds_office_editor/example'
working=root/package
tracked=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
source_paths=[p for p in tracked if (p.endswith('.dart') and (p.startswith('packages/') or p.startswith('third_party/'))) or p.endswith('/pubspec.yaml') or p in ('pubspec.yaml','pubspec.lock')]
# Include every tracked project Dart input (including imported test helpers),
# while executing only the exact selected gate files listed in this receipt.
def manifest():
    return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source_paths if (root/p).is_file()}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
before=manifest()
(output/'source-before.json').write_text(json.dumps({'head':head,'tests':selected,'files':before},indent=2)+'\n')
tests=[str((root/p).relative_to(working)) for p in selected]
if kind=='core':
    command=['dart','--packages='+str(root/'.dart_tool/package_config.json'),str(pathlib.Path(os.environ['PUB_CACHE'])/'hosted/pub.dev/test-1.31.1/bin/test.dart'),'--reporter=json','--concurrency=2','--timeout','2m',*tests]
else:
    command=['dart',str(pathlib.Path(os.environ['FLUTTER_ROOT'])/'bin/cache/flutter_tools.snapshot'),'--no-version-check','test','--no-pub','--reporter=json','--concurrency=2','--timeout','2m',*tests]
(output/'command.json').write_text(json.dumps({'argv':command,'cwd':str(working),'head':head,'dart_version':subprocess.check_output(['dart','--version'],stderr=subprocess.STDOUT,text=True).strip()},indent=2)+'\n')
print(json.dumps({'started':kind,'head':head,'files':selected,'source_files':len(before),'output':str(output)}),flush=True)
started=time.monotonic()
with (output/'events.jsonl').open('w') as log:
    process=subprocess.run(command,cwd=working,stdout=log,stderr=subprocess.STDOUT,check=False)
(output/'exit-code.txt').write_text(str(process.returncode)+'\n')
after=manifest()
(output/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
changed=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
events=[]
for line in (output/'events.jsonl').read_text().splitlines():
    try: event=json.loads(line)
    except ValueError: continue
    if isinstance(event,dict): events.append(event)
results={}
for event in events:
    if event.get('type')=='testDone' and not event.get('hidden',False):
        result='skipped' if event.get('skipped') else event.get('result','unknown')
        results[result]=results.get(result,0)+1
errors=[e for e in events if e.get('type')=='error']
done=[e for e in events if e.get('type')=='done']
summary={'head':head,'tests':selected,'exit_code':process.returncode,'seconds':round(time.monotonic()-started,3),'results':results,'errors':len(errors),'done':done,'source_unchanged':not changed,'changed_sources':changed,'source_files':len(before),'executed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
if errors:
    print(json.dumps({'error_details':errors[:4]}),flush=True)
raise SystemExit(process.returncode if process.returncode else (0 if done and done[-1].get('success') and not errors and not changed else 1))
