import argparse
import collections
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

options = argparse.ArgumentParser(description='Reverify the exact frozen Git intake and supplemental published-main merges without fetching refs.')
options.add_argument('--workspace', type=Path, default=Path('/workspace/scratch/7efafb699daf'))
options.add_argument('--repository', type=Path)
args = options.parse_args()
ROOT = args.repository.resolve() if args.repository else args.workspace.resolve() / 'quds_office_suite'
OUT = args.workspace.resolve() / 'zotero-local-results'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


head = git('rev-parse', 'HEAD')
ancestors = set(git('rev-list', head).splitlines())
frozen = OUT / 'frozen-intake-at-dc87bf94.json'
frozen_hash = hashlib.sha256(frozen.read_bytes()).hexdigest()
assert frozen_hash == '0d59dd012c0738050b45a7afb4168fed5bdfefd9de24b8472a3519d87d5e3c3e'
source = json.loads(frozen.read_text())
previous = json.loads((OUT / 'final-intake-coverage.json').read_text())
proofs = previous['proofs']
for proof in proofs.values():
    original, replacement = proof['source'], proof['replacement']
    if proof['kind'] == 'full_tree':
        proof['equal'] = git('rev-parse', original + '^{tree}') == git('rev-parse', replacement + '^{tree}')
    else:
        proof['equal'] = all(git('rev-parse', original + ':' + path) == git('rev-parse', replacement + ':' + path) for path in proof['changed_paths'])
    proof['replacement_is_ancestor'] = replacement in ancestors
    proof['reverified_at'] = head
refs = []
for ref in source['refs']:
    entry = dict(ref)
    commit = ref['sha']
    proof = proofs.get(commit)
    if commit in ancestors:
        entry['disposition'] = 'ancestor'
    elif proof and proof['equal'] and proof['replacement_is_ancestor']:
        entry['disposition'] = 'verified_historical_equivalent'
    else:
        entry['disposition'] = 'uncovered'
    refs.append(entry)
uncovered = [ref for ref in refs if ref['disposition'] == 'uncovered']
assert len(refs) == 352
report = {
    'captured_at': source['captured_at'],
    'audited_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'target': head,
    'target_tree': git('rev-parse', head + '^{tree}'),
    'snapshot_scope': 'Exact frozen352 publication intake captured at dc87bf94; no ref refresh or branch chasing. Supplemental current-main preservation is recorded separately.',
    'frozen_snapshot_file': frozen.name,
    'frozen_snapshot_sha256': frozen_hash,
    'counts': dict(collections.Counter(ref['kind'] for ref in refs)),
    'dispositions': dict(collections.Counter(ref['disposition'] for ref in refs)),
    'total_refs': len(refs),
    'all_captured_refs_covered': not uncovered,
    'uncovered': uncovered,
    'proofs': proofs,
    'refs': refs,
    'github_actions': 'Not queried or awaited.',
}
(OUT / 'final-intake-coverage.json').write_text(json.dumps(report, indent=2) + '\n')
captured_word = '75b429e30a80181c34205d49391fb21e9928b490'
published_main = 'f92c0d24f0513c5e13e61ae58507c36e9cf4f1c1'
integration = 'c4e1d67540e7c3a706d2f0a3fead0cb17949f437'
delta = git('diff', '--name-status', captured_word, published_main).splitlines()
supplement = {
    'audited_at': report['audited_at'],
    'target': head,
    'scope': 'Supplemental main-only preservation after the frozen352-reference branch cutoff; does not alter that snapshot.',
    'captured_word_branch': captured_word,
    'published_main_recheck': published_main,
    'integration_commit': integration,
    'integration_parents': git('show', '-s', '--format=%P', integration).split(),
    'published_main_is_ancestor': published_main in ancestors,
    'integration_is_ancestor': integration in ancestors,
    'changes_since_captured_word_branch': [{'status': line.split('\t')[0], 'path': line.split('\t')[-1]} for line in delta],
    'changed_engine_lib_paths': git('diff', '--name-only', captured_word, published_main, '--', 'packages/quds_office_engine/lib').splitlines(),
    'test_gate_addition': 'packages/quds_office_engine/test/word_zotero_nested_note_tables_test.dart',
    'github_actions': 'Not queried or awaited.',
}
second_main = 'c10416d39894031164be68313253db5bbb3a5ad2'
second_merge = 'ed30a633a96960552d4fab11bd6e3226ee73ca14'
prior_checkpoint = '574bc02bc533bf5e8402d619b1e0e46c0950d935'
second_delta = git('diff', '--name-status', prior_checkpoint, second_merge).splitlines()
dependency_scope = ['packages/quds_office_engine', 'packages/legacy_doc_parser', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.fvmrc']
supplement['additional_preservations'] = [{
    'published_main_recheck': second_main,
    'integration_commit': second_merge,
    'prior_published_checkpoint': prior_checkpoint,
    'integration_parents': git('show', '-s', '--format=%P', second_merge).split(),
    'published_main_is_ancestor': second_main in ancestors,
    'integration_is_ancestor': second_merge in ancestors,
    'combined_changes_relative_to_prior_checkpoint': [{'status': line.split('\t')[0], 'path': line.split('\t')[-1]} for line in second_delta],
    'unchanged_engine_dependency_scope': dependency_scope,
    'engine_dependency_scope_changed_paths': git('diff', '--name-only', prior_checkpoint, second_merge, '--', *dependency_scope).splitlines(),
    'merge_resolution_record': 'final-main-merge-resolution.json',
    'replacement_studio_gate': 'late-mail/studio-combined-final',
}]
supplement['most_recent_preserved_published_main'] = second_main
supplement['all_published_main_rechecks_preserved'] = published_main in ancestors and second_main in ancestors
(OUT / 'supplemental-main-preservation.json').write_text(json.dumps(supplement, indent=2) + '\n')

quit_path = 'packages/quds_office_editor/example/test/studio_mail_quit_test.dart'
host_path = 'packages/quds_office_editor/example/test/studio_mail_sync_host_test.dart'
quit_source = git('show', second_merge + ':' + quit_path)
host_source = git('show', second_merge + ':' + host_path)
reopen = host_source.split('// Reopen with no provider or credential source.', 1)[1].split("await tester.tap(find.text('Open downloaded mail'));", 1)[0]
resolution = {
    'audited_at': report['audited_at'],
    'merge': second_merge,
    'parents': [prior_checkpoint, second_main],
    'paths': {p: git('rev-parse', second_merge + ':' + p) for p in [quit_path, host_path]},
    'quit_fixture': {
        'retains_two_sync_lifetime_assertions': quit_source.count('expectSync(') == 2,
        'retains_incoming_switcher_predicate': 'widget is StudioAppSwitcher && widget.label == _strings.mail' in quit_source,
        'difference_from_ours': git('diff', prior_checkpoint, second_merge, '--', quit_path),
        'difference_from_incoming': git('diff', second_main, second_merge, '--', quit_path),
    },
    'host_reopen_fixture': {
        'exactly_one_early_unmount': reopen.count('await tester.pumpWidget(const SizedBox.shrink());') == 1,
        'unmount_precedes_owner_open': reopen.index('await tester.pumpWidget(const SizedBox.shrink());') < reopen.index('harness.open(identity)'),
        'retains_owner_teardown': 'addTearDown(() async {' in reopen and 'await awaitOutboxOperation(tester, owner.close());' in reopen,
        'difference_from_ours': git('diff', prior_checkpoint, second_merge, '--', host_path),
        'difference_from_incoming': git('diff', second_main, second_merge, '--', host_path),
    },
    'runtime_qualification': 'late-mail/studio-combined-final; the final 11-file run exercises both resolved fixtures.',
}
assert all(v for k, v in resolution['quit_fixture'].items() if k.startswith('retains_'))
assert all(v for k, v in resolution['host_reopen_fixture'].items() if k in ['exactly_one_early_unmount', 'unmount_precedes_owner_open', 'retains_owner_teardown'])
(OUT / 'final-main-merge-resolution.json').write_text(json.dumps(resolution, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['target', 'counts', 'dispositions', 'all_captured_refs_covered']}))
