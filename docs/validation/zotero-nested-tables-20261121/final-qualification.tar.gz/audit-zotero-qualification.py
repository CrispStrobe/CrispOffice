import argparse
import collections
import datetime
import hashlib
import json
from pathlib import Path
import posixpath
import subprocess

options = argparse.ArgumentParser(description='Recount preserved Zotero qualification logs and compare their inputs to a checkout. Extract historical and final evidence into the original relative directory layout under --workspace.')
options.add_argument('--workspace', type=Path, default=Path('/workspace/scratch/7efafb699daf'))
options.add_argument('--repository', type=Path)
args = options.parse_args()
BASE = args.workspace.resolve()
ROOT = args.repository.resolve() if args.repository else BASE / 'quds_office_suite'
RESULTS = BASE / 'zotero-local-results'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def mapping(data):
    return data.get('files', data.get('inputs', data))


def compare_to_current(data):
    changed, absent, archived = [], [], []
    for path, expected in data.items():
        full = ROOT / path
        if full.is_file():
            if sha(full.read_bytes()) != expected:
                changed.append(path)
            continue
        try:
            blob = subprocess.check_output(['git', 'show', 'HEAD:' + path], cwd=ROOT, stderr=subprocess.DEVNULL)
        except subprocess.CalledProcessError:
            absent.append(path)
        else:
            (archived if sha(blob) == expected else absent).append(path)
    return {
        'captured_paths': len(data),
        'changed_paths': changed,
        'missing_or_different_git_paths': absent,
        'not_checked_out_but_exact_git_blob_match': archived,
        'all_captured_inputs_match_current': not changed and not absent,
    }


identities = {}


def cohort(name, log, before=None, after=None, receipt=None):
    if not log.exists():
        return {'status': 'pending', 'expected_log': str(log.relative_to(BASE))}
    events, non_json = [], 0
    for line in log.read_text().splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            non_json += bool(line.strip())
            continue
        if isinstance(event, dict):
            events.append(event)
    suites = {e['suite']['id']: e['suite']['path'] for e in events if e.get('type') == 'suite'}
    tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    context = read(receipt) if receipt and receipt.exists() else {}
    command_receipt = log.parent / 'command.json'
    cwd = context.get('cwd')
    if not cwd and command_receipt.exists():
        cwd = read(command_receipt).get('cwd')

    def suite_path(test):
        path = suites.get(test.get('suiteID'), '<unknown>')
        if not path.startswith('/') and cwd:
            path = posixpath.normpath(posixpath.join(cwd, path))
        if not path.startswith('/') and (test.get('url') or '').endswith('/' + path):
            path = test['url'].removeprefix('file://')
        if path.startswith(str(ROOT) + '/'):
            path = path[len(str(ROOT)) + 1:]
        elif '/packages/' in path:
            path = 'packages/' + path.split('/packages/', 1)[1]
        return path

    registrations = collections.Counter()
    instance_identity = {}
    for event in events:
        if event.get('type') == 'testStart':
            test = event['test']
            key = (suite_path(test), test.get('name', '<unknown>'))
            registrations[key] += 1
            instance_identity[test['id']] = (*key, registrations[key])
    skip_reasons = {e['testID']: e.get('message') for e in events if e.get('type') == 'print' and e.get('messageType') == 'skip'}
    counts, by_file, ids, passes, skipped, failures, skipped_cases = collections.Counter(), {}, [], [], [], [], []
    completion_ids = []
    completed_by_name = collections.defaultdict(list)
    for event in events:
        if event.get('type') != 'testDone' or event.get('hidden'):
            continue
        test = tests.get(event['testID'], {})
        identity = instance_identity[event['testID']]
        path = identity[0]
        completion_ids.append(event['testID'])
        completed_by_name[identity[:2]].append({
            'raw_test_id': event['testID'],
            'suite_id': test.get('suiteID'),
            'registration_ordinal': identity[2],
            'source_url': test.get('url'),
            'line': test.get('line'),
            'column': test.get('column'),
        })
        result = 'skipped' if event.get('skipped') else event.get('result', 'unknown')
        counts[result] += 1
        by_file.setdefault(path, collections.Counter())[result] += 1
        ids.append(identity)
        if result == 'success':
            passes.append(identity)
        elif result == 'skipped':
            skipped.append(identity)
            skipped_cases.append({'file': path, 'name': identity[1], 'reason': skip_reasons.get(event['testID']) or test.get('metadata', {}).get('skipReason')})
        else:
            failures.append({'file': path, 'name': identity[1], 'result': result})
    identities[name] = {'all': set(ids), 'success': set(passes), 'skipped': set(skipped)}
    terminals = [e for e in events if e.get('type') == 'done']
    value = {
        'status': 'complete' if terminals else 'in_progress_or_interrupted',
        'log': str(log.relative_to(BASE)),
        'log_sha256': sha(log.read_bytes()),
        'counts': dict(counts),
        'error_events': sum(e.get('type') == 'error' for e in events),
        'terminal_success': terminals[-1].get('success') if terminals else None,
        'non_json_lines': non_json,
        'files': {p: dict(c) for p, c in sorted(by_file.items())},
        'unique_successful_identities': len(set(passes)),
        'unique_successful_file_title_pairs': len({identity[:2] for identity in passes}),
        'duplicate_nonhidden_identity_occurrences': len(ids) - len(set(ids)),
        'repeated_completion_test_ids': len(completion_ids) - len(set(completion_ids)),
        'name_collision_groups': [{'file': key[0], 'name': key[1], 'registrations': values} for key, values in completed_by_name.items() if len(values) > 1],
        'all_identities_sha256': sha(json.dumps(sorted(set(ids)), ensure_ascii=False).encode()),
        'failed_cases': failures,
        'skipped_cases': skipped_cases,
    }
    if receipt and receipt.exists():
        data = read(receipt)
        value['recorded_head'] = data.get('head', data.get('git_head'))
        value['exit_code'] = data.get('exit_code')
    if before and before.exists():
        data = read(before)
        captured = mapping(data)
        value['source_before'] = str(before.relative_to(BASE))
        value['current_input_comparison'] = compare_to_current(captured)
        value['recorded_head'] = value.get('recorded_head') or data.get('head', data.get('git_head'))
        if after and after.exists():
            final = mapping(read(after))
            changed = sorted(p for p in set(captured) | set(final) if captured.get(p) != final.get(p))
            value['source_after'] = str(after.relative_to(BASE))
            value['inputs_changed_during_run'] = changed
    return value


def standard(name, directory, log_name='events.jsonl', receipt_name='summary.json'):
    path = RESULTS / directory
    return cohort(name, path / log_name, path / 'source-before.json', path / 'source-after.json', path / receipt_name)


groups = {
    'historical_engine_1221': standard('historical_engine_1221', 'engine-regression-final'),
    'historical_editor_perf': standard('historical_editor_perf', 'incoming-perf-editor-01', 'stdout.jsonl', 'receipt.json'),
    'historical_editor_nested_schedule': standard('historical_editor_nested_schedule', 'nested-controller-and-schedule-03', 'stdout.jsonl', 'receipt.json'),
    'historical_editor_zotero': standard('historical_editor_zotero', 'editor-zotero-regression-01', 'stdout.jsonl', 'receipt.json'),
    'mail_core': standard('mail_core', 'late-mail/core'),
    'diagnostic_mail_studio_first': standard('diagnostic_mail_studio_first', 'late-mail/studio'),
    'historical_mail_studio_318': standard('historical_mail_studio_318', 'late-mail/studio-final'),
    'final_mail_studio': standard('final_mail_studio', 'late-mail/studio-combined-final'),
    'final_engine': standard('final_engine', 'engine-combined-final'),
    'final_editor': standard('final_editor', 'editor-combined-final', 'stdout.jsonl', 'receipt.json'),
}

incoming = BASE / 'incoming-local-checks'
for name in ['mail-ui', 'editor-localization', 'studio-localization-credentials']:
    groups['initial_' + name] = cohort('initial_' + name, incoming / (name + '.jsonl'), incoming / 'inputs-start.json')

core_before = RESULTS / 'late-mail/core/source-before.json'
if core_before.exists():
    data = mapping(read(core_before))
    relevant = {p: h for p, h in data.items() if p.startswith('packages/quds_mail_core/lib/') or p == 'packages/quds_mail_core/test/body_download_test.dart' or p.endswith('/pubspec.yaml') or p in ('pubspec.yaml', 'pubspec.lock')}
    groups['mail_core']['relevant_input_comparison'] = compare_to_current(relevant)
    groups['mail_core']['relevance_basis'] = 'body_download_test imports core and test only; core imports only its own sources, dart libraries, and locked crypto. Retain core63 only when these captured core/test/package/lock inputs remain identical. Broad-manifest unrelated Mail UI/Studio changes remain listed separately.'

engine_before = RESULTS / 'engine-combined-final/source-before.json'
if engine_before.exists():
    engine_capture = read(engine_before)
    data = mapping(engine_capture)
    relevant = {p: h for p, h in data.items() if p.startswith(('packages/quds_office_engine/', 'packages/legacy_doc_parser/')) or p.endswith('/pubspec.yaml') or p in ('pubspec.yaml', 'pubspec.lock')}
    groups['final_engine']['relevant_input_comparison'] = compare_to_current(relevant)
    scope = ['packages/quds_office_engine', 'packages/legacy_doc_parser', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.fvmrc']
    groups['final_engine']['complete_tracked_dependency_scope'] = {
        'captured_commit': engine_capture['head'],
        'paths': scope,
        'changed_paths_against_current_worktree': git('diff', '--name-only', engine_capture['head'], '--', *scope).splitlines(),
        'method': 'Git tree/worktree comparison supplements captured Dart hashes with all tracked fixtures, assets, tools, package configurations and analysis/runtime pins in the engine and its only local package dependency.',
    }
    groups['final_engine']['relevance_basis'] = 'The pure Dart engine local dependency is legacy_doc_parser; its remaining dependencies and test packages are locked external packages. Every captured engine/legacy Dart source and test plus all package manifests and root lock remain checked. Later incoming Mail/Studio code and fixtures are outside this dependency scope and stay explicitly listed in the broad comparison. No engine rerun is double-counted.'

accepted = []
for name in ['mail_core', 'final_mail_studio', 'final_engine', 'final_editor']:
    group = groups[name]
    inputs = group.get('relevant_input_comparison', group.get('current_input_comparison', {}))
    if group.get('terminal_success') and group.get('exit_code') == 0 and not group.get('error_events') and not group.get('repeated_completion_test_ids') and inputs.get('all_captured_inputs_match_current') and not group.get('inputs_changed_during_run') and not group.get('complete_tracked_dependency_scope', {}).get('changed_paths_against_current_worktree'):
        accepted.append(name)
all_successes, all_skips = set(), set()
overlaps = []
for name in accepted:
    duplicate = all_successes & identities[name]['success']
    if duplicate:
        overlaps.append({'cohort': name, 'duplicate_successful_identities': len(duplicate)})
    all_successes |= identities[name]['success']
    all_skips |= identities[name]['skipped']

policy_file = 'packages/quds_office_engine/test/office_vba_word_proofing_integration_test.dart'
policy_title = "ordinary mutation policy applies to proofing controls: Instance of 'OfficeMacroPolicy'"
policy_parameters = [
    'OfficeMacroPolicy(allowMutation: false)',
    "OfficeMacroPolicy(allowedTools: {'docx.runFormat'})",
    "OfficeMacroPolicy(allowedTools: {'docx.paragraphFormat'})",
    'OfficeMacroPolicy(maxSteps: 2)',
]
parameterized_identity_proofs = []
for name in accepted:
    for collision in groups[name].get('name_collision_groups', []):
        assert name == 'final_engine' and collision['file'] == policy_file and collision['name'] == policy_title, 'Unverified duplicate display title in accepted cohort'
        source = (ROOT / policy_file).read_text()
        positions = [source.index(parameter) for parameter in policy_parameters]
        registrations = sorted(collision['registrations'], key=lambda value: value['registration_ordinal'])
        captured_hash = mapping(read(engine_before))[policy_file]
        verified = (
            len(registrations) == 4
            and [item['registration_ordinal'] for item in registrations] == [1, 2, 3, 4]
            and len({item['raw_test_id'] for item in registrations}) == 4
            and len({item['suite_id'] for item in registrations}) == 1
            and positions == sorted(positions)
            and sha((ROOT / policy_file).read_bytes()) == captured_hash
        )
        assert verified, 'Parameterized registration source proof failed'
        parameterized_identity_proofs.append({
            'file': policy_file,
            'source_sha256': captured_hash,
            'loop_line': 61,
            'parameter_lines': [62, 63, 64, 65],
            'registration_call_line': 67,
            'display_title': policy_title,
            'verified': True,
            'parameters_in_registration_order': [dict(record, parameter=parameter) for record, parameter in zip(registrations, policy_parameters)],
            'explanation': 'Four distinct parameterized registrations share their default object-string display title. Each raw ID completes once in one suite. Registration ordinal distinguishes these source-verified cases; no repeated cohort is added.',
        })

historical_editor = ['historical_editor_perf', 'historical_editor_nested_schedule', 'historical_editor_zotero']
historic_passes = set().union(*(identities.get(n, {}).get('success', set()) for n in historical_editor))
historic_skips = set().union(*(identities.get(n, {}).get('skipped', set()) for n in historical_editor))

converter = RESULTS / 'nested-converter/summary.json'
converter_receipt = RESULTS / 'nested-converter/final-source-verification.json'
converter_data = read(converter) if converter.exists() else {}
converter_audit = {
    'summary': str(converter.relative_to(BASE)),
    'scope': converter_data.get('artifact_scope'),
    'converter_version': converter_data.get('converter_version'),
    'results': converter_data.get('results'),
}
if converter_receipt.exists():
    data = read(converter_receipt)
    converter_audit['final_verifier_head'] = data.get('git_head')
    converter_audit['current_input_comparison'] = compare_to_current(data['source_inputs'])
    converter_audit['exit_code'] = data.get('exit_code')

static_validation = {}
previous_checks = RESULTS / 'editor-final-checks/summary.json'
if previous_checks.exists():
    prior = read(previous_checks)
    static_validation['historical_editor_check'] = {
        'summary': str(previous_checks.relative_to(BASE)),
        'head': prior['head'],
        'format_exit_code': prior['format']['exit_code'],
        'analyze_exit_code': prior['analyze']['exit_code'],
        'qualification': 'Historical read-only formatter failure on the incoming sync-dialog test; later published main supplies its formatted version. This receipt is preserved and not represented as a passing format gate.',
    }
checks = RESULTS / 'editor-final-checks-02'
if (checks / 'summary.json').exists():
    static_validation['editor_and_format'] = read(checks / 'summary.json')
    static_validation['editor_and_format']['current_input_comparison'] = compare_to_current(mapping(read(checks / 'source-before.json')))
engine_analyzer = RESULTS / 'engine-combined-final/analyze.log'
engine_analyzer_exit = RESULTS / 'engine-combined-final/analyze-exit-code.txt'
if engine_analyzer.exists():
    static_validation['engine_analyzer'] = {
        'log': str(engine_analyzer.relative_to(BASE)),
        'log_sha256': sha(engine_analyzer.read_bytes()),
        'exit_code': int(engine_analyzer_exit.read_text().strip()) if engine_analyzer_exit.exists() else None,
        'output': engine_analyzer.read_text().strip(),
    }

render_dir = RESULTS / 'editor-combined-final/render'
render_summary = {'status': 'pending'}
if all((render_dir / f'cycle-{i}.png').exists() and (render_dir / f'cycle-{i}-layout.txt').exists() for i in range(4)):
    cycles = []
    for i in range(4):
        item = {
            'cycle': i,
            'png_sha256': sha((render_dir / f'cycle-{i}.png').read_bytes()),
            'normalized_layout_sha256': sha((render_dir / f'cycle-{i}-layout.txt').read_bytes()),
        }
        if i and (render_dir / f'cycle-{i}-difference.json').exists():
            item.update(read(render_dir / f'cycle-{i}-difference.json'))
        cycles.append(item)
    render_summary = {
        'status': 'complete',
        'cycles': cycles,
        'all_png_identical': len({c['png_sha256'] for c in cycles}) == 1,
        'all_normalized_layout_identical': len({c['normalized_layout_sha256'] for c in cycles}) == 1,
        'all_reported_pixel_differences_zero': all(c.get('changedPixels') == 0 and c.get('maximumChannelDelta') == 0 for c in cycles[1:]),
        'comparison': 'Exact zero-tolerance RGBA assertions in the executed test; independently recounted PNG and normalized layout SHA-256 values. Layout fingerprints normalize only transient source-model identity hashes.',
    }
    (render_dir / 'summary.json').write_text(json.dumps(render_summary, indent=2) + '\n')

published_by_tree = collections.defaultdict(list)
published_commits = set()
for line in git('log', '--remotes=origin', '--format=%H %T').splitlines():
    commit, tree = line.split()
    published_by_tree[tree].append(commit)
    published_commits.add(commit)
executed_heads = {g.get('recorded_head') for g in groups.values()} - {None}
executed_heads.update(['f14ec176d08c431631cd65e647288bc20f10318f', '703a41527932dba3a04f0d04eda48ab0cdd41d04'])
for path in (RESULTS / 'late-mail').rglob('source-before.json'):
    value = read(path).get('head')
    if value:
        executed_heads.add(value)
publication_mapping = []
for commit in sorted(executed_heads):
    tree = git('rev-parse', commit + '^{tree}')
    publication_mapping.append({
        'executed_commit_as_recorded': commit,
        'tree': tree,
        'executed_commit_in_fetched_origin_ancestry': commit in published_commits,
        'exact_tree_equivalent_in_fetched_origin_ancestry': published_by_tree.get(tree, []),
        'method': 'Immutable Git tree equality and reachability from locally fetched origin refs; original receipts are unchanged.'
    })

baseline = '23903dfe7b680cc8df2319f25e3fbf2e5f116b36'
feature_source = ['packages/quds_office_engine/lib/src/word/model/word_zotero_note.dart']
word_sources = ['packages/quds_office_engine/lib/' + p for p in [
    'src/automation/office_vba_language.dart',
    'src/automation/operations/word_steps.dart',
    'src/word/layout/word_incremental_layout.dart',
    'src/word/serial/word_deserializer.dart',
    'src/word/serial/word_property_io.dart',
    'src/word/serial/word_style_cascade.dart',
]]
mail_sources = [
    'packages/quds_mail_core/lib/quds_mail_core.dart',
    'packages/quds_mail_core/lib/src/sync/body_download.dart',
    'packages/quds_mail_ui/lib/src/workspace/message_list.dart',
] + ['packages/quds_office_editor/example/lib/' + p for p in [
    'studio_mail_body_download.dart', 'studio_mail_ews.dart',
    'studio_mail_message_loader.dart', 'studio_mail_native.dart',
    'studio_mail_reader_labels.dart', 'studio_mail_sync_dialog.dart',
    'studio_mail_sync_strings.dart', 'studio_plural.dart', 'suite_workspace.dart',
]]
changed_production = [p for p in git('diff', '--name-only', baseline, 'HEAD').splitlines() if p.startswith('packages/') and '/lib/' in p]
product_scope = {
    'reconciled_baseline': baseline,
    'feature_sources': feature_source,
    'integrated_word_sources': word_sources,
    'integrated_mail_sources_including_gate_repair': mail_sources,
    'unexpected_production_paths': sorted(set(changed_production) - set(feature_source + word_sources + mail_sources)),
    'changed_production_path_count': len(changed_production),
    'current_production_sha256': {p: sha((ROOT / p).read_bytes()) for p in changed_production},
    'editor_library_changes_since_reconciled_baseline': git('diff', '--name-only', baseline, 'HEAD', '--', 'packages/quds_office_editor/lib').splitlines(),
    'engine_library_changes_since_captured_word_merge': git('diff', '--name-only', '75b429e30a80181c34205d49391fb21e9928b490', 'HEAD', '--', 'packages/quds_office_engine/lib').splitlines(),
    'feature_parser_blob_unchanged_since_6270ec92': git('rev-parse', '6270ec92c957ee856aa68f33fb07f27e2f8b3c33:' + feature_source[0]) == git('rev-parse', 'HEAD:' + feature_source[0]),
    'uncommitted_production_paths': [p for p in git('diff', '--name-only', 'HEAD').splitlines() if p.startswith('packages/') and '/lib/' in p],
}

audit = {
    'audited_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head': git('rev-parse', 'HEAD'),
    'tree': git('rev-parse', 'HEAD^{tree}'),
    'method': 'Independent recount of raw test events, excluding hidden lifecycle cases and separating skipped=true from successful execution. Case identity=(repository-relative suite path, full test name, registration ordinal); ordinal is 1 except the four explicitly source-verified parameterized policy registrations. Repeated completion IDs are rejected. SHA-256 manifests are compared to current files, with archival Git-blob checks for absent historical evidence scripts. No GitHub Actions queried.',
    'cohorts': groups,
    'executed_commit_publication': publication_mapping,
    'product_scope': product_scope,
    'static_validation': static_validation,
    'final_render': render_summary,
    'accepted_final_cohorts': accepted,
    'final_executed_case_registrations': sum(groups[name]['counts'].get('success', 0) for name in accepted),
    'final_unique_passes': len(all_successes),
    'final_unique_successful_file_title_pairs': len({identity[:2] for identity in all_successes}),
    'parameterized_identity_proofs': parameterized_identity_proofs,
    'final_unique_skips': len(all_skips),
    'final_duplicate_successful_identities': overlaps,
    'all_requested_final_cohorts_complete_and_applicable': len(accepted) == 4 and not overlaps,
    'final_static_gates_passed': bool(static_validation.get('editor_and_format', {}).get('success') and static_validation.get('engine_analyzer', {}).get('exit_code') == 0),
    'historical_composed_editor': {
        'unique_passes': len(historic_passes),
        'unique_skips': len(historic_skips),
        'qualification': 'Historical 510+8 only. Original perf stream contains a disk-full loader error; complete file results were composed with the subsequent successful schedule run. Six later shared engine-source changes require the new single-process final16 run. Do not add these repeated passes to final totals.'
    },
    'initial_incoming_118': {
        'successful_cases': sum(groups['initial_' + n]['counts'].get('success', 0) for n in ['mail-ui', 'editor-localization', 'studio-localization-credentials']),
        'qualification': 'Historical successful intake, not added to final-current totals. Subsequent core/Mail UI/Studio and shared Word source changes invalidate a blanket final-source claim. Late Mail/final engine/final editor gates qualify their explicitly selected current scopes; they do not imply all original118 were repeated.',
        'source_timing_receipt': 'incoming-local-checks/results.json',
        'test_delta_review': 'zotero-local-results/formatting-only-test-review.json',
    },
    'converter': converter_audit,
    'frozen_intake': 'zotero-local-results/final-intake-coverage.json',
    'publication_main_supplement': 'zotero-local-results/supplemental-main-preservation.json',
    'limitations': ['No live Zotero session or Word/LibreOffice/OpenOffice plugin acceptance is claimed by synthetic callback/controller tests or headless converter checks.', 'The documented DOCX-to-ODT-to-DOCX list-numbering failure remains a failed route and is not included as a passing test.'],
}
(RESULTS / 'final-qualification-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps({k: audit[k] for k in ['head', 'accepted_final_cohorts', 'final_unique_passes', 'final_unique_skips', 'all_requested_final_cohorts_complete_and_applicable']}))
