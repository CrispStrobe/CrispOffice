import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/7efafb699daf/quds_office_suite')
OUT = ROOT.parent / 'zotero-local-results/editor-final-checks-02'
OUT.mkdir(parents=True, exist_ok=False)
feature = [
    'packages/quds_office_engine/lib/src/word/model/word_zotero_note.dart',
    'packages/quds_office_engine/test/word_zotero_note_table_test.dart',
    'packages/quds_office_engine/test/word_zotero_nested_table_test.dart',
    'packages/quds_office_engine/test/word_zotero_nested_tables_integration_test.dart',
    'packages/quds_office_editor/test/word_zotero_nested_table_controller_test.dart',
    'packages/quds_office_engine/tool/zotero/nested_table_acceptance.dart',
]
mail = [
    'packages/quds_office_editor/example/lib/studio_mail_sync_dialog.dart',
    'packages/quds_office_editor/example/test/studio_mail_sync_dialog_test.dart',
    'packages/quds_office_editor/example/test/studio_mail_sync_host_test.dart',
    'packages/quds_office_editor/example/test/studio_mail_quit_test.dart',
    'packages/quds_office_editor/example/lib/studio_mail_ews.dart',
    'packages/quds_office_editor/example/test/studio_mail_body_download_store_test.dart',
    'packages/quds_office_editor/example/test/studio_mail_sync_native_test.dart',
]
format_paths = feature + mail
analyze_paths = [feature[4]] + mail
tracked = subprocess.check_output(['git', 'ls-files'], cwd=ROOT, text=True).splitlines()
paths = sorted({p for p in tracked if (
    (p.endswith('.dart') and p.startswith(('packages/', 'third_party/')))
    or p.endswith(('/pubspec.yaml', '/analysis_options.yaml'))
    or p in ('pubspec.lock', 'pubspec.yaml', '.fvmrc', 'analysis_options.yaml')
)} | {'.dart_tool/package_config.json'})


def snapshot():
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths if (ROOT / p).is_file()}


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
before = snapshot()
write('source-before.json', {'head': head, 'files': before})
summary = {
    'head': head,
    'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'dart_version': subprocess.check_output(['dart', '--version'], text=True).strip(),
    'cwd': str(ROOT),
    'format_paths': format_paths,
    'analyze_paths': analyze_paths,
    'source_path_count': len(before),
}
for name, command in [
    ('format', ['dart', 'format', '--output=none', '--set-exit-if-changed', *format_paths]),
    ('analyze', ['dart', 'analyze', '--fatal-infos', *analyze_paths]),
]:
    start = time.monotonic()
    with (OUT / (name + '.log')).open('w') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    summary[name] = {
        'command': command,
        'exit_code': result.returncode,
        'seconds': round(time.monotonic() - start, 3),
        'log_sha256': hashlib.sha256((OUT / (name + '.log')).read_bytes()).hexdigest(),
    }
    print(json.dumps({name: summary[name]}), flush=True)
after = snapshot()
write('source-after.json', after)
summary['inputs_changed_during_run'] = sorted(p for p in set(before) | set(after) if before.get(p) != after.get(p))
summary['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
summary['success'] = all(summary[k]['exit_code'] == 0 for k in ['format', 'analyze']) and not summary['inputs_changed_during_run']
write('summary.json', summary)
print(json.dumps(summary), flush=True)
raise SystemExit(0 if summary['success'] else 1)
