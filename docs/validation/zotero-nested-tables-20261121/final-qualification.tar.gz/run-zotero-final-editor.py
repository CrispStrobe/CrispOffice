import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('name')
parser.add_argument('package')
parser.add_argument('--flutter', action='store_true')
parser.add_argument('--render-artifacts', action='store_true')
parser.add_argument('tests', nargs='+')
args = parser.parse_args()
root = Path('/workspace/scratch/7efafb699daf/quds_office_suite')
output = Path('/workspace/scratch/7efafb699daf/zotero-local-results') / args.name
output.mkdir(parents=True, exist_ok=False)
package = root / 'packages' / args.package
tracked = subprocess.check_output(['git', 'ls-files'], cwd=root, text=True).splitlines()
# Final qualification captures all checked-out project Dart sources, assets,
# fixtures, and package/configuration inputs, including imported test helpers.
paths = [path for path in tracked if (
    (path.endswith('.dart') and path.startswith(('packages/', 'third_party/')))
    or path.endswith(('/pubspec.yaml', '/analysis_options.yaml'))
    or path in ('pubspec.lock', 'pubspec.yaml', '.fvmrc', 'analysis_options.yaml')
    or ('/test/fixtures/' in path and path.startswith('packages/'))
    or ('/assets/' in path and path.startswith('packages/'))
)]
paths += [(package / test).relative_to(root).as_posix() for test in args.tests]
paths += ['.dart_tool/package_config.json']
paths = sorted({path for path in paths if (root / path).is_file()})

def source_hashes():
    return {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in paths}

def write(name, value):
    (output / name).write_text(json.dumps(value, indent=2) + '\n')

before = source_hashes()
write('source-before.json', before)
command = ['dart']
if args.flutter:
    command += [os.environ['FLUTTER_ROOT'] + '/bin/cache/flutter_tools.snapshot', '--no-version-check', 'test', '--no-pub']
else:
    command += ['test']
command += ['--reporter=json', '--concurrency', '2', '--timeout', '2m']
if args.render_artifacts:
    command += ['--dart-define=QUDS_NESTED_RENDER_ARTIFACTS=' + str(output / 'render')]
command += args.tests
receipt = {
    'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'command': command,
    'cwd': str(package),
    'dart_version': subprocess.check_output(['dart', '--version'], text=True).strip(),
    'input_count': len(before),
}
write('receipt.json', receipt)
with (output / 'stdout.jsonl').open('w') as stdout, (output / 'stderr.log').open('w') as stderr:
    completed = subprocess.run(command, cwd=package, stdout=stdout, stderr=stderr)
after = source_hashes()
write('source-after.json', after)
events = []
for line in (output / 'stdout.jsonl').read_text().splitlines():
    try:
        event = json.loads(line)
    except json.JSONDecodeError:
        continue
    if isinstance(event, dict):
        events.append(event)
names = {event['test']['id']: event['test']['name'] for event in events if event.get('type') == 'testStart'}
counts = collections.Counter(event['result'] for event in events if event.get('type') == 'testDone' and not event.get('hidden') and not event.get('skipped'))
receipt.update(
    exit_code=completed.returncode,
    finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    changed_inputs=[path for path in paths if before[path] != after[path]],
    results=dict(counts),
    skipped=sum(1 for event in events if event.get('type') == 'testDone' and event.get('skipped')),
    errors=[{'test': names.get(event.get('testID')), 'error': event.get('error')} for event in events if event.get('type') == 'error'],
    terminal_events=[event for event in events if event.get('type') == 'done'],
)
write('receipt.json', receipt)
print(json.dumps(receipt, indent=2))
if completed.returncode:
    print((output / 'stderr.log').read_text()[-2000:])
    print((output / 'stdout.jsonl').read_text()[-5000:])
raise SystemExit(completed.returncode)
