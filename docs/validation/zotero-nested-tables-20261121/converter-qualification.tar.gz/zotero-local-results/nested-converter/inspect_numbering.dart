import 'dart:convert';
import 'dart:io';
import 'package:quds_office_engine/quds_office_engine.dart';

void main(List<String> paths) {
  for (final path in paths) {
    final document = WordDeserializer().readBytes(File(path).readAsBytesSync());
    stdout.writeln(jsonEncode({
      'input': path,
      'paragraphs': [
        for (final paragraph in document.paragraphs)
          if (paragraph.text.startsWith('First ') ||
              paragraph.text.startsWith('Second '))
            {
              'text': paragraph.text.split('ITEM CSL_CITATION').first,
              'numId': paragraph.properties.numId,
              'listLabel': paragraph.properties.listLabel,
            },
      ],
    }));
  }
}
