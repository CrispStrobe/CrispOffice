from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib, io, json, shutil, tarfile, time, urllib.request, yaml

ROOT = Path(__file__).resolve().parent
CACHE = ROOT / 'pub-cache'
PRELOAD = ROOT / 'flutter/.pub-preload-cache'
locks = [ROOT.parent / 'quds_office_suite/pubspec.lock', ROOT / 'flutter/packages/flutter_tools/pubspec.lock']
packages = {}
for lock in locks:
    for name, spec in yaml.safe_load(lock.read_text())['packages'].items():
        if spec['source'] != 'hosted':
            continue
        assert spec['description']['url'] == 'https://pub.dev'
        packages[name + '-' + spec['version']] = {'name': name, 'version': spec['version'], 'sha256': spec['description']['sha256']}
for sub in ['_temp', 'hosted/pub.dev', 'hosted-hashes/pub.dev']:
    (CACHE / sub).mkdir(parents=True, exist_ok=True)

def fetch(pair):
    key, spec = pair
    target = CACHE / 'hosted/pub.dev' / key
    hash_path = CACHE / 'hosted-hashes/pub.dev' / (key + '.sha256')
    if target.is_dir() and hash_path.is_file() and hash_path.read_text().strip() == spec['sha256']:
        return dict(spec, status='verified-cache')
    preloaded = PRELOAD / (key + '.tar.gz')
    url = 'https://pub.dev/api/archives/' + key + '.tar.gz'
    for attempt in range(3):
        try:
            if preloaded.is_file():
                payload = preloaded.read_bytes()
                source = 'official-sdk-preload'
            else:
                with urllib.request.urlopen(url, timeout=45) as response:
                    payload = response.read()
                source = url
            actual = hashlib.sha256(payload).hexdigest()
            if actual != spec['sha256']:
                raise RuntimeError('Archive checksum mismatch')
            temporary = CACHE / '_temp' / key
            if temporary.exists():
                shutil.rmtree(temporary)
            temporary.mkdir()
            with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
                archive.extractall(temporary, filter='data')
            if target.exists():
                shutil.rmtree(target)
            temporary.rename(target)
            hash_path.write_text(actual)
            return dict(spec, source=source, bytes=len(payload), actual_sha256=actual, status='verified-install')
        except Exception as error:
            if attempt == 2:
                return dict(spec, source=url, status='failed', error=str(error))

start = time.monotonic()
results = []
with ThreadPoolExecutor(max_workers=8) as pool:
    for future in as_completed([pool.submit(fetch, item) for item in sorted(packages.items())]):
        result = future.result()
        results.append(result)
        if result['status'] == 'failed' or len(results) % 20 == 0:
            print(json.dumps({'completed': len(results), 'total': len(packages), 'latest': result}), flush=True)
receipt = {'packages': sorted(results, key=lambda item: (item['name'], item['version'])), 'seconds': time.monotonic()-start}
(ROOT / 'prefetch-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
failures = [result for result in results if result['status'] == 'failed']
print(json.dumps({'completed': len(results), 'failures': len(failures), 'seconds': receipt['seconds']}), flush=True)
raise SystemExit(1 if failures else 0)
