export FLUTTER_ROOT=/workspace/scratch/7efafb699daf/zotero-toolchain/flutter
export PUB_CACHE=/workspace/scratch/7efafb699daf/zotero-toolchain/pub-cache
export XDG_CONFIG_HOME=/workspace/scratch/7efafb699daf/zotero-toolchain/config
export TMPDIR=/workspace/scratch/7efafb699daf/zotero-toolchain/tmp
export FLUTTER_SUPPRESS_ANALYTICS=true
export DART_SUPPRESS_ANALYTICS=true
export CI=true
export PATH="$FLUTTER_ROOT/bin/cache/dart-sdk/bin:$FLUTTER_ROOT/bin:$PATH"
