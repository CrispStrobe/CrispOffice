from pathlib import Path
import subprocess
r=Path('/tmp/quds-german-context-20261117');p=r/'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart';s=p.read_text();old=subprocess.check_output(['git','show','898c4c07:packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart'],cwd=r,text=True)
helper=old[old.index('  static void _writeParagraphInlines('):old.index('  static bool _isPageNumberParagraph(')]
helper=helper.replace('    XmlWriter w,\n','',1).replace('    _OdtLayout layout,\n  ) {','    _OdtLayout layout,\n    void Function(WmlInline, {String? nativeField}) writeInline,\n  ) {',1).replace('_writeInline(w, inlines[index], layout);','writeInline(inlines[index]);').replace('_writeInline(w, field.cache, layout, nativeField: field.element);','writeInline(field.cache, nativeField: field.element);')
pos=s.index('  static bool _isPageNumberParagraph(');s=s[:pos]+helper+s[pos:]
s=s.replace('    final pageField = _isPageNumberParagraph(paragraph);','    final pageField = layout.fieldDepth == 0 && _isPageNumberParagraph(paragraph);')
start=s.index('    void writeInline(',s.index('  static void _writeParagraph('));end=s.index('    startParagraph();',start);chunk=s[start:end];chunk=chunk.replace('      String? textOverride,','      String? textOverride,\n      String? nativeField,',1).replace('          textOverride: textOverride,','          textOverride: textOverride,\n          nativeField: nativeField,',1);s=s[:start]+chunk+s[end:]
s=s.replace('      for (final inline in paragraph.inlines) {\n        writeInline(inline);\n      }','      _writeParagraphInlines(paragraph.inlines, layout, writeInline);',1)
s=s.replace('        if (layout.fieldResultSuppressed) break;\n','');start=s.index('        if (layout.pendingFieldElement case');end=s.index('        final href =',start);s=s[:start]+s[end:]
start=s.index('      case WmlFieldBoundary():',s.index('  static void _writeInline('));end=s.index('      case WmlBookmarkBoundary():',start);s=s[:start]+'''      case WmlFieldBoundary():
        // Complete admitted packets are emitted by _writeParagraphInlines.
        // Other boundaries are hidden metadata; every cached run stays visible.
        break;
'''+s[end:]
start=s.index('  String? pendingFieldElement;');end=s.index('  final Map<String, String> _runStyles',start);s=s[:start]+s[end:]
s=s.replace('var _bookmarkNames = <String, String>{};','var _bookmarkNames = <String, String?>{};').replace('_bookmarkNames = <String, String>{};','_bookmarkNames = <String, String?>{};')
start=s.index('  String? bookmarkName(');end=s.index('  _OdtListMarker listMarker(',start)
s=s[:start]+'''  String? bookmarkName(WmlBookmarkBoundary boundary) {
    final String id;
    try {
      id = WordBookmarks.canonicalId(boundary.id);
    } on StateError {
      return null;
    }
    if (!boundary.isStart) {
      // Do not assign an end to either of two competing active starts.
      if (_bookmarkNames.containsKey(id)) return _bookmarkNames.remove(id);
      return boundary.name;
    }
    final name = boundary.name;
    if (name != null && name.isNotEmpty) {
      _bookmarkNames[id] = _bookmarkNames.containsKey(id) ? null : name;
    }
    return name;
  }

'''+s[end:];p.write_text(s)
p=r/'packages/quds_office_engine/test/odt_bookmark_end_fidelity_test.dart';s=p.read_text().replace("test('an unexported TOC start cannot create a visible orphan end', () {", "test('an omitted TOC title cannot create a visible orphan end', () {");needle='            WmlToc(\n              titleParagraph:';assert needle in s;s=s.replace(needle,"            WmlToc(\n              title: '',\n              titleParagraph:",1);p.write_text(s)
p=r/'packages/quds_office_engine/test/odt_section_fidelity_test.dart';s=p.read_text();s=s.replace("        if (cached)\n          toc.itemParagraphs = [_p('Cached introduction'), _p('Cached details')];", "        if (cached) {\n          toc.itemParagraphs = [_p('Cached introduction'), _p('Cached details')];\n        }");p.write_text(s)
