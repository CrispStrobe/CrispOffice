import 'dart:io';
import 'package:quds_office_engine/quds_office_engine.dart';

void main(List<String> args) {
  final document = WmlDocument(sections: [
    WmlSection(blocks: [WmlParagraph(inlines: [WmlRun(text: 'FIRST SECTION')])]),
    WmlSection(
      pageSize: const WmlPageSize(width: 600, height: 400),
      blocks: [WmlToc(title: 'CONTENTS ON SECOND PAGE', entries: [
        WmlTocEntry(text: 'Introduction', level: 1, headingParagraphIndex: 0, pageNumber: 3),
        WmlTocEntry(text: 'Details', level: 2, headingParagraphIndex: 1, pageNumber: 4),
      ])],
    ),
  ]);
  File(args.single).writeAsBytesSync(OdtDocumentWriter.writeBytes(document));
}
