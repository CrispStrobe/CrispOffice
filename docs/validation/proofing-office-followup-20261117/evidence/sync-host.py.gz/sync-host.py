from pathlib import Path
import subprocess,json,sys
r=Path('/tmp/crispcloud-german-syntax-20261117').resolve();q=Path('/tmp/quds-german-context-20261117').resolve();sys.path.insert(0,str(r/'tool'));import sync_office_fidelity as sync
m=json.loads((r/'tool/office_fidelity_manifest.json').read_text());ind=sync.standalone_sources(m,r);target=sync.git(q,'rev-parse','HEAD').decode().strip();base=m['source_commit'];changed=sync.git(q,'diff','--name-only',base,target).decode().splitlines();names=sorted(set(m['files'])|{n for n in changed if sync.shared(n) and not sync.standalone_path(n,ind)})
managed=[n for n in names if not sync.standalone_path(n,ind)]
def blobs(ref):
 p=subprocess.run(['git','cat-file','--batch'],input=('\n'.join(ref+':'+n for n in managed)+'\n').encode(),stdout=subprocess.PIPE,cwd=q,check=True);raw=p.stdout;at=0;out={}
 for n in managed:
  end=raw.index(b'\n',at);head=raw[at:end].split();at=end+1
  if head[-1]==b'missing':out[n]=None;continue
  size=int(head[-1]);out[n]=raw[at:at+size];at+=size+1
 return out
before=blobs(base);after=blobs(target);writes={};deletes=[];hashes={};diverged=[];admitted=[]
for n in names:
 sync.safe_path(n);p=r/n;assert not p.is_symlink() and p.resolve().is_relative_to(r);data=p.read_bytes() if p.exists() else None;sha=sync.digest(data) if data is not None else None
 if n in m['files']:assert sha==m['files'][n],f'Unrecorded host edit: {n}'
 if sync.standalone_path(n,ind):hashes[n]=sha;continue
 prior=before[n];candidate=after[n]
 if n in m['files']:
  if prior is None or sync.digest(prior)!=sha:diverged.append(n)
 elif data is not None:
  assert data==prior or data==candidate,f'Unmanaged customization: {n}'
  admitted.append(n)
 if candidate is None:
  if data is not None:deletes.append(n)
 else:
  hashes[n]=sync.digest(candidate)
  if candidate!=data:writes[n]=candidate
expected=json.loads(Path('/tmp/office-proofing-followup-20261117-evidence/host-manifest-audit.json').read_text())['recorded_divergences'];assert sorted(diverged)==sorted(expected)
assert not any('quds_proofing_aot/' in n or n.endswith('studio_aot.dart') for n in names)
receipt={'source_commit':target,'previous_source':base,'reviewed_recorded_divergences':diverged,'existing_unmanaged_files_matched':admitted,'writes':sorted(writes),'deletes':deletes,'files':len(hashes)};Path('/tmp/office-proofing-followup-20261117-evidence/host-sync-reviewed.json').write_text(json.dumps(receipt,indent=2)+'\n')
sync.apply(r,{'writes':writes,'deletes':deletes,'manifest':dict(m,source_commit=target,source_branch='main',files=hashes),'manifest_path':r/'tool/office_fidelity_manifest.json'});print(json.dumps(receipt,indent=2))
