from pathlib import Path
import subprocess,hashlib,json
r=Path('/tmp/crispcloud-german-syntax-20261117');q=Path('/tmp/quds-german-context-20261117');m=json.loads((r/'tool/office_fidelity_manifest.json').read_text());names=[n for n in m['files'] if not n.startswith('packages/legacy_doc_parser/')];refs=[m['source_commit']+':'+n for n in names];p=subprocess.run(['git','cat-file','--batch'],input=('\n'.join(refs)+'\n').encode(),stdout=subprocess.PIPE,cwd=q,check=True);data=p.stdout;at=0;bad=[]
for n in names:
 e=data.index(b'\n',at);h=data[at:e].split();at=e+1
 if h[-1]==b'missing':bad.append(n);continue
 size=int(h[-1]);blob=data[at:at+size];at+=size+1
 assert hashlib.sha256((r/n).read_bytes()).hexdigest()==m['files'][n],n
 if hashlib.sha256(blob).hexdigest()!=m['files'][n]:bad.append(n)
result={'source_commit':m['source_commit'],'host_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'recorded_divergences':bad};Path('/tmp/office-proofing-followup-20261117-evidence/host-manifest-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
