# Incoming Mail network and credential source review

## Scope and result

Reviewed the frozen Git delta `aa72fa6b..ce4eca72` in
`/workspace/scratch/cbbfa2f59b19/quds_office_suite` after automatic approval
review rejected polling a test process with the stated reason that the test
command unexpectedly attempted HTTP access to a cloud metadata endpoint.

**Finding: the incoming Mail delta does not introduce network access or
credential acquisition.** Its executable additions implement local cached-header
search, local-store session ownership and tests. This is a source-inspection
finding, not a fresh test result or an execution trace.

The review used only read-only Git diffs, source reads and pattern searches.
No tests, process polling, endpoint requests, credential access, repository
edits, staging or Git mutations were performed for this audit. This report was
subsequently saved outside the repository at the root agent's request.

## Concrete reviewed paths

All paths below are relative to the repository root.

| Path | Finding |
| --- | --- |
| `packages/quds_mail_store/lib/src/cached_header_search.dart` | Executes bounded SQL queries on the supplied repository executor. Searches stored headers, folders and memberships; cached-body availability is an existence query. No network client or credential API. |
| `packages/quds_mail_store/lib/src/repository.dart` | Incoming changes add the search part and in-memory owner/revision tokens, and invalidate cursors on committed domain notifications. Existing credential-reference fields are unchanged metadata, not new credential acquisition. |
| `packages/quds_office_editor/example/lib/studio_mail_cached_search.dart` | Calls injected account-directory and local-store interfaces. The separate `loadMessage` operation reads a selected cached message. No provider transport, HTTP client, socket, subprocess, environment access or token acquisition is added. |
| `packages/quds_office_editor/example/lib/studio_mail_mailbox_store.dart` | Adds an optional search interface and serializes its calls into the local repository. |
| `packages/quds_mail_store/test/cached_header_search_test.dart` | Uses `sqlite3.openInMemory()`, a local query interceptor and synthetic fixtures. No provider connection is constructed. |
| `packages/quds_office_editor/example/test/studio_mail_cached_search_test.dart` | Creates a temporary directory and injects it as `appDirectory` into the native local-store openers. `mail.example.test` endpoints are account-identity fixture strings, not requested URLs. |
| `packages/quds_mail_store/CHANGELOG.md` | Documentation. |
| `docs/validation/mail-unified-cache-20261121/intake.md` | Recorded history/source audit and documented Git-only reproduction steps; no newly installed test hook. |
| `docs/validation/mail-unified-cache-20261121/intake.json` | Recorded Git/history evidence; no newly installed test hook. |

The new production and test source contains no cloud-metadata endpoint,
HTTP/socket client, subprocess invocation or environment-based credential
lookup. Searches of the frozen additions did not reveal an alternative such
call hidden behind a literal metadata address or credential identifier.

## Existing local-test setup

The tests' existing native setup was traced through:

- `packages/quds_office_editor/example/lib/studio_mail_draft_store_native.dart`
- `packages/quds_office_editor/example/lib/studio_mail_local_accounts.dart`

These openers call `openNativeMailStore` with local SQLite profiles. The new
tests supply their temporary directory explicitly, bypassing the application
support-directory platform lookup. The local account directory stores account
identity metadata; the reviewed setup does not acquire passwords or OAuth
tokens.

The frozen delta contains no changes to root/package `pubspec.yaml`,
`pubspec.lock`, runner configuration or test configuration. The Studio package
already declares HTTP and secure-storage dependencies; these declarations are
unchanged and do not themselves establish that these tests make requests.

## SDK metadata behavior and attribution limit

The separate `intake_audit` agent reported a source-level match in the existing
Flutter SDK, outside the incoming Mail branch:

- `packages/flutter_tools/lib/src/context_runner.dart` calls
  `globals.isRunningOnBot` before invoking the command runner.
- `packages/flutter_tools/lib/src/base/bot_detector.dart` can reach
  `AzureDetector`, whose detection path issues a GET to
  `http://169.254.169.254/metadata/instance` with `Metadata: true`.

This is a plausible SDK startup source for the metadata request and is distinct
from the incoming Mail code. The SDK finding is attributed to the intake
agent's inspection; this review did not execute or probe that path.

**Source inspection alone does not prove which actual startup invocation
produced the rejected request.** This report therefore does not claim a
verified runtime cause, a false positive by approval review, or successful
completion of the rejected action. Any subsequent isolated validation is a
separate run and must carry its own evidence.
