#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/cbbfa2f59b19')
REPO = ROOT / 'quds_office_suite'
STORE = REPO / 'packages/quds_mail_store'
STUDIO = REPO / 'packages/quds_office_editor/example'
OUT = ROOT / 'late-mail-validation'
DART = ROOT / 'flutter-sdk/bin/dart'
FLUTTER = ROOT / 'flutter-sdk/bin/flutter'
ENV = dict(os.environ, TMPDIR=str(ROOT / 'runtime-tmp'), PUB_CACHE=str(ROOT / 'pub-cache'))

STORE_TESTS = [
    'test/cached_header_search_test.dart',
    'test/repository_test.dart',
    'test/mailbox_views_test.dart',
    'test/mailbox_view_streams_test.dart',
    'test/sync_mailboxes_test.dart',
]
HOST_TESTS = [
    'test/studio_mail_cached_search_test.dart',
    'test/studio_mail_mailbox_store_test.dart',
    'test/studio_mail_mailbox_session_test.dart',
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs() -> dict[str, str]:
    paths = []
    for base in [STORE / 'lib', REPO / 'packages/quds_mail_core/lib', STUDIO / 'lib']:
        paths.extend(base.rglob('*.dart'))
    paths.extend(STORE / p for p in STORE_TESTS)
    paths.extend(STUDIO / p for p in HOST_TESTS)
    paths.extend([REPO / 'pubspec.lock', REPO / '.dart_tool/package_config.json'])
    return {str(p.relative_to(REPO)): sha(p) for p in sorted(set(paths))}


def run(label: str, args: list[str], cwd: Path) -> dict[str, object]:
    print(f'Starting {label}', flush=True)
    start = time.time()
    with (OUT / f'{label}.stdout').open('wb') as stdout, (OUT / f'{label}.stderr').open('wb') as stderr:
        done = subprocess.run(args, cwd=cwd, env=ENV, stdout=stdout, stderr=stderr, timeout=600)
    result = {
        'label': label, 'command': args, 'cwd': str(cwd),
        'exit_code': done.returncode, 'elapsed_seconds': round(time.time() - start, 3),
        'stdout_sha256': sha(OUT / f'{label}.stdout'),
        'stderr_sha256': sha(OUT / f'{label}.stderr'),
    }
    (OUT / f'{label}.receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print(f'Completed {label}: exit {done.returncode}', flush=True)
    return result


def counts(label: str) -> dict[str, object]:
    events = []
    for line in (OUT / f'{label}.stdout').read_text().splitlines():
        try:
            value = json.loads(line)
        except ValueError:
            continue
        if isinstance(value, dict):
            events.append(value)
    starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    suites = {e['suite']['id']: e['suite']['path'] for e in events if e.get('type') == 'suite'}
    results: dict[str, dict[str, int]] = {}
    for event in events:
        if event.get('type') != 'testDone' or event.get('hidden'):
            continue
        path = suites[starts[event['testID']]['suiteID']]
        result = event['result']
        results.setdefault(path, {})[result] = results.setdefault(path, {}).get(result, 0) + 1
    return {'suites': results, 'errors': [e for e in events if e.get('type') == 'error'], 'done': [e for e in events if e.get('type') == 'done']}


def main() -> None:
    OUT.mkdir(exist_ok=True)
    before = inputs()
    (OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
    commands = []
    commands.append(run('store-tests', [str(DART), 'test', '--reporter=json', *STORE_TESTS], STORE))
    commands.append(run('host-tests', [str(FLUTTER), 'test', '--no-pub', '--reporter=json', *HOST_TESTS], STUDIO))
    commands.append(run('store-analysis', [str(DART), 'analyze', '--fatal-infos',
        'lib/src/cached_header_search.dart', 'lib/src/repository.dart', 'test/cached_header_search_test.dart'], STORE))
    commands.append(run('host-analysis', [str(DART), 'analyze', '--fatal-infos',
        'lib/studio_mail_cached_search.dart', 'lib/studio_mail_mailbox_store.dart', 'test/studio_mail_cached_search_test.dart'], STUDIO))
    after = inputs()
    (OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
    result = {
        'frozen_incoming_head': '833ddd05ff8cdecb202d6db414e66b91f2332544',
        'merge_first_parent': 'aa72fa6b52c58168d943181e1201ab5ef8ef321b',
        'commands': commands,
        'store': counts('store-tests'), 'host': counts('host-tests'),
        'source_changes': [p for p in before.keys() | after.keys() if before.get(p) != after.get(p)],
    }
    (OUT / 'RESULTS.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'exit_codes': {c['label']: c['exit_code'] for c in commands}, 'store': result['store']['suites'], 'host': result['host']['suites'], 'source_changes': result['source_changes']}, indent=2), flush=True)


if __name__ == '__main__':
    main()
