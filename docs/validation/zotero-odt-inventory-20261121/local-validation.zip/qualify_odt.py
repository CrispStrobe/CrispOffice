import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/scratch/cbbfa2f59b19/quds_office_suite')
engine = root / 'packages/quds_office_engine'
output = Path('/workspace/scratch/cbbfa2f59b19/odt-validation')
output.mkdir(exist_ok=True)
dart = '/workspace/scratch/cbbfa2f59b19/flutter-sdk/bin/dart'
environment = os.environ.copy()
environment.update(TMPDIR='/workspace/scratch/cbbfa2f59b19/runtime-tmp',
                   PUB_CACHE='/workspace/scratch/cbbfa2f59b19/pub-cache',
                   CI='true', DART_SUPPRESS_ANALYTICS='true')
tests = sorted(set(engine.glob('test/*zotero*_test.dart')) |
               set(engine.glob('test/odf*_test.dart')) |
               set(engine.glob('test/odt*_test.dart')) |
               {engine / 'test/office_vba_text_intrinsics_test.dart',
                engine / 'test/office_vba_text_conformance_test.dart',
                engine / 'test/office_vba_word_text_integration_test.dart'})

def manifest():
    paths = set((engine / 'lib').rglob('*.dart')) | set(tests)
    paths |= {path for path in (engine / 'test/fixtures').rglob('*') if path.is_file()}
    paths |= set((root / 'packages/legacy_doc_parser/lib').rglob('*.dart'))
    paths |= {root / 'pubspec.lock', root / 'pubspec.yaml', engine / 'pubspec.yaml'}
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(paths)}

before = manifest()
(output / 'inputs-before.json').write_text(json.dumps(before, indent=2)+'\n')
command = [dart, 'test', '--reporter=json', '--concurrency=4',
           *[str(path.relative_to(engine)) for path in tests]]
start = time.time()
with (output / 'engine-regression.jsonl').open('w') as stdout, (output / 'engine-regression.stderr').open('w') as stderr:
    result = subprocess.run(command, cwd=engine, env=environment, stdout=stdout, stderr=stderr)
after = manifest()
(output / 'inputs-after.json').write_text(json.dumps(after, indent=2)+'\n')
events = [json.loads(line) for line in (output / 'engine-regression.jsonl').read_text().splitlines() if line.strip().startswith('{')]
ends = [event for event in events if event.get('type') == 'testDone' and not event.get('hidden', False)]
summary = {'command': command, 'cwd': str(engine), 'exit_code': result.returncode,
           'seconds': round(time.time()-start, 3), 'test_files': len(tests),
           'passed': sum(event.get('result') == 'success' and not event.get('skipped', False) for event in ends),
           'failed': sum(event.get('result') in ['failure', 'error'] for event in ends),
           'skipped': sum(bool(event.get('skipped', False)) for event in ends),
           'error_events': [event for event in events if event.get('type') == 'error'],
           'sources_unchanged': before == after,
           'changed_inputs': [path for path in set(before) | set(after) if before.get(path) != after.get(path)],
           'input_count': len(before),
           'dart_version': subprocess.check_output([dart, '--version'], env=environment, text=True).strip(),
           'done_events': [event for event in events if event.get('type') == 'done']}
(output / 'engine-regression-summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary, indent=2))
raise SystemExit(result.returncode or (0 if before == after else 2))
