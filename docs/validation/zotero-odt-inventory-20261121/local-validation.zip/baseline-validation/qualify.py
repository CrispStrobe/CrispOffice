#!/usr/bin/env python3
"""Run the reconciled Word/Mail cohort without resolving dependencies."""
from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

WORKSPACE = Path('/workspace/scratch/cbbfa2f59b19')
REPO = WORKSPACE / 'quds_office_suite'
OUTPUT = WORKSPACE / 'baseline-validation'
DART = WORKSPACE / 'flutter-sdk/bin/dart'
ENGINE = REPO / 'packages/quds_office_engine'
MAIL = REPO / 'packages/quds_mail_core'
CONFIG = REPO / '.dart_tool/package_config.json'
ENV = dict(
    os.environ,
    PUB_CACHE=str(WORKSPACE / 'pub-cache'),
    TMPDIR=str(WORKSPACE / 'runtime-tmp'),
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot() -> dict[str, str]:
    paths = []
    for root in [ENGINE / 'lib', MAIL / 'lib']:
        paths.extend(root.rglob('*.dart'))
    paths.extend(ENGINE.glob('test/office_vba*text*test.dart'))
    paths.extend(ENGINE.glob('test/support/*.dart'))
    paths.extend(ENGINE.glob('tool/macros/*text*.dart'))
    paths.extend([
        ENGINE / 'tool/macros/web_vba_conformance.dart',
        ENGINE / 'test/fixtures/vba_conformance/text_intrinsics_v1.json',
        ENGINE / 'example/macros/word_text_report.bas',
        MAIL / 'test/header_search_boolean_test.dart',
        REPO / 'pubspec.lock', CONFIG,
    ])
    return {str(path.relative_to(REPO)): digest(path) for path in sorted(set(paths))}


def run(label: str, argv: list[str], cwd: Path, timeout: int = 600) -> dict[str, object]:
    started = time.time()
    print(f'Starting {label}', flush=True)
    with (OUTPUT / f'{label}.stdout').open('wb') as out, (OUTPUT / f'{label}.stderr').open('wb') as err:
        result = subprocess.run(argv, cwd=cwd, env=ENV, stdout=out, stderr=err, timeout=timeout)
    receipt: dict[str, object] = {
        'label': label, 'cwd': str(cwd), 'argv': argv,
        'exit_code': result.returncode, 'elapsed_seconds': round(time.time() - started, 3),
        'stdout_sha256': digest(OUTPUT / f'{label}.stdout'),
        'stderr_sha256': digest(OUTPUT / f'{label}.stderr'),
    }
    (OUTPUT / f'{label}.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(f'Completed {label}: exit {result.returncode}, {receipt["elapsed_seconds"]}s', flush=True)
    return receipt


def portable(label: str, define: str, input_file: Path, driver: Path) -> list[dict[str, object]]:
    encoded = base64.b64encode(input_file.read_bytes()).decode('ascii')
    option = f'-D{define}={encoded}'
    output_js = OUTPUT / f'{label}.js'
    rows = [run(f'{label}-vm', [str(DART), f'--packages={CONFIG}', option, str(driver)], ENGINE)]
    rows.append(run(f'{label}-compile-js', [str(DART), 'compile', 'js', '-O1', f'--packages={CONFIG}', option, str(driver), '-o', str(output_js)], ENGINE))
    if rows[-1]['exit_code'] == 0:
        rows.append(run(f'{label}-node', ['node', '-e', 'globalThis.self=globalThis; require(process.argv[1]);', str(output_js)], ENGINE))
        if rows[0]['exit_code'] == 0 and rows[-1]['exit_code'] == 0:
            vm = (OUTPUT / f'{label}-vm.stdout').read_text().strip()
            node = (OUTPUT / f'{label}-node.stdout').read_text().strip()
            equal = json.loads(vm) == json.loads(node)
            comparison = {'label': label, 'json_equal': equal, 'bytes_equal': vm == node}
            (OUTPUT / f'{label}-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
            print(f'{label}: VM/Node JSON equal: {equal}', flush=True)
    return rows


def main() -> None:
    if not CONFIG.is_file():
        raise SystemExit('Package config is not ready; root must finish pub get first.')
    OUTPUT.mkdir(parents=True, exist_ok=True)
    before = snapshot()
    (OUTPUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
    commands = []
    commands.append(run('dart-version', [str(DART), '--version'], REPO))
    commands.append(run('word-text-tests', [str(DART), 'test', '--reporter=json',
        'test/office_vba_text_intrinsics_test.dart',
        'test/office_vba_text_conformance_test.dart',
        'test/office_vba_word_text_integration_test.dart'], ENGINE))
    commands.append(run('mail-boolean-tests', [str(DART), 'test', '--reporter=json',
        'test/header_search_boolean_test.dart'], MAIL))
    commands.extend(portable('text-conformance', 'VBA_CONFORMANCE_BASE64',
        ENGINE / 'test/fixtures/vba_conformance/text_intrinsics_v1.json',
        ENGINE / 'tool/macros/web_vba_text_conformance.dart'))
    commands.extend(portable('word-text-example', 'WORD_TEXT_BAS_BASE64',
        ENGINE / 'example/macros/word_text_report.bas',
        ENGINE / 'tool/macros/web_vba_word_text_smoke.dart'))
    after = snapshot()
    (OUTPUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
    receipt = {'commands': commands, 'inputs_changed': [key for key in before.keys() | after.keys() if before.get(key) != after.get(key)]}
    (OUTPUT / 'summary.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'commands': len(commands), 'failures': [x['label'] for x in commands if x['exit_code'] != 0], 'inputs_changed': receipt['inputs_changed']}, indent=2), flush=True)


if __name__ == '__main__':
    main()
