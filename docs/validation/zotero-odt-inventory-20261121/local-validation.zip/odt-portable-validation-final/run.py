#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/cbbfa2f59b19')
REPO = ROOT / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
OUT = ROOT / 'odt-portable-validation-final'
DART = ROOT / 'flutter-sdk/bin/dart'
CONFIG = REPO / '.dart_tool/package_config.json'
DRIVER = ENGINE / 'tool/zotero/odt_inventory_acceptance.dart'
CLI = ENGINE / 'tool/zotero/odt_inventory.dart'
ENV = dict(os.environ, TMPDIR=str(ROOT / 'runtime-tmp'), PUB_CACHE=str(ROOT / 'pub-cache'))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs() -> dict[str, str]:
    paths = list((ENGINE / 'lib').rglob('*.dart'))
    paths.extend([DRIVER, CLI, REPO / 'pubspec.lock', CONFIG])
    return {str(p.relative_to(REPO)): sha(p) for p in sorted(paths)}


def run(label: str, args: list[str], expected: int = 0) -> dict[str, object]:
    print(f'Starting {label}', flush=True)
    start = time.time()
    with (OUT / f'{label}.stdout').open('wb') as stdout, (OUT / f'{label}.stderr').open('wb') as stderr:
        done = subprocess.run(args, cwd=ENGINE, env=ENV, stdout=stdout, stderr=stderr, timeout=600)
    receipt = {
        'label': label, 'command': args, 'cwd': str(ENGINE),
        'exit_code': done.returncode, 'expected_exit_code': expected,
        'elapsed_seconds': round(time.time() - start, 3),
        'stdout_sha256': sha(OUT / f'{label}.stdout'),
        'stderr_sha256': sha(OUT / f'{label}.stderr'),
    }
    (OUT / f'{label}.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(f'Completed {label}: exit {done.returncode}', flush=True)
    if done.returncode != expected:
        raise RuntimeError(f'{label} exited {done.returncode}, expected {expected}')
    return receipt


def main() -> None:
    OUT.mkdir(exist_ok=True)
    before = inputs()
    (OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
    commands = []
    commands.append(run('dart-version', [str(DART), '--version']))
    commands.append(run('analyze', [str(DART), 'analyze', '--fatal-infos', str(DRIVER)]))
    commands.append(run('vm', [str(DART), f'--packages={CONFIG}', str(DRIVER)]))
    javascript = OUT / 'odt-inventory.js'
    commands.append(run('compile-js', [str(DART), 'compile', 'js', '-O1', f'--packages={CONFIG}', str(DRIVER), '-o', str(javascript)]))
    commands.append(run('node', ['node', '-e', 'globalThis.self=globalThis; require(process.argv[1]);', str(javascript)]))
    vm_text = (OUT / 'vm.stdout').read_text()
    node_text = (OUT / 'node.stdout').read_text()
    assert vm_text == node_text, 'VM/Node receipts differ'
    vm = json.loads(vm_text)

    writer = OUT / 'write_fixture.dart'
    writer.write_text("import 'dart:io';\n" +
        "import '" + DRIVER.as_uri() + "' as fixture;\n" +
        "void main(List<String> args) {\n" +
        "  File('${args.single}/native-inventory.odt').writeAsBytesSync(fixture.nativeInventoryFixture());\n" +
        "  File('${args.single}/malformed-inventory.odt').writeAsBytesSync(fixture.malformedInventoryFixture());\n" +
        "}\n")
    commands.append(run('fixture-writer', [str(DART), f'--packages={CONFIG}', str(writer), str(OUT)]))
    native = OUT / 'native-inventory.odt'
    malformed = OUT / 'malformed-inventory.odt'
    native_before = sha(native)
    malformed_before = sha(malformed)
    commands.append(run('cli-native', [str(DART), f'--packages={CONFIG}', str(CLI), str(native)]))
    cli = json.loads((OUT / 'cli-native.stdout').read_text())
    assert cli == vm['inventory'], 'CLI/direct inventory differs'
    assert sha(native) == native_before, 'CLI changed native ODT input'
    commands.append(run('cli-malformed', [str(DART), f'--packages={CONFIG}', str(CLI), str(malformed)], expected=65))
    assert (OUT / 'cli-malformed.stdout').read_bytes() == b'', 'Malformed CLI printed successful JSON'
    assert sha(malformed) == malformed_before, 'CLI changed malformed ODT input'
    after = inputs()
    (OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
    result = {
        'native_plugin_commit': vm['nativePluginCommit'],
        'fixture_kind': vm['fixtureKind'],
        'vm_node_bytes_equal': True,
        'cli_matches_portable_inventory': True,
        'native_input_unchanged': True,
        'malformed_input_unchanged': True,
        'native_fixture_sha256': native_before,
        'malformed_fixture_sha256': malformed_before,
        'field_count': len(cli['fields']),
        'paragraph_count': cli['paragraphCount'],
        'preferences_chunks': len([p for p in cli['preferences']['properties'] if p['family'] is not None]),
        'guards': {
            'cross_cell_ineligible': not vm['guardedCrossCell']['isImportCandidate'],
            'malformed_xml_rejected': vm['malformedPackageRejected'],
            'field_budget_rejected': vm['fieldBudgetRejected'],
        },
        'source_changes': [p for p in before.keys() | after.keys() if before.get(p) != after.get(p)],
        'commands': commands,
    }
    (OUT / 'RESULTS.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'commands'}, indent=2), flush=True)


if __name__ == '__main__':
    main()
