import 'dart:io';
import 'file:///workspace/scratch/cbbfa2f59b19/quds_office_suite/packages/quds_office_engine/tool/zotero/odt_inventory_acceptance.dart' as fixture;
void main(List<String> args) {
  File('${args.single}/native-inventory.odt').writeAsBytesSync(fixture.nativeInventoryFixture());
  File('${args.single}/malformed-inventory.odt').writeAsBytesSync(fixture.malformedInventoryFixture());
}
