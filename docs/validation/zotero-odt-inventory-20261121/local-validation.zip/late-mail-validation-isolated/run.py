#!/usr/bin/env python3
from __future__ import annotations

import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/cbbfa2f59b19')
REPO = ROOT / 'quds_office_suite'
STORE = REPO / 'packages/quds_mail_store'
STUDIO = REPO / 'packages/quds_office_editor/example'
OUT = ROOT / 'late-mail-validation-isolated'
DART = ROOT / 'flutter-sdk/bin/dart'
FLUTTER = ROOT / 'flutter-sdk/bin/flutter'
SCOPED_ENV = dict(BOT='true', CI='true', FLUTTER_SUPPRESS_ANALYTICS='true',
    TMPDIR=str(ROOT / 'runtime-tmp'), PUB_CACHE=str(ROOT / 'pub-cache'))
ENV = dict(os.environ, **SCOPED_ENV)
STORE_FILES = ['lib/src/cached_header_search.dart', 'lib/src/repository.dart',
    'test/cached_header_search_test.dart']
HOST_FILES = ['lib/studio_mail_cached_search.dart', 'lib/studio_mail_mailbox_store.dart',
    'test/studio_mail_cached_search_test.dart']
HOST_TESTS = ['test/studio_mail_cached_search_test.dart',
    'test/studio_mail_mailbox_store_test.dart', 'test/studio_mail_mailbox_session_test.dart']
STORE_TESTS = ['test/cached_header_search_test.dart', 'test/repository_test.dart',
    'test/mailbox_views_test.dart', 'test/mailbox_view_streams_test.dart',
    'test/sync_mailboxes_test.dart']

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inputs():
    paths = set()
    for base in [STORE / 'lib', REPO / 'packages/quds_mail_core/lib', STUDIO / 'lib']:
        paths.update(base.rglob('*.dart'))
    paths.update(STORE / p for p in STORE_TESTS)
    paths.update(STUDIO / p for p in HOST_TESTS)
    paths.update([REPO / 'pubspec.lock', REPO / '.dart_tool/package_config.json'])
    return {str(p.relative_to(REPO)): sha(p) for p in sorted(paths)}

def proof(host_netns, enable_loopback=False):
    netns = os.readlink('/proc/self/ns/net')
    assert netns != host_netns, 'Network namespace isolation is mandatory'
    # Read the current namespace directly; netlink enumeration is sandboxed.
    interfaces = sorted(line.split(':', 1)[0].strip()
        for line in Path('/proc/self/net/dev').read_text().splitlines()[2:])
    assert interfaces == ['lo'], interfaces
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as control:
        request = struct.pack('16sH22x', b'lo', 0)
        flags = struct.unpack_from('H', fcntl.ioctl(control, 0x8913, request), 16)[0]
        if enable_loopback:
            fcntl.ioctl(control, 0x8914, struct.pack('16sH22x', b'lo', flags | 1))
            flags = struct.unpack_from('H', fcntl.ioctl(control, 0x8913, request), 16)[0]
        assert flags & 1, 'Loopback did not come up'
    routes4 = Path('/proc/self/net/route').read_text()
    routes6 = Path('/proc/self/net/ipv6_route').read_text()
    external = [line for line in routes4.splitlines()[1:] if line.split()[0] != 'lo']
    external.extend(line for line in routes6.splitlines() if line.split()[-1] != 'lo')
    assert not external, external
    return dict(network_namespace=netns, parent_network_namespace=host_netns,
        user_namespace=os.readlink('/proc/self/ns/user'), interfaces=interfaces,
        loopback_flags=flags, loopback_up=bool(flags & 1), external_routes=external,
        ipv4_route_table=routes4, ipv6_route_table=routes6,
        captured_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())

def run(label, args, cwd):
    print('Starting ' + label, flush=True)
    start = time.monotonic()
    with (OUT / (label + '.stdout')).open('wb') as stdout, (OUT / (label + '.stderr')).open('wb') as stderr:
        try:
            done = subprocess.run(args, cwd=cwd, env=ENV, stdout=stdout, stderr=stderr, timeout=600)
            code = done.returncode
        except subprocess.TimeoutExpired:
            code = 124
    result = dict(label=label, command=args, cwd=str(cwd), scoped_environment=SCOPED_ENV,
        exit_code=code, elapsed_seconds=round(time.monotonic()-start, 3),
        stdout_sha256=sha(OUT / (label+'.stdout')), stderr_sha256=sha(OUT / (label+'.stderr')))
    write(label+'.receipt.json', result)
    print('Completed ' + label + ': exit ' + str(code), flush=True)
    return result

def counts():
    events = []
    for line in (OUT / 'host-tests.stdout').read_text().splitlines():
        try:
            event = json.loads(line)
            if isinstance(event, dict): events.append(event)
        except ValueError:
            pass
    starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    suites = {e['suite']['id']: e['suite']['path'] for e in events if e.get('type') == 'suite'}
    results = {}
    for event in events:
        if event.get('type') != 'testDone' or event.get('hidden'): continue
        path = suites[starts[event['testID']]['suiteID']]
        outcome = 'skipped' if event.get('skipped') else event['result']
        results.setdefault(path, {})[outcome] = results.setdefault(path, {}).get(outcome, 0) + 1
    return dict(suites=results, errors=[e for e in events if e.get('type') == 'error'],
        done=[e for e in events if e.get('type') == 'done'])

def main():
    OUT.mkdir(exist_ok=True)
    if len(sys.argv) == 1:
        host_netns = os.readlink('/proc/self/ns/net')
        args = ['/usr/bin/unshare', '--user', '--map-root-user', '--net',
            sys.executable, str(Path(__file__).resolve()), '--inside-netns', host_netns]
        write('launch.json', dict(command=args, scoped_environment=SCOPED_ENV,
            parent_network_namespace=host_netns, runner_sha256=sha(Path(__file__))))
        os.execvpe(args[0], args, ENV)
    assert len(sys.argv) == 3 and sys.argv[1] == '--inside-netns'
    host_netns = sys.argv[2]
    write('network-before.json', proof(host_netns, enable_loopback=True))
    print('Isolated runner active; only lo interface, no external route', flush=True)
    before = inputs()
    write('inputs-before.json', before)
    commands = []
    commands.append(run('host-tests', [str(FLUTTER), '--no-version-check', 'test',
        '--no-pub', '--reporter=json', *HOST_TESTS], STUDIO))
    commands.append(run('store-analysis', [str(DART), 'analyze', '--fatal-infos', *STORE_FILES], STORE))
    commands.append(run('host-analysis', [str(DART), 'analyze', '--fatal-infos', *HOST_FILES], STUDIO))
    commands.append(run('format', [str(DART), 'format', '--output=none', '--set-exit-if-changed',
        *[str(STORE / p) for p in STORE_FILES], *[str(STUDIO / p) for p in HOST_FILES]], REPO))
    after = inputs()
    write('inputs-after.json', after)
    write('network-after.json', proof(host_netns))
    result = dict(frozen_incoming_head='833ddd05ff8cdecb202d6db414e66b91f2332544',
        isolated=True, commands=commands, host=counts(), input_count=len(before),
        source_changes=sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p)))
    write('RESULTS.json', result)
    print(json.dumps(result, indent=2), flush=True)

if __name__ == '__main__':
    main()
