#!/usr/bin/env python3
"""Run unchanged quality replay one panel at a time and seal each completed panel."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tarfile


def pin(path):
    with path.open('rb') as handle:
        digest = hashlib.file_digest(handle, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': digest}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('source-root', 'build-dir', 'panels', 'output-dir', 'helpers',
                 'bundle-dir', 'library', 'checkpoint-dir'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--library-sha256', required=True)
    parser.add_argument('--label', required=True)
    args = parser.parse_args()
    # The retained runner changes cwd for the AOT process. Keep every path
    # absolute so model admission is independent of that source-root cwd.
    for name, value in vars(args).items():
        if isinstance(value, Path):
            setattr(args, name, value.resolve())
    output = args.output_dir.resolve()
    checkpoints = args.checkpoint_dir.resolve()
    if output.exists() or checkpoints.exists():
        raise ValueError('Use fresh output and checkpoint directories.')
    checkpoints.mkdir(parents=True)
    helper = args.helpers.resolve() / 'run_quality_replay.py'
    auditor_path = args.helpers.resolve() / 'compare_quality_replay.py'
    spec = importlib.util.spec_from_file_location('quality_auditor', auditor_path)
    auditor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(auditor)
    manifest = json.loads(args.panels.read_text())
    build_path = args.build_dir.resolve() / 'quality-build.json'
    build = json.loads(build_path.read_text())
    for panel in manifest['panels']:
        command = [sys.executable, str(helper), '--source-root', str(args.source_root),
                   '--build-dir', str(args.build_dir), '--panels', str(args.panels),
                   '--output-dir', str(output), '--bundle-dir', str(args.bundle_dir),
                   '--library', str(args.library), '--library-sha256', args.library_sha256,
                   '--only', panel['name'], '--execute']
        driver_log = checkpoints / (args.label + '-' + panel['name'] + '.driver.log')
        print('PANEL_START ' + args.label + ' ' + panel['name'], flush=True)
        with driver_log.open('x') as handle:
            result = subprocess.run(command, check=False, stdout=handle, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f"Panel {panel['name']} failed; partial raw evidence is retained.")
        corpus = args.panels.parent / panel['run_file']
        report_path = output / (panel['name'] + '.json')
        report, rows = auditor.verify_report(report_path, corpus, build, panel['run_sha256'])
        summary = {
            'label': args.label, 'panel': panel['name'], 'cases': len(rows),
            'independently_reconstructed': True, 'source_build_bound': True,
            'completed_utc': datetime.now(timezone.utc).isoformat(),
            'metrics_by_language': {language: {
                lane: auditor.metrics([r for r in rows if r['language'] == language], lane)
                for lane in auditor.LANES} for language in sorted({r['language'] for r in rows})},
            'scope': 'Four-lane reused synthetic quality regression; durations are diagnostic only.',
        }
        audit_path = output / (panel['name'] + '-audit.json')
        audit_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
        files = [report_path, output / (panel['name'] + '.log'),
                 output / (panel['name'] + '-invocation.json'), audit_path]
        members = [(p, 'results/' + p.name) for p in files]
        members.extend([(driver_log, 'results/driver.log'), (build_path, 'build/quality-build.json'),
                        (corpus, 'panel/' + corpus.name),
                        (helper, 'helpers/' + helper.name),
                        (auditor_path, 'helpers/' + auditor_path.name)])
        archive = checkpoints / (args.label + '-' + panel['name'] + '.tar.xz')
        with tarfile.open(archive, 'w:xz') as stream:
            for path, name in members:
                stream.add(path, arcname=name, recursive=False)
        index = {'archive': archive.name, **pin(archive), 'label': args.label,
                 'panel': panel['name'], 'independently_audited': True,
                 'members': [{'path': name, **pin(path)} for path, name in members]}
        archive.with_suffix('.index.json').write_text(json.dumps(index, indent=2) + '\n')
        print('CHECKPOINT_READY ' + json.dumps({k: index[k] for k in
              ('archive', 'sha256', 'bytes', 'label', 'panel')}), flush=True)


if __name__ == '__main__':
    main()
