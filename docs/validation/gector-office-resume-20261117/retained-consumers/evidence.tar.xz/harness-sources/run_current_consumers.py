#!/usr/bin/env python3
"""Run the retained 33 + 7 + boundary 5 consumers without modifying harnesses."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo).decode().strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('source-repo', 'workspace', 'dart', 'runtime', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--commit', required=True)
    args = parser.parse_args()
    source, workspace, dart, runtime, output = [path.resolve() for path in
        (args.source_repo, args.workspace, args.dart, args.runtime, args.output)]
    assert git(source, 'rev-parse', 'HEAD') == args.commit, 'Source HEAD differs'
    assert not git(source, 'diff', '--name-only', args.commit, '--',
                   'packages/quds_office_engine/lib', 'packages/legacy_doc_parser/lib')
    output.mkdir(parents=True, exist_ok=False)
    logs = output / 'orchestrator-logs'
    logs.mkdir()
    reference = runtime / 'retained-reference'
    schemas = reference / 'schemas'
    boundary = source / 'docs/validation/office-reconciled-20261117/resume/consumer-new'
    common = ['--repo', str(workspace), '--source-repo', str(source),
              '--expected-head', args.commit, '--dart', str(dart), '--schemas', str(schemas)]
    commands = [
        ('retained-33', [sys.executable, '-B', str(reference / 'wave3-runner/verify_consumers.py'),
                         *common, '--output', str(output / 'retained-33')]),
        ('retained-7', [sys.executable, '-B', str(reference / 'verify_current_consumers.py'),
                        *common, '--output', str(output / 'retained-7')]),
        ('boundary-5', [sys.executable, '-B', str(boundary / 'verify_boundary_consumers.py'),
                        '--repo', str(source), '--workspace', str(workspace),
                        '--dart', str(dart), '--schemas', str(schemas),
                        '--output', str(output / 'boundary-5'), '--commit', args.commit]),
    ]
    harness_files = [Path(__file__).resolve(),
                     *reference.joinpath('wave3-runner').glob('*.py'),
                     *reference.joinpath('wave3-runner').glob('*.dart'),
                     *reference.joinpath('wave3-runner').glob('*.json'),
                     reference / 'runner-source/make_fixtures.dart',
                     reference / 'runner-source/verify_consumers.py',
                     reference / 'verify_current_consumers.py',
                     reference / 'check_current_consumers.py',
                     reference / 'make_current_fixtures.dart',
                     reference / 'tools/jing-20241231.jar',
                     boundary / 'verify_boundary_consumers.py',
                     boundary / 'make_boundary_fixtures.dart',
                     *schemas.glob('*.rng')]
    harness_before = {str(path): sha(path) for path in sorted(set(harness_files))}
    environment = dict(os.environ, TMPDIR=str(runtime / 'tmp'),
                       XDG_CONFIG_HOME=str(runtime / 'config'),
                       PYTHONDONTWRITEBYTECODE='1', DART_SUPPRESS_ANALYTICS='true',
                       FLUTTER_SUPPRESS_ANALYTICS='true', CI='true')
    receipt = {'started_at_utc': now(), 'source_commit': args.commit,
               'source_tree': git(source, 'rev-parse', args.commit + '^{tree}'),
               'source_repository': str(source), 'workspace': str(workspace),
               'harnesses_before': harness_before, 'runs': [],
               'scope': 'Unchanged retained 33, retained 7, and PR144 boundary 5 consumer harnesses.',
               'historical_outcomes_counted': False,
               'github_actions_queried_or_awaited': False}
    save(output / 'orchestration.json', receipt)
    for name, argv in commands:
        assert git(source, 'rev-parse', 'HEAD') == args.commit, 'Source HEAD changed between gates'
        print(json.dumps({'starting': name, 'at_utc': now()}), flush=True)
        started = time.monotonic()
        row = {'name': name, 'argv': argv, 'cwd': str(source), 'started_at_utc': now()}
        stdout, stderr = logs / (name + '.stdout'), logs / (name + '.stderr')
        try:
            with stdout.open('wb') as out, stderr.open('wb') as err:
                result = subprocess.run(argv, cwd=source, env=environment, stdout=out,
                                        stderr=err, timeout=1800)
            row['exit_code'] = result.returncode
        except subprocess.TimeoutExpired:
            row.update(exit_code=None, error='Outer 1800-second timeout')
        row.update(finished_at_utc=now(), duration_seconds=round(time.monotonic() - started, 3),
                   stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
        path = output / name / 'receipt.json'
        if path.is_file():
            child = json.loads(path.read_text())
            row.update(receipt_sha256=sha(path), passed=child.get('passed', False),
                       summary=child.get('summary'), fatal_error=child.get('fatal_error'),
                       error=child.get('error'))
            if name == 'boundary-5':
                row['summary'] = {'fixtures': len(child.get('fixtures', [])),
                                  'pdf_variants': sum(len(f.get('variants', {}))
                                                      for f in child.get('fixtures', [])),
                                  'inputs_unchanged': child.get('inputs_unchanged')}
        else:
            row.update(passed=False, fatal_error='No child receipt observed')
        receipt['runs'].append(row)
        save(output / 'orchestration.json', receipt)
        print(json.dumps({key: row.get(key) for key in
                          ('name', 'exit_code', 'passed', 'summary', 'fatal_error', 'error')}), flush=True)
    receipt.update(finished_at_utc=now(),
                   head_unchanged=git(source, 'rev-parse', 'HEAD') == args.commit,
                   harnesses_unchanged=harness_before ==
                       {str(path): sha(path) for path in sorted(set(harness_files))})
    receipt['passed'] = all(row['exit_code'] == 0 and row['passed'] for row in receipt['runs']) \
        and receipt['head_unchanged'] and receipt['harnesses_unchanged']
    save(output / 'orchestration.json', receipt)
    print(json.dumps({key: receipt[key] for key in
                      ('passed', 'head_unchanged', 'harnesses_unchanged')}), flush=True)
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
