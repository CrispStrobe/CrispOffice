# Consumer runtime recovery

The existing primary runtime already supplies the exact consumer versions retained in the source evidence. No external download or system installation was required.

Run `source /workspace/scratch/9d517eae36bf/consumer-runtime/env.sh` before the source-bound consumer runners. The environment points `TMPDIR` and `XDG_CONFIG_HOME` into writable scratch because the system's default `/tmp` is absent.

## Verified identities

- LibreOfficeDev 26.8.0.0.alpha0, build `2c87e51eeaa2b413ff4ae097b2705eea1995d8e5`.
- Poppler `pdftotext` 25.03.0; `pdfinfo` and `pdftoppm` 26.05.0.
- OpenJDK 21.0.13.
- lxml 6.1.1 / libxml2 2.14.6.
- Jing 20241231 JAR SHA-256 `ea5e9026244d977e607d8b52212d6871498ece51939f9c49d0e7a77aad91133a`.
- Official ODF 1.3 main schema SHA-256 `40bad03efdbb02825230d357da0aa6ac679934c5bf56c6281752c0c24d58e4e6`.
- Official ODF 1.3 manifest schema SHA-256 `8aee71f03484be112af972d622cc9031280c007b0a454ae8815e8e333c9bdd17`.

The exact source archive `consumer-intermediate-1d8325d4.tar.xz` was verified as SHA-256 `49b519e8ef949a3dd6ff6cf1befa7f0264b90dab23da932aaa93879afc2e2951`. All 710 members were checked against the versioned member index before and after recovery. Their unchanged copies live in `retained-reference/`. The installed LibreOffice/Poppler tools and libraries match all 3,504 relevant file hashes in the retained runtime map. The full per-file comparison is in `recovery.json`.

## Ready runners

The recovered archive contains the unchanged `wave3-runner/verify_consumers.py` (33 fixtures), `verify_current_consumers.py` (7 current controls), supporting Dart fixture generators, exact schemas, Jing, and historical consumer evidence. Product verification needs root's resolved Dart/Flutter workspace and a frozen current source commit; this runtime setup does not certify a product version.

The scoped boundary runner remains in the repository at `docs/validation/office-reconciled-20261117/resume/consumer-new/verify_boundary_consumers.py`. It receives the same schema directory through `--schemas "$ODF_SCHEMAS"`.

Four unchanged Jing controls were freshly replayed: two valid styled-page-count inputs pass; illegal attribute/child inputs fail. Jing's existing `-i` flag disables optional DTD compatibility identity checks, preserving ordinary RelaxNG schema validation. A historical ODT was also converted by the recovered LibreOffice build and extracted using pdftotext. Those smoke receipts explicitly do not claim current source qualification.

## Reproduction

```sh
python3 restore_runtime.py --repo /path/to/quds_office_suite --output /path/to/consumer-runtime
python3 verify_runtime.py --root /path/to/consumer-runtime
source /path/to/consumer-runtime/env.sh
```

The smoke runner refuses to overwrite an attempt. The recovery runner uses only the repository's saved archive and currently available binaries; it never probes prior conversation workspaces. Its source archive retains the original OASIS/Maven URLs, publisher metadata and licensing notices.
