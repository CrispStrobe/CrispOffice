"""Disable incidental telemetry for isolated local qualification processes.

This external startup hook changes no repository modules or inference settings.
Test-only stand-in modules without a telemetry API are left intact.
"""
import os

os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("PIP_DISABLE_PIP_VERSION_CHECK", "1")
os.environ.setdefault("DASH__SUPPRESS_ANALYTICS", "true")
os.environ.setdefault("FLUTTER_SUPPRESS_ANALYTICS", "true")

try:
    import onnxruntime
except ImportError:
    pass
else:
    disable = getattr(onnxruntime, "disable_telemetry_events", None)
    if callable(disable):
        disable()
