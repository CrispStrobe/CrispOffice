from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, signal, subprocess, time
ROOT=Path('/workspace/scratch/711adbe4f480')
REPO=ROOT/'quds_office_suite'
ENGINE=REPO/'packages/quds_office_engine'
OUT=ROOT/'validation-quality'
TOOLS=ROOT/'toolchain'
BINARY=TOOLS/'spelling-smoke-quality'
JS=TOOLS/'spelling-smoke-quality.js'

def now(): return datetime.now(timezone.utc).isoformat()
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def sources():
 paths=set((ENGINE/'lib').rglob('*.dart')) | set((ENGINE/'test/proofing').rglob('*.dart'))
 paths.update([ENGINE/'tool/check_native_spelling.dart',ENGINE/'pubspec.yaml',REPO/'pubspec.yaml',REPO/'pubspec.lock'])
 return {str(p.relative_to(REPO)):digest(p) for p in sorted(paths)}
receipt={'started_at':now(),'head_at_start':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'source_before':sources(),'commands':[],'status':'running'}
def save(): (OUT/'engine-final.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(label,args,cwd,stdout,stderr,timeout=900):
 print('START',label,flush=True)
 began=time.monotonic(); start=now(); before=sources()
 with (OUT/stdout).open('wb') as out,(OUT/stderr).open('wb') as err:
  p=subprocess.Popen(args,cwd=cwd,stdout=out,stderr=err,start_new_session=True)
  try: code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try: p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   code=124
 after=sources()
 record={'label':label,'argv':args,'cwd':str(cwd),'started_at':start,'finished_at':now(),'elapsed_seconds':time.monotonic()-began,'exit_code':code,'stdout':stdout,'stderr':stderr,'stdout_sha256':digest(OUT/stdout),'stderr_sha256':digest(OUT/stderr),'source_unchanged':before==after==receipt['source_before']}
 receipt['commands'].append(record);save();print('END',label,'exit',code,'seconds',round(record['elapsed_seconds'],2),flush=True)
 if code or not record['source_unchanged']:raise RuntimeError(label+' failed or source changed')
try:
 save()
 run('proofing-tests',['dart','test','test/proofing','--reporter','json','--concurrency=2'],ENGINE,'engine-final.jsonl','engine-final.stderr')
 events=[json.loads(l) for l in (OUT/'engine-final.jsonl').read_text().splitlines() if l.startswith('{')]
 names={e['test']['id']:e['test']['name'] for e in events if e['type']=='testStart'}
 done=[e for e in events if e['type']=='testDone' and not e.get('hidden') and not names.get(e['testID'],'').startswith('loading ')]
 receipt['tests']={'files':len(list((ENGINE/'test/proofing').rglob('*_test.dart'))),'passed':sum(e['result']=='success' and not e.get('skipped') for e in done),'failed':sum(e['result']!='success' for e in done),'skipped':sum(bool(e.get('skipped')) for e in done),'final_event':events[-1]}
 run('engine-analysis',['dart','analyze','--fatal-infos','lib/src/proofing','test/proofing','tool/check_native_spelling.dart'],ENGINE,'engine-final.analysis.log','engine-final.analysis.stderr')
 run('native-build',['dart','compile','exe','tool/check_native_spelling.dart','-o',str(BINARY)],ENGINE,'smoke-native-build.log','smoke-native-build.stderr')
 run('native-run',[str(BINARY)],ENGINE,'smoke-native.json','smoke-native.stderr')
 run('javascript-build',['dart','compile','js','-O2','tool/check_native_spelling.dart','-o',str(JS)],ENGINE,'smoke-js-build.log','smoke-js-build.stderr')
 run('javascript-run',['node','-e','globalThis.self=globalThis;require(process.argv[1]);',str(JS)],ENGINE,'smoke-js.json','smoke-js.stderr')
 panels={label:json.loads((OUT/name).read_text()) for label,name in [('vm','smoke-vm.json'),('native','smoke-native.json'),('javascript','smoke-js.json')]}
 assert panels['vm']==panels['native']==panels['javascript'],'Full smoke result objects differ'
 assert panels['vm']['caseCount']==25 and panels['vm']['failed']==0
 receipt['smoke']={'full_objects_equal':True,'cases_per_target':25,'target_count':3,'executions':75,'executable_sha256':digest(BINARY),'javascript_sha256':digest(JS),'vm_sha256':digest(OUT/'smoke-vm.json'),'native_sha256':digest(OUT/'smoke-native.json'),'js_sha256':digest(OUT/'smoke-js.json')}
 receipt['status']='passed'
except Exception as exc:
 receipt.update(status='failed',error=str(exc))
finally:
 receipt['source_after']=sources();receipt['source_unchanged']=receipt['source_before']==receipt['source_after'];receipt['finished_at']=now();save()
 print(json.dumps({k:v for k,v in receipt.items() if k not in ['source_before','source_after','commands']},indent=2),flush=True)
raise SystemExit(receipt['status']!='passed')
