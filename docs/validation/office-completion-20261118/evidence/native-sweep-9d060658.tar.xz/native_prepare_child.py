"""Build the recorded native provider and check its existing evidence auditor."""
import argparse
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import subprocess
import sys

parser=argparse.ArgumentParser()
for name in ('repo','workspace','dart','output'):parser.add_argument('--'+name,type=Path,required=True)
args=parser.parse_args()
args.output.mkdir(exist_ok=False)
commands=[
 ('audit-controls',[sys.executable,args.repo/'docs/validation/german-gector/2026-11-17-followup/native-threads/check_thread_sweep_audit.py','--source-root',args.repo,'--output',args.output/'audit-controls.json']),
 ('provider-build',[sys.executable,args.repo/'tools/proofing/german_model/build_gector_aot.py','--source-root',args.workspace,'--dart',args.dart,'--output',args.output/'provider.aot','--receipt',args.output/'provider-build.json']),
]
receipts=[]
for label,argv in commands:
    row={'label':label,'argv':list(map(str,argv)),'started_utc':datetime.now(timezone.utc).isoformat()};receipts.append(row)
    (args.output/'commands.json').write_text(json.dumps(receipts,indent=2)+'\n')
    with (args.output/(label+'.stdout')).open('wb') as stdout,(args.output/(label+'.stderr')).open('wb') as stderr:
        result=subprocess.run(row['argv'],cwd=args.repo,stdout=stdout,stderr=stderr,timeout=300)
    row.update(exit_code=result.returncode,finished_utc=datetime.now(timezone.utc).isoformat())
    (args.output/'commands.json').write_text(json.dumps(receipts,indent=2)+'\n')
    assert result.returncode==0,label
print(json.dumps({'passed':True,'audit_controls':str(args.output/'audit-controls.json'),'provider_build':str(args.output/'provider-build.json')}),flush=True)
