#!/usr/bin/env python3
"""Read-only independent audit of current Flutter/workspace restoration."""
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from urllib.parse import urlparse, unquote
import yaml

sys.dont_write_bytecode = True
ROOT = Path("/workspace/scratch/21605f06e47d")
REPO = ROOT / "qualification-source"
DATA = ROOT / "flutter-qualification"
SDK = ROOT / "toolchains/flutter"
CACHE = ROOT / "toolchains/pub-cache"
WORK = DATA / "workspace"
OUT = ROOT / "continuation/runtime-review"
SOURCE = "9d060658ee6be8ec97d73f56b9aec10d346b7952"
FRAMEWORK = "737ba8f885dc774b53b442759999a312c9461e4e"
ENGINE = "cf636b1dfb818dd6a3ff16e390e93b1a036969c8"
LOCK = "344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130"
ARCHIVE = "baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2"
findings = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def fsha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def check(value, name, details=None):
    if not value:
        findings.append({"check":name,"details":details})
    return bool(value)

def git(repo,*args):
    return subprocess.check_output(["git","-C",str(repo),*args],
        env=dict(os.environ,GIT_OPTIONAL_LOCKS="0"))

def save(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")

def compressed(name,value):
    data=json.dumps(value,sort_keys=True,separators=(",",":")).encode()
    target=OUT/name
    target.write_bytes(gzip.compress(data,mtime=0))
    return {"path":name,"bytes":len(data),"sha256":sha(data),
            "compressed_bytes":target.stat().st_size,"compressed_sha256":fsha(target)}

def git_tree(repo,commit):
    result={}
    for row in git(repo,"ls-tree","-r","-z",commit).split(b"\0"):
        if not row:
            continue
        meta,name=row.split(b"\t",1)
        mode,kind,blob=meta.decode().split()
        if kind=="blob":
            result[name.decode()]={"mode":mode,"blob":blob}
    return result

prewarm_path=DATA/"setup/prewarm-receipt.json"
if not prewarm_path.exists():
    raise SystemExit("Prewarm not finished: receipt does not exist")
prewarm=read(prewarm_path)
if "package_config_after" not in prewarm:
    raise SystemExit("Prewarm not finished: final config marker absent")
started=datetime.now(timezone.utc).isoformat()
OUT.mkdir(parents=True,exist_ok=True)
check(prewarm.get('unchanged') and prewarm['package_config_before']==prewarm['package_config_after'],
      'prewarm-config-stable')
check(len(prewarm.get('commands',[]))==2,'prewarm-command-count')
for row in prewarm.get('commands',[]):
    check(row['exit_code']==0 and fsha(DATA/'setup'/(row['name']+'.log'))==row['log_sha256'],
          'prewarm-command-exit-log',row['name'])
report_path=OUT/"current-restoration-audit.json"
if report_path.exists():
    raise SystemExit("Audit report already exists; preserve it rather than overwrite")
head_before=git(REPO,"rev-parse","HEAD").decode().strip()
status_before=git(REPO,"status","--porcelain").decode().strip()
check(head_before==SOURCE and status_before=="","source-clean-at-start",{"head":head_before,"status":status_before})
old_source="9a7c80be00258def2dcae3bb288c28558c83aa72"
non_docs_delta=[p for p in git(REPO,"diff","--name-only",old_source,SOURCE).decode().splitlines()
                if not p.startswith("docs/")]
check(not non_docs_delta,"implementation-equivalent-to-prior-source",non_docs_delta)

original=(ROOT/"continuation/flutter-restoration/setup/restore_compact_flutter.py").read_bytes()
adapted=(ROOT/"continuation/restore_compact_flutter.py").read_bytes()
check(adapted==original.replace(b"/workspace/scratch/eddfdfc8cc56",str(ROOT).encode()).replace(b"REPO = ROOT / 'quds_office_suite'", b"REPO = ROOT / 'qualification-source'"),
      "restore-recipe-path-only")
prepare_original=REPO/"docs/validation/office-reconciled-20261117/qualification/prepare_workspace.py"
prepare_adapted=DATA/"setup/prepare_workspace_actual_path.py"
expected=prepare_original.read_text().replace(
    "FLUTTER_ROOT=str(runtime / 'flutter-sdk')",
    "FLUTTER_ROOT=str((runtime / 'flutter').resolve())").replace(
    "dart = runtime / 'flutter-sdk/bin/cache/dart-sdk/bin/dart'",
    "dart = (runtime / 'flutter').resolve() / 'bin/cache/dart-sdk/bin/dart'")
check(prepare_adapted.read_text()==expected,"workspace-recipe-actual-path-only")
restore=DATA/"runtime-restoration"
install=read(restore/"flutter-install-receipt.json")
ready=read(restore/"ready.json")
version=read(restore/"flutter-version.log")
check(install["sha256"]==ARCHIVE,"official-sdk-archive-pin")
check(install["archive_bytes"]==1581444364,"official-sdk-archive-size")
check(len(install["files"])==3277 and install["extracted_bytes"]==572002795,"sdk-selection-count-size")
check(ready["version"]==version,"version-receipts-agree")
check(version["frameworkVersion"]=="3.47.8" and version["dartSdkVersion"]=="3.13.7"
      and version["frameworkRevision"]==FRAMEWORK and version["engineRevision"]==ENGINE,
      "all-runtime-version-pins")
check(git(SDK,"rev-parse","HEAD").decode().strip()==FRAMEWORK,"actual-sdk-git-head")
for row in read(restore/"commands.json"):
    check(row["exit_code"]==0 and fsha(restore/(row["label"]+".log"))==row["log_sha256"],
          "restoration-command-log",row["label"])
check(all(x["exit_code"]==0 for x in read(restore/"flutter-shallow-identity.json")),
      "shallow-sdk-identity-commands")

sdk_tree=git_tree(SDK,FRAMEWORK)
sdk_map={}
sdk_source_count=0
sdk_crlf=[]
for row in install["files"]:
    file=ROOT/"toolchains"/row["path"]
    check(file.is_file() and file.stat().st_size==row["bytes"],"retained-sdk-file-size",row["path"])
    if not file.is_file():
        continue
    data=file.read_bytes()
    sdk_map[row["path"]]={"bytes":len(data),"sha256":sha(data)}
    relative=file.relative_to(SDK).as_posix()
    if relative in sdk_tree:
        blob=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
        matched=blob==sdk_tree[relative]["blob"]
        if not matched:
            attrs=git(SDK,"check-attr","-z","text","eol","--",relative).split(b"\0")
            attrs={attrs[i+1].decode():attrs[i+2].decode() for i in range(0,len(attrs)-1,3)}
            normalized=data.replace(b"\r\n",b"\n")
            normalized_blob=hashlib.sha1(b"blob "+str(len(normalized)).encode()+b"\0"+normalized).hexdigest()
            matched=attrs=={"text":"set","eol":"crlf"} and normalized_blob==sdk_tree[relative]["blob"]
            if matched:
                sdk_crlf.append({"path":relative,"raw_sha256":sha(data),"normalized_blob":normalized_blob,
                                 "attributes":attrs,"crlf_count":data.count(b"\r\n")})
        check(matched,"sdk-tracked-file-matches-pinned-commit",relative)
        sdk_source_count+=int(matched)
sdk_map_file=compressed("retained-sdk-inputs.json.gz",sdk_map)

pub=read(restore/"pub-cache-receipt.json")
lock_paths=[SDK/"packages/flutter_tools/pubspec.lock",
            REPO/"docs/validation/proofing-20261116/integration-resume/workspace-pubspec.lock"]
entries={}
for path in lock_paths:
    check(pub["locks"][str(path)]==fsha(path),"pub-source-lock-live-hash",str(path))
    for name,value in yaml.safe_load(path.read_text())["packages"].items():
        if value["source"]!="hosted":
            continue
        check(value["description"]["url"]=="https://pub.dev","official-pub-origin",name)
        key=name+"-"+value["version"]
        entry={"name":name,"version":value["version"],"sha256":value["description"]["sha256"]}
        check(key not in entries or entries[key]==entry,"conflicting-pub-lock-pin",key)
        entries[key]=entry
receipt_entries={row["name"]+"-"+row["version"]:row for row in pub["packages"]}
check(len(entries)==len(receipt_entries)==len(pub["packages"])==162,"complete-unique-pub-union")
check(set(entries)==set(receipt_entries),"pub-receipt-exact-lock-package-set")
for key,pin in entries.items():
    row=receipt_entries[key]
    check(row["status"]=="verified-download" and row["actual_sha256"]==row["sha256"]==pin["sha256"],
          "pub-fresh-verified-archive-pin",key)
    check((CACHE/"hosted-hashes/pub.dev"/(key+".sha256")).read_text().strip()==pin["sha256"],
          "pub-live-cache-marker",key)
    check((CACHE/"hosted/pub.dev"/key/"pubspec.yaml").is_file(),"pub-live-package-root",key)

setup=read(WORK/"setup.json")
check(setup["exit_code"]==0 and "--offline" in setup["command"]
      and "--enforce-lockfile" in setup["command"],"offline-locked-resolution")
check(setup["lock_before_sha256"]==setup["lock_after_sha256"]==fsha(WORK/"pubspec.lock")==LOCK,
      "workspace-lock-identical")
check(setup["environment"]["FLUTTER_ROOT"]==str(SDK),"setup-used-actual-flutter-root")
for row in setup["links"]:
    path=Path(row["path"])
    check(path.is_symlink() and path.resolve()==Path(row["source"]).resolve(),
          "workspace-source-link",row)
config_path=WORK/".dart_tool/package_config.json"
config_bytes=config_path.read_bytes()
config=read(config_path)
check(sha(config_bytes)==prewarm['package_config_after'],'config-matches-final-prewarm')
check(config["configVersion"]==2 and len(config["packages"])==109,"workspace-package-record-count")
check(config["flutterRoot"]==SDK.as_uri(),"config-flutterRoot-actual",config.get("flutterRoot"))
check(b"flutter-sdk" not in config_bytes,"no-symlink-alias-in-workspace-package-config")
(OUT/"package_config.before.json").write_bytes(config_bytes)
graph_path=WORK/".dart_tool/package_graph.json"
if graph_path.is_file():
    (OUT/"package_graph.before.json").write_bytes(graph_path.read_bytes())

spec=importlib.util.spec_from_file_location("qualification_audit",
    REPO/"docs/validation/office-reconciled-20261117/qualification/prior_run_qualification.py")
audit=importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
graph=audit.normalized_graph(config_path,REPO)
source=audit.source_snapshot(REPO,SOURCE)
check(not source["commit_mismatches"] and not source["untracked_non_evidence_paths"],
      "complete-source-blob-binding")
dependencies=audit.dependency_snapshot(graph,REPO)
workspace=audit.workspace_snapshot(WORK)
runtime=audit.runtime_snapshot(SDK)
for key,value in runtime.items():
    check(value is not None,"required-core-runtime-exists",key)
workspace_extra={}
for file in [WORK/"analysis_options.yaml",WORK/"tool",WORK/"docs"]:
    if file.is_file() or file.is_symlink():
        workspace_extra[str(file)]=audit.sha(file)
extra_relatives=[
    "bin/cache/dart-sdk/bin/snapshots/dart2js_aot.dart.snapshot",
    "bin/cache/dart-sdk/bin/snapshots/gen_kernel_aot.dart.snapshot",
    "bin/cache/dart-sdk/lib/_internal/dart2js_platform.dill",
    "bin/cache/dart-sdk/lib/_internal/dart2js_server_platform.dill",
    "bin/cache/dart-sdk/lib/_internal/vm_platform_strong.dill",
    "bin/cache/artifacts/engine/linux-x64/frontend_server_aot.dart.snapshot",
]
extra={}
for relative in extra_relatives:
    file=SDK/relative
    check(file.is_file(),"supplemental-compiler-input-exists",relative)
    if file.is_file():
        extra[str(file)]={"relative":relative,"bytes":file.stat().st_size,"sha256":fsha(file)}
node=Path(shutil.which('node')).resolve()
extra[str(node)]={"kind":"node-executable","bytes":node.stat().st_size,"sha256":fsha(node)}
for file in [WORK/"pubspec.yaml",WORK/"analysis_options.yaml",*WORK.glob("packages/*/pubspec.yaml"),
             *WORK.glob("packages/*/example/pubspec.yaml"),*WORK.glob("apps/*/pubspec.yaml")]:
    check(file.read_bytes()==(REPO/file.relative_to(WORK)).read_bytes(),"workspace-manifest-source-identity",
          str(file.relative_to(WORK)))
maps={
 "source":compressed("source-baseline.json.gz",source),
 "dependencies":compressed("dependency-baseline.json.gz",dependencies),
 "workspace":compressed("workspace-baseline.json.gz",workspace),
 "runtime":compressed("runtime-baseline.json.gz",runtime),
 "workspace_extra":compressed("workspace-extra-baseline.json.gz",workspace_extra)
}
save("supplemental-runtime-baseline.json",{"source_commit":SOURCE,"recorded_utc":datetime.now(timezone.utc).isoformat(),
      "actual_flutter_root":str(SDK),"files":extra,
      "purpose":"Immutable input baseline for extra Node/Dart/Flutter compiler inputs omitted by generic runner map."})
head_after=git(REPO,"rev-parse","HEAD").decode().strip()
status_after=git(REPO,"status","--porcelain").decode().strip()
check(head_after==head_before==SOURCE and status_before==status_after=="","source-clean-unchanged-during-audit")
check(config_path.read_bytes()==config_bytes,"config-byte-stable-during-audit")
report={
 "schema":"quds.office.current_flutter_restore_independent_audit.v1",
 "started_utc":started,"finished_utc":datetime.now(timezone.utc).isoformat(),
 "source_commit":SOURCE,"source_tree":git(REPO,"rev-parse",SOURCE+"^{tree}").decode().strip(),
 "prior_source":old_source,"non_documentation_delta_from_prior":non_docs_delta,
 "source_head_clean_and_unchanged":head_before==head_after==SOURCE and status_before==status_after=="",
 "recipes":{"restore_original_sha256":sha(original),"restore_adapted_sha256":sha(adapted),
            "restore_path_only":adapted==original.replace(b"/workspace/scratch/eddfdfc8cc56",str(ROOT).encode()).replace(b"REPO = ROOT / 'quds_office_suite'", b"REPO = ROOT / 'qualification-source'"),
            "workspace_original_sha256":fsha(prepare_original),"workspace_adapted_sha256":fsha(prepare_adapted),
            "workspace_actual_path_only":prepare_adapted.read_text()==expected},
 "sdk":{"archive_url":install["url"],"archive_sha256":install["sha256"],"archive_bytes":install["archive_bytes"],
        "retained_files_rehashed":len(sdk_map),"retained_bytes":sum(r["bytes"] for r in sdk_map.values()),
        "tracked_source_files_matching_framework_commit":sdk_source_count,
        "declared_crlf_normalizations":sdk_crlf,"retained_sdk_map":sdk_map_file,"version":version},
 "pub":{"fresh_verified_archive_receipts":len(pub["packages"]),"exact_union_of_two_pinned_locks":set(entries)==set(receipt_entries),
        "dependency_roots":len(dependencies["package_roots"]),"consumed_dependency_files_rehashed":dependencies["count"]},
 "workspace":{"package_count":len(config["packages"]),"flutterRoot":config["flutterRoot"],"package_config_sha256":sha(config_bytes),
              "package_graph_sha256":fsha(graph_path) if graph_path.is_file() else None,
              "lock_sha256":fsha(WORK/"pubspec.lock"),"source_links_checked":len(setup["links"])},
 "prewarm_receipt_sha256":fsha(prewarm_path),"prewarm_receipt":prewarm,
 "baseline_maps":maps,"supplemental_compiler_inputs":len(extra),
 "report_inputs":{"restore_receipts":{str(p.relative_to(ROOT)):fsha(p) for p in sorted(restore.glob("*")) if p.is_file()},
                  "audit_script_sha256":fsha(Path(__file__))},
 "findings":findings,"restoration_audit_accepted":not findings,"qualification_accepted":False,
 "tests_executed_by_auditor":0,"source_runtime_mutations":0,"github_actions_endpoints_queried":0,
 "limitations":["Large official download archives were not fetched a second time: verified download receipts/pins, live retained SDK bytes and pinned Git source blobs were independently checked.",
                "Baseline files are current observed inputs, not a claim that later gates passed; compare exact after snapshots and supplemental hashes before accepting.",
                "Scope remains VM/Flutter tester/Node qualification; omitted desktop/web/devtool components are not qualified."]
}
save("current-restoration-audit.json",report)
print(json.dumps({"accepted":not findings,"findings":findings,"source":SOURCE,
                  "sdk_files":len(sdk_map),"sdk_source_matches":sdk_source_count,
                  "pub_archives":len(pub["packages"]),"dependency_files":dependencies["count"],
                  "extra_compiler_inputs":len(extra),"report":str(report_path)}))
raise SystemExit(0 if not findings else 1)

