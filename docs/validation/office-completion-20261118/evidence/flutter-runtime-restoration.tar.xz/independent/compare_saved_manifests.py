#!/usr/bin/env python3
"""Read-only comparison of new runtime audit with preserved accepted manifests."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/21605f06e47d')
SAVED = ROOT / 'continuation/flutter-restoration/independent'
CURRENT = ROOT / 'continuation/runtime-review'
OLD_ROOT = '/workspace/scratch/eddfdfc8cc56'
report_path = CURRENT / 'saved-manifest-comparison.json'
if report_path.exists():
    raise SystemExit('Preserve previous comparison report; do not overwrite.')

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def load(path):
    data = path.read_bytes()
    if path.suffix == '.gz':
        data = gzip.decompress(data)
    return json.loads(data)

def remap(value):
    if isinstance(value, str):
        return value.replace(OLD_ROOT + '/quds_office_suite', str(ROOT / 'qualification-source')).replace(OLD_ROOT, str(ROOT))
    if isinstance(value, dict):
        return {remap(k): remap(v) for k, v in value.items()}
    if isinstance(value, list):
        return [remap(v) for v in value]
    return value

checks = []
findings = []
inputs = {}
for name in ['retained-sdk-inputs.json.gz', 'runtime-baseline.json.gz',
             'dependency-baseline.json.gz', 'source-baseline.json.gz']:
    old_path, new_path = SAVED / name, CURRENT / name
    old, new = remap(load(old_path)), load(new_path)
    equal = old == new
    checks.append({'manifest': name, 'equal_after_root_path_mapping': equal})
    inputs[name] = {'saved_sha256': sha(old_path), 'current_sha256': sha(new_path)}
    if not equal:
        if isinstance(old, dict) and isinstance(new, dict):
            differing = [k for k in sorted(set(old) | set(new)) if old.get(k) != new.get(k)]
        else:
            differing = ['top-level-value']
        findings.append({'manifest': name, 'differing_keys': differing})

saved_pub_path = ROOT / 'continuation/flutter-restoration/runtime/pub-cache-receipt.json'
current_pub_path = ROOT / 'flutter-qualification/runtime-restoration/pub-cache-receipt.json'
saved_pub, current_pub = load(saved_pub_path), load(current_pub_path)
def pins(receipt):
    return {row['name'] + '-' + row['version']: {
        key: row[key] for key in ['sha256', 'actual_sha256', 'archive_bytes',
                                  'selected_members', 'omitted_development_members',
                                  'selected_bytes']
    } for row in receipt['packages']}
pub_equal = pins(saved_pub) == pins(current_pub)
checks.append({'manifest': 'pub-archives', 'all_162_archive_pins_and_selection_receipts_equal':
               len(pins(saved_pub)) == len(pins(current_pub)) == 162 and pub_equal})
if not checks[-1]['all_162_archive_pins_and_selection_receipts_equal']:
    findings.append({'manifest': 'pub-archives', 'problem': 'package count, pins or selected archive receipts differ'})
inputs['pub-archives'] = {'saved_sha256': sha(saved_pub_path), 'current_sha256': sha(current_pub_path)}

old_report_path, new_report_path = SAVED / 'current-restoration-audit.json', CURRENT / 'current-restoration-audit.json'
old_report, new_report = load(old_report_path), load(new_report_path)
checks.append({'manifest': 'auditor-outcomes', 'both_accepted':
               old_report['restoration_audit_accepted'] and new_report['restoration_audit_accepted']})
if not checks[-1]['both_accepted']:
    findings.append({'manifest': 'auditor-outcomes', 'problem': 'one or both restoration audits not accepted'})
report = {
    'schema': 'quds.office.restored_saved_manifest_comparison.v1',
    'observed_at': datetime.now(timezone.utc).isoformat(),
    'source_commit': new_report['source_commit'],
    'source_files': load(CURRENT / 'source-baseline.json.gz')['count'],
    'retained_sdk_files': len(load(CURRENT / 'retained-sdk-inputs.json.gz')),
    'core_runtime_files': len(load(CURRENT / 'runtime-baseline.json.gz')),
    'dependency_files': load(CURRENT / 'dependency-baseline.json.gz')['count'],
    'pub_archive_pins': len(pins(current_pub)),
    'normalization': {'old_root': OLD_ROOT, 'new_root': str(ROOT),
                     'old_source_relative_path': 'quds_office_suite',
                     'new_source_relative_path': 'qualification-source'},
    'checks': checks, 'findings': findings, 'accepted': not findings,
    'inputs': inputs,
    'audit_reports': {'saved_sha256': sha(old_report_path), 'current_sha256': sha(new_report_path)},
    'script_sha256': sha(Path(__file__)),
    'runtime_or_source_mutations': 0, 'compiles_or_model_jobs': 0,
    'qualification_reexecution_claimed': False,
}
report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'accepted': report['accepted'], 'findings': findings,
                  'sdk_files': report['retained_sdk_files'],
                  'dependency_files': report['dependency_files'],
                  'pub_archive_pins': report['pub_archive_pins'],
                  'report': str(report_path)}))
raise SystemExit(0 if not findings else 1)
