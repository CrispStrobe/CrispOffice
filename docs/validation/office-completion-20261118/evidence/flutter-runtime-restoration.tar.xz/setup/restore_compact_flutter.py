"""Restore the recorded Flutter archive and independently hash each Pub archive."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import time
import urllib.parse
import urllib.request
import yaml

ROOT = Path('/workspace/scratch/21605f06e47d')
REPO = ROOT / 'qualification-source'
OUT = ROOT / 'flutter-qualification/runtime-restoration'
RUNTIME = ROOT / 'toolchains'
CACHE = RUNTIME / 'pub-cache'
SDK = RUNTIME / 'flutter'
SPEC = importlib.util.spec_from_file_location('recorded_bootstrap', REPO / 'docs/validation/proofing-20261116/integration-followup/flutter-setup/bootstrap_flutter.py')
BOOT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BOOT)

# All retained SDK bytes come from the pinned official archive. Exclusions only
# remove unrelated Git history, web renderer, interactive DevTools, sanitizer
# variants and desktop GTK embedding; Dart2JS and all test/analyzer cores remain.
original_selected = BOOT.selected
COMPACT_PREFIXES = (
    'flutter/.git',
    'flutter/bin/cache/flutter_web_sdk',
    'flutter/bin/cache/dart-sdk/bin/resources/devtools',
)
COMPACT_FILES = {
    'flutter/bin/cache/dart-sdk/bin/snapshots/analysis_server.dart.snapshot',
    'flutter/bin/cache/dart-sdk/bin/snapshots/dartdevc.dart.snapshot',
    'flutter/bin/cache/dart-sdk/bin/snapshots/dart2wasm_product.snapshot',
    'flutter/bin/cache/dart-sdk/bin/snapshots/dart2bytecode.dart.snapshot',
    'flutter/bin/cache/dart-sdk/bin/dartaotruntime_msan',
    'flutter/bin/cache/dart-sdk/bin/dartaotruntime_tsan',
    'flutter/bin/cache/dart-sdk/bin/dartaotruntime_asan',
    'flutter/bin/cache/artifacts/engine/linux-x64/libflutter_linux_gtk.so',
}
def compact_selected(name):
    return original_selected(name) and name not in COMPACT_FILES and not any(
        name == p or name.startswith(p + '/') for p in COMPACT_PREFIXES)
BOOT.selected = compact_selected

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def main():
    for path in (OUT, RUNTIME, CACHE / '_temp', CACHE / 'hosted/pub.dev', CACHE / 'hosted-hashes/pub.dev'):
        path.mkdir(parents=True, exist_ok=True)
    began = time.time()
    if not (OUT / 'flutter-install-receipt.json').exists():
        expanded = 0
        last = time.time()
        manifest = []
        print('Downloading and verifying official Flutter archive', flush=True)
        with urllib.request.urlopen(BOOT.URL, timeout=120) as response:
            reader = BOOT.DigestReader(response)
            with tarfile.open(fileobj=reader, mode='r|xz') as archive:
                for member in archive:
                    if BOOT.selected(member.name):
                        expanded += member.size
                        if expanded > 1100 * 1024**2 or shutil.disk_usage(RUNTIME).free < 100 * 1024**2:
                            raise RuntimeError('SDK extraction exceeded safety budget')
                        archive.extract(member, RUNTIME, filter='data')
                        if member.isfile():
                            manifest.append({'path': member.name, 'bytes': member.size})
                    if time.time() - last > 20:
                        print(json.dumps({'downloaded_bytes': reader.total, 'expanded_bytes': expanded}), flush=True)
                        last = time.time()
            while reader.read(1024**2):
                pass
            assert reader.hash.hexdigest() == BOOT.SHA256, reader.hash.hexdigest()
        write('flutter-install-receipt.json', {'url': BOOT.URL, 'sha256': reader.hash.hexdigest(), 'archive_bytes': reader.total, 'extracted_bytes': expanded, 'files': manifest})
    else:
        receipt = json.loads((OUT / 'flutter-install-receipt.json').read_text())
        assert receipt['sha256'] == BOOT.SHA256

    # Use an authentic shallow checkout identity instead of 300MB+ of history.
    if not (SDK / '.git').exists():
        commands = [
            ['git', 'init', '--initial-branch=stable', str(SDK)],
            ['git', '-C', str(SDK), 'remote', 'add', 'origin', 'https://github.com/flutter/flutter.git'],
            ['git', '-C', str(SDK), 'fetch', '--depth=1', 'origin', 'refs/tags/3.47.8:refs/tags/3.47.8'],
            ['git', '-C', str(SDK), 'reset', '--mixed', '3.47.8'],
        ]
        git_receipts = []
        for command in commands:
            result = subprocess.run(command, capture_output=True, timeout=120)
            git_receipts.append({'command': command, 'exit_code': result.returncode,
                'stdout': result.stdout.decode(errors='replace'), 'stderr': result.stderr.decode(errors='replace')})
            write('flutter-shallow-identity.json', git_receipts)
            assert result.returncode == 0, git_receipts[-1]
    revision = subprocess.check_output(['git', '-C', str(SDK), 'rev-parse', 'HEAD'], text=True).strip()
    assert revision == BOOT.REVISION, revision

    link = RUNTIME / 'flutter-sdk'
    if not link.exists():
        link.symlink_to('flutter', target_is_directory=True)

    locks = [SDK / 'packages/flutter_tools/pubspec.lock', REPO / 'docs/validation/proofing-20261116/integration-resume/workspace-pubspec.lock']
    assert BOOT.sha(locks[1]) == '344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130'
    entries = {}
    for lock in locks:
        for name, value in yaml.safe_load(lock.read_text())['packages'].items():
            if value['source'] != 'hosted':
                continue
            assert value['description']['url'] == 'https://pub.dev'
            key = name + '-' + value['version']
            entry = {'name': name, 'version': value['version'], 'sha256': value['description']['sha256']}
            assert key not in entries or entries[key] == entry
            entries[key] = entry

    def fetch(item):
        key, entry = item
        target = CACHE / 'hosted/pub.dev' / key
        mark = CACHE / 'hosted-hashes/pub.dev' / (key + '.sha256')
        if target.exists() and mark.exists() and mark.read_text().strip() == entry['sha256']:
            return dict(entry, status='matching-restored-cache')
        url = 'https://pub.dev/api/archives/' + urllib.parse.quote(key, safe='-._+') + '.tar.gz'
        with urllib.request.urlopen(url, timeout=90) as response:
            data = response.read()
        actual = hashlib.sha256(data).hexdigest()
        assert actual == entry['sha256'], key
        temporary = CACHE / '_temp' / key
        temporary.mkdir(exist_ok=False)
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
            members = archive.getmembers()
            omitted = [m for m in members if m.name.split('/')[0] in {'test', 'tests', 'example', 'examples', 'doc', 'docs', 'benchmark', 'benchmarks', 'coverage'}]
            selected = [m for m in members if m not in omitted]
            archive.extractall(temporary, members=selected, filter='data')
        temporary.rename(target)
        mark.write_text(actual)
        return dict(entry, status='verified-download', url=url, archive_bytes=len(data), actual_sha256=actual, selected_members=len(selected), omitted_development_members=len(omitted), selected_bytes=sum(m.size for m in selected if m.isfile()))

    print('Restoring pinned Pub archives: ' + str(len(entries)), flush=True)
    with ThreadPoolExecutor(max_workers=16) as pool:
        results = list(pool.map(fetch, sorted(entries.items())))
    write('pub-cache-receipt.json', {'locks': {str(p): BOOT.sha(p) for p in locks}, 'packages': results})
    env = dict(os.environ, XDG_CONFIG_HOME=str(OUT / 'config'), PUB_CACHE=str(CACHE), FLUTTER_ROOT=str(SDK), CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true')
    commands = [
        ('flutter-tools-offline', [str(SDK / 'bin/cache/dart-sdk/bin/dart'), 'pub', '--suppress-analytics', '--directory', str(SDK / 'packages/flutter_tools'), 'get', '--example', '--offline']),
        ('flutter-version', [str(SDK / 'bin/flutter'), '--version', '--machine']),
    ]
    records = []
    for label, command in commands:
        print('START ' + label, flush=True)
        with (OUT / (label + '.log')).open('wb') as stream:
            result = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=240)
        records.append({'label': label, 'command': command, 'exit_code': result.returncode, 'log_sha256': BOOT.sha(OUT / (label + '.log'))})
        write('commands.json', records)
        assert result.returncode == 0, (OUT / (label + '.log')).read_text()[-12000:]
    version = json.loads((OUT / 'flutter-version.log').read_text())
    assert version['frameworkRevision'] == BOOT.REVISION and version['dartSdkVersion'] == '3.13.7'
    write('ready.json', {'version': version, 'workspace': str(ROOT / 'full-validation-workspace'), 'runtime': str(SDK), 'pub_cache': str(CACHE), 'elapsed_seconds': time.time() - began, 'finished_utc': datetime.now(timezone.utc).isoformat()})
    print('RUNTIME READY', flush=True)

if __name__ == '__main__':
    main()
