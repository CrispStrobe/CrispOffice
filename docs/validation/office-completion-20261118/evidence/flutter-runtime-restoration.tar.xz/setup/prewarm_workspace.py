"""Prewarm the recorded Dart/Flutter CLIs before frozen runtime snapshots."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / 'flutter-qualification/workspace'
SDK = ROOT / 'toolchains/flutter'
OUT = ROOT / 'continuation/prewarm'
OUT.mkdir(exist_ok=False)
CONFIG = WORK / '.dart_tool/package_config.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = sha(CONFIG)
env = dict(os.environ, FLUTTER_ROOT=str(SDK), PUB_CACHE=str(ROOT / 'toolchains/pub-cache'),
           TMPDIR=str(WORK / 'tmp'), XDG_CONFIG_HOME=str(WORK / 'config'),
           CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true',
           DASH__SUPPRESS_ANALYTICS='true', PYTHONDONTWRITEBYTECODE='1')
dart = SDK / 'bin/cache/dart-sdk/bin/dart'
env['PATH'] = str(dart.parent) + os.pathsep + env.get('PATH', '')
rows = []
for name, command in [
    ('dart-test-help', [str(dart), 'test', '--help']),
    ('flutter-test-help', [str(dart), str(SDK / 'bin/cache/flutter_tools.snapshot'), 'test', '--help']),
]:
    started = time.monotonic()
    with (OUT / (name + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=WORK, env=env, stdout=log,
                                stderr=subprocess.STDOUT, timeout=300)
    rows.append({'name': name, 'argv': command, 'exit_code': result.returncode,
                 'elapsed_seconds': time.monotonic() - started,
                 'log_sha256': sha(OUT / (name + '.log'))})
    (OUT / 'commands.json').write_text(json.dumps(rows, indent=2) + '\n')
    assert result.returncode == 0, name
    print(name + ' passed', flush=True)
config = json.loads(CONFIG.read_text())
receipt = {'commands': rows, 'package_config_before': before,
           'package_config_after': sha(CONFIG), 'unchanged': before == sha(CONFIG),
           'flutter_root': config['flutterRoot'], 'resolved_flutter_root': str(SDK.resolve()),
           'packages': len(config['packages']), 'lock_sha256': sha(WORK / 'pubspec.lock'),
           'finished_utc': datetime.now(timezone.utc).isoformat()}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert receipt['unchanged']
assert receipt['flutter_root'] == SDK.as_uri()
assert receipt['packages'] == 109
assert receipt['lock_sha256'] == '344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130'
print(json.dumps(receipt), flush=True)
