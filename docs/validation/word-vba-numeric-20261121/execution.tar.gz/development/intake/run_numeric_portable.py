#!/usr/bin/env python3
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('vm', 'js'))
args = parser.parse_args()
root = Path('/workspace/scratch/55ae4c05da4e')
engine = root / 'quds_office_suite/packages/quds_office_engine'
output = root / 'intake'
runtime = root / 'runtime'
dart = runtime / 'dart-sdk/bin/dart'
config = root / 'quds_office_suite/.dart_tool/package_config.json'
source = engine / 'example/macros/word_numeric_report.bas'
script = 'tool/macros/web_vba_word_numeric_smoke.dart'
inputs = [
    engine / 'lib/src/automation/office_vba_language.dart',
    engine / 'test/office_vba_numeric_intrinsics_integration_test.dart',
    engine / script,
    source,
]


def hashes():
    return {str(p.relative_to(engine)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}


before = hashes()
environment = dict(
    os.environ,
    TMPDIR=str(runtime / 'tmp'),
    PUB_CACHE=str(runtime / 'pub-cache'),
    DART_DISABLE_ANALYTICS='1',
)
define = '-DWORD_NUMERIC_BAS_BASE64=' + base64.b64encode(source.read_bytes()).decode()
js = output / 'numeric-smoke-accepted.js'
if args.mode == 'vm':
    commands = [[str(dart), '--packages=' + str(config), define, script]]
else:
    commands = [
        [str(dart), 'compile', 'js', '-O1', '--packages=' + str(config), define, script, '-o', str(js)],
        ['node', '-e', 'globalThis.self = globalThis; require(' + json.dumps(str(js)) + ')'],
    ]
results = []
for index, command in enumerate(commands):
    executed = subprocess.run(command, cwd=engine, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    prefix = output / f'numeric-smoke-accepted-{args.mode}-{index}'
    prefix.with_suffix('.stdout').write_bytes(executed.stdout)
    prefix.with_suffix('.stderr').write_bytes(executed.stderr)
    results.append(dict(command=command, exit_code=executed.returncode))
    if executed.returncode:
        print(executed.stderr.decode())
        break
after = hashes()
record = dict(mode=args.mode, inputs_before=before, inputs_after=after, unchanged=before == after, commands=results)
(output / f'numeric-smoke-accepted-{args.mode}.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(mode=args.mode, unchanged=before == after, exit_codes=[r['exit_code'] for r in results])))
raise SystemExit(0 if before == after and all(r['exit_code'] == 0 for r in results) else 1)
