export FLUTTER_ROOT=/workspace/scratch/a450b8f86aed/runtime/flutter
export PUB_CACHE=/workspace/scratch/a450b8f86aed/runtime/pub-cache
export TMPDIR=/workspace/scratch/a450b8f86aed/runtime/tmp
export DART_SUPPRESS_ANALYTICS=true
export FLUTTER_SUPPRESS_ANALYTICS=true
export CI=true
export PATH="$FLUTTER_ROOT/bin/cache/dart-sdk/bin:$FLUTTER_ROOT/bin:$PATH"
