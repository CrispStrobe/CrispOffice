#!/usr/bin/env python3
"""Resolve only the local workspace using the verified offline SDK/cache."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/a450b8f86aed')
REPO = ROOT / 'quds_office_suite'
RUNTIME = ROOT / 'runtime'
OUT = RUNTIME / 'setup' / 'workspace-resolution'
OUT.mkdir(parents=True, exist_ok=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manifests():
    paths = subprocess.check_output(
        ['git', 'ls-files', 'pubspec.yaml', '**/pubspec.yaml'],
        cwd=REPO, text=True,
    ).splitlines()
    return {p: digest(REPO / p) for p in paths}


env = {
    **os.environ,
    'FLUTTER_ROOT': str(RUNTIME / 'flutter'),
    'PUB_CACHE': str(RUNTIME / 'pub-cache'),
    'TMPDIR': str(RUNTIME / 'tmp'),
    'DART_SUPPRESS_ANALYTICS': 'true',
    'FLUTTER_SUPPRESS_ANALYTICS': 'true',
    'CI': 'true',
}
lock = REPO / 'pubspec.lock'
seed = RUNTIME / 'setup' / 'workspace-pubspec.lock'
record = {
    'started': datetime.now(timezone.utc).isoformat(),
    'repo': str(REPO),
    'environment': {k: env[k] for k in ('FLUTTER_ROOT', 'PUB_CACHE', 'TMPDIR', 'CI')},
    'source_head_at_start': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True,
    ).strip(),
    'pubspec_before': manifests(),
    'copied_pinned_seed_lock': not lock.exists(),
    'seed_lock_sha256': digest(seed),
}
if not lock.exists():
    shutil.copyfile(seed, lock)
record['lock_before_sha256'] = digest(lock)
argv = [str(RUNTIME / 'flutter/bin/flutter'), 'pub', 'get', '--offline']
record['argv'] = argv
begin = time.monotonic()
with (OUT / 'workspace-pub-get.log').open('wb') as stream:
    result = subprocess.run(argv, cwd=REPO, env=env, stdout=stream,
                            stderr=subprocess.STDOUT, timeout=180)
record['elapsed_seconds'] = time.monotonic() - begin
record['exit_code'] = result.returncode
record['log_sha256'] = digest(OUT / 'workspace-pub-get.log')
record['lock_after_sha256'] = digest(lock)
shutil.copyfile(lock, OUT / 'workspace.pubspec.lock')
config = REPO / '.dart_tool/package_config.json'
if config.exists():
    record['package_config_sha256'] = digest(config)
    record['package_count'] = len(json.loads(config.read_text())['packages'])
    shutil.copyfile(config, OUT / 'workspace.package_config.json')
record['pubspec_after'] = manifests()
record['pubspec_unchanged'] = record['pubspec_before'] == record['pubspec_after']
record['finished'] = datetime.now(timezone.utc).isoformat()
record['status'] = 'passed' if result.returncode == 0 and record['pubspec_unchanged'] else 'failed'
(OUT / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if record['status'] == 'passed' else 1)
