"""Finite shortcut/Mail integration gate; execute only on a frozen checkpoint."""

import argparse
from collections import Counter
import json
import os
from pathlib import Path
import shutil
import subprocess

REPO = Path('/workspace/scratch/8eb34dc8ced9/quds_office_suite')
RUNTIME = Path('/workspace/scratch/8eb34dc8ced9/runtime')
OUTPUT = RUNTIME / 'shortcuts-integration'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--expected-head', required=True)
args = parser.parse_args()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip()
assert head == args.expected_head, (head, args.expected_head)
assert not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--',
                                    'packages', 'third_party', 'pubspec.yaml',
                                    'pubspec.lock', '.fvmrc'], cwd=REPO).strip()
assert not OUTPUT.exists(), OUTPUT
incoming = [
    'packages/quds_office_editor/example/lib/studio_settings.dart',
    'packages/quds_office_editor/example/lib/studio_shortcuts.dart',
    'packages/quds_office_editor/example/lib/suite_workspace.dart',
    'packages/quds_office_editor/example/lib/suite_workspace_settings.dart',
    'packages/quds_office_editor/example/test/studio_shortcuts_test.dart',
    'packages/quds_office_editor/example/test/studio_settings_test.dart',
    'packages/quds_office_editor/example/test/suite_workspace_mail_shortcuts_test.dart',
]
tests = [
    'test/studio_shortcuts_test.dart',
    'test/studio_settings_test.dart',
    'test/suite_workspace_mail_shortcuts_test.dart',
    'test/studio_mail_cached_search_refresh_dialog_test.dart',
]
for path in incoming:
    assert (REPO / path).is_file(), path
OUTPUT.mkdir()
shutil.copyfile(__file__, OUTPUT / 'run_shortcuts_integration.py')
support = REPO / 'docs/validation/mail-live-search-20261121/run_local.py'
shutil.copyfile(support, OUTPUT / 'qualification_support.py')
helpers = {'__name__': 'qualification_support', '__file__': str(support)}
exec(compile(support.read_text(), str(support), 'exec'), helpers)
save = helpers['save_json']
manifest = helpers['source_manifest']
changed = helpers['changed_inputs']
execute = helpers['execute']
audit_events = helpers['audit_events']
digest = helpers['digest']
env = dict(os.environ)
env.update(CI='true', FLUTTER_SUPPRESS_ANALYTICS='true', DART_SUPPRESS_ANALYTICS='true')
flutter = shutil.which('flutter')
dart = shutil.which('dart')
assert flutter is not None and dart is not None
base = [flutter, '--suppress-analytics', '--no-version-check']
checked = list(dict.fromkeys(helpers['CHANGED_DART'] + incoming))
before = manifest(REPO)
save(OUTPUT / 'source-before.json', before)
previous = RUNTIME / 'main-integration'
previous_summary = json.loads((previous / 'summary.json').read_text())
assert previous_summary['accepted']
previous_sources = json.loads((previous / 'source-after.json').read_text())
delta = changed(previous_sources, before)
assert set(delta).issubset(set(incoming)), delta
versions = []
for label, command in [
    ('flutter-version', [*base, '--version', '--machine']),
    ('dart-version', [dart, '--version']),
]:
    versions.append(execute(command, REPO, env, OUTPUT / (label + '.stdout'),
                            OUTPUT / (label + '.stderr'), 900))
save(OUTPUT / 'runtime-versions.json', versions)
save(OUTPUT / 'context.json', {
    'schema': 'quds-mail-live-search-shortcuts-integration/v1',
    'git_head': head,
    'prior_qualified_head': previous_summary['git_head'],
    'source_input_count': len(before),
    'source_delta_against_prior_qualification': delta,
    'production_delta_against_prior_qualification': [p for p in delta if '/lib/' in p],
    'source_sha256_against_prior_qualification': {
        path: {'before': previous_sources.get(path), 'after': before.get(path)} for path in delta
    },
    'prior_source_manifest_sha256': digest(previous / 'source-after.json'),
    'environment': {name: env.get(name) for name in [
        'CI', 'FLUTTER_SUPPRESS_ANALYTICS', 'DART_SUPPRESS_ANALYTICS', 'PUB_CACHE', 'TMPDIR',
    ]},
    'qualification_support_sha256': digest(support),
    'runner_sha256': digest(Path(__file__)),
})
cwd = REPO / 'packages/quds_office_editor/example'
steps = [
    ('analysis', REPO, [*base, 'analyze', '--no-pub', '--fatal-infos',
                        '--fatal-warnings', *checked], []),
    ('format', REPO, [dart, 'format', '--output=none', '--set-exit-if-changed', *checked], []),
    ('shortcuts-mail', cwd, [*base, 'test', '--no-pub', '--concurrency=1',
                            '--reporter=json', *tests], [cwd / name for name in tests]),
]
receipts = []
for name, directory, command, selected in steps:
    print('Starting ' + name + ': ' + json.dumps(command), flush=True)
    step_before = manifest(REPO)
    save(OUTPUT / (name + '.source-before.json'), step_before)
    receipt = execute(command, directory, env, OUTPUT / (name + '.stdout'),
                      OUTPUT / (name + '.stderr'), 900)
    step_after = manifest(REPO)
    save(OUTPUT / (name + '.source-after.json'), step_after)
    receipt.update(name=name, source_input_count=len(step_before),
                   changed_inputs=changed(step_before, step_after))
    accepted = (receipt['exit_code'] == 0 and not receipt['timed_out']
                and receipt['stderr_bytes'] == 0 and step_before == step_after)
    if selected:
        audit = audit_events(OUTPUT / (name + '.stdout'), selected)
        save(OUTPUT / (name + '.cases.json'), audit)
        receipt['test_summary'] = {key: value for key, value in audit.items() if key != 'cases'}
        accepted = (accepted and audit['complete_lifecycle'] and audit['failed'] == 0
                    and audit['skipped'] == 0 and not audit['runtime_error_events'])
    receipt['accepted'] = accepted
    save(OUTPUT / (name + '.receipt.json'), receipt)
    receipts.append(receipt)
    print(json.dumps({'step': name, 'accepted': accepted, 'exit_code': receipt['exit_code'],
                      'stderr_bytes': receipt['stderr_bytes'], 'changed_inputs': receipt['changed_inputs'],
                      'passed': receipt.get('test_summary', {}).get('passed')}), flush=True)
after = manifest(REPO)
save(OUTPUT / 'source-after.json', after)

def identities(directory, name):
    audit = json.loads((directory / (name + '.cases.json')).read_text())
    receipt = json.loads((directory / (name + '.receipt.json')).read_text())
    assert receipt['accepted']
    return {(case['suite'].split('/quds_office_suite/', 1)[1], case['name'])
            for case in audit['cases']}

prior_cases = set()
for directory, name in [
    (RUNTIME / 'final-corrected', 'studio'),
    (RUNTIME / 'final', 'store'),
    (RUNTIME / 'final', 'editor'),
    (previous, 'engine'),
]:
    prior_cases |= identities(directory, name)
assert len(prior_cases) == 404, len(prior_cases)
audit = json.loads((OUTPUT / 'shortcuts-mail.cases.json').read_text())
current_cases = {(case['suite'].split('/quds_office_suite/', 1)[1], case['name'])
                 for case in audit['cases']}
overlap = current_cases & prior_cases
expected_overlap = {case for case in prior_cases
                    if case[0].endswith('/studio_mail_cached_search_refresh_dialog_test.dart')}
assert len(expected_overlap) == 14
counting_valid = overlap == expected_overlap and len(current_cases) == len(audit['cases'])
summary = {
    'schema': 'quds-mail-live-search-shortcuts-integration/v1',
    'git_head': head,
    'accepted': (all(step['accepted'] for step in receipts)
                 and all(version['exit_code'] == 0 for version in versions)
                 and before == after and counting_valid),
    'source_input_count': len(before),
    'changed_inputs_across_gate': changed(before, after),
    'steps': receipts,
    'per_suite_visible_cases': dict(Counter(case[0] for case in current_cases)),
    'counting': {
        'prior_accepted_distinct_case_identities': len(prior_cases),
        'current_executed_case_identities': len(current_cases),
        'rerun_prior_case_identities': len(overlap),
        'additional_case_identities': len(current_cases - prior_cases),
        'combined_distinct_case_identities': len(prior_cases | current_cases),
        'expected_fourteen_case_overlap_verified': counting_valid,
        'rerun_case_identities': sorted(overlap),
        'rule': 'The existing 14 refresh-dialog cases are rerun and counted once. '
                'The earlier 404 accepted identities remain a separate recorded population; '
                'only additional identities increase a combined distinct total.',
    },
    'prior_qualification_applicability': {
        'prior_qualified_head': previous_summary['git_head'],
        'source_delta': delta,
        'scope': 'The new delta is limited to Studio shortcut/settings/workspace paths '
                 'and their tests. Mail/core/store/editor-engine package inputs outside '
                 'those explicitly recorded paths and dependency manifests are unchanged. '
                 'This gate covers actual shortcut dispatch, persistence, Mail isolation '
                 'and the existing refresh lifecycle cohort; it does not claim a full '
                 'Studio or repository regression.',
    },
}
save(OUTPUT / 'summary.json', summary)
print(json.dumps({'accepted': summary['accepted'], 'output': str(OUTPUT),
                  'counting': {key: value for key, value in summary['counting'].items()
                               if key != 'rerun_case_identities'}}), flush=True)
raise SystemExit(0 if summary['accepted'] else 1)
