from pathlib import Path
import json
import os
import shutil
import subprocess

REPO = Path('/workspace/scratch/8eb34dc8ced9/quds_office_suite')
RUNTIME = Path('/workspace/scratch/8eb34dc8ced9/runtime')
OUTPUT = RUNTIME / 'main-integration'
EXPECTED_HEAD = '3d49a13d9e3d01db2a273d43affd36140475b467'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip()
assert head == EXPECTED_HEAD, head
assert not OUTPUT.exists(), OUTPUT
OUTPUT.mkdir()
shutil.copyfile(__file__, OUTPUT / 'run_main_integration.py')
support = REPO / 'docs/validation/mail-live-search-20261121/run_local.py'
shutil.copyfile(support, OUTPUT / 'qualification_support.py')
helpers = {'__name__': 'qualification_support', '__file__': str(support)}
exec(compile(support.read_text(), str(support), 'exec'), helpers)
save = helpers['save_json']
manifest = helpers['source_manifest']
changed = helpers['changed_inputs']
execute = helpers['execute']
audit_events = helpers['audit_events']
digest = helpers['digest']
env = dict(os.environ)
env.update(CI='true', FLUTTER_SUPPRESS_ANALYTICS='true', DART_SUPPRESS_ANALYTICS='true')
flutter = shutil.which('flutter')
dart = shutil.which('dart')
assert flutter is not None and dart is not None
base = [flutter, '--suppress-analytics', '--no-version-check']
engine = REPO / 'packages/quds_office_engine'
tests = [
    'test/office_vba_numeric_intrinsics_test.dart',
    'test/office_vba_numeric_conformance_test.dart',
    'test/office_vba_numeric_intrinsics_integration_test.dart',
]
incoming = [
    'packages/quds_office_engine/lib/src/automation/office_vba_language.dart',
    *['packages/quds_office_engine/' + name for name in tests],
    'packages/quds_office_engine/tool/macros/web_vba_word_numeric_smoke.dart',
]
checked = helpers['CHANGED_DART'] + incoming
for path in checked:
    assert (REPO / path).is_file(), path
before = manifest(REPO)
save(OUTPUT / 'source-before.json', before)
prior_directory = RUNTIME / 'final-corrected'
prior = json.loads((prior_directory / 'source-after.json').read_text())
prior_summary = json.loads((prior_directory / 'summary.json').read_text())
delta = changed(prior, before)
production_delta = [path for path in delta if '/lib/' in path]
assert production_delta == [incoming[0]], production_delta
assert all(path.startswith('packages/quds_office_engine/') for path in delta), delta
versions = []
for label, command in [
    ('flutter-version', [*base, '--version', '--machine']),
    ('dart-version', [dart, '--version']),
]:
    versions.append(execute(command, REPO, env, OUTPUT / (label + '.stdout'),
                            OUTPUT / (label + '.stderr'), 900))
save(OUTPUT / 'runtime-versions.json', versions)
save(OUTPUT / 'context.json', {
    'schema': 'quds-mail-live-search-merged-main-integration/v1',
    'git_head': head,
    'prior_qualified_head': prior_summary['git_head'],
    'source_input_count': len(before),
    'source_delta_against_prior_qualification': delta,
    'production_delta_against_prior_qualification': production_delta,
    'source_sha256_against_prior_qualification': {
        path: {'before': prior.get(path), 'after': before.get(path)} for path in delta
    },
    'prior_source_manifest_sha256': digest(prior_directory / 'source-after.json'),
    'environment': {name: env.get(name) for name in [
        'CI', 'FLUTTER_SUPPRESS_ANALYTICS', 'DART_SUPPRESS_ANALYTICS', 'PUB_CACHE', 'TMPDIR',
    ]},
    'qualification_support_sha256': digest(support),
    'runner_sha256': digest(Path(__file__)),
})
steps = [
    ('analysis', REPO, [*base, 'analyze', '--no-pub', '--fatal-infos',
                        '--fatal-warnings', *checked], []),
    ('format', REPO, [dart, 'format', '--output=none', '--set-exit-if-changed', *checked], []),
    ('engine', engine, [*base, 'test', '--no-pub', '--concurrency=1',
                        '--reporter=json', *tests], [engine / name for name in tests]),
]
receipts = []
for name, cwd, command, selected in steps:
    print('Starting ' + name + ': ' + json.dumps(command), flush=True)
    step_before = manifest(REPO)
    save(OUTPUT / (name + '.source-before.json'), step_before)
    receipt = execute(command, cwd, env, OUTPUT / (name + '.stdout'),
                      OUTPUT / (name + '.stderr'), 900)
    step_after = manifest(REPO)
    save(OUTPUT / (name + '.source-after.json'), step_after)
    receipt.update(name=name, source_input_count=len(step_before),
                   changed_inputs=changed(step_before, step_after))
    accepted = (receipt['exit_code'] == 0 and not receipt['timed_out']
                and receipt['stderr_bytes'] == 0 and step_before == step_after)
    if selected:
        audit = audit_events(OUTPUT / (name + '.stdout'), selected)
        save(OUTPUT / (name + '.cases.json'), audit)
        receipt['test_summary'] = {key: value for key, value in audit.items() if key != 'cases'}
        accepted = (accepted and audit['complete_lifecycle'] and audit['failed'] == 0
                    and audit['skipped'] == 0 and not audit['runtime_error_events'])
    receipt['accepted'] = accepted
    save(OUTPUT / (name + '.receipt.json'), receipt)
    receipts.append(receipt)
    print(json.dumps({'step': name, 'accepted': accepted, 'exit_code': receipt['exit_code'],
                      'stderr_bytes': receipt['stderr_bytes'], 'changed_inputs': receipt['changed_inputs'],
                      'passed': receipt.get('test_summary', {}).get('passed')}), flush=True)
after = manifest(REPO)
save(OUTPUT / 'source-after.json', after)
summary = {
    'schema': 'quds-mail-live-search-merged-main-integration/v1',
    'git_head': head,
    'accepted': (all(step['accepted'] for step in receipts)
                 and all(version['exit_code'] == 0 for version in versions) and before == after),
    'source_input_count': len(before),
    'changed_inputs_across_gate': changed(before, after),
    'steps': receipts,
    'prior_qualification_applicability': {
        'prior_qualified_head': prior_summary['git_head'],
        'source_delta': delta,
        'production_delta': production_delta,
        'mail_editor_core_store_package_sources_unchanged': True,
        'root_and_package_dependency_manifests_unchanged': True,
        'scope': 'The only production change is the isolated engine VBA-language extension. '
                 'This finite three-suite engine gate qualifies that incoming increment on the merged tree. '
                 'It does not represent a new execution of the prior Mail/Store/Editor cohorts.',
    },
}
save(OUTPUT / 'summary.json', summary)
print(json.dumps({'accepted': summary['accepted'], 'output': str(OUTPUT)}), flush=True)
raise SystemExit(0 if summary['accepted'] else 1)
