# Source this file from any directory in the current task workspace.
export PUB_CACHE=/workspace/scratch/f0616b02624b/toolchains/pub-cache
export TMPDIR=/workspace/scratch/f0616b02624b/toolchains/tmp
export DART_SUPPRESS_ANALYTICS=true
export CI=true
export PATH=/workspace/scratch/f0616b02624b/toolchains/dart-sdk/bin:$PATH
export QUDS_VALIDATION_PACKAGES=/workspace/scratch/f0616b02624b/validation-workspace/.dart_tool/package_config.json
