"""Qualify the frozen final intake against an existing published commit.

Read-only local Git audit. Writes a new scratch receipt only; never fetches,
changes refs, stages files, executes validation, or replaces C9 evidence.
"""
from pathlib import Path
from collections import Counter
import datetime
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/workspace/scratch/f0616b02624b')
REPO = ROOT / 'quds_office_suite'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
CUTOFF = ROOT / 'incoming-final-cutoff-20261120.json'
TARGET = sys.argv[1]
DESTINATION = ROOT / (sys.argv[2] if len(sys.argv) > 2 else 'final-cutoff-inclusion-20261120.json')


def raw(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env=ENV)


def git(*args):
    return raw(*args).decode().rstrip('\n')


def ancestor(older, newer):
    result = subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', older, newer],
                            env=ENV, capture_output=True)
    if result.returncode not in (0, 1):
        raise RuntimeError(result.stderr.decode())
    return result.returncode == 0


def entries(revision):
    result = {}
    for row in raw('ls-tree', '-r', '-z', revision).split(b'\0'):
        if not row:
            continue
        info, path = row.split(b'\t', 1)
        mode, kind, oid = info.decode('ascii').split(' ')
        result[path.decode()] = {'mode': mode, 'type': kind, 'object': oid}
    return result


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob_hashes(objects):
    result = {}
    with subprocess.Popen(['git', '-C', str(REPO), 'cat-file', '--batch'],
                          env=ENV, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                          stderr=subprocess.DEVNULL) as process:
        try:
            for oid in sorted(objects):
                process.stdin.write((oid + '\n').encode())
                process.stdin.flush()
                header = process.stdout.readline().decode().strip().split(' ')
                assert len(header) == 3 and header[:2] == [oid, 'blob'], header
                remaining = int(header[2])
                digest = hashlib.sha256()
                while remaining:
                    chunk = process.stdout.read(min(1024 * 1024, remaining))
                    assert chunk, oid
                    digest.update(chunk)
                    remaining -= len(chunk)
                assert process.stdout.read(1) == b'\n'
                result[oid] = digest.hexdigest()
            process.stdin.close()
            assert process.wait(timeout=30) == 0
        except BaseException:
            process.kill()
            process.wait(timeout=5)
            raise
    return result


target = git('rev-parse', TARGET)
cutoff_bytes = CUTOFF.read_bytes()
cutoff = json.loads(cutoff_bytes)
assert cutoff['schema'] == 'quds-vba-expansion-final-cutoff/v1'
baseline = cutoff['qualification_baseline']['commit']
assert ancestor(baseline, target), 'Final source must retain C9 ancestry'
known = {p['historical_head']: p for p in cutoff['historical_equivalence_proofs_at_baseline']}
proofs = {}


def qualify(ref, head):
    row = {'ref': ref, 'sha': head}
    if ancestor(head, target):
        row['status'] = 'ancestor'
        return row
    if head not in known:
        row['status'] = 'uncovered'
        return row
    if head not in proofs:
        old = known[head]
        accepted = old['accepted_ancestor']
        paths = [p.decode() for p in raw('diff', '--name-only', '-z', old['comparison_base'], head).split(b'\0') if p]
        assert paths, 'Historical equivalence needs a nonempty changed-path set'
        historical_entries = raw('ls-tree', '-r', '-z', head, '--', *paths)
        accepted_entries = raw('ls-tree', '-r', '-z', accepted, '--', *paths)
        proof = {
            'historical_head': head,
            'accepted_ancestor': accepted,
            'accepted_is_ancestor': ancestor(accepted, target),
            'comparison_base': old['comparison_base'],
            'changed_paths': paths,
            'changed_path_count': len(paths),
            'changed_modes_types_objects_exact': historical_entries == accepted_entries,
            'historical_changed_entries_sha256': sha(historical_entries),
            'accepted_changed_entries_sha256': sha(accepted_entries),
            'historical_tree': git('rev-parse', head + '^{tree}'),
            'accepted_tree': git('rev-parse', accepted + '^{tree}'),
        }
        proof['whole_tree_equal'] = proof['historical_tree'] == proof['accepted_tree']
        proof['verified'] = proof['accepted_is_ancestor'] and proof['changed_modes_types_objects_exact']
        proofs[head] = proof
    proof = proofs[head]
    row['status'] = 'historically_superseded_equivalent' if proof['verified'] else 'uncovered'
    row['accepted_ancestor'] = proof['accepted_ancestor']
    return row


branches = [qualify(r['ref'], r['sha']) for r in cutoff['current_branches']]
prs = [qualify(r['ref'], r['sha']) for r in cutoff['current_pull_requests']]
upstream = [qualify(r['ref'], r['sha']) for r in cutoff['current_upstream']]
deleted = [qualify(r['ref'], r['sha']) for r in cutoff['retained_deleted_branches']]
advanced_branches = [qualify(r['ref'], r['prior_sha']) for r in cutoff['advanced_branches']]
advanced_prs = [qualify(r['ref'], r['prior_sha']) for r in cutoff['advanced_pull_request_heads']]
prior_path = REPO / cutoff['prior_capture']['path']
assert sha(prior_path.read_bytes()) == cutoff['prior_capture']['sha256']
prior = json.loads(prior_path.read_bytes())
prior_branches = [qualify(r['ref'], r['sha']) for r in prior['branches']]
prior_prs = [qualify(r['ref'], r['sha']) for r in prior['pull_requests']]
prior_upstream = [qualify(r['ref'], r['sha']) for r in prior['upstream']]
required_heads = [{**r, 'is_ancestor': ancestor(r['sha'], target)} for r in cutoff['required_new_heads']]
assert all(r['is_ancestor'] for r in required_heads), 'Required final-intake head is missing'
all_rows = branches + prs + upstream + deleted + advanced_branches + advanced_prs + prior_branches + prior_prs + prior_upstream
uncovered = [r for r in all_rows if r['status'] == 'uncovered']
assert not uncovered, 'Final intake has uncovered refs'
before, after = entries(baseline), entries(target)
changes = [
    {'path': p, 'status': 'A' if p not in before else ('D' if p not in after else 'M'),
     'before': before.get(p), 'after': after.get(p)}
    for p in sorted(set(before) | set(after)) if before.get(p) != after.get(p)
]
baseline_review_path = REPO / 'docs/validation/office-vba-expansion-20261120/integration/final-main-review.json'
baseline_review_bytes = baseline_review_path.read_bytes()
baseline_review = json.loads(baseline_review_bytes)
assert baseline_review['frozen_source']['commit'] == baseline
baseline_inputs = baseline_review['input_entries']
assert len(baseline_inputs) == 1164
objects = {entry['object'] for row in changes for entry in [row['before'], row['after']]
           if entry and entry['type'] == 'blob'}
for path, entry in baseline_inputs.items():
    assert before[path] == {key: entry[key] for key in ['mode', 'type', 'object']}
    assert path in after and after[path]['type'] == 'blob'
    objects.add(before[path]['object'])
    objects.add(after[path]['object'])
hashes = blob_hashes(objects)
gate_inputs = {}
for path, entry in baseline_inputs.items():
    assert hashes[before[path]['object']] == entry['sha256']
    gate_inputs[path] = {**after[path], 'sha256': hashes[after[path]['object']]}
for row in changes:
    for side in ['before', 'after']:
        entry = row[side]
        row[side + '_sha256'] = hashes[entry['object']] if entry and entry['type'] == 'blob' else None
    row['in_baseline_gate_input_union'] = row['path'] in baseline_inputs
engine_changes = []
for change in changes:
    if not change['path'].startswith('packages/quds_office_engine/'):
        continue
    engine_changes.append(dict(change))
gate_changes = [r for r in changes if r['in_baseline_gate_input_union']]
outside_changes = [r for r in changes if not r['in_baseline_gate_input_union']]
assert len(engine_changes) == len(gate_changes) == 8
assert [r['path'] for r in engine_changes] == [r['path'] for r in gate_changes]

result = {
    'schema': 'quds-vba-expansion-final-cutoff-inclusion/v1',
    'audited_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repository': cutoff['repository'],
    'target_commit': target,
    'target_tree': git('rev-parse', target + '^{tree}'),
    'cutoff_path': 'docs/validation/office-vba-expansion-20261120/integration/final-cutoff-inventory.json',
    'cutoff_sha256': sha(cutoff_bytes),
    'cutoff_at_utc': cutoff['cutoff_at_utc'],
    'baseline_commit': baseline,
    'baseline_is_ancestor': True,
    'required_new_heads': required_heads,
    'summary': {
        'branch_count': len(branches), 'branches': dict(Counter(r['status'] for r in branches)),
        'pr_count': len(prs), 'prs': dict(Counter(r['status'] for r in prs)),
        'upstream_count': len(upstream), 'upstream': dict(Counter(r['status'] for r in upstream)),
        'retained_deleted_branch_count': len(deleted),
        'retained_deleted_branches_all_ancestors': all(r['status'] == 'ancestor' for r in deleted),
        'retained_advanced_branch_prior_head_count': len(advanced_branches),
        'retained_advanced_pr_prior_head_count': len(advanced_prs),
        'prior_capture_branch_count': len(prior_branches),
        'prior_capture_pr_count': len(prior_prs),
        'prior_capture_upstream_count': len(prior_upstream),
        'historical_proof_count': len(proofs),
        'historical_whole_tree_equal_count': sum(p['whole_tree_equal'] for p in proofs.values()),
        'all_historical_proofs_verified': all(p['verified'] for p in proofs.values()),
        'uncovered_count': len(uncovered),
        'all_required_new_heads_ancestors': True,
    },
    'branches': branches, 'pull_requests': prs, 'upstream': upstream,
    'retained_deleted_branches': deleted,
    'retained_advanced_branch_prior_heads': advanced_branches,
    'retained_advanced_pr_prior_heads': advanced_prs,
    'prior_capture_coverage': {'branches': prior_branches, 'pull_requests': prior_prs, 'upstream': prior_upstream},
    'historical_equivalence_proofs': [proofs[k] for k in sorted(proofs)],
    'source_delta': {'comparison': [baseline, target], 'path_count': len(changes), 'changes': changes},
    'engine_delta': {'comparison': [baseline, target], 'path_count': len(engine_changes), 'changes': engine_changes},
    'gate_input_delta': {'comparison': [baseline, target], 'path_count': len(gate_changes),
                         'unchanged_input_count': len(baseline_inputs) - len(gate_changes),
                         'changes': gate_changes},
    'outside_gate_delta': {'comparison': [baseline, target], 'path_count': len(outside_changes),
                           'changes': outside_changes},
    'gate_input_path_basis': {
        'path': baseline_review_path.relative_to(REPO).as_posix(),
        'sha256': sha(baseline_review_bytes),
        'path_count': len(baseline_inputs),
        'meaning': 'Same tracked input paths as the historical C9 static/portable/first-group union; all baseline and target bytes independently hashed. Final runtime manifests must independently match target entries.',
    },
    'target_gate_input_entries': gate_inputs,
    'network_used': False, 'refs_fetched': False, 'github_actions_used': False,
    'qualification_claim': 'Source ancestry, historical equivalence, and exact tree-entry comparison only; runtime acceptance is recorded separately.',
    'limits': [
        'The branch/PR cutoff is immutable. Later main consistency observations are separate.',
        'Historical equivalent heads require exact changed-path mode/type/blob equality to an accepted ancestor; whole-tree equality is reported separately.',
        'Source inclusion does not inherit incoming Flutter, provider, or native runtime claims across merge resolutions.',
        'The newly integrated work-in-progress Outbox core/store and Flutter host workflows are outside the Office engine gate; their incoming evidence remains historical and source-specific.',
        'The earlier C9 inclusion and main-review receipts remain source-specific historical evidence.',
    ],
}
DESTINATION.write_text(json.dumps(result, indent=2) + '\n')
assert CUTOFF.read_bytes() == cutoff_bytes
print(json.dumps({'output': str(DESTINATION), 'sha256': sha(DESTINATION.read_bytes()),
                  'target': target, 'summary': result['summary'],
                  'engine_changed_paths': [r['path'] for r in engine_changes]}, indent=2))
