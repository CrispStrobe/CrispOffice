import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/scratch/f0616b02624b')
repo = root / 'quds_office_suite'
engine = repo / 'packages/quds_office_engine'
out = root / 'validation-results'
build = root / 'toolchains/portable-build'
out.mkdir(exist_ok=True)
build.mkdir(parents=True, exist_ok=True)
dart = root / 'toolchains/dart-sdk/bin/dart'
config = repo / '.dart_tool/package_config.json'
prefix = os.environ.get('VBA_PORTABLE_PREFIX', 'expansion-portable')
if (out / (prefix + '.receipt.json')).exists():
    raise SystemExit('Archive existing portable receipts before another run: ' + prefix)
entry = 'tool/macros/web_vba_office_expansion_smoke.dart'
samples = {
    'WORD_TYPOGRAPHY_BAS_BASE64': 'example/macros/word_typography.bas',
    'POWERPOINT_SLIDESHOW_BAS_BASE64': 'example/macros/powerpoint_slideshow.bas',
    'WORD_OPTIONAL_HELPERS_BAS_BASE64': 'example/macros/word_optional_helpers.bas',
    'POWERPOINT_OPTIONAL_HELPERS_BAS_BASE64': 'example/macros/powerpoint_optional_helpers.bas',
    'WORD_PARAGRAPH_LAYOUT_BAS_BASE64': 'example/macros/word_paragraph_layout.bas',
    'POWERPOINT_TEXT_MARGINS_BAS_BASE64': 'example/macros/powerpoint_text_margins.bas',
}
defines = ['-D'+key+'='+base64.b64encode((engine/path).read_bytes()).decode() for key,path in samples.items()]
def git(*args):
    return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def hashes():
    paths = git('ls-files','packages/quds_office_engine/lib','packages/quds_office_engine/test','packages/quds_office_engine/tool','packages/quds_office_engine/example/macros','packages/legacy_doc_parser/lib','pubspec.lock').splitlines()
    return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
before = hashes()
receipt = dict(commit=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'), stages=[],
    samples={p:hashlib.sha256((engine/p).read_bytes()).hexdigest() for p in samples.values()}, source_hashes=before)
env = os.environ.copy()
env.update(PUB_CACHE=str(root/'toolchains/pub-cache'), TMPDIR=str(root/'toolchains/tmp'), DART_SUPPRESS_ANALYTICS='true', CI='true')
js = build / 'office-expansion.js'
commands = [
    ('vm',[str(dart),'--old_gen_heap_size=1024','--packages='+str(config),*defines,entry]),
    ('compile-js',[str(dart),'compile','js','-O1','--packages='+str(config),*defines,entry,'-o',str(js)]),
    ('javascript',['node','-e','globalThis.self = globalThis; require(process.argv[1])',str(js)]),
]
for name,cmd in commands:
    start = time.time()
    with (out/(prefix+'-'+name+'.stdout')).open('w') as stdout, (out/(prefix+'-'+name+'.stderr')).open('w') as stderr:
        result = subprocess.run(cmd,cwd=engine,env=env,stdout=stdout,stderr=stderr)
    stage=dict(name=name,command=cmd,exit_code=result.returncode,seconds=round(time.time()-start,3))
    receipt['stages'].append(stage)
    print(json.dumps({k:v for k,v in stage.items() if k != 'command'}),flush=True)
    if result.returncode: break
receipt['commands_passed'] = len(receipt['stages']) == 3 and all(s['exit_code'] == 0 for s in receipt['stages'])
receipt['vm_js_byte_equal'] = receipt['commands_passed'] and (out/(prefix+'-vm.stdout')).read_bytes() == (out/(prefix+'-javascript.stdout')).read_bytes()
receipt['source_unchanged'] = before == hashes()
def canonical(value):
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, list):
        return [canonical(v) for v in value]
    if isinstance(value, dict):
        return {k: canonical(v) for k, v in value.items()}
    return value
receipt['semantic_comparison'] = 'Exact canonical JSON, with integral floats normalized to integers; boolean/string types retained and no numeric tolerance.'
receipt['vm_js_semantic_equal'] = False
if receipt['commands_passed']:
    vm = canonical(json.loads((out/(prefix+'-vm.stdout')).read_text()))
    js_result = canonical(json.loads((out/(prefix+'-javascript.stdout')).read_text()))
    encode = lambda value: json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    receipt['vm_js_semantic_equal'] = encode(vm) == encode(js_result)
    receipt['result'] = vm
    (out/(prefix+'-canonical.json')).write_text(encode(vm)+'\n')
(out/(prefix+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('stages','source_hashes')},indent=2),flush=True)
raise SystemExit(0 if receipt['vm_js_semantic_equal'] and receipt['source_unchanged'] else 1)
