#!/usr/bin/env python3
"""Package a completed frozen Office VBA expansion gate; never run validation.

This collector is deliberately specific to the 2026-11-20, 80-file/30-group
acceptance. It refuses partial, stale, inconsistent, or overwritten evidence.
Only the Python standard library and read-only local Git commands are used.
No network, SDK execution, tests, CI calls, or product-source changes occur.

Run only after the final static -> portable -> shard sequence has completed:
    python collect_expansion_evidence.py
The default destinations are the new validation runtime directory and its
parent README. Existing destinations are refused rather than overwritten.
Do not redirect this collector's output into validation-results while it is
being snapshotted; use the terminal or a separate scratch output path.
"""

from __future__ import annotations

import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
import tempfile


ROOT = Path('/workspace/scratch/f0616b02624b')
REPO = ROOT / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
RESULTS = ROOT / 'validation-results'
EVIDENCE = REPO / 'docs/validation/office-vba-expansion-20261120'
EXPECTED_HEAD = 'c9cbeb1248d6b5f088d1084a8c113a743aa7a77f'
PREVIOUS_MAIN = '3ffa599ff003a6e678260df1237b01887693e546'
LATER_MAIN = 'a652a205e6daf6b4b8e3baec04db1c1b52fabd0d'
LAYOUT_BASELINE = '58000866a6a36d7cc29e2a5677ef23c2f71dff51'
CHECKPOINTS = [
    'f761cfe6d25c27fede697943a18ab89c11353d8f',
    'b6d6a26d9fcb5602ad9bd65d451aa5273881c933',
    '9e0d8173fada4ae3f22ace5c5b896c21ab5191da',
    LAYOUT_BASELINE,
    '979cfa77c3bf7718664db7ecb4f62b656a58f187',
    '40572427fc7d62b0fb2423712fa79162814b53a9',
    '050ba58acad35f41803377b385ea22c833822845',
    '89910ff6363cd45ced5faf0e48b11cac46754b28',
    '4a2607162199deedde0587b2cdb919bbf6435251',
    EXPECTED_HEAD,
]
GATE_PATHS = [
    'packages/quds_office_engine/lib',
    'packages/quds_office_engine/test',
    'packages/quds_office_engine/tool',
    'packages/quds_office_engine/example/macros',
    'packages/quds_office_editor/fonts',
    'packages/legacy_doc_parser/lib',
    'packages/quds_office_engine/pubspec.yaml',
    'packages/legacy_doc_parser/pubspec.yaml',
    'pubspec.lock',
]
STATIC_PATHS = [
    'packages/quds_office_engine',
    'packages/legacy_doc_parser/lib',
    'packages/quds_office_editor/lib/src/editor_slide/render_slide_stage.dart',
    'pubspec.lock',
]
PORTABLE_PATHS = [
    'packages/quds_office_engine/lib',
    'packages/quds_office_engine/test',
    'packages/quds_office_engine/tool',
    'packages/quds_office_engine/example/macros',
    'packages/legacy_doc_parser/lib',
    'pubspec.lock',
]
SAMPLES = {
    'WORD_TYPOGRAPHY_BAS_BASE64': 'example/macros/word_typography.bas',
    'POWERPOINT_SLIDESHOW_BAS_BASE64': 'example/macros/powerpoint_slideshow.bas',
    'WORD_OPTIONAL_HELPERS_BAS_BASE64': 'example/macros/word_optional_helpers.bas',
    'POWERPOINT_OPTIONAL_HELPERS_BAS_BASE64': 'example/macros/powerpoint_optional_helpers.bas',
    'WORD_PARAGRAPH_LAYOUT_BAS_BASE64': 'example/macros/word_paragraph_layout.bas',
    'POWERPOINT_TEXT_MARGINS_BAS_BASE64': 'example/macros/powerpoint_text_margins.bas',
}
DRIVERS = [
    'collect_expansion_evidence.py',
    'setup_validation.py',
    'finalize_validation_setup.py',
    'validation-env.sh',
    'run_vba_validation.py',
    'prepare_expansion_validation.py',
    'run_expansion_static.py',
    'run_expansion_portable.py',
    'run_expansion_shards.py',
    'run_cache_regression.py',
    'run_arguments_portable.py',
    'run_portable_office_layout.py',
    'audit_incoming_expansion.py',
    'review_ppt_short_boxes.dart',
    'word_incremental_layout_differential_test.dart',
    'word_incremental_layout_differential_test.bootstrap.isolate.dart',
]
DEVELOPMENT_PATTERNS = [
    'arguments-*.log',
    'word-*.log',
    'incremental-layout-*.log',
    'incremental-layout-*.json',
    'ppt-*.log',
    'review-ppt-*.jsonl',
    'arguments-portable-results/*.json',
    'arguments-portable-results/*.jsonl',
    'arguments-portable-results/*.log',
    'arguments-portable-results/*.stdout',
    'arguments-portable-results/*.stderr',
]
NEW_FILES = [
    'office_vba_arguments_test', 'office_vba_arguments_integration_test',
    'office_vba_word_argument_shapes_test', 'office_vba_word_paragraph_layout_test',
    'office_vba_word_paragraph_layout_integration_test', 'office_vba_powerpoint_margins_test',
    'office_vba_powerpoint_margins_integration_test', 'slide_text_insets_preservation_test',
    'word_incremental_layout_differential_test', 'word_incremental_layout_test',
    'word_incremental_layout_prefix_test', 'word_zotero_note_table_test',
    'word_zotero_note_tables_integration_test', 'style_cascade_test',
    'word_referenced_styles_and_breaks_test', 'word_paragraph_mark_layout_test',
]
SNAPSHOTS: dict[Path, str] = {}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def checksum(path: Path) -> str:
    require(path.is_file(), f'Missing required file: {path}')
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def capture(path: Path) -> bytes:
    require(path.is_file() and not path.is_symlink(), f'Expected regular evidence file: {path}')
    data = path.read_bytes()
    digest = sha_bytes(data)
    require(path not in SNAPSHOTS or SNAPSHOTS[path] == digest,
            f'Evidence changed while collecting: {path}')
    SNAPSHOTS[path] = digest
    return data


def reject_constant(value: str):
    raise ValueError(f'Non-finite JSON constant: {value}')


def json_load(data: bytes | str):
    return json.loads(data, parse_constant=reject_constant)


def read_json(path: Path):
    return json_load(capture(path))


def encode(value) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=False,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')


def pretty(value) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8')


def canonical(value):
    # Test float specifically; bool is an int subclass in Python and must stay bool.
    if type(value) is float:
        require(math.isfinite(value), 'Non-finite portable result')
        return int(value) if value.is_integer() else value
    if isinstance(value, list):
        return [canonical(item) for item in value]
    if isinstance(value, dict):
        return {key: canonical(item) for key, item in value.items()}
    return value


def git(*args: str) -> str:
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def git_bytes(*args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def ancestor(older: str, newer: str) -> bool:
    result = subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', older, newer],
                            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    require(result.returncode in (0, 1), f'Cannot inspect ancestry of {older}')
    return result.returncode == 0


def git_tree_entries(revision: str) -> dict[str, dict[str, str]]:
    result = {}
    for record in git_bytes('ls-tree', '-r', '-z', '--full-tree', revision).split(b'\0'):
        if not record:
            continue
        description, raw_path = record.split(b'\t', 1)
        mode, kind, oid = description.decode('ascii').split(' ')
        path = raw_path.decode('utf-8')
        require(path not in result, f'Duplicate tree entry in {revision}: {path}')
        result[path] = {'mode': mode, 'type': kind, 'object': oid}
    return result


def git_blob_hashes(objects: set[str]) -> dict[str, str]:
    """Hash existing blobs through one read-only process with bounded buffering."""
    result = {}
    with subprocess.Popen(['git', '-C', str(REPO), 'cat-file', '--batch'],
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                          stderr=subprocess.DEVNULL) as process:
        try:
            require(process.stdin is not None and process.stdout is not None, 'Git batch pipes unavailable')
            for oid in sorted(objects):
                process.stdin.write((oid + '\n').encode('ascii'))
                process.stdin.flush()
                header = process.stdout.readline().decode('ascii').strip().split(' ')
                require(len(header) == 3 and header[:2] == [oid, 'blob'] and header[2].isdigit(),
                        f'Missing or non-blob prospective input object: {oid}')
                remaining = int(header[2])
                digest = hashlib.sha256()
                while remaining:
                    block = process.stdout.read(min(1024 * 1024, remaining))
                    require(bool(block), f'Truncated Git object: {oid}')
                    digest.update(block)
                    remaining -= len(block)
                require(process.stdout.read(1) == b'\n', f'Invalid Git batch delimiter: {oid}')
                result[oid] = digest.hexdigest()
            process.stdin.close()
            require(process.wait(timeout=30) == 0, 'Git blob verification failed')
        except BaseException:
            process.kill()
            process.wait(timeout=5)
            raise
    return result


def tree_changes(before: dict, after: dict) -> list[dict]:
    return [{'path': path, 'status': 'A' if path not in before else ('D' if path not in after else 'M'),
             'before': before.get(path), 'after': after.get(path)}
            for path in sorted(set(before) | set(after)) if before.get(path) != after.get(path)]


def strip_hashes(receipt: dict) -> dict:
    return {key: value for key, value in receipt.items() if key != 'source_hashes'}


def nonnegative_int(value, context: str) -> int:
    require(type(value) is int and value >= 0, f'Invalid integer in {context}: {value!r}')
    return value


def test_path(value: str) -> str:
    require(isinstance(value, str), 'Test path must be text')
    path = Path(value)
    if path.is_absolute():
        path = path.relative_to(ENGINE)
    result = path.as_posix()
    require(result.startswith('test/') and '..' not in path.parts and result.endswith('.dart'),
            f'Unexpected test path: {value}')
    return result


def parse_test_events(path: Path, files: list[str]) -> dict:
    events = []
    for number, line in enumerate(capture(path).splitlines(), 1):
        require(bool(line.strip()), f'Empty JSONL event at {path}:{number}')
        event = json_load(line)
        require(isinstance(event, dict) and isinstance(event.get('type'), str),
                f'Invalid JSONL event at {path}:{number}')
        events.append(event)
    require(events and events[0]['type'] == 'start', f'Missing runner start: {path}')
    require(sum(event['type'] == 'start' for event in events) == 1, f'Multiple runs in {path}')
    done = [event for event in events if event['type'] == 'done']
    require(len(done) == 1 and events[-1] == done[0], f'Incomplete runner output: {path}')
    suites = {}
    declared_counts = {}
    tests = {}
    completions = {}
    for event in events:
        kind = event['type']
        if kind == 'suite':
            suite = event['suite']
            require(suite['id'] not in suites and suite['platform'] == 'vm',
                    f'Duplicate or non-VM suite: {path}')
            suites[suite['id']] = test_path(suite['path'])
        elif kind == 'group' and event['group'].get('parentID') is None:
            group = event['group']
            require(group['suiteID'] not in declared_counts, f'Duplicate root test group: {path}')
            declared_counts[group['suiteID']] = nonnegative_int(group['testCount'],
                                                                str(path) + '/root testCount')
        elif kind == 'testStart':
            test = event['test']
            require(test['id'] not in tests, f'Duplicate test ID: {path}')
            tests[test['id']] = test
        elif kind == 'testDone':
            require(event['testID'] not in completions, f'Duplicate completion: {path}')
            require(event.get('result') in ('success', 'failure', 'error'),
                    f'Unknown test result: {path}')
            require(type(event.get('hidden')) is bool and type(event.get('skipped')) is bool,
                    f'Missing completion flags: {path}')
            completions[event['testID']] = event
    require(Counter(suites.values()) == Counter(files), f'Wrong suite coverage: {path}')
    require(set(declared_counts) == set(suites), f'Missing root test-group counts: {path}')
    require(set(tests) == set(completions), f'Unfinished or unknown tests: {path}')
    all_suites = [event for event in events if event['type'] == 'allSuites']
    require(len(all_suites) == 1 and all_suites[0]['count'] == len(files),
            f'Wrong allSuites count: {path}')
    per_file = {file: {'passed': 0, 'failed': 0, 'skipped': 0, 'hidden': 0, 'tests': []}
                for file in files}
    for identifier, event in completions.items():
        test = tests[identifier]
        require(test['suiteID'] in suites, f'Unknown suite for test: {path}')
        item = per_file[suites[test['suiteID']]]
        if event['hidden']:
            item['hidden'] += 1
            require(event['result'] == 'success' and not event['skipped'],
                    f'Hidden load/setup/cleanup did not pass: {path}')
            continue
        if event['skipped']:
            item['skipped'] += 1
        elif event['result'] == 'success':
            item['passed'] += 1
        else:
            item['failed'] += 1
        item['tests'].append({'id': identifier, 'name': test['name'],
                              'result': event['result'], 'skipped': event['skipped']})
    for identifier, file in suites.items():
        counts = per_file[file]
        require(sum(counts[key] for key in ('passed', 'failed', 'skipped')) == declared_counts[identifier],
                f'Not every declared test completed in {file}: {path}')
    return {'per_file': per_file, 'runner_done': done,
            'errors': [event for event in events if event['type'] == 'error'],
            'passed': sum(item['passed'] for item in per_file.values()),
            'failed': sum(item['failed'] for item in per_file.values()),
            'skipped': sum(item['skipped'] for item in per_file.values()),
            'jsonl_sha256': SNAPSHOTS[path]}


def check_raw_receipt(receipt: dict, parsed: dict, name: str, passing: bool = True) -> None:
    require(receipt.get('source_unchanged') is True, f'Source changed during {name}')
    for key in ('passed', 'failed', 'skipped'):
        require(nonnegative_int(receipt.get(key), name + '/' + key) == parsed[key],
                f'Raw events disagree with {name}/{key}')
    require(receipt.get('runner_done') == parsed['runner_done'], f'Runner done mismatch: {name}')
    require(len(receipt.get('errors', [])) == len(parsed['errors']), f'Error count mismatch: {name}')
    if passing:
        require(receipt.get('exit_code') == 0 and receipt['failed'] == 0 and receipt['skipped'] == 0,
                f'Nonpassing receipt: {name}')
        require(not parsed['errors'] and parsed['runner_done'][0].get('success') is True,
                f'Runner did not report complete success: {name}')


def expected_manifest_paths(prefixes: list[str]) -> set[str]:
    return set(git('ls-files', '--', *prefixes).splitlines())


def check_manifest(receipt: dict, prefixes: list[str], name: str) -> dict[str, str]:
    values = receipt.get('source_hashes')
    require(isinstance(values, dict) and values, f'Missing source manifest: {name}')
    require(set(values) == expected_manifest_paths(prefixes), f'Incomplete source domain: {name}')
    for path, digest in values.items():
        require(not PurePosixPath(path).is_absolute() and '..' not in PurePosixPath(path).parts,
                f'Invalid source path: {path}')
        require(isinstance(digest, str) and re.fullmatch(r'[0-9a-f]{64}', digest) is not None,
                f'Invalid source digest: {name}/{path}')
    return values


def check_current_sources(head: str, hashes: dict[str, str]) -> None:
    require(git('rev-parse', 'HEAD') == head, 'HEAD changed while collecting evidence')
    changed = set(git('diff', '--name-only', 'HEAD', '--').splitlines())
    require(not changed.intersection(hashes), 'Validated source differs from the frozen commit')
    for path, digest in hashes.items():
        require(checksum(REPO / path) == digest, f'Source changed since validation: {path}')


def check_portable(receipt: dict, head: str, tree: str) -> tuple[dict, list[dict]]:
    require(receipt.get('commit') == head and receipt.get('tree') == tree, 'Stale portable receipt')
    require(receipt.get('source_unchanged') is True and receipt.get('commands_passed') is True
            and receipt.get('vm_js_semantic_equal') is True, 'Portable run did not pass')
    stages = receipt.get('stages', [])
    require([stage.get('name') for stage in stages] == ['vm', 'compile-js', 'javascript']
            and all(stage.get('exit_code') == 0 for stage in stages), 'Incomplete portable stages')
    sample_hashes = {path: checksum(ENGINE / path) for path in SAMPLES.values()}
    require(receipt.get('samples') == sample_hashes, 'Portable BAS samples differ from frozen source')
    for stage in stages[:2]:
        defines = [item for item in stage['command'] if item.startswith('-D')]
        require(len(defines) == len(SAMPLES), f'Wrong portable defines: {stage["name"]}')
        by_key = {}
        for item in defines:
            key, value = item[2:].split('=', 1)
            require(key not in by_key, 'Duplicate portable define')
            by_key[key] = value
        require(set(by_key) == set(SAMPLES), 'Portable define names differ')
        for key, path in SAMPLES.items():
            require(base64.b64decode(by_key[key], validate=True) == (ENGINE / path).read_bytes(),
                    f'Portable command did not receive exact BAS bytes: {path}')
    vm_raw = capture(RESULTS / 'expansion-portable-vm.stdout')
    js_raw = capture(RESULTS / 'expansion-portable-javascript.stdout')
    vm = canonical(json_load(vm_raw))
    javascript = canonical(json_load(js_raw))
    require(encode(vm) == encode(javascript), 'Portable canonical JSON differs')
    require(encode(receipt['result']) == encode(vm), 'Portable receipt result differs')
    require(receipt.get('vm_js_byte_equal') is (vm_raw == js_raw), 'Raw byte equality misreported')
    require(capture(RESULTS / 'expansion-portable-canonical.json') == encode(vm),
            'Recorded canonical JSON differs')
    require(vm['paragraphsAndMargins']['insetBoundaryEmus'] == [1, 2147483647],
            'Missing exact EMU boundaries')
    require(vm['paragraphsAndMargins']['additionalReopens'] == 2, 'Missing repeated reopens')
    earlier = vm['previousTypographyAndSlideshow']
    require(all(earlier[key] is True for key in
                ['immutableValidation', 'unchangedCallerInput', 'secondSaveSemanticMatch']),
            'Previous examples lost transaction/persistence checks')
    specifications = [
        ('word_typography.bas', earlier['word']['steps'], 12),
        ('powerpoint_slideshow.bas', earlier['powerpoint']['steps'], 12),
        ('word_optional_helpers.bas', vm['optionalHelpers']['word']['operations'], 7),
        ('powerpoint_optional_helpers.bas', vm['optionalHelpers']['powerpoint']['operations'], 5),
        ('word_paragraph_layout.bas', vm['paragraphsAndMargins']['word']['operations'], 10),
        ('powerpoint_text_margins.bas', vm['paragraphsAndMargins']['powerpoint']['operations'], 5),
    ]
    examples = []
    for name, actual, expected in specifications:
        require(type(actual) is int and actual == expected, f'Unexpected operation count for {name}')
        path = 'example/macros/' + name
        examples.append({'file': path, 'operations': actual, 'sha256': sample_hashes[path]})
    compact = strip_hashes(receipt)
    compact['stages'] = [{key: value for key, value in stage.items() if key != 'command'}
                         for stage in stages]
    compact['full_commands'] = 'acceptance-evidence.tar.gz: validation-results/expansion-portable.receipt.json'
    compact['comparison_recomputed_by_collector'] = True
    compact['vm_stdout_sha256'] = sha_bytes(vm_raw)
    compact['javascript_stdout_sha256'] = sha_bytes(js_raw)
    compact['canonical_json_sha256'] = sha_bytes(encode(vm))
    compact['examples'] = examples
    return compact, examples


def check_differential(per_file: dict[str, dict]) -> dict:
    relative = 'test/word_incremental_layout_differential_test.dart'
    repo_path = 'packages/quds_office_engine/' + relative
    current = (REPO / repo_path).read_text()
    baseline_bytes = git_bytes('show', LAYOUT_BASELINE + ':' + repo_path)
    baseline = baseline_bytes.decode('utf-8')
    previous_lines = iter(current.splitlines())
    preserved = all(any(line == candidate for candidate in previous_lines)
                    for line in baseline.splitlines())
    require(preserved, 'Original differential source was removed or changed')
    original_markers = [
        "test('same-height edits actually converge and reuse the tail'",
        'for (var index = 0; index < 10; index++)',
        "_equivalent(document, previous, 'same-height edit $index');",
        'for (final structures in <bool>[false, true])',
        'for (final seed in <int>[7, 43, 109])',
        'for (var step = 0; step < 48; step++)',
        "'seed=$seed structures=$structures step=$step'",
        'for (final endnote in <bool>[false, true])',
        "_equivalent(document, actual, 'note fallback');",
        "test('discarded state and section-list changes use fresh flow'",
        "_equivalent(document, previous, 'discarded state');",
        "_equivalent(document, previous, 'section-list change');",
    ]
    require(all(marker in current and marker in baseline for marker in original_markers),
            'Original comparison-count source markers changed')
    focused_markers = [
        'for (final editText in <bool>[true, false])',
        "_equivalent(document, previous, 'initial unwrapped cache');",
        "_equivalent(document, previous, 'edited with a wrapping frame');",
        "_equivalent(document, previous, 'clean target after frame removal');",
    ]
    require(all(marker in current for marker in focused_markers), 'Focused comparison markers changed')
    require(current.count('_equivalent(') == 9 and baseline.count('_equivalent(') == 6,
            'Unexpected differential comparison call sites')
    require(per_file[relative]['passed'] == 12, 'Expected 12 final differential cases')
    historical = read_json(EVIDENCE / 'integration/layout/receipt.json')
    require(historical['tests_passed'] == 10 and historical['fresh_engine_differential_comparisons'] == 302,
            'Historical layout receipt disagrees with source derivation')
    return {'test': relative, 'test_sha256': checksum(REPO / repo_path),
            'passing_cases': 12, 'fresh_engine_geometry_comparisons': 308,
            'derivation_kind': 'Source-reviewed fixed loop bounds, tied to the final passing file; not a runtime counter',
            'original': {'cases': 10, 'comparisons': 302,
                         'formula': '10 + (2 structures * 3 seeds * 48 edits) + 2 note cases + 2 state/section comparisons',
                         'baseline_commit': LAYOUT_BASELINE, 'baseline_sha256': sha_bytes(baseline_bytes),
                         'all_original_lines_preserved_in_order': preserved},
            'focused': {'cases': 2, 'comparisons': 6,
                        'formula': '2 text/font edit cases * 3 before/during/after frame comparisons'},
            'metrics': 'Pure Dart null-font fallback metrics; independent public geometry snapshot'}


def check_cache_reproduction() -> dict:
    reproduction = read_json(RESULTS / 'cache-invalidation-reproduction.json')
    require(reproduction.get('restored_sources') is True and reproduction['old_failed_cases'] == 2
            and reproduction['fixed_passed_cases'] == 2, 'Incomplete cache negative control')
    relative = 'test/word_incremental_layout_differential_test.dart'
    negative = read_json(RESULTS / 'cache-invalidation-negative-control.receipt.json')
    fixed = read_json(RESULTS / 'cache-invalidation-fixed.receipt.json')
    negative_raw = parse_test_events(RESULTS / 'cache-invalidation-negative-control.jsonl', [relative])
    fixed_raw = parse_test_events(RESULTS / 'cache-invalidation-fixed.jsonl', [relative])
    check_raw_receipt(negative, negative_raw, 'cache-negative-control', passing=False)
    check_raw_receipt(fixed, fixed_raw, 'cache-fixed')
    require(negative['exit_code'] == 1 and negative_raw['passed'] == 0 and negative_raw['failed'] == 2
            and negative_raw['skipped'] == 0 and negative_raw['runner_done'][0]['success'] is False,
            'Negative control did not demonstrate two failures')
    require(fixed_raw['passed'] == 2, 'Fixed cache control must pass both focused cases')
    require(negative.get('commit') == fixed.get('commit') == reproduction['fixed_commit']
            and ancestor(reproduction['old_production_commit'], reproduction['fixed_commit'])
            and ancestor(reproduction['fixed_commit'], EXPECTED_HEAD),
            'Cache-control revision identities or ancestry differ')
    require(all('incremental/full geometry differs' in event['error'] for event in negative_raw['errors']),
            'Negative control failed for an unrelated reason')
    for path, digest in reproduction['fixed_source_sha256'].items():
        require(fixed['source_hashes'][path] == digest, 'Fixed control source mismatch')
        old = git_bytes('show', reproduction['old_production_commit'] + ':' + path)
        require(negative['source_hashes'][path] == sha_bytes(old), 'Negative control did not use old production source')
    fixture = 'packages/quds_office_engine/' + relative
    require(negative['source_hashes'][fixture] == fixed['source_hashes'][fixture]
            == checksum(REPO / fixture), 'Cache-control regression fixture changed')
    return {**reproduction, 'included_in_acceptance_totals': False,
            'negative_control': strip_hashes(negative), 'fixed_control': strip_hashes(fixed),
            'current_source_sha256': {path: checksum(REPO / path)
                                      for path in reproduction['fixed_source_sha256']},
            'interpretation': 'Supplemental two-failure/two-pass reproduction on the recorded old/fixed sources; final coverage comes from the final gate.'}


def check_premerge_review(head: str, tree: str, merged: dict[str, str]) -> dict:
    path = EVIDENCE / 'integration/final-main-review.json'
    review = read_json(path)
    require(review.get('schema') == 'quds-vba-expansion-final-main-review/v1'
            and review.get('frozen_source') == {'commit': head, 'tree': tree}
            and review.get('network_used') is False and review.get('github_actions_used') is False,
            'Premerge review does not describe the frozen qualification source')
    observed = review['observed_main']
    main_head = observed['commit']
    require(re.fullmatch(r'[0-9a-f]{40}', main_head) is not None
            and observed['tree'] == git('rev-parse', main_head + '^{tree}')
            and observed['parents'] == git('show', '-s', '--format=%P', main_head).split(),
            'Observed main identities differ from Git objects')
    require(git('rev-parse', 'refs/remotes/origin/main') == main_head,
            'Fetched main has moved beyond the premerge review; refresh that proof before collection')
    base = git('merge-base', head, main_head)
    actual_ancestry = {'frozen_is_ancestor_of_observed_main': ancestor(head, main_head),
                       'observed_main_is_ancestor_of_frozen': ancestor(main_head, head),
                       'merge_base': base, 'merge_base_tree': git('rev-parse', base + '^{tree}')}
    require(review.get('ancestry') == actual_ancestry and base == LATER_MAIN
            and not actual_ancestry['frozen_is_ancestor_of_observed_main']
            and not actual_ancestry['observed_main_is_ancestor_of_frozen'],
            'Premerge ancestry changed')
    prospective = review['prospective_merge']
    future_tree = prospective['tree']
    require(re.fullmatch(r'[0-9a-f]{40}', future_tree) is not None
            and prospective.get('method') == 'git merge-tree --write-tree'
            and prospective.get('ordered_heads') == [head, main_head]
            and prospective.get('exit_code') == 0 and prospective.get('conflicts') == []
            and prospective.get('actual_head_or_refs_changed') is False
            and prospective.get('working_tree_changed_by_merge_tree') is False
            and prospective.get('delta_from_frozen_equals_incoming_main_delta') is True
            and git('cat-file', '-t', future_tree) == 'tree',
            'Missing clean prospective native Git merge tree')
    # Inspect the already recorded result; never create a merge or mutate refs here.
    frozen_entries = git_tree_entries(tree)
    main_entries = git_tree_entries(observed['tree'])
    future_entries = git_tree_entries(future_tree)
    base_entries = git_tree_entries(actual_ancestry['merge_base_tree'])
    recorded_inputs = review['input_entries']
    summary = review['validated_input_union']
    require(set(recorded_inputs) == set(merged) and len(merged) == summary['unique_inputs'] == 1164,
            'Premerge review does not cover the exact final validation-input union')
    require(all(summary.get(key) == [] for key in
                ['manifest_hash_conflicts', 'frozen_hash_mismatches',
                 'prospective_merge_mismatches', 'missing_paths']), 'Premerge review contains input mismatches')
    # The audit uses Python's default ensure_ascii=True and no trailing newline.
    # This intentionally differs from encode(), which writes our file format.
    review_digest = lambda value: sha_bytes(json.dumps(value, sort_keys=True,
                                                       separators=(',', ':')).encode('utf-8'))
    require(summary['manifest_union_sha256'] == review_digest(merged)
            and summary['git_entry_union_sha256'] == review_digest(recorded_inputs),
            'Premerge review union/dictionary digest differs')
    manifests = review['validation_manifests']
    require([item['path'] for item in manifests] == [
        'validation-results/expansion-final-static.receipt.json',
        'validation-results/expansion-portable.receipt.json',
        'validation-results/expansion-shard01.receipt.json'], 'Unexpected premerge manifest inputs/order')
    original_manifests = {}
    for item in manifests:
        current = read_json(ROOT / item['path'])
        original_manifests[item['path']] = current['source_hashes']
        require(item['sha256'] == SNAPSHOTS[ROOT / item['path']]
                and item['commit'] == current['commit'] == head
                and item['source_unchanged'] is current['source_unchanged'] is True
                and item['source_input_count'] == len(current['source_hashes']),
                'Premerge review refers to a different validation receipt')
    all_objects = set()
    for source, digest in merged.items():
        frozen = frozen_entries.get(source)
        require(frozen is not None and frozen['type'] == 'blob'
                and future_entries.get(source) == frozen,
                f'Prospective merge changes a validated mode/type/blob: {source}')
        recorded = recorded_inputs[source]
        require({key: recorded[key] for key in ['mode', 'type', 'object']} == frozen
                and recorded['sha256'] == digest, f'Premerge input entry differs: {source}')
        require(recorded.get('manifest_sources') == [Path(item['path']).name for item in manifests
                                                     if source in original_manifests[item['path']]],
                f'Premerge original manifest provenance differs: {source}')
        all_objects.add(frozen['object'])
        if source in main_entries:
            require(main_entries[source]['type'] == 'blob', f'Observed main input is not a blob: {source}')
            all_objects.add(main_entries[source]['object'])
    blob_hashes = git_blob_hashes(all_objects)
    for source, digest in merged.items():
        require(blob_hashes[frozen_entries[source]['object']] == digest,
                f'Frozen/prospective Git bytes differ from final source manifest: {source}')
    mismatches = []
    for source, digest in sorted(merged.items()):
        frozen, incoming = frozen_entries[source], main_entries.get(source)
        incoming_hash = blob_hashes[incoming['object']] if incoming else None
        if incoming != frozen or incoming_hash != digest:
            mismatches.append({'path': source, 'frozen': frozen, 'observed_main': incoming,
                               'manifest_sha256': digest, 'frozen_sha256': blob_hashes[frozen['object']],
                               'observed_main_sha256': incoming_hash})
    branch_only = {
        'packages/quds_office_engine/CHANGELOG.md',
        'packages/quds_office_engine/lib/src/word/layout/word_incremental_layout.dart',
        'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
        'packages/quds_office_engine/test/word_incremental_layout_differential_test.dart',
    }
    require({item['path'] for item in mismatches} == branch_only
            and summary['observed_main_mismatches'] == mismatches
            and summary['observed_main_exact_mode_type_blob_and_hash_matches'] == len(merged) - len(mismatches)
            and summary['frozen_hash_matches_manifest'] == len(merged)
            and summary['prospective_merge_exact_mode_type_blob_and_hash_matches'] == len(merged),
            'Direct observed-main comparison is not the reviewed four-input difference')
    incoming_delta = tree_changes(base_entries, main_entries)
    prospective_delta = tree_changes(frozen_entries, future_entries)
    direct_delta = tree_changes(frozen_entries, main_entries)
    incoming_record = review['incoming_main_delta']
    direct_record = review['direct_frozen_to_observed_main_delta']
    require(incoming_delta == prospective_delta == incoming_record['changes']
            and incoming_record['comparison'] == [base, main_head]
            and len(incoming_delta) == incoming_record['path_count'] == 10
            and incoming_record['validated_input_overlap'] == []
            and not set(merged).intersection(item['path'] for item in incoming_delta),
            'Prospective merge does not preserve the exact outside-input incoming delta')
    require(direct_delta == direct_record['changes'] and direct_record['comparison'] == [head, main_head]
            and len(direct_delta) == direct_record['path_count'] == 14,
            'Direct frozen-to-main delta differs from review')
    production_paths = [item['path'] for item in incoming_delta if not item['path'].startswith('docs/')]
    require(production_paths == incoming_record['production_paths']
            == ['packages/quds_office_editor/example/lib/studio_licenses.dart']
            and incoming_record['documentation_or_evidence_paths'] == 9,
            'Incoming changes exceed the reviewed Mail evidence/license-loader scope')
    preserved = [{'path': source, 'frozen': frozen_entries[source],
                  'prospective_merge': future_entries[source], 'exact': True}
                 for source in sorted(branch_only)]
    require(review['preserved_cache_fix_and_regressions'] == preserved,
            'Cache fix/regression preservation entries differ')
    return {'schema': 'quds-vba-expansion-collected-premerge/v1',
            'status': 'Verified prospective Git objects only; actual final merge remains pending',
            'qualified_source': {'commit': head, 'tree': tree},
            'observed_main': observed, 'ancestry': actual_ancestry,
            'prospective_tree': future_tree, 'prospective_method_recorded': prospective['method'],
            'prospective_method_reexecuted_by_collector': False,
            'review_path': '../integration/final-main-review.json',
            'review_sha256': SNAPSHOTS[path],
            'review_manifest_union_sha256': summary['manifest_union_sha256'],
            'review_git_entry_union_sha256': summary['git_entry_union_sha256'],
            'review_digest_encoding': 'Sorted compact JSON, ensure_ascii=True, UTF-8, no trailing newline',
            'validated_inputs': len(merged), 'exact_mode_type_blob_and_sha256_matches': len(merged),
            'comparison_recomputed_against_all_final_manifests': True,
            'direct_observed_main_mismatch_count': len(mismatches),
            'direct_observed_main_mismatch_paths': sorted(branch_only),
            'incoming_outside_input_path_count': len(incoming_delta),
            'incoming_documentation_or_evidence_paths': 9,
            'incoming_production_paths': production_paths,
            'incoming_changes': incoming_delta,
            'qualification_extended_to_observed_main': False,
            'actual_final_merge_claimed': False,
            'limits': ['The receipt concerns the captured main head; no network refresh is performed.',
                       'Later evidence commits may change the full tree without changing validated inputs.',
                       'Incoming Flutter/license-loader/Mail runtime behavior was not executed by this proof.']}


def classification(relative: str) -> str:
    if relative.startswith('validation-results/pre-cache-fix/'):
        return 'excluded-pre-cache-fix-attempt-including-real-regression'
    if relative.startswith('validation-results/pre-main-refresh/'):
        return 'excluded-pre-main-refresh-attempt-interrupted-before-source-change'
    name = Path(relative).name
    if relative.startswith('validation-results/'):
        if name.startswith('cache-invalidation-'):
            return 'supplemental-cache-reproduction-not-added-to-total'
        if re.match(r'expansion-shard\d{2}\.', name) or name.startswith('expansion-acceptance.receipt'):
            return 'final-acceptance'
        if name.startswith(('expansion-final-', 'expansion-portable-')) or name == 'expansion-portable.receipt.json':
            return 'final-static-or-portable'
        if name in ('expansion-selection.json', 'expansion-shards.json', 'environment.json') or name.startswith('test-runner-compile-bounded'):
            return 'final-selection-or-environment'
        return 'excluded-development-setup-or-aborted-attempt'
    if relative.startswith('drivers/'):
        return 'reproduction-driver'
    if relative.startswith('runtime-configuration/'):
        return 'runtime-configuration-no-sdk-or-cache-binaries'
    if relative.startswith('frozen-inputs/'):
        return 'frozen-test-example-or-driver-source'
    if relative.startswith('integration/'):
        return 'intake-or-earlier-integration-evidence-not-added-to-total'
    return 'excluded-development-evidence'


def archive_inputs(selection: list[str]) -> tuple[dict[str, Path], set[str]]:
    members: dict[str, Path] = {}

    def add(name: str, path: Path) -> None:
        require(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts,
                f'Unsafe archive name: {name}')
        require(path.is_file() and not path.is_symlink(), f'Unsafe or missing archive input: {path}')
        require(name not in members or members[name] == path, f'Duplicate archive name: {name}')
        require(path.stat().st_size <= 64 * 1024 * 1024,
                f'Unexpected large evidence file; inspect explicitly before packaging: {path}')
        members[name] = path

    result_names = set()
    for path in sorted(RESULTS.rglob('*')):
        require(not path.is_symlink(), f'Symlink inside validation-results: {path}')
        if path.is_file():
            relative = path.relative_to(ROOT).as_posix()
            add(relative, path)
            result_names.add(relative)
    require(any('/pre-cache-fix/' in name for name in result_names), 'Missing pre-cache-fix history')
    require(any('/pre-main-refresh/' in name for name in result_names), 'Missing interrupted main-refresh history')
    for name in DRIVERS:
        add('drivers/' + name, ROOT / name)
    for pattern in DEVELOPMENT_PATTERNS:
        for path in sorted(ROOT.glob(pattern)):
            if path.is_file():
                add('development/' + path.relative_to(ROOT).as_posix(), path)
    for name in ['arguments-first-test.log', 'arguments-integration-test.log',
                 'incremental-layout-differential-first.log', 'incremental-layout-differential-second.log',
                 'ppt-insets-preservation.log', 'word-compiler-layout-tests.log',
                 'word-native-layout-tests-final.log', 'word-legacy-layout-tests.log']:
        require('development/' + name in members, f'Missing expected development log: {name}')
    for path in sorted((EVIDENCE / 'integration').rglob('*')):
        if path.is_file():
            add('integration/' + path.relative_to(EVIDENCE / 'integration').as_posix(), path)
    configuration = {
        'engine-package-config.json': REPO / '.dart_tool/package_config.json',
        'validation-package-config.json': ROOT / 'validation-workspace/.dart_tool/package_config.json',
        'validation-pubspec.yaml': ROOT / 'validation-workspace/pubspec.yaml',
        'validation-pubspec.lock': ROOT / 'validation-workspace/pubspec.lock',
        'test-runner.d': ROOT / 'toolchains/test-runner/test-runner.d',
    }
    for name, path in configuration.items():
        add('runtime-configuration/' + name, path)
    sources = ['packages/quds_office_engine/' + path for path in selection]
    sources += ['packages/quds_office_engine/' + path for path in SAMPLES.values()]
    sources += ['packages/quds_office_engine/tool/macros/' + name for name in
                ['web_vba_office_expansion_smoke.dart', 'web_vba_arguments_smoke.dart',
                 'web_vba_office_layout_smoke.dart']]
    for path in sources:
        add('frozen-inputs/' + path, REPO / path)
    require(sum(path.stat().st_size for path in members.values()) <= 256 * 1024 * 1024,
            'Unexpected evidence volume; inspect before creating archive')
    return members, result_names


def write_archive(path: Path, members: dict[str, Path]) -> dict:
    records = []
    for name, source in sorted(members.items()):
        digest = checksum(source)
        require(source not in SNAPSHOTS or SNAPSHOTS[source] == digest,
                f'Evidence changed before archive: {source}')
        SNAPSHOTS[source] = digest
        records.append({'path': name, 'bytes': source.stat().st_size, 'sha256': digest,
                        'classification': classification(name)})
    index = {'schema': 'quds-vba-expansion-archive/v1', 'member_count': len(records),
             'uncompressed_bytes': sum(record['bytes'] for record in records), 'members': records,
             'policy': 'Every regular validation-results file, explicit task development log patterns, reproduction drivers, configuration, integration evidence, and frozen small test/example sources. SDK, pub cache, generated JS/kernel binaries, and Office fixture binaries are not copied.'}
    manifest = pretty(index)
    with path.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', compresslevel=6, fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as archive:
                for record in records:
                    info = tarfile.TarInfo(record['path'])
                    info.size = record['bytes']
                    info.mode = 0o644
                    info.mtime = 0
                    with members[record['path']].open('rb') as content:
                        archive.addfile(info, content)
                info = tarfile.TarInfo('archive-members.json')
                info.size = len(manifest)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(manifest))
    index['archive_sha256'] = checksum(path)
    index['archive_bytes'] = path.stat().st_size
    index['internal_manifest'] = 'archive-members.json (its payload is the pre-archive index, without the archive checksum)'
    return index


def make_readme(head: str, tree: str, acceptance: dict, static: dict, portable: dict,
                environment: dict, examples: list[dict], checkpoints: list[dict],
                source_manifest: dict, file_rows: list[dict], archive: dict,
                premerge: dict) -> str:
    new_set = {'test/' + name + '.dart' for name in NEW_FILES}
    new_cases = sum(row['passed'] for row in file_rows if row['file'] in new_set)
    byte_equal = 'equal' if portable['vm_js_byte_equal'] else 'different'
    example_rows = '\n'.join(f'| [{Path(row["file"]).name}](../../../packages/quds_office_engine/{row["file"]}) | {row["operations"]} |'
                             for row in examples)
    checkpoint_rows = '\n'.join('| `{}` | {} |'.format(row['commit'], row['subject'].replace('|', '\\|'))
                                for row in checkpoints)
    return f'''# Word and PowerPoint VBA expansion: local qualification

The frozen source commit `{head}` (tree `{tree}`) passed **{acceptance['passed']:,} tests across 80 distinct files in 30 serial groups**, with **zero failed and zero skipped tests**. The static checks and actual-example VM/JavaScript comparison passed on the same commit. This record qualifies that saved source checkpoint; it does not claim that a final merge to remote `main` has occurred.

## What changed

### Word typed formatting, reading order and line presets

The Word adapter now accepts typed `Font` and `ParagraphFormat` selectors and required `ByVal` helper parameters, including named helper calls. `Paragraph.Format` selects the same paragraph formatting target as the existing range path. `ReadingOrder` accepts exactly `wdReadingOrderRtl = 0` and `wdReadingOrderLtr = 1`, changes base direction independently of alignment, and writes an explicit override against inherited direction. `LineSpacingRule` accepts the single, one-and-a-half and double presets (`0`, `1`, `2`), which persist as native automatic multipliers `1`, `1.5`, `2` and DOCX line values `240`, `360`, `480`.

Sparse paragraph writes retain unrelated native XML and spacing metadata. A line-only write does not materialize inherited before/after spacing, and same-value assignments remain direct overrides. Namespace-qualified reads and writes keep foreign same-name attributes and elements opaque. Paragraph formatting can target empty paragraphs; font edits still require existing nonempty text and exclude paragraph marks. This increment does not add live formatting reads, point-based `LineSpacing`, arbitrary multiples, or the `Space1`/`Space15`/`Space2` methods. See the [Word compatibility guide](../../VBA_WORD_MACROS.md).

### PowerPoint text-frame margins

`TextFrame.MarginLeft`, `MarginTop`, `MarginRight` and `MarginBottom` work through typed aliases, `With`, and helper targets. Values are finite nonnegative numbers in points whose conversion at 12,700 EMUs per point is exactly integral within `0..2147483647`; invalid precision, negative/out-of-range values, numeric Strings and Booleans are refused. A side write preserves the other sides, anchor, rich text, fields, hyperlinks, direction and autofit. Explicit zero and same-value assignments write direct native values; omitted sides remain absent.

The model and PDF path use the direct DrawingML inset rectangle, including unequal top/bottom margins and bounded overflow. Tests retain unsaved rich-run formatting, zero-height autofit text, extension data, namespace ownership, layout bindings, and untouched malformed or unsupported native sides across repeated saves. Editor paint/hit-test code was updated, but Flutter execution was outside this gate. Layout/master inherited margins remain preserved in the package; their inherited values are **not resolved by the live margin projection**. This increment does not add `WordWrap`, `AutoSize`, text-direction edits, or margin getters. See the [PowerPoint guide](../../VBA_POWERPOINT_MACROS.md).

### Shared named and optional helper arguments

The Word, PowerPoint and Excel adapters share case-insensitive `name:=expression` helper arguments, positional arguments before named arguments, optional-position holes, and omitted optional scalar `ByVal` parameters. Supplied expressions execute once in written source order before binding to the callee's parameter order. Defaults are checked declaration-time constant expressions in module scope. Duplicate or unknown names, required omissions, invalid ordering and unsupported types are rejected even in unused helpers and unreachable branches.

Optional `Long`, `Double`, `String`, `Boolean` and scalar `Variant` parameters have the documented defaults. An omitted defaultless Variant has a distinct Missing state; `IsMissing` accepts the current helper's direct optional Variant formal. Explicit `Empty` and `Null` remain distinct, assignment clears Missing, and an ordinary unhandled Missing read is refused. This is bounded Missing behavior, not general Variant Error propagation. ByRef, array/ParamArray and optional object parameters, `Nothing` defaults, and named application-member/intrinsic arguments remain unsupported. Shared work/copy/call budgets and native transaction boundaries remain in force. See [the argument contract](../../VBA_ARGUMENTS.md) and [shared macro guide](../../VBA_MACROS.md).

## Final local results

| Check | Result |
| --- | --- |
| Combined regression gate | {acceptance['passed']:,} passed; 0 failed; 0 skipped; 80 files; 30 complete nonoverlapping groups |
| Newly selected files | 16 files / {new_cases:,} passing cases, already included in the combined total; the other 64 files retain the prior selection |
| Engine analysis | `dart analyze --fatal-infos`: exit 0 |
| Formatting | {static['format_file_count']} relevant Dart files, `--output=none --set-exit-if-changed`: exit 0 |
| Actual example programs | All six committed BAS files executed on Dart VM and compiled JavaScript |
| Cross-runtime semantics | Exact canonical JSON equality; no numeric tolerance |
| Raw VM/JavaScript JSON bytes | {byte_equal}; recorded separately from semantic equality |
| Word incremental/full layout | 12 passing cases / 308 geometry comparisons, derived from verified fixed source loops |
| Source consistency | {source_manifest['file_count']:,} files in the compatible union; all captured before/after hashes and final disk/HEAD checks agree |

[Acceptance receipt](runtime/acceptance.json), [per-file counts and checksums](runtime/per-file.json), [selection](runtime/selection.json), [group plan](runtime/shards.json), [static receipt](runtime/static.json), [portable receipt](runtime/portable.json), and [merged source manifest](runtime/source-manifest.json) make these totals reviewable. The collector re-derives every visible case count from the raw JSONL, checks complete suite coverage and runner completion, and excludes hidden loading/setup events from the totals. The final test process durations sum to {acceptance['duration_seconds']:.3f} seconds; this is not the whole session's wall time.

The manifest domains are intentionally different: the test gate also covers editor font assets and manifests, the static run covers the entire engine package plus the touched editor renderer, and portable execution captures its compiler/runtime sources. Hashes must agree on every overlap. All 30 test groups have an identical gate manifest. The merged file set is checked against both the current disk and unchanged tracked content at the frozen commit; matching commit labels alone are insufficient.

## Actual BAS inputs and native persistence

| Committed example | Native operations |
| --- | ---: |
{example_rows}

The driver receives the exact source bytes via six base64 compiler defines; the collector independently checks both the VM and JavaScript compiler arguments against the committed files and their SHA-256 hashes. Detached validation leaves the input and revision unchanged. Execution publishes one native transaction, verifies intended and untouched content, and checks additional native save/reopen cycles. The combined driver also exercises exact one-EMU and signed-Long-maximum positive-EMU margin boundaries (`1` and `2147483647`) through actual PPTX serialization. Helper coverage includes source-order effects, Missing/refusal behavior and late native failure rollback.

The prior typography/slideshow pair checks an additional save/reopen; the helper and new paragraph/margin examples each check two additional native save/reopens. The examples operate on generated fixture documents with existing body paragraphs or named Title shapes; they do not create those application targets implicitly.

Cross-runtime comparison parses the complete JSON from each runtime, recursively converts only integral floating-point numbers to integers, then serializes with sorted keys, UTF-8 strings and compact separators. Boolean and String types are retained; non-finite values are forbidden; fractional numeric values receive no tolerance. Python Boolean-versus-integer equality is not used as the comparison. The exact canonical bytes are [recorded separately](runtime/portable-canonical.json), and SHA-256 values for both raw outputs are retained. ZIP container bytes are not compared across runtimes.

## Incoming layout defect: preserved failure and repair

The pre-cache-fix integrated source `89910ff6` produced a real differential failure at seed 7, structures enabled, edit 44. A paragraph edited while frame wrapping was active retained stale unwrapped line breaks; later flow changes could make that old cache readable again. The repaired source invalidates old breaks at paragraph entry when the block is not proven clean, including the paths that return early or bypass ordinary cache replacement. Subsequent main included the related cache guard, and the final gate runs the reconciled source.

The old-source negative control records **2 failed focused cases**, followed by **2 passing focused cases** on the repaired source with restoration checked. These supplemental results are [preserved explicitly](runtime/cache-reproduction.json) and are **not added** to the final acceptance total. The original 302 fresh-engine comparisons are preserved: 10 convergence comparisons, six deterministic 48-edit sequences (288), two note fallbacks and two discarded-state/section-list comparisons. Two text/font frame-edit cases add three comparisons each, producing 12 cases and 308 comparisons. The [source-derived proof](runtime/differential.json) binds those loop bounds to the final passing test-file hash; 308 is not a counter emitted by package:test. Geometry uses the pure Dart null-font fallback, without installed Word or Flutter font-metric comparison.

## Intake and saved checkpoints

The [refreshed reconciliation](integration/refreshed-reconciliation.md) and [qualified source inclusion receipt](integration/qualified-source-inclusion.json) account for the frozen inventory of **24 branch refs, 249 PR heads and four upstream heads**: 15 branch ancestors plus nine verified historical equivalents; 235 PR ancestors plus 14 equivalents; all four upstream heads are ancestors. All 14 historical changed-path proofs pass, 13 also with complete-tree identity. The separately captured later main `{LATER_MAIN}` is included by the final frozen merge checkpoint. These are point-in-time inclusion statements, not claims about refs created afterward or runtime qualification of every incoming application feature.

The published first-parent checkpoints are recorded with their actual remote-history SHAs below. Local pre-publication commits are not substituted for them. The collector checks these ancestors against the frozen checkpoint and the already fetched remote-tracking ref; it performs no network refresh.

| Published checkpoint | Purpose |
| --- | --- |
{checkpoint_rows}

### Later main: prospective merge proof

After the qualification source was frozen, remote main was observed at `{premerge['observed_main']['commit']}`. Neither that head nor the frozen qualification commit is an ancestor of the other; their merge base is `{premerge['ancestry']['merge_base']}`. The [full pre-merge review](integration/final-main-review.json) records the conflict-free standard Git prospective merge tree `{premerge['prospective_tree']}`. The collector independently checks that already recorded tree against the final manifest union: **all {premerge['validated_inputs']:,} input paths retain identical bytes, modes, object types and Git blob identities**. This check uses all completed final source domains, extending the review's initial static/portable/first-group manifest coverage without changing the qualified source commit.

The prospective merge changes exactly {premerge['incoming_outside_input_path_count']} paths outside the validated input set: nine Mail documentation/evidence paths and `packages/quds_office_editor/example/lib/studio_licenses.dart`. It retains the exact incoming delta from the merge base. A direct snapshot comparison with observed main differs in four qualified branch-side cache, regression-test and changelog inputs; the prospective merge preserves the frozen versions of all four. The [compact checked proof](runtime/premerge.json) identifies those paths and the incoming changes. Incoming license-loader or Mail runtime results are not newly executed by this object comparison.

This is a **pre-merge preservation proof**. It does not report an actual final merge, move the qualification claim to observed main, or guarantee any later main head. Evidence-file commits can change the complete final tree while keeping every validated input unchanged; the actual merge still requires a corresponding post-merge input check.

## Runtime, evidence and reproducibility

The environment uses Dart **3.13.7**, package:test **{environment['resolved_packages']['test']}**, test_core **{environment['resolved_packages']['test_core']}**, and Node **{environment['host_node']}**. The 56 shared hosted package versions match the repository lockfile. A standalone pure-Dart workspace provides unchanged engine/legacy/example manifests and a canonical package configuration; no Flutter SDK is needed for this engine gate. [Environment metadata](runtime/environment.json) records SDK archive, dependency lock, package configuration and precompiled test-runner checksums.

The unmodified package:test runner is first compiled to kernel using the installed SDK's `gen_kernel_aot.dart.snapshot` under `dartaotruntime --old_gen_heap_size=512`. Its `.dill` then runs under the normal Dart VM with the same old-generation bound, `--compiler source --concurrency=1 --timeout=4x --fail-fast`. Thirty fresh processes avoid accumulated runner/compiler state; process-spawning integration files are isolated in their own groups. This bound is not a process RSS cap and is not forwarded to independent CLI/MCP subprocesses or the normal JavaScript compiler. The archived bounded-compile receipt preserves the exact compiler command and successful runner checksum. Runtime binaries and caches are omitted from the archive and can be restored from the recorded SDK and package versions.

The [compressed evidence archive](runtime/acceptance-evidence.tar.gz) contains all {archive['member_count']} indexed raw evidence/configuration/source members, plus its internal index, and the exact collection/validation drivers. Its [external member index](runtime/archive-index.json) gives each member's classification, byte count and SHA-256. [Checksums](runtime/SHA256SUMS) cover the compact outputs and archive. The archive includes **every regular file under `validation-results`**, the root Word/arguments/layout/PowerPoint development logs selected by explicit patterns, and both `pre-cache-fix` and `pre-main-refresh` directories. It contains no SDK, pub cache, compiled JS/kernel binaries, or large generated Office fixtures.

The first frozen gate's real cache regression, the explicitly interrupted pre-main-refresh run (SIGINT), source-startup SIGKILL attempts, the failed normal kernel-wrapper compilation, setup attempts and earlier development passes remain available under their original names. Completed prefixes and all earlier runs are excluded from the final total; only the final 30 complete same-source groups contribute. Some older development receipts intentionally report changed inputs and are evidence of development activity only. The standalone historical 10-case/302-comparison receipt is retained without being relabeled as a final-source result.

To inspect/reproduce, restore the recorded SDK/dependencies, adapt the archived scratch-root paths, and use the archived static, portable and sharded drivers on the frozen commit. `prepare_expansion_validation.py` documents the initial all-at-once attempt and selection; the final execution strategy is `run_expansion_shards.py`. Run this collector only after all stages finish; it refuses incomplete receipts, unknown/missing/duplicate suites, skipped/failing cases, stale HEAD, source mismatches, or missing historical controls. Collection performs no compiler, test, remote or CI operation.

## Qualification limits

GitHub Actions was neither queried nor awaited. The tests cover the bounded, explicitly invoked VBA source-to-native-plan adapter, native macro/CLI/MCP behavior, and engine persistence. Embedded VBA projects remain preserved and inert; full VBA execution, COM, events and a VBA editor are outside this increment. Flutter UI/controller execution, installed Microsoft Word/PowerPoint, platform keychains, native signing and live mail-provider execution were not performed here. Incoming Mail, Downloads, credential and Zotero source inclusion is documented independently of these runtime limits.
'''


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', default=EXPECTED_HEAD)
    parser.add_argument('--output', type=Path, default=EVIDENCE / 'runtime')
    parser.add_argument('--readme', type=Path, default=EVIDENCE / 'README.md')
    args = parser.parse_args()
    require(args.expected_head == EXPECTED_HEAD, 'This collector is scoped to the reviewed frozen commit')
    head = git('rev-parse', 'HEAD')
    require(head == args.expected_head, 'Checkout is not the frozen acceptance commit')
    tree = git('rev-parse', 'HEAD^{tree}')
    require(not args.output.exists() and not args.readme.exists(),
            'Evidence destination already exists; review it or choose separate --output/--readme paths')
    for target in (args.output, args.readme):
        require(target.resolve().is_relative_to(ROOT), 'Destination must remain in this workspace')
    selection = read_json(RESULTS / 'expansion-selection.json')
    require(isinstance(selection, list) and len(selection) == len(set(selection)) == 80,
            'Expected exactly 80 distinct selected test files')
    require(all(test_path(path) == path for path in selection), 'Noncanonical selection path')
    prior = read_json(REPO / 'docs/validation/office-vba-continuation-20261120/runtime/selection.json')
    expected_selection = list(dict.fromkeys(['test/' + name + '.dart' for name in NEW_FILES] + prior))
    require(len(prior) == 64 and selection == expected_selection, 'Selection differs from the reviewed 16 + 64 files')
    plan = read_json(RESULTS / 'expansion-shards.json')
    require(isinstance(plan, list) and len(plan) == 30, 'Expected exactly 30 groups')
    require([group['label'] for group in plan] == [f'expansion-shard{i:02d}' for i in range(1, 31)],
            'Unexpected group labels')
    require([path for group in plan for path in group['files']] == selection,
            'Groups omit, reorder or repeat selected files')
    acceptance = read_json(RESULTS / 'expansion-acceptance.receipt.json')
    require(acceptance.get('commit') == head and acceptance.get('source_unchanged') is True
            and acceptance.get('distinct_selection') is True
            and acceptance.get('selected_file_count') == 80
            and acceptance.get('completed_group_count') == 30
            and acceptance.get('failed') == 0 and acceptance.get('skipped') == 0,
            'Missing, incomplete or nonpassing final acceptance receipt')
    gate_hashes = check_manifest(acceptance, GATE_PATHS, 'acceptance')
    rows = []
    group_summaries = []
    receipts = []
    for group in plan:
        label, files = group['label'], group['files']
        receipt = read_json(RESULTS / (label + '.receipt.json'))
        require(receipt.get('commit') == head and receipt.get('source_hashes') == gate_hashes,
                f'Stale source or HEAD in {label}')
        command = receipt.get('command', [])
        require(command[-len(files):] == files, f'Wrong test arguments in {label}')
        require(all(flag in command for flag in ['--old_gen_heap_size=512', '--concurrency=1',
                                                 '--timeout=4x', '--reporter=json', '--fail-fast']),
                f'Unexpected final execution strategy in {label}')
        require('--compiler' in command and command[command.index('--compiler') + 1] == 'source',
                f'Wrong test compiler in {label}')
        require(str(ROOT / 'toolchains/test-runner/test-runner.dill') in command
                and '--name' not in command and '-n' not in command,
                f'Unexpected test runner/filter in {label}')
        parsed = parse_test_events(RESULTS / (label + '.jsonl'), files)
        check_raw_receipt(receipt, parsed, label)
        for file in files:
            counts = parsed['per_file'][file]
            require(counts['passed'] > 0, f'Selected file executed no visible cases: {file}')
            rows.append({'file': file, 'group': label,
                         'passed': counts['passed'], 'failed': counts['failed'], 'skipped': counts['skipped'],
                         'hidden_events_excluded': counts['hidden'],
                         'source_sha256': gate_hashes['packages/quds_office_engine/' + file],
                         'raw_jsonl_sha256': parsed['jsonl_sha256'],
                         'case_manifest_sha256': sha_bytes(encode(counts['tests']))})
        group_summaries.append({'label': label, 'files': files, 'passed': parsed['passed'],
                                'seconds': receipt['duration_seconds']})
        receipts.append(receipt)
    require([row['file'] for row in rows] == selection, 'Per-file derivation lost selected files')
    total = sum(row['passed'] for row in rows)
    require(nonnegative_int(acceptance.get('passed'), 'aggregate passed') == total,
            'Aggregate passing count differs from raw per-file events')
    require(acceptance.get('groups') == group_summaries, 'Aggregate group metadata differs')
    require(acceptance.get('duration_seconds') == sum(item['duration_seconds'] for item in receipts),
            'Aggregate duration differs from group receipts')
    static = read_json(RESULTS / 'expansion-final-static.receipt.json')
    require(static.get('commit') == head and static.get('source_unchanged') is True,
            'Stale/changed-source static receipt')
    require([item.get('name') for item in static.get('checks', [])] == ['format', 'analyze']
            and all(item.get('exit_code') == 0 for item in static['checks']), 'Static checks did not pass')
    require('--fatal-infos' in static['checks'][1]['command'] and
            all(flag in static['checks'][0]['command'] for flag in
                ['--output=none', '--set-exit-if-changed']), 'Static command strictness differs')
    format_files = [path for path in git('diff', '--name-only', PREVIOUS_MAIN, '--',
                                         'packages/quds_office_engine',
                                         'packages/quds_office_editor/lib/src/editor_slide/render_slide_stage.dart').splitlines()
                    if path.endswith('.dart') and (REPO / path).is_file()]
    require(static['checks'][0]['command'][4:] == format_files
            and static['format_file_count'] == len(format_files), 'Static formatting coverage differs')
    require(static['checks'][0]['cwd'] == str(REPO) and static['checks'][1]['cwd'] == str(ENGINE),
            'Static check working directory differs')
    portable_raw = read_json(RESULTS / 'expansion-portable.receipt.json')
    portable, examples = check_portable(portable_raw, head, tree)
    manifests = {'acceptance': gate_hashes,
                 'static': check_manifest(static, STATIC_PATHS, 'static'),
                 'portable': check_manifest(portable_raw, PORTABLE_PATHS, 'portable')}
    merged = {}
    for label, hashes in manifests.items():
        for path, digest in hashes.items():
            require(path not in merged or merged[path] == digest,
                    f'Inconsistent {label} hash for {path}')
            merged[path] = digest
    check_current_sources(head, merged)
    source_manifest = {'schema': 'quds-vba-expansion-source-union/v1', 'commit': head, 'tree': tree,
                       'file_count': len(merged), 'source_hashes': dict(sorted(merged.items())),
                       'capture_domains': {'acceptance': GATE_PATHS, 'static': STATIC_PATHS,
                                           'portable': PORTABLE_PATHS},
                       'capture_counts': {label: len(values) for label, values in manifests.items()},
                       'capture_manifest_sha256': {label: sha_bytes(encode(values))
                                                   for label, values in manifests.items()},
                       'all_overlap_hashes_equal': True, 'all_30_gate_manifests_identical': True,
                       'current_disk_hashes_match': True, 'tracked_source_matches_frozen_head': True}
    environment = read_json(RESULTS / 'environment.json')
    require(environment.get('shared_lock_versions_match') is True
            and environment.get('shared_resolved_package_count') == 56
            and len(environment.get('resolved_packages', {})) == 56
            and not environment.get('mismatches')
            and all(environment.get('package_manifests_match', {}).values()), 'Environment/dependency mismatch')
    require(environment.get('external_ci_used') is False, 'Environment claims unexpected CI use')
    configs = [REPO / '.dart_tool/package_config.json',
               ROOT / 'validation-workspace/.dart_tool/package_config.json']
    require(all(checksum(path) == environment['package_config_sha256'] for path in configs),
            'Canonical package configuration changed')
    require(checksum(ROOT / 'validation-workspace/pubspec.lock') == environment['resolved_lock_sha256']
            and checksum(REPO / 'pubspec.lock') == environment['root_lock_sha256'], 'Dependency lock changed')
    compiled_runner = read_json(RESULTS / 'test-runner-compile-bounded.receipt.json')
    runner_path = ROOT / 'toolchains/test-runner/test-runner.dill'
    require(compiled_runner.get('exit_code') == 0
            and compiled_runner.get('runner_sha256') == environment['test_runner_kernel_sha256']
            == checksum(runner_path), 'Precompiled runner is missing or differs')
    require(compiled_runner['command'][1] == '--old_gen_heap_size=512'
            and compiled_runner['command'][0].endswith('/dartaotruntime')
            and compiled_runner['command'][2].endswith('/gen_kernel_aot.dart.snapshot'),
            'Runner compiler heap bound was not applied to the frontend VM')
    environment = {**environment, 'qualified_commit': head, 'qualified_tree': tree,
                   'bounded_runner_compile': compiled_runner,
                   'runtime_binaries_archived': False,
                   'environment_source_sha256': SNAPSHOTS[RESULTS / 'environment.json']}
    by_file = {row['file']: row for row in rows}
    differential = check_differential(by_file)
    cache = check_cache_reproduction()
    failed_prefix = read_json(RESULTS / 'pre-cache-fix/expansion-shard04.receipt.json')
    require(failed_prefix.get('commit') == '89910ff6363cd45ced5faf0e48b11cac46754b28'
            and failed_prefix.get('exit_code') == 1 and failed_prefix.get('failed') == 1,
            'Original real cache-regression receipt is missing')
    interruption = read_json(RESULTS / 'pre-main-refresh/interruption.json')
    require(interruption.get('process_exit_code') == 130, 'Missing explicit pre-main-refresh SIGINT record')
    inclusion = read_json(EVIDENCE / 'integration/qualified-source-inclusion.json')
    require(inclusion.get('target_commit') == head and inclusion.get('target_tree') == tree,
            'Inclusion receipt does not target the frozen source')
    summary = inclusion['summary']
    require((summary['branch_count'], summary['pr_count'], summary['upstream_count']) == (24, 249, 4)
            and summary['branches'] == {'ancestor': 15, 'historically_superseded_equivalent': 9}
            and summary['prs'] == {'ancestor': 235, 'historically_superseded_equivalent': 14}
            and summary['all_historical_proofs_verified'] is True
            and summary['upstream_all_ancestors'] is True, 'Unexpected intake coverage')
    require(inclusion['post_inventory_main_reconciliation']['head'] == LATER_MAIN
            and inclusion['post_inventory_main_reconciliation']['is_ancestor'] is True
            and ancestor(LATER_MAIN, head), 'Later main is not included')
    require((EVIDENCE / 'integration/refreshed-reconciliation.md').is_file(), 'Missing reconciliation text')
    premerge = check_premerge_review(head, tree, merged)
    remote_ref = 'refs/remotes/origin/codex/word-powerpoint-vba-expansion-20261120'
    require(git('rev-parse', remote_ref) == head, 'Fetched remote checkpoint ref differs from qualification HEAD')
    history = git('rev-list', '--first-parent', '--reverse', PREVIOUS_MAIN + '..' + head).splitlines()
    require(history == CHECKPOINTS, 'Published checkpoint list differs from reviewed first-parent history')
    checkpoints = [{'commit': commit, 'subject': git('show', '-s', '--format=%s', commit)}
                   for commit in history]
    acceptance_compact = {**strip_hashes(acceptance), 'raw_events_independently_recounted': True,
                          'source_manifest': 'source-manifest.json', 'per_file': 'per-file.json',
                          'only_final_groups_counted': True}
    per_file = {'commit': head, 'file_count': 80, 'passed': total, 'failed': 0, 'skipped': 0,
                'counting': 'Visible testDone events only; suite/test IDs mapped from the same shard JSONL; all selected files covered once',
                'selection_sha256': SNAPSHOTS[RESULTS / 'expansion-selection.json'],
                'files': rows}
    metadata = {'schema': 'quds-vba-expansion-collection/v1',
                'collected_at_utc': datetime.now(timezone.utc).isoformat(),
                'qualified_commit': head, 'qualified_tree': tree,
                'collector_sha256': checksum(Path(__file__).resolve()),
                'remote_ref_checked_locally': remote_ref, 'network_used': False,
                'github_actions_queried_or_awaited': False, 'final_main_merge_claimed': False,
                'checkpoints': checkpoints, 'intake_summary': summary,
                'post_inventory_main_reconciliation': inclusion['post_inventory_main_reconciliation'],
                'later_main_premerge_proof': {'path': 'premerge.json',
                                             'observed_main': premerge['observed_main']['commit'],
                                             'prospective_tree': premerge['prospective_tree'],
                                             'review_sha256': premerge['review_sha256']},
                'excluded_attempts': {
                    'pre_cache_fix': 'Real seed-7 layout regression plus completed prefixes; excluded',
                    'pre_main_refresh': interruption,
                    'startup_and_setup': 'Preserved in archive, excluded',
                    'development': 'All nonfinal raw receipts/logs are excluded regardless of partial passing counts',
                    'cache_negative_and_fixed_controls': 'Supplemental reproduction; not added to total'},
                'development_patterns': DEVELOPMENT_PATTERNS}
    members, result_names = archive_inputs(selection)
    with tempfile.TemporaryDirectory(prefix='expansion-evidence-stage-', dir=ROOT) as temporary:
        stage = Path(temporary)
        runtime = stage / 'runtime'
        runtime.mkdir()
        archive = write_archive(runtime / 'acceptance-evidence.tar.gz', members)
        compact_outputs = {
            'acceptance.json': acceptance_compact, 'per-file.json': per_file,
            'selection.json': selection, 'shards.json': plan, 'source-manifest.json': source_manifest,
            'environment.json': environment, 'static.json': strip_hashes(static),
            'portable.json': portable, 'cache-reproduction.json': cache,
            'premerge.json': premerge,
            'differential.json': differential, 'collection.json': metadata, 'archive-index.json': archive,
        }
        for name, value in compact_outputs.items():
            (runtime / name).write_bytes(pretty(value))
        (runtime / 'portable-canonical.json').write_bytes(capture(RESULTS / 'expansion-portable-canonical.json'))
        readme = make_readme(head, tree, acceptance, static, portable, environment,
                             examples, checkpoints, source_manifest, rows, archive, premerge)
        (stage / 'README.md').write_text(readme)
        (runtime / 'README.md').write_text('# Runtime evidence\n\nSee the [qualification report](../README.md). '
                                          'The passing total comes only from `acceptance.json` and its 30 final groups. '
                                          'Other raw results are preserved and classified in `archive-index.json`.\n')
        checksums = [(path.name, checksum(path)) for path in sorted(runtime.iterdir()) if path.is_file()]
        checksums.append(('../README.md', checksum(stage / 'README.md')))
        (runtime / 'SHA256SUMS').write_text(''.join(digest + '  ' + name + '\n' for name, digest in checksums))
        current_results = {path.relative_to(ROOT).as_posix() for path in RESULTS.rglob('*') if path.is_file()}
        require(current_results == result_names, 'validation-results files changed while collecting')
        for path, digest in SNAPSHOTS.items():
            require(checksum(path) == digest, f'Evidence changed during collection: {path}')
        check_current_sources(head, merged)
        require(not args.output.exists() and not args.readme.exists(), 'Destination appeared while collecting')
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.readme.parent.mkdir(parents=True, exist_ok=True)
        os.replace(runtime, args.output)
        os.replace(stage / 'README.md', args.readme)
    print(json.dumps({'commit': head, 'passed': total, 'files': 80, 'groups': 30,
                      'source_files': len(merged), 'archive_members': archive['member_count'],
                      'archive_bytes': archive['archive_bytes'], 'archive_sha256': archive['archive_sha256'],
                      'runtime': str(args.output), 'readme': str(args.readme)}, indent=2))


if __name__ == '__main__':
    main()
