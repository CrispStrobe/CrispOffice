import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/workspace/scratch/f0616b02624b')
repo = root / 'quds_office_suite'
engine = repo / 'packages/quds_office_engine'
old = json.loads((repo / 'docs/validation/office-vba-continuation-20261120/runtime/selection.json').read_text())
new = [
    'office_vba_arguments_test', 'office_vba_arguments_integration_test',
    'office_vba_word_argument_shapes_test', 'office_vba_word_paragraph_layout_test',
    'office_vba_word_paragraph_layout_integration_test', 'office_vba_powerpoint_margins_test',
    'office_vba_powerpoint_margins_integration_test', 'slide_text_insets_preservation_test',
    'word_incremental_layout_differential_test', 'word_incremental_layout_test',
    'word_incremental_layout_prefix_test', 'word_zotero_note_table_test',
    'word_zotero_note_tables_integration_test', 'style_cascade_test',
    'word_referenced_styles_and_breaks_test', 'word_paragraph_mark_layout_test',
]
selection = list(dict.fromkeys([*(f'test/{name}.dart' for name in new), *old]))
assert all((engine / path).is_file() for path in selection)
out = root / 'validation-results'
(out / 'expansion-selection.json').write_text(json.dumps(selection, indent=2) + '\n')
print(json.dumps({'selected_files': len(selection), 'selection': str(out / 'expansion-selection.json')}), flush=True)
env = os.environ.copy()
env.update(VBA_TEST_CONCURRENCY='1', VBA_TEST_FAIL_FAST='1', VBA_DART_HEAP_MB='1024')
raise SystemExit(subprocess.run([sys.executable, str(root / 'run_vba_validation.py'), 'expansion-acceptance', *selection], env=env).returncode)
