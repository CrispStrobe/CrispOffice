import 'dart:convert';

import 'package:quds_office_engine/quds_office_engine.dart';

void main() {
  for (final height in <int>[0, 3, 7, 8, 20, 100]) {
    for (final autofit in <bool>[false, true]) {
      final original = PmlPresentation(
        slides: <PmlSlide>[
          PmlSlide(id: 256, shapes: <PmlShape>[
            PmlShape(
              id: 2,
              name: 'Short box',
              text: 'Retained text',
              fontSizePt: 20,
              transform: PmlTransform(
                x: 127000,
                y: 127000,
                cx: 3810000,
                cy: height * 12700,
              ),
            ),
          ]),
        ],
      );
      final package = OpcPackage.openBytes(SlideSerializer().writeBytes(original));
      if (autofit) {
        final part = package.getPart('/ppt/slides/slide1.xml')!;
        final xml = XmlDocument.parse(part.readText());
        final props = xml.root!
            .firstChild('cSld', namespaceUri: OfficeNamespaces.p)!
            .firstChild('spTree', namespaceUri: OfficeNamespaces.p)!
            .firstChild('sp', namespaceUri: OfficeNamespaces.p)!
            .firstChild('txBody', namespaceUri: OfficeNamespaces.p)!
            .firstChild('bodyPr', namespaceUri: OfficeNamespaces.a)!;
        props.addChild(XmlElement(localName: 'spAutoFit', prefix: 'a', namespaceUri: OfficeNamespaces.a));
        part.writeText(xml.toXmlString());
      }
      final deck = SlideDeserializer().read(package);
      final ops = PdfFile.open(OfficePdfExport.presentation(deck))
          .displayList(0).ops.whereType<PdfDrawText>().toList();
      print(jsonEncode(<String, Object?>{
        'height': height,
        'autoFit': autofit,
        'textOperations': ops.length,
        'positions': [for (final op in ops) [op.x, op.y]],
      }));
    }
  }
}
