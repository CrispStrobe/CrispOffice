"""Read-only ancestry and historical equality audit of locally fetched refs."""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/f0616b02624b')
REPO = ROOT / 'quds_office_suite'
TARGET = sys.argv[1] if len(sys.argv) > 1 else '3ffa599ff003a6e678260df1237b01887693e546'
PRIOR = 'docs/validation/office-vba-continuation-20261120/integration/final-inclusion.json'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env=ENV).decode().rstrip('\n')

def is_ancestor(sha, target=TARGET):
    result = subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', sha, target], env=ENV, capture_output=True)
    if result.returncode not in (0, 1):
        raise RuntimeError(result.stderr.decode())
    return result.returncode == 0

TARGET = git('rev-parse', TARGET)
prior = json.loads(git('show', f'{TARGET}:{PRIOR}'))
known = {p['historical_head']: p for p in prior['historical_equivalence_proofs']}
proofs = {}

def historical(sha):
    if sha in proofs:
        return proofs[sha]
    old = known.get(sha)
    if old is None:
        return None
    accepted = old['accepted_ancestor']
    paths = [p for p in git('diff', '--name-only', '-z', old['comparison_base'], sha).split('\0') if p]
    one = git('ls-tree', '-r', '-z', sha, '--', *paths)
    two = git('ls-tree', '-r', '-z', accepted, '--', *paths)
    proof = {
        'historical_head': sha,
        'accepted_ancestor': accepted,
        'accepted_is_ancestor': is_ancestor(accepted),
        'comparison_base': old['comparison_base'],
        'changed_path_count': len(paths),
        'changed_modes_types_objects_exact': one == two,
        'changed_entries_sha256': hashlib.sha256(one.encode()).hexdigest(),
        'historical_tree': git('rev-parse', f'{sha}^{{tree}}'),
        'accepted_tree': git('rev-parse', f'{accepted}^{{tree}}'),
    }
    proof['whole_tree_equal'] = proof['historical_tree'] == proof['accepted_tree']
    proof['verified'] = proof['accepted_is_ancestor'] and proof['changed_modes_types_objects_exact']
    proofs[sha] = proof
    return proof

branches = []
prs = []
for row in git('for-each-ref', '--format=%(refname) %(objectname)', 'refs/remotes/origin/').splitlines():
    ref, sha = row.split(' ', 1)
    if ref.endswith('/HEAD'):
        continue
    entry = {'ref': ref, 'sha': sha}
    if is_ancestor(sha):
        entry['status'] = 'ancestor'
    elif (proof := historical(sha)) is not None:
        entry['status'] = 'historically_superseded_equivalent' if proof['verified'] else 'unverified_historical'
        entry['accepted_ancestor'] = proof['accepted_ancestor']
    else:
        entry['status'] = 'incoming'
        entry['ahead_commits'] = int(git('rev-list', '--count', f'{TARGET}..{sha}'))
        entry['merge_base'] = git('merge-base', TARGET, sha)
    (prs if ref.startswith('refs/remotes/origin/pr/') else branches).append(entry)

incoming = sorted({r['sha'] for r in branches + prs if r['status'] == 'incoming'})
minimal = [sha for sha in incoming if not any(other != sha and is_ancestor(sha, other) for other in incoming)]
upstream = []
for row in git('for-each-ref', '--format=%(refname) %(objectname)', 'refs/remotes/upstream/').splitlines():
    ref, sha = row.split(' ', 1)
    if not ref.endswith('/HEAD'):
        upstream.append({'ref': ref, 'sha': sha, 'is_ancestor': is_ancestor(sha)})
result = {
    'schema': 'quds-vba-expansion-incoming/v1',
    'audited_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repository': 'CrispStrobe/quds_office_suite',
    'target_commit': TARGET,
    'target_tree': git('rev-parse', f'{TARGET}^{{tree}}'),
    'scope': 'Fetched branch and PR refs; read-only git ancestry and historical exact changed-entry equality; no runtime claims',
    'network_used_by_script': False,
    'github_actions_used': False,
    'prior_proof_path': PRIOR,
    'prior_proof_blob': git('rev-parse', f'{TARGET}:{PRIOR}'),
    'summary': {
        'branch_count': len(branches),
        'branches': dict(collections.Counter(r['status'] for r in branches)),
        'pr_count': len(prs),
        'prs': dict(collections.Counter(r['status'] for r in prs)),
        'historical_proofs': len(proofs),
        'historical_full_tree_equal': sum(p['whole_tree_equal'] for p in proofs.values()),
        'all_historical_proofs_verified': all(p['verified'] for p in proofs.values()),
        'incoming_unique_heads': len(incoming),
        'minimal_incoming_heads': minimal,
        'upstream_count': len(upstream),
        'upstream_all_ancestors': all(r['is_ancestor'] for r in upstream),
    },
    'branches': branches,
    'pull_requests': sorted(prs, key=lambda r: int(r['ref'].rsplit('/', 1)[1])),
    'historical_equivalence_proofs': list(proofs.values()),
    'upstream': upstream,
}
out = ROOT / (sys.argv[2] if len(sys.argv) > 2 else 'incoming-expansion-audit-20261120.json')
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output': str(out), 'summary': result['summary'], 'incoming': [r for r in branches if r['status'] == 'incoming']}, indent=2))
