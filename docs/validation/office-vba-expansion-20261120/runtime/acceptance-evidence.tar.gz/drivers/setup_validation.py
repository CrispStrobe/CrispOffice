from pathlib import Path
import json
import shutil

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'quds_office_suite'
WORK = ROOT / 'validation-workspace'
WORK.mkdir(exist_ok=True)
(ROOT / 'toolchains/pub-cache').mkdir(parents=True, exist_ok=True)
(ROOT / 'toolchains/tmp').mkdir(parents=True, exist_ok=True)
(WORK / 'pubspec.yaml').write_text('name: office_vba_local_validation\npublish_to: none\nenvironment:\n  sdk: ^3.12.0\nworkspace:\n  - packages/legacy_doc_parser\n  - packages/quds_office_engine\n  - packages/quds_office_engine/example\n')
shutil.copy2(REPO / 'pubspec.lock', WORK / 'pubspec.lock')
for name in ['legacy_doc_parser', 'quds_office_engine']:
    source = REPO / 'packages' / name
    dest = WORK / 'packages' / name
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / 'pubspec.yaml', dest / 'pubspec.yaml')
    for child in source.iterdir():
        if child.name in ['pubspec.yaml', '.dart_tool']:
            continue
        link = dest / child.name
        if not link.exists():
            link.symlink_to(child, target_is_directory=child.is_dir())
shutil.copy2(REPO / 'analysis_options.yaml', WORK / 'analysis_options.yaml')
print(WORK)
