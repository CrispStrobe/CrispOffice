#!/usr/bin/env python3
"""Collect scoped Office VBA qualification without running validation.

The accepted 80-file selection is partitioned by a reviewed, pinned plan:
completed unaffected baseline cases retain their original commit provenance;
all affected, guard and previously unrun files must pass on the final commit.
This is not an 80-file run on one frozen source tree.

Only standard-library Python and read-only Git object inspection are used.
No network, test, compiler, analyzer, CI, merge or remote mutation is performed.
Run only after scoped static, portable and test receipts are complete. Existing
output destinations are refused. Do not redirect output into validation-results
while that directory is being snapshotted.
"""

from __future__ import annotations

import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
from functools import lru_cache
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
import tempfile


ROOT = Path('/workspace/scratch/f0616b02624b')
REPO = ROOT / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
RESULTS = ROOT / 'validation-results'
EVIDENCE = REPO / 'docs/validation/office-vba-expansion-20261120'
BASELINE_COMMIT = 'c9cbeb1248d6b5f088d1084a8c113a743aa7a77f'
PREVIOUS_MAIN = '3ffa599ff003a6e678260df1237b01887693e546'
LATER_MAIN = 'a652a205e6daf6b4b8e3baec04db1c1b52fabd0d'
LAYOUT_BASELINE = '58000866a6a36d7cc29e2a5677ef23c2f71dff51'
CHECKPOINTS = [
    'f761cfe6d25c27fede697943a18ab89c11353d8f',
    'b6d6a26d9fcb5602ad9bd65d451aa5273881c933',
    '9e0d8173fada4ae3f22ace5c5b896c21ab5191da',
    LAYOUT_BASELINE,
    '979cfa77c3bf7718664db7ecb4f62b656a58f187',
    '40572427fc7d62b0fb2423712fa79162814b53a9',
    '050ba58acad35f41803377b385ea22c833822845',
    '89910ff6363cd45ced5faf0e48b11cac46754b28',
    '4a2607162199deedde0587b2cdb919bbf6435251',
    BASELINE_COMMIT,
]
GATE_PATHS = [
    'packages/quds_office_engine/lib',
    'packages/quds_office_engine/test',
    'packages/quds_office_engine/tool',
    'packages/quds_office_engine/example/macros',
    'packages/quds_office_editor/fonts',
    'packages/legacy_doc_parser/lib',
    'packages/quds_office_engine/pubspec.yaml',
    'packages/legacy_doc_parser/pubspec.yaml',
    'pubspec.lock',
]
STATIC_PATHS = [
    'packages/quds_office_engine',
    'packages/legacy_doc_parser/lib',
    'packages/quds_office_editor/lib/src/editor_slide/render_slide_stage.dart',
    'pubspec.lock',
]
PORTABLE_PATHS = [
    'packages/quds_office_engine/lib',
    'packages/quds_office_engine/test',
    'packages/quds_office_engine/tool',
    'packages/quds_office_engine/example/macros',
    'packages/legacy_doc_parser/lib',
    'pubspec.lock',
]
SAMPLES = {
    'WORD_TYPOGRAPHY_BAS_BASE64': 'example/macros/word_typography.bas',
    'POWERPOINT_SLIDESHOW_BAS_BASE64': 'example/macros/powerpoint_slideshow.bas',
    'WORD_OPTIONAL_HELPERS_BAS_BASE64': 'example/macros/word_optional_helpers.bas',
    'POWERPOINT_OPTIONAL_HELPERS_BAS_BASE64': 'example/macros/powerpoint_optional_helpers.bas',
    'WORD_PARAGRAPH_LAYOUT_BAS_BASE64': 'example/macros/word_paragraph_layout.bas',
    'POWERPOINT_TEXT_MARGINS_BAS_BASE64': 'example/macros/powerpoint_text_margins.bas',
}
DRIVERS = [
    'collect_expansion_evidence.py',
    'collect_scoped_expansion_evidence.py',
    'run_scoped_expansion.py',
    'scoped-qualification-plan.json',
    'setup_validation.py',
    'finalize_validation_setup.py',
    'validation-env.sh',
    'run_vba_validation.py',
    'prepare_expansion_validation.py',
    'run_expansion_static.py',
    'run_expansion_portable.py',
    'run_expansion_shards.py',
    'run_cache_regression.py',
    'run_arguments_portable.py',
    'run_portable_office_layout.py',
    'audit_incoming_expansion.py',
    'qualify_final_cutoff.py',
    'review_ppt_short_boxes.dart',
    'word_incremental_layout_differential_test.dart',
    'word_incremental_layout_differential_test.bootstrap.isolate.dart',
]
DEVELOPMENT_PATTERNS = [
    'arguments-*.log',
    'word-*.log',
    'incremental-layout-*.log',
    'incremental-layout-*.json',
    'ppt-*.log',
    'review-ppt-*.jsonl',
    'arguments-portable-results/*.json',
    'arguments-portable-results/*.jsonl',
    'arguments-portable-results/*.log',
    'arguments-portable-results/*.stdout',
    'arguments-portable-results/*.stderr',
]
NEW_FILES = [
    'office_vba_arguments_test', 'office_vba_arguments_integration_test',
    'office_vba_word_argument_shapes_test', 'office_vba_word_paragraph_layout_test',
    'office_vba_word_paragraph_layout_integration_test', 'office_vba_powerpoint_margins_test',
    'office_vba_powerpoint_margins_integration_test', 'slide_text_insets_preservation_test',
    'word_incremental_layout_differential_test', 'word_incremental_layout_test',
    'word_incremental_layout_prefix_test', 'word_zotero_note_table_test',
    'word_zotero_note_tables_integration_test', 'style_cascade_test',
    'word_referenced_styles_and_breaks_test', 'word_paragraph_mark_layout_test',
]
SNAPSHOTS: dict[Path, str] = {}
BASELINE_ACCEPTED_RAW: set[str] = set()
FINAL_ACCEPTED_RAW: set[str] = set()
PLAN_PATH = ROOT / 'scoped-qualification-plan.json'
FINAL_INCLUSION = EVIDENCE / 'integration/final-cutoff-inclusion.json'
GIT_ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
DELTA_NOTE = ('Retention is a source-reviewed impact decision, not a new test '
              'execution. Every retained case keeps its baseline commit and raw provenance.')
APPROVED_ENGINE_DELTA = {
    'packages/quds_office_engine/CHANGELOG.md',
    'packages/quds_office_engine/lib/src/slide/model/pml_presentation.dart',
    'packages/quds_office_engine/lib/src/slide/shapes/drawingml.dart',
    'packages/quds_office_engine/test/slide_text_insets_preservation_test.dart',
    'packages/quds_office_engine/lib/src/word/layout/word_incremental_layout.dart',
    'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
    'packages/quds_office_engine/test/word_incremental_layout_test.dart',
    'packages/quds_office_engine/tool/zotero/research_target_acceptance.dart',
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def checksum(path: Path) -> str:
    require(path.is_file(), f'Missing required file: {path}')
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def capture(path: Path) -> bytes:
    require(path.is_file() and not path.is_symlink(), f'Expected regular evidence file: {path}')
    data = path.read_bytes()
    digest = sha_bytes(data)
    require(path not in SNAPSHOTS or SNAPSHOTS[path] == digest,
            f'Evidence changed while collecting: {path}')
    SNAPSHOTS[path] = digest
    return data


def reject_constant(value: str):
    raise ValueError(f'Non-finite JSON constant: {value}')


def json_load(data: bytes | str):
    return json.loads(data, parse_constant=reject_constant)


def read_json(path: Path):
    return json_load(capture(path))


def encode(value) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=False,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')


def pretty(value) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8')


def canonical(value):
    # Test float specifically; bool is an int subclass in Python and must stay bool.
    if type(value) is float:
        require(math.isfinite(value), 'Non-finite portable result')
        return int(value) if value.is_integer() else value
    if isinstance(value, list):
        return [canonical(item) for item in value]
    if isinstance(value, dict):
        return {key: canonical(item) for key, item in value.items()}
    return value


def git(*args: str) -> str:
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True, env=GIT_ENV).strip()


def git_bytes(*args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), *args], env=GIT_ENV)


@lru_cache(maxsize=None)
def ancestor(older: str, newer: str) -> bool:
    result = subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', older, newer],
                            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, env=GIT_ENV)
    require(result.returncode in (0, 1), f'Cannot inspect ancestry of {older}')
    return result.returncode == 0


def git_tree_entries(revision: str) -> dict[str, dict[str, str]]:
    result = {}
    for record in git_bytes('ls-tree', '-r', '-z', '--full-tree', revision).split(b'\0'):
        if not record:
            continue
        description, raw_path = record.split(b'\t', 1)
        mode, kind, oid = description.decode('ascii').split(' ')
        path = raw_path.decode('utf-8')
        require(path not in result, f'Duplicate tree entry in {revision}: {path}')
        result[path] = {'mode': mode, 'type': kind, 'object': oid}
    return result


def git_blob_hashes(objects: set[str]) -> dict[str, str]:
    """Hash existing blobs through one read-only process with bounded buffering."""
    result = {}
    with subprocess.Popen(['git', '-C', str(REPO), 'cat-file', '--batch'],
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                          stderr=subprocess.DEVNULL, env=GIT_ENV) as process:
        try:
            require(process.stdin is not None and process.stdout is not None, 'Git batch pipes unavailable')
            for oid in sorted(objects):
                process.stdin.write((oid + '\n').encode('ascii'))
                process.stdin.flush()
                header = process.stdout.readline().decode('ascii').strip().split(' ')
                require(len(header) == 3 and header[:2] == [oid, 'blob'] and header[2].isdigit(),
                        f'Missing or non-blob prospective input object: {oid}')
                remaining = int(header[2])
                digest = hashlib.sha256()
                while remaining:
                    block = process.stdout.read(min(1024 * 1024, remaining))
                    require(bool(block), f'Truncated Git object: {oid}')
                    digest.update(block)
                    remaining -= len(block)
                require(process.stdout.read(1) == b'\n', f'Invalid Git batch delimiter: {oid}')
                result[oid] = digest.hexdigest()
            process.stdin.close()
            require(process.wait(timeout=30) == 0, 'Git blob verification failed')
        except BaseException:
            process.kill()
            process.wait(timeout=5)
            raise
    return result


def tree_changes(before: dict, after: dict) -> list[dict]:
    return [{'path': path, 'status': 'A' if path not in before else ('D' if path not in after else 'M'),
             'before': before.get(path), 'after': after.get(path)}
            for path in sorted(set(before) | set(after)) if before.get(path) != after.get(path)]


def strip_hashes(receipt: dict) -> dict:
    return {key: value for key, value in receipt.items() if key != 'source_hashes'}


def nonnegative_int(value, context: str) -> int:
    require(type(value) is int and value >= 0, f'Invalid integer in {context}: {value!r}')
    return value


def test_path(value: str) -> str:
    require(isinstance(value, str), 'Test path must be text')
    path = Path(value)
    if path.is_absolute():
        path = path.relative_to(ENGINE)
    result = path.as_posix()
    require(result.startswith('test/') and '..' not in path.parts and result.endswith('.dart'),
            f'Unexpected test path: {value}')
    return result


def parse_test_events(path: Path, files: list[str]) -> dict:
    events = []
    for number, line in enumerate(capture(path).splitlines(), 1):
        require(bool(line.strip()), f'Empty JSONL event at {path}:{number}')
        event = json_load(line)
        require(isinstance(event, dict) and isinstance(event.get('type'), str),
                f'Invalid JSONL event at {path}:{number}')
        events.append(event)
    require(events and events[0]['type'] == 'start', f'Missing runner start: {path}')
    require(sum(event['type'] == 'start' for event in events) == 1, f'Multiple runs in {path}')
    done = [event for event in events if event['type'] == 'done']
    require(len(done) == 1 and events[-1] == done[0], f'Incomplete runner output: {path}')
    suites = {}
    declared_counts = {}
    tests = {}
    completions = {}
    for event in events:
        kind = event['type']
        if kind == 'suite':
            suite = event['suite']
            require(suite['id'] not in suites and suite['platform'] == 'vm',
                    f'Duplicate or non-VM suite: {path}')
            suites[suite['id']] = test_path(suite['path'])
        elif kind == 'group' and event['group'].get('parentID') is None:
            group = event['group']
            require(group['suiteID'] not in declared_counts, f'Duplicate root test group: {path}')
            declared_counts[group['suiteID']] = nonnegative_int(group['testCount'],
                                                                str(path) + '/root testCount')
        elif kind == 'testStart':
            test = event['test']
            require(test['id'] not in tests, f'Duplicate test ID: {path}')
            tests[test['id']] = test
        elif kind == 'testDone':
            require(event['testID'] not in completions, f'Duplicate completion: {path}')
            require(event.get('result') in ('success', 'failure', 'error'),
                    f'Unknown test result: {path}')
            require(type(event.get('hidden')) is bool and type(event.get('skipped')) is bool,
                    f'Missing completion flags: {path}')
            completions[event['testID']] = event
    require(Counter(suites.values()) == Counter(files), f'Wrong suite coverage: {path}')
    require(set(declared_counts) == set(suites), f'Missing root test-group counts: {path}')
    require(set(tests) == set(completions), f'Unfinished or unknown tests: {path}')
    all_suites = [event for event in events if event['type'] == 'allSuites']
    require(len(all_suites) == 1 and all_suites[0]['count'] == len(files),
            f'Wrong allSuites count: {path}')
    per_file = {file: {'passed': 0, 'failed': 0, 'skipped': 0, 'hidden': 0, 'tests': []}
                for file in files}
    for identifier, event in completions.items():
        test = tests[identifier]
        require(test['suiteID'] in suites, f'Unknown suite for test: {path}')
        item = per_file[suites[test['suiteID']]]
        if event['hidden']:
            item['hidden'] += 1
            require(event['result'] == 'success' and not event['skipped'],
                    f'Hidden load/setup/cleanup did not pass: {path}')
            continue
        if event['skipped']:
            item['skipped'] += 1
        elif event['result'] == 'success':
            item['passed'] += 1
        else:
            item['failed'] += 1
        item['tests'].append({'id': identifier, 'name': test['name'],
                              'result': event['result'], 'skipped': event['skipped']})
    for identifier, file in suites.items():
        counts = per_file[file]
        require(sum(counts[key] for key in ('passed', 'failed', 'skipped')) == declared_counts[identifier],
                f'Not every declared test completed in {file}: {path}')
    return {'per_file': per_file, 'runner_done': done,
            'errors': [event for event in events if event['type'] == 'error'],
            'passed': sum(item['passed'] for item in per_file.values()),
            'failed': sum(item['failed'] for item in per_file.values()),
            'skipped': sum(item['skipped'] for item in per_file.values()),
            'jsonl_sha256': SNAPSHOTS[path]}


def check_raw_receipt(receipt: dict, parsed: dict, name: str, passing: bool = True) -> None:
    require(receipt.get('source_unchanged') is True, f'Source changed during {name}')
    for key in ('passed', 'failed', 'skipped'):
        require(nonnegative_int(receipt.get(key), name + '/' + key) == parsed[key],
                f'Raw events disagree with {name}/{key}')
    require(receipt.get('runner_done') == parsed['runner_done'], f'Runner done mismatch: {name}')
    require(len(receipt.get('errors', [])) == len(parsed['errors']), f'Error count mismatch: {name}')
    if passing:
        require(receipt.get('exit_code') == 0 and receipt['failed'] == 0 and receipt['skipped'] == 0,
                f'Nonpassing receipt: {name}')
        require(not parsed['errors'] and parsed['runner_done'][0].get('success') is True,
                f'Runner did not report complete success: {name}')


def expected_manifest_paths(prefixes: list[str], revision: str | None = None) -> set[str]:
    if revision is None:
        return set(git('ls-files', '--', *prefixes).splitlines())
    return {path for path in git_tree_entries(revision)
            if any(path == prefix or path.startswith(prefix.rstrip('/') + '/') for prefix in prefixes)}


def check_manifest(receipt: dict, prefixes: list[str], name: str,
                   revision: str | None = None) -> dict[str, str]:
    values = receipt.get('source_hashes')
    require(isinstance(values, dict) and values, f'Missing source manifest: {name}')
    require(set(values) == expected_manifest_paths(prefixes, revision), f'Incomplete source domain: {name}')
    for path, digest in values.items():
        require(not PurePosixPath(path).is_absolute() and '..' not in PurePosixPath(path).parts,
                f'Invalid source path: {path}')
        require(isinstance(digest, str) and re.fullmatch(r'[0-9a-f]{64}', digest) is not None,
                f'Invalid source digest: {name}/{path}')
    return values


def check_current_sources(head: str, hashes: dict[str, str]) -> None:
    require(git('rev-parse', 'HEAD') == head, 'HEAD changed while collecting evidence')
    changed = set(git('diff', '--name-only', 'HEAD', '--').splitlines())
    require(not changed.intersection(hashes), 'Validated source differs from the frozen commit')
    for path, digest in hashes.items():
        require(checksum(REPO / path) == digest, f'Source changed since validation: {path}')


def check_portable(receipt: dict, head: str, tree: str, prefix: str = 'scoped-portable') -> tuple[dict, list[dict]]:
    require(receipt.get('commit') == head and receipt.get('tree') == tree, 'Stale portable receipt')
    require(receipt.get('source_unchanged') is True and receipt.get('commands_passed') is True
            and receipt.get('vm_js_semantic_equal') is True, 'Portable run did not pass')
    stages = receipt.get('stages', [])
    require([stage.get('name') for stage in stages] == ['vm', 'compile-js', 'javascript']
            and all(stage.get('exit_code') == 0 for stage in stages), 'Incomplete portable stages')
    sample_hashes = {path: checksum(ENGINE / path) for path in SAMPLES.values()}
    require(receipt.get('samples') == sample_hashes, 'Portable BAS samples differ from frozen source')
    for stage in stages[:2]:
        defines = [item for item in stage['command'] if item.startswith('-D')]
        require(len(defines) == len(SAMPLES), f'Wrong portable defines: {stage["name"]}')
        by_key = {}
        for item in defines:
            key, value = item[2:].split('=', 1)
            require(key not in by_key, 'Duplicate portable define')
            by_key[key] = value
        require(set(by_key) == set(SAMPLES), 'Portable define names differ')
        for key, path in SAMPLES.items():
            require(base64.b64decode(by_key[key], validate=True) == (ENGINE / path).read_bytes(),
                    f'Portable command did not receive exact BAS bytes: {path}')
    vm_raw = capture(RESULTS / (prefix + '-vm.stdout'))
    js_raw = capture(RESULTS / (prefix + '-javascript.stdout'))
    vm = canonical(json_load(vm_raw))
    javascript = canonical(json_load(js_raw))
    require(encode(vm) == encode(javascript), 'Portable canonical JSON differs')
    require(encode(receipt['result']) == encode(vm), 'Portable receipt result differs')
    require(receipt.get('vm_js_byte_equal') is (vm_raw == js_raw), 'Raw byte equality misreported')
    require(capture(RESULTS / (prefix + '-canonical.json')) == encode(vm),
            'Recorded canonical JSON differs')
    require(vm['paragraphsAndMargins']['insetBoundaryEmus'] == [1, 2147483647],
            'Missing exact EMU boundaries')
    require(vm['paragraphsAndMargins']['additionalReopens'] == 2, 'Missing repeated reopens')
    earlier = vm['previousTypographyAndSlideshow']
    require(all(earlier[key] is True for key in
                ['immutableValidation', 'unchangedCallerInput', 'secondSaveSemanticMatch']),
            'Previous examples lost transaction/persistence checks')
    specifications = [
        ('word_typography.bas', earlier['word']['steps'], 12),
        ('powerpoint_slideshow.bas', earlier['powerpoint']['steps'], 12),
        ('word_optional_helpers.bas', vm['optionalHelpers']['word']['operations'], 7),
        ('powerpoint_optional_helpers.bas', vm['optionalHelpers']['powerpoint']['operations'], 5),
        ('word_paragraph_layout.bas', vm['paragraphsAndMargins']['word']['operations'], 10),
        ('powerpoint_text_margins.bas', vm['paragraphsAndMargins']['powerpoint']['operations'], 5),
    ]
    examples = []
    for name, actual, expected in specifications:
        require(type(actual) is int and actual == expected, f'Unexpected operation count for {name}')
        path = 'example/macros/' + name
        examples.append({'file': path, 'operations': actual, 'sha256': sample_hashes[path]})
    compact = strip_hashes(receipt)
    compact['stages'] = [{key: value for key, value in stage.items() if key != 'command'}
                         for stage in stages]
    compact['full_commands'] = 'acceptance-evidence.tar.gz: validation-results/' + prefix + '.receipt.json'
    compact['comparison_recomputed_by_collector'] = True
    compact['vm_stdout_sha256'] = sha_bytes(vm_raw)
    compact['javascript_stdout_sha256'] = sha_bytes(js_raw)
    compact['canonical_json_sha256'] = sha_bytes(encode(vm))
    compact['examples'] = examples
    return compact, examples


def check_differential(per_file: dict[str, dict]) -> dict:
    relative = 'test/word_incremental_layout_differential_test.dart'
    repo_path = 'packages/quds_office_engine/' + relative
    current = (REPO / repo_path).read_text()
    baseline_bytes = git_bytes('show', LAYOUT_BASELINE + ':' + repo_path)
    baseline = baseline_bytes.decode('utf-8')
    previous_lines = iter(current.splitlines())
    preserved = all(any(line == candidate for candidate in previous_lines)
                    for line in baseline.splitlines())
    require(preserved, 'Original differential source was removed or changed')
    original_markers = [
        "test('same-height edits actually converge and reuse the tail'",
        'for (var index = 0; index < 10; index++)',
        "_equivalent(document, previous, 'same-height edit $index');",
        'for (final structures in <bool>[false, true])',
        'for (final seed in <int>[7, 43, 109])',
        'for (var step = 0; step < 48; step++)',
        "'seed=$seed structures=$structures step=$step'",
        'for (final endnote in <bool>[false, true])',
        "_equivalent(document, actual, 'note fallback');",
        "test('discarded state and section-list changes use fresh flow'",
        "_equivalent(document, previous, 'discarded state');",
        "_equivalent(document, previous, 'section-list change');",
    ]
    require(all(marker in current and marker in baseline for marker in original_markers),
            'Original comparison-count source markers changed')
    focused_markers = [
        'for (final editText in <bool>[true, false])',
        "_equivalent(document, previous, 'initial unwrapped cache');",
        "_equivalent(document, previous, 'edited with a wrapping frame');",
        "_equivalent(document, previous, 'clean target after frame removal');",
    ]
    require(all(marker in current for marker in focused_markers), 'Focused comparison markers changed')
    require(current.count('_equivalent(') == 9 and baseline.count('_equivalent(') == 6,
            'Unexpected differential comparison call sites')
    require(per_file[relative]['passed'] == 12, 'Expected 12 final differential cases')
    historical = read_json(EVIDENCE / 'integration/layout/receipt.json')
    require(historical['tests_passed'] == 10 and historical['fresh_engine_differential_comparisons'] == 302,
            'Historical layout receipt disagrees with source derivation')
    return {'test': relative, 'test_sha256': checksum(REPO / repo_path),
            'passing_cases': 12, 'fresh_engine_geometry_comparisons': 308,
            'execution_source_commit': per_file[relative]['source_commit'],
            'execution_source_kind': per_file[relative]['source_kind'],
            'derivation_kind': 'Source-reviewed fixed loop bounds, tied to the final passing file; not a runtime counter',
            'original': {'cases': 10, 'comparisons': 302,
                         'formula': '10 + (2 structures * 3 seeds * 48 edits) + 2 note cases + 2 state/section comparisons',
                         'baseline_commit': LAYOUT_BASELINE, 'baseline_sha256': sha_bytes(baseline_bytes),
                         'all_original_lines_preserved_in_order': preserved},
            'focused': {'cases': 2, 'comparisons': 6,
                        'formula': '2 text/font edit cases * 3 before/during/after frame comparisons'},
            'metrics': 'Pure Dart null-font fallback metrics; independent public geometry snapshot'}


def check_cache_reproduction(head: str) -> dict:
    reproduction = read_json(RESULTS / 'cache-invalidation-reproduction.json')
    require(reproduction.get('restored_sources') is True and reproduction['old_failed_cases'] == 2
            and reproduction['fixed_passed_cases'] == 2, 'Incomplete cache negative control')
    relative = 'test/word_incremental_layout_differential_test.dart'
    negative = read_json(RESULTS / 'cache-invalidation-negative-control.receipt.json')
    fixed = read_json(RESULTS / 'cache-invalidation-fixed.receipt.json')
    negative_raw = parse_test_events(RESULTS / 'cache-invalidation-negative-control.jsonl', [relative])
    fixed_raw = parse_test_events(RESULTS / 'cache-invalidation-fixed.jsonl', [relative])
    check_raw_receipt(negative, negative_raw, 'cache-negative-control', passing=False)
    check_raw_receipt(fixed, fixed_raw, 'cache-fixed')
    require(negative['exit_code'] == 1 and negative_raw['passed'] == 0 and negative_raw['failed'] == 2
            and negative_raw['skipped'] == 0 and negative_raw['runner_done'][0]['success'] is False,
            'Negative control did not demonstrate two failures')
    require(fixed_raw['passed'] == 2, 'Fixed cache control must pass both focused cases')
    require(negative.get('commit') == fixed.get('commit') == reproduction['fixed_commit']
            and ancestor(reproduction['old_production_commit'], reproduction['fixed_commit'])
            and ancestor(reproduction['fixed_commit'], head),
            'Cache-control revision identities or ancestry differ')
    require(all('incremental/full geometry differs' in event['error'] for event in negative_raw['errors']),
            'Negative control failed for an unrelated reason')
    for path, digest in reproduction['fixed_source_sha256'].items():
        require(fixed['source_hashes'][path] == digest, 'Fixed control source mismatch')
        old = git_bytes('show', reproduction['old_production_commit'] + ':' + path)
        require(negative['source_hashes'][path] == sha_bytes(old), 'Negative control did not use old production source')
    fixture = 'packages/quds_office_engine/' + relative
    require(negative['source_hashes'][fixture] == fixed['source_hashes'][fixture]
            == checksum(REPO / fixture), 'Cache-control regression fixture changed')
    return {**reproduction, 'included_in_acceptance_totals': False,
            'negative_control': strip_hashes(negative), 'fixed_control': strip_hashes(fixed),
            'current_source_sha256': {path: checksum(REPO / path)
                                      for path in reproduction['fixed_source_sha256']},
            'interpretation': 'Supplemental two-failure/two-pass reproduction on the recorded old/fixed sources; final coverage comes from the final gate.'}


def classification(relative: str) -> str:
    if relative in FINAL_ACCEPTED_RAW:
        return 'accepted-final-source-group-or-static-portable'
    if relative in BASELINE_ACCEPTED_RAW:
        return 'complete-baseline-group-only-retained-file-cases-counted'
    if relative.startswith('validation-results/pre-cache-fix/'):
        return 'excluded-pre-cache-fix-attempt-including-real-regression'
    if relative.startswith('validation-results/pre-main-refresh/'):
        return 'excluded-pre-main-refresh-attempt-interrupted-before-source-change'
    name = Path(relative).name
    if relative.startswith('validation-results/'):
        if name.startswith('cache-invalidation-'):
            return 'supplemental-cache-reproduction-not-added-to-total'
        if re.match(r'expansion-shard\d{2}\.', name) or name.startswith('expansion-acceptance.receipt'):
            return 'baseline-history-superseded-or-failed-not-counted'
        if name.startswith(('scoped-shard', 'scoped-acceptance', 'scoped-static', 'scoped-portable',
                            'scoped-format', 'scoped-analyze')):
            return 'final-scoped-qualification-evidence-see-per-file-provenance'
        if name.startswith(('expansion-final-', 'expansion-portable-')) or name == 'expansion-portable.receipt.json':
            return 'historical-baseline-static-or-portable-superseded'
        if name in ('expansion-selection.json', 'expansion-shards.json', 'environment.json') or name.startswith('test-runner-compile-bounded'):
            return 'final-selection-or-environment'
        return 'excluded-development-setup-or-aborted-attempt'
    if relative.startswith('drivers/'):
        return 'reproduction-driver'
    if relative.startswith('runtime-configuration/'):
        return 'runtime-configuration-no-sdk-or-cache-binaries'
    if relative.startswith('frozen-inputs/'):
        return 'frozen-test-example-or-driver-source'
    if relative.startswith('integration/'):
        return 'intake-or-earlier-integration-evidence-not-added-to-total'
    return 'excluded-development-evidence'


def archive_inputs(selection: list[str]) -> tuple[dict[str, Path], set[str]]:
    members: dict[str, Path] = {}

    def add(name: str, path: Path) -> None:
        require(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts,
                f'Unsafe archive name: {name}')
        require(path.is_file() and not path.is_symlink(), f'Unsafe or missing archive input: {path}')
        require(name not in members or members[name] == path, f'Duplicate archive name: {name}')
        require(path.stat().st_size <= 64 * 1024 * 1024,
                f'Unexpected large evidence file; inspect explicitly before packaging: {path}')
        members[name] = path

    result_names = set()
    for path in sorted(RESULTS.rglob('*')):
        require(not path.is_symlink(), f'Symlink inside validation-results: {path}')
        if path.is_file():
            relative = path.relative_to(ROOT).as_posix()
            add(relative, path)
            result_names.add(relative)
    require(any('/pre-cache-fix/' in name for name in result_names), 'Missing pre-cache-fix history')
    require(any('/pre-main-refresh/' in name for name in result_names), 'Missing interrupted main-refresh history')
    for name in DRIVERS:
        add('drivers/' + name, ROOT / name)
    for pattern in DEVELOPMENT_PATTERNS:
        for path in sorted(ROOT.glob(pattern)):
            if path.is_file():
                add('development/' + path.relative_to(ROOT).as_posix(), path)
    for name in ['arguments-first-test.log', 'arguments-integration-test.log',
                 'incremental-layout-differential-first.log', 'incremental-layout-differential-second.log',
                 'ppt-insets-preservation.log', 'word-compiler-layout-tests.log',
                 'word-native-layout-tests-final.log', 'word-legacy-layout-tests.log']:
        require('development/' + name in members, f'Missing expected development log: {name}')
    for path in sorted((EVIDENCE / 'integration').rglob('*')):
        if path.is_file():
            add('integration/' + path.relative_to(EVIDENCE / 'integration').as_posix(), path)
    configuration = {
        'engine-package-config.json': REPO / '.dart_tool/package_config.json',
        'validation-package-config.json': ROOT / 'validation-workspace/.dart_tool/package_config.json',
        'validation-pubspec.yaml': ROOT / 'validation-workspace/pubspec.yaml',
        'validation-pubspec.lock': ROOT / 'validation-workspace/pubspec.lock',
        'test-runner.d': ROOT / 'toolchains/test-runner/test-runner.d',
    }
    for name, path in configuration.items():
        add('runtime-configuration/' + name, path)
    sources = ['packages/quds_office_engine/' + path for path in selection]
    sources += ['packages/quds_office_engine/' + path for path in SAMPLES.values()]
    sources += ['packages/quds_office_engine/tool/macros/' + name for name in
                ['web_vba_office_expansion_smoke.dart', 'web_vba_arguments_smoke.dart',
                 'web_vba_office_layout_smoke.dart']]
    for path in sources:
        add('frozen-inputs/' + path, REPO / path)
    require(sum(path.stat().st_size for path in members.values()) <= 256 * 1024 * 1024,
            'Unexpected evidence volume; inspect before creating archive')
    return members, result_names


def write_archive(path: Path, members: dict[str, Path]) -> dict:
    records = []
    for name, source in sorted(members.items()):
        digest = checksum(source)
        require(source not in SNAPSHOTS or SNAPSHOTS[source] == digest,
                f'Evidence changed before archive: {source}')
        SNAPSHOTS[source] = digest
        records.append({'path': name, 'bytes': source.stat().st_size, 'sha256': digest,
                        'classification': classification(name)})
    index = {'schema': 'quds-vba-expansion-archive/v1', 'member_count': len(records),
             'uncompressed_bytes': sum(record['bytes'] for record in records), 'members': records,
             'policy': 'Every regular validation-results file, explicit task development log patterns, reproduction drivers, configuration, integration evidence, and frozen small test/example sources. SDK, pub cache, generated JS/kernel binaries, and Office fixture binaries are not copied.'}
    manifest = pretty(index)
    with path.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', compresslevel=6, fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as archive:
                for record in records:
                    info = tarfile.TarInfo(record['path'])
                    info.size = record['bytes']
                    info.mode = 0o644
                    info.mtime = 0
                    with members[record['path']].open('rb') as content:
                        archive.addfile(info, content)
                info = tarfile.TarInfo('archive-members.json')
                info.size = len(manifest)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(manifest))
    index['archive_sha256'] = checksum(path)
    index['archive_bytes'] = path.stat().st_size
    index['internal_manifest'] = 'archive-members.json (its payload is the pre-archive index, without the archive checksum)'
    return index


def case_names_digest(names: list[str]) -> str:
    return sha_bytes(json.dumps(sorted(names), ensure_ascii=False, sort_keys=True,
                                separators=(',', ':'), allow_nan=False).encode('utf-8'))


def evidence_path(value: str) -> Path:
    require(isinstance(value, str), 'Evidence path must be text')
    relative = PurePosixPath(value)
    require(not relative.is_absolute() and '..' not in relative.parts,
            f'Unsafe evidence path: {value}')
    path = ROOT / relative
    require(path.resolve().is_relative_to(ROOT), f'Evidence escapes workspace: {value}')
    return path


def merged_manifests(manifests: dict[str, dict[str, str]]) -> dict[str, str]:
    merged = {}
    for label, values in manifests.items():
        for path, digest in values.items():
            require(path not in merged or merged[path] == digest,
                    f'Contradictory {label} source hash for {path}')
            merged[path] = digest
    return dict(sorted(merged.items()))


def check_test_command(receipt: dict, files: list[str], context: str) -> None:
    command = receipt.get('command', [])
    require(isinstance(command, list) and all(isinstance(value, str) for value in command),
            f'Invalid command in {context}')
    require(command[-len(files):] == files, f'Test arguments differ in {context}')
    require(receipt.get('cwd') == str(ENGINE), f'Test working directory differs in {context}')
    required = ['--old_gen_heap_size=512', '--concurrency=1', '--timeout=4x',
                '--reporter=json', '--fail-fast']
    require(all(flag in command for flag in required), f'Unexpected execution strategy: {context}')
    require('--compiler' in command and command[command.index('--compiler') + 1] == 'source',
            f'Wrong compiler in {context}')
    require(str(ROOT / 'toolchains/test-runner/test-runner.dill') in command,
            f'Unexpected runner in {context}')
    filters = {'--name', '-n', '--plain-name', '--tags', '-t', '--exclude-tags', '-x',
               '--total-shards', '--shard-index'}
    require(not any(value.split('=', 1)[0] in filters or
                    (value.startswith('-n') and not value.startswith('--'))
                    for value in command), f'Filtered final suite in {context}')


def checked_case_names(counts: dict, context: str) -> list[str]:
    names = [entry['name'] for entry in counts['tests']]
    require(all(isinstance(name, str) and name for name in names),
            f'Empty or invalid case name in {context}')
    require(len(names) == counts['passed'] and counts['failed'] == counts['skipped'] == 0,
            f'Nonpassing visible cases in {context}')
    return sorted(names)


def check_plan(plan: dict, head: str) -> tuple[list[str], dict[str, dict], dict[str, dict], list[dict]]:
    require(plan.get('baseline_commit') == BASELINE_COMMIT,
            'Scoped plan refers to another baseline')
    require(plan.get('final_commit') == head and head != BASELINE_COMMIT
            and re.fullmatch(r'[0-9a-f]{40}', head) is not None,
            'Scoped plan must pin the final published commit')
    require(ancestor(BASELINE_COMMIT, head), 'Final source does not contain baseline history')
    selection = plan.get('selection')
    require(isinstance(selection, list) and len(selection) == len(set(selection)) == 80
            and all(test_path(path) == path for path in selection),
            'Scoped plan must preserve the 80-file selection')
    require(selection == read_json(RESULTS / 'expansion-selection.json'),
            'Scoped selection differs from the original acceptance selection')
    prior = read_json(REPO / 'docs/validation/office-vba-continuation-20261120/runtime/selection.json')
    expected = list(dict.fromkeys(['test/' + name + '.dart' for name in NEW_FILES] + prior))
    require(len(prior) == 64 and selection == expected, 'Selection changed beyond the reviewed 16 + 64 files')
    retained_list, rerun_list = plan.get('retained_files'), plan.get('rerun_files')
    require(isinstance(retained_list, list) and isinstance(rerun_list, list),
            'Missing reviewed cohort decisions')
    retained = {row['file']: row for row in retained_list}
    rerun = {row['file']: row for row in rerun_list}
    require(len(retained) == len(retained_list) and len(rerun) == len(rerun_list)
            and not set(retained).intersection(rerun)
            and set(retained) | set(rerun) == set(selection),
            'Retained and rerun cohorts must be an exact, disjoint selection partition')
    for row in retained_list + rerun_list:
        require(isinstance(row.get('reason'), str) and bool(row['reason'].strip()),
                f'Missing source-impact reason for {row["file"]}')
    groups = plan.get('rerun_groups')
    require(isinstance(groups, list) and groups, 'Missing final rerun group plan')
    require([row['label'] for row in groups] ==
            [f'scoped-shard{index:02d}' for index in range(1, len(groups) + 1)],
            'Unexpected scoped group labels')
    require(Counter(file for group in groups for file in group['files']) == Counter(rerun.keys()),
            'Scoped groups omit or duplicate rerun files')
    require(all(group['files'] for group in groups), 'Empty scoped group')
    require(plan.get('expected_added_cases') == {
        'test/slide_text_insets_preservation_test.dart': 3,
        'test/word_incremental_layout_test.dart': 3,
    }, 'Expected new regression cases differ from the reviewed change')
    require(set(plan['expected_added_cases']).issubset(rerun),
            'Changed test files cannot be retained from baseline')
    delta = plan.get('approved_source_delta')
    require(isinstance(delta, list) and [row['path'] for row in delta] == sorted(APPROVED_ENGINE_DELTA),
            'Plan must pin the exact eight approved engine input changes')
    return selection, retained, rerun, groups


def accepted_row(file: str, label: str, commit: str, kind: str, receipt_path: Path,
                 raw_path: Path, receipt: dict, parsed: dict, reason: str) -> dict:
    counts = parsed['per_file'][file]
    names = checked_case_names(counts, file)
    require(names, f'No visible cases executed in {file}')
    return {
        'file': file, 'source_kind': kind, 'source_commit': commit, 'source_group': label,
        'receipt': receipt_path.relative_to(ROOT).as_posix(),
        'jsonl': raw_path.relative_to(ROOT).as_posix(),
        'passed': counts['passed'], 'failed': 0, 'skipped': 0,
        'declared_cases': len(names), 'case_names': names,
        'case_names_sha256': case_names_digest(names),
        'test_source_sha256': receipt['source_hashes']['packages/quds_office_engine/' + file],
        'receipt_sha256': SNAPSHOTS[receipt_path],
        'raw_jsonl_sha256': parsed['jsonl_sha256'],
        'hidden_events_excluded': counts['hidden'], 'reason': reason,
    }


def collect_cases(plan: dict, head: str, selection: list[str], retained: dict,
                  rerun: dict, groups: list[dict]) -> tuple[list[dict], dict, dict, dict]:
    original_plan = read_json(RESULTS / 'expansion-shards.json')
    require([row['label'] for row in original_plan] ==
            [f'expansion-shard{index:02d}' for index in range(1, 31)]
            and [file for group in original_plan for file in group['files']] == selection,
            'Original 30-group plan differs from the reviewed selection')
    original_by_label = {row['label']: row['files'] for row in original_plan}
    baseline_hashes = None
    baseline_complete = {}
    baseline_groups = []
    accepted = {}
    for group in original_plan:
        label, files = group['label'], group['files']
        receipt_path = RESULTS / (label + '.receipt.json')
        requested = [file for file in files if file in retained]
        if not receipt_path.is_file():
            require(not requested, f'Retained file lacks its original receipt: {label}')
            continue
        receipt = read_json(receipt_path)
        if receipt.get('commit') != BASELINE_COMMIT or receipt.get('exit_code') != 0:
            require(not requested, f'Retained file comes from a failed/stale group: {label}')
            continue
        raw_path = RESULTS / (label + '.jsonl')
        check_test_command(receipt, files, label)
        parsed = parse_test_events(raw_path, files)
        check_raw_receipt(receipt, parsed, label)
        values = check_manifest(receipt, GATE_PATHS, label, BASELINE_COMMIT)
        require(baseline_hashes is None or baseline_hashes == values,
                'Completed baseline groups have different source manifests')
        baseline_hashes = values
        for file in files:
            baseline_complete[file] = checked_case_names(parsed['per_file'][file], file)
        group_kept = 0
        for file in requested:
            decision = retained[file]
            require(decision['source_group'] == label
                    and evidence_path(decision['receipt']) == receipt_path
                    and evidence_path(decision['jsonl']) == raw_path,
                    f'Baseline provenance differs from reviewed plan: {file}')
            row = accepted_row(file, label, BASELINE_COMMIT, 'retained_baseline',
                               receipt_path, raw_path, receipt, parsed, decision['reason'])
            for key in ('passed', 'case_names_sha256', 'test_source_sha256'):
                require(decision.get(key) == row[key], f'Retained {key} differs from raw evidence: {file}')
            require(Counter(decision['case_names']) == Counter(row['case_names'])
                    and decision['source_commit'] == BASELINE_COMMIT
                    and decision['receipt_sha256'] == row['receipt_sha256']
                    and decision['jsonl_sha256'] == row['raw_jsonl_sha256'],
                    f'Retained raw identity differs from the reviewed plan: {file}')
            require(checksum(ENGINE / file) == row['test_source_sha256'],
                    f'Retained test source changed: {file}')
            require(file not in accepted, f'Duplicate accepted file: {file}')
            accepted[file] = row
            group_kept += row['passed']
        if requested:
            for source in (receipt_path, raw_path):
                BASELINE_ACCEPTED_RAW.add(source.relative_to(ROOT).as_posix())
            baseline_groups.append({
                'label': label, 'files': requested, 'retained_passed': group_kept,
                'all_group_passed': parsed['passed'],
                'superseded_group_cases_excluded': parsed['passed'] - group_kept,
                'receipt': receipt_path.relative_to(ROOT).as_posix(),
                'receipt_sha256': SNAPSHOTS[receipt_path],
                'jsonl': raw_path.relative_to(ROOT).as_posix(),
                'jsonl_sha256': parsed['jsonl_sha256'],
            })
    require(baseline_hashes and set(accepted) == set(retained), 'Incomplete retained cohort')
    final_hashes = None
    final_groups = []
    for group in groups:
        label, files = group['label'], group['files']
        receipt_path = RESULTS / (label + '.receipt.json')
        raw_path = RESULTS / (label + '.jsonl')
        receipt = read_json(receipt_path)
        require(receipt.get('commit') == head, f'Final group ran another commit: {label}')
        check_test_command(receipt, files, label)
        parsed = parse_test_events(raw_path, files)
        check_raw_receipt(receipt, parsed, label)
        values = check_manifest(receipt, GATE_PATHS, label, head)
        require(final_hashes is None or final_hashes == values,
                'Final rerun groups have different source manifests')
        final_hashes = values
        for source in (receipt_path, raw_path):
            FINAL_ACCEPTED_RAW.add(source.relative_to(ROOT).as_posix())
        for file in files:
            row = accepted_row(file, label, head, 'rerun_final', receipt_path,
                               raw_path, receipt, parsed, rerun[file]['reason'])
            require(file not in accepted, f'Accepted cohorts overlap: {file}')
            old = baseline_complete.get(file)
            if old is not None:
                extra = plan['expected_added_cases'].get(file, 0)
                require(Counter(old) <= Counter(row['case_names'])
                        and len(row['case_names']) == len(old) + extra,
                        f'Final rerun removed/renamed cases or added an unreviewed count: {file}')
                row['baseline_case_comparison'] = {
                    'baseline_complete_cases': len(old), 'baseline_case_names_sha256': case_names_digest(old),
                    'all_prior_cases_preserved': True,
                    'added_case_names': sorted((Counter(row['case_names']) - Counter(old)).elements()),
                }
            else:
                row['baseline_case_comparison'] = {
                    'baseline_complete_cases': None,
                    'reason': 'No fully successful baseline group supplies this file; all acceptance cases are final-source reruns.',
                }
            accepted[file] = row
        final_groups.append({
            'label': label, 'files': files, 'passed': parsed['passed'],
            'seconds': receipt['duration_seconds'],
            'receipt': receipt_path.relative_to(ROOT).as_posix(),
            'receipt_sha256': SNAPSHOTS[receipt_path],
            'jsonl': raw_path.relative_to(ROOT).as_posix(),
            'jsonl_sha256': parsed['jsonl_sha256'],
        })
    require(final_hashes and set(accepted) == set(selection), 'Incomplete final 80-file coverage')
    rows = [accepted[file] for file in selection]
    identities = [(row['file'], name, ordinal)
                  for row in rows for name, count in sorted(Counter(row['case_names']).items())
                  for ordinal in range(1, count + 1)]
    require(len(identities) == len(set(identities)), 'Accepted case identities overlap')
    retained_passed = sum(row['passed'] for row in rows if row['source_kind'] == 'retained_baseline')
    require(retained_passed == plan.get('baseline_retained_passed'),
            'Raw retained count differs from the reviewed plan')
    provenance = {'retained_file_groups': baseline_groups, 'rerun_groups': final_groups,
                  'unique_case_count': len(identities),
                  'case_identity': ['file', 'full_test_name', 'occurrence_ordinal_per_name'],
                  'case_identity_sha256': sha_bytes(encode(identities)),
                  'cohorts_disjoint': True, 'all_started_and_declared_cases_completed': True}
    return rows, baseline_hashes, final_hashes, provenance


def compact_digest(value, ensure_ascii: bool = False) -> str:
    return sha_bytes(json.dumps(value, sort_keys=True, ensure_ascii=ensure_ascii,
                                separators=(',', ':'), allow_nan=False).encode('utf-8'))


def check_aggregate(plan: dict, rows: list[dict], provenance: dict,
                    baseline_hashes: dict, final_hashes: dict, plan_path: Path) -> dict:
    path = RESULTS / 'scoped-acceptance.receipt.json'
    receipt = read_json(path)
    retained = [row for row in rows if row['source_kind'] == 'retained_baseline']
    rerun = [row for row in rows if row['source_kind'] == 'rerun_final']
    expected = {
        'baseline_commit': plan['baseline_commit'], 'final_commit': plan['final_commit'],
        'single_source_full_rerun': False, 'selected_file_count': len(rows),
        'distinct_selection': True, 'retained_file_count': len(retained),
        'rerun_file_count': len(rerun), 'completed_rerun_group_count': len(plan['rerun_groups']),
        'retained_passed': sum(row['passed'] for row in retained),
        'rerun_passed': sum(row['passed'] for row in rerun),
        'passed': sum(row['passed'] for row in rows), 'failed': 0, 'skipped': 0,
        'source_unchanged': True, 'plan_sha256': SNAPSHOTS[plan_path],
        'approved_source_delta': plan['approved_source_delta'], 'source_hashes': final_hashes,
        'baseline_source_manifest_sha256': compact_digest(baseline_hashes),
        'failed_group28_included': False, 'superseded_baseline_passes_included': False,
    }
    for key, value in expected.items():
        require(receipt.get(key) == value, f'Scoped aggregate disagrees with independent {key}')
    keys = ['file', 'source_kind', 'source_commit', 'source_group', 'receipt', 'jsonl',
            'passed', 'failed', 'skipped', 'declared_cases', 'case_names_sha256', 'test_source_sha256']
    require(receipt.get('per_file') == [{key: row[key] for key in keys} for row in rows],
            'Aggregate per-file counts, hashes or provenance differ from raw events')
    old_groups = [{
        'source_group': row['label'], 'source_commit': BASELINE_COMMIT,
        'files': row['files'], 'passed': row['retained_passed'],
        'receipt': row['receipt'], 'jsonl': row['jsonl'],
        'receipt_sha256': row['receipt_sha256'], 'jsonl_sha256': row['jsonl_sha256'],
        'full_original_group_passed': row['all_group_passed'], 'only_listed_files_counted': True,
    } for row in provenance['retained_file_groups']]
    final_groups = [{**row, 'source_commit': plan['final_commit']}
                    for row in provenance['rerun_groups']]
    require(receipt.get('retained_file_groups') == old_groups
            and receipt.get('rerun_groups') == final_groups,
            'Aggregate group provenance differs from original receipts')
    require(receipt.get('duration_seconds_rerun') == sum(row['seconds'] for row in final_groups),
            'Scoped duration differs from final rerun receipts')
    return receipt


def check_static(receipt: dict, revision: str, context: str) -> dict[str, str]:
    require(receipt.get('commit') == revision and receipt.get('source_unchanged') is True,
            f'Stale or changed-source static receipt: {context}')
    checks = receipt.get('checks', [])
    require([item.get('name') for item in checks] == ['format', 'analyze']
            and all(item.get('exit_code') == 0 for item in checks), f'Static checks failed: {context}')
    require(checks[1]['command'][-2:] == ['analyze', '--fatal-infos']
            and checks[0]['command'][1:4] == ['format', '--output=none', '--set-exit-if-changed'],
            f'Static command strictness differs: {context}')
    entries = git_tree_entries(revision)
    files = [path for path in git('diff', '--name-only', PREVIOUS_MAIN, revision, '--',
                                  'packages/quds_office_engine',
                                  'packages/quds_office_editor/lib/src/editor_slide/render_slide_stage.dart').splitlines()
             if path.endswith('.dart') and path in entries]
    require(checks[0]['command'][4:] == files and receipt.get('format_file_count') == len(files),
            f'Static formatting coverage differs: {context}')
    require(checks[0]['cwd'] == str(REPO) and checks[1]['cwd'] == str(ENGINE),
            f'Static working directories differ: {context}')
    return check_manifest(receipt, STATIC_PATHS, context, revision)


def check_source_delta(plan: dict, baseline_manifests: dict, final_manifests: dict,
                       retained: dict, head: str) -> tuple[dict, dict, dict]:
    baseline = merged_manifests(baseline_manifests)
    final = merged_manifests(final_manifests)
    require(set(baseline) == set(final), 'Final input union added or removed unreviewed paths')
    before, after = git_tree_entries(BASELINE_COMMIT), git_tree_entries(head)
    changes = tree_changes(before, after)
    object_ids = set()
    for entries, hashes in ((before, baseline), (after, final)):
        for path in hashes:
            require(path in entries and entries[path]['type'] == 'blob',
                    f'Missing or non-blob input: {path}')
            object_ids.add(entries[path]['object'])
    for change in changes:
        for side in ('before', 'after'):
            entry = change[side]
            if entry is not None:
                require(entry['type'] == 'blob', f'Non-blob changed object: {change["path"]}')
                object_ids.add(entry['object'])
    blob_hashes = git_blob_hashes(object_ids)

    def enriched(entry):
        return None if entry is None else {**entry, 'sha256': blob_hashes[entry['object']]}

    for entries, hashes, label in ((before, baseline, 'baseline'), (after, final, 'final')):
        for path, digest in hashes.items():
            require(blob_hashes[entries[path]['object']] == digest,
                    f'{label} source receipt disagrees with its Git blob: {path}')
    input_delta = [{
        'path': row['path'], 'before': enriched(row['before']), 'after': enriched(row['after']),
    } for row in changes if row['path'] in baseline]
    require([row['path'] for row in input_delta] == sorted(APPROVED_ENGINE_DELTA)
            and input_delta == plan['approved_source_delta'],
            'Actual input delta differs from the exact eight reviewed mode/type/blob/SHA256 changes')
    require([row['path'] for row in changes if row['path'].startswith('packages/quds_office_engine/')]
            == sorted(APPROVED_ENGINE_DELTA), 'Unreviewed engine change outside the captured input delta')
    for file in retained:
        path = 'packages/quds_office_engine/' + file
        require(enriched(before[path]) == enriched(after[path]),
                f'Retained test source changed: {file}')
    detailed_changes = [{
        **row,
        'before_sha256': None if row['before'] is None else blob_hashes[row['before']['object']],
        'after_sha256': None if row['after'] is None else blob_hashes[row['after']['object']],
        'in_baseline_gate_input_union': row['path'] in baseline,
    } for row in changes]
    source_manifest = {
        'schema': 'quds-vba-expansion-scoped-source-unions/v1',
        'baseline_commit': BASELINE_COMMIT, 'baseline_tree': git('rev-parse', BASELINE_COMMIT + '^{tree}'),
        'final_commit': head, 'final_tree': git('rev-parse', head + '^{tree}'),
        'file_count': len(final), 'all_input_paths_shared': True,
        'baseline_source_hashes': baseline, 'final_source_hashes': final,
        'baseline_entries': {path: enriched(before[path]) for path in sorted(baseline)},
        'final_entries': {path: enriched(after[path]) for path in sorted(final)},
        'capture_domains': {'test_gate': GATE_PATHS, 'static': STATIC_PATHS, 'portable': PORTABLE_PATHS},
        'capture_counts': {
            'baseline': {key: len(value) for key, value in baseline_manifests.items()},
            'final': {key: len(value) for key, value in final_manifests.items()},
        },
        'manifest_sha256': {
            'baseline': {key: compact_digest(value) for key, value in baseline_manifests.items()},
            'final': {key: compact_digest(value) for key, value in final_manifests.items()},
        },
        'all_overlap_hashes_equal_within_each_commit': True,
        'all_completed_baseline_gate_manifests_identical': True,
        'all_final_rerun_gate_manifests_identical': True,
        'all_manifest_hashes_match_recorded_git_objects': True,
        'current_disk_matches_final_inputs': True,
        'retention_is_new_execution': False,
    }
    delta = {
        'schema': 'quds-vba-expansion-scoped-source-delta/v1',
        'baseline_commit': BASELINE_COMMIT, 'final_commit': head,
        'approved_input_changes': input_delta, 'input_changed_count': len(input_delta),
        'input_unchanged_count': len(final) - len(input_delta),
        'input_path_count': len(final), 'all_unlisted_inputs_exactly_unchanged': True,
        'retained_test_file_count': len(retained), 'retained_test_mode_type_blob_sha256_unchanged': True,
        'full_tree_change_count': len(detailed_changes), 'full_tree_changes': detailed_changes,
        'outside_input_changes': [row for row in detailed_changes if not row['in_baseline_gate_input_union']],
        'qualification_note': DELTA_NOTE,
    }
    check_current_sources(head, final)
    return source_manifest, delta, final


def check_historical_equivalence(proof: dict, head: str) -> None:
    old, accepted = proof['historical_head'], proof['accepted_ancestor']
    require(proof.get('verified') is True and proof.get('accepted_is_ancestor') is True
            and ancestor(accepted, head), 'Historical equivalent is not accepted by final history')
    paths = [value.decode('utf-8') for value in git_bytes(
        'diff', '--name-only', '-z', proof['comparison_base'], old).split(b'\0') if value]
    require(paths and len(paths) == proof['changed_path_count'], 'Historical changed-path count differs')
    if 'changed_paths' in proof:
        require(paths == proof['changed_paths'], 'Historical changed paths differ')
    one = git_bytes('ls-tree', '-r', '-z', old, '--', *paths)
    two = git_bytes('ls-tree', '-r', '-z', accepted, '--', *paths)
    require(one == two and proof.get('changed_modes_types_objects_exact') is True,
            'Historical changed-path mode/type/blob equivalence failed')
    old_digest = proof.get('historical_changed_entries_sha256', proof.get('changed_entries_sha256'))
    new_digest = proof.get('accepted_changed_entries_sha256', proof.get('changed_entries_sha256'))
    require(sha_bytes(one) == old_digest == new_digest, 'Historical proof raw-entry digest differs')
    old_tree, accepted_tree = git('rev-parse', old + '^{tree}'), git('rev-parse', accepted + '^{tree}')
    require(proof['historical_tree'] == old_tree and proof['accepted_tree'] == accepted_tree
            and proof['whole_tree_equal'] is (old_tree == accepted_tree), 'Historical tree identity differs')


def check_inclusion(plan: dict, head: str, tree: str, manifests: dict, delta: dict) -> tuple[dict, dict, list[dict]]:
    require(plan.get('final_inclusion_path') == FINAL_INCLUSION.relative_to(REPO).as_posix()
            and plan.get('final_main_review_path')
            == (EVIDENCE / 'integration/final-cutoff-main-review.json').relative_to(REPO).as_posix(),
            'Scoped plan points to different final intake/main proofs')
    inclusion = read_json(FINAL_INCLUSION)
    require(inclusion.get('schema') == 'quds-vba-expansion-final-cutoff-inclusion/v1'
            and inclusion.get('target_commit') == head and inclusion.get('target_tree') == tree,
            'Final-cutoff inclusion does not target final qualified source')
    inventory_path = REPO / inclusion['cutoff_path']
    require(inventory_path == EVIDENCE / 'integration/final-cutoff-inventory.json', 'Unexpected cutoff path')
    inventory = read_json(inventory_path)
    require(inclusion['cutoff_sha256'] == SNAPSHOTS[inventory_path]
            and inventory.get('schema') == 'quds-vba-expansion-final-cutoff/v1', 'Final inventory hash/schema differs')
    require(inclusion['baseline_commit'] == BASELINE_COMMIT and inclusion['baseline_is_ancestor'] is True
            and ancestor(BASELINE_COMMIT, head), 'Final source lacks baseline ancestry')
    required = inclusion['required_new_heads']
    require(len(required) == 4 and {row['sha'] for row in required}
            == {row['sha'] for row in inventory['required_new_heads']}, 'Final required incoming heads differ')
    require(all(row['is_ancestor'] is True and ancestor(row['sha'], head) for row in required),
            'Final source lacks a required incoming head')
    proofs = inclusion['historical_equivalence_proofs']
    by_head = {row['historical_head']: row for row in proofs}
    require(len(by_head) == len(proofs) == 14, 'Historical proof coverage differs')
    for proof in proofs:
        check_historical_equivalence(proof, head)
    cohorts = [('branches', 'current_branches'), ('pull_requests', 'current_pull_requests'),
               ('upstream', 'current_upstream'), ('retained_deleted_branches', 'retained_deleted_branches')]

    def verify_ref_rows(rows: list[dict], captured: list[dict], context: str) -> None:
        require(Counter((row['ref'], row['sha']) for row in rows)
                == Counter((row['ref'], row['sha']) for row in captured),
                f'Final inclusion does not cover the exact {context}')
        for row in rows:
            if ancestor(row['sha'], head):
                require(row.get('status') == 'ancestor' or row.get('is_ancestor') is True,
                        f'Incorrect ancestry status for {row["ref"]}')
            else:
                proof = by_head.get(row['sha'])
                require(row.get('status') == 'historically_superseded_equivalent' and proof
                        and row.get('accepted_ancestor') == proof['accepted_ancestor'],
                        f'Uncovered incoming ref: {row["ref"]}')
    covered = {}
    for final_key, cutoff_key in cohorts:
        rows, captured = inclusion[final_key], inventory[cutoff_key]
        verify_ref_rows(rows, captured, cutoff_key)
        covered[final_key] = len(rows)
    for key, cutoff_key in [('retained_advanced_branch_prior_heads', 'advanced_branches'),
                            ('retained_advanced_pr_prior_heads', 'advanced_pull_request_heads')]:
        expected = [{'ref': row['ref'], 'sha': row['prior_sha']} for row in inventory[cutoff_key]]
        verify_ref_rows(inclusion[key], expected, cutoff_key)
    prior_capture = inventory['prior_capture']
    prior_path = REPO / prior_capture['path']
    require(prior_path.resolve().is_relative_to(REPO), 'Prior cutoff capture escapes repository')
    prior = read_json(prior_path)
    require(SNAPSHOTS[prior_path] == prior_capture['sha256'], 'Prior captured inventory hash changed')
    for key in ('branches', 'pull_requests', 'upstream'):
        verify_ref_rows(inclusion['prior_capture_coverage'][key], prior[key], 'prior_capture/' + key)
    summary = inclusion['summary']
    expected_summary = {
        'branch_count': covered['branches'],
        'branches': dict(Counter(row['status'] for row in inclusion['branches'])),
        'pr_count': covered['pull_requests'],
        'prs': dict(Counter(row['status'] for row in inclusion['pull_requests'])),
        'upstream_count': covered['upstream'],
        'upstream': dict(Counter(row['status'] for row in inclusion['upstream'])),
        'retained_deleted_branch_count': covered['retained_deleted_branches'],
        'retained_deleted_branches_all_ancestors': all(ancestor(row['sha'], head)
                                                       for row in inclusion['retained_deleted_branches']),
        'retained_advanced_branch_prior_head_count': len(inclusion['retained_advanced_branch_prior_heads']),
        'retained_advanced_pr_prior_head_count': len(inclusion['retained_advanced_pr_prior_heads']),
        'prior_capture_branch_count': len(prior['branches']),
        'prior_capture_pr_count': len(prior['pull_requests']),
        'prior_capture_upstream_count': len(prior['upstream']),
    }
    require(all(summary.get(key) == value for key, value in expected_summary.items()),
            'Final intake summary differs from independently checked ref counts/statuses')
    require(summary['uncovered_count'] == 0 and summary['all_historical_proofs_verified'] is True
            and summary['all_required_new_heads_ancestors'] is True
            and summary['historical_proof_count'] == len(proofs)
            and summary['historical_whole_tree_equal_count'] == sum(row['whole_tree_equal'] for row in proofs),
            'Inclusion summary overstates its proofs')
    require((covered['branches'], covered['pull_requests'], covered['upstream'],
             covered['retained_deleted_branches']) == (16, 249, 4, 9), 'Final-cutoff coverage changed')
    require(inclusion['target_gate_input_entries'] == manifests['final_entries'],
            'Inclusion input objects differ from the complete qualified source union')
    expected_full = delta['full_tree_changes']
    for key, expected_rows in (
        ('source_delta', expected_full),
        ('engine_delta', [row for row in expected_full if row['path'].startswith('packages/quds_office_engine/')]),
        ('gate_input_delta', [row for row in expected_full if row['in_baseline_gate_input_union']]),
        ('outside_gate_delta', delta['outside_input_changes']),
    ):
        require(inclusion[key]['changes'] == expected_rows and inclusion[key]['path_count'] == len(expected_rows),
                f'Inclusion {key} disagrees with independently hashed Git objects')
    old = read_json(EVIDENCE / 'integration/qualified-source-inclusion.json')
    require(old.get('target_commit') == BASELINE_COMMIT, 'Historical C9 inclusion was relabeled')
    historical_main = read_json(EVIDENCE / 'integration/final-main-review.json')
    require(historical_main['frozen_source']['commit'] == BASELINE_COMMIT,
            'Historical C9 prospective-main proof was relabeled')

    review_path = EVIDENCE / 'integration/final-cutoff-main-review.json'
    review = read_json(review_path)
    require(review.get('schema') == 'quds-vba-expansion-final-cutoff-main-review/v1'
            and review['qualified_source'] == {'commit': head, 'tree': tree}, 'Wrong final main-review target')
    main = review['included_main']['commit']
    captured_main = [row['sha'] for row in inventory['current_branches']
                     if row['ref'] == 'refs/remotes/origin/main']
    require(captured_main == [main] and ancestor(main, head)
            and review['included_main']['parents'] == git('show', '-s', '--format=%P', main).split()
            and review['included_main']['tree'] == git('rev-parse', main + '^{tree}')
            and review['ancestry']['included_main_is_ancestor_of_qualified'] is True
            and review['ancestry']['merge_base'] == git('merge-base', main, head) == main,
            'Captured main is not fully included in final source')
    prospective = review['prospective_merge']
    require(prospective['ordered_heads'] == [head, main] and prospective['exit_code'] == 0
            and prospective['conflicts'] == [] and prospective['tree'] == tree
            and prospective['changed_paths'] == [] and prospective['validated_input_differences'] == []
            and prospective['whole_tree_equal_to_qualified'] is True,
            'Captured included-main merge cannot be shown to preserve final source')
    basis = review['input_basis']
    require(basis['path'] == FINAL_INCLUSION.relative_to(REPO).as_posix()
            and basis['sha256'] == SNAPSHOTS[FINAL_INCLUSION]
            and basis['path_count'] == len(manifests['final_entries'])
            and basis['input_entries_sha256'] == compact_digest(manifests['final_entries'], True)
            and basis['manifest_union_sha256'] == compact_digest(manifests['final_source_hashes'], True),
            'Final main-review complete input basis differs')
    comparison = review['input_comparison']
    require(comparison['qualified_to_prospective_mismatch_count'] == 0
            and comparison['qualified_to_prospective_exact_mode_type_blob_sha256_matches']
            == len(manifests['final_entries']), 'Main-review input matching count differs')
    main_entries = git_tree_entries(main)
    direct = [{'path': path,
               'qualified': {key: value for key, value in entry.items() if key != 'sha256'},
               'included_main': main_entries.get(path)}
              for path, entry in manifests['final_entries'].items()
              if {key: value for key, value in entry.items() if key != 'sha256'} != main_entries.get(path)]
    require(comparison['included_main_direct_mismatches'] == direct,
            'Direct main snapshot mismatches were not recorded accurately')
    require(review.get('actual_final_main_merge_claimed') is False,
            'Pre-merge receipt must not claim an actual final merge')
    remote_ref = 'refs/remotes/origin/codex/word-powerpoint-vba-expansion-20261120'
    require(git('rev-parse', remote_ref) == head, 'Fetched remote checkpoint ref differs from final source')
    current_main = git('rev-parse', 'refs/remotes/origin/main')
    history = git('rev-list', '--first-parent', '--reverse', PREVIOUS_MAIN + '..' + head).splitlines()
    require(history[:len(CHECKPOINTS)] == CHECKPOINTS and history[-1] == head
            and len(history) >= len(CHECKPOINTS) + 2, 'Published checkpoint ancestry differs')
    checkpoints = [{'commit': commit, 'subject': git('show', '-s', '--format=%s', commit)} for commit in history]
    compact_inclusion = {
        'target_commit': head, 'target_tree': tree, 'cutoff_at_utc': inventory['cutoff_at_utc'],
        'receipt': FINAL_INCLUSION.relative_to(REPO).as_posix(), 'receipt_sha256': SNAPSHOTS[FINAL_INCLUSION],
        'inventory': inventory_path.relative_to(REPO).as_posix(), 'inventory_sha256': SNAPSHOTS[inventory_path],
        'summary': summary, 'required_new_heads': required, 'all_ancestry_and_historical_proofs_recomputed': True,
        'source_and_input_deltas_independently_recomputed': True,
        'historical_C9_inclusion_retained_separately': True, 'runtime_qualification_of_incoming_apps_claimed': False,
    }
    compact_main = {
        'qualified_commit': head, 'qualified_tree': tree,
        'included_cutoff_main': main, 'included_main_is_ancestor': True,
        'recorded_prospective_tree': tree, 'whole_tree_unchanged_for_captured_main': True,
        'complete_input_count': len(manifests['final_entries']),
        'exact_input_mode_type_blob_sha256_match': True,
        'review': review_path.relative_to(REPO).as_posix(), 'review_sha256': SNAPSHOTS[review_path],
        'locally_fetched_main_at_collection': current_main,
        'locally_fetched_main_is_ancestor_of_final': ancestor(current_main, head),
        'newer_main_needs_separate_review_before_merge': not ancestor(current_main, head),
        'remote_checkpoint_ref_checked_locally': remote_ref,
        'network_used': False, 'final_main_merge_claimed': False,
    }
    return compact_inclusion, compact_main, checkpoints


def check_environment(head: str, tree: str, plan: dict, acceptance: dict) -> dict:
    path = RESULTS / 'environment.json'
    environment = read_json(path)
    require(environment.get('shared_lock_versions_match') is True
            and environment.get('shared_resolved_package_count') == 56
            and len(environment.get('resolved_packages', {})) == 56
            and not environment.get('mismatches')
            and environment.get('package_manifests_match')
            and all(environment['package_manifests_match'].values()), 'Environment/dependency mismatch')
    require(environment.get('external_ci_used') is False, 'Environment claims unexpected CI use')
    configs = [REPO / '.dart_tool/package_config.json',
               ROOT / 'validation-workspace/.dart_tool/package_config.json']
    require(all(checksum(config) == environment['package_config_sha256'] for config in configs),
            'Canonical package configuration changed')
    require(checksum(ROOT / 'validation-workspace/pubspec.lock') == environment['resolved_lock_sha256']
            and checksum(REPO / 'pubspec.lock') == environment['root_lock_sha256'], 'Dependency lock changed')
    compiled = read_json(RESULTS / 'test-runner-compile-bounded.receipt.json')
    require(compiled.get('exit_code') == 0 and compiled.get('runner_sha256')
            == environment['test_runner_kernel_sha256']
            == checksum(ROOT / 'toolchains/test-runner/test-runner.dill'),
            'Precompiled runner is missing or differs')
    require(compiled['command'][1] == '--old_gen_heap_size=512'
            and compiled['command'][0].endswith('/dartaotruntime')
            and compiled['command'][2].endswith('/gen_kernel_aot.dart.snapshot'),
            'Runner compiler heap bound was not applied to the frontend VM')
    return {**environment,
            'historical_baseline_test_strategy': environment['test_strategy'],
            'test_strategy': (
                f"Scoped qualification: {len(plan['retained_files'])} unaffected files / "
                f"{acceptance['retained_passed']} cases retain complete baseline C9 evidence; "
                f"{len(plan['rerun_files'])} affected, guard and previously unrun files execute on final D "
                f"in {len(plan['rerun_groups'])} fresh serial processes under the bounded runner. "
                'Final static and six-example VM/JavaScript checks also execute on D. '
                'This is not a single-source 80-file execution.'),
            'final_static_portable_and_rerun_commit': head, 'final_tree': tree,
            'retained_case_commit': BASELINE_COMMIT, 'bounded_runner_compile': compiled,
            'runtime_binaries_archived': False, 'environment_source_sha256': SNAPSHOTS[path]}


def check_excluded_history() -> dict:
    cache_path = RESULTS / 'pre-cache-fix/expansion-shard04.receipt.json'
    failed_cache = read_json(cache_path)
    require(failed_cache.get('commit') == '89910ff6363cd45ced5faf0e48b11cac46754b28'
            and failed_cache.get('exit_code') == 1 and failed_cache.get('failed') == 1,
            'Original real cache-regression receipt is missing')
    interruption = read_json(RESULTS / 'pre-main-refresh/interruption.json')
    require(interruption.get('process_exit_code') == 130, 'Missing explicit main-refresh SIGINT record')
    inset_path = RESULTS / 'expansion-shard28.receipt.json'
    failed_inset = read_json(inset_path)
    require(failed_inset.get('commit') == BASELINE_COMMIT and failed_inset.get('exit_code') == 1
            and failed_inset.get('failed') == 1 and failed_inset.get('source_unchanged') is True,
            'Missing source-specific C9 multiline-replacement failure')
    raw = capture(RESULTS / 'expansion-shard28.jsonl')
    events = [json_load(line) for line in raw.splitlines() if line.strip()]
    starts = {event['test']['id']: event['test']['name'] for event in events if event['type'] == 'testStart'}
    failing = [event for event in events if event['type'] == 'testDone' and
               event.get('result') in ('failure', 'error') and not event.get('hidden')]
    require(len(failing) == 1 and 'multiline text replacement' in starts[failing[0]['testID']],
            'C9 group28 failed for a different case')
    require(not any(name in BASELINE_ACCEPTED_RAW for name in
                    [inset_path.relative_to(ROOT).as_posix(), 'validation-results/expansion-shard28.jsonl']),
            'Failed C9 group28 was accidentally accepted')
    return {
        'pre_cache_fix': {'receipt': cache_path.relative_to(ROOT).as_posix(),
                         'sha256': SNAPSHOTS[cache_path], 'included_in_accepted_total': False},
        'pre_main_refresh': {'interruption': interruption, 'included_in_accepted_total': False},
        'C9_group28': {
            'receipt': inset_path.relative_to(ROOT).as_posix(), 'sha256': SNAPSHOTS[inset_path],
            'jsonl': 'validation-results/expansion-shard28.jsonl', 'jsonl_sha256': sha_bytes(raw),
            'failed_case': starts[failing[0]['testID']], 'reported_prefix_passed': failed_inset['passed'],
            'all_group_cases_excluded': True, 'included_in_accepted_total': False,
            'reason': 'The entire unsuccessful group is excluded, including any passing prefix; final cases come from final-source reruns.',
        },
        'superseded_C9_passes': 'Passing baseline cases in rerun files are replaced by final-source evidence, never added twice.',
        'development_and_other_attempts': 'Preserved in the archive; excluded from accepted totals.',
        'cache_negative_and_fixed_controls': 'Supplemental source-specific reproduction; excluded from accepted totals.',
    }


def make_readme(head: str, tree: str, acceptance: dict, static: dict, portable: dict,
                environment: dict, examples: list[dict], checkpoints: list[dict],
                source: dict, delta: dict, rows: list[dict], archive: dict,
                inclusion: dict, main_proof: dict) -> str:
    retained_files = acceptance['retained_file_count']
    rerun_files = acceptance['rerun_file_count']
    rerun_groups = acceptance['completed_rerun_group_count']
    new_set = {'test/' + name + '.dart' for name in NEW_FILES}
    new_cases = sum(row['passed'] for row in rows if row['file'] in new_set)
    byte_equal = 'equal' if portable['vm_js_byte_equal'] else 'different'
    example_rows = '\n'.join(
        f'| [{Path(row["file"]).name}](../../../packages/quds_office_engine/{row["file"]}) | {row["operations"]} |'
        for row in examples)
    checkpoint_rows = '\n'.join('| `{}` | {} |'.format(row['commit'], row['subject'].replace('|', '\\|'))
                                for row in checkpoints)
    summary = inclusion['summary']
    return f'''# Word and PowerPoint VBA expansion: scoped local qualification

The reviewed 80-file selection has **{acceptance['passed']:,} accepted passing cases, zero failed and zero skipped cases**, with explicit source provenance. **{retained_files} unaffected files / {acceptance['retained_passed']:,} cases retain complete passing evidence from baseline `{BASELINE_COMMIT}` (C9). The other {rerun_files} files / {acceptance['rerun_passed']:,} cases passed in {rerun_groups} complete serial groups on final source `{head}` (D), tree `{tree}`.** Final static checks and all six actual-example VM/JavaScript executions also passed on D.

This is a scoped qualification combining reviewed baseline evidence with final-source reruns. It is **not an 80-file execution on one frozen source tree**. The initial C9 attempt stopped at a real regression in group 28. Its entire failed group, all superseded baseline passes, and every earlier attempt remain preserved and are excluded from the accepted total. This record qualifies the saved source checkpoint; it does not claim that the final merge to remote `main` has occurred.

## What changed

### Word typed formatting, reading order and line presets

The Word adapter accepts typed `Font` and `ParagraphFormat` selectors and required `ByVal` helper parameters, including named helper calls. `Paragraph.Format` selects the same paragraph target as the existing range path. `ReadingOrder` accepts exactly `wdReadingOrderRtl = 0` and `wdReadingOrderLtr = 1`, changes base direction independently of alignment, and writes an explicit override against inherited direction. `LineSpacingRule` accepts the single, one-and-a-half and double presets (`0`, `1`, `2`), persisted as native automatic multipliers `1`, `1.5`, `2` and DOCX line values `240`, `360`, `480`.

Sparse paragraph writes retain unrelated native XML and spacing metadata. A line-only write does not materialize inherited before/after spacing, and same-value assignments remain direct overrides. Namespace-qualified reads and writes keep foreign same-name attributes and elements opaque. Paragraph formatting can target empty paragraphs; font edits require existing nonempty text and exclude paragraph marks. This increment does not add live formatting reads, point-based `LineSpacing`, arbitrary multiples, or `Space1`/`Space15`/`Space2` methods. See the [Word compatibility guide](../../VBA_WORD_MACROS.md).

### PowerPoint text-frame margins and original-value preservation

`TextFrame.MarginLeft`, `MarginTop`, `MarginRight` and `MarginBottom` work through typed aliases, `With`, and helper targets. Values are finite nonnegative numbers in points whose conversion at 12,700 EMUs per point is exactly integral within `0..2147483647`; invalid precision, negative/out-of-range values, numeric Strings and Booleans are refused. A side write preserves the other sides, anchor, rich text, fields, hyperlinks, direction and autofit. Explicit zero and same-value native assignments write direct values; omitted sides remain absent.

The model and PDF path use the direct DrawingML inset rectangle, including unequal top/bottom margins and bounded overflow. Imported original inset values now form an immutable source baseline: untouched nondefault margins do not turn a direct plain-text replacement into an explicit rich-paragraph edit. Genuine direct model inset changes remain detectable, including a change back to the constructor default, and a same-value explicit native write retains its override intent. Three additional final-source cases cover these distinctions.

Tests retain unsaved rich-run formatting, zero-height autofit text, extension data, namespace ownership, layout bindings, and untouched malformed or unsupported native sides across repeated saves. Editor paint/hit-test code was updated and its tracked source is included in the static manifest, but Flutter execution was outside this gate. Layout/master inherited margins remain preserved in the package; their inherited values are **not resolved by the live margin projection**. This increment does not add `WordWrap`, `AutoSize`, text-direction edits, or margin getters. See the [PowerPoint guide](../../VBA_POWERPOINT_MACROS.md).

### Shared named and optional helper arguments

The Word, PowerPoint and Excel adapters share case-insensitive `name:=expression` helper arguments, positional arguments before named arguments, optional-position holes, and omitted optional scalar `ByVal` parameters. Supplied expressions execute once in written source order before binding to callee parameter order. Defaults are checked declaration-time constant expressions in module scope. Duplicate or unknown names, required omissions, invalid ordering and unsupported types are rejected even in unused helpers and unreachable branches.

Optional `Long`, `Double`, `String`, `Boolean` and scalar `Variant` parameters have the documented defaults. An omitted defaultless Variant has a distinct Missing state; `IsMissing` accepts the current helper's direct optional Variant formal. Explicit `Empty` and `Null` remain distinct, assignment clears Missing, and an ordinary unhandled Missing read is refused. This is bounded Missing behavior, not general Variant Error propagation. ByRef, array/ParamArray and optional object parameters, `Nothing` defaults, and named application-member/intrinsic arguments remain unsupported. Shared work/copy/call budgets and native transaction boundaries remain in force. See [the argument contract](../../VBA_ARGUMENTS.md) and [shared macro guide](../../VBA_MACROS.md).

## Accepted evidence and final reruns

| Check | Result and source |
| --- | --- |
| Accepted combined selection | {acceptance['passed']:,} cases across 80 distinct files; 0 failed; 0 skipped; split provenance below |
| Retained complete baseline evidence | {retained_files} files / {acceptance['retained_passed']:,} cases on C9; reviewed unchanged and outside the changed native paths |
| Final affected, guard and previously unrun files | {rerun_files} files / {acceptance['rerun_passed']:,} cases on D in {rerun_groups} complete groups |
| Newly selected files | 16 files / {new_cases:,} accepted cases, already included in the combined total; the other 64 files retain the prior selection |
| Final engine analysis | `dart analyze --fatal-infos`: exit 0 on D |
| Final formatting | {static['format_file_count']} relevant Dart files; `--output=none --set-exit-if-changed`: exit 0 on D |
| Actual examples | All six committed BAS files executed on Dart VM and compiled JavaScript on D |
| Cross-runtime semantics | Exact canonical JSON equality; no numeric tolerance |
| Raw VM/JavaScript JSON bytes | {byte_equal}; recorded separately from semantic equality |
| Final Word incremental/full geometry | 12 passing cases / 308 comparisons on D, derived from verified fixed source loops |
| Qualified source union | {source['file_count']:,} paths; exactly {delta['input_changed_count']} approved C9-to-D input changes, {delta['input_unchanged_count']:,} exactly unchanged inputs |

The [acceptance receipt](runtime/acceptance.json), [complete per-file case provenance](runtime/per-file.json), [reviewed scoped plan](runtime/scoped-plan.json), [final group plan](runtime/scoped-shards.json), [source manifests](runtime/source-manifests.json), and [exact source delta](runtime/source-delta.json) make the split reviewable. Every retained file refers to its original complete passing C9 group, raw JSONL checksum, case-name multiset and source hash. Every rerun file refers to its final D group. An original group can contain both retained and superseded files; only its explicitly retained files contribute C9 cases.

The collector independently re-derives all visible case counts, requires one complete successful runner ending, complete selected-suite coverage, matching declared root test counts, and a completion for every started test. Hidden loading/setup events are checked for success and excluded from totals. Cases are identified by `(file, full test name, occurrence ordinal per name)`: the pre-existing duplicate full name in the slide-format suite represents two legitimate tests, both retained in the counts. The partition is disjoint and full-name multiplicities are preserved. The final rerun process durations sum to {acceptance['duration_seconds_rerun']:.3f} seconds; this is not total session wall time or baseline execution time.

The reviewed impact decision reruns all selected PML consumers, the affected Word-layout consumers, native VBA integration, shared runtime/CLI/MCP and PDF guards, and the files from the failed or unrun tail. The two changed test files each add exactly three cases. Retained files keep their original C9 provenance; source review is a qualification decision, not a new execution. The complete reasons are in the scoped plan.

Test, static and portable capture domains intentionally differ. The test gate includes editor fonts and manifests; static capture includes the entire engine package plus the touched editor renderer; portable capture includes compiler/runtime sources. Hashes agree on all overlaps within each commit, all completed baseline groups share one baseline manifest, and all final groups share one final manifest. Each manifest is independently checked against its commit's Git blobs. The complete final union is also checked against disk and HEAD. The exact eight approved changes include the PML baseline repair, its three cases, Word layout owner/fallback and empty-cache guards, its three cases, the research acceptance registration, and the changelog. The C9 prefix-slice checkpoint guards remain present. No change to the shared VBA language implementation is hidden by this qualification split.

## Actual BAS inputs and native persistence

| Committed example | Native operations |
| --- | ---: |
{example_rows}

The driver receives the exact source bytes via six base64 compiler defines; the collector independently checks both VM and JavaScript compiler arguments against the committed files and their SHA-256 hashes. Detached validation leaves the caller input and revision unchanged. Execution publishes one native transaction, verifies intended and untouched content, and checks additional native save/reopen cycles. The combined driver also exercises exact one-EMU and signed-Long-maximum positive-EMU margin boundaries (`1` and `2147483647`) through actual PPTX serialization. Helper coverage includes source-order effects, Missing/refusal behavior and late native failure rollback.

The prior typography/slideshow pair checks one additional save/reopen; the helper and new paragraph/margin examples each check two additional native save/reopens. The examples use generated fixture documents with existing body paragraphs or named Title shapes; they do not create those application targets implicitly.

Cross-runtime comparison parses each complete JSON output, recursively converts only integral floating-point numbers to integers, then serializes with sorted keys, UTF-8 strings and compact separators. Boolean and String types remain distinct; non-finite values are forbidden; fractional numeric values receive no tolerance. Python Boolean-versus-integer equality is not used as the comparison. The [canonical bytes](runtime/portable-canonical.json) and SHA-256 hashes of both raw outputs are retained. Integral floating-point spelling can differ between the raw runtime outputs; canonical semantic equality is the accepted claim. ZIP container bytes are not compared across runtimes.

## Real regressions, repairs and preserved historical evidence

The pre-cache-fix integrated source `89910ff6` produced a real differential failure at seed 7, structures enabled, edit 44. A paragraph edited while frame wrapping was active retained stale unwrapped line breaks; later flow changes could make the old cache readable again. The repair invalidates old breaks at paragraph entry when the block is not proven clean, including early-return and cache-bypass paths. The old-source negative control records **two failed focused cases**, followed by **two passing focused cases** on the recorded repaired source. These [supplemental controls](runtime/cache-reproduction.json) retain their actual old/fixed production hashes and are **not added** to the accepted total or relabeled as D execution.

The final D differential rerun preserves the original 302 fresh-engine comparisons: 10 convergence comparisons, six deterministic 48-edit sequences (288), two note fallbacks and two discarded-state/section-list comparisons. Two text/font frame-edit cases add three comparisons each, producing 12 cases and 308 comparisons. The [source-derived proof](runtime/differential.json) binds fixed loop bounds to the final passing test-file hash; 308 is not a runtime counter emitted by package:test. Geometry uses pure Dart null-font fallback metrics, without installed Word or Flutter font-metric comparison. Final incoming layout work additionally binds incremental state to its owning engine, falls back for cross-engine state, and retires empty-paragraph caches; affected selected layout files were rerun on D.

C9 group 28 then exposed a separate legacy multiline text-replacement regression. Imported nondefault text margins were incorrectly treated as a new inset edit, causing `resolvedRichText` to synthesize paragraphs for a plain-text replacement. The original receipt and raw failure are retained in the archive. The final immutable source-inset baseline repair preserves the legacy plain-text fallback while retaining genuine direct and explicit native margin edits. The legacy fidelity suite, new inset regressions and selected native/PDF consumers all contribute only final D evidence. No passing prefix from failed C9 group 28 is counted.

## Incoming work, final cutoff and saved checkpoints

The [final-cutoff reconciliation](integration/final-cutoff-reconciliation.md) and [inclusion proof](integration/final-cutoff-inclusion.json) account for the captured **{summary['branch_count']} current branch refs, {summary['pr_count']} PR heads and {summary['upstream_count']} upstream heads**, plus **{summary['retained_deleted_branch_count']} deleted earlier branch refs** and the recorded previous heads of advancing refs. Current PR heads resolve as {summary['prs']['ancestor']} ancestors and {summary['prs']['historically_superseded_equivalent']} verified historical equivalents; all four upstream heads are ancestors. The collector recomputes the 14 historical changed-path proofs; 13 also have complete-tree identity. The four explicitly required incoming heads, including captured main `{main_proof['included_cutoff_main']}`, are ancestors of D. Earlier C9 inclusion and main-review receipts remain separate historical records.

The complete C9-to-D tree delta has {delta['full_tree_change_count']} paths: {delta['input_changed_count']} approved engine input changes and {len(delta['outside_input_changes'])} paths outside the qualified input union. Each changed path records mode, object type, Git object identity and SHA-256. Incoming Mail/account, Outbox, desktop/editor and documentation integration is included in the history and audit; this source-object accounting does not claim new Flutter, Outbox, keychain or mail-provider runtime execution.

The [captured-main review](integration/final-cutoff-main-review.json) compares D with the prospective merge of D and the already included captured main. That prospective tree is exactly D, so all {source['file_count']:,} qualified input entries are preserved. A direct snapshot comparison between D and captured main is a different comparison and retains its recorded differences. The [compact checked main proof](runtime/main-proof.json) also records the locally fetched main ref at collection and whether a newer head needs separate review. This is a pre-merge source-preservation check, not an actual final-merge receipt. Any subsequent main advance or evidence commit needs a corresponding final consistency check.

The published first-parent checkpoints are preserved below with actual remote-history identities. The collector checks their ancestry and the already fetched remote checkpoint ref without fetching or querying GitHub.

| Published checkpoint | Purpose |
| --- | --- |
{checkpoint_rows}

## Runtime, evidence and reproduction

The environment uses Dart **3.13.7**, package:test **{environment['resolved_packages']['test']}**, test_core **{environment['resolved_packages']['test_core']}**, and Node **{environment['host_node']}**. The 56 shared hosted package versions match the repository lockfile. A standalone pure-Dart workspace provides unchanged engine/legacy/example manifests and a canonical package configuration. [Environment metadata](runtime/environment.json) records SDK archive, dependency lock, package configuration and precompiled runner checksums.

The unmodified package:test runner was compiled to kernel using the installed SDK's `gen_kernel_aot.dart.snapshot` under `dartaotruntime --old_gen_heap_size=512`. Its `.dill` runs under the normal Dart VM with the same old-generation bound, `--compiler source --concurrency=1 --timeout=4x --fail-fast`. The final {rerun_groups} fresh processes avoid accumulated runner/compiler state; process-spawning integration files are isolated. This old-generation bound is not a process RSS cap and is not forwarded to independent CLI/MCP subprocesses or the normal JavaScript compiler. The archived bounded-compile receipt preserves the exact successful compiler command and runner checksum.

The [evidence archive](runtime/acceptance-evidence.tar.gz) contains {archive['member_count']} indexed raw evidence/configuration/source members plus its internal index, including every regular file under `validation-results`, the selected root development logs, exact collection/validation/intake drivers, plan, and source-specific integration records. The [archive index](runtime/archive-index.json) records classification, byte count and SHA-256 for every member. [Checksums](runtime/SHA256SUMS) cover compact outputs and the archive. SDK/pub-cache binaries, compiled JavaScript/kernel binaries, and large generated Office fixtures are omitted.

The archive retains the original cache failure, C9 group28 failure, interrupted pre-main-refresh run, startup SIGKILL attempts, failed normal kernel-wrapper compilation, setup attempts and development results. A raw successful original group may contain cases that are superseded in the final aggregate; per-file provenance determines which original cases are retained. Earlier static/portable checks are historical and are replaced by final scoped checks. Historical controls, development runs, failed groups and superseded cases never inflate the accepted total. The earlier 10-case/302-comparison receipt remains labeled as historical.

To reproduce the final cohort, restore the recorded SDK/dependencies, adapt archived scratch-root paths, and use the pinned `scoped-qualification-plan.json` with `run_scoped_expansion.py` after final scoped static and portable checks. The archived baseline raw evidence is required to reconstruct retained cases; a fresh all-80-files D run would be a separate stronger execution claim. The collector refuses incomplete groups, missing or duplicate runtime IDs, uncompleted declared cases, skipped/failing accepted cases, source mismatches, stale HEAD, unreviewed source deltas or missing historical failure evidence. Collection performs no tests, compiler, analyzer, network, CI, merge or remote mutation.

## Qualification limits

GitHub Actions was neither queried nor awaited. The checks cover the bounded, explicitly invoked VBA source-to-native-plan adapter, native macro/CLI/MCP behavior and engine persistence. Embedded VBA projects remain preserved and inert; full VBA execution, COM, events and a VBA editor remain outside this increment. Flutter UI/controller execution, installed Microsoft Word/PowerPoint, platform keychains, native signing and live mail providers were not executed here. Incoming application source inclusion and historical incoming runtime evidence remain separate from this scoped Office engine qualification.
'''


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, default=PLAN_PATH)
    parser.add_argument('--expected-head')
    parser.add_argument('--output', type=Path, default=EVIDENCE / 'runtime')
    parser.add_argument('--readme', type=Path, default=EVIDENCE / 'README.md')
    args = parser.parse_args()
    require(args.plan.resolve() == PLAN_PATH, 'Use the reviewed named scoped plan')
    require(not args.output.exists() and not args.readme.exists(),
            'Evidence destination already exists; review it or choose separate output paths')
    for target in (args.output, args.readme):
        require(target.resolve().is_relative_to(ROOT), 'Destination must remain in this workspace')
    plan = read_json(args.plan)
    head = git('rev-parse', 'HEAD')
    require(args.expected_head in (None, head), 'Checkout differs from requested final commit')
    tree = git('rev-parse', head + '^{tree}')
    selection, retained, rerun, groups = check_plan(plan, head)
    require(plan['final_tree'] == tree, 'Final source tree differs from plan')
    rows, baseline_gate, final_gate, provenance = collect_cases(plan, head, selection, retained, rerun, groups)
    acceptance = check_aggregate(plan, rows, provenance, baseline_gate, final_gate, args.plan)
    static_path = RESULTS / 'scoped-static.receipt.json'
    portable_path = RESULTS / 'scoped-portable.receipt.json'
    static = read_json(static_path)
    portable_raw = read_json(portable_path)
    portable, examples = check_portable(portable_raw, head, tree)
    baseline_static = read_json(RESULTS / 'expansion-final-static.receipt.json')
    baseline_portable = read_json(RESULTS / 'expansion-portable.receipt.json')
    require(baseline_portable.get('commit') == BASELINE_COMMIT
            and baseline_portable.get('source_unchanged') is True
            and baseline_portable.get('commands_passed') is True,
            'Baseline portable manifest does not belong to the successful C9 stage')
    baseline_manifests = {
        'test_gate': baseline_gate,
        'static': check_static(baseline_static, BASELINE_COMMIT, 'historical-baseline-static'),
        'portable': check_manifest(baseline_portable, PORTABLE_PATHS, 'historical-baseline-portable', BASELINE_COMMIT),
    }
    final_manifests = {
        'test_gate': final_gate,
        'static': check_static(static, head, 'final-scoped-static'),
        'portable': check_manifest(portable_raw, PORTABLE_PATHS, 'final-scoped-portable', head),
    }
    source, delta, final_hashes = check_source_delta(plan, baseline_manifests, final_manifests, retained, head)
    require(plan['validated_input_count'] == source['file_count'], 'Planned input union count differs')
    for path in [static_path, portable_path, RESULTS / 'scoped-format.log', RESULTS / 'scoped-analyze.log',
                 RESULTS / 'scoped-portable-vm.stdout', RESULTS / 'scoped-portable-javascript.stdout',
                 RESULTS / 'scoped-portable-canonical.json']:
        capture(path)
        FINAL_ACCEPTED_RAW.add(path.relative_to(ROOT).as_posix())
    environment = check_environment(head, tree, plan, acceptance)
    differential = check_differential({row['file']: row for row in rows})
    require(differential['execution_source_commit'] == head
            and differential['execution_source_kind'] == 'rerun_final',
            'Differential proof must be tied to a final D execution')
    cache = check_cache_reproduction(head)
    excluded = check_excluded_history()
    inclusion, main_proof, checkpoints = check_inclusion(plan, head, tree, source, delta)
    total = sum(row['passed'] for row in rows)
    acceptance_compact = {**strip_hashes(acceptance),
                          'raw_events_independently_recounted': True,
                          'source_manifests': 'source-manifests.json', 'source_delta': 'source-delta.json',
                          'per_file_case_provenance': 'per-file.json', 'all_started_and_declared_cases_completed': True,
                          'case_identity': provenance['case_identity'],
                          'case_identity_sha256': provenance['case_identity_sha256'],
                          'retention_note': DELTA_NOTE}
    per_file = {
        'schema': 'quds-vba-expansion-scoped-case-provenance/v1',
        'baseline_commit': BASELINE_COMMIT, 'final_commit': head,
        'file_count': len(rows), 'passed': total, 'failed': 0, 'skipped': 0,
        'counting': 'Visible completed cases in disjoint files; duplicate full names retain occurrence multiplicity; hidden setup/loading events excluded.',
        'case_identity': provenance['case_identity'], 'case_identity_sha256': provenance['case_identity_sha256'],
        'selection_sha256': SNAPSHOTS[RESULTS / 'expansion-selection.json'], 'files': rows,
    }
    metadata = {
        'schema': 'quds-vba-expansion-scoped-collection/v1',
        'collected_at_utc': datetime.now(timezone.utc).isoformat(),
        'baseline_commit': BASELINE_COMMIT, 'final_commit': head, 'final_tree': tree,
        'collector_sha256': checksum(Path(__file__).resolve()),
        'reviewed_plan_sha256': SNAPSHOTS[args.plan], 'network_used': False,
        'github_actions_queried_or_awaited': False, 'single_source_full_rerun_claimed': False,
        'final_main_merge_claimed': False, 'checkpoints': checkpoints,
        'cohort_provenance': provenance, 'intake_summary': inclusion['summary'],
        'excluded_attempts': excluded, 'development_patterns': DEVELOPMENT_PATTERNS,
        'historical_evidence_collector_preserved': 'drivers/collect_expansion_evidence.py',
    }
    members, result_names = archive_inputs(selection)
    with tempfile.TemporaryDirectory(prefix='scoped-expansion-evidence-stage-', dir=ROOT) as temporary:
        stage = Path(temporary)
        runtime = stage / 'runtime'
        runtime.mkdir()
        archive = write_archive(runtime / 'acceptance-evidence.tar.gz', members)
        outputs = {
            'acceptance.json': acceptance_compact, 'per-file.json': per_file,
            'selection.json': selection, 'scoped-plan.json': plan, 'scoped-shards.json': groups,
            'source-manifests.json': source, 'source-delta.json': delta,
            'environment.json': environment, 'static.json': strip_hashes(static),
            'portable.json': portable, 'cache-reproduction.json': cache,
            'differential.json': differential, 'excluded-history.json': excluded,
            'inclusion.json': inclusion, 'main-proof.json': main_proof,
            'collection.json': metadata, 'archive-index.json': archive,
        }
        for name, value in outputs.items():
            (runtime / name).write_bytes(pretty(value))
        (runtime / 'portable-canonical.json').write_bytes(capture(RESULTS / 'scoped-portable-canonical.json'))
        readme = make_readme(head, tree, acceptance, static, portable, environment,
                             examples, checkpoints, source, delta, rows, archive, inclusion, main_proof)
        (stage / 'README.md').write_text(readme, encoding='utf-8')
        (runtime / 'README.md').write_text(
            '# Runtime evidence\n\nSee the [qualification report](../README.md). '
            'Accepted cases combine the reviewed retained C9 files and final D reruns, '
            'with disjoint per-file provenance. This is not one same-source 80-file run. '
            'Failed, superseded and development evidence remains preserved and classified in `archive-index.json`.\n',
            encoding='utf-8')
        checksums = [(path.name, checksum(path)) for path in sorted(runtime.iterdir()) if path.is_file()]
        checksums.append(('../README.md', checksum(stage / 'README.md')))
        (runtime / 'SHA256SUMS').write_text(''.join(digest + '  ' + name + '\n' for name, digest in checksums))
        current_results = {path.relative_to(ROOT).as_posix() for path in RESULTS.rglob('*') if path.is_file()}
        require(current_results == result_names, 'validation-results files changed while collecting')
        for path, digest in SNAPSHOTS.items():
            require(checksum(path) == digest, f'Evidence changed during collection: {path}')
        check_current_sources(head, final_hashes)
        require(not args.output.exists() and not args.readme.exists(), 'Destination appeared while collecting')
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.readme.parent.mkdir(parents=True, exist_ok=True)
        os.replace(runtime, args.output)
        os.replace(stage / 'README.md', args.readme)
    print(json.dumps({'baseline_commit': BASELINE_COMMIT, 'final_commit': head,
                      'passed': total, 'files': len(rows), 'retained_files': len(retained),
                      'rerun_files': len(rerun), 'rerun_groups': len(groups),
                      'source_files': len(final_hashes), 'approved_input_changes': len(delta['approved_input_changes']),
                      'archive_members': archive['member_count'], 'archive_bytes': archive['archive_bytes'],
                      'archive_sha256': archive['archive_sha256'],
                      'runtime': str(args.output), 'readme': str(args.readme)}, indent=2))


if __name__ == '__main__':
    main()


