import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/workspace/scratch/f0616b02624b')
repo = root / 'quds_office_suite'
out = root / 'validation-results'
old = '89910ff6363cd45ced5faf0e48b11cac46754b28'
paths = [
    'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
    'packages/quds_office_engine/lib/src/word/layout/word_incremental_layout.dart',
]
saved = {p: (repo / p).read_bytes() for p in paths}
backup = root / 'toolchains/cache-fix-backup'
backup.mkdir(exist_ok=True)
for p, content in saved.items():
    (backup / Path(p).name).write_bytes(content)
env = os.environ.copy()
env.update(VBA_TEST_CONCURRENCY='1', VBA_TEST_FAIL_FAST='0', VBA_DART_HEAP_MB='512',
           VBA_TEST_FILTER='edits while wrapping invalidate older unwrapped breaks',
           VBA_TEST_RUNNER=str(root / 'toolchains/test-runner/test-runner.dill'))
test = 'test/word_incremental_layout_differential_test.dart'
def run(label):
    with (out / (label + '.driver.log')).open('w') as log:
        result = subprocess.run([sys.executable, str(root / 'run_vba_validation.py'), label, test],
                                env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt = json.loads((out / (label + '.receipt.json')).read_text())
    print(json.dumps({'label': label, 'process_exit': result.returncode,
                      **{k: receipt[k] for k in ['exit_code', 'passed', 'failed', 'skipped', 'source_unchanged']}}), flush=True)
    return receipt

try:
    for p in paths:
        (repo / p).write_bytes(subprocess.check_output(['git', '-C', str(repo), 'show', old + ':' + p]))
    negative = run('cache-invalidation-negative-control')
finally:
    for p, content in saved.items():
        (repo / p).write_bytes(content)
assert all((repo / p).read_bytes() == content for p, content in saved.items())
assert negative['exit_code'] == 1 and negative['failed'] == 2 and negative['passed'] == 0
assert negative['source_unchanged'] and negative['runner_done']
assert all('incremental/full geometry differs' in e['error'] for e in negative['errors'])
positive = run('cache-invalidation-fixed')
assert positive['exit_code'] == 0 and positive['passed'] == 2 and positive['failed'] == 0
assert positive['source_unchanged'] and positive['runner_done']
receipt = dict(old_production_commit=old,
               fixed_commit=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
               old_failed_cases=2, fixed_passed_cases=2, restored_sources=True,
               fixed_source_sha256={p: hashlib.sha256(content).hexdigest() for p, content in saved.items()})
(out / 'cache-invalidation-reproduction.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
