    // @dart=3.12

    import 'dart:isolate';

    import 'package:test_core/src/bootstrap/vm.dart';

    import 'file:///workspace/scratch/f0616b02624b/word_incremental_layout_differential_test.dart' as test;

    // This variable is read at runtime through the VM service and is unsafe to
    // remove.
    const packageConfigLocation = 'file:///workspace/scratch/f0616b02624b/validation-workspace/.dart_tool/package_config.json';

    void main(_, SendPort sendPort) {
      internalBootstrapVmTest(() => test.main, sendPort);
    }
  