#!/usr/bin/env python3
"""Run the reviewed final-source cohort and retain explicit C9 provenance.

This file is a driver, not an already executed validation result. Its default
plan must first be pinned to a committed final source. It refuses dirty tracked
inputs, unreviewed input deltas, incomplete baseline evidence and stale output.
No network/CI operations or repository source edits are performed.
"""

from __future__ import annotations

import hashlib
import json
import os
from collections import Counter
from pathlib import Path
import re
import subprocess
import sys
import tempfile

ROOT = Path('/workspace/scratch/f0616b02624b')
REPO = ROOT / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
OUT = ROOT / 'validation-results'
PLAN = ROOT / 'scoped-qualification-plan.json'
BASELINE = 'c9cbeb1248d6b5f088d1084a8c113a743aa7a77f'
INPUT_PREFIXES = [
    'packages/quds_office_engine',
    'packages/quds_office_editor/fonts',
    'packages/quds_office_editor/lib/src/editor_slide/render_slide_stage.dart',
    'packages/legacy_doc_parser/lib',
    'packages/legacy_doc_parser/pubspec.yaml',
    'pubspec.lock',
]
GATE_PREFIXES = [
    'packages/quds_office_engine/lib', 'packages/quds_office_engine/test',
    'packages/quds_office_engine/tool', 'packages/quds_office_engine/example/macros',
    'packages/quds_office_editor/fonts', 'packages/legacy_doc_parser/lib',
    'packages/quds_office_engine/pubspec.yaml', 'packages/legacy_doc_parser/pubspec.yaml',
    'pubspec.lock',
]
REVIEWED_DELTA = {
    'packages/quds_office_engine/CHANGELOG.md',
    'packages/quds_office_engine/lib/src/slide/model/pml_presentation.dart',
    'packages/quds_office_engine/lib/src/slide/shapes/drawingml.dart',
    'packages/quds_office_engine/test/slide_text_insets_preservation_test.dart',
    'packages/quds_office_engine/lib/src/word/layout/word_incremental_layout.dart',
    'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
    'packages/quds_office_engine/test/word_incremental_layout_test.dart',
    'packages/quds_office_engine/tool/zotero/research_target_acceptance.dart',
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def case_digest(names):
    return digest(canonical(sorted(names)))


def load(path):
    require(path.is_file(), f'Missing evidence: {path}')
    return json.loads(path.read_bytes())


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def tree_entries(revision):
    raw = subprocess.check_output(['git', '-C', str(REPO), 'ls-tree', '-r', '-z', '--full-tree', revision])
    result = {}
    for record in raw.split(b'\0'):
        if not record:
            continue
        description, name = record.split(b'\t', 1)
        mode, kind, oid = description.decode('ascii').split()
        path = name.decode('utf-8')
        if any(path == prefix or path.startswith(prefix + '/') for prefix in INPUT_PREFIXES):
            result[path] = {'mode': mode, 'type': kind, 'object': oid}
    return result


def enriched(entry):
    if entry is None:
        return None
    require(entry['type'] == 'blob', 'Only ordinary source blobs are expected in the approved delta')
    content = subprocess.check_output(['git', '-C', str(REPO), 'cat-file', 'blob', entry['object']])
    return {**entry, 'sha256': digest(content)}


def check_source_scope(plan):
    final = plan.get('final_commit')
    require(isinstance(final, str) and re.fullmatch(r'[0-9a-f]{40}', final),
            'Pin plan.final_commit to the published repaired source before running')
    require(final != BASELINE and git('rev-parse', 'HEAD') == final,
            'Current HEAD must equal the pinned repaired source')
    require(subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', BASELINE, final],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0,
            'Repaired source must retain C9 ancestry')
    require(not git('diff', '--name-only', 'HEAD', '--', *INPUT_PREFIXES),
            'Tracked validation inputs are dirty; freeze them before running')
    before, after = tree_entries(BASELINE), tree_entries(final)
    require(len(before) == len(after) == plan['validated_input_count'] == 1164,
            'Validation-input universe changed; revisit the impact plan')
    changes = [{'path': path, 'before': enriched(before.get(path)), 'after': enriched(after.get(path))}
               for path in sorted(set(before) | set(after)) if before.get(path) != after.get(path)]
    require({item['path'] for item in changes} == REVIEWED_DELTA,
            'Input delta exceeds or differs from the eight reviewed files')
    require(changes == plan.get('approved_source_delta'),
            'Final Git mode/type/blob/SHA-256 delta differs from the reviewed plan')
    for item in plan['retained_files']:
        path = 'packages/quds_office_engine/' + item['file']
        require(before.get(path) == after.get(path), 'Retained test source changed: ' + path)
    paths = git('ls-files', '--', *GATE_PREFIXES).splitlines()
    hashes = {path: digest((REPO / path).read_bytes()) for path in paths}
    return final, changes, hashes


def parse_events(path, files):
    events = [json.loads(line) for line in path.read_bytes().splitlines()]
    require(events and events[0].get('type') == 'start', 'Missing runner start: ' + str(path))
    require(sum(event.get('type') == 'start' for event in events) == 1, 'Multiple runs in ' + str(path))
    done = [event for event in events if event.get('type') == 'done']
    require(len(done) == 1 and events[-1] == done[0] and done[0].get('success') is True,
            'Incomplete or failing runner: ' + str(path))
    require(not any(event.get('type') == 'error' for event in events), 'Runner error in ' + str(path))
    suites, declared, starts, finished = {}, {}, {}, {}
    for event in events:
        kind = event.get('type')
        if kind == 'suite':
            suite = event['suite']
            require(suite['id'] not in suites and suite['platform'] == 'vm', 'Duplicate/non-VM suite')
            value = Path(suite['path'])
            suites[suite['id']] = (value.relative_to(ENGINE) if value.is_absolute() else value).as_posix()
        elif kind == 'group' and event['group'].get('parentID') is None:
            group = event['group']
            require(group['suiteID'] not in declared and type(group['testCount']) is int
                    and group['testCount'] >= 0, 'Invalid root group count')
            declared[group['suiteID']] = group['testCount']
        elif kind == 'testStart':
            test = event['test']
            require(test['id'] not in starts, 'Duplicate test ID')
            starts[test['id']] = test
        elif kind == 'testDone':
            require(event['testID'] not in finished, 'Duplicate completion')
            require(event.get('result') == 'success' and event.get('skipped') is False
                    and type(event.get('hidden')) is bool, 'Failed/skipped/incomplete case')
            finished[event['testID']] = event
    require(len(suites) == len(files) and set(suites.values()) == set(files), 'Wrong suite coverage')
    require(set(declared) == set(suites) and set(starts) == set(finished), 'Incomplete suite/case declaration')
    all_suites = [event for event in events if event.get('type') == 'allSuites']
    require(len(all_suites) == 1 and all_suites[0]['count'] == len(files), 'Wrong allSuites count')
    result = {}
    for identifier, file in suites.items():
        names = [starts[key]['name'] for key, event in finished.items()
                 if starts[key]['suiteID'] == identifier and not event['hidden']]
        require(len(names) == declared[identifier] and names, 'Declared cases did not all run: ' + file)
        # Distinct registered tests can share a display name. Keep multiplicity;
        # identity is (file, full name, occurrence ordinal), never a name set.
        result[file] = {'passed': len(names), 'failed': 0, 'skipped': 0,
                        'declared_cases': declared[identifier], 'case_names': names,
                        'case_names_sha256': case_digest(names)}
    return result, done


def check_receipt(receipt_path, jsonl_path, files, commit, hashes=None):
    receipt = load(receipt_path)
    require(receipt.get('commit') == commit and receipt.get('exit_code') == 0
            and receipt.get('source_unchanged') is True and receipt.get('failed') == 0
            and receipt.get('skipped') == 0, 'Nonpassing or wrong-source receipt: ' + str(receipt_path))
    require(receipt['command'][-len(files):] == files and receipt['cwd'] == str(ENGINE),
            'Receipt command/cwd differs from planned coverage')
    require('--name' not in receipt['command'] and '-n' not in receipt['command'], 'Filtered runs cannot qualify files')
    if hashes is not None:
        require(receipt['source_hashes'] == hashes, 'Source manifest differs: ' + str(receipt_path))
    parsed, done = parse_events(jsonl_path, files)
    require(receipt['passed'] == sum(item['passed'] for item in parsed.values())
            and receipt['runner_done'] == done and not receipt.get('errors'), 'Receipt/raw events disagree')
    return receipt, parsed


def per_file_row(item, parsed, source_kind, commit, group, receipt, jsonl):
    return {'file': item['file'], 'source_kind': source_kind, 'source_commit': commit,
            'source_group': group, 'receipt': receipt, 'jsonl': jsonl,
            'passed': parsed['passed'], 'failed': 0, 'skipped': 0,
            'declared_cases': parsed['declared_cases'], 'case_names_sha256': parsed['case_names_sha256'],
            'test_source_sha256': item['test_source_sha256']}


def main():
    plan_bytes = PLAN.read_bytes()
    plan = json.loads(plan_bytes)
    require(plan.get('baseline_commit') == BASELINE, 'Unexpected baseline commit')
    selection = plan['selection']
    retained = plan['retained_files']
    rerun = plan['rerun_files']
    groups = plan['rerun_groups']
    require(len(selection) == len(set(selection)) == 80 and len(retained) == 42 and len(rerun) == 38,
            'Expected reviewed 80-file, 42-retained/38-rerun partition')
    require({item['file'] for item in retained}.isdisjoint(item['file'] for item in rerun)
            and {item['file'] for item in retained + rerun} == set(selection), 'Partition overlaps or omits files')
    flattened = [file for group in groups for file in group['files']]
    require(len(flattened) == len(set(flattened)) == 38
            and set(flattened) == {item['file'] for item in rerun}, 'Rerun groups overlap or omit files')
    require([group['label'] for group in groups] == [f'scoped-shard{i:02d}' for i in range(1, len(groups) + 1)],
            'Unexpected output labels')
    for group in groups:
        require(1 <= len(group['files']) <= 4, 'Groups must contain at most four files')
        for file in group['files']:
            require(file.startswith('test/') and '..' not in Path(file).parts, 'Unsafe test path')
            text = (ENGINE / file).read_text()
            isolated = bool(re.search(r'\bProcess\.(?:start|run|runSync)\b', text)) or '_cli_test.' in file or '_mcp_test.' in file
            require(not isolated or len(group['files']) == 1, 'CLI/MCP/process-spawning file must run alone')
    final, delta, final_hashes = check_source_scope(plan)
    baseline_plan = load(OUT / 'expansion-shards.json')
    original_groups = {group['label']: group['files'] for group in baseline_plan}
    rows, retained_groups = {}, []
    baseline_hashes = None
    for label in sorted({item['source_group'] for item in retained}):
        require(label != 'expansion-shard28', 'Failed group 28 is excluded in its entirety')
        members = [item for item in retained if item['source_group'] == label]
        first = members[0]
        receipt_path, jsonl_path = ROOT / first['receipt'], ROOT / first['jsonl']
        require(all(item['receipt'] == first['receipt'] and item['jsonl'] == first['jsonl'] for item in members),
                'Inconsistent baseline provenance')
        require(digest(receipt_path.read_bytes()) == first['receipt_sha256']
                and digest(jsonl_path.read_bytes()) == first['jsonl_sha256'], 'Baseline evidence changed')
        receipt, parsed = check_receipt(receipt_path, jsonl_path, original_groups[label], BASELINE, baseline_hashes)
        if baseline_hashes is None:
            baseline_hashes = receipt['source_hashes']
        for item in members:
            file = item['file']
            source = 'packages/quds_office_engine/' + file
            require(parsed[file]['passed'] == item['passed'] and parsed[file]['case_names_sha256'] == item['case_names_sha256']
                    and Counter(parsed[file]['case_names']) == Counter(item['case_names']), 'Retained cases differ: ' + file)
            require(receipt['source_hashes'][source] == item['test_source_sha256'] == final_hashes[source],
                    'Retained test bytes changed: ' + file)
            rows[file] = per_file_row(item, parsed[file], 'retained_baseline', BASELINE,
                                      label, first['receipt'], first['jsonl'])
        retained_groups.append({'source_group': label, 'source_commit': BASELINE,
                                'files': [item['file'] for item in members],
                                'passed': sum(parsed[item['file']]['passed'] for item in members),
                                'receipt': first['receipt'], 'jsonl': first['jsonl'],
                                'receipt_sha256': first['receipt_sha256'], 'jsonl_sha256': first['jsonl_sha256'],
                                'full_original_group_passed': receipt['passed'],
                                'only_listed_files_counted': True})
    retained_passed = sum(row['passed'] for row in rows.values())
    require(retained_passed == plan['baseline_retained_passed'] == 1808, 'Retained baseline count differs')
    env = os.environ.copy()
    env.pop('VBA_TEST_FILTER', None)
    env.update(VBA_TEST_CONCURRENCY='1', VBA_TEST_FAIL_FAST='1', VBA_DART_HEAP_MB='512',
               VBA_TEST_RUNNER=str(ROOT / 'toolchains/test-runner/test-runner.dill'))
    require(Path(env['VBA_TEST_RUNNER']).is_file(), 'Pinned precompiled runner is missing')
    rerun_by_file = {item['file']: item for item in rerun}
    run_groups = []
    for group in groups:
        require(PLAN.read_bytes() == plan_bytes, 'Plan changed during execution')
        require(check_source_scope(plan)[2] == final_hashes, 'Inputs changed between groups')
        label, files = group['label'], group['files']
        receipt_path = OUT / (label + '.receipt.json')
        jsonl_path = OUT / (label + '.jsonl')
        if not receipt_path.exists():
            require(not any((OUT / (label + suffix)).exists() for suffix in ['.jsonl', '.stderr', '.driver.log']),
                    'Archive the interrupted attempt before reusing its label: ' + label)
            with (OUT / (label + '.driver.log')).open('w') as log:
                result = subprocess.run([sys.executable, str(ROOT / 'run_vba_validation.py'), label, *files],
                                        env=env, stdout=log, stderr=subprocess.STDOUT)
            require(result.returncode == 0, f'{label} failed; raw evidence retained, no acceptance aggregate written')
        receipt, parsed = check_receipt(receipt_path, jsonl_path, files, final, final_hashes)
        require(all(flag in receipt['command'] for flag in ['--old_gen_heap_size=512', '--concurrency=1',
                                                           '--timeout=4x', '--reporter=json', '--fail-fast'])
                and env['VBA_TEST_RUNNER'] in receipt['command'], 'Final runtime strategy differs')
        for file in files:
            item = rerun_by_file[file]
            old_names = item.get('case_names', [])
            require(not (Counter(old_names) - Counter(parsed[file]['case_names'])),
                    'Previously observed case occurrence disappeared: ' + file)
            if item.get('baseline_file_complete'):
                additions = plan['expected_added_cases'].get(file, 0)
                require(parsed[file]['passed'] == item['passed'] + additions,
                        'Existing cases were removed or unexpected cases added: ' + file)
            final_item = {**item, 'test_source_sha256': final_hashes['packages/quds_office_engine/' + file]}
            rows[file] = per_file_row(final_item, parsed[file], 'rerun_final', final, label,
                                      receipt_path.relative_to(ROOT).as_posix(), jsonl_path.relative_to(ROOT).as_posix())
        run_groups.append({'label': label, 'files': files, 'source_commit': final,
                           'passed': receipt['passed'], 'seconds': receipt['duration_seconds'],
                           'receipt': receipt_path.relative_to(ROOT).as_posix(),
                           'jsonl': jsonl_path.relative_to(ROOT).as_posix(),
                           'receipt_sha256': digest(receipt_path.read_bytes()),
                           'jsonl_sha256': digest(jsonl_path.read_bytes())})
        print(json.dumps({'group': label, 'complete_groups': len(run_groups), 'total_groups': len(groups),
                          'rerun_passed_so_far': sum(item['passed'] for item in run_groups),
                          'retained_baseline_passed': retained_passed}), flush=True)
    require(set(rows) == set(selection) and len(rows) == 80, 'Accepted file coverage is incomplete')
    require(check_source_scope(plan)[2] == final_hashes and PLAN.read_bytes() == plan_bytes,
            'Final source or plan changed during the cohort')
    rerun_passed = sum(item['passed'] for item in run_groups)
    aggregate = {'schema': 'quds-office-vba-scoped-acceptance/v1',
                 'baseline_commit': BASELINE, 'final_commit': final,
                 'qualification_kind': 'C9 unaffected-file evidence plus repaired-source affected/guard/unrun cohort',
                 'single_source_full_rerun': False, 'selected_file_count': 80, 'distinct_selection': True,
                 'retained_file_count': 42, 'rerun_file_count': 38,
                 'completed_rerun_group_count': len(run_groups),
                 'retained_passed': retained_passed, 'rerun_passed': rerun_passed,
                 'passed': retained_passed + rerun_passed, 'failed': 0, 'skipped': 0,
                 'source_unchanged': True, 'plan_sha256': digest(plan_bytes),
                 'retained_file_groups': retained_groups, 'rerun_groups': run_groups,
                 'per_file': [rows[file] for file in selection],
                 'approved_source_delta': delta, 'source_hashes': final_hashes,
                 'baseline_source_manifest_sha256': digest(canonical(baseline_hashes)),
                 'failed_group28_included': False,
                 'superseded_baseline_passes_included': False,
                 'duration_seconds_rerun': sum(item['seconds'] for item in run_groups)}
    target = OUT / 'scoped-acceptance.receipt.json'
    data = (json.dumps(aggregate, indent=2, ensure_ascii=False) + '\n').encode('utf-8')
    if target.exists():
        require(target.read_bytes() == data, 'A different acceptance aggregate exists; archive it explicitly')
    else:
        with tempfile.NamedTemporaryFile(dir=OUT, prefix='scoped-acceptance-', suffix='.tmp', delete=False) as temporary:
            temporary.write(data)
            temporary.flush()
            os.fsync(temporary.fileno())
            temporary_name = temporary.name
        os.replace(temporary_name, target)
    print(json.dumps({key: value for key, value in aggregate.items()
                      if key not in ['source_hashes', 'per_file', 'approved_source_delta',
                                     'retained_file_groups', 'rerun_groups']}, indent=2), flush=True)


if __name__ == '__main__':
    main()
