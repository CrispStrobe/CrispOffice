from pathlib import Path
from urllib.parse import urljoin
import hashlib
import json
import subprocess
import yaml

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'quds_office_suite'
WORK = ROOT / 'validation-workspace'
CONFIG = WORK / '.dart_tool/package_config.json'
data = json.loads(CONFIG.read_text())
for package in data['packages']:
    package['rootUri'] = urljoin(CONFIG.as_uri(), package['rootUri'])
    local_roots = {
        'quds_office_engine': REPO / 'packages/quds_office_engine',
        'legacy_doc_parser': REPO / 'packages/legacy_doc_parser',
        'quds_office_engine_example': REPO / 'packages/quds_office_engine/example',
    }
    if package['name'] in local_roots:
        package['rootUri'] = local_roots[package['name']].as_uri() + '/'
# Keep compiler/analyzer resolution independent of the symlink entry point.
for target in [CONFIG, REPO / '.dart_tool/package_config.json']:
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(data, indent=2) + '\n')
expected = yaml.safe_load((REPO / 'pubspec.lock').read_text())['packages']
actual = yaml.safe_load((WORK / 'pubspec.lock').read_text())['packages']
versions = {k:v['version'] for k,v in actual.items() if v['source'] == 'hosted'}
mismatches = {k: {'expected': expected.get(k, {}).get('version'), 'actual': v}
              for k,v in versions.items() if expected.get(k, {}).get('version') != v}
receipt = {
    'dart_version': subprocess.check_output([str(ROOT / 'toolchains/dart-sdk/bin/dart'), '--version'], text=True).strip(),
    'dart_sdk_archive_sha256': hashlib.sha256((ROOT / 'toolchains/dartsdk-3.13.7.zip').read_bytes()).hexdigest(),
    'host_node': subprocess.check_output(['node','--version'], text=True).strip(),
    'workspace_packages': ['quds_office_engine', 'legacy_doc_parser', 'quds_office_engine_example'],
    'package_manifests_match': {name: (REPO / 'packages' / name / 'pubspec.yaml').read_bytes() == (WORK / 'packages' / name / 'pubspec.yaml').read_bytes() for name in ['quds_office_engine','legacy_doc_parser', 'quds_office_engine/example']},
    'resolved_packages': versions,
    'shared_lock_versions_match': not mismatches,
    'shared_resolved_package_count': len(versions),
    'mismatches': mismatches,
    'package_config_sha256': hashlib.sha256(CONFIG.read_bytes()).hexdigest(),
    'resolved_lock_sha256': hashlib.sha256((WORK / 'pubspec.lock').read_bytes()).hexdigest(),
    'test_strategy': 'package:test --compiler source --concurrency=4 --timeout=4x --fail-fast; input hashes captured by run_vba_validation.py',
    'external_ci_used': False,
    'scope_limitations': ['No Flutter SDK installed', 'No installed Microsoft Word or PowerPoint host qualification'],
}
(ROOT / 'validation-results').mkdir(exist_ok=True)
(ROOT / 'validation-results/environment.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k:v for k,v in receipt.items() if k != 'resolved_packages'}, indent=2))
assert not mismatches, mismatches
assert all(receipt['package_manifests_match'].values())
