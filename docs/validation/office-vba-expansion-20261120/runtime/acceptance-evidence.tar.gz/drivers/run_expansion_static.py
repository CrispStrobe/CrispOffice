import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/scratch/f0616b02624b')
repo = root / 'quds_office_suite'
engine = repo / 'packages/quds_office_engine'
out = root / 'validation-results'
dart = root / 'toolchains/dart-sdk/bin/dart'
prefix = os.environ.get('VBA_STATIC_PREFIX', 'expansion-final')
if (out / (prefix + '-static.receipt.json')).exists():
    raise SystemExit('Archive existing static receipts before another run: ' + prefix)

def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()

def hashes():
    paths = git('ls-files', 'packages/quds_office_engine', 'packages/legacy_doc_parser/lib',
                'packages/quds_office_editor/lib/src/editor_slide/render_slide_stage.dart',
                'pubspec.lock').splitlines()
    return {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in paths}

files = git('diff', '--name-only', '3ffa599ff003a6e678260df1237b01887693e546', '--',
            'packages/quds_office_engine',
            'packages/quds_office_editor/lib/src/editor_slide/render_slide_stage.dart').splitlines()
files = [p for p in files if p.endswith('.dart') and (repo / p).is_file()]
before = hashes()
receipt = dict(commit=git('rev-parse', 'HEAD'), checks=[], format_file_count=len(files), source_hashes=before)
env = os.environ.copy()
env.update(PUB_CACHE=str(root / 'toolchains/pub-cache'), TMPDIR=str(root / 'toolchains/tmp'),
           DART_SUPPRESS_ANALYTICS='true', CI='true')
checks = [
    ('format', [str(dart), 'format', '--output=none', '--set-exit-if-changed', *files], repo),
    ('analyze', [str(dart), 'analyze', '--fatal-infos'], engine),
]
for name, cmd, cwd in checks:
    start = time.time()
    log_path = out / (prefix + '-' + name + '.log')
    with log_path.open('w') as log:
        result = subprocess.run(cmd, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    item = dict(name=name, command=cmd, cwd=str(cwd), exit_code=result.returncode,
                seconds=round(time.time() - start, 3))
    receipt['checks'].append(item)
    print(json.dumps({k: v for k, v in item.items() if k not in ('command', 'cwd')}), flush=True)
    print(log_path.read_text()[-5000:], flush=True)
receipt['source_unchanged'] = before == hashes()
(out / (prefix + '-static.receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
raise SystemExit(0 if receipt['source_unchanged'] and all(c['exit_code'] == 0 for c in receipt['checks']) else 1)
