import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

root = Path('/workspace/scratch/f0616b02624b')
repo = root / 'quds_office_suite'
engine = repo / 'packages/quds_office_engine'
out = root / 'validation-results'
selection = json.loads((out / 'expansion-selection.json').read_text())
groups = [[selection[0]]]
pending = []
for path in selection[1:]:
    spawns_process = re.search(r'\bProcess\.(?:start|run|runSync)\b', (engine / path).read_text())
    if spawns_process:
        if pending:
            groups.append(pending)
            pending = []
        groups.append([path])
    else:
        pending.append(path)
        if len(pending) == 4:
            groups.append(pending)
            pending = []
if pending:
    groups.append(pending)
assert [p for group in groups for p in group] == selection
plan = [{'label': f'expansion-shard{i + 1:02d}', 'files': group} for i, group in enumerate(groups)]
(out / 'expansion-shards.json').write_text(json.dumps(plan, indent=2) + '\n')
env = os.environ.copy()
env.update(VBA_TEST_CONCURRENCY='1', VBA_TEST_FAIL_FAST='1', VBA_DART_HEAP_MB='512',
           VBA_TEST_RUNNER=str(root / 'toolchains/test-runner/test-runner.dill'))
head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
receipts = []
for group in plan:
    receipt_path = out / (group['label'] + '.receipt.json')
    reused = False
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_text())
        reused = (receipt['commit'] == head and receipt['exit_code'] == 0 and receipt['source_unchanged']
                  and receipt['runner_done'] and all(e.get('success') is True for e in receipt['runner_done'])
                  and receipt['command'][-len(group['files']):] == group['files'])
        if not reused:
            raise SystemExit('Existing nonpassing receipt must be archived explicitly: ' + group['label'])
    else:
        with (out / (group['label'] + '.driver.log')).open('w') as log:
            result = subprocess.run([sys.executable, str(root / 'run_vba_validation.py'), group['label'],
                                     *group['files']], env=env, stdout=log, stderr=subprocess.STDOUT)
        receipt = json.loads(receipt_path.read_text())
        if result.returncode:
            print(json.dumps({'failed_group': group, 'receipt': {k: v for k, v in receipt.items()
                                                              if k not in ('command', 'source_hashes')}}), flush=True)
            raise SystemExit(result.returncode)
    receipts.append(receipt)
    print(json.dumps({'group': group['label'], 'files': len(group['files']), 'passed': receipt['passed'],
                      'failed': receipt['failed'], 'skipped': receipt['skipped'], 'reused': reused,
                      'groups_complete': len(receipts), 'groups_total': len(plan),
                      'total_passed': sum(r['passed'] for r in receipts)}), flush=True)

source_hashes = receipts[0]['source_hashes']
assert all(r['source_hashes'] == source_hashes for r in receipts), 'Sources differed between groups'
assert all((repo / p).is_file() and hashlib.sha256((repo / p).read_bytes()).hexdigest() == sha
           for p, sha in source_hashes.items()), 'Sources changed after final group'
assert all(r['commit'] == head and r['exit_code'] == 0 and r['source_unchanged'] and r['failed'] == 0
           and r['skipped'] == 0 and r['runner_done'] and all(e.get('success') is True for e in r['runner_done'])
           for r in receipts)
aggregate = dict(commit=head, selected_file_count=len(selection), completed_group_count=len(plan),
                 passed=sum(r['passed'] for r in receipts), failed=0, skipped=0, source_unchanged=True,
                 distinct_selection=len(selection) == len(set(selection)),
                 duration_seconds=sum(r['duration_seconds'] for r in receipts),
                 groups=[dict(label=g['label'], files=g['files'], passed=r['passed'],
                              seconds=r['duration_seconds']) for g, r in zip(plan, receipts)],
                 source_hashes=source_hashes)
(out / 'expansion-acceptance.receipt.json').write_text(json.dumps(aggregate, indent=2) + '\n')
print(json.dumps({k: v for k, v in aggregate.items() if k not in ('groups', 'source_hashes')}, indent=2), flush=True)
