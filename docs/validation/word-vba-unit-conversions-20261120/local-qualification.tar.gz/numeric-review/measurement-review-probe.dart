import 'dart:convert';
import 'package:quds_office_engine/quds_office_automation.dart';

OfficeMacro compile(String body, {String language = 'vba-word', OfficeMacroFormat format = OfficeMacroFormat.docx, String helpers = ''}) =>
    OfficeMacroLanguages().compile(OfficeMacroSource(language: language, format: format, source: 'Option Explicit\n$helpers\nSub Main()\n$body\nEnd Sub'));

void main() {
  const pairs = <(String, String, String)>[
    ('InchesToPoints', 'PointsToInches', 'Inches'),
    ('CentimetersToPoints', 'PointsToCentimeters', 'Centimeters'),
    ('MillimetersToPoints', 'PointsToMillimeters', 'Millimeters'),
    ('PicasToPoints', 'PointsToPicas', 'Picas'),
    ('LinesToPoints', 'PointsToLines', 'Lines'),
  ];
  final values = <int>[0, 1, -1, 2, -2, 7, -7, 23, -23, 127, -127, 239, -239, 240, -240, 241, -241, 2147483646, -2147483646, 2147483647, -2147483647];
  var seed = 67439;
  for (var index = 0; index < 40; index++) {
    seed = (48271 * seed) % 2147483647;
    values.add(index.isEven ? seed : -seed);
  }
  var roundTrips = 0;
  for (final (forward, inverse, parameter) in pairs) {
    for (final twips in values) {
      final points = twips / 20;
      for (final prefix in ['', 'Application.']) {
        final expr = '$prefix$forward($parameter:=$prefix$inverse(Points:=$points))';
        final result = compile('ActiveDocument.Paragraphs(1).Format.LeftIndent = $expr');
        if (result.steps.single.arguments['left'] != points) {
          throw StateError('Roundtrip failed for $expr');
        }
        roundTrips++;
      }
    }
  }
  var boundaryRejections = 0;
  for (final (forward, inverse, _) in pairs) {
    for (final points in [107374182.4, -107374182.4]) {
      try {
        compile('ActiveDocument.Paragraphs(1).Format.LeftIndent = $forward($inverse($points))');
      } on OfficeVbaCompileException catch (error) {
        if (error.code != 'vba_type_error') rethrow;
        boundaryRejections++;
        continue;
      }
      throw StateError('Native bound accepted $points for $forward');
    }
  }
  var scopeChecks = 0;
  final names = pairs.expand((pair) => [pair.$1, pair.$2]);
  for (final (language, format) in [('vba-excel', OfficeMacroFormat.xlsx), ('vba-powerpoint', OfficeMacroFormat.pptx)]) {
    for (final name in names) {
      for (final prefix in ['', 'Application.']) {
        try {
          compile('Dim n As Double\nIf False Then\nn = $prefix$name(2)\nEnd If', language: language, format: format);
        } on OfficeVbaCompileException {
          scopeChecks++;
          continue;
        }
        throw StateError('Word conversion leaked into $language: $prefix$name');
      }
      compile('Dim n As Double\nn = $name(2)', language: language, format: format,
        helpers: 'Function $name(ByVal n As Double) As Double\n$name = n\nEnd Function');
      scopeChecks++;
    }
  }
  final once = compile('ActiveDocument.Paragraphs(1).Format.LeftIndent = Application.CentimetersToPoints(Centimeters:=Measure())', helpers: '''
Function Measure() As Double
ActiveDocument.Paragraphs(1).Range.InsertBefore "once"
Measure = 1.27
End Function
''');
  if (once.steps.length != 2 || once.steps.last.arguments['left'] != 36) {
    throw StateError('Named argument evaluated more than once');
  }
  print(jsonEncode({'roundTrips': roundTrips, 'boundaryRejections': boundaryRejections,
    'scopeChecks': scopeChecks, 'namedArgumentEvaluatedOnce': true}));
}
