import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_editor/quds_office_editor.dart';

void main() {
  testWidgets('note undo must not route the next citation into a prior body selection', (tester) async {
    final document = WmlDocument.empty(text: 'Body');
    final note = WordNotes.insert(document, document.paragraphs.single, endnote: false, text: 'Short');
    final controller = WordEditorController(document: document);
    controller.proofing.enabled = false;
    controller.caret.logicalIndex = 2;
    controller.caret.selectionAnchor = 0;
    controller.caret.selectionAnchorParagraph = 0;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: WordNotesPane(controller: controller))));
    final field = find.byKey(const ValueKey<String>('notes-edit-1'));
    await tester.enterText(field, 'Other');
    await tester.pump();
    expect(controller.noteEditingTarget?.note, same(note));
    controller.undo();
    await tester.pump();
    expect(tester.widget<TextField>(field).focusNode!.hasFocus, isTrue);
    expect(controller.noteEditingTarget?.note, same(note));
    expect(controller.beginZoteroTransaction(documentId: 'review').session.insertionParagraph, same(note.paragraphs.single));
    await tester.pumpWidget(const SizedBox.shrink());
    controller.dispose();
  });
  testWidgets('ordinary note undo keeps visible and command caret synchronized', (tester) async {
    final document = WmlDocument.empty(text: 'Body');
    final note = WordNotes.insert(document, document.paragraphs.single, endnote: false, text: 'Short');
    final controller = WordEditorController(document: document);
    controller.proofing.enabled = false;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: WordNotesPane(controller: controller))));
    final field = find.byKey(const ValueKey<String>('notes-edit-1'));
    await tester.enterText(field, 'A much longer note');
    await tester.pump();
    expect(controller.noteEditingTarget!.selection.extentOffset, 18);
    controller.undo();
    await tester.pump();
    final visible = tester.widget<TextField>(field).controller!;
    expect(visible.text, 'Short');
    expect(visible.selection.extentOffset, 5);
    expect(controller.noteEditingTarget!.selection, visible.selection);
    expect(() => controller.beginZoteroTransaction(documentId: 'review'), returnsNormally);
    await tester.pumpWidget(const SizedBox.shrink());
    controller.dispose();
  });
}
