import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
WmlParagraph p(String text,{WmlParagraphProps? props})=>WmlParagraph(inlines:[WmlRun(text:text)],properties:props);
WordZoteroCitingSession s(WmlDocument doc,WmlParagraph first,WmlParagraph last,{int start=3,int end=3})=>WordZoteroCitingSession(document:doc,documentId:'review',insertionParagraph:first,insertionOffset:start,insertionEndParagraph:last,insertionEndOffset:end);
void apply(WordZoteroCitingSession session,String html){session.handle('Document.insertText',['review',html]);session.handle('Document.complete',['review']);session.apply();}
void main(){
 for(final kind in ['bookmark','source-bookmark','field-end']){
 final first=p('pre OLD'), middle=p('MID',props:WmlParagraphProps(bookmarkName:kind=='bookmark'?'Saved':null,sourceBookmarkName:kind=='source-bookmark'?'Saved':null,fieldEnd:kind=='field-end')),last=p('OLD suffix');
 final doc=WmlDocument(sections:[WmlSection(blocks:[first,middle,last])]);
 final session=s(doc,first,last);final can=session.canInsertNoteText;
 if(can)apply(session,'<p>NEW</p>');
 print(jsonEncode({'kind':kind,'can':can,'paragraphs':doc.paragraphs.map((p)=>p.text).toList(),'bookmarkRemaining':doc.paragraphs.any((p)=>p.properties.bookmarkName=='Saved'||p.properties.sourceBookmarkName=='Saved'),'fieldEndRemaining':doc.paragraphs.any((p)=>p.properties.fieldEnd)}));
 }
 final a=p('pre OLD'), shared=p('OLD suffix');final d=WmlDocument(sections:[WmlSection(blocks:[a,shared]),WmlSection(blocks:[shared])]);final ss=s(d,a,shared);final canShared=ss.canInsertNoteText;if(canShared)apply(ss,'<p>NEW</p>');print(jsonEncode({'kind':'shared-end','can':canShared,'other-section':d.sections.last.blocks.whereType<WmlParagraph>().map((p)=>p.text).toList()}));
 for(final endnote in [false,true]){
 for(final payload in ['<p>NEW</p>','<h2>NEW</h2>','<table><tr><td>NEW</td></tr></table>']){
 final doc=WmlDocument.empty(text:'Body');final note=WordNotes.insert(doc,doc.paragraphs.single,endnote:endnote,text:' OLD');
 final first=note.paragraphs.single;first.inlines.insert(0,WmlNoteMarker(endnote:endnote,properties:WmlRunProps()));
 final last=p('OLD suffix');note.blocks.add(last);
 final session=s(doc,first,last,start:0);final can=session.canInsertNoteText;
 if(can)apply(session,payload);
 print(jsonEncode({'kind':'note','endnote':endnote,'payload':payload,'can':can,'text':note.allParagraphs.map((p)=>p.text).toList(),'markerFirst':note.paragraphs.first.inlines.first is WmlNoteMarker,'inlines':note.paragraphs.first.inlines.map((i)=>i is WmlRun?i.text:i.runtimeType.toString()).toList()}));
 }
 }
}
