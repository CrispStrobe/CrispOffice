import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
WmlParagraph p(String text)=>WmlParagraph(inlines:[WmlRun(text:text)]);
ZoteroCitation citation(String id)=>ZoteroCitation(citationId:id,plainCitation:'(old)',items:[ZoteroCitationItem.fromCsl(itemData:{'id':id,'type':'book','title':'Source'},uris:['http://zotero.org/users/42/items/ABCD1234'])]);
void main(){
 for(final complex in [false,true]){
 for(final reopen in [false,true]){
 for(final side in ['prefix','suffix']){
  var first=p('Before OLD'),last=p('OLD After');
  var doc=WmlDocument(sections:[WmlSection(blocks:[first,last])]);
  WordZotero.insertCitation(side=='prefix'?first:last,citation('x'),index:side=='prefix'?7:3);
  if(complex){final target=side=='prefix'?first:last;final run=target.inlines.whereType<WmlRun>().firstWhere((r)=>r.fieldInstruction!=null);final at=target.inlines.indexOf(run);target.inlines.replaceRange(at,at+1,[WmlFieldBoundary(kind:WmlFieldBoundaryKind.begin),WmlFieldBoundary(kind:WmlFieldBoundaryKind.instruction,text:run.fieldInstruction!),WmlFieldBoundary(kind:WmlFieldBoundaryKind.separate),WmlRun(text:run.text,properties:run.properties.copy()),WmlFieldBoundary(kind:WmlFieldBoundaryKind.end)]);}
  if(reopen){doc=WordDeserializer().readBytes(WordSerializer().writeBytes(doc));first=doc.paragraphs.first;last=doc.paragraphs.last;}
  final field=WordZotero.fields(doc).single;
  final start=side=='prefix'?field.end:7;final end=3;
  final s=WordZoteroCitingSession(document:doc,documentId:'r',insertionParagraph:first,insertionOffset:start,insertionEndParagraph:last,insertionEndOffset:end);
  String reason='';try{s.assertCanInsertNoteText();}catch(e){reason=e.toString();}
  if(s.canInsertNoteText){s.handle('Document.insertText',['r','<p>RESEARCH</p>']);final fs=s.handle('Document.getFields',['r','Http']) as List;for(final f in fs){s.handle('Field.setText',['r',f['id'],'<i>UPDATED SOURCE</i>',true]);}s.handle('Document.complete',['r']);s.apply();}
  final updatedFields=WordZotero.fields(doc);
  print(jsonEncode({'complex':complex,'result':doc.paragraphs.map((p)=>p.text).toList(),'fields':updatedFields.map((f)=>f.cachedText).toList(),'reopen':reopen,'side':side,'first':first.text,'last':last.text,'selection':[start,end],'can':s.canInsertNoteText,'reason':reason}));
 }
}
}
}
