from pathlib import Path
import subprocess,json,hashlib,time,datetime,os
root=Path('/workspace/scratch/b3c425a3b090')
source=root/'quds_office_suite'
runtime=root/'runtime'
logs=runtime/'logs'
files=['test/bulk_api_aliases_test.dart','test/presentation_test.dart','test/presentation_whitespace_test.dart','test/remote_images_test.dart','test/reader_image_updates_test.dart','test/controller_test.dart']
scopes=['packages/quds_mail_ui','packages/quds_mail_core','packages/quds_mail_mime','third_party/enough_mail','pubspec.yaml','pubspec.lock','analysis_options.yaml','dart_test.yaml']
def git(*args): return subprocess.check_output(['git',*args],cwd=source,text=True).strip()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def inputs():
 paths=subprocess.check_output(['git','ls-files','-z','--',*scopes],cwd=source).decode().split('\0')
 out={p:sha(source/p) for p in sorted(set(paths)) if p and not p.endswith('.md') and (source/p).is_file()}
 out['runtime/workspace/.dart_tool/package_config.json']=sha(runtime/'workspace/.dart_tool/package_config.json')
 return out
before=inputs()
before_path=logs/'intake-mail-sources-before.json'
before_path.write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
cmd=[str(runtime/'flutter/bin/cache/dart-sdk/bin/dart'),str(runtime/'flutter/bin/cache/flutter_tools.snapshot'),'--no-version-check','test','--no-pub','--reporter=json','--concurrency=1',*files]
cwd=runtime/'workspace/packages/quds_mail_ui'
receipt={'command':cmd,'cwd':str(cwd),'head':git('rev-parse','HEAD'),'index_tree':git('write-tree'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_files':len(before),'source_manifest_sha256':sha(before_path),'pubspec_lock_sha256':sha(source/'pubspec.lock'),'files':files,'sdk':json.loads((runtime/'logs/flutter-version.json').read_text())}
start=time.monotonic()
with (logs/'intake-mail.jsonl').open('w') as out,(logs/'intake-mail.stderr').open('w') as err:
 result=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=err,check=False)
after=inputs()
(logs/'intake-mail-sources-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
events=[json.loads(l) for l in (logs/'intake-mail.jsonl').read_text().splitlines() if l.strip()]
starts={e['test']['id']:e['test'] for e in events if e['type']=='testStart'}
done=[e for e in events if e['type']=='testDone' and not e.get('hidden',False) and not starts[e['testID']]['name'].startswith('loading ')]
cases=[{'name':starts[e['testID']]['name'],'file':starts[e['testID']].get('url'),'result':e['result'],'skipped':e['skipped']} for e in done]
(logs/'intake-mail-cases.json').write_text(json.dumps(cases,indent=2)+'\n')
receipt.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,source_stable=before==after,source_changes=[p for p in sorted(before.keys()|after.keys()) if before.get(p)!=after.get(p)],passed=sum(e['result']=='success' and not e['skipped'] for e in done),skipped=sum(e['skipped'] for e in done),failed=sum(e['result']!='success' for e in done),errors=sum(e['type']=='error' for e in events),unique_cases=len({(c['file'],c['name']) for c in cases}),case_count=len(cases),terminal=events[-1] if events else None,jsonl_sha256=sha(logs/'intake-mail.jsonl'),stderr_sha256=sha(logs/'intake-mail.stderr'))
(logs/'intake-mail-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
raise SystemExit(0 if result.returncode==0 and before==after and receipt['errors']==0 and receipt['failed']==0 and receipt['terminal'].get('success') else 1)
