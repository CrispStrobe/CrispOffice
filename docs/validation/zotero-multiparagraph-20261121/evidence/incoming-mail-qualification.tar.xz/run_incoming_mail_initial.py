from pathlib import Path
import subprocess,json,hashlib,time,datetime,os,sys,collections
root=Path('/workspace/scratch/b3c425a3b090')
runtime=root/'runtime'; source=runtime/'mail-source'; workspace=runtime/'mail-workspace'; logs=runtime/'logs'
gate=sys.argv[1]
plans={
 'store':('packages/quds_mail_store',['test/flag_reconciliation_test.dart','test/migration_test.dart','test/flag_journal_test.dart'],'vm'),
 'transport':('packages/quds_mail_transport',['test/cloud_provider_test.dart','test/cloud_unsupported_test.dart','test/ews_provider_test.dart','test/ews_unsupported_test.dart','test/native_flag_observation_test.dart','test/unsupported_test.dart'],'vm'),
 'core':('packages/quds_mail_core',['test/bulk_flags_compatibility_test.dart'],'vm'),
 'ui':('packages/quds_mail_ui',['test/bulk_api_aliases_test.dart','test/presentation_test.dart','test/presentation_whitespace_test.dart'],'flutter'),
 'studio':('packages/quds_office_editor/example',['test/studio_mail_remote_images_incoming_test.dart'],'flutter'),
}
package,files,kind=plans[gate]
for f in files: assert (source/package/f).is_file(),f
prefix='incoming-mail-'+gate
export=json.loads((runtime/'setup/mail-export.json').read_text())
scopes=['packages/quds_mail_core/','packages/quds_mail_mime/','packages/quds_mail_store/','packages/quds_mail_transport/','packages/quds_mail_ui/','third_party/enough_mail/']
individual=['pubspec.yaml','pubspec.lock','analysis_options.yaml','packages/quds_office_editor/example/pubspec.yaml','packages/quds_office_editor/example/lib/studio_mail_remote_images.dart','packages/quds_office_editor/example/test/studio_mail_remote_images_incoming_test.dart']
input_names=sorted(p for p in export['files'] if not p.endswith('.md') and (p in individual or any(p.startswith(s) for s in scopes)))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
 out={p:sha(source/p) for p in input_names}
 for p in input_names: assert out[p]==export['files'][p]['sha256'],p
 for p in ['mail-workspace/.dart_tool/package_config.json','mail-workspace/.dart_tool/native_assets.yaml','mail-workspace/.dart_tool/lib/libsqlite3.so','mail-workspace/pubspec.lock','flutter/bin/cache/dart-sdk/bin/dart','flutter/bin/cache/flutter_tools.snapshot','flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester','pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart']:
  out['runtime/'+p]=sha(runtime/p)
 return out
assert sha(workspace/'.dart_tool/lib/libsqlite3.so')=='0a65852703763619a7a34633b4959b3b86c4103804a4dfe4e8b27b5de1c0647b'
before=inputs(); before_path=logs/(prefix+'-sources-before.json'); before_path.write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
dart=runtime/'flutter/bin/cache/dart-sdk/bin/dart'
if kind=='flutter':
 cmd=[str(dart),str(runtime/'flutter/bin/cache/flutter_tools.snapshot'),'--no-version-check','test','--no-pub','--reporter=json','--concurrency=1',*files]
else:
 cmd=[str(dart),'--packages='+str(workspace/'.dart_tool/package_config.json'),str(runtime/'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),'--reporter=json','--concurrency=1','--platform=vm',*files]
cwd=workspace/package
receipt={'gate':gate,'command':cmd,'cwd':str(cwd),'head':export['commit'],'tree':export['tree'],'immutable_export':True,'all_exported_git_blobs_verified':True,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_files':len(before),'source_manifest_sha256':sha(before_path),'pubspec_lock_sha256':sha(source/'pubspec.lock'),'original_files':[package+'/'+f for f in files],'runtime':json.loads((runtime/'logs/flutter-version.json').read_text()),'native_sqlite':json.loads((logs/'incoming-mail-sqlite-readiness.json').read_text()),'runner_sha256':sha(Path(__file__))}
(logs/(prefix+'-started.json')).write_text(json.dumps(receipt,indent=2)+'\n')
start=time.monotonic()
with (logs/(prefix+'.jsonl')).open('w') as out,(logs/(prefix+'.stderr')).open('w') as err: result=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=err,check=False)
(logs/(prefix+'-process.json')).write_text(json.dumps({'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n')
after=inputs(); (logs/(prefix+'-sources-after.json')).write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
events=[json.loads(l) for l in (logs/(prefix+'.jsonl')).read_text().splitlines() if l.strip()]
starts={e['test']['id']:e['test'] for e in events if e['type']=='testStart'}; suites={e['suite']['id']:e['suite'] for e in events if e['type']=='suite'}
completed=[e for e in events if e['type']=='testDone']; visible=[e for e in completed if not e.get('hidden',False) and not starts[e['testID']]['name'].startswith('loading ')]
cases=[]
for e in visible:
 t=starts[e['testID']]; s=Path(suites[t['suiteID']]['path']); p=str(s.relative_to(cwd)) if s.is_absolute() else str(s)
 cases.append({'name':t['name'],'file':package+'/'+p,'result':e['result'],'skipped':e['skipped']})
(logs/(prefix+'-cases.json')).write_text(json.dumps(cases,indent=2)+'\n')
receipt.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,source_stable=before==after,source_changes=[p for p in before.keys()|after.keys() if before.get(p)!=after.get(p)],passed=sum(e['result']=='success' and not e['skipped'] for e in visible),skipped=sum(e['skipped'] for e in visible),failed=sum(e['result']!='success' for e in visible),errors=sum(e['type']=='error' for e in events),unique_cases=len({(c['file'],c['name']) for c in cases}),case_count=len(cases),suite_counts=dict(collections.Counter(c['file'] for c in cases)),all_started_tests_completed=len(completed)==len(starts)==len({e['testID'] for e in completed}),terminal_event_count=sum(e['type']=='done' for e in events),terminal=events[-1] if events else None,jsonl_sha256=sha(logs/(prefix+'.jsonl')),stderr_sha256=sha(logs/(prefix+'.stderr')),cases_sha256=sha(logs/(prefix+'-cases.json')))
(logs/(prefix+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['gate','head','tree','source_files','source_manifest_sha256','exit_code','elapsed_seconds','source_stable','source_changes','passed','skipped','failed','errors','unique_cases','all_started_tests_completed','terminal_event_count','terminal']},indent=2))
raise SystemExit(0 if result.returncode==0 and before==after and receipt['errors']==0 and receipt['failed']==0 and receipt['terminal'] and receipt['terminal'].get('success') and receipt['all_started_tests_completed'] and receipt['terminal_event_count']==1 else 1)
