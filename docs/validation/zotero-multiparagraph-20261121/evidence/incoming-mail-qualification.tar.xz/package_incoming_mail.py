from pathlib import Path
import hashlib,json,tarfile,gzip,io
root=Path('/workspace/scratch/b3c425a3b090'); rt=root/'runtime'; logs=rt/'logs'
gates=['store','transport','core','ui','studio','unsupported']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipts={g:json.loads((logs/f'incoming-mail-{g}-receipt.json').read_text()) for g in gates}
for g,r in receipts.items():
 assert r['exit_code']==0 and r['source_stable'] and r['failed']==r['errors']==r['skipped']==0
 assert r['terminal_event_count']==1 and r['terminal']['success'] and r['all_started_tests_completed']
 assert r['head']=='6c180d7e805b49663fda32fcf9c5c92e0ae2d86e'
 b=logs/f'incoming-mail-{g}-sources-before.json'; a=logs/f'incoming-mail-{g}-sources-after.json'
 assert b.read_bytes()==a.read_bytes()
 assert sha(b)==r['source_manifest_sha256']
 for suffix,key in [('.jsonl','jsonl_sha256'),('.stderr','stderr_sha256'),('-cases.json','cases_sha256')]:
  assert sha(logs/f'incoming-mail-{g}{suffix}')==r[key]
allcases=[c for g in gates for c in json.loads((logs/f'incoming-mail-{g}-cases.json').read_text())]
assert len(allcases)==len({(c['file'],c['name']) for c in allcases})==332
assert len({r['source_manifest_sha256'] for r in receipts.values()})==1
transport=receipts['transport']
transport['declared_platform_exclusions']=[{'file':'packages/quds_mail_transport/test/'+name,'declaration':"@TestOn('js')",'qualification_gate':'incoming-mail-unsupported-receipt.json'} for name in ['cloud_unsupported_test.dart','ews_unsupported_test.dart','unsupported_test.dart']]
transport['executed_original_files']=sorted(transport['suite_counts'])
(logs/'incoming-mail-transport-receipt.json').write_text(json.dumps(transport,indent=2)+'\n')
summary={'head':'6c180d7e805b49663fda32fcf9c5c92e0ae2d86e','tree':'94d8880ff9f665f5eba24e3f648d5053750a3171','immutable_git_blob_verified_export':True,'unique_original_files':len({c['file'] for c in allcases}),'unique_cases':332,'passed':332,'skipped_test_cases':0,'failed':0,'errors':0,'all_six_process_exits':0,'all_started_cases_completed':True,'all_terminal_events_successful':True,'source_input_count':502,'source_manifest_sha256':next(iter(receipts.values()))['source_manifest_sha256'],'source_stable_all_runs':True,'native_sqlite':json.loads((logs/'incoming-mail-sqlite-readiness.json').read_text()),'gate_results':{g:{k:r[k] for k in ['passed','skipped','failed','errors','exit_code','suite_counts']} for g,r in receipts.items()},'platform_exclusions':transport['declared_platform_exclusions'],'scope':'Affected native SQLite reconciliation/journal/migration, core provider compatibility, native/cloud/EWS observations, JavaScript unsupported boundaries, UI aliases/presentation, and the Studio remote-image compatibility consumer. Provider responses are synthetic; native SQLite is the actual pinned native library.'}
(logs/'incoming-mail-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
entries={}
for path in sorted(logs.glob('incoming-mail-*')):
 if path.is_file() and path.suffix not in {'.gz'} and path.name not in {'incoming-mail-archive-index.json','incoming-mail-package.json','incoming-mail-package-run.log'}:
  entries['logs/'+path.name]=path
for name in ['run_incoming_mail.py','run_incoming_mail_initial.py','package_incoming_mail.py','setup/mail-export.json','setup/sqlite-download.json','setup/native/sqlite_probe.dart','logs/flutter-version.json','setup/sdk.json']:
 entries[name]=rt/name
for name in ['.dart_tool/package_config.json','.dart_tool/native_assets.yaml','pubspec.lock']:
 entries['runtime-configuration/'+name.replace('.dart_tool/','')]=rt/'mail-workspace'/name
manifest={name:{'sha256':sha(p),'bytes':p.stat().st_size} for name,p in entries.items()}
(logs/'incoming-mail-archive-index.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
archive=logs/'incoming-mail-qualification.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed, tarfile.open(fileobj=compressed,mode='w') as tar:
 for name,path in sorted(entries.items()):
  data=path.read_bytes(); info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0; info.uid=info.gid=0; tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(entries)
 for member in tar:
  data=tar.extractfile(member).read(); assert hashlib.sha256(data).hexdigest()==manifest[member.name]['sha256']
package={'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(entries),'member_index_sha256':sha(logs/'incoming-mail-archive-index.json'),'verified_all_members':True,'summary_sha256':sha(logs/'incoming-mail-summary.json')}
(logs/'incoming-mail-package.json').write_text(json.dumps(package,indent=2)+'\n')
print(json.dumps({'summary':summary,'package':package},indent=2))
