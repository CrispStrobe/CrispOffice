# Refreshed Studio Zotero qualification and retained scoped gates

Fresh source: `a5dc721dd8e519dde4f019b82a89572fe9f570f4`; tree `b3c010249b88c1ae29bce6d901f5c983adf1acf4`.

Both Studio selections passed: **18 citing-transport cases and 15 shortcuts**,
in separate direct Flutter-snapshot processes. Each exited zero with one
successful terminal, no skipped or unfinished cases, no error events and empty
stderr. All 2,887 source and mirrored inputs and runtime hashes remained stable
through each invocation. Raw receipts, case inventories and manifests are under
`records/`; the runner and environment recipe are under `runtime/`.

`scoped-retention.json` records the complete exceptions relative to the original
`c5cf1ec11970211597fd16eebdc8d0eaa115278b` qualification. The editor manifest has 2,871 of 2,884 original inputs
unchanged, 13 changed inputs and three newly added Studio Mail files. The engine
manifest has 2,849 of 2,853 inputs unchanged, with four Word-path differences.
Every selected editor/engine test and all nine Zotero static-check files retain
their exact bytes.

Three Word files differ only in formatting: complete-file Dart 3.12 normalization
proves equality for `word_steps.dart` and the VBA PageSetup test; the macro
PageSetup test is identical to its prior qualified source `537d2e7cdd056e06739cd3504b37e5f8751d9373`.
The compatibility-fidelity helper separately adds namespace-aware lookup and
passed five fresh cases on a local commit with the identical published tree.
Supporting proof and receipts are included without adding those cases to the
33-case Studio result. The new Mail feature gates are supplied separately by
the Mail owner; the Studio Zotero regressions alone do not prove those features.

The 400 editor, 977 native engine and overlapping 148 targeted Node results
retain their original source attribution; they were not broadly rerun. Earlier
Studio receipts and source-applicability reports remain unchanged as history.
This increment claims no live installed-application or external Zotero session.
