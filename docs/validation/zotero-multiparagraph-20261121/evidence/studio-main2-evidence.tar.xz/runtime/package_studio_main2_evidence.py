"""Retain earlier scoped gates and package the refreshed Studio host checks."""

import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/b3c425a3b090')
RUNTIME = ROOT / 'runtime'
REPO = ROOT / 'quds_office_suite'
LOGS = RUNTIME / 'logs'
BASE = 'c5cf1ec11970211597fd16eebdc8d0eaa115278b'
FINAL = 'a5dc721dd8e519dde4f019b82a89572fe9f570f4'
WORD_PRIOR = '537d2e7cdd056e06739cd3504b37e5f8751d9373'
WORD_DELTA = RUNTIME / 'isolated/main2-fidelity-da066'
LABELS = ['final-studio-citing_transport-main2', 'final-studio-shortcuts-main2']
FORMAT_PATHS = [
    'packages/quds_office_engine/lib/src/automation/operations/word_steps.dart',
    'packages/quds_office_engine/test/office_macro_word_page_setup_test.dart',
    'packages/quds_office_engine/test/office_vba_word_page_setup_test.dart',
]
HELPER_PATH = 'packages/quds_office_engine/test/word_compatibility_fidelity_test.dart'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def read_json(path):
    return json.loads(path.read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def tree(commit):
    result = {}
    for row in git('ls-tree', '-r', '-z', commit).decode().split('\0'):
        if row:
            metadata, name = row.split('\t', 1)
            _, kind, blob = metadata.split()
            if kind == 'blob':
                result[name] = blob
    return result


old_tree = tree(BASE)
new_tree = tree(FINAL)
final_tree = git('rev-parse', FINAL + '^{tree}').decode().strip()
editor_old = read_json(LOGS / 'final-editor-combined-sources-before.json')
editor_new = read_json(LOGS / (LABELS[0] + '-sources-before.json'))
for name, record in editor_old.items():
    assert record['source_blob'] == old_tree[name] and record['matches_source']
for name, record in editor_new.items():
    assert record['source_blob'] == new_tree[name] and record['matches_source']
changed = [name for name in editor_old if editor_old[name]['sha256'] != editor_new[name]['sha256']]
added = sorted(set(editor_new) - set(editor_old))
removed = sorted(set(editor_old) - set(editor_new))
mail_changed = sorted(name for name in changed if name.startswith('packages/quds_office_editor/example/'))
assert len(changed) == 13 and len(mail_changed) == 9 and len(added) == 3 and not removed
assert set(changed) == set(mail_changed + FORMAT_PATHS + [HELPER_PATH])
assert all(name.startswith('packages/quds_office_editor/example/') for name in added)

word_delta = read_json(WORD_DELTA / 'delta-receipt.json')
normalization = read_json(WORD_DELTA / 'delta-logs/format-normalization-proof.json')
assert word_delta['tree'] == final_tree and word_delta['source_stable']
assert all(row['exit_code'] == 0 for row in word_delta['results'])
assert normalization['exit_code'] == 0
for row in normalization['files']:
    assert row['base_commit'] == BASE and row['normalized_bytes_identical']
    assert row['before_normalized_sha256'] == row['after_normalized_sha256']
    assert row['before_raw_sha256'] == editor_old[row['path']]['sha256']
    assert row['after_raw_sha256'] == editor_new[row['path']]['sha256']
assert {row['path'] for row in normalization['files']} == {FORMAT_PATHS[0], FORMAT_PATHS[2]}
prior_tree = tree(WORD_PRIOR)
assert prior_tree[FORMAT_PATHS[1]] == new_tree[FORMAT_PATHS[1]]

def disposition(name):
    if name in FORMAT_PATHS:
        return 'Word formatting only; two complete-file normalized equality proofs and one exact prior-qualified test blob.'
    if name == HELPER_PATH:
        return 'Unexecuted-by-Zotero Word test helper gains namespace-aware lookup; separately qualified by five fresh Word cases.'
    return 'Studio Mail host or test change; fresh Studio Zotero regression run and separate Mail feature qualification.'


changed_records = [{
    'path': name,
    'qualified_sha256': editor_old[name]['sha256'],
    'final_sha256': editor_new[name]['sha256'],
    'qualified_blob': old_tree[name], 'final_blob': new_tree[name],
    'disposition': disposition(name),
} for name in changed]
added_records = [{
    'path': name, 'final_sha256': editor_new[name]['sha256'], 'final_blob': new_tree[name],
    'disposition': disposition(name),
} for name in added]

editor_receipt = read_json(LOGS / 'final-editor-combined-receipt.json')
editor_suites = ['packages/' + path.split('/packages/', 1)[1] for path in editor_receipt['per_suite']]
engine_receipt = read_json(LOGS / 'combined-engine-vm-receipt.json')
engine_suites = ['packages/quds_office_engine/' + path for path in engine_receipt['original_files']]
static_files = [row['file'] for row in read_json(LOGS / 'final-editor-combined-static-format.json')]
assert len(editor_suites) == 12 and len(engine_suites) == 36 and len(static_files) == 9
assert all(old_tree[name] == new_tree[name] for name in editor_suites + engine_suites + static_files)

engine_old = read_json(LOGS / 'combined-engine-vm-sources-before.json')
engine_changed = []
runtime_inputs = []
for name, old_sha in engine_old.items():
    if name.startswith('runtime/'):
        runtime_inputs.append(name)
        assert sha((ROOT / name).read_bytes()) == old_sha
    elif old_tree[name] != new_tree[name]:
        assert sha(git('show', f'{BASE}:{name}')) == old_sha
        engine_changed.append(name)
assert set(engine_changed) == set(FORMAT_PATHS + [HELPER_PATH])
engine_scoped_paths = {
    name for name in new_tree
    if (name.startswith(('packages/quds_office_engine/', 'packages/legacy_doc_parser/'))
        or name in ('pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', 'dart_test.yaml'))
    and not name.endswith('.md')
}
assert engine_scoped_paths == set(engine_old) - set(runtime_inputs)

fresh = []
fresh_cases = []
for label in LABELS:
    row = read_json(LOGS / (label + '-receipt.json'))
    assert row['source_commit'] == FINAL and row['source_tree'] == final_tree
    assert row['qualification_passed'] and row['source_input_count'] == len(editor_new)
    fresh.append({
        'label': label, 'source': FINAL, 'tree': final_tree,
        'passed': row['visible_cases'], 'results': row['results'],
        'process_exit': row['exit_code'], 'stderr_bytes': row['stderr_bytes'],
        'terminal_events': row['terminal_events'],
        'source_inputs_unchanged': row['source_inputs_unchanged'],
        'validation_workspace_inputs_unchanged': row['validation_workspace_inputs_unchanged'],
        'runtime_inputs_unchanged': row['runtime_inputs_unchanged'],
    })
    fresh_cases.extend(read_json(LOGS / (label + '-cases.json')))
assert len(fresh_cases) == len({(row['suite'], row['name']) for row in fresh_cases}) == 33

report = {
    'qualified_editor_engine_source': BASE,
    'refreshed_product_source': FINAL, 'refreshed_product_tree': final_tree,
    'retained_editor_cases': 400, 'retained_engine_vm_cases': 977,
    'retained_targeted_node_cases': 148,
    'all_selected_editor_and_engine_test_files_byte_identical': True,
    'executed_editor_files': sorted(editor_suites), 'executed_engine_files': sorted(engine_suites),
    'retained_static_files': sorted(static_files), 'all_nine_static_files_byte_identical': True,
    'editor_original_input_count': len(editor_old),
    'editor_byte_identical_original_inputs': len(editor_old) - len(changed),
    'editor_changed_original_inputs': changed_records,
    'editor_new_inputs': added_records, 'editor_removed_inputs': removed,
    'editor_refreshed_input_count': len(editor_new),
    'engine_original_input_count': len(engine_old),
    'engine_byte_identical_original_inputs': len(engine_old) - len(engine_changed),
    'engine_changed_original_inputs': [row for row in changed_records if row['path'] in engine_changed],
    'engine_runtime_inputs_unchanged': sorted(runtime_inputs),
    'engine_scoped_path_set_unchanged': True,
    'word_format_only_paths': FORMAT_PATHS,
    'word_namespace_test_helper_path': HELPER_PATH,
    'word_delta_local_commit': word_delta['commit'], 'word_delta_tree': word_delta['tree'],
    'word_delta_tree_matches_published_source': True,
    'prior_macro_test_qualified_source': WORD_PRIOR,
    'prior_macro_test_final_blob_identical': True,
    'supporting_word_proof_sha256': sha((WORD_DELTA / 'delta-logs/format-normalization-proof.json').read_bytes()),
    'supporting_word_delta_receipt_sha256': sha((WORD_DELTA / 'delta-receipt.json').read_bytes()),
    'fresh_studio_runs': fresh, 'fresh_studio_unique_cases': 33,
    'retention_accepted_with_explicit_exceptions': True,
    'all_prior_recorded_inputs_byte_identical': False,
    'qualification_limits': [
        '400 editor and 977 engine VM cases were not rerun; they retain their c5cf1ec1 source attribution with the documented exceptions.',
        'The retained targeted Node148 cases overlap native engine cases and are not added to a unique-case total.',
        'The fresh33 Studio cases replace the earlier host regression result for current applicability; prior33 results remain historical and are not added.',
        'Fresh Studio Zotero regressions do not independently establish the new Mail features; the separate Mail owner supplies those gates.',
        'The Word helper change is not formatting; its separate five-case qualification is supporting evidence, not part of the33 Studio count.',
        'No live external Zotero or installed Word/LibreOffice/OpenOffice acceptance is claimed.',
    ],
}
for key in ['qualification_limits']:
    report[key] = [value.replace('Node148', 'Node 148').replace('fresh33', 'fresh 33').replace('prior33', 'prior 33').replace('the33', 'the 33') for value in report[key]]
report_path = RUNTIME / 'studio-main2-scoped-retention.json'
report_path.write_bytes(encoded(report))

members = {}
for label in [*LABELS, 'final-studio-main2']:
    for path in sorted(LOGS.glob(label + '*')):
        if path.is_file():
            members['records/' + path.name] = path.read_bytes()
for name in ['run_final_editor.py', 'run_combined_editor.py', 'run_studio_refresh.py',
             'package_studio_main2_evidence.py', 'env.sh']:
    members['runtime/' + name] = (RUNTIME / name).read_bytes()
for name in ['delta-receipt.json', 'delta-logs/format-normalization-proof.json',
             'delta-logs/fidelity-command.json', 'delta-logs/fidelity-receipt.json',
             'delta-logs/fidelity-cases.json']:
    members['supporting-word/' + name] = (WORD_DELTA / name).read_bytes()
members['scoped-retention.json'] = encoded(report)
members['README.md'] = f'''# Refreshed Studio Zotero qualification and retained scoped gates

Fresh source: `{FINAL}`; tree `{final_tree}`.

Both Studio selections passed: **18 citing-transport cases and 15 shortcuts**,
in separate direct Flutter-snapshot processes. Each exited zero with one
successful terminal, no skipped or unfinished cases, no error events and empty
stderr. All 2,887 source and mirrored inputs and runtime hashes remained stable
through each invocation. Raw receipts, case inventories and manifests are under
`records/`; the runner and environment recipe are under `runtime/`.

`scoped-retention.json` records the complete exceptions relative to the original
`{BASE}` qualification. The editor manifest has 2,871 of 2,884 original inputs
unchanged, 13 changed inputs and three newly added Studio Mail files. The engine
manifest has 2,849 of 2,853 inputs unchanged, with four Word-path differences.
Every selected editor/engine test and all nine Zotero static-check files retain
their exact bytes.

Three Word files differ only in formatting: complete-file Dart 3.12 normalization
proves equality for `word_steps.dart` and the VBA PageSetup test; the macro
PageSetup test is identical to its prior qualified source `{WORD_PRIOR}`.
The compatibility-fidelity helper separately adds namespace-aware lookup and
passed five fresh cases on a local commit with the identical published tree.
Supporting proof and receipts are included without adding those cases to the
33-case Studio result. The new Mail feature gates are supplied separately by
the Mail owner; the Studio Zotero regressions alone do not prove those features.

The 400 editor, 977 native engine and overlapping 148 targeted Node results
retain their original source attribution; they were not broadly rerun. Earlier
Studio receipts and source-applicability reports remain unchanged as history.
This increment claims no live installed-application or external Zotero session.
'''.encode()
manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())}
members['manifest.json'] = encoded(manifest)
archive_path = RUNTIME / 'studio-main2-evidence.tar.xz'
with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(archive_path, 'r:xz') as archive:
    assert set(archive.getnames()) == set(members)
    for name, metadata in manifest.items():
        data = archive.extractfile(name).read()
        assert len(data) == metadata['bytes'] and sha(data) == metadata['sha256']
index = {
    'archive': archive_path.name, 'archive_bytes': archive_path.stat().st_size,
    'archive_sha256': sha(archive_path.read_bytes()), 'member_count': len(members),
    'source_commit': FINAL, 'source_tree': final_tree,
    'fresh_studio_unique_cases': 33, 'all_members_read_back_and_verified': True,
    'members': manifest,
}
(RUNTIME / 'studio-main2-evidence.index.json').write_bytes(encoded(index))
(RUNTIME / 'studio-main2-summary.json').write_bytes(encoded({
    key: report[key] for key in [
        'qualified_editor_engine_source', 'refreshed_product_source', 'refreshed_product_tree',
        'retained_editor_cases', 'retained_engine_vm_cases', 'retained_targeted_node_cases',
        'editor_original_input_count', 'editor_byte_identical_original_inputs',
        'editor_refreshed_input_count', 'engine_original_input_count',
        'engine_byte_identical_original_inputs', 'fresh_studio_runs',
        'fresh_studio_unique_cases', 'qualification_limits',
    ]
}))
print(json.dumps({key: value for key, value in index.items() if key != 'members'}, indent=2))
