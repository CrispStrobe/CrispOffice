import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

REPO = Path('/workspace/scratch/b3c425a3b090/quds_office_suite')
RUNTIME = Path('/workspace/scratch/b3c425a3b090/runtime')
LOGS = RUNTIME / 'logs'
SOURCE = '6ac854de0583b7955470648916c53c76b67c0fff'
TREE = '5bd40fb467d6710987e06634934e84c3dc513bfa'
DART = RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'
FLUTTER = RUNTIME / 'flutter/bin/cache/flutter_tools.snapshot'

def command(*args):
    return subprocess.check_output(args, cwd=REPO, text=True).strip()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write_json(name, value):
    path = LOGS / name
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    return str(path)

def source_manifest():
    rows = subprocess.check_output(
        ['git', 'ls-tree', '-r', '-z', SOURCE], cwd=REPO
    ).decode().split('\0')
    result = {}
    for row in rows:
        if not row:
            continue
        metadata, name = row.split('\t', 1)
        mode, kind, blob = metadata.split()
        if kind != 'blob':
            continue
        path = Path(name)
        if not (
            path.name in ('pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml')
            or (name.startswith('packages/') and (
                '/lib/' in name or '/assets/' in name or '/fonts/' in name
                or (name.startswith((
                    'packages/quds_office_editor/',
                    'packages/quds_office_engine/',
                )) and '/test/' in name)
            ))
        ):
            continue
        data = (REPO / name).read_bytes()
        actual_blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        result[name] = {
            'sha256': digest(data), 'bytes': len(data), 'source_blob': blob,
            'matches_source': actual_blob == blob,
        }
    return result

def suite_summary(log_path):
    events = []
    non_json = []
    for line in log_path.read_text().splitlines():
        try:
            events.append(json.loads(line))
        except ValueError:
            non_json.append(line)
    suites = {
        row['suite']['id']: row['suite']['path']
        for row in events if row.get('type') == 'suite'
    }
    starts = {
        row['test']['id']: row['test']
        for row in events if row.get('type') == 'testStart'
    }
    finished = {
        row['testID']: row
        for row in events if row.get('type') == 'testDone'
    }
    cases = []
    for test_id, end in finished.items():
        if end.get('hidden'):
            continue
        test = starts[test_id]
        cases.append({
            'id': test_id, 'name': test['name'], 'suite': suites.get(test['suiteID']),
            'result': end['result'], 'skipped': end.get('skipped', False),
        })
    tally = collections.Counter()
    per_suite = collections.defaultdict(collections.Counter)
    for case in cases:
        category = 'skipped' if case['skipped'] else case['result']
        tally[category] += 1
        per_suite[case['suite']][category] += 1
    return {
        'visible_cases': len(cases),
        'unique_named_cases': len({(c['suite'], c['name']) for c in cases}),
        'results': dict(tally),
        'per_suite': {key: dict(value) for key, value in per_suite.items()},
        'errors': [row for row in events if row.get('type') == 'error'],
        'terminal_events': [row for row in events if row.get('type') == 'done'],
        'unfinished_test_ids': sorted(set(starts) - set(finished)),
        'non_json_output': non_json,
        'cases': cases,
    }

def run_suite(label, cwd, tests, allow_changed_inputs=()):
    before = source_manifest()
    changed_inputs = sorted(name for name, row in before.items() if not row['matches_source'])
    if set(changed_inputs) - set(allow_changed_inputs):
        raise RuntimeError(f'{label}: source differs from frozen commit')
    before_path = write_json(f'{label}-sources-before.json', before)
    argv = [str(DART), str(FLUTTER), '--no-version-check', 'test', '--no-pub',
            '--reporter=json', '--concurrency=1', *tests]
    log = LOGS / f'{label}.jsonl'
    stderr = LOGS / f'{label}.stderr'
    started = time.time()
    print(f'{label}: starting {len(tests)} test files', flush=True)
    with log.open('w') as output, stderr.open('w') as errors:
        completed = subprocess.run(argv, cwd=cwd, stdout=output, stderr=errors)
    after = source_manifest()
    after_path = write_json(f'{label}-sources-after.json', after)
    summary = suite_summary(log)
    cases_path = write_json(f'{label}-cases.json', summary.pop('cases'))
    receipt = {
        'source_commit': SOURCE, 'source_tree': TREE,
        'head_at_completion': command('git', 'rev-parse', 'HEAD'),
        'argv': argv, 'cwd': str(cwd),
        'runtime': {
            'flutter_version': '3.47.8',
            'flutter_revision': '737ba8f885dc774b53b442759999a312c9461e4e',
            'dart_version': '3.13.7',
            'sdk_archive_sha256': 'baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2',
            'package_config_sha256': digest((RUNTIME / 'workspace/.dart_tool/package_config.json').read_bytes()),
            'lockfile_sha256': digest((RUNTIME / 'workspace/pubspec.lock').read_bytes()),
        },
        'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(started)),
        'duration_seconds': round(time.time() - started, 3),
        'exit_code': completed.returncode,
        'stderr_bytes': stderr.stat().st_size,
        'source_input_count': len(before),
        'source_inputs_unchanged': before == after,
        'all_inputs_match_frozen_commit': all(row['matches_source'] for row in after.values()),
        'permitted_changed_test_inputs': changed_inputs,
        'all_other_inputs_match_frozen_commit': all(row['matches_source'] for name, row in after.items() if name not in allow_changed_inputs),
        'source_manifest_sha256': digest(Path(before_path).read_bytes()),
        'source_manifest_before': before_path, 'source_manifest_after': after_path,
        'log': str(log), 'stderr': str(stderr), 'cases': cases_path,
        **summary,
    }
    write_json(f'{label}-receipt.json', receipt)
    print(json.dumps({
        'suite': label, 'exit_code': completed.returncode,
        'results': summary['results'], 'visible_cases': summary['visible_cases'],
        'errors': len(summary['errors']), 'terminal': summary['terminal_events'],
        'stderr_bytes': receipt['stderr_bytes'],
        'source_inputs_unchanged': receipt['source_inputs_unchanged'],
    }), flush=True)
    return completed.returncode

if __name__ == '__main__':
    editor_tests = [
        'test/word_zotero_multiparagraph_controller_test.dart',
        'test/word_zotero_add_note_controller_test.dart',
        'test/word_zotero_note_target_test.dart',
        'test/word_zotero_note_image_controller_test.dart',
        'test/word_zotero_vertical_table_controller_test.dart',
        'test/word_zotero_citing_controller_test.dart',
        'test/word_zotero_citing_dialog_test.dart',
        'test/word_zotero_direct_command_test.dart',
        'test/word_zotero_bibliography_controller_test.dart',
        'test/word_zotero_rich_controller_test.dart',
        'test/word_zotero_adjacent_citations_controller_test.dart',
        'test/word_cross_paragraph_marker_delete_test.dart',
    ]
    exit_codes = [run_suite('final-editor',
        RUNTIME / 'workspace/packages/quds_office_editor', editor_tests)]
    # Separate invocations keep each Studio fixture's font initialization and
    # test bindings independent while still using the identical frozen source.
    for name in ['citing_transport', 'shortcuts']:
        exit_codes.append(run_suite(f'final-studio-{name}',
            RUNTIME / 'workspace/packages/quds_office_editor/example',
            [f'test/studio_zotero_{name}_test.dart']))
    raise SystemExit(max(exit_codes))
