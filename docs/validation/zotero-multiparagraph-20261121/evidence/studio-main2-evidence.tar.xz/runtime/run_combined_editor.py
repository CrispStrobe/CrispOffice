"""Qualify an explicitly frozen combined source without modifying product files.

Keep run_final_editor.py alongside this runner.  Its original results are
historical evidence; this wrapper writes separate labels and stronger mirror
and runtime checks for the final combined publication source.
"""

import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

import run_final_editor as base


EDITOR_TESTS = [
    'test/word_zotero_multiparagraph_controller_test.dart',
    'test/word_zotero_add_note_controller_test.dart',
    'test/word_zotero_note_target_test.dart',
    'test/word_zotero_note_image_controller_test.dart',
    'test/word_zotero_vertical_table_controller_test.dart',
    'test/word_zotero_citing_controller_test.dart',
    'test/word_zotero_citing_dialog_test.dart',
    'test/word_zotero_direct_command_test.dart',
    'test/word_zotero_bibliography_controller_test.dart',
    'test/word_zotero_rich_controller_test.dart',
    'test/word_zotero_adjacent_citations_controller_test.dart',
    'test/word_cross_paragraph_marker_delete_test.dart',
]
CHANGED_DART_FILES = [
    'packages/quds_office_editor/lib/src/embed/office_controller.dart',
    'packages/quds_office_editor/lib/src/embed/word_zotero_dialog.dart',
    'packages/quds_office_editor/test/word_zotero_add_note_controller_test.dart',
    'packages/quds_office_editor/test/word_zotero_multiparagraph_controller_test.dart',
    'packages/quds_office_editor/test/word_zotero_note_image_controller_test.dart',
    'packages/quds_office_editor/test/word_zotero_citing_dialog_test.dart',
    'packages/quds_office_engine/lib/src/word/model/word_zotero_citing.dart',
    'packages/quds_office_engine/test/word_zotero_multiparagraph_test.dart',
    'packages/quds_office_engine/test/zotero_item_children_test.dart',
]
WORKSPACE = base.RUNTIME / 'workspace'
PACKAGE_CONFIG = WORKSPACE / '.dart_tool/package_config.json'


def digest_file(path):
    return base.digest(path.read_bytes())


def runtime_manifest():
    files = [
        base.DART,
        base.FLUTTER,
        PACKAGE_CONFIG,
        WORKSPACE / 'pubspec.lock',
        base.RUNTIME / 'env.sh',
        Path(__file__),
        Path(base.__file__),
    ]
    return {str(path): digest_file(path) for path in files}


def guard(label):
    head = base.command('git', 'rev-parse', 'HEAD')
    source = base.source_manifest()
    changed = [name for name, item in source.items() if not item['matches_source']]
    if head != base.SOURCE or changed:
        raise RuntimeError(f'{label}: frozen source mismatch: HEAD={head}, changed={changed}')
    mirror = {}
    for name, item in source.items():
        path = WORKSPACE / name
        mirror[name] = {
            'sha256': digest_file(path),
            'resolved_path': str(path.resolve()),
            'matches_source': digest_file(path) == item['sha256'],
        }
    mismatched = [name for name, item in mirror.items() if not item['matches_source']]
    if mismatched:
        raise RuntimeError(f'{label}: validation mirror differs: {mismatched}')
    return {'head': head, 'source': source, 'workspace': mirror, 'runtime': runtime_manifest()}


def write_guard(label, stage, snapshot):
    return {
        kind: base.write_json(f'{label}-{kind}-{stage}.json', snapshot[kind])
        for kind in ['source', 'workspace', 'runtime']
    }


def run_suite(label, cwd, tests):
    before = guard(label)
    before_files = write_guard(label, 'before', before)
    process_exit = base.run_suite(label, cwd, tests)
    after = guard(label)
    after_files = write_guard(label, 'after', after)
    receipt_path = base.LOGS / f'{label}-receipt.json'
    receipt = json.loads(receipt_path.read_text())
    terminal = receipt['terminal_events']
    accepted = (
        process_exit == 0
        and len(terminal) == 1
        and terminal[0].get('success') is True
        and not receipt['errors']
        and not receipt['unfinished_test_ids']
        and not receipt['non_json_output']
        and receipt['results'] == {'success': receipt['visible_cases']}
        and receipt['unique_named_cases'] == receipt['visible_cases']
        and receipt['visible_cases'] > 0
        and receipt['stderr_bytes'] == 0
        and before == after
    )
    receipt.update({
        'head_at_start': before['head'],
        'head_unchanged': before['head'] == after['head'],
        'validation_workspace_inputs_unchanged': before['workspace'] == after['workspace'],
        'runtime_inputs_unchanged': before['runtime'] == after['runtime'],
        'all_validation_workspace_inputs_match_source': True,
        'additional_manifests_before': before_files,
        'additional_manifests_after': after_files,
        'qualification_passed': accepted,
    })
    base.write_json(receipt_path.name, receipt)
    return 0 if accepted else 1


def run_static(label):
    before = guard(label)
    before_files = write_guard(label, 'before', before)
    argv = [str(base.DART), 'analyze', f'--packages={PACKAGE_CONFIG}',
            '--fatal-infos', '--format=machine', *CHANGED_DART_FILES]
    analysis_stdout = base.LOGS / f'{label}-analysis.txt'
    analysis_stderr = base.LOGS / f'{label}-analysis.stderr'
    started = time.time()
    print(f'{label}: starting analysis and no-write format for {len(CHANGED_DART_FILES)} files', flush=True)
    with analysis_stdout.open('w') as output, analysis_stderr.open('w') as errors:
        analysis = subprocess.run(argv, cwd=base.REPO, stdout=output, stderr=errors)
    format_rows = []
    for name in CHANGED_DART_FILES:
        data = (base.REPO / name).read_bytes()
        format_argv = [str(base.DART), 'format', '--language-version=3.12',
                       '--output=none', '--set-exit-if-changed']
        result = subprocess.run(format_argv, cwd=base.RUNTIME, input=data, capture_output=True)
        format_rows.append({
            'file': name, 'input_sha256': base.digest(data),
            'argv': format_argv, 'cwd': str(base.RUNTIME),
            'input_transport': 'stdin; no source file writes',
            'exit_code': result.returncode,
            'stdout': result.stdout.decode(), 'stderr': result.stderr.decode(),
        })
    format_path = base.write_json(f'{label}-format.json', format_rows)
    after = guard(label)
    after_files = write_guard(label, 'after', after)
    accepted = (
        analysis.returncode == 0
        and analysis_stdout.stat().st_size == 0
        and analysis_stderr.stat().st_size == 0
        and all(row['exit_code'] == 0 and row['stderr'] == '' for row in format_rows)
        and before == after
    )
    receipt = {
        'source_commit': base.SOURCE, 'source_tree': base.TREE,
        'head_at_start': before['head'], 'head_at_completion': after['head'],
        'analysis': {'argv': argv, 'cwd': str(base.REPO),
                     'exit_code': analysis.returncode,
                     'stdout': str(analysis_stdout), 'stderr': str(analysis_stderr),
                     'stdout_bytes': analysis_stdout.stat().st_size,
                     'stderr_bytes': analysis_stderr.stat().st_size},
        'format': {'files': len(format_rows), 'language_version': '3.12',
                   'receipt': format_path,
                   'all_exit_zero': all(row['exit_code'] == 0 for row in format_rows)},
        'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(started)),
        'duration_seconds': round(time.time() - started, 3),
        'inputs_unchanged': before == after,
        'manifests_before': before_files, 'manifests_after': after_files,
        'qualification_passed': accepted,
    }
    base.write_json(f'{label}-receipt.json', receipt)
    print(json.dumps({'suite': label, 'analysis_exit': analysis.returncode,
                      'format_files': len(format_rows), 'qualification_passed': accepted}), flush=True)
    return 0 if accepted else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, help='Explicit frozen combined commit, full SHA-1')
    parser.add_argument('--suffix', default='combined', help='Fresh output suffix; never overwrite earlier evidence')
    args = parser.parse_args()
    if not re.fullmatch('[0-9a-f]{40}', args.source):
        parser.error('--source must be a full commit SHA-1')
    if not re.fullmatch('[a-z0-9-]+', args.suffix):
        parser.error('--suffix must use lower-case letters, digits, or hyphens')
    base.SOURCE = args.source
    base.TREE = base.command('git', 'rev-parse', f'{base.SOURCE}^{{tree}}')
    labels = [f'final-editor-{args.suffix}',
              f'final-studio-citing_transport-{args.suffix}',
              f'final-studio-shortcuts-{args.suffix}',
              f'final-editor-{args.suffix}-static']
    for label in labels:
        if (base.LOGS / f'{label}-receipt.json').exists() or (base.LOGS / f'{label}.jsonl').exists():
            parser.error(f'existing evidence would be overwritten: {label}')
    codes = [run_suite(labels[0], WORKSPACE / 'packages/quds_office_editor', EDITOR_TESTS)]
    # Separate processes preserve each Studio fixture's font initialization.
    for label, name in zip(labels[1:3], ['citing_transport', 'shortcuts']):
        codes.append(run_suite(label, WORKSPACE / 'packages/quds_office_editor/example',
                               [f'test/studio_zotero_{name}_test.dart']))
    codes.append(run_static(labels[3]))
    base.write_json(f'final-editor-{args.suffix}-orchestrator.json', {
        'source_commit': base.SOURCE, 'source_tree': base.TREE,
        'labels': labels, 'qualification_exit_codes': codes,
        'all_passed': all(code == 0 for code in codes),
    })
    return max(codes)


if __name__ == '__main__':
    raise SystemExit(main())
