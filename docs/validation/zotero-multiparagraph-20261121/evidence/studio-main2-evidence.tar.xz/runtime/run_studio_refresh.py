"""Run only the two Studio Zotero selections on a new frozen host source."""

import argparse
from pathlib import Path
import re

import run_combined_editor as combined


original_runtime_manifest = combined.runtime_manifest


def runtime_manifest():
    result = original_runtime_manifest()
    result[str(Path(__file__))] = combined.digest_file(Path(__file__))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--suffix', required=True)
    args = parser.parse_args()
    if not re.fullmatch('[0-9a-f]{40}', args.source):
        parser.error('--source must be a full commit SHA-1')
    if not re.fullmatch('[a-z0-9-]+', args.suffix):
        parser.error('--suffix must use lower-case letters, digits, or hyphens')
    base = combined.base
    base.SOURCE = args.source
    base.TREE = base.command('git', 'rev-parse', f'{base.SOURCE}^{{tree}}')
    combined.runtime_manifest = runtime_manifest
    labels = [f'final-studio-{name}-{args.suffix}' for name in ['citing_transport', 'shortcuts']]
    for label in labels:
        if (base.LOGS / f'{label}-receipt.json').exists() or (base.LOGS / f'{label}.jsonl').exists():
            parser.error(f'existing evidence would be overwritten: {label}')
    codes = []
    for label, name in zip(labels, ['citing_transport', 'shortcuts']):
        codes.append(combined.run_suite(
            label,
            combined.WORKSPACE / 'packages/quds_office_editor/example',
            [f'test/studio_zotero_{name}_test.dart'],
        ))
    base.write_json(f'final-studio-{args.suffix}-orchestrator.json', {
        'source_commit': base.SOURCE, 'source_tree': base.TREE,
        'labels': labels, 'qualification_exit_codes': codes,
        'scope': 'Two Studio Zotero suites only after shared host UI changes; no editor or engine rerun.',
        'all_passed': all(code == 0 for code in codes),
    })
    return max(codes)


if __name__ == '__main__':
    raise SystemExit(main())
