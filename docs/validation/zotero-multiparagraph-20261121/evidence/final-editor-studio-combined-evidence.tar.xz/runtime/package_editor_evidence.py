"""Package source-bound editor/Studio receipts without changing the repository."""

import hashlib
import io
import json
from pathlib import Path
import tarfile

RUNTIME = Path('/workspace/scratch/b3c425a3b090/runtime')
LOGS = RUNTIME / 'logs'
SOURCE = 'c5cf1ec11970211597fd16eebdc8d0eaa115278b'
TREE = 'e5744c280f3838d0e6831b925494f3d584908d42'
ARCHIVE = RUNTIME / 'final-editor-studio-combined-evidence.tar.xz'
INDEX = RUNTIME / 'final-editor-studio-combined-evidence.index.json'


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(label):
    return json.loads((LOGS / f'{label}-receipt.json').read_text())


labels = ['final-editor-combined', 'final-studio-citing_transport-combined',
          'final-studio-shortcuts-combined']
receipts = [load(label) for label in labels]
static = load('final-editor-combined-static')
for receipt in [*receipts, static]:
    assert receipt['source_commit'] == SOURCE
    assert receipt['source_tree'] == TREE
    assert receipt['qualification_passed'] is True

all_cases = []
for label in labels:
    all_cases.extend(json.loads((LOGS / f'{label}-cases.json').read_text()))
assert len(all_cases) == len({(case['suite'], case['name']) for case in all_cases})
assert all(case['result'] == 'success' and not case['skipped'] for case in all_cases)

historical = load('final-editor')
repairs = load('final-editor-test-repairs')
summary = {
    'source_commit': SOURCE, 'source_tree': TREE,
    'qualification': {
        label: {key: receipt[key] for key in [
            'visible_cases', 'unique_named_cases', 'results', 'per_suite',
            'exit_code', 'stderr_bytes', 'terminal_events',
            'source_input_count', 'source_inputs_unchanged',
            'all_inputs_match_frozen_commit', 'head_unchanged',
            'validation_workspace_inputs_unchanged', 'runtime_inputs_unchanged',
            'qualification_passed',
        ]} for label, receipt in zip(labels, receipts)
    },
    'final_unique_cases': len(all_cases),
    'static_checks': static,
    'runtime': receipts[0]['runtime'],
    'history_not_added_to_final_totals': {
        'initial_frozen_checkpoint': {
            'source_commit': historical['source_commit'],
            'results': historical['results'],
            'visible_cases': historical['visible_cases'],
            'explanation': 'Two image selection tests expected all cross-paragraph selections to refuse; one dialog test matched the obsolete tooltip. Raw failed events and receipts are retained unchanged.',
        },
        'focused_test_repairs': {
            'baseline_commit': repairs['source_commit'],
            'permitted_changed_test_inputs': repairs['permitted_changed_test_inputs'],
            'results': repairs['results'],
            'visible_cases': repairs['visible_cases'],
            'explanation': 'Replaced obsolete blanket refusals with explicit cross-section, cross-table and cross-field safety cases, updated exact tooltip wording, and fixed one test indentation. This overlapping focused run is historical only.',
        },
    },
    'scope_limits': [
        'Selected local native editor/Studio tests and focused static checks; not a complete repository test run.',
        'No live Zotero desktop or installed Word/LibreOffice/OpenOffice interoperability acceptance is claimed.',
        'No GitHub Actions queue, workflow/check/status endpoint, or hosted CI result was used.',
        'Receipts bind to the stated commit/tree and exact input bytes, not to an unqualified later commit.',
    ],
}

members = {}
for path in sorted([*LOGS.glob('final-editor*'), *LOGS.glob('final-studio*')]):
    if not path.is_file():
        continue
    if '-combined' in path.name:
        phase = 'combined-c5cf1ec1'
    elif path.name.startswith('final-editor-test-repairs'):
        phase = 'historical-focused-test-repairs'
    else:
        phase = 'historical-frozen-6ac854de'
    members[f'records/{phase}/{path.name}'] = path.read_bytes()
for name in ['run_final_editor.py', 'run_combined_editor.py', 'package_editor_evidence.py', 'env.sh', 'README.md']:
    members[f'runtime/{name}'] = (RUNTIME / name).read_bytes()

members['summary.json'] = encoded(summary)
members['README.md'] = f'''# Combined Zotero editor and Studio qualification

Source: `{SOURCE}`; tree `{TREE}`.

The final selection passed **400 editor cases, 18 Studio transport cases and
15 Studio shortcut cases**, totaling **433 distinct suite/name cases** across
14 test files. Each process exited zero with one successful terminal event,
no error events, no skipped or unfinished cases and empty stderr. The direct
Flutter snapshot ran with `--no-version-check --no-pub --reporter=json
--concurrency=1`; Studio fixtures used separate processes.

The 2,884 scoped repository inputs matched this commit. The corresponding
validation workspace bytes, runtime files and HEAD were unchanged before and
after every run. Input manifests, raw events, complete named cases, process
commands and receipts are under `records/combined-c5cf1ec1/`.

Focused `--fatal-infos` analysis passed for nine changed Zotero Dart files with
empty stdout and stderr. All nine passed no-write formatting with explicit
Dart language version 3.12. Static receipts preserve each input SHA-256 and
the exact commands. The namespace-fix owner's separate checks are outside
this package.

`records/historical-frozen-6ac854de/` retains the initial failed editor run:
393 successes, two obsolete blanket-refusal failures and one obsolete-tooltip
error. Its successful Studio runs and the initial indentation-format failure
are also retained. `records/historical-focused-test-repairs/` preserves the
121-case focused repair run and its static checks. These overlapping histories
are not added to the final total and are not relabeled as final-source runs.

This package establishes the selected local behavior only. It does not claim
live Zotero/Word/LibreOffice/OpenOffice acceptance or completion of full parity.
No hosted CI was queried or awaited. The final qualification remains bound to
the commit and byte hashes above, even if later publication adds documentation
or formatting-only changes.

`summary.json` gives the machine-readable result and per-suite counts.
`manifest.json` hashes each other archived member. Original absolute paths in
receipts identify the workspace used; member filenames preserve their basenames.
The two test runner scripts and environment recipe are under `runtime/`.
After restoring the recorded official runtime and linked source workspace,
run `run_combined_editor.py --source {SOURCE} --suffix replay` to write a fresh
set of receipts without overwriting the original evidence.
'''.encode()

manifest = {
    name: {'bytes': len(data), 'sha256': sha(data)}
    for name, data in sorted(members.items())
}
members['manifest.json'] = encoded(manifest)
with tarfile.open(ARCHIVE, 'w:xz', preset=6) as archive:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(ARCHIVE, 'r:xz') as archive:
    assert set(archive.getnames()) == set(members)
    for name, metadata in manifest.items():
        data = archive.extractfile(name).read()
        assert len(data) == metadata['bytes'] and sha(data) == metadata['sha256']
index = {
    'archive': ARCHIVE.name, 'archive_bytes': ARCHIVE.stat().st_size,
    'archive_sha256': sha(ARCHIVE.read_bytes()), 'member_count': len(members),
    'source_commit': SOURCE, 'source_tree': TREE,
    'final_unique_cases': len(all_cases), 'historical_failures_preserved': True,
    'all_members_read_back_and_verified': True, 'members': manifest,
}
INDEX.write_bytes(encoded(index))
(RUNTIME / 'final-editor-studio-combined-summary.json').write_bytes(encoded(summary))
print(json.dumps({key: value for key, value in index.items() if key != 'members'}, indent=2))
