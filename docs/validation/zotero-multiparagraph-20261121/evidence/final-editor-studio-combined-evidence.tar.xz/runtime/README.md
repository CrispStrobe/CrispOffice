# Local Flutter/Dart validation runtime

Official SDK: Flutter 3.47.8 (`737ba8f885dc774b53b442759999a312c9461e4e`), Dart 3.13.7, Linux x64.

Archive: `https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.47.8-stable.tar.xz`

SHA-256: `baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2` (verified before extraction).

The `workspace` directory has copied, unmodified current manifests and lockfile, and live links to repository implementation, tests and fixtures. It therefore observes new product edits immediately without changing the repository's dependency metadata. Dependencies from both the product and Flutter-tools lockfiles were downloaded from official pub.dev archives, individually SHA-256 verified, and resolved offline with `--enforce-lockfile`.

## Environment

```sh
source /workspace/scratch/b3c425a3b090/runtime/env.sh
```

## Engine tests

Working directory: `/workspace/scratch/b3c425a3b090/runtime/workspace/packages/quds_office_engine`

```sh
../../../flutter/bin/cache/dart-sdk/bin/dart \
  --packages=../../.dart_tool/package_config.json \
  ../../../pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart \
  test/word_zotero_citing_test.dart --reporter=json --concurrency=1
```

## Editor tests

Working directory: `/workspace/scratch/b3c425a3b090/runtime/workspace/packages/quds_office_editor`

```sh
../../../flutter/bin/cache/dart-sdk/bin/dart \
  ../../../flutter/bin/cache/flutter_tools.snapshot \
  --no-version-check test --no-pub --reporter=json --concurrency=1 \
  test/word_zotero_note_target_test.dart
```

The official SDK's original Flutter-tools package configuration refers to its build host. Its tools dependencies have been re-resolved offline inside this runtime. This avoids Flutter's otherwise unnecessary online tool bootstrap before test execution. No product dependency or workflow policy was changed.

Initial interrupted Flutter invocations are retained as startup diagnostics in logs. They are not test acceptance. The engine smoke run has a successful terminal event and process exit 0, with 142 visible cases across three original suites; qualification of later implementation edits must be run separately.
