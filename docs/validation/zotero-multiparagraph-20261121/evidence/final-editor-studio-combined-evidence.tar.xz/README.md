# Combined Zotero editor and Studio qualification

Source: `c5cf1ec11970211597fd16eebdc8d0eaa115278b`; tree `e5744c280f3838d0e6831b925494f3d584908d42`.

The final selection passed **400 editor cases, 18 Studio transport cases and
15 Studio shortcut cases**, totaling **433 distinct suite/name cases** across
14 test files. Each process exited zero with one successful terminal event,
no error events, no skipped or unfinished cases and empty stderr. The direct
Flutter snapshot ran with `--no-version-check --no-pub --reporter=json
--concurrency=1`; Studio fixtures used separate processes.

The 2,884 scoped repository inputs matched this commit. The corresponding
validation workspace bytes, runtime files and HEAD were unchanged before and
after every run. Input manifests, raw events, complete named cases, process
commands and receipts are under `records/combined-c5cf1ec1/`.

Focused `--fatal-infos` analysis passed for nine changed Zotero Dart files with
empty stdout and stderr. All nine passed no-write formatting with explicit
Dart language version 3.12. Static receipts preserve each input SHA-256 and
the exact commands. The namespace-fix owner's separate checks are outside
this package.

`records/historical-frozen-6ac854de/` retains the initial failed editor run:
393 successes, two obsolete blanket-refusal failures and one obsolete-tooltip
error. Its successful Studio runs and the initial indentation-format failure
are also retained. `records/historical-focused-test-repairs/` preserves the
121-case focused repair run and its static checks. These overlapping histories
are not added to the final total and are not relabeled as final-source runs.

This package establishes the selected local behavior only. It does not claim
live Zotero/Word/LibreOffice/OpenOffice acceptance or completion of full parity.
No hosted CI was queried or awaited. The final qualification remains bound to
the commit and byte hashes above, even if later publication adds documentation
or formatting-only changes.

`summary.json` gives the machine-readable result and per-suite counts.
`manifest.json` hashes each other archived member. Original absolute paths in
receipts identify the workspace used; member filenames preserve their basenames.
The two test runner scripts and environment recipe are under `runtime/`.
After restoring the recorded official runtime and linked source workspace,
run `run_combined_editor.py --source c5cf1ec11970211597fd16eebdc8d0eaa115278b --suffix replay` to write a fresh
set of receipts without overwriting the original evidence.
