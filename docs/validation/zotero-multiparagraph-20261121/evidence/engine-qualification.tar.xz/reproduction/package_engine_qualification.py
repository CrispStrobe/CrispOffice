from pathlib import Path
import hashlib,json,tarfile,gzip,io,re,collections
root=Path('/workspace/scratch/b3c425a3b090'); rt=root/'runtime'; logs=rt/'logs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prefixes=['final-engine-vm','final-engine-node','combined-engine-vm','combined-engine-node']
records={}; cases_by={}; raw_tests={}
for prefix in prefixes:
 r=json.loads((logs/(prefix+'-receipt.json')).read_text()); process=json.loads((logs/(prefix+'-process.json')).read_text())
 assert process['exit_code']==r['exit_code']
 before=logs/(prefix+'-sources-before.json'); after=logs/(prefix+'-sources-after.json')
 assert before.read_bytes()==after.read_bytes() and r['source_stable']
 assert sha(before)==r['source_manifest_sha256']
 for suffix,key in [('.jsonl','jsonl_sha256'),('.stderr','stderr_sha256'),('-cases.json','cases_sha256')]: assert sha(logs/(prefix+suffix))==r[key]
 es=[json.loads(l) for l in (logs/(prefix+'.jsonl')).read_text().splitlines() if l.strip()]
 starts={e['test']['id']:e['test'] for e in es if e['type']=='testStart'}; suites={e['suite']['id']:e['suite'] for e in es if e['type']=='suite'}
 completed=[e for e in es if e['type']=='testDone']
 assert len(completed)==len(starts)==len({e['testID'] for e in completed})
 terminals=[e for e in es if e['type']=='done']; assert len(terminals)==1
 visible=[e for e in completed if not e.get('hidden',False) and not starts[e['testID']]['name'].startswith('loading ')]
 actual=[]; metadata=[]
 for e in visible:
  t=starts[e['testID']]; p=Path(suites[t['suiteID']]['path']); name=str(p.relative_to(Path(r['cwd']))) if p.is_absolute() else str(p)
  actual.append({'name':t['name'],'file':name,'result':e['result'],'skipped':e['skipped']})
  metadata.append({'file':name,'name':t['name'],'line':t['line'],'column':t['column']})
 saved=json.loads((logs/(prefix+'-cases.json')).read_text()); assert actual==saved
 assert len(actual)==len({(c['file'],c['name']) for c in actual})==r['unique_cases']
 assert sum(c['result']=='success' and not c['skipped'] for c in actual)==r['passed']
 assert sum(c['result']!='success' for c in actual)==r['failed']
 assert sum(e['type']=='error' for e in es)==r['errors']
 assert {c['file'] for c in actual}==set(r['original_files'])
 expected=(1,1,False) if prefix=='final-engine-node' else (0,0,True)
 assert (r['exit_code'],r['failed'],terminals[0]['success'])==expected
 runner=rt/('run_combined_engine.py' if prefix.startswith('combined') else 'run_final_engine.py'); assert sha(runner)==r['runner_sha256']
 records[prefix]=r; cases_by[prefix]=saved; raw_tests[prefix]=metadata
assert records['final-engine-vm']['passed']==977
assert (records['final-engine-node']['passed'],records['final-engine-node']['unique_cases'])==(964,965)
assert records['combined-engine-vm']['passed']==977
assert records['combined-engine-node']['passed']==148
assert records['combined-engine-vm']['head']==records['combined-engine-node']['head']=='c5cf1ec11970211597fd16eebdc8d0eaa115278b'
# Cross-runtime label mapping is explicit and limited to the four existing
# declarations that interpolate runtime-dependent hashCode labels.
selected=set(records['combined-engine-node']['original_files'])
vm=[c for c in cases_by['combined-engine-vm'] if c['file'] in selected]
node=cases_by['combined-engine-node']
pattern=re.compile(r'^(rejects malformed or ambiguous data|damaged native chunk refuses read and replacement|ambiguous or excessive preferences are refused|invalid XML characters cannot be silently replaced) \d+$')
mapping=[]
for file in sorted(selected):
 v=[c for c in vm if c['file']==file]; n=[c for c in node if c['file']==file]; assert len(v)==len(n)
 for ordinal,(a,b) in enumerate(zip(v,n)):
  if a['name']==b['name']: continue
  ma=pattern.fullmatch(a['name']); mb=pattern.fullmatch(b['name'])
  assert file=='test/word_zotero_document_data_test.dart' and ma and mb and ma.group(1)==mb.group(1)
  ta=next(t for t in raw_tests['combined-engine-vm'] if t['file']==file and t['name']==a['name'])
  tb=next(t for t in raw_tests['combined-engine-node'] if t['file']==file and t['name']==b['name'])
  assert (ta['line'],ta['column'])==(tb['line'],tb['column'])
  mapping.append({'file':file,'registration_ordinal_zero_based':ordinal,'source_line':ta['line'],'source_column':ta['column'],'vm_name':a['name'],'node_name':b['name']})
remap={(m['file'],m['node_name']):m['vm_name'] for m in mapping}
assert {(c['file'],c['name']) for c in vm}=={(c['file'],remap.get((c['file'],c['name']),c['name'])) for c in node}
comparison={'head':records['combined-engine-node']['head'],'selected_original_files':sorted(selected),'vm_selected_cases':len(vm),'node_cases':len(node),'explicit_hashCode_label_mapping':mapping,'population_equal_after_source_line_and_registration_mapping':True,'source_manifest_sha256':records['combined-engine-node']['source_manifest_sha256'],'unknown_missing_cases':[],'unknown_extra_cases':[]}
(logs/'combined-engine-population-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
initial_comparison=json.loads((logs/'final-engine-population-comparison.json').read_text()); assert initial_comparison['population_equal_after_explicit_source_registration_mapping']
assert len(initial_comparison['node_excluded_filesystem_cases'])==12
summary={
 'current_source':{'head':records['combined-engine-vm']['head'],'tree':records['combined-engine-vm']['tree'],'source_manifest_sha256':records['combined-engine-vm']['source_manifest_sha256'],'source_input_count':records['combined-engine-vm']['source_files']},
 'current_qualification':{'vm':{'original_suites':36,'unique_cases':977,'passed':977,'failed':0,'skipped':0,'exit_code':0},'node_targeted':{'original_suites':3,'unique_cases':148,'passed':148,'failed':0,'skipped':0,'exit_code':0,'original_files':records['combined-engine-node']['original_files']}},
 'historical_complete_run':{'head':records['final-engine-vm']['head'],'product_reference_head':records['final-engine-vm']['reference_head'],'source_manifest_sha256':records['final-engine-vm']['source_manifest_sha256'],'vm':{'original_suites':36,'unique_cases':977,'passed':977,'failed':0,'exit_code':0},'node':{'original_suites':36,'unique_cases':965,'passed':964,'failed':1,'exit_code':1,'exclusions':records['final-engine-node']['exclusions']}},
 'fixture_diagnosis':{'file':'test/zotero_item_children_test.dart','case':'a malformed or substituted child refuses the entire page','cause':'Dart fixture 12.0 serializes/decodes as a non-int on VM and an integral JSON value on JS. Both runtimes reject12.5.','correction':'Malformed fixture changed to12.5; parser unchanged. The corrected original suite passes on current VM and Node.','diagnostic':'logs/final-engine-numeric-diagnostic.json'},
 'case_identity':{'initial_explicit_mapping':'logs/final-engine-population-comparison.json','current_explicit_mapping':'logs/combined-engine-population-comparison.json','reason':'Four existing document-data test families interpolate hashCode labels. Explicit mappings preserve raw names and match immutable source declarations and registration order.'},
 'initial_vm_reporting_diagnostic':{'accepted':False,'archive_directory':'diagnostics/initial-vm-reporting-error','reason':'Test events ended successfully, but a reporting exception preceded subprocess-exit recording. Preserved only as diagnostic; corrected complete initial VM run has explicit process receipt.'},
 'counting_policy':'Repeated runs and overlapping VM/Node cases are not summed. Current qualification is977 full VM cases and148 targeted Node cases. The historical965-case Node run is retained with its known fixture failure; no full965-case current Node execution is claimed.',
 'all_four_run_inputs_stable':True,'all_started_tests_completed':True,'all_actual_process_exits_recorded':True,'audit':'Each archived run was independently recounted from original machine events, matched to its case inventory and receipt, and checked against before/after source manifests and hashes. No new tests were executed by packaging.',
 'runtime':records['combined-engine-vm']['runtime']}
(logs/'engine-qualification-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
entries={}
for prefix in prefixes:
 for p in sorted(logs.glob(prefix+'*')):
  if p.is_file(): entries['logs/'+p.name]=p
for p in sorted(logs.glob('final-engine-numeric-*')):
 if p.is_file(): entries['logs/'+p.name]=p
for name in ['final-engine-population-comparison.json','combined-engine-population-comparison.json','engine-qualification-summary.json']:
 entries['logs/'+name]=logs/name
for p in sorted((logs/'final-engine-vm-attempt1').iterdir()):
 if p.is_file(): entries['diagnostics/initial-vm-reporting-error/'+p.name]=p
for name in ['run_final_engine.py','run_combined_engine.py','probe_child_numeric.dart','tmp/probe_loader.cjs','package_engine_qualification.py','env.sh','setup/sdk.json','setup/workspace.json','setup/prefetch-101.json','setup/prefetch-135.json','logs/flutter-version.json','logs/flutter-version.stderr']:
 entries['reproduction/'+name]=rt/name
for name in ['.dart_tool/package_config.json','pubspec.lock']:
 p=rt/'workspace'/name
 key='runtime/workspace/'+name
 for prefix in prefixes:
  m=json.loads((logs/(prefix+'-sources-before.json')).read_text()); assert sha(p)==m[key]
 entries['runtime-configuration/'+name.replace('.dart_tool/','')]=p
manifest={name:{'sha256':sha(p),'bytes':p.stat().st_size} for name,p in entries.items()}
index=logs/'engine-qualification-index.json'; index.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
archive=logs/'engine-qualification.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
 for name,path in sorted(entries.items()):
  data=path.read_bytes(); info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0; info.uid=info.gid=0; tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(entries)
 for member in tar:
  data=tar.extractfile(member).read(); assert hashlib.sha256(data).hexdigest()==manifest[member.name]['sha256']
package={'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(entries),'index_sha256':sha(index),'summary_sha256':sha(logs/'engine-qualification-summary.json'),'all_members_verified':True}
(logs/'engine-qualification-package.json').write_text(json.dumps(package,indent=2)+'\n')
print(json.dumps(package,indent=2))
