import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';

Future<void> main() async {
  for (final (label, value) in <(String, Object)>[
    ('integral double 12.0', 12.0),
    ('fractional 12.5', 12.5),
    ('string 12', '12'),
  ]) {
    final child = <String, Object?>{
      'key': 'CHILD001',
      'version': 12,
      'library': {'type': 'user', 'id': 7},
      'data': {
        'key': 'CHILD001',
        'version': value,
        'parentItem': 'SOURCE01',
        'itemType': 'note',
      },
    };
    final body = jsonEncode([child]);
    final decoded = jsonDecode(body) as List;
    final decodedVersion = (decoded.single as Map)['data']['version'];
    final client = ZoteroClient(
      transport: (_) async => ZoteroHttpResponse(statusCode: 200, body: body),
    );
    Object result;
    try {
      final page = await client.itemChildren(ZoteroLibrary.user(7), 'SOURCE01');
      result = {'accepted': true, 'items': page.items.length};
    } on ZoteroApiException catch (e) {
      result = {'accepted': false, 'kind': e.kind.name};
    }
    print(jsonEncode({
      'label': label,
      'inputIsInt': value is int,
      'body': body,
      'decodedIsInt': decodedVersion is int,
      'result': result,
    }));
  }
}
