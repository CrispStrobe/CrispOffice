globalThis.self = globalThis;
require('./probe_child_numeric.js');
