#!/usr/bin/env python3
"""Export one exact commit and run the scoped Word intake gates outside Git."""
import argparse
import base64
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

ROOT = Path('/workspace/scratch/b3c425a3b090')
RUNTIME = ROOT / 'runtime'
SDK = RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'
BASE_CONFIG = RUNTIME / 'workspace/.dart_tool/package_config.json'
TEST_RUNNER = RUNTIME / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
ENGINE = 'packages/quds_office_engine'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def git(repo, *args):
    env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0')
    return subprocess.check_output(['git', *args], cwd=repo, env=env).decode().strip()


def prepare(args):
    repo = Path(args.repo)
    commit = git(repo, 'rev-parse', args.ref + '^{commit}')
    tree = git(repo, 'rev-parse', commit + '^{tree}')
    target = RUNTIME / 'isolated' / args.label
    target.mkdir(parents=True, exist_ok=False)
    workspace = target / 'workspace'
    workspace.mkdir()
    config = json.loads(BASE_CONFIG.read_text())
    tracked = set(git(repo, 'ls-tree', '-r', '--name-only', commit).splitlines())
    scopes = [f'{ENGINE}/lib', f'{ENGINE}/test', f'{ENGINE}/tool',
              f'{ENGINE}/example/macros', 'packages/legacy_doc_parser/lib']
    for package in config['packages']:
        uri = package['rootUri']
        if not uri.startswith('file:'):
            relative = Path(os.path.abspath(BASE_CONFIG.parent / uri)).relative_to(RUNTIME / 'workspace')
            manifest = (relative / 'pubspec.yaml').as_posix()
            if manifest in tracked:
                scopes.append(manifest)
    scopes += [p for p in ['pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
                           'dart_test.yaml', f'{ENGINE}/analysis_options.yaml'] if p in tracked]
    scopes = sorted(set(scopes))
    process = subprocess.Popen(['git', 'archive', '--format=tar', commit, '--', *scopes],
                               cwd=repo, stdout=subprocess.PIPE,
                               env=dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0'))
    with tarfile.open(fileobj=process.stdout, mode='r|') as archive:
        archive.extractall(workspace, filter='data')
    assert process.wait() == 0
    (workspace / '.dart_tool').mkdir()
    write_json(workspace / '.dart_tool/package_config.json', config)
    (workspace / '.dart_tool/package_graph.json').write_bytes(
        (BASE_CONFIG.parent / 'package_graph.json').read_bytes())
    files = {str(p.relative_to(workspace)): sha(p) for p in workspace.rglob('*') if p.is_file()}
    write_json(target / 'sources-before.json', files)
    metadata = {'commit': commit, 'tree': tree, 'source_repository': str(repo),
                'workspace': str(workspace), 'scopes': scopes, 'source_files': len(files),
                'source_manifest_sha256': sha(target / 'sources-before.json'),
                'original_package_config_sha256': sha(BASE_CONFIG),
                'runner_sha256': sha(Path(__file__)),
                'prepared_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'note': 'Exact committed source export; no live repository source symlinks or dependency resolution.'}
    write_json(target / 'prepared.json', metadata)
    print(json.dumps(metadata, indent=2))


def run(args):
    target = RUNTIME / 'isolated' / args.label
    metadata = json.loads((target / 'prepared.json').read_text())
    workspace = target / 'workspace'
    cwd = workspace / ENGINE
    config = workspace / '.dart_tool/package_config.json'
    logs = target / 'logs'
    logs.mkdir(exist_ok=False)
    env = dict(os.environ, FLUTTER_ROOT=str(RUNTIME / 'flutter'),
               PUB_CACHE=str(RUNTIME / 'pub-cache'), CI='true', DART_SUPPRESS_ANALYTICS='true',
               DASH__SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true',
               TMPDIR=str(target / 'tmp'))
    (target / 'tmp').mkdir(exist_ok=True)
    before = json.loads((target / 'sources-before.json').read_text())
    assert all(sha(workspace / path) == digest for path, digest in before.items())
    example = base64.b64encode((cwd / 'example/macros/word_page_setup.bas').read_bytes()).decode()
    define = '-DWORD_PAGE_SETUP_BAS_BASE64=' + example
    test_prefix = [str(SDK), '--packages=' + str(config), str(TEST_RUNNER),
                   '--reporter=json', '--concurrency=2', '--platform=vm']
    javascript = target / 'word-page-setup.js'
    commands = [
        ('page-setup-tests', test_prefix + [
            'test/office_macro_word_page_setup_test.dart',
            'test/office_vba_word_page_setup_test.dart',
            'test/office_vba_word_page_setup_integration_test.dart']),
        ('section-clone', test_prefix + ['test/word_section_clone_fidelity_test.dart']),
        ('section-roundtrip', test_prefix + ['test/word_fidelity_test.dart', '--name=section|columns']),
        ('portable-vm', [str(SDK), '--packages=' + str(config), define,
                         'tool/macros/web_vba_word_page_setup_smoke.dart']),
        ('portable-js-compile', [str(SDK), 'compile', 'js', '--packages=' + str(config), define,
                                'tool/macros/web_vba_word_page_setup_smoke.dart', '-o', str(javascript)]),
        ('portable-node', ['node', '-e', 'globalThis.self = globalThis; require(process.argv[1]);', str(javascript)]),
    ]
    results = []
    for name, command in commands:
        started = time.monotonic()
        write_json(logs / (name + '-command.json'), {'command': command, 'cwd': str(cwd)})
        with (logs / (name + '.stdout')).open('w') as out, (logs / (name + '.stderr')).open('w') as err:
            result = subprocess.run(command, cwd=cwd, env=env, stdout=out, stderr=err)
        receipt = {'name': name, 'exit_code': result.returncode,
                   'elapsed_seconds': time.monotonic() - started,
                   'stdout_sha256': sha(logs / (name + '.stdout')),
                   'stderr_sha256': sha(logs / (name + '.stderr'))}
        if '--reporter=json' in command:
            events = [json.loads(line) for line in (logs / (name + '.stdout')).read_text().splitlines() if line.strip()]
            starts = {e['test']['id']: e['test'] for e in events if e['type'] == 'testStart'}
            suites = {e['suite']['id']: e['suite'] for e in events if e['type'] == 'suite'}
            done = [e for e in events if e['type'] == 'testDone']
            cases = [{'file': suites[starts[e['testID']]['suiteID']]['path'],
                      'name': starts[e['testID']]['name'], 'result': e['result'], 'skipped': e['skipped']}
                     for e in done if not e.get('hidden') and not starts[e['testID']]['name'].startswith('loading ')]
            write_json(logs / (name + '-cases.json'), cases)
            receipt.update(passed=sum(c['result'] == 'success' and not c['skipped'] for c in cases),
                           skipped=sum(c['skipped'] for c in cases), failed=sum(c['result'] != 'success' for c in cases),
                           errors=sum(e['type'] == 'error' for e in events), case_count=len(cases),
                           unique_cases=len({(c['file'], c['name']) for c in cases}),
                           all_started_completed=len(starts) == len(done) == len({e['testID'] for e in done}),
                           terminal=events[-1] if events else None,
                           suite_counts=dict(collections.Counter(c['file'] for c in cases)))
        write_json(logs / (name + '-receipt.json'), receipt)
        results.append(receipt)
        print(json.dumps(receipt), flush=True)
        if result.returncode != 0:
            break
    after = {path: sha(workspace / path) for path in before}
    write_json(target / 'sources-after.json', after)
    summary = dict(metadata, source_stable=before == after, results=results,
                   all_phases_completed=len(results) == len(commands),
                   finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write_json(target / 'receipt.json', summary)
    okay = before == after and len(results) == len(commands) and all(r['exit_code'] == 0 for r in results)
    for receipt in results:
        if 'case_count' in receipt:
            okay &= receipt['case_count'] > 0 and receipt['unique_cases'] == receipt['case_count']
            okay &= not receipt['skipped'] and not receipt['failed'] and not receipt['errors']
            okay &= receipt['all_started_completed'] and bool(receipt['terminal'].get('success'))
    raise SystemExit(0 if okay else 1)


parser = argparse.ArgumentParser()
sub = parser.add_subparsers(dest='action', required=True)
p = sub.add_parser('prepare')
p.add_argument('ref')
p.add_argument('label')
p.add_argument('--repo', default=str(ROOT / 'quds_office_suite'))
p = sub.add_parser('run')
p.add_argument('label')
arguments = parser.parse_args()
{'prepare': prepare, 'run': run}[arguments.action](arguments)
