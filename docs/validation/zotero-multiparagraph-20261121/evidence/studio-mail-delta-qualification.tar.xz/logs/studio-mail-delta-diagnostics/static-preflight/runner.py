from pathlib import Path
import subprocess, json, hashlib, datetime, time

root = Path('/workspace/scratch/b3c425a3b090')
runtime = root / 'runtime'
logs = runtime / 'logs'
prefix = 'studio-mail-delta-static'
source = runtime / 'studio-mail-delta-source'
workspace = runtime / 'studio-mail-delta-workspace'
export = json.loads((runtime / 'setup/studio-mail-delta-export.json').read_text())
dart = runtime / 'flutter/bin/cache/dart-sdk/bin/dart'
repo = root / 'quds_office_suite'
files = subprocess.check_output([
    'git', 'diff-tree', '--no-commit-id', '--name-only', '-r',
    'c25a6ffb1b74673b567cc91eaba0d9d3a2a74345', '--',
    'packages/quds_office_editor/example',
], cwd=repo, text=True).splitlines()
assert len(files) == 12 and all(p.endswith('.dart') for p in files)
assert sum('/lib/' in p for p in files) == 8
assert sum('/test/' in p for p in files) == 4


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    path = logs / (prefix + '-' + name + '.json')
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    return path


def inputs():
    result = {p: sha(source / p) for p in export['files'] if not p.endswith('.md')}
    for p, digest in result.items():
        assert digest == export['files'][p]['sha256'], p
    for p in ['studio-mail-delta-workspace/.dart_tool/package_config.json',
              'studio-mail-delta-workspace/pubspec.lock',
              'flutter/bin/cache/dart-sdk/bin/dart',
              'flutter/bin/cache/dart-sdk/bin/snapshots/analysis_server.dart.snapshot',
              'flutter/bin/cache/dart-sdk/bin/snapshots/dartdev.dart.snapshot']:
        result['runtime/' + p] = sha(runtime / p)
    return result


before = inputs()
before_path = write('inputs-before', before)
command = [str(dart), 'analyze', '--packages=' + str(workspace / '.dart_tool/package_config.json'),
           '--fatal-infos', '--format=machine', *files]
receipt = {
    'head': export['commit'], 'tree': export['tree'],
    'original_files': files, 'file_count': len(files),
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'command': command, 'cwd': str(workspace),
    'source_count': len(before), 'source_manifest_sha256': sha(before_path),
    'dart_version': subprocess.check_output([str(dart), '--version'], text=True).strip(),
    'runner_sha256': sha(Path(__file__)),
}
write('started', receipt)
started = time.monotonic()
stdout = logs / (prefix + '-analysis.stdout')
stderr = logs / (prefix + '-analysis.stderr')
with stdout.open('w') as out, stderr.open('w') as err:
    process = subprocess.run(command, cwd=workspace, stdout=out, stderr=err)
write('analysis-process', {'exit_code': process.returncode, 'elapsed_seconds': time.monotonic() - started})
format_rows = []
for file in files:
    data = (source / file).read_bytes()
    argv = [str(dart), 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed']
    result = subprocess.run(argv, cwd=runtime, input=data, capture_output=True)
    format_rows.append({
        'file': file, 'input_sha256': hashlib.sha256(data).hexdigest(),
        'command': argv, 'cwd': str(runtime), 'input_transport': 'stdin; no source file writes',
        'exit_code': result.returncode, 'stdout': result.stdout.decode(), 'stderr': result.stderr.decode(),
    })
format_path = write('format', format_rows)
after = inputs()
after_path = write('inputs-after', after)
accepted = (process.returncode == 0 and stdout.stat().st_size == stderr.stat().st_size == 0
            and all(r['exit_code'] == 0 and r['stderr'] == '' for r in format_rows) and before == after)
receipt.update(
    analysis_exit_code=process.returncode, analysis_stdout_bytes=stdout.stat().st_size,
    analysis_stderr_bytes=stderr.stat().st_size, analysis_stdout_sha256=sha(stdout),
    analysis_stderr_sha256=sha(stderr), format_language_version='3.12',
    format_files=len(format_rows), format_passed=sum(r['exit_code'] == 0 for r in format_rows),
    format_receipt_sha256=sha(format_path), inputs_stable=before == after,
    source_manifest_after_sha256=sha(after_path), qualification_passed=accepted,
    elapsed_seconds=time.monotonic() - started,
)
write('receipt', receipt)
print(json.dumps(receipt, indent=2))
raise SystemExit(0 if accepted else 1)
