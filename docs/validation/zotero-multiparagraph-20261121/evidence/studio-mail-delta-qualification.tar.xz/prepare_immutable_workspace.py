from pathlib import Path
import subprocess,tarfile,re,hashlib,json,shutil,sys
root=Path('/workspace/scratch/b3c425a3b090'); repo=root/'quds_office_suite'; rt=root/'runtime'
commit=sys.argv[1]; label=sys.argv[2]
assert re.fullmatch('[0-9a-f]{40}',commit) and re.fullmatch('[a-z0-9-]+',label)
source=rt/(label+'-source'); workspace=rt/(label+'-workspace'); assert not source.exists() and not workspace.exists()
source.mkdir(); workspace.mkdir()
paths=['packages','apps','third_party','pubspec.yaml','pubspec.lock','analysis_options.yaml']
p=subprocess.Popen(['git','archive',commit,*paths],cwd=repo,stdout=subprocess.PIPE)
with tarfile.open(fileobj=p.stdout,mode='r|') as archive: archive.extractall(source,filter='data')
assert p.wait()==0
raw=subprocess.check_output(['git','ls-tree','-rz',commit,'--',*paths],cwd=repo)
expected={}
for entry in raw.split(b'\0'):
 if not entry: continue
 info,name=entry.split(b'\t',1); mode,kind,digest=info.decode().split(); name=name.decode()
 if kind!='blob': continue
 file=source/name; content=file.read_bytes(); assert hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()==digest,name
 expected[name]={'mode':mode,'git_blob':digest,'sha256':hashlib.sha256(content).hexdigest()}
members=re.findall(r'^  - (\S+)\s*$',(source/'pubspec.yaml').read_text().split('\nworkspace:\n',1)[1],re.M)
for member in members: (workspace/member).mkdir(parents=True)
for name in ['pubspec.yaml','pubspec.lock']+[m+'/pubspec.yaml' for m in members]: shutil.copy2(source/name,workspace/name)
skip={'.git','.dart_tool','build','pubspec.yaml','pubspec.lock','pubspec_overrides.yaml'}
for member in members:
 for child in (source/member).iterdir():
  target=workspace/member/child.name
  if child.name not in skip and not target.exists() and not target.is_symlink(): target.symlink_to(child,target_is_directory=child.is_dir())
for child in source.iterdir():
 if child.name in skip or child.name in {'packages','apps'}: continue
 target=workspace/child.name
 if not target.exists() and not target.is_symlink(): target.symlink_to(child,target_is_directory=child.is_dir())
for name,item in expected.items(): (source/name).chmod(0o555 if item['mode']=='100755' else 0o444)
for path in sorted(source.rglob('*'),key=lambda p:len(p.parts),reverse=True):
 if path.is_dir(): path.chmod(0o555)
source.chmod(0o555)
asset=workspace/'.dart_tool/hooks_runner/shared/sqlite3/build/download-0a658527/libsqlite3.so'; asset.parent.mkdir(parents=True); shutil.copy2(rt/'downloads/libsqlite3.x64.linux.so',asset)
probe=workspace/'packages/quds_mail_store/build/runtime-preparation/sqlite_probe.dart'; probe.parent.mkdir(parents=True); shutil.copy2(rt/'setup/native/sqlite_probe.dart',probe)
record={'commit':commit,'tree':subprocess.check_output(['git','rev-parse',commit+'^{tree}'],cwd=repo,text=True).strip(),'source':str(source),'workspace':str(workspace),'all_exported_git_blobs_verified':True,'files':expected}
(rt/'setup'/(label+'-export.json')).write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({'commit':commit,'source':str(source),'workspace':str(workspace),'files':len(expected),'members':len(members)}))
