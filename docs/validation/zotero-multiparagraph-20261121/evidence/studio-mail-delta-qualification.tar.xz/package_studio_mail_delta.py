from pathlib import Path
import hashlib, json, tarfile, io, datetime, struct, collections

root = Path('/workspace/scratch/b3c425a3b090')
rt = root / 'runtime'
logs = rt / 'logs'
prefix = 'studio-mail-delta'
head = 'a5dc721dd8e519dde4f019b82a89572fe9f570f4'
tree = 'b3c010249b88c1ae29bce6d901f5c983adf1acf4'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name):
    return json.loads((logs / name).read_text())


def write(name, value):
    path = logs / name
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    return path


r = read(prefix + '-receipt.json')
static = read(prefix + '-static-receipt.json')
retained = read(prefix + '-retained-packages.json')
native = read(prefix + '-native-readiness.json')
assert r['head'] == static['head'] == retained['current_head'] == native['head'] == head
assert r['tree'] == static['tree'] == retained['current_tree'] == tree
assert r['exit_code'] == r['failed'] == r['skipped'] == r['errors'] == 0
assert r['source_stable'] and r['all_started_tests_completed'] and r['terminal_count'] == 1 and r['terminal']['success']
assert r['passed'] == r['unique_cases'] == r['case_count'] == 191
assert (logs / (prefix + '-sources-before.json')).read_bytes() == (logs / (prefix + '-sources-after.json')).read_bytes()
assert r['source_manifest_sha256'] == sha(logs / (prefix + '-sources-before.json'))
for suffix, key in [('.jsonl', 'jsonl_sha256'), ('.stderr', 'stderr_sha256'), ('-cases.json', 'cases_sha256')]:
    assert sha(logs / (prefix + suffix)) == r[key]
events = [json.loads(line) for line in (logs / (prefix + '.jsonl')).read_text().splitlines() if line.strip()]
starts = {e['test']['id']: e['test'] for e in events if e['type'] == 'testStart'}
suites = {e['suite']['id']: e['suite'] for e in events if e['type'] == 'suite'}
done = [e for e in events if e['type'] == 'testDone']
assert len(starts) == len(done) == len({e['testID'] for e in done})
assert sum(e['type'] == 'done' for e in events) == 1 and events[-1]['success']
reconstructed = []
for event in done:
    item = starts[event['testID']]
    if event.get('hidden') or item['name'].startswith('loading '):
        continue
    file = Path(suites[item['suiteID']]['path'])
    if file.is_absolute():
        file = file.relative_to(Path(r['cwd']))
    reconstructed.append({'file': str(file), 'name': item['name'], 'result': event['result'], 'skipped': event['skipped']})
fresh_cases = read(prefix + '-cases.json')
assert reconstructed == fresh_cases
assert static['qualification_passed'] and static['analysis_exit_code'] == 0
assert static['analysis_stdout_bytes'] == static['analysis_stderr_bytes'] == 0
assert static['format_files'] == static['format_passed'] == 12 and static['format_language_version'] == '3.12'
assert static['inputs_stable'] and static['source_manifest_sha256'] == static['source_manifest_after_sha256']
assert native['exit_code'] == 0 and native['inputs_stable'] and native['probe']['fts5'] == 'ready'
assert retained['exact_equality'] and retained['path_sets_equal'] and retained['changed_inputs'] == []
assert retained['total_inputs'] == 499 and retained['retained_unique_passes'] == 314
retained_cases = read(prefix + '-retained-cases.json')
combined_cases = retained_cases + [dict(c, file='packages/quds_office_editor/example/' + c['file']) for c in fresh_cases]
assert len(combined_cases) == len({(c['file'], c['name']) for c in combined_cases}) == 505
assert len({c['file'] for c in combined_cases}) == 18
assert all(c['result'] == 'success' and not c['skipped'] for c in combined_cases)
write(prefix + '-combined-cases.json', combined_cases)

visuals = []
for name, details in sorted(r['screenshots'].items()):
    path = logs / (prefix + '-visuals') / name
    assert sha(path) == details['sha256']
    data = path.read_bytes()
    assert data[:8] == b'\x89PNG\r\n\x1a\n'
    width, height = struct.unpack('>II', data[16:24])
    is_desktop = name.startswith('en-')
    assert (width, height) == ((1350, 1140) if is_desktop else (540, 1140))
    visuals.append({
        'file': prefix + '-visuals/' + name, **details,
        'pixels': [width, height], 'logical_surface': [900, 760] if is_desktop else [360, 760],
        'text_scale': 1.0 if is_desktop else 1.4, 'capture_pixel_ratio': 1.5,
        'state': 'before explicit check' if name.endswith('-check.png') else 'after observation recorded',
        'visual_inspection': 'Inspected full raw capture. Heading and close control remain visible; action or observation card is readable; no horizontal text overflow or overlapping controls observed.',
        'direction': 'RTL' if name.startswith('ar-') else 'LTR',
    })
assert len(visuals) == 6
visual_review = {
    'head': head, 'tree': tree, 'original_test': 'packages/quds_office_editor/example/test/studio_mail_flag_recovery_dialog_test.dart',
    'capture_mechanism': 'Unchanged original test MAIL_RECOVERY_SCREENSHOT_DIR hook, RenderRepaintBoundary toImage(pixelRatio: 1.5).',
    'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'screenshots': visuals,
    'observations': [
        'English desktop shows original uncertain action count unchanged and a separate checked observation after the explicit check.',
        'German compact text and button wrap within the dialog at 1.4 text scale; the full observed subject and status fit within their card.',
        'Arabic compact labels and controls use RTL placement; the full observed subject and status are readable at 1.4 text scale.',
        'Compact captures intentionally show scrolled body states: the original tests call ensureVisible on the check action or observation card. Earlier body text can be above the viewport while the header stays fixed.',
    ],
    'limits': 'Six captured widget-test states, not a live account session or a whole-app accessibility audit. English compact is assertion-tested by the original suite but does not emit a screenshot.',
}
write(prefix + '-visual-review.json', visual_review)

prior_package = read('incoming-mail-xz-package.json')
assert sha(logs / 'incoming-mail-qualification.tar.xz') == prior_package['sha256']
summary = {
    'head': head, 'tree': tree, 'qualification_passed': True,
    'scope': 'Incoming Studio Mail uncertain-action recovery UI and its changed consumers, plus scope-bound retention of unchanged Mail package qualifications.',
    'fresh_tests': {
        'original_files': ['packages/quds_office_editor/example/' + file for file in r['original_files']],
        'unique_cases': 191, 'passed': 191, 'failed': 0, 'skipped': 0, 'errors': 0,
        'suite_counts': r['suite_counts'], 'process_exit_code': 0,
        'all_started_tests_completed': True, 'terminal_success': True,
        'bound_source_and_runtime_inputs': r['source_count'], 'source_manifest_sha256': r['source_manifest_sha256'],
        'inputs_unchanged_during_run': True, 'immutable_export_all_git_blobs_verified': True,
        'receipt': prefix + '-receipt.json',
    },
    'retained_tests': {
        'qualified_commit': retained['qualified_head'], 'unique_cases': 314,
        'gate_passes': retained['retained_gate_passes'], 'exact_input_count': 499,
        'repository_inputs': 491, 'runtime_inputs': 8, 'scope_equal': True,
        'input_manifest_sha256': retained['input_manifest_sha256'],
        'proof': prefix + '-retained-packages.json',
        'historical_raw_evidence_archive': 'incoming-mail-qualification.tar.xz',
        'historical_raw_evidence_archive_sha256': prior_package['sha256'],
    },
    'applicable_population': {
        'unique_cases': 505, 'passed': 505, 'unique_original_files': 18,
        'failed': 0, 'skipped_test_cases': 0, 'errors': 0,
        'calculation': '314 unchanged package cases retained by exact inputs + 191 freshly executed Studio cases. The earlier 18 Studio cases are replaced, never added again. Historical 332 remains a source-specific record.',
        'combined_case_index': prefix + '-combined-cases.json',
    },
    'static_checks': {
        'original_changed_files': static['original_files'], 'file_count': 12,
        'analysis_fatal_infos': True, 'analysis_exit_code': 0,
        'analysis_output_bytes': 0, 'format_declared_language_version': '3.12',
        'format_unchanged_files': 12, 'format_writes': False,
        'bound_source_and_runtime_inputs': static['source_count'], 'inputs_stable': True,
        'receipt': prefix + '-static-receipt.json',
    },
    'native_sqlite': {
        'library_sha256': r['native_sqlite_sha256'], 'version': native['probe']['sqlite3'],
        'fts5_probe': native['probe']['fts5'], 'readiness_process_exit_code': 0,
        'uses_official_sqlite3_3_9_1_default_hook_asset': True,
        'receipt': prefix + '-native-readiness.json',
    },
    'visual_review': {'raw_pngs': 6, 'inspection_record': prefix + '-visual-review.json'},
    'runtime': r['runtime'],
    'diagnostics': [{'accepted': False, 'path': prefix + '-diagnostics/static-preflight', 'detail': 'Scratch runner initially named a nonexistent dartdev snapshot while sealing inputs. It failed before analyzer/formatter execution; corrected to actual AOT snapshot. Original runner and error preserved, no product or test edits.'}],
    'limits': 'Provider responses are synthetic. Native SQLite is real. This is an affected-scope qualification, not the unrelated full repository suite or a live network/account test. No GitHub Actions used.',
}
summary_path = write(prefix + '-summary.json', summary)
entries = {}
excluded = {prefix + '-qualification.tar.xz', prefix + '-archive-index.json', prefix + '-xz-package.json', prefix + '-package-run.log'}
for path in sorted(logs.glob(prefix + '*')):
    if path.name in excluded:
        continue
    if path.is_file():
        entries['logs/' + path.name] = path
    elif path.is_dir():
        for child in sorted(path.rglob('*')):
            if child.is_file():
                entries['logs/' + str(child.relative_to(logs))] = child
for name in [
    'prepare_immutable_workspace.py', 'run_studio_mail_delta.py', 'run_studio_mail_delta_static.py',
    'verify_mail_package_retention.py', 'package_studio_mail_delta.py', 'env.sh',
    'setup/studio-mail-delta-export.json', 'setup/sqlite-download.json', 'setup/native/sqlite_probe.dart',
    'setup/sdk.json', 'setup/prefetch-135.json', 'setup/prefetch-101.json', 'logs/flutter-version.json',
]:
    entries[name] = rt / name
for name in ['.dart_tool/package_config.json', '.dart_tool/native_assets.yaml', 'pubspec.lock']:
    entries['runtime-configuration/' + name.replace('.dart_tool/', '')] = rt / 'studio-mail-delta-workspace' / name
for name in ['incoming-mail-xz-package.json', 'incoming-mail-archive-index.json', 'incoming-mail-summary.json',
             'incoming-mail-store-sources-before.json', *['incoming-mail-' + gate + '-receipt.json' for gate in ['store', 'transport', 'core', 'ui', 'unsupported']]]:
    entries['historical-reference/' + name] = logs / name
index = {name: {'sha256': sha(path), 'bytes': path.stat().st_size} for name, path in sorted(entries.items())}
index_path = write(prefix + '-archive-index.json', index)
archive = logs / (prefix + '-qualification.tar.xz')
assert not archive.exists(), 'Do not overwrite prior evidence archives.'
with tarfile.open(archive, 'w:xz', preset=9) as tar:
    for name, path in sorted(entries.items()):
        data = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        info.uid = info.gid = 0
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as tar:
    assert len(tar.getmembers()) == len(index)
    for member in tar:
        data = tar.extractfile(member).read()
        assert len(data) == index[member.name]['bytes']
        assert hashlib.sha256(data).hexdigest() == index[member.name]['sha256']
package = {
    'archive': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size,
    'members': len(index), 'member_index': index_path.name, 'member_index_sha256': sha(index_path),
    'summary': summary_path.name, 'summary_sha256': sha(summary_path),
    'verified_all_member_hashes_and_sizes': True, 'contains_source_or_runtime_binaries': False,
    'contains_raw_screenshot_pngs': True, 'head': head, 'tree': tree,
    'applicable_unique_passes': 505, 'fresh_unique_passes': 191, 'retained_unique_passes': 314,
}
write(prefix + '-xz-package.json', package)
print(json.dumps(package, indent=2))
