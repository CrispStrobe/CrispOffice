from pathlib import Path
import subprocess,json,hashlib,datetime,sys
root=Path('/workspace/scratch/b3c425a3b090'); repo=root/'quds_office_suite'; rt=root/'runtime'; logs=rt/'logs'; final=sys.argv[1]
qualified='6c180d7e805b49663fda32fcf9c5c92e0ae2d86e'
original=json.loads((logs/'incoming-mail-store-sources-before.json').read_text())
excluded=[p for p in original if p.startswith('packages/quds_office_editor/example/')]
expected={p:h for p,h in original.items() if p not in excluded}; repository=sorted(p for p in expected if not p.startswith('runtime/')); runtime=sorted(p for p in expected if p.startswith('runtime/'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prefixes=['packages/quds_mail_core/','packages/quds_mail_mime/','packages/quds_mail_store/','packages/quds_mail_transport/','packages/quds_mail_ui/','third_party/enough_mail/']; individual=['pubspec.yaml','pubspec.lock','analysis_options.yaml']
raw=subprocess.check_output(['git','ls-tree','-rz',final,'--',*prefixes,*individual],cwd=repo)
objects={}
for entry in raw.split(b'\0'):
 if not entry: continue
 info,path=entry.split(b'\t',1); mode,kind,digest=info.decode().split(); path=path.decode()
 if kind=='blob' and not path.endswith('.md'): objects[path]=digest
assert set(objects)==set(repository),(set(objects)-set(repository),set(repository)-set(objects))
request=''.join(final+':'+p+'\n' for p in repository).encode(); response=subprocess.run(['git','cat-file','--batch'],input=request,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
position=0; actual={}; per_file={}
for p in repository:
 end=response.index(b'\n',position); digest,kind,size=response[position:end].decode().split(); assert kind=='blob'; size=int(size); start=end+1; content=response[start:start+size]; assert response[start+size:start+size+1]==b'\n'; position=start+size+1
 actual[p]=hashlib.sha256(content).hexdigest(); assert digest==objects[p]
 per_file[p]={'qualified_sha256':expected[p],'current_git_blob':digest,'current_sha256':actual[p],'matches':actual[p]==expected[p]}
assert position==len(response)
for p in runtime:
 actual[p]=sha(root/p); per_file[p]={'qualified_sha256':expected[p],'current_sha256':actual[p],'matches':actual[p]==expected[p]}
changed=[p for p in expected if expected[p]!=actual[p]]; assert not changed,changed
selection=['store','transport','core','ui','unsupported']; cases=[]
for gate in selection:
 r=json.loads((logs/f'incoming-mail-{gate}-receipt.json').read_text()); assert r['exit_code']==r['failed']==r['errors']==0 and r['source_stable']
 cases+=json.loads((logs/f'incoming-mail-{gate}-cases.json').read_text())
assert len(cases)==len({(c['file'],c['name']) for c in cases})==314
for p in [logs/'studio-mail-delta-retained-inputs.json',logs/'studio-mail-delta-retained-input-comparison.json',logs/'studio-mail-delta-retained-cases.json']:
 data=actual if 'retained-inputs' in p.name else per_file if 'comparison' in p.name else cases
 p.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
report={'qualified_head':qualified,'current_head':final,'current_tree':subprocess.check_output(['git','rev-parse',final+'^{tree}'],cwd=repo,text=True).strip(),'scope':'Mail packages, their source/fixtures, third_party/enough_mail, root manifests, and original native validation runtime. The prior Studio example consumer is excluded and replaced by fresh delta execution.','repository_inputs':len(repository),'runtime_inputs':len(runtime),'total_inputs':len(expected),'path_sets_equal':True,'changed_inputs':[],'exact_equality':True,'removed_from_retention_scope':excluded,'retained_unique_passes':314,'retained_gate_passes':{'store':83,'transport_vm':163,'core':28,'ui':34,'unsupported_js':6},'old_studio_18_cases_not_retained_or_added':True,'cases_sha256':sha(logs/'studio-mail-delta-retained-cases.json'),'input_manifest_sha256':sha(logs/'studio-mail-delta-retained-inputs.json'),'input_comparison_sha256':sha(logs/'studio-mail-delta-retained-input-comparison.json'),'no_new_package_test_execution':True,'verifier_sha256':sha(Path(__file__)),'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(logs/'studio-mail-delta-retained-packages.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report,indent=2))
