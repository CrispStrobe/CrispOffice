from pathlib import Path
import subprocess,json,hashlib,time,datetime,collections
root=Path('/workspace/scratch/b3c425a3b090'); rt=root/'runtime'; logs=rt/'logs'; label='studio-mail-delta'
source=rt/(label+'-source'); workspace=rt/(label+'-workspace'); prefix=label
export=json.loads((rt/'setup'/(label+'-export.json')).read_text())
files=['test/studio_mail_flag_reconciliation_test.dart','test/studio_mail_flag_recovery_dialog_test.dart','test/studio_mail_journal_host_test.dart','test/studio_mail_message_loader_test.dart','test/studio_mail_remote_images_incoming_test.dart']
cwd=workspace/'packages/quds_office_editor/example'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=sorted(p for p in export['files'] if not p.endswith('.md'))
def inputs():
 result={p:sha(source/p) for p in paths}
 for p in paths: assert result[p]==export['files'][p]['sha256'],p
 for p in [label+'-workspace/.dart_tool/package_config.json',label+'-workspace/.dart_tool/native_assets.yaml',label+'-workspace/.dart_tool/lib/libsqlite3.so',label+'-workspace/pubspec.lock','flutter/bin/cache/dart-sdk/bin/dart','flutter/bin/cache/flutter_tools.snapshot','flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester']:
  result['runtime/'+p]=sha(rt/p)
 return result
assert sha(workspace/'.dart_tool/lib/libsqlite3.so')=='0a65852703763619a7a34633b4959b3b86c4103804a4dfe4e8b27b5de1c0647b'
before=inputs(); before_path=logs/(prefix+'-sources-before.json'); before_path.write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
visuals=logs/(prefix+'-visuals'); visuals.mkdir(exist_ok=True)
cmd=[str(rt/'flutter/bin/cache/dart-sdk/bin/dart'),str(rt/'flutter/bin/cache/flutter_tools.snapshot'),'--no-version-check','test','--no-pub','--reporter=json','--concurrency=1','--dart-define=MAIL_RECOVERY_SCREENSHOT_DIR='+str(visuals),*files]
receipt={'command':cmd,'cwd':str(cwd),'head':export['commit'],'tree':export['tree'],'immutable_git_blob_verified_export':True,'original_files':files,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_count':len(before),'source_manifest_sha256':sha(before_path),'runtime':json.loads((logs/'flutter-version.json').read_text()),'pubspec_lock_sha256':sha(source/'pubspec.lock'),'native_sqlite_sha256':sha(workspace/'.dart_tool/lib/libsqlite3.so'),'runner_sha256':sha(Path(__file__)),'visual_capture_directory':str(visuals)}
(logs/(prefix+'-started.json')).write_text(json.dumps(receipt,indent=2)+'\n')
start=time.monotonic()
with (logs/(prefix+'.jsonl')).open('w') as out,(logs/(prefix+'.stderr')).open('w') as err: result=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=err,check=False)
(logs/(prefix+'-process.json')).write_text(json.dumps({'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n')
after=inputs(); (logs/(prefix+'-sources-after.json')).write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
events=[json.loads(l) for l in (logs/(prefix+'.jsonl')).read_text().splitlines() if l.strip()]
starts={e['test']['id']:e['test'] for e in events if e['type']=='testStart'}; suites={e['suite']['id']:e['suite'] for e in events if e['type']=='suite'}
completed=[e for e in events if e['type']=='testDone']; visible=[e for e in completed if not e.get('hidden',False) and not starts[e['testID']]['name'].startswith('loading ')]
cases=[]
for e in visible:
 t=starts[e['testID']]; p=Path(suites[t['suiteID']]['path']); name=str(p.relative_to(cwd)) if p.is_absolute() else str(p)
 cases.append({'file':name,'name':t['name'],'result':e['result'],'skipped':e['skipped']})
(logs/(prefix+'-cases.json')).write_text(json.dumps(cases,indent=2)+'\n')
receipt.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,source_stable=before==after,source_changes=[p for p in before.keys()|after.keys() if before.get(p)!=after.get(p)],passed=sum(c['result']=='success' and not c['skipped'] for c in cases),skipped=sum(c['skipped'] for c in cases),failed=sum(c['result']!='success' for c in cases),errors=sum(e['type']=='error' for e in events),unique_cases=len({(c['file'],c['name']) for c in cases}),case_count=len(cases),suite_counts=dict(collections.Counter(c['file'] for c in cases)),all_started_tests_completed=len(starts)==len(completed)==len({e['testID'] for e in completed}),terminal_count=sum(e['type']=='done' for e in events),terminal=events[-1] if events else None,jsonl_sha256=sha(logs/(prefix+'.jsonl')),stderr_sha256=sha(logs/(prefix+'.stderr')),cases_sha256=sha(logs/(prefix+'-cases.json')),screenshots={str(p.relative_to(visuals)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in visuals.rglob('*.png')})
(logs/(prefix+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['head','tree','exit_code','passed','failed','skipped','errors','unique_cases','suite_counts','source_stable','source_manifest_sha256','all_started_tests_completed','terminal_count','terminal']},indent=2))
raise SystemExit(0 if result.returncode==0 and receipt['source_stable'] and receipt['failed']==receipt['errors']==0 and receipt['all_started_tests_completed'] and receipt['terminal_count']==1 and receipt['terminal'] and receipt['terminal'].get('success') else 1)
