#!/usr/bin/env python3
"""Qualify only the changed section fidelity suite and formatting deltas."""
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/b3c425a3b090')
RUNTIME = ROOT / 'runtime'
REPO = ROOT / 'quds_office_integration'
TARGET = RUNTIME / 'isolated/main2-fidelity-reproduce'
WORKSPACE = TARGET / 'workspace'
SDK = RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'
TEST_RUNNER = RUNTIME / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
CONFIG = WORKSPACE / '.dart_tool/package_config.json'
CWD = WORKSPACE / 'packages/quds_office_engine'
BASE = 'c5cf1ec11970211597fd16eebdc8d0eaa115278b'
HEAD = 'a5dc721dd8e519dde4f019b82a89572fe9f570f4'
CHANGED = [
    'lib/src/automation/operations/word_steps.dart',
    'test/office_vba_word_page_setup_test.dart',
    'test/word_compatibility_fidelity_test.dart',
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


logs = TARGET / 'delta-logs'
logs.mkdir(exist_ok=False)
before = json.loads((TARGET / 'sources-before.json').read_text())
assert all(sha(WORKSPACE / path) == digest for path, digest in before.items())
normalization = []
scratch = TARGET / 'format-proof'
for path in CHANGED[:2]:
    item = {'path': 'packages/quds_office_engine/' + path, 'base_commit': BASE, 'target_commit': HEAD}
    for name, ref in [('before', BASE), ('after', HEAD)]:
        dest = scratch / name / Path(path).name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(subprocess.check_output(['git', 'show', ref + ':' + item['path']], cwd=REPO))
        item[name + '_raw_sha256'] = sha(dest)
    normalization.append(item)
copies = [str(p) for p in sorted(scratch.rglob('*.dart'))]
normalize_command = [str(SDK), 'format', '--language-version=3.12', *copies]
normalize = subprocess.run(normalize_command, cwd=scratch, text=True, capture_output=True)
(logs / 'normalization.stdout').write_text(normalize.stdout)
(logs / 'normalization.stderr').write_text(normalize.stderr)
assert normalize.returncode == 0
for item in normalization:
    name = Path(item['path']).name
    item['before_normalized_sha256'] = sha(scratch / 'before' / name)
    item['after_normalized_sha256'] = sha(scratch / 'after' / name)
    item['normalized_bytes_identical'] = (scratch / 'before' / name).read_bytes() == (scratch / 'after' / name).read_bytes()
    assert item['normalized_bytes_identical'], item
write(logs / 'format-normalization-proof.json', {
    'command': normalize_command,
    'exit_code': normalize.returncode,
    'formatter_language_version': '3.12',
    'dart_version': subprocess.check_output([str(SDK), '--version'], text=True).strip(),
    'files': normalization,
    'conclusion': 'Both complete files are byte-identical after the same declared-language formatter; incoming differences are formatting only.',
})
env = dict(os.environ, FLUTTER_ROOT=str(RUNTIME / 'flutter'), PUB_CACHE=str(RUNTIME / 'pub-cache'),
           TMPDIR=str(TARGET / 'tmp'), CI='true', DART_SUPPRESS_ANALYTICS='true',
           DASH__SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true')
(TARGET / 'tmp').mkdir(exist_ok=True)
commands = [
    ('format', [str(SDK), 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed', *CHANGED]),
    *[(f'analyze-{i}', [str(SDK), 'analyze', '--fatal-infos', path]) for i, path in enumerate(CHANGED)],
    ('fidelity', [str(SDK), '--packages=' + str(CONFIG), str(TEST_RUNNER), '--reporter=json',
                  '--concurrency=2', '--platform=vm', CHANGED[2]]),
]
results = []
for name, command in commands:
    write(logs / (name + '-command.json'), {'command': command, 'cwd': str(CWD)})
    start = time.monotonic()
    with (logs / (name + '.stdout')).open('w') as out, (logs / (name + '.stderr')).open('w') as err:
        result = subprocess.run(command, cwd=CWD, env=env, stdout=out, stderr=err)
    receipt = {'name': name, 'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - start,
               'stdout_sha256': sha(logs / (name + '.stdout')), 'stderr_sha256': sha(logs / (name + '.stderr'))}
    if name == 'fidelity':
        events = [json.loads(line) for line in (logs / (name + '.stdout')).read_text().splitlines() if line.strip()]
        starts = {e['test']['id']: e['test'] for e in events if e['type'] == 'testStart'}
        suites = {e['suite']['id']: e['suite'] for e in events if e['type'] == 'suite'}
        done = [e for e in events if e['type'] == 'testDone']
        cases = [{'file': suites[starts[e['testID']]['suiteID']]['path'], 'name': starts[e['testID']]['name'],
                  'result': e['result'], 'skipped': e['skipped']}
                 for e in done if not e.get('hidden') and not starts[e['testID']]['name'].startswith('loading ')]
        write(logs / 'fidelity-cases.json', cases)
        receipt.update(passed=sum(c['result'] == 'success' and not c['skipped'] for c in cases),
                       skipped=sum(c['skipped'] for c in cases), failed=sum(c['result'] != 'success' for c in cases),
                       errors=sum(e['type'] == 'error' for e in events), case_count=len(cases),
                       unique_cases=len({(c['file'], c['name']) for c in cases}),
                       all_started_completed=len(starts) == len(done) == len({e['testID'] for e in done}),
                       terminal=events[-1] if events else None)
    write(logs / (name + '-receipt.json'), receipt)
    results.append(receipt)
    print(json.dumps(receipt), flush=True)
    if result.returncode != 0:
        break
after = {path: sha(WORKSPACE / path) for path in before}
write(TARGET / 'delta-sources-after.json', after)
summary = {'commit': HEAD, 'tree': json.loads((TARGET / 'prepared.json').read_text())['tree'],
           'input_count': len(before), 'source_stable': before == after, 'results': results,
           'all_phases_completed': len(results) == len(commands), 'normalization_proof': 'delta-logs/format-normalization-proof.json',
           'runner_sha256': sha(Path(__file__)),
           'qualification_scope': 'Changed Word compatibility fidelity suite, three-file static checks, and full-file formatting normalization only; no full-suite repetition.'}
write(TARGET / 'delta-receipt.json', summary)
okay = before == after and len(results) == len(commands) and all(r['exit_code'] == 0 for r in results)
if results[-1]['name'] == 'fidelity':
    r = results[-1]
    okay &= r['case_count'] > 0 and r['case_count'] == r['unique_cases'] and not r['failed'] and not r['skipped'] and not r['errors']
    okay &= r['all_started_completed'] and bool(r['terminal'].get('success'))
raise SystemExit(0 if okay else 1)
