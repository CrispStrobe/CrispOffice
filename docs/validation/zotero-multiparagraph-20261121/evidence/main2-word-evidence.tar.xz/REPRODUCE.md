# Scoped refreshed-main Word validation

The executed runner and raw commands preserve the exact local run. The published commit has the identical tree, verified in source-applicability.json. The companion reproducer substitutes the durable published commit for the local merge ID.

Using the same restored runtime, prepare an isolated export with `runners/prepare_word_export.py prepare a5dc721dd8e519dde4f019b82a89572fe9f570f4 main2-fidelity-reproduce --repo /path/to/checkout`, then run `runners/reproduce_main2_fidelity.py`. Update the workspace/runtime roots in these scripts when reproducing elsewhere. No dependency resolution, remote changes or CI requests are performed.

The archive contains commands, raw events, case inventories, normalization hashes, manifests and receipts. It excludes exported workspaces, temporary formatting copies and SDK binaries. The five compatibility-fidelity cases are additional to the earlier 156-case Word population; the broad suites were not repeated.
