from pathlib import Path
import datetime, hashlib, json, os, subprocess, time
root = Path('/workspace/scratch/12e9ca120c75/quds_office_suite')
out = root.parent/'separator-layout-validation'
paths = [
'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
'packages/quds_office_engine/lib/src/word/layout/word_note_layout.dart',
'packages/quds_office_engine/lib/src/word/model/word_notes.dart',
'packages/quds_office_engine/lib/src/word/model/wml_document.dart',
'packages/quds_office_editor/lib/src/editor_word/render_word_canvas.dart',
'packages/quds_office_engine/test/word_footnote_separator_layout_test.dart',
'packages/quds_office_editor/test/word_footnote_separator_render_test.dart',
'pubspec.lock',
]
def hashes():
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
initial=hashes()
commands=[
('engine-layout-and-legacy',[str(root.parent/'runtime/bin/dart'),'--packages=.dart_tool/package_config.json',str(root.parent/'runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),
'packages/quds_office_engine/test/word_footnote_separator_layout_test.dart',
'packages/quds_office_engine/test/rich_note_test.dart',
'packages/quds_office_engine/test/note_separator_fidelity_test.dart',
'packages/quds_office_engine/test/word_footnote_reference_test.dart',
'packages/quds_office_engine/test/word_note_numbering_test.dart',
'packages/quds_office_engine/test/word_incremental_layout_test.dart',
'--reporter','json']),
('editor-render-and-history',[str(root.parent/'runtime/bin/flutter'),'test','--no-pub',
'packages/quds_office_editor/test/word_footnote_separator_render_test.dart',
'packages/quds_office_editor/test/word_notes_editing_test.dart',
'packages/quds_office_editor/test/word_note_numbering_test.dart',
'--reporter','json']),
]
records=[]
for name, command in commands:
 cwd = root/'packages'/('quds_office_engine' if name.startswith('engine') else 'quds_office_editor')
 command = [arg.replace('--packages=.dart_tool/package_config.json', '--packages='+str(root/'.dart_tool/package_config.json')).replace('packages/'+cwd.name+'/', '') for arg in command]
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 print('Running '+name,flush=True)
 with (out/(name+'.jsonl')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(command,cwd=cwd,stdout=stdout,stderr=stderr,env=os.environ,timeout=600)
 records.append({'name':name,'command':command,'cwd':str(cwd),'started_at':started,'exit_code':result.returncode,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 (out/'receipt.json').write_text(json.dumps({'runs':records,'selected_inputs_before':initial,'selected_inputs_after':hashes(),'note':'Selected input fingerprints only; root performs complete final-source qualification.'},indent=2)+'\n')
 print('Completed '+name+' exit='+str(result.returncode),flush=True)
 if result.returncode:
  print((out/(name+'.stderr')).read_text()[-5000:],flush=True)
