# Development and superseded qualification evidence

These runs are retained for provenance and are not added to final accepted counts.

- The initial full engine run at 434bad5 has 2659 passes and one stale test assertion error. Exact starting-source reproduction proves incoming e65ce54 empty-run preservation already produced the extra ordinary empty run. The corrected assertion preserves the unique linked inline picture checks and explicitly checks the ordinary empty packet.
- The initial editor aggregate was interrupted with exit 130 after about four and a half minutes without new events while two suites loaded. Its partial stream receives no acceptance credit. The final run uses five smaller batches of the same 55 suites.
- Initial Studio, analysis and formatting passes used a narrower 2449-file input manifest. Final executions use the expanded complete tracked workspace manifest and supersede these runs.
- Targeted native and layout logs include development attempts, wrong-working-directory fixture lookup errors and the first legacy golden mismatch. The legacy visual mismatch was fixed by keeping the established legacy editor rule thickness separate from modeled filled rectangles; no golden baseline was changed.
- Later targeted passes support debugging, but overlapping runs are never summed into final qualification.

SHA256SUMS identifies every file except itself. The main work record and final gate receipts define accepted scope.
