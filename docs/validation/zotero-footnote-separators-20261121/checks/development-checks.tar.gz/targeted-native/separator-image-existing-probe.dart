import 'dart:convert';
import 'dart:typed_data';

import 'package:image/image.dart' as img;
import 'package:quds_office_engine/quds_office_engine.dart';


const _docId = 'zotero-image-integration';
const _first = '<a href="https://www.zotero.org/?FIRST1">(old first)</a>';
const _second = '<a href="https://www.zotero.org/?SECOND2">(old second)</a>';

Uint8List _picture({bool jpeg = false}) {
  final raster = img.Image(width: 8, height: 4, numChannels: 3);
  for (var y = 0; y < raster.height; y++) {
    for (var x = 0; x < raster.width; x++) {
      raster.setPixelRgb(x, y, x * 30, y * 60, 120);
    }
  }
  return Uint8List.fromList(
    jpeg ? img.encodeJpg(raster, quality: 95) : img.encodePng(raster),
  );
}

String _image(Uint8List bytes, {bool jpeg = false, String extra = ''}) =>
    '<img src="data:image/${jpeg ? 'jpeg' : 'png'};base64,${base64Encode(bytes)}" '
    'width="96" height="48" alt="Diagram &amp; detail" title="Research image" $extra>';

String _preferences(int noteType) => jsonEncode({
  'dataVersion': 4,
  'sessionID': 'image-note-session',
  'zoteroVersion': '10.0',
  'style': {'styleID': 'http://www.zotero.org/styles/apa', 'locale': 'en-US'},
  'prefs': {'fieldType': 'Http', 'noteType': noteType},
});

ZoteroCitation _citation(
  String id,
  String text, {
  int noteIndex = 0,
}) => ZoteroCitation(
  citationId: id,
  plainCitation: text,
  noteIndex: noteIndex,
  items: [
    ZoteroCitationItem.fromCsl(
      itemData: {'id': id, 'type': 'book', 'title': 'Source $id'},
      uris: [
        'http://zotero.org/users/42/items/${id == 'first' ? 'ABCD1234' : 'EFGH5678'}',
      ],
      locator: id == 'first' ? '4' : '9',
      label: 'page',
    ),
  ],
);

WordZoteroCitingSession _session(WmlDocument document, {int offset = 6}) =>
    WordZoteroCitingSession(
      document: document,
      documentId: _docId,
      insertionParagraph: document.paragraphs.first,
      insertionOffset: offset,
    );

Object? _call(
  WordZoteroCitingSession session,
  String command, [
  List<Object?> args = const [],
]) => session.handle(command, [_docId, ...args]);

List<Map<String, Object?>> _fields(WordZoteroCitingSession session) =>
    (_call(session, 'Document.getFields', ['Http'])! as List<Object?>)
        .cast<Map<String, Object?>>();

void _setCitation(
  WordZoteroCitingSession session,
  Map<String, Object?> field,
  String id,
  String text,
) {
  _call(session, 'Field.setCode', [
    field['id'],
    'ITEM CSL_CITATION ${jsonEncode(_citation(id, text, noteIndex: field['noteIndex']! as int).toJson())}',
  ]);
  _call(session, 'Field.setText', [field['id'], '<i>$text</i>', true]);
}

void _start(WordZoteroCitingSession session, String html, int noteType) {
  _call(session, 'Document.setDocumentData', [_preferences(noteType)]);
  final temporary =
      _call(session, 'Document.insertField', ['Http', noteType])!
          as Map<String, Object?>;
  _call(session, 'Field.delete', [temporary['id']]);
  _call(session, 'Document.insertText', [html]);
}

void _finish(WordZoteroCitingSession session) {
  _call(session, 'Document.complete');
  session.apply();
}

List<OfficeVisual> _images(WmlDocument document) => [
  for (final picture in document.visuals) picture.visual,
];

void main() {
  final png = _picture();
  final document = WmlDocument.empty(text: '');
  final session = _session(document, offset: 0);
  _start(session, '<p><a href="https://example.org/figure">${_image(png)}</a></p>', 0);
  _finish(session);
  final package = WordSerializer().write(document);
  final part = package.getPart('/word/document.xml')!;
  part.writeText(part.readText().replaceAll(RegExp(r'<w:(pPr|rPr)\b[^>]*(?:/>|>.*?</w:\1>)', dotAll: true), ''));
  print(part.readText());
  var reopened = WordDeserializer().read(package);
  for(var cycle=0;cycle<3;cycle++) {
    print(jsonEncode({'cycle':cycle,'separator':reopened.footnoteSeparator?.reservedHeight,'runs':reopened.paragraphs.single.inlines.whereType<WmlRun>().map((r)=>{'text':r.text,'link':r.hyperlink?.url,'visual':r.inlineVisual!=null,'size':r.properties.fontSizeHalfPoints}).toList()}));
    reopened=WordDeserializer().readBytes(WordSerializer().writeBytes(reopened));
  }
}
