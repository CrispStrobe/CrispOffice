from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED, ZIP_STORED
import concurrent.futures
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import fitz

ROOT = Path(__file__).resolve().parent
NS = {
    'office': 'urn:oasis:names:tc:opendocument:xmlns:office:1.0',
    'style': 'urn:oasis:names:tc:opendocument:xmlns:style:1.0',
    'text': 'urn:oasis:names:tc:opendocument:xmlns:text:1.0',
    'fo': 'urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0',
    'svg': 'urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0',
}
NSATTR = ' '.join(f'xmlns:{k}="{v}"' for k, v in NS.items())


def make_probe(case):
    name = case['name']
    folder = ROOT / 'odt-probes' / name
    folder.mkdir(parents=True, exist_ok=True)
    attrs = {
        'width': f"{case['thickness']}pt", 'rel-width': f"{case['relative'] * 100:g}%",
        'adjustment': case['align'], 'color': case['color'],
        'line-style': case['style'], 'distance-before-sep': f"{case['before']}pt",
        'distance-after-sep': f"{case['after']}pt",
    }
    sep = '<style:footnote-sep ' + ' '.join(f'style:{k}="{v}"' for k, v in attrs.items()) + '/>'
    lines = [f'<text:p text:style-name="Start">Separator probe {name}<text:note text:id="ftn1" text:note-class="footnote"><text:note-citation>1</text:note-citation><text:note-body><text:p text:style-name="Footnote">Footnote content has a twelve point line height.</text:p></text:note-body></text:note></text:p>']
    for i in range(1, case.get('lines', 2)):
        lines.append(f'<text:p text:style-name="Standard">Body line {i:02d}: pagination and separator geometry.</text:p>')
    font = '<office:font-face-decls><style:font-face style:name="LiberationSerif" svg:font-family="Liberation Serif" style:font-family-generic="roman" style:font-pitch="variable"/></office:font-face-decls>'
    parts = {
        'content.xml': f'''<?xml version="1.0" encoding="UTF-8"?><office:document-content {NSATTR} office:version="1.3">{font}<office:automatic-styles/><office:body><office:text>{''.join(lines)}</office:text></office:body></office:document-content>''',
        'styles.xml': f'''<?xml version="1.0" encoding="UTF-8"?><office:document-styles {NSATTR} office:version="1.3">{font}<office:styles><style:default-style style:family="paragraph"><style:paragraph-properties fo:margin-top="0pt" fo:margin-bottom="0pt" fo:margin-left="0pt" fo:margin-right="0pt" fo:line-height="12pt"/><style:text-properties style:font-name="LiberationSerif" fo:font-size="12pt"/></style:default-style><style:style style:name="Standard" style:family="paragraph"/><style:style style:name="Start" style:family="paragraph" style:parent-style-name="Standard" style:master-page-name="Standard"/><style:style style:name="Footnote" style:family="paragraph"><style:paragraph-properties fo:margin-top="0pt" fo:margin-bottom="0pt" fo:line-height="12pt"/></style:style><text:notes-configuration text:note-class="footnote" style:num-format="1" text:start-value="0" text:footnotes-position="page"/></office:styles><office:automatic-styles><style:page-layout style:name="pm1"><style:page-layout-properties fo:page-width="612pt" fo:page-height="792pt" fo:margin-top="72pt" fo:margin-bottom="72pt" fo:margin-left="72pt" fo:margin-right="72pt">{sep}</style:page-layout-properties></style:page-layout></office:automatic-styles><office:master-styles><style:master-page style:name="Standard" style:page-layout-name="pm1"/></office:master-styles></office:document-styles>''',
        'META-INF/manifest.xml': '''<?xml version="1.0" encoding="UTF-8"?><manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.3"><manifest:file-entry manifest:full-path="/" manifest:media-type="application/vnd.oasis.opendocument.text"/><manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/><manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/></manifest:manifest>''',
    }
    path = folder / f'{name}.odt'
    with ZipFile(path, 'w', ZIP_DEFLATED) as z:
        z.writestr('mimetype', 'application/vnd.oasis.opendocument.text', compress_type=ZIP_STORED)
        for key, value in parts.items():
            z.writestr(key, value)
    return path


def convert(path, kind, output):
    output.mkdir(parents=True, exist_ok=True)
    profile = output / 'profile'
    cmd = ['soffice', f'-env:UserInstallation={profile.as_uri()}', '--headless', '--convert-to', kind, '--outdir', str(output), str(path)]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    dest = output / (path.stem + '.' + kind.split(':')[0])
    (output / 'command.json').write_text(json.dumps({'argv': cmd, 'exit': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr, 'input_sha256': sha(path), 'output_sha256': sha(dest) if dest.exists() else None}, indent=2))
    if proc.returncode or not dest.exists():
        raise RuntimeError(f'Conversion failed {cmd!r}: {proc.returncode}: {proc.stderr}')
    return dest


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inspect_odt(path):
    with ZipFile(path) as z:
        styles = z.read('styles.xml')
        (path.parent / 'styles.xml').write_bytes(styles)
        root = ET.fromstring(styles)
        return [{k.split('}')[-1]: v for k, v in s.attrib.items()} for s in root.iter('{'+NS['style']+'}footnote-sep')]


def inspect_pdf(path):
    doc = fitz.open(path)
    result = []
    for n, page in enumerate(doc):
        page.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(path.parent / f'page-{n+1}.png')
        page.get_pixmap(matrix=fitz.Matrix(2,2), clip=fitz.Rect(60,page.rect.height-172,page.rect.width-60,page.rect.height-62)).save(path.parent / f'page-{n+1}-bottom.png')
        result.append({'page': n+1, 'drawings': [{k: list(v) if isinstance(v, fitz.Rect) else v for k, v in x.items() if k in ('rect','width','color','fill','type')} for x in page.get_drawings()], 'blocks': page.get_text('blocks')})
    return result


def task(case):
    path = make_probe(case)
    pdf = convert(path, 'pdf', path.parent / 'input-pdf')
    pass1 = convert(path, 'odt:writer8', path.parent / 'pass1')
    pass2 = convert(pass1, 'odt:writer8', path.parent / 'pass2')
    pass2_pdf = convert(pass2, 'pdf', path.parent / 'pass2-pdf')
    return {'case':case, 'input':str(path), 'input_sha256':sha(path), 'input_attrs':inspect_odt(path), 'pass1_attrs':inspect_odt(pass1), 'pass2_attrs':inspect_odt(pass2), 'input_pdf':inspect_pdf(pdf), 'pass2_pdf':inspect_pdf(pass2_pdf)}


if __name__ == '__main__':
    base = {'thickness':2,'relative':.5,'align':'left','color':'#000000','style':'solid','before':6,'after':6}
    cases = [
        {'name':'solid-left-half', **base},
        {**base,'name':'solid-center-quarter-color','relative':.25,'align':'center','color':'#1464C8','thickness':1.5,'before':9,'after':3},
        {**base,'name':'solid-right-full-color','relative':1,'align':'right','color':'#C81464','thickness':3,'before':0,'after':12},
        {**base,'name':'solid-right-half-zero','align':'right','color':'#00A040','before':0,'after':0},
        {**base,'name':'none-with-gaps','style':'none','align':'center','color':'#C81464','before':9,'after':9},
        {**base,'name':'none-zero','style':'none','before':0,'after':0},
        {**base,'name':'solid-zero-width','relative':0,'color':'#C81464'},
        {**base,'name':'solid-zero-thickness','thickness':0,'color':'#C81464'},
        {**base,'name':'pagination-before-0','before':0,'after':6,'lines':60},
        {**base,'name':'pagination-before-24','before':24,'after':6,'lines':60},
    ]
    version = subprocess.run(['soffice','--version'],capture_output=True,text=True,check=True).stdout.strip()
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(task, cases))
    report = {'version':version, 'results':results}
    (ROOT / 'odt-probe-results.json').write_text(json.dumps(report,indent=2))
    for r in results:
        print(r['case']['name'], json.dumps({'input':r['input_attrs'],'pass1':r['pass1_attrs'],'pass2':r['pass2_attrs'],'drawings':r['input_pdf'][0]['drawings'],'pages':len(r['input_pdf']),'last_block':r['input_pdf'][0]['blocks'][-1]}))
