import concurrent.futures
import json
from odt_probe import ROOT, task

base = {'relative':.5,'align':'left','color':'#000000','style':'none','before':0,'after':0,'lines':60}
cases = [
    {**base, 'name':'hidden-reserve-0', 'thickness':0},
    {**base, 'name':'hidden-reserve-24', 'thickness':24},
    {**base, 'name':'zero-relative-reserve-24', 'thickness':24, 'relative':0,'style':'solid'},
    {**base, 'name':'visible-reserve-24', 'thickness':24, 'style':'solid'},
]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(task, cases))
(ROOT / 'hidden-reservation-results.json').write_text(json.dumps(results,indent=2))
for r in results:
    for key in ['input_pdf','pass2_pdf']:
        bodylines=[line for block in r[key][0]['blocks'] for line in block[4].splitlines() if line.startswith('Body line')]
        print(r['case']['name'], key, 'body_count',len(bodylines)+1, 'last_body',bodylines[-1], 'drawings',r[key][0]['drawings'])
