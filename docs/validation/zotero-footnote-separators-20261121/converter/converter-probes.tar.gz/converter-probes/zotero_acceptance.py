from pathlib import Path
import concurrent.futures
import hashlib
import json
import subprocess
from odt_probe import ROOT, convert, inspect_odt, inspect_pdf

ENGINE = ROOT.parent / 'quds_office_suite' / 'packages' / 'quds_office_engine'
TOOL = ['dart', '--packages=../../.dart_tool/package_config.json', 'tool/zotero/footnote_separator_acceptance.dart']


def native(preset, name, *args):
    folder = ROOT / 'zotero' / preset
    folder.mkdir(parents=True, exist_ok=True)
    cmd = TOOL + list(args)
    proc = subprocess.run(cmd, cwd=ENGINE, capture_output=True, text=True, timeout=120)
    data = {'argv':cmd, 'cwd':str(ENGINE), 'exit':proc.returncode, 'stdout':proc.stdout, 'stderr':proc.stderr}
    (folder / (name + '-command.json')).write_text(json.dumps(data,indent=2))
    if proc.returncode:
        raise RuntimeError(f'{preset} {name} failed: {proc.stderr}')
    return json.loads(proc.stdout)


def run(preset):
    folder = ROOT / 'zotero' / preset
    folder.mkdir(parents=True, exist_ok=True)
    source = ROOT / 'zotero' / (preset + '.odt')
    initial = native(preset, 'create', 'create', str(source), preset)
    source_pdf = convert(source, 'pdf', folder / 'source-pdf')
    lo1 = convert(source, 'odt:writer8', folder / 'lo1')
    cycle1 = native(preset, 'after-lo1-cycle', 'cycle', str(lo1), str(folder / 'native-after-lo1'), preset)
    lo2 = convert(folder / 'native-after-lo1' / 'native-2.odt', 'odt:writer8', folder / 'lo2')
    cycle2 = native(preset, 'after-lo2-cycle', 'cycle', str(lo2), str(folder / 'native-after-lo2'), preset)
    final = native(preset, 'final-inspect', 'inspect', str(folder / 'native-after-lo2' / 'native-2.odt'), preset)
    lo2_pdf = convert(lo2, 'pdf', folder / 'lo2-pdf')
    report = {'preset':preset,'initial':initial, 'lo1Attrs':inspect_odt(lo1), 'lo2Attrs':inspect_odt(lo2), 'cycle1':cycle1,'cycle2':cycle2,'final':final,'sourcePdf':inspect_pdf(source_pdf),'lo2Pdf':inspect_pdf(lo2_pdf)}
    (folder / 'acceptance.json').write_text(json.dumps(report,indent=2))
    return report


if __name__ == '__main__':
    reports = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        futures = {pool.submit(run, preset):preset for preset in ['custom','zero','hidden']}
        for future in concurrent.futures.as_completed(futures):
            preset = futures[future]
            try:
                result = future.result()
                reports.append({'preset':preset, 'accepted':True, 'report':str(ROOT / 'zotero' / preset / 'acceptance.json')})
                print(preset, 'ACCEPTED', flush=True)
            except Exception as error:
                reports.append({'preset':preset, 'accepted':False, 'error':str(error)})
                print(preset, 'FAILED', str(error), flush=True)
    (ROOT / 'zotero-acceptance-results.json').write_text(json.dumps(reports,indent=2))
    if not all(x['accepted'] for x in reports):
        raise SystemExit(1)
