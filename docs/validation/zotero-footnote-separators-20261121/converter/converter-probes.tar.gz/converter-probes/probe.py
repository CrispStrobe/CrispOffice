from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import concurrent.futures
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import fitz

ROOT = Path(__file__).resolve().parent
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
STYLE = 'urn:oasis:names:tc:opendocument:xmlns:style:1.0'


def make_probe(name, properties, content):
    folder = ROOT / 'probes' / name
    folder.mkdir(parents=True, exist_ok=True)
    document = f'''<w:document xmlns:w="{W}"><w:body>
      <w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="exact"/></w:pPr>
      <w:r><w:t>Separator geometry probe {name}</w:t></w:r><w:r><w:footnoteReference w:id="1"/></w:r></w:p>
      <w:p><w:r><w:t>The page body ends here.</w:t></w:r></w:p>
      <w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr>
      </w:body></w:document>'''
    footnotes = f'''<w:footnotes xmlns:w="{W}"><w:footnote w:type="separator" w:id="-1"><w:p>{properties}{content}</w:p></w:footnote>
      <w:footnote w:type="continuationSeparator" w:id="0"><w:p><w:r><w:continuationSeparator/></w:r></w:p></w:footnote>
      <w:footnote w:id="1"><w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="exact"/></w:pPr><w:r><w:footnoteRef/><w:t>  Footnote content has a twelve point line height.</w:t></w:r></w:p></w:footnote></w:footnotes>'''
    parts = {
        '[Content_Types].xml': '''<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/footnotes.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml"/><Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>''',
        '_rels/.rels': '''<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>''',
        'word/_rels/document.xml.rels': '''<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes" Target="footnotes.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>''',
        'word/document.xml': document,
        'word/footnotes.xml': footnotes,
        'word/settings.xml': f'<w:settings xmlns:w="{W}"><w:footnotePr><w:footnote w:id="-1"/><w:footnote w:id="0"/></w:footnotePr></w:settings>',
        'word/styles.xml': f'<w:styles xmlns:w="{W}"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Liberation Serif" w:hAnsi="Liberation Serif"/><w:sz w:val="24"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:before="0" w:after="0"/></w:pPr></w:pPrDefault></w:docDefaults></w:styles>',
    }
    path = folder / f'{name}.docx'
    with ZipFile(path, 'w', ZIP_DEFLATED) as z:
        for key, value in parts.items():
            z.writestr(key, value)
    return path


def convert(path, kind, suffix):
    target = path.parent / suffix
    target.mkdir(exist_ok=True)
    profile = target / 'profile'
    cmd = ['soffice', f'-env:UserInstallation={profile.as_uri()}', '--headless', '--convert-to', kind, '--outdir', str(target), str(path)]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    (target / 'command.json').write_text(json.dumps({'argv':cmd,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr}, indent=2))
    out = target / f'{path.stem}.{kind.split(":")[0]}'
    if result.returncode or not out.exists():
        raise RuntimeError(f'Failed: {cmd}: {result.returncode} {result.stderr}')
    return out


def inspect_pdf(path):
    d = fitz.open(path)
    result = []
    for i, page in enumerate(d):
        page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5)).save(path.with_name(f'page-{i+1}.png'))
        result.append({'page':i+1, 'drawings':[{k:v for k,v in p.items() if k in ('rect','width','color','fill','type')} for p in page.get_drawings()], 'blocks':page.get_text('blocks')})
    return result


def inspect_odt(path):
    with ZipFile(path) as z:
        xml = z.read('styles.xml')
        (path.parent / 'styles.xml').write_bytes(xml)
        root = ET.fromstring(xml)
        return [dict(x.attrib) for x in root.iter(f'{{{STYLE}}}footnote-sep')]


def task(path):
    pdf = convert(path, 'pdf', 'pdf')
    odt = convert(path, 'odt', 'odt')
    return {'name':path.stem,'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'pdf':inspect_pdf(pdf),'odt':inspect_odt(odt)}


def props(edge='bottom', height=120, before=0, after=120):
    return f'<w:pPr><w:pBdr><w:{edge} w:val="single" w:sz="16" w:space="0" w:color="FF0000"/></w:pBdr><w:spacing w:before="{before}" w:after="{after}" w:line="{height}" w:lineRule="exact"/><w:ind w:left="4680" w:right="0"/><w:jc w:val="left"/><w:rPr><w:sz w:val="2"/></w:rPr></w:pPr>'


if __name__ == '__main__':
    cases = [
        ('bare', '<w:pPr><w:spacing w:before="0" w:after="0"/></w:pPr>', '<w:r><w:separator/></w:r>'),
        ('border-bottom', props(), ''),
        ('border-bottom-zero', props(height=0), ''),
        ('border-top', props(edge='top', height=120,before=120,after=0), ''),
        ('border-top-zero', props(edge='top',height=0,before=120,after=0), ''),
        ('border-hidden-marker', props(), '<w:r><w:rPr><w:vanish/></w:rPr><w:separator/></w:r>'),
        ('border-visible-marker', props(), '<w:r><w:rPr><w:sz w:val="2"/></w:rPr><w:separator/></w:r>'),
    ]
    inputs = [make_probe(*case) for case in cases]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(task, inputs))
    (ROOT / 'probe-results.json').write_text(json.dumps(results, indent=2, default=str))
    print(json.dumps(results, indent=2, default=str))
