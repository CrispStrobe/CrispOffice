"""Independently recount the 71-case late-main Word bridge; no test execution."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import subprocess

BASE = Path('/workspace/scratch/03cd41fa0e7e')
REPO = BASE / 'quds_delivery'
DIR = BASE / 'runtime/word-late-main-qualification'
OUT = BASE / 'runtime/word-late-main-independent-review.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    return json.loads((DIR / name).read_text())


receipt = read('qualification.json')
head = receipt['source_head']
assert head == '52eace9e151cff88c5908a049b0a51ade4c20b00'
assert receipt['success'] and receipt['worktree_clean'] and receipt['head_unchanged']
env = os.environ | {'GIT_NO_LAZY_FETCH': '1', 'GIT_TERMINAL_PROMPT': '0'}
git = lambda *a: subprocess.check_output(['git', '-C', str(REPO), *a], env=env).decode().strip()
assert git('rev-parse', head + '^{tree}') == receipt['source_tree']
before, after = read('source-before.json'), read('source-after.json')
assert before == after and len(before) == receipt['source_files_hashed'] == 2859
runtime_before, runtime_after = read('runtime-before.json'), read('runtime-after.json')
assert runtime_before == runtime_after
for p, digest in runtime_before.items():
    assert sha(Path(p).read_bytes()) == digest, p
process = subprocess.Popen(['git', '-C', str(REPO), 'cat-file', '--batch'], env=env,
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
for path, digest in before.items():
    process.stdin.write((head + ':' + path + '\n').encode())
    process.stdin.flush()
    header = process.stdout.readline().decode().split()
    assert len(header) == 3 and header[1] == 'blob', (path, header)
    data = process.stdout.read(int(header[2]))
    assert process.stdout.read(1) == b'\n'
    assert sha(data) == digest == sha((REPO / path).read_bytes()), path
process.stdin.close()
assert process.wait() == 0

assert {c['name'] for c in receipt['commands']} == {'word-bridge', 'engine-analysis', 'format'}
for command in receipt['commands']:
    assert command['exit_code'] == 0
    for stream in ('stdout', 'stderr'):
        assert sha((DIR / command[stream]).read_bytes()) == command[stream + '_sha256']
    if command['name'] == 'engine-analysis':
        assert '--fatal-infos' in command['command']
    if command['name'] == 'format':
        assert '--set-exit-if-changed' in command['command'] and '--output=none' in command['command']

events = [json.loads(line) for line in (DIR / 'word-bridge.stdout.log').read_text().splitlines() if line.startswith('{')]
assert not any(e.get('type') == 'error' for e in events)
terminals = [e for e in events if e.get('type') == 'done']
assert len(terminals) == 1 and terminals[0]['success'] and events[-1] == terminals[0]
suites = {e['suite']['id']: e['suite']['path'] for e in events if e.get('type') == 'suite'}
starts_list = [e['test'] for e in events if e.get('type') == 'testStart']
starts = {e['id']: e for e in starts_list}
assert len(starts) == len(starts_list)
done = [e for e in events if e.get('type') == 'testDone']
assert Counter(e['testID'] for e in done) == Counter({k: 1 for k in starts})
occurrence, cases = Counter(), []
for event in done:
    if event.get('hidden'):
        continue
    assert event['result'] == 'success' and not event.get('skipped')
    test = starts[event['testID']]
    path = Path(suites[test['suiteID']])
    if not path.is_absolute():
        path = REPO / 'packages/quds_office_engine' / path
    file = str(path.resolve().relative_to(REPO))
    occurrence[(file, test['name'])] += 1
    cases.append({'file': file, 'name': test['name'], 'occurrence': occurrence[(file, test['name'])],
                  'result': 'success', 'skipped': False})
assert cases == read('word-bridge-cases.json') and len(cases) == 71
assert dict(Counter(c['file'] for c in cases)) == read('selection.json')
audit_bytes = (DIR / 'incoming-retention-audit.json').read_bytes()
assert sha(audit_bytes) == receipt['incoming_audit_sha256'] == 'f828d114b18b8760916407cf818d2ad0cae200f45cbd36ef03e89c90e205b56b'
incoming = json.loads(audit_bytes)
for path, digest in incoming['selected_source'].items():
    assert before[path] == digest
status = git('status', '--porcelain')
assert not any(not line[3:].startswith('docs/') for line in status.splitlines()), status
report = {'schema': 1, 'success': True, 'actionable_findings': [],
          'source_head': head, 'source_tree': receipt['source_tree'],
          'qualification_sha256': sha((DIR / 'qualification.json').read_bytes()),
          'incoming_audit_sha256': sha(audit_bytes), 'passed': 71, 'failed': 0, 'skipped': 0,
          'per_file': read('selection.json'), 'every_started_test_completed_once': True,
          'raw_case_identity_export_exact': True, 'command_logs_verified': 6,
          'strict_engine_analysis_and_format_passed': True,
          'source_before_after_git_and_current_inputs_verified': len(before),
          'runtime_before_after_and_current_inputs_verified': len(runtime_before),
          'all_seven_selected_incoming_and_bridge_source_hashes_match': True,
          'expected_post_gate_documentation_changes': status.splitlines(),
          'limits': ['Read-only recount and immutable source comparison; no additional tests executed.',
                     'Incoming evidence and older c623 populations retain their original source/runtime attribution.',
                     'Final Mail merge still needs a source-identity proof that it retains these Word inputs.'],
          'auditor_sha256': sha(Path(__file__).read_bytes())}
OUT.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'path': str(OUT), 'sha256': sha(OUT.read_bytes()), 'passed': 71, 'success': True}))
