#!/usr/bin/env python3
"""Package the completed 71-case Word bridge without editing source or refs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

BASE = Path('/workspace/scratch/03cd41fa0e7e')
RUNTIME = BASE / 'runtime'
REPO = BASE / 'quds_delivery'
RUN = RUNTIME / 'word-late-main-qualification'
OUT = RUNTIME / 'word-late-main-package'
SOURCE = '52eace9e151cff88c5908a049b0a51ade4c20b00'
AUDIT_SHA = 'f828d114b18b8760916407cf818d2ad0cae200f45cbd36ef03e89c90e205b56b'


def sha(content):
    return hashlib.sha256(content).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def load(path):
    return json.loads(Path(path).read_text())


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


receipt = load(RUN / 'qualification.json')
audit_path = RUNTIME / 'incoming-pr275-word-evidence-audit.json'
audit = load(audit_path)
assert receipt['success'] and receipt['source_head'] == SOURCE
assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert sha(audit_path.read_bytes()) == AUDIT_SHA
assert receipt['tests']['passed'] == 71 and receipt['tests']['failed'] == receipt['tests']['skipped'] == 0
assert all(receipt[k] for k in ['source_unchanged', 'runtime_unchanged', 'head_unchanged', 'worktree_clean'])
assert all(sha(git('show', SOURCE + ':' + p)) == expected for p, expected in audit['selected_source'].items())
delta = git('diff', '--name-only', 'c62338c65571aa399da5592455b651fa5c6a9317', SOURCE, '--',
    'packages/quds_office_engine/lib', 'packages/quds_office_editor/lib').decode().splitlines()
assert sorted(delta) == sorted(audit['engine_editor_production_delta_vs_c623'])
cases = load(RUN / 'word-bridge-cases.json')
prior = load(RUNTIME / 'word-zotero-delivery-qualification/native-cases.json')
prior = [r for r in prior if r['file'] in receipt['selection']]
identity = lambda rows: {(r['file'], r['name'], r['occurrence']) for r in rows}
assert len(cases) == len(prior) == 71 and identity(cases) == identity(prior)
OUT.mkdir(exist_ok=False)
members = {}
for path in sorted(RUN.iterdir()):
    if path.is_file() and path.suffix in ('.json', '.log'):
        members['fresh/' + path.name] = path.read_bytes()
for filename in ['qualify_late_word_main.py', 'audit_incoming_pr275_word_evidence.py',
    'incoming-pr275-word-evidence-audit.json', 'incoming-pr275-archive-verifier.json',
    'quds-delivery-runtime-mapping.json']:
    members['tools-and-bindings/' + filename] = (RUNTIME / filename).read_bytes()
members['tools-and-bindings/' + Path(__file__).name] = Path(__file__).read_bytes()
identity_proof = {'source_commit': SOURCE, 'prior_source_commit': 'c62338c65571aa399da5592455b651fa5c6a9317',
    'case_count': 71, 'same_case_identity_set': True, 'cases': cases,
    'counting_rule': 'Fresh qualification of existing independent assertions against changed Word production; not71 new logical tests.'}
members['accepted-identities/bridge-identity-retention.json'] = encoded(identity_proof)
review_path = RUNTIME / 'word-late-main-independent-review.json'
review = None
if review_path.is_file():
    assert sha(review_path.read_bytes()) == 'ad0afd8aaaecda5b9be460edb6c8295e8a66439f4bc4b3e0387a5fa3beca2435'
    review = {'path': 'archive:independent-review/' + review_path.name,
        'sha256': sha(review_path.read_bytes())}
    members['independent-review/' + review_path.name] = review_path.read_bytes()
    members['independent-review/audit_word_late_main.py'] = (RUNTIME / 'audit_word_late_main.py').read_bytes()
incoming_archive = BASE / 'quds_merge_final' / audit['archive']['path']
assert sha(incoming_archive.read_bytes()) == audit['archive']['sha256']
assert incoming_archive.stat().st_size == audit['archive']['bytes']
summary = {'schema_version': 1, 'accepted': True, 'source_commit': SOURCE,
    'source_tree': receipt['source_tree'], 'completed_utc': receipt['finished_utc'],
    'fresh_bridge': {'passed': 71, 'failed': 0, 'skipped': 0, 'files': 3,
        'per_file': receipt['tests']['per_file_passed'], 'exact_c623_case_identities_preserved': True},
    'strict_checks': [c for c in receipt['commands'] if c['name'] != 'word-bridge'],
    'source_binding': {'captured_inputs': receipt['source_files_hashed'],
        'selected_files': audit['selected_source'], 'selected_files_match_remote_git_objects': True,
        'engine_editor_production_delta_from_c623': delta,
        'compiler_and_macro_files_unchanged_from_c623': audit['compiler_and_macro_files_unchanged_from_c623'],
        'source_runtime_head_unchanged': True, 'clean_tree_at_execution_boundaries': True},
    'incoming_retained_word': audit['retained_exact_word_population'],
    'incoming_retained_affected_zotero': audit['retained_affected_zotero'],
    'incoming_actual_bas_pairs': audit['bas_driver_pairs'],
    'incoming_archive': dict(audit['archive'], git_commit=audit['incoming_main'], duplicated_here=False),
    'incoming_audit_sha256': AUDIT_SHA, 'incoming_auditor_sha256': audit['auditor_sha256'],
    'independent_final_review': review,
    'incoming_runtime_and_scope_limits': audit['limits'],
    'historical_verifier_limit': audit['full_historical_verifier_limit'],
    'reference_fixture_binding_limit': audit['reference_fixture_binding_limit'],
    'carry_forward_policy': audit['carry_forward_policy'],
    'historical_macro_corpus': {'cases': 3598, 'suites': 69, 'compiler_unchanged': True,
        'this_is_not_a_whole_corpus_rerun': True, 'add_this_receipt_to_prior_total': False},
    'runtimes': {'fresh': receipt['dart_version'], 'incoming': 'Retains each archived execution runtime; not relabeled as a fresh run.'},
}
readme = f'''# Word late-main bridge qualification — 2026-11-20

The narrow Word bridge is accepted at published commit
`{SOURCE}`, tree `{receipt['source_tree']}`.
All **71 cases passed**, with no failures or skips. Whole-engine analysis with
fatal infos and the agreed seven-file read-only format check also passed.
The [fresh receipt](qualification.json) records exact commands, case populations,
raw output hashes and unchanged source/runtime seals; the
[accepted summary](accepted-summary.json) preserves the source attribution of
the incoming results separately.

## What changed after the c623 checkpoint

Only two engine/editor production files differ from `c62338c6`:
`word_layout.dart` and `word_deserializer.dart`. Both are byte-identical to
incoming main `5e7e4d24284954603a0a5951699bea870ad1955f` and the selected incoming
execution source. The VBA compiler, macro fixtures and canonical BAS examples
remain unchanged. This checkpoint contains the Word changes independently of
the remaining Mail reconciliation, allowing the bounded Word check to finish
without waiting for that separate work.

The layout change recognizes a repeated reference to the same `WmlVisual`
node within one header/footer collection as one occurrence. It still preserves
distinct authored nodes that share an image asset or position. It also shares
the existing body-frame-prefix filtering between continuation and content-bottom
calculation. The deserializer updates imported paragraph baselines only when
table fallback spacing actually changes and an imported baseline already exists.
That preserves the distinction between an import default and an authored edit.

Two incoming suites add 15 header-visual and 14 table-import regression cases.
Their exact-source incoming executions are retained. Our additional independent
identity/style assertions and the canonical contained-text fixture are freshly
checked against the integrated libraries.

## Fresh bridge

| Suite | Passing cases | Purpose |
| --- | ---: | --- |
| `word_header_picture_identity_test.dart` | 13 | Distinct nodes, shared assets, placements and native header/footer roundtrips |
| `word_styles_layout_test.dart` | 17 | Existing style/layout behavior plus explicit color and bold-off precedence |
| `word_contained_text_wrap_test.dart` | 41 | Exact text/glyph containment and repeated native direct/isolate save/reopen behavior |

The 71 identities match the corresponding cases in the c623 receipt exactly.
They are superseding executions of existing assertions against changed Word
production, not 71 new logical test cases. The 31.2-point inner-content fixture
and all exact glyph, fit and roundtrip assertions remain unchanged.

The whole engine analyzer reports no issues with `--fatal-infos`. Formatting
was checked without writes for the two production files, these three suites,
and the two new incoming regression suites. The fresh engine runtime is
Dart 3.14.1 with the pinned package:test runner and dependency configuration.
All {receipt['source_files_hashed']:,} captured source inputs, runtime inputs,
HEAD and clean-tree boundaries remained unchanged. The seven selected file
hashes were also compared directly with immutable Git objects at the published
source. No dependency resolution, SDK/cache change, CI wait or product edit
occurred during this gate.

## Incoming evidence retained with its original source/runtime

The [incoming audit](incoming-retention-audit.json) verifies all 271 members of
`docs/validation/mail-bulk-flags-20261120/late-evidence.tar.gz`, paired source
seals, raw case events, successful exits, and direct bindings to available
Git objects at incoming execution `44f3f61fa7d812971e973f1763ac8e04eb39785a`
and main `5e7e4d24284954603a0a5951699bea870ad1955f`.

| Incoming scope | Retained result | Counting boundary |
| --- | --- | --- |
| Combined Word VM | 929 passing cases | Exact selected source |
| Additional focused Word VM | 188 passing cases | Excludes incoming style15 and contained41 variants, which this bridge replaces |
| Word VM union | 1,055 unique passing cases | 929 + 188 minus 62 shared identities |
| Word Node/dart2js | 787 passing rechecks | Overlaps VM; not additional logical cases |
| Affected Zotero VM | 165 passing cases | Exact relevant inputs; overlaps earlier acceptance |
| Affected Zotero Node | 117 passing rechecks | Separate platform evidence, not added to VM |
| Editor follow-up | 362 passes and eight declared exclusions | Nine Zotero suites plus incremental-layout and two proofing suites |
| Font loader | 9 passing cases | Includes actual lowercase filename-alias fixtures |

The incoming editor source manifests are broader than those test dependencies.
Mail host differences are explicitly excluded where the editor/Zotero code
does not reference them. The incoming 16-case Studio receipt is recorded but
is **not adopted as exact-current evidence**, because Studio can load the
changed Mail paths. Mail retains its own source-specific qualification.

The two actual BAS measurement/named-measurement VM and Node driver pairs are
verified in the incoming audit. Their input and driver hashes, commands and
result comparisons remain in that evidence. No new BAS execution is claimed
for this 71-case bridge.

The incoming archive remains at its original repository path and is not
duplicated here. Its SHA-256 is
`{audit['archive']['sha256']}` ({audit['archive']['bytes']:,} bytes).
The audit gives its source commit and exact location, so it remains retrievable
from immutable incoming Git history even in a checkpoint containing only the
Word product delta.

## Relationship to the prior accepted reports

The [c623 Word/Zotero report](../word-final-integration-20261120/README.md)
retains its original result and source seals, including its 663 fresh macro,
223 native, 96 editor-layout, 188 Zotero-engine and 143 Zotero-editor cases.
Those earlier cohorts are **not described as rerun at this later checkpoint**.
The earlier 3,598-case macro corpus also keeps its own source attribution;
the compiler and macro/example files are unchanged. VM, Node, native and editor
counts overlap, so this report supplies no grand total across them.

The eight editor editing-equivalence exclusions remain the exact
`no paragraphs to edit` cases recorded in the c623 report and this incoming
audit. They were not changed into passes. The fresh 71-case bridge itself has
zero skipped cases.

## Reproducibility and limits

The original archive-only verifier passed. Its broader historical Git verifier
could not read an unrelated old promisor object
`df576aa4e32c8c151446309ea1c72dab11d84f06` while checking baseline ancestry.
No fetch was attempted. The independent audit instead directly verified every
selected receipt against the available incoming execution/main objects; the
missing unrelated object is not treated as a successful historical verifier
run. The raw verifier result and independent audit are preserved.

Tracked reference fixtures are bound by immutable peer/main/c623 Git equivalence,
not relabeled as additional historical per-file before/after execution seals.
Incoming runs retain their archived runtime attribution. Node evidence is not
a browser/WASM run, and no installed Microsoft Word/Zotero host or live provider
session was exercised by this gate.

The [deterministic archive](local-qualification.tar.gz) contains the exact fresh
runner, raw outputs, case identities, source/runtime seals, the incoming audit
and auditor, and configuration provenance. It excludes SDKs, caches and build
outputs. [The manifest](receipt-manifest.json) records all member hashes/sizes.
Reproduction uses the commands and working directories in `qualification.json`;
paths and immutable source arguments must be explicitly remapped when running
outside the original workspace. These records must not be overwritten.
'''
top = {'README.md': readme.encode(), 'accepted-summary.json': encoded(summary),
    'qualification.json': (RUN / 'qualification.json').read_bytes(),
    'incoming-retention-audit.json': audit_path.read_bytes()}


def archive_bytes():
    stream = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, content in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(content), 0o644, 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(content))
    return stream.getvalue()


archive = archive_bytes()
assert archive == archive_bytes()
top['local-qualification.tar.gz'] = archive
manifest = {'source_commit': SOURCE,
    'archive': {'path': 'local-qualification.tar.gz', 'sha256': sha(archive),
        'bytes': len(archive), 'members': len(members),
        'uncompressed_member_bytes': sum(map(len, members.values())),
        'sorted_members': True, 'tar_and_gzip_mtime': 0, 'uid': 0, 'gid': 0,
        'repeated_serialization_equal': True},
    'files': {name: {'bytes': len(content), 'sha256': sha(content)} for name, content in top.items()},
    'members': {name: {'bytes': len(content), 'sha256': sha(content)} for name, content in sorted(members.items())},
    'self_exclusion': 'The manifest does not hash itself.'}
top['receipt-manifest.json'] = encoded(manifest)
for name, content in top.items():
    (OUT / name).write_bytes(content)
with tarfile.open(OUT / 'local-qualification.tar.gz', 'r:gz') as tar:
    assert {m.name: tar.extractfile(m).read() for m in tar if m.isfile()} == members
print(json.dumps({'package': str(OUT), 'files': {name: len(content) for name, content in top.items()},
    'archive_sha256': sha(archive), 'archive_members': len(members), 'independent_review_included': review is not None}, indent=2))
