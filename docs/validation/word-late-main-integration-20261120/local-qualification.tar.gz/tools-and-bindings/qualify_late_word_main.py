#!/usr/bin/env python3
"""Run the narrow Word bridge only after its immutable remote source is supplied."""
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path('/workspace/scratch/03cd41fa0e7e')
REPO = BASE / 'quds_delivery'
ENGINE = REPO / 'packages/quds_office_engine'
RUNTIME = BASE / 'runtime'
OUT = RUNTIME / 'word-late-main-qualification'
DART = RUNTIME / 'toolchain/dart-sdk/bin/dart'
FDART = RUNTIME / 'flutter-toolchain/flutter/bin/cache/dart-sdk/bin/dart'
KERNEL = RUNTIME / 'toolchain/test-runner/test-runner.dill'
CONFIG = REPO / '.dart_tool/package_config.json'
SELECTION = {
    'packages/quds_office_engine/test/word_header_picture_identity_test.dart': 13,
    'packages/quds_office_engine/test/word_styles_layout_test.dart': 17,
    'packages/quds_office_engine/test/word_contained_text_wrap_test.dart': 41,
}
FORMAT_PATHS = sorted(set(SELECTION) | {
    'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
    'packages/quds_office_engine/lib/src/word/serial/word_deserializer.dart',
    'packages/quds_office_engine/test/word_header_visual_reconciliation_test.dart',
    'packages/quds_office_engine/test/word_table_style_import_regression_test.dart',
})


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


parser = argparse.ArgumentParser()
parser.add_argument('--source', required=True)
parser.add_argument('--incoming-audit', required=True, type=Path)
parser.add_argument('--repo', type=Path, default=REPO)
args = parser.parse_args()
REPO = args.repo.resolve()
ENGINE = REPO / 'packages/quds_office_engine'
CONFIG = REPO / '.dart_tool/package_config.json'
assert len(args.source) == 40 and git('rev-parse', 'HEAD') == args.source
assert not git('status', '--porcelain'), 'Source freeze must be clean before execution'
assert args.incoming_audit.is_file()
assert sha(args.incoming_audit) == 'f828d114b18b8760916407cf818d2ad0cae200f45cbd36ef03e89c90e205b56b'
incoming = json.loads(args.incoming_audit.read_text())
assert incoming['success'] is True
assert incoming['fresh_bridge']['tests'] == SELECTION
assert sorted(incoming['fresh_bridge']['format_paths']) == FORMAT_PATHS
assert all(sha(REPO / path) == expected for path, expected in incoming['selected_source'].items())
assert sha(ENGINE / 'lib/src/automation/office_vba_language.dart') == '41de865411b884d18c1097e9a80d68cd6bf1fb245e1844a46f72af05636f5ecd'
assert sum(SELECTION.values()) == 71
assert all((REPO / p).is_file() for p in FORMAT_PATHS)
OUT.mkdir(exist_ok=False)
for name in ['tmp', 'config', 'cache']:
    (OUT / name).mkdir()
environment = dict(os.environ)
environment.update({'PATH': str(DART.parent) + os.pathsep + os.environ['PATH'],
    'PUB_CACHE': str(RUNTIME / 'flutter-toolchain/pub-cache'),
    'TMPDIR': str(OUT / 'tmp'), 'XDG_CONFIG_HOME': str(OUT / 'config'),
    'XDG_CACHE_HOME': str(OUT / 'cache'), 'DART_SUPPRESS_ANALYTICS': 'true',
    'DASH__SUPPRESS_ANALYTICS': 'true', 'CI': 'true'})
source_paths = git('ls-files', '--', ':(glob)packages/**/lib/**', ':(glob)packages/**/test/**',
    ':(glob)packages/**/fonts/**', ':(glob)packages/**/pubspec.yaml',
    ':(glob)packages/**/analysis_options.yaml', 'third_party/enough_mail/lib',
    'third_party/enough_mail/pubspec.yaml', 'pubspec.yaml', 'pubspec.lock',
    'analysis_options.yaml', '.fvmrc', 'packages/quds_office_engine/tool',
    'packages/quds_office_engine/example/macros').splitlines()
runtime_paths = [DART, FDART, KERNEL, CONFIG, REPO / '.dart_tool/package_graph.json',
    DART.parent / 'snapshots/analysis_server_aot.dart.snapshot',
    RUNTIME / 'toolchain/environment.json', RUNTIME / 'flutter-toolchain/runtime.json',
    RUNTIME / ('quds-delivery-runtime-mapping.json' if REPO.name == 'quds_delivery' else 'quds-merge-final-runtime-mapping.json'),
    BASE / 'quds_final_integration/.dart_tool/package_config.json',
    BASE / 'quds_final_integration/.dart_tool/package_graph.json', args.incoming_audit, Path(__file__)]


def sources():
    return {p: sha(REPO / p) for p in source_paths}


def runtimes():
    return {str(p): sha(p) for p in runtime_paths if p.exists()}


before, runtime_before = sources(), runtimes()
save('source-before.json', before)
save('runtime-before.json', runtime_before)
save('selection.json', SELECTION)
(OUT / 'incoming-retention-audit.json').write_bytes(args.incoming_audit.read_bytes())
report = {'source_head': args.source, 'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'started_utc': now(), 'incoming_audit_sha256': sha(args.incoming_audit),
    'incoming_selected_source_hashes_verified': incoming['selected_source'],
    'compiler_unchanged_from_c623_and_historical_corpus': True,
    'source_files_hashed': len(before), 'selection': SELECTION, 'commands': [],
    'selection_rationale': 'Fresh bridge of the independent 13-case visual-node identity, 17-case direct-format precedence and 41-case contained-text suites against the reconciled incoming Word production. Incoming executions retain separate source/runtime attribution.',
    'dart_version': subprocess.check_output([DART, '--version'], text=True).strip()}


def run(name, command, cwd):
    print('Starting ' + name, flush=True)
    start, started = time.monotonic(), now()
    stdout, stderr = OUT / (name + '.stdout.log'), OUT / (name + '.stderr.log')
    with stdout.open('w') as out, stderr.open('w') as err:
        result = subprocess.run([str(v) for v in command], cwd=cwd, env=environment, stdout=out, stderr=err)
    row = {'name': name, 'command': [str(v) for v in command], 'cwd': str(cwd),
        'started_utc': started, 'finished_utc': now(), 'seconds': round(time.monotonic() - start, 3),
        'exit_code': result.returncode, 'stdout': stdout.name, 'stdout_sha256': sha(stdout),
        'stderr': stderr.name, 'stderr_sha256': sha(stderr)}
    report['commands'].append(row)
    save('progress.json', report)
    print('Finished ' + name + ': exit ' + str(result.returncode), flush=True)


run('word-bridge', [DART, '--old_gen_heap_size=768', f'--packages={CONFIG}', KERNEL,
    '--compiler', 'source', '--concurrency=1', '--timeout=4x', '--reporter=json',
    *[str((REPO / p).relative_to(ENGINE)) for p in SELECTION]], ENGINE)
events, malformed = [], []
for number, line in enumerate((OUT / 'word-bridge.stdout.log').read_text().splitlines(), 1):
    if line.startswith('{'):
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            malformed.append(number)
suites = {}
for event in events:
    if event.get('type') == 'suite':
        path = Path(event['suite']['path'])
        if not path.is_absolute():
            path = ENGINE / path
        suites[event['suite']['id']] = str(path.resolve().relative_to(REPO))
starts = {event['test']['id']: event['test'] for event in events if event.get('type') == 'testStart'}
done = [event for event in events if event.get('type') == 'testDone']
completion_counts = collections.Counter(event['testID'] for event in done)
occurrences, cases = collections.Counter(), []
for event in done:
    if event.get('hidden'):
        continue
    test = starts[event['testID']]
    path = suites[test['suiteID']]
    occurrences[(path, test['name'])] += 1
    cases.append({'file': path, 'name': test['name'], 'occurrence': occurrences[(path, test['name'])],
        'result': event['result'], 'skipped': bool(event.get('skipped'))})
save('word-bridge-cases.json', cases)
passed = collections.Counter(r['file'] for r in cases if r['result'] == 'success' and not r['skipped'])
report['tests'] = {'passed': sum(passed.values()), 'failed': sum(r['result'] != 'success' for r in cases),
    'skipped': sum(r['skipped'] for r in cases), 'per_file_passed': dict(passed),
    'exact_selected_population': dict(passed) == SELECTION, 'malformed_reporter_lines': malformed,
    'reporter_errors': sum(e.get('type') == 'error' for e in events),
    'every_started_test_completed_once': set(starts) == set(completion_counts) and all(n == 1 for n in completion_counts.values()),
    'terminal_success': bool(events and events[-1].get('type') == 'done' and events[-1].get('success'))}
run('engine-analysis', [DART, 'analyze', '--fatal-infos'], ENGINE)
run('format', [FDART, 'format', '--output=none', '--set-exit-if-changed', *FORMAT_PATHS], REPO)
after, runtime_after = sources(), runtimes()
save('source-after.json', after)
save('runtime-after.json', runtime_after)
report.update({'source_unchanged': before == after, 'runtime_unchanged': runtime_before == runtime_after,
    'head_unchanged': git('rev-parse', 'HEAD') == args.source, 'worktree_clean': not git('status', '--porcelain'),
    'finished_utc': now()})
tests = report['tests']
report['success'] = all(c['exit_code'] == 0 for c in report['commands']) and tests['passed'] == 71 and \
    tests['failed'] == tests['skipped'] == tests['reporter_errors'] == 0 and not malformed and \
    all(tests[k] for k in ['exact_selected_population', 'every_started_test_completed_once', 'terminal_success']) and \
    all(report[k] for k in ['source_unchanged', 'runtime_unchanged', 'head_unchanged', 'worktree_clean'])
save('qualification.json', report)
print(json.dumps({'success': report['success'], 'tests': tests, 'source_unchanged': report['source_unchanged'],
    'runtime_unchanged': report['runtime_unchanged']}), flush=True)
raise SystemExit(0 if report['success'] else 1)
