"""Read-only, bounded audit of PR275 Word evidence against the selected union.

Reads Git objects and archive members; never fetches, extracts, or executes tests.
The historical archive's unrelated missing promisor ancestry is not required for
the direct peer/main blob bindings established here.
"""
from collections import Counter
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile

BASE = Path('/workspace/scratch/03cd41fa0e7e')
ROOT = BASE / 'quds_merge_final'
RUNTIME = BASE / 'runtime'
DOCS = ROOT / 'docs/validation/mail-bulk-flags-20261120'
OUT = RUNTIME / 'incoming-pr275-word-evidence-audit.json'
PEER = '44f3f61fa7d812971e973f1763ac8e04eb39785a'
PRODUCTION = '64da231816b1b3ddab35e0e12d50d885bf24f75f'
MAIN = '5e7e4d24284954603a0a5951699bea870ad1955f'
PRIOR = 'c62338c65571aa399da5592455b651fa5c6a9317'
ENGINE = 'packages/quds_office_engine/'
EDITOR = 'packages/quds_office_editor/'
ENV = os.environ | {'GIT_NO_LAZY_FETCH': '1', 'GIT_TERMINAL_PROMPT': '0'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args, data=None):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], input=data, env=ENV)


trees, blobs = {}, {}


def tree(head):
    if head not in trees:
        rows = {}
        for row in git('ls-tree', '-rz', head).split(b'\0'):
            if row:
                header, path = row.split(b'\t', 1)
                mode, kind, oid = header.decode().split()
                rows[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
        trees[head] = rows
    return trees[head]


def preload(head, paths):
    ids = sorted({tree(head)[p]['oid'] for p in paths if p in tree(head)} - blobs.keys())
    if not ids:
        return
    stream = io.BytesIO(git('cat-file', '--batch', data=('\n'.join(ids) + '\n').encode()))
    for oid in ids:
        meta = stream.readline().decode().split()
        assert len(meta) == 3 and meta[:2] == [oid, 'blob'], meta
        body = stream.read(int(meta[2]))
        assert stream.read(1) == b'\n'
        blobs[oid] = body


def body(head, path):
    preload(head, [path])
    return blobs[tree(head)[path]['oid']]


def compare(hashes, head):
    preload(head, hashes)
    different, runtime = [], []
    for p, digest in hashes.items():
        if p == '.dart_tool/package_config.json':
            runtime.append({'path': p, 'recorded_sha256': digest})
        else:
            actual = sha(body(head, p)) if p in tree(head) else None
            if actual != digest:
                different.append({'path': p, 'recorded_sha256': digest, 'git_sha256': actual})
    return {'commit': head, 'tracked_inputs': len(hashes) - len(runtime),
            'differences': different, 'untracked_runtime_inputs': runtime}


def relative(path, cwd):
    if '/quds_office_suite/' in path:
        return path.split('/quds_office_suite/', 1)[1]
    return str(Path(cwd.split('/quds_office_suite/', 1)[1]) / path)


def raw_cases(data, row):
    text = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', data.decode())
    terminal = re.search(r'\+(\d+)(?: ~(\d+))?: All tests passed!\s*$', text)
    assert terminal and row['exit_code'] == 0
    passed, skipped = int(terminal[1]), int(terminal[2] or 0)
    assert passed == row.get('passed', passed) and skipped == row.get('skipped', skipped)
    command = row.get('argv', row.get('command'))
    selected = [relative(p, row['cwd']) for p in command if p.endswith('_test.dart')]
    cases, counters, occurrence = [], [], Counter()
    for line in text.splitlines():
        m = re.match(r'\d+:\d+ \+(\d+)(?: ~(\d+))?(?: -(\d+))?: (.*)$', line)
        if not m:
            continue
        assert not m[3], line
        counts = (int(m[1]), int(m[2] or 0))
        counters.append(counts)
        label = m[4]
        if label.startswith('loading ') or label == 'All tests passed!':
            continue
        named = re.match(r'((?:/[^:]+|test/[^:]+)\.dart): (.*)$', label)
        if named:
            path, name = relative(named[1], row['cwd']), named[2]
        elif len(selected) == 1:
            path, name = selected[0], label
        else:
            raise AssertionError(('Unclassified reporter entry', row['name'], line))
        if name.startswith(('(setUpAll)', '(tearDownAll)')):
            continue
        assert path in selected, (path, selected)
        occurrence[(path, name)] += 1
        cases.append({'file': path, 'name': name, 'occurrence': occurrence[(path, name)],
                      'before': counts})
    assert all(a[0] <= b[0] and a[1] <= b[1] for a, b in zip(counters, counters[1:]))
    for i, case in enumerate(cases):
        after = cases[i + 1]['before'] if i + 1 < len(cases) else (passed, skipped)
        delta = (after[0] - case['before'][0], after[1] - case['before'][1])
        assert delta in ((1, 0), (0, 1)), (row['name'], case, delta)
        case['result'] = 'passed' if delta == (1, 0) else 'skipped'
        del case['before']
    assert sum(c['result'] == 'passed' for c in cases) == passed
    assert sum(c['result'] == 'skipped' for c in cases) == skipped
    return {'passed': passed, 'skipped': skipped, 'terminal_success': True,
            'per_file_passed': dict(Counter(c['file'] for c in cases if c['result'] == 'passed')),
            'case_identities': cases}


manifest_bytes = (DOCS / 'late-evidence-members.json').read_bytes()
manifest = json.loads(manifest_bytes)
archive_bytes = (DOCS / 'late-evidence.tar.gz').read_bytes()
assert len(archive_bytes) == manifest['archive']['bytes']
assert sha(archive_bytes) == manifest['archive']['sha256']
members = {}
with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as tar:
    for entry in tar:
        assert entry.isfile() and entry.name not in members
        assert not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts
        members[entry.name] = tar.extractfile(entry).read()
assert len(members) == manifest['member_count'] == 271
assert set(members) == {r['path'] for r in manifest['members']}
for r in manifest['members']:
    assert len(members[r['path']]) == r['bytes'] and sha(members[r['path']]) == r['sha256']

archive_verifier = json.loads((RUNTIME / 'incoming-pr275-archive-verifier.json').read_text())
assert archive_verifier['status'] == 'PASS' and archive_verifier['mode'] == 'archive-only'
assert archive_verifier['archive_sha256'] == sha(archive_bytes)
commits = {}
for head in (PRODUCTION, PEER, MAIN, PRIOR):
    raw = git('cat-file', 'commit', head).decode()
    commits[head] = {'tree': re.search(r'^tree (\w+)$', raw, re.M)[1],
                     'parents': re.findall(r'^parent (\w+)$', raw, re.M)}
assert commits[PEER]['tree'] == '9ad9555b01e5c0a0872f868356c232e669a8b977'

cohorts = {}
receipt_paths = [f'peer-main/word/{n}.json' for n in (
    'word-vm', 'word-node', 'focused-vm', 'word-analyze', 'focused-analyze',
    'word-format-check', 'focused-format-check', 'measurements-driver-vm',
    'measurements-driver-js-compile', 'measurements-driver-js-run',
    'named_measurements-driver-vm', 'named_measurements-driver-js-compile',
    'named_measurements-driver-js-run')]
receipt_paths += [f'peer-main/zotero/{n}.json' for n in (
    'zotero-vm', 'zotero-node', 'zotero-analyze', 'zotero-format-check')]
rows = [(p, json.loads(members[p])) for p in receipt_paths]
host_rows = json.loads(members['peer-main/hosts/receipt.json'])
rows += [('peer-main/hosts/receipt.json', r) for r in host_rows if r['name'] in (
    'zotero-editor', 'zotero-studio', 'font-tests', 'zotero-editor-analysis', 'font-analysis')]
for path, row in rows:
    before = row.get('source_before', row.get('source_hashes_before'))
    after = row.get('source_after', row.get('source_hashes_after'))
    assert before == after and before
    assert row.get('source_unchanged', row.get('sources_unchanged', False))
    assert row['exit_code'] == 0
    log_ref = row['log']
    log = log_ref.split('/late-main-validation/', 1)[1] if '/late-main-validation/' in log_ref else str(Path(path).parent / log_ref)
    assert sha(members[log]) == row['log_sha256']
    binding_peer = compare(before, PEER)
    assert not binding_peer['differences'], (path, binding_peer['differences'])
    binding_main = compare(before, MAIN)
    current_diff = [p for p, h in before.items() if p != '.dart_tool/package_config.json'
                    and (not (ROOT / p).is_file() or sha((ROOT / p).read_bytes()) != h)]
    item = {'receipt': path, 'receipt_sha256': sha(members[path]), 'name': row['name'],
            'log': log, 'log_sha256': row['log_sha256'], 'command': row.get('argv', row.get('command')),
            'exit_code': 0, 'source_before_equals_after': True,
            'peer_git_binding': binding_peer, 'main_git_binding': binding_main,
            'selected_worktree_differences': current_diff}
    if row['name'] in ('word-vm', 'word-node', 'focused-vm', 'zotero-vm', 'zotero-node',
                       'zotero-editor', 'zotero-studio', 'font-tests'):
        item['raw'] = raw_cases(members[log], row)
    cohorts[row['name']] = item

for name in ('word-vm', 'word-node', 'zotero-vm', 'zotero-node'):
    assert not cohorts[name]['selected_worktree_differences']
    assert not cohorts[name]['main_git_binding']['differences']
two_variants = {ENGINE + 'test/word_styles_layout_test.dart', ENGINE + 'test/word_contained_text_wrap_test.dart'}
assert set(cohorts['focused-vm']['selected_worktree_differences']) == two_variants

# Broad host snapshots include unrelated Mail files. All selected editor tests,
# engine/editor libraries and their Dart test support remain exact. Studio is
# recorded but not adopted as exact-current because its app may load Mail.
editor_paths = {p for p in tree(PEER) if p.startswith((ENGINE + 'lib/', EDITOR + 'lib/', EDITOR + 'test/'))}
assert editor_paths <= tree(MAIN).keys()
assert all(tree(PEER)[p] == tree(MAIN)[p] for p in editor_paths)
assert all(body(PEER, p) == (ROOT / p).read_bytes() for p in editor_paths)
no_mail_imports = []
for p in editor_paths:
    if p.endswith('.dart'):
        directives = re.findall(r'^\s*(?:import|export|part)\s+[^;]+;', body(PEER, p).decode(), re.M)
        if any('quds_mail' in d or 'studio_mail' in d for d in directives):
            no_mail_imports.append(p)
assert not no_mail_imports

# Test fixtures outside recorded Dart source manifests are compared as immutable
# Git objects, not mislabeled as per-file before/after runtime seals.
fixture_paths = {p for p in tree(PEER) if '/test/fixtures/' in p or '/fonts/' in p or p.startswith('docs/validation/word-line-boxes-20261120/reference/') or p.startswith('docs/validation/word-run-vertical-alignment-20261120/reference/')}
fixture_same = sorted(p for p in fixture_paths if tree(PEER).get(p) == tree(MAIN).get(p) == tree(PRIOR).get(p))
fixture_different = sorted(fixture_paths - set(fixture_same))
assert not fixture_different
fixture_inventory = [{'path': p, 'git_blob': tree(PEER)[p]['oid']} for p in fixture_same]

driver_pairs = []
for name in ('measurements', 'named_measurements'):
    record = json.loads(members[f'peer-main/word/{name}-vm-js-comparison.json'])
    vm = json.loads(members[f'peer-main/word/{name}-driver-vm.log'])
    js = json.loads(members[f'peer-main/word/{name}-driver-js-run.log'])
    assert vm == js == record['vm_json'] == record['js_json'] and record['json_equal']
    driver_pairs.append({'name': name, 'equal_json': True, 'comparison_sha256': sha(members[f'peer-main/word/{name}-vm-js-comparison.json'])})

fresh = {ENGINE + 'test/word_header_picture_identity_test.dart': 13,
         ENGINE + 'test/word_styles_layout_test.dart': 17,
         ENGINE + 'test/word_contained_text_wrap_test.dart': 41}
for p in fresh:
    assert body(PRIOR, p) == (ROOT / p).read_bytes()
source_paths = [ENGINE + 'lib/src/word/layout/word_layout.dart', ENGINE + 'lib/src/word/serial/word_deserializer.dart']
new_tests = [ENGINE + 'test/word_header_visual_reconciliation_test.dart', ENGINE + 'test/word_table_style_import_regression_test.dart']
for p in source_paths + new_tests:
    assert body(PEER, p) == body(MAIN, p) == (ROOT / p).read_bytes()
all_engine_editor_libs = {p for p in tree(PEER) if p.startswith((ENGINE + 'lib/', EDITOR + 'lib/'))}
assert all(tree(PEER)[p] == tree(MAIN)[p] for p in all_engine_editor_libs)
production_delta = [p for p in all_engine_editor_libs if tree(PRIOR).get(p) != tree(MAIN).get(p)]
assert set(production_delta) == set(source_paths)
compiler_bas = [p for p in tree(MAIN) if p.startswith((ENGINE + 'lib/src/automation/', ENGINE + 'example/macros/'))]
assert all(tree(PRIOR).get(p) == tree(MAIN)[p] for p in compiler_bas)

def ids(cases):
    return {(c['file'], c['name'], c['occurrence']) for c in cases if c['result'] == 'passed'}

combined_ids = ids(cohorts['word-vm']['raw']['case_identities'])
focused_exact = [c for c in cohorts['focused-vm']['raw']['case_identities'] if c['file'] not in two_variants]
assert len(focused_exact) == 188
assert ids(cohorts['word-node']['raw']['case_identities']) <= combined_ids
assert ids(cohorts['zotero-node']['raw']['case_identities']) <= ids(cohorts['zotero-vm']['raw']['case_identities'])
exact_word = combined_ids | ids(focused_exact)
assert len(exact_word) == 1055
report = {'schema': 1, 'success': True, 'audit_kind': 'Read-only incoming evidence and selected-source binding; no fresh tests executed.',
          'incoming_peer': PEER, 'incoming_production_checkpoint': PRODUCTION, 'incoming_main': MAIN,
          'prior_qualified_source': PRIOR, 'commits': commits,
          'archive': {'path': str((DOCS / 'late-evidence.tar.gz').relative_to(ROOT)),
                      'bytes': len(archive_bytes), 'sha256': sha(archive_bytes), 'members_verified': len(members),
                      'manifest_sha256': sha(manifest_bytes)},
          'archive_only_verifier': {'path': str(RUNTIME / 'incoming-pr275-archive-verifier.json'),
                                    'sha256': sha((RUNTIME / 'incoming-pr275-archive-verifier.json').read_bytes()),
                                    'status': 'PASS'},
          'full_historical_verifier_limit': 'Git-qualified archive verifier encountered an unavailable old promisor object df576aa4e32c8c151446309ea1c72dab11d84f06 while checking unrelated baseline3645 ancestry. No fetch was attempted. This audit directly verifies all selected receipts against available44f3/5e7 blobs instead.',
          'cohorts': cohorts,
          'selected_source': {p: sha((ROOT / p).read_bytes()) for p in source_paths + new_tests + sorted(fresh)},
          'engine_editor_production_delta_vs_c623': sorted(production_delta),
          'engine_editor_libraries_peer_equals_main': len(all_engine_editor_libs),
          'editor_library_and_test_inputs_peer_equals_main_and_worktree': len(editor_paths),
          'editor_directives_reference_no_changed_mail_packages': True,
          'reference_fixture_git_inventory': fixture_inventory,
          'reference_fixture_binding_limit': 'Immutable peer/main/c623 Git object equivalence, not an additional historical per-file before/after execution seal.',
          'compiler_and_macro_files_unchanged_from_c623': len(compiler_bas),
          'bas_driver_pairs': driver_pairs,
          'retained_exact_word_population': {'combined_vm': 929, 'focused_exact_vm': 188,
              'overlap_cases': 62, 'unique_vm': len(exact_word), 'node_rechecks': 787,
              'excluded_incoming_variant_suites': sorted(two_variants)},
          'retained_affected_zotero': {'engine_vm': 165, 'node_rechecks': 117,
              'editor_vm': 362, 'editor_skipped': 8,
              'editor_scope': 'Nine Zotero suites plus incremental-layout and two proofing suites; overlap historical acceptance, not additional logical cases.',
              'font_vm': 9, 'studio_16': 'Recorded only, not asserted exact-current because Studio may load changed Mail paths.'},
          'fresh_bridge': {'tests': fresh, 'expected_passed': 71, 'analyses': ['whole-engine dart analyze --fatal-infos'],
              'format_paths': sorted(set(source_paths + new_tests + list(fresh))),
              'reason': 'Preserve our additional13 node-identity assertions and17 direct-format suite, plus the canonical41 contained-text fixture variant. Incoming new29 tests already run against exactly selected libraries and are retained.'},
          'carry_forward_policy': 'The c623 receipts keep their original source bindings. Only this narrow two-file production delta is newly qualified by incoming exact-source runs and the pending71-case fresh bridge; do not describe all earlier1313 tests as rerun on latest main.',
          'limits': ['Historical execution used its recorded runtime, not this session runtime.',
                     'JavaScript evidence is Node execution, not browser/WASM.',
                     'No installed Microsoft Word/Zotero host or live provider session was exercised.',
                     'Final remote source SHA must bind these selected hashes before the fresh bridge runs.'],
          'auditor_sha256': sha(Path(__file__).read_bytes())}
OUT.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'path': str(OUT), 'sha256': sha(OUT.read_bytes()), 'success': True,
                  'word_exact_vm_unique': len(exact_word), 'fresh_bridge': 71,
                  'archive_members': len(members)}, sort_keys=True))
