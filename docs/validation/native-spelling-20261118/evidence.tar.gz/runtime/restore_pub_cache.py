#!/usr/bin/env python3
"""Restore authentic lock-pinned Pub archives for local spelling validation."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import io
import json
import os
import shutil
import signal
import subprocess
import tarfile
import time
import urllib.parse
import urllib.request
import yaml

ROOT = Path(__file__).resolve().parent.parent
TOOLS = ROOT / "toolchains"
SDK = TOOLS / "flutter"
CACHE = TOOLS / "pub-cache"
REPO = ROOT / "quds_office_suite"
BASELINE = ROOT / "spelling-baseline"
OUT = TOOLS / "dependency-restoration"
OUT.mkdir(parents=True, exist_ok=True)
LOCK = REPO / "docs/validation/native-spacy-w5-20261117/workspace-pubspec.lock"
LOCKS = [SDK / "packages/flutter_tools/pubspec.lock", LOCK]

def digest(data):
    return hashlib.sha256(data).hexdigest()

receipt = {"started_at": datetime.now(timezone.utc).isoformat(),
           "locks": [{"path": str(p), "sha256": digest(p.read_bytes())} for p in LOCKS],
           "packages": [], "commands": [], "status": "running"}

def save():
    (OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")

packages = {}
for lock in LOCKS:
    for name, item in yaml.safe_load(lock.read_text())["packages"].items():
        if item["source"] != "hosted":
            continue
        description = item["description"]
        if description["url"] != "https://pub.dev":
            raise RuntimeError("Unexpected package source")
        key = name + "-" + item["version"]
        expected = description["sha256"]
        if key in packages and packages[key] != expected:
            raise RuntimeError("Conflicting pinned archive identity")
        packages[key] = expected
for path in [CACHE / "_temp", CACHE / "hosted/pub.dev", CACHE / "hosted-hashes/pub.dev"]:
    path.mkdir(parents=True, exist_ok=True)

def fetch(pair):
    key, expected = pair
    url = "https://pub.dev/api/archives/" + urllib.parse.quote(key, safe="-._+") + ".tar.gz"
    result = {"package": key, "url": url, "expected_sha256": expected}
    began = time.monotonic()
    for attempt in range(1, 3):
        try:
            with urllib.request.urlopen(url, timeout=45) as response:
                payload = response.read()
            actual = digest(payload)
            if actual != expected:
                raise RuntimeError("Archive SHA-256 mismatch: " + actual)
            temporary = CACHE / "_temp" / ("native-spelling-verified-" + key)
            if temporary.exists():
                shutil.rmtree(temporary)
            temporary.mkdir()
            with tarfile.open(fileobj=io.BytesIO(payload), mode="r:gz") as archive:
                archive.extractall(temporary, filter="data")
            target = CACHE / "hosted/pub.dev" / key
            if target.exists():
                shutil.rmtree(target)
            temporary.rename(target)
            (CACHE / "hosted-hashes/pub.dev" / (key + ".sha256")).write_text(actual)
            result.update(status="verified", actual_sha256=actual, archive_bytes=len(payload), attempt=attempt)
            break
        except Exception as error:
            result.update(status="failed", error=str(error), attempt=attempt)
    result["elapsed_seconds"] = time.monotonic() - began
    print(key + " " + result["status"], flush=True)
    return result

def run(label, args, cwd, timeout=150):
    path = OUT / (label + ".log")
    env = {**os.environ, "PUB_CACHE": str(CACHE), "XDG_CONFIG_HOME": str(TOOLS / "config"),
           "CI": "true", "DART_SUPPRESS_ANALYTICS": "true", "FLUTTER_SUPPRESS_ANALYTICS": "true",
           "FLUTTER_ROOT": str(SDK)}
    print("START " + label, flush=True)
    began = time.monotonic()
    with path.open("wb") as output:
        process = subprocess.Popen(args, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            code = 124
    result = {"label": label, "argv": args, "cwd": str(cwd), "exit_code": code,
              "elapsed_seconds": time.monotonic()-began, "log": str(path),
              "log_sha256": digest(path.read_bytes())}
    receipt["commands"].append(result)
    save()
    print("END " + label + " " + str(code), flush=True)
    if code:
        print(path.read_text(errors="replace")[-12000:], flush=True)
        raise RuntimeError(label + " failed")

try:
    save()
    print("Restoring " + str(len(packages)) + " pinned hosted archives", flush=True)
    with ThreadPoolExecutor(max_workers=32) as pool:
        receipt["packages"] = list(pool.map(fetch, sorted(packages.items())))
    save()
    failed = [p for p in receipt["packages"] if p["status"] != "verified"]
    if failed:
        raise RuntimeError("Failed archives: " + json.dumps(failed))
    dart = str(SDK / "bin/cache/dart-sdk/bin/dart")
    flutter = str(SDK / "bin/flutter")
    run("flutter-tools-offline", [dart, "pub", "--suppress-analytics", "--directory",
        str(SDK / "packages/flutter_tools"), "get", "--example", "--offline"], REPO)
    for name, repo in [("workspace", REPO), ("baseline", BASELINE)]:
        if not (repo / "pubspec.lock").exists():
            shutil.copyfile(LOCK, repo / "pubspec.lock")
        run(name + "-offline", [flutter, "pub", "get", "--offline"], repo)
        config = repo / ".dart_tool/package_config.json"
        receipt[name] = {"lock_sha256": digest((repo / "pubspec.lock").read_bytes()),
                         "package_config_sha256": digest(config.read_bytes()),
                         "package_count": len(json.loads(config.read_text())["packages"])}
    receipt["status"] = "passed"
except Exception as error:
    receipt["status"] = "failed"
    receipt["error"] = str(error)
finally:
    receipt["finished_at"] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps({k: v for k, v in receipt.items() if k not in ["packages", "locks"]}), flush=True)
raise SystemExit(0 if receipt["status"] == "passed" else 1)
