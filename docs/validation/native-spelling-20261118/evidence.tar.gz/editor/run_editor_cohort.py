#!/usr/bin/env python3
"""Run the bounded editor proofing cohort with exact before/after source seals."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/workspace/scratch/a43ef7a44754/quds_office_suite')
OUTPUT = Path('/workspace/scratch/a43ef7a44754/platform-validation/editor-cohort')
TOOLCHAINS = Path('/workspace/scratch/a43ef7a44754/toolchains')
WORKDIR = ROOT / 'packages/quds_office_editor'
OUTPUT.mkdir(parents=True, exist_ok=True)

tests_dir = ROOT / 'packages/quds_office_editor/test'
tests = sorted({
    tests_dir / 'platform_spelling_provider_test.dart',
    tests_dir / 'word_manual_proofing_test.dart',
    *tests_dir.glob('word_*proofing*_test.dart'),
})
sources = sorted({
    *ROOT.joinpath('packages/quds_office_engine/lib').rglob('*.dart'),
    *ROOT.joinpath('packages/quds_office_editor/lib').rglob('*.dart'),
    *tests,
    *[ROOT / path for path in (
        '.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
        '.dart_tool/package_config.json',
        'packages/quds_office_engine/pubspec.yaml',
        'packages/quds_office_editor/pubspec.yaml',
        'packages/quds_office_editor/analysis_options.yaml',
    ) if (ROOT / path).is_file()],
})

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    return {str(path.relative_to(ROOT)): digest(path) for path in sources}

def save(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2) + '\n')

environment = {
    'TMPDIR': str(TOOLCHAINS / 'tmp'),
    'PUB_CACHE': str(TOOLCHAINS / 'pub-cache'),
    'XDG_CONFIG_HOME': str(TOOLCHAINS / 'config'),
    'CI': 'true', 'DART_SUPPRESS_ANALYTICS': 'true',
    'FLUTTER_SUPPRESS_ANALYTICS': 'true',
}
env = os.environ | environment
command = [str(TOOLCHAINS / 'flutter/bin/flutter'), 'test', '--no-pub',
           '--concurrency=2', '--reporter', 'json',
           *[str(path.relative_to(WORKDIR)) for path in tests]]
before = snapshot()
save('source-before.json', before)
for path in [*tests,
             ROOT / 'packages/quds_office_editor/lib/src/proofing/platform_spelling_provider.dart',
             ROOT / 'packages/quds_office_editor/lib/src/proofing/word_proofing.dart',
             ROOT / 'packages/quds_office_engine/lib/src/proofing/german_spelling.dart']:
    target = OUTPUT / 'source' / path.relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
save('command.json', {'argv': command, 'cwd': str(WORKDIR), 'environment': environment})
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OUTPUT / 'events.jsonl').open('w') as stdout, (OUTPUT / 'stderr.log').open('w') as stderr:
    process = subprocess.run(command, cwd=WORKDIR, env=env, stdout=stdout, stderr=stderr)
after = snapshot()
save('source-after.json', after)
events = []
unparsed = []
for line in (OUTPUT / 'events.jsonl').read_text().splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        unparsed.append(line)
by_id = {event['test']['id']: event['test'] for event in events if event.get('type') == 'testStart'}
all_results = [event for event in events if event.get('type') == 'testDone' and not event.get('hidden')]
hooks = [event for event in all_results if by_id.get(event['testID'], {}).get('name') in ('(setUpAll)', '(tearDownAll)')]
results = [event for event in all_results if event not in hooks]
summary = {
    'started_utc': started,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exit_code': process.returncode,
    'done': [event for event in events if event.get('type') == 'done'],
    'files': [str(path.relative_to(ROOT)) for path in tests],
    'passed': sum(event.get('result') == 'success' and not event.get('skipped') for event in results),
    'failed': sum(event.get('result') != 'success' and not event.get('skipped') for event in results),
    'skipped': sum(bool(event.get('skipped')) for event in results),
    'failures': [by_id.get(event['testID'], {}) for event in results if event.get('result') != 'success'],
    'suite_hook_failures': [by_id.get(event['testID'], {}) for event in hooks if event.get('result') != 'success'],
    'source_unchanged': before == after,
    'source_count': len(before),
    'changed_source_paths': [path for path in before if before[path] != after[path]],
    'unparsed_output': unparsed,
    'events_sha256': digest(OUTPUT / 'events.jsonl'),
    'stderr_sha256': digest(OUTPUT / 'stderr.log'),
}
save('summary.json', summary)
print(json.dumps(summary, indent=2))
sys.exit(0 if process.returncode == 0 and before == after else 1)
