from pathlib import Path
import base64
import hashlib
import json
import subprocess
import time

base = Path('/workspace/scratch/8df90910f867')
root = base / 'engine-final-page-setup-validation/packages/quds_office_engine'
runtime = base / 'engine-final-page-setup-validation/validation'
source = root / 'example/macros/word_page_setup.bas'
define = '-DWORD_PAGE_SETUP_BAS_BASE64=' + base64.b64encode(source.read_bytes()).decode()
runner = str(runtime / 'run-engine.sh')
compiled = runtime / 'page-setup-smoke.js'
commands = [
    ('vm', [runner, define, 'tool/macros/web_vba_word_page_setup_smoke.dart']),
    ('compile', [runner, 'compile', 'js', '-O1', define, 'tool/macros/web_vba_word_page_setup_smoke.dart', '-o', str(compiled)]),
    ('js', ['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node', '-e', 'globalThis.self=globalThis; require(process.argv[1]);', str(compiled)]),
]
results = []
for label, command in commands:
    started = time.monotonic()
    with (runtime / f'page-setup-{label}.stdout').open('w') as out, (runtime / f'page-setup-{label}.stderr').open('w') as err:
        result = subprocess.run(command, stdout=out, stderr=err, timeout=180)
    results.append({'command': label, 'exit_code': result.returncode, 'seconds': time.monotonic() - started})
    print(json.dumps(results[-1]), flush=True)
    if result.returncode:
        print((runtime / f'page-setup-{label}.stdout').read_text())
        print((runtime / f'page-setup-{label}.stderr').read_text())
        raise SystemExit(result.returncode)
vm = (runtime / 'page-setup-vm.stdout').read_bytes()
js = (runtime / 'page-setup-js.stdout').read_bytes()
receipt = {'commands': results, 'actual_bas_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'vm_js_byte_identical': vm == js, 'receipt_sha256': hashlib.sha256(vm).hexdigest(), 'receipt': json.loads(vm)}
(runtime / 'page-setup-portable-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
if vm != js:
    raise SystemExit('VM and JavaScript receipts differ')
