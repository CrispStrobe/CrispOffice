#!/usr/bin/env bash
set -euo pipefail
source /workspace/scratch/8df90910f867/.runtime/env.sh
cd /workspace/scratch/8df90910f867/engine-final-page-setup-validation/packages/quds_office_engine
exec dart "$@"
