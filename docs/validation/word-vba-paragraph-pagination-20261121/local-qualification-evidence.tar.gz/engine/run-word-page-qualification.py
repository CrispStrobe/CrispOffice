from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE = Path('/workspace/scratch/8df90910f867')
REPO = BASE / 'quds_office_suite'
ROOT = BASE / 'engine-final-page-setup-validation/packages/quds_office_engine'
RUNTIME = BASE / 'engine-final-page-setup-validation/validation'
RUNNER = str(RUNTIME / 'run-engine.sh')
tests = sorted({str(p.relative_to(ROOT))
                for pattern in ('office_vba*_test.dart', 'office_macro*_test.dart')
                for p in (ROOT / 'test').glob(pattern)})
for name in ('office_steps_test.dart', 'word_section_clone_fidelity_test.dart',
             'word_header_picture_identity_test.dart', 'word_structure_steps_test.dart',
             'fidelity_waves_test.dart'):
    tests.append('test/' + name)

source_files = [p for p in ROOT.rglob('*') if p.is_file() and
                p.suffix in ('.dart', '.bas') and
                p.relative_to(ROOT).parts[0] in ('lib', 'test', 'tool', 'example')]
before = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in source_files}
commands = [
    ('analysis', [RUNNER, 'analyze', '--fatal-infos', 'lib', 'tool/macros',
                  'test/office_macro_word_page_setup_test.dart',
                  'test/office_vba_word_page_setup_test.dart',
                  'test/office_vba_word_page_setup_integration_test.dart']),
    ('regression', [RUNNER, 'test', *tests, '--reporter', 'json', '--concurrency', '4']),
]
results = []
for label, command in commands:
    start = time.monotonic()
    with (RUNTIME / f'page-setup-{label}.log').open('w') as out:
        result = subprocess.run(command, stdout=out, stderr=subprocess.STDOUT)
    receipt = {'label': label, 'command': command, 'exit_code': result.returncode,
               'seconds': round(time.monotonic() - start, 3)}
    results.append(receipt)
    print(json.dumps(receipt), flush=True)
    if result.returncode:
        print((RUNTIME / f'page-setup-{label}.log').read_text()[-15000:], flush=True)
        break
events = []
log = RUNTIME / 'page-setup-regression.log'
if log.exists():
    for line in log.read_text().splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            continue
        events.append(event)
done = [event for event in events if event.get('type') == 'testDone' and not event.get('hidden')]
after = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in source_files}
receipt = {'results': results, 'test_files': tests, 'test_file_count': len(tests),
           'passed': sum(e.get('result') == 'success' and not e.get('skipped') for e in done),
           'failed': sum(e.get('result') in ('failure', 'error') for e in done),
           'skipped': sum(bool(e.get('skipped')) for e in done),
           'source_inputs_unchanged': before == after,
           'source_files_checked': len(before),
           'source_sha256': before,
           'final_event': next((e for e in reversed(events) if e.get('type') == 'done'), None)}
(RUNTIME / 'page-setup-qualification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items()
                  if key not in ('source_sha256', 'test_files')}), flush=True)
raise SystemExit(0 if all(r['exit_code'] == 0 for r in results) and before == after else 1)
