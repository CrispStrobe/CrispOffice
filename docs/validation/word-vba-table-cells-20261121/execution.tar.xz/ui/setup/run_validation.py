import os,sys,json,subprocess,time,hashlib
from pathlib import Path
base=Path('/workspace/scratch/1ba3887906e6')
name,cwd,*args=sys.argv[1:]
folder=base/'incoming-validation-logs'/name
folder.mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
env.update({'CI':'true','DART_SUPPRESS_ANALYTICS':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','TMPDIR':str(base/'sdk-runtime/tmp'),'PUB_CACHE':str(base/'sdk-runtime/pub-cache'),'XDG_CONFIG_HOME':str(base/'sdk-runtime/config'),'XDG_CACHE_HOME':str(base/'sdk-runtime/cache')})
env['PATH']=str(base/'sdk-runtime/flutter/bin')+':'+env['PATH']
repo=base/'quds_office_suite'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
def snapshot():
 paths=set(repo.glob('packages/*/lib/**/*.dart')) | set(repo.glob('packages/quds_office_editor/example/lib/**/*.dart'))
 for arg in args:
  candidate=Path(cwd)/arg
  if arg.endswith('.dart') and candidate.is_file():paths.add(candidate.resolve())
 paths.update(repo.glob('packages/*/pubspec.yaml'))
 paths.add(repo/'pubspec.lock')
 return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=snapshot()
(folder/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
started=time.time()
(folder/'command.json').write_text(json.dumps({'cwd':cwd,'args':args,'head_at_start':head,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(started)),'sdk':'Flutter 3.47.8 / Dart 3.13.7','pubspec_lock_sha256':hashlib.sha256((base/'workspace-validation-runtime/pubspec.lock').read_bytes()).hexdigest()},indent=2)+'\n')
with (folder/'stdout.log').open('w') as out,(folder/'stderr.log').open('w') as err:
 result=subprocess.run(args,cwd=cwd,env=env,stdout=out,stderr=err)
after=snapshot()
(folder/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
changed=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
receipt={'sources_changed_during_run':changed,'exit_code':result.returncode,'elapsed_seconds':round(time.time()-started,3),'head_at_end':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()}
(folder/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'folder':str(folder),**receipt}),flush=True)
for log in ['stdout.log','stderr.log']:
 lines=(folder/log).read_text().splitlines()
 print(log+':')
 print('\n'.join(lines[-35:]))
sys.exit(result.returncode)
