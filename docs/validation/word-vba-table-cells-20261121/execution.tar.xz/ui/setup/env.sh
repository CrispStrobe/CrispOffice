export CI=true
export FLUTTER_SUPPRESS_ANALYTICS=true
export DART_SUPPRESS_ANALYTICS=true
export TMPDIR=/workspace/scratch/1ba3887906e6/sdk-runtime/tmp
export PUB_CACHE=/workspace/scratch/1ba3887906e6/sdk-runtime/pub-cache
export XDG_CONFIG_HOME=/workspace/scratch/1ba3887906e6/sdk-runtime/config
export XDG_CACHE_HOME=/workspace/scratch/1ba3887906e6/sdk-runtime/cache
export PATH=/workspace/scratch/1ba3887906e6/sdk-runtime/flutter/bin:/workspace/scratch/1ba3887906e6/sdk-runtime/dart-sdk/bin:$PATH
