from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

workspace = Path('/workspace/scratch/9f1eb3b4a51a')
root = Path(sys.argv[1]).resolve()
label = sys.argv[2] if len(sys.argv) > 2 else 'cell-formatting-cli'
package = root / 'packages/quds_office_engine'
runtime = workspace / 'dart-runtime'
dart = runtime / 'dart-sdk/bin/dart'
env = os.environ.copy()
env['TMPDIR'] = str(runtime / 'tmp')
env['PUB_CACHE'] = str(runtime / 'pub-cache')
env['PATH'] = str(dart.parent) + os.pathsep + env.get('PATH', '')
outdir = root / 'validation-results' / label
outdir.mkdir(parents=True, exist_ok=True)
config = root / '.dart_tool/package_config.json'
source = package / 'example/macros/word_table_formatting.bas'
probe = outdir / 'fixture_probe.dart'
portable = package / 'tool/macros/web_vba_word_cell_formatting_smoke.dart'
probe.write_text("import 'dart:convert';\nimport 'dart:io';\n" +
    "import 'package:quds_office_engine/quds_office_engine.dart';\n" +
    f"import '{portable.as_uri()}' as portable;\n" + '''
void main(List<String> args) {
  if (args.first == 'prepare') {
    File(args[1]).writeAsBytesSync(portable.wordCellFormattingInput());
    print(jsonEncode({'fixture': args[1], 'macroEnabled': true}));
  } else {
    final bytes = File(args[1]).readAsBytesSync();
    portable.assertWordCellFormattingOutput(bytes);
    final package = OpcPackage.openBytes(bytes);
    final vba = package.getPart('/word/vbaProject.bin')!.readBytes();
    if (base64Encode(vba) != base64Encode([0, 7, 42, 128, 255])) {
      throw StateError('CLI failed to preserve opaque VBA project');
    }
    if (package.getPart('/customXml/table.xml') == null) {
      throw StateError('CLI failed to preserve custom XML');
    }
    print(jsonEncode({'formattingCorrect': true, 'opaqueVbaPreserved': true,
      'customXmlPreserved': true, 'state': portable.wordCellFormattingState(bytes)}));
  }
}
''')
records = []
def run(stage, command, expected=0):
    start = time.time()
    stdout = outdir / f'{stage}.stdout'
    stderr = outdir / f'{stage}.stderr'
    with stdout.open('w') as out, stderr.open('w') as err:
        result = subprocess.run(command, cwd=package, env=env, stdout=out, stderr=err, timeout=180)
    record = {'stage': stage, 'command': command, 'exit_code': result.returncode,
              'seconds': round(time.time() - start, 2), 'stdout': str(stdout), 'stderr': str(stderr)}
    records.append(record)
    print(json.dumps(record), flush=True)
    if result.returncode != expected:
        print(stderr.read_text()[-6000:], flush=True)
        raise AssertionError(f'{stage}: {result.returncode} != {expected}')
    return stdout.read_text(), stderr.read_text()

input_doc = outdir / 'input.docm'
output_doc = outdir / 'output.docm'
compiled = outdir / 'word_table_formatting.qudsmacro.json'
kernel = outdir / 'office_macro.dill'
run('prepare', [str(dart), f'--packages={config}', str(probe), 'prepare', str(input_doc)])
original = input_doc.read_bytes()
run('compile-kernel', [str(dart), 'compile', 'kernel', f'--packages={config}',
                      'tool/macros/office_macro.dart', '-o', str(kernel)])
cli = [str(dart), str(kernel)]
compile_out, _ = run('compile-word-vba', [*cli, 'compile-word-vba', str(source), str(compiled)])
compiled_macro = json.loads(compiled.read_text())
steps = len(compiled_macro['steps'])
validate_out, _ = run('validate-word-vba', [*cli, 'validate-word-vba', str(input_doc), str(source)])
validation = json.loads(validate_out)
assert input_doc.read_bytes() == original
run_out, _ = run('run-word-vba', [*cli, 'run-word-vba', str(input_doc), str(source), str(output_doc)])
execution = json.loads(run_out)
assert input_doc.read_bytes() == original
inspect_out, _ = run('inspect-output', [str(dart), f'--packages={config}', str(probe), 'inspect', str(output_doc)])
saved = output_doc.read_bytes()
invalid = outdir / 'invalid-late-cell.bas'
invalid.write_text('''Sub Main()
ActiveDocument.Tables(1).Cell(1, 1).Range.Text = "Not published"
ActiveDocument.Tables(1).Cell(1, 1).Range.Font.Bold = True
ActiveDocument.Tables(2).Cell(9, 1).Range.Font.Italic = True
End Sub
''')
_, failure_err = run('reject-late-cell', [*cli, 'run-word-vba', str(input_doc), str(invalid), str(output_doc)], expected=1)
failure = json.loads(failure_err)
assert input_doc.read_bytes() == original
assert output_doc.read_bytes() == saved
assert failure['error']['stepIndex'] == 2
summary = {
    'actual_bas': str(source), 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'compiled_operations': steps, 'compile': json.loads(compile_out), 'validation': validation,
    'execution': execution, 'inspection': json.loads(inspect_out), 'failure': failure,
    'input_unchanged': True, 'existing_output_preserved_on_late_failure': True,
    'input_sha256': hashlib.sha256(original).hexdigest(), 'output_sha256': hashlib.sha256(saved).hexdigest(),
    'stages': records,
}
(outdir / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('stages','inspection')}, indent=2), flush=True)
