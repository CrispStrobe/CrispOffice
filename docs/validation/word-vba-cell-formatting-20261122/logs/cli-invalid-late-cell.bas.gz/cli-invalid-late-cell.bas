Sub Main()
ActiveDocument.Tables(1).Cell(1, 1).Range.Text = "Not published"
ActiveDocument.Tables(1).Cell(1, 1).Range.Font.Bold = True
ActiveDocument.Tables(2).Cell(9, 1).Range.Font.Italic = True
End Sub
