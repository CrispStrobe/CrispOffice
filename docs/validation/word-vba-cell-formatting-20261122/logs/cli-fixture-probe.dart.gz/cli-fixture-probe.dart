import 'dart:convert';
import 'dart:io';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'file:///workspace/scratch/9f1eb3b4a51a/engine-validation-ca4d7ea9/packages/quds_office_engine/tool/macros/web_vba_word_cell_formatting_smoke.dart' as portable;

void main(List<String> args) {
  if (args.first == 'prepare') {
    File(args[1]).writeAsBytesSync(portable.wordCellFormattingInput());
    print(jsonEncode({'fixture': args[1], 'macroEnabled': true}));
  } else {
    final bytes = File(args[1]).readAsBytesSync();
    portable.assertWordCellFormattingOutput(bytes);
    final package = OpcPackage.openBytes(bytes);
    final vba = package.getPart('/word/vbaProject.bin')!.readBytes();
    if (base64Encode(vba) != base64Encode([0, 7, 42, 128, 255])) {
      throw StateError('CLI failed to preserve opaque VBA project');
    }
    if (package.getPart('/customXml/table.xml') == null) {
      throw StateError('CLI failed to preserve custom XML');
    }
    print(jsonEncode({'formattingCorrect': true, 'opaqueVbaPreserved': true,
      'customXmlPreserved': true, 'state': portable.wordCellFormattingState(bytes)}));
  }
}
