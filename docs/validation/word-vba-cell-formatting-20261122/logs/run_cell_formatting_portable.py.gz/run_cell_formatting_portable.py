from pathlib import Path
import base64
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

workspace = Path('/workspace/scratch/9f1eb3b4a51a')
root = Path(sys.argv[1]).resolve()
label = sys.argv[2] if len(sys.argv) > 2 else 'cell-formatting-portable'
package = root / 'packages/quds_office_engine'
runtime = workspace / 'dart-runtime'
dart = runtime / 'dart-sdk/bin/dart'
env = os.environ.copy()
env['TMPDIR'] = str(runtime / 'tmp')
env['PUB_CACHE'] = str(runtime / 'pub-cache')
env['PATH'] = str(dart.parent) + os.pathsep + env.get('PATH', '')
node = shutil.which('node', path=env['PATH'])
assert node
source = package / 'example/macros/word_table_formatting.bas'
payload = base64.b64encode(source.read_bytes()).decode()
define = '-DWORD_CELL_FORMAT_BAS_BASE64=' + payload
smoke = 'tool/macros/web_vba_word_cell_formatting_smoke.dart'
output_dir = root / 'validation-results'
output_dir.mkdir(exist_ok=True)
js_path = output_dir / f'{label}.js'
commands = [
    ('vm', [str(dart), define, smoke]),
    ('compile-js', [str(dart), 'compile', 'js', '-O1', define, smoke, '-o', str(js_path)]),
    ('node', [node, '-e', 'globalThis.self = globalThis; require(process.argv[1]);', str(js_path)]),
]
summary = {
    'source': str(source),
    'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'runtime': str(dart),
    'node': node,
    'cwd': str(package),
    'stages': [],
}
for stage, command in commands:
    start = time.time()
    stdout = output_dir / f'{label}-{stage}.stdout'
    stderr = output_dir / f'{label}-{stage}.stderr'
    with stdout.open('w') as out, stderr.open('w') as err:
        result = subprocess.run(command, cwd=package, env=env, stdout=out, stderr=err)
    record = {
        'stage': stage,
        'exit_code': result.returncode,
        'seconds': round(time.time() - start, 2),
        'command': [entry if entry != define else '-DWORD_CELL_FORMAT_BAS_BASE64=<base64 of actual BAS file>' for entry in command],
        'stdout': str(stdout),
        'stderr': str(stderr),
    }
    summary['stages'].append(record)
    print(json.dumps(record), flush=True)
    if result.returncode:
        print(stderr.read_text()[-6000:], flush=True)
        (output_dir / f'{label}.summary.json').write_text(json.dumps(summary, indent=2) + '\n')
        sys.exit(result.returncode)
vm = (output_dir / f'{label}-vm.stdout').read_bytes()
js = (output_dir / f'{label}-node.stdout').read_bytes()
summary['vm_js_byte_identical'] = vm == js
summary['vm_json'] = json.loads(vm)
summary['js_json'] = json.loads(js)
(output_dir / f'{label}.summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
assert vm == js
