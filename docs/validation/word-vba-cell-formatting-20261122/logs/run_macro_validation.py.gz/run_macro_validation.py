from pathlib import Path
import json
import os
import subprocess
import sys
import time

workspace = Path('/workspace/scratch/9f1eb3b4a51a')
root = Path(sys.argv[1]).resolve()
label = sys.argv[2]
package = root / 'packages/quds_office_engine'
if len(sys.argv) > 3:
    paths = sys.argv[3:]
else:
    paths = sorted(
        p.relative_to(package).as_posix()
        for p in (package / 'test').glob('office_*_test.dart')
        if p.name.startswith(('office_macro', 'office_vba'))
    )
runtime = workspace / 'dart-runtime'
dart = runtime / 'dart-sdk/bin/dart'
env = os.environ.copy()
env['TMPDIR'] = str(runtime / 'tmp')
env['PUB_CACHE'] = str(runtime / 'pub-cache')
env['PATH'] = str(dart.parent) + os.pathsep + env.get('PATH', '')
cmd = [str(dart), 'test', '--concurrency=4', '--reporter=json', *paths]
output_dir = root / 'validation-results'
output_dir.mkdir(exist_ok=True)
log = output_dir / f'{label}.jsonl'
stderr_log = output_dir / f'{label}.stderr.log'
start = time.time()
print(json.dumps({'label': label, 'suites': len(paths), 'cwd': str(package), 'log': str(log)}), flush=True)
with log.open('w') as out, stderr_log.open('w') as err:
    result = subprocess.run(cmd, cwd=package, env=env, stdout=out, stderr=err)
events = []
for line in log.read_text().splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        pass
starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
finished = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden')]
summary = {
    'label': label,
    'command': cmd,
    'cwd': str(package),
    'runtime': str(dart),
    'temp_dir': env['TMPDIR'],
    'pub_cache': env['PUB_CACHE'],
    'suites_requested': len(paths),
    'exit_code': result.returncode,
    'seconds': round(time.time() - start, 2),
    'visible_passed': sum(e['result'] == 'success' and not e.get('skipped') for e in finished),
    'visible_failed': sum(e['result'] != 'success' for e in finished),
    'visible_skipped': sum(bool(e.get('skipped')) for e in finished),
    'failed_tests': [starts.get(e['testID'], {}) for e in finished if e['result'] != 'success'],
    'errors': [e for e in events if e.get('type') == 'error'],
    'done': [e for e in events if e.get('type') == 'done'],
    'log': str(log),
    'stderr': str(stderr_log),
}
(output_dir / f'{label}.summary.json').write_text(json.dumps(summary, indent=2) + '\n')
display = {key: value for key, value in summary.items() if key not in ('command', 'errors', 'failed_tests')}
display['failed_tests'] = [test.get('name') for test in summary['failed_tests']]
display['error_excerpts'] = [event['error'][:350] for event in summary['errors']]
print(json.dumps(display, indent=2), flush=True)
sys.exit(result.returncode)
