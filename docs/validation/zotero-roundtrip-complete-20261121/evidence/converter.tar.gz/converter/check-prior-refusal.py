#!/usr/bin/env python3
"""Retain the expected refusal of the untouched earlier converter endnote."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import time

BASE = Path('/workspace/scratch/b47dba313a2c/validation/converter')
spec = importlib.util.spec_from_file_location('acceptance', BASE / 'run-after-note-styles.py')
acceptance = importlib.util.module_from_spec(spec)
spec.loader.exec_module(acceptance)
destination = BASE / 'after-note-styles/prior-export-refusal'
destination.mkdir(parents=True, exist_ok=True)
artifact = BASE / 'saved-first/endnote-only.odt'
before_source = acceptance.snapshot()
before_artifact = acceptance.sha(artifact)
stdout = destination / 'command.stdout'
stderr = destination / 'command.stderr'
probe = BASE / 'prior-endnote-reader-probe.dart'
argv = [str(acceptance.DART), '--packages=../../.dart_tool/package_config.json',
        str(probe), str(artifact)]
receipt = {
    'kind': 'expected-refusal-of-untouched-prior-export',
    'argv': argv,
    'cwd': str(acceptance.ENGINE),
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'input': str(artifact),
    'input_before_sha256': before_artifact,
    'probe_sha256': acceptance.sha(probe),
    'source_before_sha256': before_source['source_sha256'],
    'source_before_head': before_source['head'],
}
start = time.monotonic()
with stdout.open('wb') as out, stderr.open('wb') as err:
    result = subprocess.run(argv, cwd=acceptance.ENGINE, stdin=subprocess.DEVNULL,
                            stdout=out, stderr=err, timeout=180)
after_source = acceptance.snapshot()
receipt.update({
    'exit_code': result.returncode,
    'elapsed_seconds': round(time.monotonic() - start, 3),
    'stdout_sha256': acceptance.sha(stdout),
    'stderr_sha256': acceptance.sha(stderr),
    'input_after_sha256': acceptance.sha(artifact),
    'source_after_sha256': after_source['source_sha256'],
    'source_after_head': after_source['head'],
})
receipt['input_unchanged'] = receipt['input_before_sha256'] == receipt['input_after_sha256']
receipt['source_unchanged'] = receipt['source_before_sha256'] == receipt['source_after_sha256']
receipt['expected_refusal_observed'] = (
    result.returncode != 0 and
    'Unsupported ODT note marker position.' in stderr.read_text() and
    receipt['input_unchanged'] and receipt['source_unchanged']
)
acceptance.write_json(destination / 'receipt.json', receipt)
print(json.dumps(receipt), flush=True)
raise SystemExit(0 if receipt['expected_refusal_observed'] else 1)
