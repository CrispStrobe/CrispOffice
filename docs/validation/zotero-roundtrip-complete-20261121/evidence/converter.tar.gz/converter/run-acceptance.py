#!/usr/bin/env python3
"""Retain exact local converter inputs, outputs, command results and sources."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

WORKSPACE = Path('/workspace/scratch/b47dba313a2c')
REPO = WORKSPACE / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
OUT = WORKSPACE / 'validation/converter'
SOFFICE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/program/soffice')
DART = WORKSPACE / 'runtime/bin/dart'
ROUNDTRIP = 'tool/zotero/odt_roundtrip_acceptance.dart'
IMAGES = 'tool/zotero/odt_image_acceptance.dart'
NAMES = ('body-bibliography', 'table-only', 'endnote-only', 'uppercase-citations')
IMAGE_NAMES = ('png-citations', 'jpeg-citations')
COMMANDS = []


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def files(directory):
    return {str(p.relative_to(directory)): sha(p) for p in sorted(directory.rglob('*')) if p.is_file()}


def snapshot():
    selected = list((ENGINE / 'lib').rglob('*.dart')) + [
        ENGINE / ROUNDTRIP, ENGINE / IMAGES, ENGINE / 'pubspec.yaml',
        REPO / 'pubspec.yaml', REPO / 'pubspec.lock',
        REPO / '.dart_tool/package_config.json',
    ]
    hashes = {str(p.relative_to(REPO)): sha(p) for p in sorted(selected)}
    canonical = json.dumps(hashes, sort_keys=True, separators=(',', ':')).encode()
    return {
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
        'source_sha256': hashlib.sha256(canonical).hexdigest(),
        'files': hashes,
    }


def run(name, argv, timeout=180):
    directory = OUT / 'commands'
    directory.mkdir(parents=True, exist_ok=True)
    stdout = directory / f'{name}.stdout'
    stderr = directory / f'{name}.stderr'
    receipt = {
        'name': name, 'argv': [str(arg) for arg in argv], 'cwd': str(ENGINE),
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'stdout': str(stdout.relative_to(OUT)), 'stderr': str(stderr.relative_to(OUT)),
    }
    start = time.monotonic()
    with stdout.open('wb') as out, stderr.open('wb') as err:
        try:
            result = subprocess.run(argv, cwd=ENGINE, stdin=subprocess.DEVNULL,
                                    stdout=out, stderr=err, timeout=timeout)
            receipt['exit_code'] = result.returncode
        except subprocess.TimeoutExpired:
            receipt['exit_code'] = None
            receipt['timed_out_seconds'] = timeout
    receipt['elapsed_seconds'] = round(time.monotonic() - start, 3)
    receipt['stdout_sha256'] = sha(stdout)
    receipt['stderr_sha256'] = sha(stderr)
    write_json(directory / f'{name}.json', receipt)
    COMMANDS.append(receipt)
    write_json(OUT / 'commands.json', COMMANDS)
    print(json.dumps({'command': name, 'exit_code': receipt['exit_code'],
                      'elapsed_seconds': receipt['elapsed_seconds']}), flush=True)
    if receipt['exit_code'] != 0:
        raise RuntimeError(f'{name} did not exit successfully; inspect raw logs')


def dart(name, tool, *args):
    run(name, [DART, '--packages=../../.dart_tool/package_config.json', tool,
               *[str(arg) for arg in args]])


def convert(name, input_dir, output_dir, names):
    output_dir.mkdir(parents=True, exist_ok=True)
    profile = OUT / 'profiles' / name
    run(name, [SOFFICE, '--headless', f'-env:UserInstallation={profile.as_uri()}',
               '--convert-to', 'odt', '--outdir', output_dir,
               *[input_dir / f'{item}.odt' for item in names]], timeout=120)
    missing = [item for item in names if not (output_dir / f'{item}.odt').is_file()]
    if missing:
        raise RuntimeError(f'{name} did not produce outputs for {missing}')


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    before = snapshot()
    write_json(OUT / 'source-before.json', before)
    original_before = files(OUT / 'original')
    write_json(OUT / 'original-before.json', original_before)
    failures = []
    roundtrip_ok = False
    images_ok = False
    try:
        run('converter-version', [SOFFICE, '--version'])
        run('dart-version', [DART, '--version'])
        try:
            dart('roundtrip-original-verify', ROUNDTRIP, 'verify', OUT / 'original', OUT / 'original')
            convert('roundtrip-first-save', OUT / 'original', OUT / 'saved-first', NAMES)
            dart('roundtrip-first-verify', ROUNDTRIP, 'verify', OUT / 'saved-first', OUT / 'original')
            dart('roundtrip-native-reexport', ROUNDTRIP, 'reexport', OUT / 'saved-first', OUT / 'original', OUT / 'reexported')
            convert('roundtrip-second-save', OUT / 'reexported', OUT / 'saved-second', NAMES)
            dart('roundtrip-second-verify', ROUNDTRIP, 'verify', OUT / 'saved-second', OUT / 'original')
            roundtrip_ok = True
        except Exception as error:
            failures.append({'route': 'roundtrip', 'error': str(error)})
        try:
            dart('images-create', IMAGES, 'create', OUT / 'images/original')
            image_original_before = files(OUT / 'images/original')
            write_json(OUT / 'images/original-before.json', image_original_before)
            convert('images-libreoffice-save', OUT / 'images/original', OUT / 'images/saved', IMAGE_NAMES)
            image_saved_before = files(OUT / 'images/saved')
            write_json(OUT / 'images/saved-before.json', image_saved_before)
            dart('images-native-cycles', IMAGES, 'verify', OUT / 'images/saved', OUT / 'images/original', OUT / 'images/cycles')
            if image_original_before != files(OUT / 'images/original'):
                raise RuntimeError('Image original inputs changed')
            if image_saved_before != files(OUT / 'images/saved'):
                raise RuntimeError('Image converter inputs changed during verification')
            images_ok = True
        except Exception as error:
            failures.append({'route': 'images', 'error': str(error)})
    finally:
        after = snapshot()
        write_json(OUT / 'source-after.json', after)
        original_unchanged = original_before == files(OUT / 'original')
        source_unchanged = before['files'] == after['files']
        if not original_unchanged:
            failures.append({'route': 'inputs', 'error': 'Original fixture files changed'})
        if not source_unchanged:
            failures.append({'route': 'source', 'error': 'Executable source/dependencies changed during conversion'})
        artifacts = {}
        for subdirectory in ('original', 'saved-first', 'reexported', 'saved-second', 'images'):
            directory = OUT / subdirectory
            if directory.exists():
                artifacts[subdirectory] = files(directory)
        write_json(OUT / 'artifacts.json', artifacts)
        receipt = {
            'kind': 'file-conversion-acceptance',
            'installed_zotero_plugin_tested': False,
            'converter_version': (OUT / 'commands/converter-version.stdout').read_text().strip(),
            'source_before_sha256': before['source_sha256'],
            'source_after_sha256': after['source_sha256'],
            'source_unchanged': source_unchanged,
            'original_inputs_unchanged': original_unchanged,
            'roundtrip_fixtures': list(NAMES),
            'roundtrip_matched': roundtrip_ok,
            'image_fixtures': list(IMAGE_NAMES),
            'image_three_native_cycles_matched': images_ok,
            'failures': failures,
            'success': roundtrip_ok and images_ok and not failures,
        }
        write_json(OUT / 'acceptance.json', receipt)
        print(json.dumps(receipt), flush=True)
    return 0 if roundtrip_ok and images_ok and not failures else 1


if __name__ == '__main__':
    sys.exit(main())
