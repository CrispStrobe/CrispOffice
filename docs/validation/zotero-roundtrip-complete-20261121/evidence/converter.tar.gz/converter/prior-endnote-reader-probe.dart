import 'dart:io';

import 'package:quds_office_engine/quds_office_engine.dart';

Future<void> main(List<String> args) async {
  await OdtDocumentReader.readBytes(File(args.single).readAsBytesSync());
}
