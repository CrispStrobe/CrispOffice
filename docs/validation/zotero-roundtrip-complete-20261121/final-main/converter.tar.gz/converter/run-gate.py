#!/usr/bin/env python3
"""Replay immutable actual-host files through the accepted main native code."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

WORKSPACE = Path('/workspace/scratch/b47dba313a2c')
REPO = WORKSPACE / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
OUT = WORKSPACE / 'validation/latest-main/converter'
PRIOR = WORKSPACE / 'validation/converter/after-note-styles'
DART = WORKSPACE / 'runtime/bin/dart'
SOFFICE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/program/soffice')
EXPECTED_HEAD = 'c9709f19a2e6eae03e1114d9e4c254090a1caad6'
REMOTE_EQUIVALENT = 'a7f69313ed2e610f82242c31be8ad5387ae5cea0'
ACCEPTED_MAIN = 'aa861c28e336b17bcd4c259351164380cd6b1438'
EXPECTED_TREE = '8f0acd00b505c230ea6ccd2db2d57e17d7475011'
NAMES = ('body-bibliography', 'table-only', 'endnote-only', 'uppercase-citations')
ROUNDTRIP = 'tool/zotero/odt_roundtrip_acceptance.dart'
IMAGES = 'tool/zotero/odt_image_acceptance.dart'
COMMANDS = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()


def source_snapshot():
    paths = []
    for package in ('quds_office_engine', 'legacy_doc_parser', 'quds_reports'):
        paths.extend((REPO / 'packages' / package / 'lib').rglob('*.dart'))
        paths.append(REPO / 'packages' / package / 'pubspec.yaml')
    paths.extend([REPO / 'pubspec.yaml', REPO / 'pubspec.lock', REPO / '.fvmrc',
                  REPO / '.dart_tool/package_config.json', ENGINE / ROUNDTRIP,
                  ENGINE / IMAGES])
    files = {str(p.relative_to(REPO)): sha(p.read_bytes()) for p in sorted(paths)}
    return {
        'head': git('rev-parse', 'HEAD'),
        'tree': git('rev-parse', 'HEAD^{tree}'),
        'source_sha256': sha(json.dumps(files, sort_keys=True, separators=(',', ':')).encode()),
        'files': files,
    }


def input_snapshot():
    files = {}
    for name in ('original', 'saved-first', 'images/original', 'images/saved'):
        for path in sorted((PRIOR / name).rglob('*')):
            if path.is_file():
                files[str(path.relative_to(PRIOR))] = sha(path.read_bytes())
    return files


def run(name, argv, timeout=600):
    directory = OUT / 'commands'
    directory.mkdir(parents=True, exist_ok=True)
    stdout = directory / f'{name}.stdout'
    stderr = directory / f'{name}.stderr'
    receipt = {
        'name': name, 'argv': [str(a) for a in argv], 'cwd': str(ENGINE),
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'stdout': str(stdout.relative_to(OUT)), 'stderr': str(stderr.relative_to(OUT)),
    }
    start = time.monotonic()
    with stdout.open('wb') as out, stderr.open('wb') as err:
        try:
            result = subprocess.run(argv, cwd=ENGINE, stdin=subprocess.DEVNULL,
                                    stdout=out, stderr=err, timeout=timeout)
            receipt['exit_code'] = result.returncode
        except subprocess.TimeoutExpired:
            receipt['exit_code'] = None
            receipt['timeout_seconds'] = timeout
    receipt['elapsed_seconds'] = round(time.monotonic() - start, 3)
    receipt['stdout_sha256'] = sha(stdout.read_bytes())
    receipt['stderr_sha256'] = sha(stderr.read_bytes())
    write_json(directory / f'{name}.json', receipt)
    COMMANDS.append(receipt)
    write_json(OUT / 'commands.json', COMMANDS)
    print(json.dumps({k: receipt[k] for k in ('name', 'exit_code', 'elapsed_seconds')}), flush=True)
    if receipt['exit_code'] != 0:
        raise RuntimeError(f'{name} did not succeed; raw logs retained')


def dart(name, tool, *args):
    run(name, [DART, '--packages=../../.dart_tool/package_config.json', tool,
               *[str(a) for a in args]])


def main():
    if (OUT / 'commands').exists():
        raise RuntimeError('Refusing to overwrite an existing replay')
    source_before = source_snapshot()
    assert source_before['head'] == EXPECTED_HEAD
    assert source_before['tree'] == EXPECTED_TREE
    assert git('rev-parse', REMOTE_EQUIVALENT + '^{tree}') == EXPECTED_TREE
    write_json(OUT / 'source-before.json', source_before)
    inputs_before = input_snapshot()
    write_json(OUT / 'inputs-before.json', inputs_before)
    prior_evidence = REPO / 'docs/validation/zotero-roundtrip-complete-20261121/evidence'
    prior_index = json.loads((prior_evidence / 'converter-index.json').read_text())
    prior_members = {v['path']: v for v in prior_index['members']}
    assert sha((prior_evidence / 'converter.tar.gz').read_bytes()) == prior_index['archive_sha256']
    provenance = []
    for path, digest in inputs_before.items():
        member = 'converter/after-note-styles/' + path
        assert prior_members[member]['sha256'] == digest
        provenance.append({'path': str(PRIOR / path), 'archive_member': member, 'sha256': digest})
    write_json(OUT / 'input-provenance.json', {
        'archive': str(prior_evidence.relative_to(REPO) / 'converter.tar.gz'),
        'archive_sha256': prior_index['archive_sha256'], 'files': provenance,
        'all_preserved_input_hashes_match_prior_archive': True,
    })
    failures = []
    roundtrip_ok = False
    images_ok = False
    try:
        run('converter-version', [SOFFICE, '--version'], timeout=60)
        run('dart-version', [DART, '--version'], timeout=60)
        try:
            dart('native-reexport', ROUNDTRIP, 'reexport', PRIOR / 'saved-first',
                 PRIOR / 'original', OUT / 'native-reexport')
            saved = OUT / 'saved-current'
            saved.mkdir(parents=True, exist_ok=True)
            profile = OUT / 'profiles/current-save'
            run('current-libreoffice-save', [SOFFICE, '--headless',
                f'-env:UserInstallation={profile.as_uri()}', '--convert-to', 'odt',
                '--outdir', saved,
                *[OUT / 'native-reexport' / f'{name}.odt' for name in NAMES]], timeout=120)
            assert all((saved / f'{name}.odt').is_file() for name in NAMES)
            dart('current-native-verify', ROUNDTRIP, 'verify', saved, PRIOR / 'original')
            roundtrip_ok = True
        except Exception as error:
            failures.append({'route': 'roundtrip', 'error': str(error)})
        try:
            dart('images-native-cycles', IMAGES, 'verify', PRIOR / 'images/saved',
                 PRIOR / 'images/original', OUT / 'image-cycles')
            images_ok = True
        except Exception as error:
            failures.append({'route': 'images', 'error': str(error)})
    finally:
        source_after = source_snapshot()
        inputs_after = input_snapshot()
        write_json(OUT / 'source-after.json', source_after)
        write_json(OUT / 'inputs-after.json', inputs_after)
        source_unchanged = source_before == source_after
        inputs_unchanged = inputs_before == inputs_after
        if not source_unchanged:
            failures.append({'route': 'source', 'error': 'Source/configuration or HEAD changed'})
        if not inputs_unchanged:
            failures.append({'route': 'inputs', 'error': 'Preserved original/host files changed'})
        artifacts = {}
        for root in ('native-reexport', 'saved-current', 'image-cycles'):
            for path in sorted((OUT / root).rglob('*')):
                if path.is_file():
                    artifacts[str(path.relative_to(OUT))] = {
                        'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()),
                    }
        write_json(OUT / 'artifacts.json', artifacts)
        receipt = {
            'schema': 1,
            'kind': 'accepted-main-native-file-replay',
            'local_source_commit': EXPECTED_HEAD,
            'remote_equivalent_commit': REMOTE_EQUIVALENT,
            'source_tree': EXPECTED_TREE,
            'accepted_main_production': ACCEPTED_MAIN,
            'source_before_sha256': source_before['source_sha256'],
            'source_after_sha256': source_after['source_sha256'],
            'source_file_count': len(source_before['files']),
            'source_and_head_unchanged': source_unchanged,
            'preserved_input_count': len(inputs_before),
            'preserved_inputs_unchanged': inputs_unchanged,
            'preserved_inputs_match_prior_archive': True,
            'converter_version': (OUT / 'commands/converter-version.stdout').read_text().strip(),
            'converter_launcher_sha256': sha(SOFFICE.read_bytes()),
            'converter_executable_sha256': sha(SOFFICE.with_name('soffice.bin').read_bytes()),
            'dart_version': (OUT / 'commands/dart-version.stdout').read_text().strip(),
            'roundtrip_fixtures': list(NAMES),
            'roundtrip_fields': 13,
            'roundtrip_matched': roundtrip_ok,
            'image_fixtures': ['png-citations', 'jpeg-citations'],
            'image_three_native_cycles_matched': images_ok,
            'gate_dart_commands': 3,
            'actual_host_save_commands': 1,
            'failures': failures,
            'success': roundtrip_ok and images_ok and not failures,
            'limits': [
                'Reuses immutable previously qualified LibreOffice first-save inputs and authored expected JSON.',
                'The current native reader/DOCX reexport and one new actual LibreOffice save are freshly executed.',
                'The converter is the identified development build; stable LibreOffice releases are not qualified.',
                'No installed Zotero plugin or Microsoft Word application is exercised.',
                'No native footnote reopening or ODT Position interchange is claimed.',
            ],
        }
        write_json(OUT / 'acceptance.json', receipt)
        print(json.dumps(receipt), flush=True)
    return 0 if roundtrip_ok and images_ok and not failures else 1


if __name__ == '__main__':
    raise SystemExit(main())
