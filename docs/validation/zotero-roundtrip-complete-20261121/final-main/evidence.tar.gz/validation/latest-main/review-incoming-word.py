#!/usr/bin/env python3
"""Read Git/archive objects and bind incoming executed gates to accepted main."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

WORKSPACE = Path('/workspace/scratch/b47dba313a2c')
REPO = WORKSPACE / 'quds_office_suite'
OUT = WORKSPACE / 'validation/latest-main'
TARGET = 'aa861c28e336b17bcd4c259351164380cd6b1438'
LOCAL = 'c9709f19a2e6eae03e1114d9e4c254090a1caad6'
REMOTE = 'a7f69313ed2e610f82242c31be8ad5387ae5cea0'
TREE = '8f0acd00b505c230ea6ccd2db2d57e17d7475011'
BASE = 'docs/validation/word-vba-typography-20261121/'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args, data=None):
    return subprocess.check_output(['git', *args], cwd=REPO, input=data)


def show(path):
    return git('show', TARGET + ':' + path)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


archive_raw = show(BASE + 'execution.tar.gz')
archive = tarfile.open(fileobj=io.BytesIO(archive_raw), mode='r:gz')
manifest_raw = show(BASE + 'archive-manifest.json')
manifest = json.loads(manifest_raw)
validation_raw = show(BASE + 'validation.json')
validation = json.loads(validation_raw)
assert sha(archive_raw) == validation['archive_sha256']
assert set(archive.getnames()) == set(manifest['files']) | {'manifest.json'}
for name, expected in manifest['files'].items():
    raw = archive.extractfile(name).read()
    assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256']
assert sha(archive.extractfile('manifest.json').read()) == manifest['embedded_manifest_sha256']


def member(name):
    return json.load(archive.extractfile(name))


def member_ref(name):
    raw = archive.extractfile(name).read()
    return {'archive': BASE + 'execution.tar.gz', 'member': name,
            'bytes': len(raw), 'sha256': sha(raw)}


stems = ['word-tests', 'incoming-tests', 'publication-integration/01-publication-odt',
         'publication-integration/02-publication-editor', 'follow-up/01-format-followup']
maps = {name: {phase: member(name + '/source-' + phase + '.json')
               for phase in ('before', 'after')} for name in stems}
maps['portable'] = {phase: member('portable/sources-' + phase + '.json')
                    for phase in ('before', 'after')}
converter_source = json.loads((OUT / 'converter/source-before.json').read_text())
paths = set(converter_source['files'])
for snapshots in maps.values():
    paths.update(snapshots['before'])
    paths.update(snapshots['after'])
engine_paths = set(git('ls-tree', '-r', '--name-only', TARGET, '--',
                       'packages/quds_office_engine/lib').decode().splitlines())
paths.update(engine_paths)
paths = sorted(paths)
stream = io.BytesIO(git('cat-file', '--batch',
                      data=''.join(TARGET + ':' + p + '\n' for p in paths).encode()))
target_hashes = {}
for path in paths:
    header = stream.readline().decode().strip()
    if header.endswith(' missing'):
        target_hashes[path] = None
        continue
    _, _, size = header.split()
    raw = stream.read(int(size))
    assert stream.read(1) == b'\n'
    target_hashes[path] = sha(raw)


def compare(snapshot):
    untracked = [p for p in snapshot if target_hashes[p] is None]
    differences = [
        {'path': p, 'captured_sha256': digest, 'accepted_main_sha256': target_hashes[p]}
        for p, digest in snapshot.items()
        if target_hashes[p] is not None and target_hashes[p] != digest
    ]
    return {
        'captured_paths': len(snapshot),
        'tracked_matches': len(snapshot) - len(untracked) - len(differences),
        'untracked_runtime_paths': untracked,
        'tracked_differences': differences,
        'current_engine_library_file_count': len(engine_paths),
        'uncaptured_engine_library_paths': sorted(engine_paths - set(snapshot)),
        'changed_engine_library_paths': [d['path'] for d in differences if d['path'] in engine_paths],
    }


gates = {}
for name, snapshots in maps.items():
    prefix = name + ('/sources-' if name == 'portable' else '/source-')
    gates[name] = {
        'before': member_ref(prefix + 'before.json'),
        'after': member_ref(prefix + 'after.json'),
        'before_after_identical': snapshots['before'] == snapshots['after'],
        'before_comparison': compare(snapshots['before']),
        'after_comparison': compare(snapshots['after']),
    }
    if name in ('word-tests', 'incoming-tests', 'publication-integration/01-publication-odt'):
        summary = member(name + '/summary.json')
        gates[name]['summary'] = member_ref(name + '/summary.json')
        gates[name]['recorded_result'] = {
            key: summary[key] for key in ('exit_code', 'passing', 'failures', 'skipped', 'done')
        }
        gates[name]['requested_test_files'] = member(name + '/command.json')['test_files']
    elif name == 'follow-up/01-format-followup':
        summary = member(name + '/summary.json')
        gates[name]['summary'] = member_ref(name + '/summary.json')
        gates[name]['recorded_result'] = {
            key: summary[key] for key in ('passing', 'failures', 'skipped', 'passed',
                'formatting_only', 'production_sources_byte_identical', 'source_changed')
        }
        gates[name]['command_exit_codes'] = [c['exit_code'] for c in summary['commands']]
    elif name == 'publication-integration/02-publication-editor':
        gates[name]['recorded_result'] = validation['checks']['final_editor']
        gates[name]['receipt'] = member_ref(name + '/receipt.json')
    elif name == 'portable':
        gates[name]['recorded_result'] = validation['checks']['portable']
        gates[name]['commands'] = member_ref(name + '/commands.json')

production_diff = git('diff', '--name-only', '0705336aa52b299e06cf7efabc61228e8e22d662',
                      TARGET, '--', 'packages', 'pubspec.yaml', 'pubspec.lock', '.fvmrc').decode().splitlines()
assert not production_diff
for name in ('word-tests', 'incoming-tests', 'publication-integration/01-publication-odt',
             'publication-integration/02-publication-editor', 'portable'):
    assert gates[name]['before_after_identical']
    assert not gates[name]['after_comparison']['uncaptured_engine_library_paths']
    assert not gates[name]['after_comparison']['changed_engine_library_paths']
assert not gates['publication-integration/01-publication-odt']['after_comparison']['tracked_differences']
assert not gates['publication-integration/02-publication-editor']['after_comparison']['tracked_differences']

source_binding_raw = show(BASE + 'source-binding.json')
publication_raw = show(BASE + 'publication-follow-up.json')
review = {
    'schema': 'quds-incoming-word-gate-source-review-v1',
    'method': 'SHA-256 of archived snapshot bytes compared independently with git cat-file bytes at the accepted main commit; no test execution.',
    'accepted_main': TARGET,
    'local_integrated_source': LOCAL,
    'remote_equivalent_source': REMOTE,
    'integrated_tree': TREE,
    'word_final_qualified_checkpoint': '0705336aa52b299e06cf7efabc61228e8e22d662',
    'packages_and_root_config_differences_since_word_qualification': production_diff,
    'archive': {'path': BASE + 'execution.tar.gz', 'sha256': sha(archive_raw),
        'bytes': len(archive_raw), 'members': len(archive.getnames()),
        'all_member_hashes_and_sizes_verified': True},
    'published_records': {
        'archive-manifest.json': sha(manifest_raw),
        'validation.json': sha(validation_raw),
        'source-binding.json': sha(source_binding_raw),
        'publication-follow-up.json': sha(publication_raw),
    },
    'gates': gates,
    'change_dispositions': json.loads(source_binding_raw)['change_dispositions'],
    'runtime_boundary': {
        'recorded_runtime': validation['runtime'],
        'package_config': 'The captured package configuration is an untracked runtime file; it is not equated to a Git blob.',
        'tracked_lockfile_matches_accepted_main': all(
            snapshots['after'].get('pubspec.lock') == target_hashes['pubspec.lock']
            for snapshots in maps.values() if 'pubspec.lock' in snapshots['after']),
    },
    'conclusion': 'Reuse the source-bound 998-case and 716-case engine gates with their 33-case formatter and 46-case ODT matcher follow-ups. No new broad engine execution is required for unchanged production bytes. The separate current-main converter replay exercises the native-file interaction after Position integration.',
    'test_counts_are_separate_gates_not_a_unique_total': True,
    'tests_executed_by_this_review': False,
    'github_actions_queried_or_awaited': False,
}
save(OUT / 'incoming-word-review.json', review)
converter_binding = compare(converter_source['files'])
assert not converter_binding['tracked_differences']
assert converter_binding['untracked_runtime_paths'] == ['.dart_tool/package_config.json']
save(OUT / 'converter/accepted-main-source-binding.json', {
    'schema': 1, 'accepted_main': TARGET, 'local_commit': LOCAL,
    'remote_equivalent_commit': REMOTE, 'source_tree': TREE,
    'source_manifest_sha256': sha((OUT / 'converter/source-before.json').read_bytes()),
    'comparison': converter_binding,
    'all_captured_tracked_source_inputs_match_accepted_main': True,
})
print(json.dumps({'review': str(OUT / 'incoming-word-review.json'),
    'review_sha256': sha((OUT / 'incoming-word-review.json').read_bytes()),
    'archive_members_verified': len(archive.getnames()),
    'converter_tracked_sources_match': converter_binding['tracked_matches'],
    'engine_libraries_match': len(engine_paths)}, indent=2))
