import collections
import hashlib
import json
from pathlib import Path
import subprocess
import time

repo = Path('/workspace/scratch/b47dba313a2c/quds_office_suite')
cwd = repo / 'packages/quds_office_editor'
out = Path('/workspace/scratch/b47dba313a2c/validation/latest-main/renderer')
out.mkdir(parents=True, exist_ok=False)
tests = sorted([
    'test/office_dark_document_test.dart',
    'test/word_page_text_picture_cache_test.dart',
    'test/word_proofing_capture_cache_test.dart',
    'test/word_proofing_geometry_test.dart',
    'test/word_selection_paint_test.dart',
    'test/word_selection_path_cache_test.dart',
    'test/word_body_text_cache_test.dart',
    'test/word_position_test.dart',
])

def write(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args]).decode().strip()

def manifest():
    paths = git('ls-files', '-z').split('\0')
    selected = [name for name in paths if name and (
        (name.startswith(('packages/', 'third_party/')) and name.endswith('.dart'))
        or name.endswith(('pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml')))]
    selected += ['.dart_tool/package_config.json',
                 'packages/quds_office_editor/test/word_page_text_picture_cache_test.dart']
    return {name: hashlib.sha256((repo / name).read_bytes()).hexdigest()
            for name in sorted(set(selected)) if (repo / name).is_file()}

before = manifest()
write('source-before.json', before)
for name in ['lib/src/editor_word/render_word_canvas.dart', *tests]:
    source = cwd / name
    target = out / 'source' / source.relative_to(repo)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
command = ['flutter', 'test', '--no-pub', '--reporter=json', '--concurrency=2', *tests]
receipt = dict(scope='renderer', phase='latest-main',
               environment_script='/workspace/scratch/b47dba313a2c/runtime/env.sh',
               cwd=str(cwd), command=command, tests=tests, expected_tests=51,
               source_commit=git('rev-parse', 'HEAD'), source_tree=git('rev-parse', 'HEAD^{tree}'),
               started=time.time(), source_files=len(before))
write('receipt.json', receipt)
with (out / 'events.jsonl').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
    result = subprocess.run(command, cwd=cwd, stdout=stdout, stderr=stderr)
after = manifest()
write('source-after.json', after)
events, other = [], []
for line in (out / 'events.jsonl').read_text().splitlines():
    try:
        event = json.loads(line)
    except json.JSONDecodeError:
        if line.strip():
            other.append(line)
        continue
    if isinstance(event, dict):
        events.append(event)
starts = {event['test']['id']: event['test'] for event in events if event.get('type') == 'testStart'}
suites = {event['suite']['id']: event['suite'] for event in events if event.get('type') == 'suite'}
cases = [{**starts.get(event['testID'], {}), 'result': event['result'],
          'skipped': event.get('skipped', False)} for event in events
         if event.get('type') == 'testDone' and not event.get('hidden', False)]
for case in cases:
    case['suite'] = suites.get(case.get('suiteID'), {}).get('path')
write('cases.json', cases)
errors = [event for event in events if event.get('type') == 'error']
raw = (out / 'events.jsonl').read_text() + (out / 'stderr.log').read_text()
background_errors = [marker for marker in ['Unhandled exception:', 'EXCEPTION CAUGHT BY'] if marker in raw]
receipt.update(finished=time.time(), exit_code=result.returncode,
               source_commit_after=git('rev-parse', 'HEAD'), source_tree_after=git('rev-parse', 'HEAD^{tree}'),
               passed=sum(case['result'] == 'success' and not case['skipped'] for case in cases),
               failed=sum(case['result'] != 'success' for case in cases),
               skipped=sum(case['skipped'] for case in cases), errors=errors,
               raw_background_error_markers=background_errors,
               source_changes=[name for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)],
               runner_done=[event for event in events if event.get('type') == 'done'],
               non_json_output=other, stderr_bytes=(out / 'stderr.log').stat().st_size)
receipt['accepted'] = bool(result.returncode == 0 and receipt['passed'] == receipt['expected_tests']
                           and not receipt['failed'] and not receipt['skipped'] and not errors
                           and not background_errors and not receipt['source_changes']
                           and receipt['source_commit_after'] == receipt['source_commit']
                           and receipt['source_tree_after'] == receipt['source_tree']
                           and receipt['runner_done'] and receipt['runner_done'][-1].get('success'))
write('receipt.json', receipt)
write('suite-counts.json', dict(sorted(collections.Counter(case['suite'] for case in cases
                                                         if case['result'] == 'success' and not case['skipped']).items())))
print(json.dumps({key: receipt[key] for key in ['scope', 'source_commit', 'passed', 'failed',
                                              'skipped', 'exit_code', 'accepted', 'source_changes', 'stderr_bytes']}))
raise SystemExit(0 if receipt['accepted'] else 1)
