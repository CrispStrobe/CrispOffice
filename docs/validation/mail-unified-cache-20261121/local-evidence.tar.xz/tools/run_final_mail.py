#!/usr/bin/env python3
"""Capture final, source-bound local Mail validation without touching the index.

Usage (run only after source is frozen):
    python3 validation/run_final_mail.py studio mail-core
    python3 validation/run_final_mail.py studio

Each invocation creates a new validation/final-integrated/<UTC timestamp>/.
No prior log is overwritten. Tests run sequentially; neither GitHub Actions nor
dependency installation is invoked. The native Dart test runner can perform its
normal startup work, which is preserved in stdout/stderr and dependency hashes.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from typing import Any


WORKSPACE = Path(__file__).resolve().parent.parent
REPO = WORKSPACE / "quds_office_suite"
ENV_FILE = WORKSPACE / "toolchains/env.sh"
SDK = WORKSPACE / "toolchains/flutter"
OUTPUT_ROOT = WORKSPACE / "validation/final-integrated"
STUDIO_DIR = "packages/quds_office_editor/example"
STUDIO_TESTS = [
    "test/studio_mail_cached_search_test.dart",
    "test/studio_mail_cached_search_dialog_test.dart",
    "test/studio_mail_mailbox_store_test.dart",
    "test/studio_mail_local_accounts_test.dart",
    "test/studio_mail_local_accounts_dialog_test.dart",
    "test/studio_credential_biometric_recovery_test.dart",
    "test/studio_credential_biometric_unlock_test.dart",
    "test/studio_credential_selection_test.dart",
    "test/studio_credential_selection_race_test.dart",
    "test/studio_mail_credentials_test.dart",
    "test/studio_mail_credential_backend_switch_test.dart",
]
CONFIG_NAMES = {
    "pubspec.yaml",
    "pubspec.lock",
    "pubspec_overrides.yaml",
    "analysis_options.yaml",
    "dart_test.yaml",
    "melos.yaml",
    ".fvmrc",
}
RECORDED_ENV_KEYS = (
    "PATH",
    "PUB_CACHE",
    "TMPDIR",
    "XDG_CONFIG_HOME",
    "XDG_CACHE_HOME",
    "XDG_DATA_HOME",
    "CI",
    "FLUTTER_SUPPRESS_ANALYTICS",
    "DART_SUPPRESS_ANALYTICS",
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def git(*args: str) -> bytes:
    # Read-only Git commands must not opportunistically refresh the index.
    env = os.environ.copy()
    env["GIT_OPTIONAL_LOCKS"] = "0"
    result = subprocess.run(
        ["git", *args], cwd=REPO, env=env, capture_output=True, check=True
    )
    return result.stdout


def git_snapshot(output: Path, phase: str) -> dict[str, Any]:
    status = git("status", "--porcelain=v2", "--untracked-files=all", "-z")
    status_path = output / f"git-status-{phase}.nul"
    status_path.write_bytes(status)
    # ls-files observes the index without writing a tree object or changing it.
    index = git("ls-files", "--stage", "-z")
    return {
        "captured_utc": utc_now(),
        "head": git("rev-parse", "HEAD").decode().strip(),
        "head_tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
        "branch": git("rev-parse", "--abbrev-ref", "HEAD").decode().strip(),
        "status_path": str(status_path),
        "status_sha256": hashlib.sha256(status).hexdigest(),
        "index_listing_sha256": hashlib.sha256(index).hexdigest(),
        "worktree_clean": not status,
    }


def load_environment() -> dict[str, str]:
    # Source the verified pinned-runtime helper. Never write the complete
    # inherited environment: only the non-secret allowlisted keys are recorded.
    result = subprocess.run(
        [
            "bash", "--noprofile", "--norc", "-c",
            'set -e\nsource "$1"\nexec env -0',
            "bash", str(ENV_FILE),
        ],
        cwd=WORKSPACE,
        capture_output=True,
        check=True,
    )
    values = {}
    for field in result.stdout.split(b"\0"):
        if field:
            key, value = field.split(b"=", 1)
            values[os.fsdecode(key)] = os.fsdecode(value)
    return values


def source_roots(cohort: str) -> list[str]:
    if cohort == "mail-core":
        return ["packages/quds_mail_core/lib", "packages/quds_mail_core/test"]
    # Bind all local package libraries imported by host/editor/engine code, not
    # just the Mail entry points. Only STUDIO_TESTS are executed by this cohort;
    # all host tests are fingerprinted to cover shared helper/fixture changes.
    return sorted({
        *(str(path.relative_to(REPO))
          for path in (REPO / "packages").glob("*/lib")),
        "packages/quds_office_editor/lib",
        f"{STUDIO_DIR}/lib",
        f"{STUDIO_DIR}/test",
        "packages/quds_office_engine/lib",
        "third_party/enough_mail/lib",
    })


def source_snapshot(cohort: str) -> dict[str, Any]:
    paths = {REPO / "pubspec.yaml", REPO / "pubspec.lock", REPO / ".fvmrc"}
    # Bind all repository manifests/locks/configuration, including untracked
    # overrides, so automatic resolution changes cannot pass unnoticed.
    inventory = git("ls-files", "--cached", "--others", "--exclude-standard", "-z")
    for raw in inventory.split(b"\0"):
        if raw:
            path = REPO / os.fsdecode(raw)
            if path.name in CONFIG_NAMES and path.is_file():
                paths.add(path)
    # Overrides and package-local locks can be gitignored but still affect the
    # dependency graph. Observe them beside every discovered pubspec as well.
    for manifest in list(paths):
        if manifest.name == "pubspec.yaml":
            for name in CONFIG_NAMES:
                path = manifest.parent / name
                if path.is_file():
                    paths.add(path)
    # These generated resolution files bind the actual installed graph as well
    # as the checked-in manifests; they are read only.
    for name in ("package_config.json", "package_graph.json"):
        path = REPO / ".dart_tool" / name
        if path.is_file():
            paths.add(path)
    roots = source_roots(cohort)
    for relative in roots:
        path = REPO / relative
        if not path.is_dir():
            raise FileNotFoundError(f"Required source root missing: {relative}")
        paths.update(item for item in path.rglob("*") if item.is_file())
    hashes = {
        str(path.relative_to(REPO)): sha256(path)
        for path in sorted(paths)
    }
    canonical = json.dumps(hashes, sort_keys=True, separators=(",", ":")).encode()
    return {
        "captured_utc": utc_now(),
        "source_roots": roots,
        "configuration_file_names": sorted(CONFIG_NAMES),
        "file_count": len(hashes),
        "aggregate_sha256": hashlib.sha256(canonical).hexdigest(),
        "sha256": hashes,
    }


def event_summary(path: Path) -> dict[str, Any]:
    """Count typed protocol events, not keywords embedded in printed messages."""
    counts: Counter[str] = Counter()
    prints: Counter[str] = Counter()
    starts: dict[int, dict[str, Any]] = {}
    completions: dict[int, dict[str, Any]] = {}
    suites: dict[int, dict[str, Any]] = {}
    done_events = []
    errors = []
    non_event_lines = 0
    non_event_examples = []
    duplicate_completions = []
    warnings = 0
    lines = 0
    with path.open(encoding="utf-8", errors="replace") as stream:
        for line_number, line in enumerate(stream, 1):
            lines += 1
            try:
                event = json.loads(line)
            except (ValueError, TypeError):
                event = None
            if not isinstance(event, dict) or not isinstance(event.get("type"), str):
                if line.strip():
                    non_event_lines += 1
                    if len(non_event_examples) < 10:
                        non_event_examples.append({"line": line_number, "text": line.rstrip()[:500]})
                continue
            kind = event["type"]
            counts[kind] += 1
            if kind == "testStart":
                starts[event["test"]["id"]] = event["test"]
            elif kind == "testDone":
                test_id = event["testID"]
                if test_id in completions:
                    duplicate_completions.append(test_id)
                completions[test_id] = event
            elif kind == "suite":
                suites[event["suite"]["id"]] = event["suite"]
            elif kind == "done":
                done_events.append(event)
            elif kind == "error":
                errors.append({"line": line_number, **event})
            elif kind == "print":
                prints[str(event.get("messageType", "unknown"))] += 1
                if str(event.get("message", "")).lstrip().upper().startswith("WARNING"):
                    warnings += 1
    hidden_ids = {key for key, value in completions.items() if value.get("hidden") is True}
    visible = []
    results: Counter[str] = Counter()
    for test_id, event in completions.items():
        if test_id in hidden_ids:
            continue
        result = "skipped" if event.get("skipped") is True else event.get("result", "unknown")
        results[result] += 1
        started = starts.get(test_id, {})
        visible.append({
            "id": test_id,
            "name": started.get("name"),
            "suite_id": started.get("suiteID"),
            "result": result,
        })
    unfinished = [
        {"id": key, "name": value.get("name"), "suite_id": value.get("suiteID")}
        for key, value in starts.items() if key not in completions
    ]
    protocol_success = (
        len(done_events) == 1
        and done_events[0].get("success") is True
        and results["success"] > 0
        and results["failure"] == 0
        and results["error"] == 0
        and not any(count for key, count in results.items()
                    if key not in {"success", "failure", "error", "skipped"})
        and not errors
        and not unfinished
        and not duplicate_completions
    )
    per_suite = []
    for suite_id, suite in suites.items():
        suite_results = Counter(test["result"] for test in visible
                                if test["suite_id"] == suite_id)
        per_suite.append({**suite, "visible_test_results": dict(sorted(suite_results.items()))})
    return {
        "stdout_lines": lines,
        "typed_event_counts": dict(sorted(counts.items())),
        "print_message_type_counts": dict(sorted(prints.items())),
        "warning_print_events": warnings,
        "non_event_line_count": non_event_lines,
        "non_event_examples": non_event_examples,
        "suites": per_suite,
        "real_tests": {
            "completed": len(visible),
            "passed": results["success"],
            "failed": results["failure"],
            "errors": results["error"],
            "skipped": results["skipped"],
            "other_results": {key: count for key, count in results.items()
                              if key not in {"success", "failure", "error", "skipped"} and count},
            "unfinished": unfinished,
        },
        "hidden_completions_excluded": len(hidden_ids),
        "duplicate_completion_ids": duplicate_completions,
        "done_events": done_events,
        "error_events": errors,
        "tests": visible,
        "protocol_success": protocol_success,
    }


def runtime_record(env: dict[str, str]) -> dict[str, Any]:
    commands = [
        [str(SDK / "bin/dart"), "--version"],
        [str(SDK / "bin/flutter"), "--no-version-check", "--version", "--machine"],
    ]
    versions = []
    for command in commands:
        start = utc_now()
        result = subprocess.run(command, cwd=REPO, env=env, capture_output=True, timeout=60)
        versions.append({
            "argv": command,
            "cwd": str(REPO),
            "start_utc": start,
            "end_utc": utc_now(),
            "exit_code": result.returncode,
            "stdout": result.stdout.decode(errors="replace"),
            "stderr": result.stderr.decode(errors="replace"),
        })
        if result.returncode != 0:
            raise RuntimeError(f"Pinned runtime version command failed: {command[0]}")
    return {
        "environment_helper": str(ENV_FILE),
        "environment_helper_sha256": sha256(ENV_FILE),
        "recorded_environment": {key: env.get(key) for key in RECORDED_ENV_KEYS},
        "version_commands": versions,
    }


def run_cohort(cohort: str, output: Path, env: dict[str, str]) -> dict[str, Any]:
    output.mkdir()
    if cohort == "studio":
        cwd = REPO / STUDIO_DIR
        for test in STUDIO_TESTS:
            if not (cwd / test).is_file():
                raise FileNotFoundError(f"Required Studio test missing: {test}")
        command = [str(SDK / "bin/flutter"), "--no-version-check", "test",
                   "--no-pub", "--reporter", "json", *STUDIO_TESTS]
    else:
        cwd = REPO / "packages/quds_mail_core"
        command = [str(SDK / "bin/dart"), "test", "--reporter", "json"]
    before_git = git_snapshot(output, "before")
    before = source_snapshot(cohort)
    write_json(output / "sources-before.json", before)
    stdout_path = output / "stdout.jsonl"
    stderr_path = output / "stderr.log"
    receipt = {
        "schema_version": 1,
        "cohort": cohort,
        "state": "prepared",
        "argv": command,
        "cwd": str(cwd),
        "git_before": before_git,
        "sources_before": str(output / "sources-before.json"),
        "stdout": str(stdout_path),
        "stderr": str(stderr_path),
        "runner_sha256_before": sha256(Path(__file__).resolve()),
        "environment_helper_sha256_before": sha256(ENV_FILE),
    }
    write_json(output / "receipt.json", receipt)
    print(json.dumps({"cohort": cohort, "state": "starting", "output": str(output)}), flush=True)
    started = time.monotonic()
    receipt["start_utc"] = utc_now()
    exit_code = None
    interrupted = False
    launch_error = None
    with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        try:
            process = subprocess.Popen(
                command, cwd=cwd, env=env, stdout=stdout, stderr=stderr,
                start_new_session=True,
            )
            receipt.update({"state": "running", "pid": process.pid})
            write_json(output / "receipt.json", receipt)
            try:
                exit_code = process.wait()
            except KeyboardInterrupt:
                interrupted = True
                for sig, timeout in ((signal.SIGINT, 10), (signal.SIGTERM, 5), (signal.SIGKILL, 5)):
                    if process.poll() is not None:
                        break
                    os.killpg(process.pid, sig)
                    try:
                        process.wait(timeout=timeout)
                    except subprocess.TimeoutExpired:
                        continue
                exit_code = process.wait()
        except OSError as error:
            launch_error = f"{type(error).__name__}: {error}"
    receipt.update({
        "end_utc": utc_now(),
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "exit_code": exit_code,
        "interrupted": interrupted,
        "launch_error": launch_error,
    })
    after = source_snapshot(cohort)
    after_git = git_snapshot(output, "after")
    write_json(output / "sources-after.json", after)
    changed = sorted(path for path in before["sha256"].keys() | after["sha256"].keys()
                     if before["sha256"].get(path) != after["sha256"].get(path))
    events = event_summary(stdout_path)
    write_json(output / "events.json", events)
    runner_after = sha256(Path(__file__).resolve())
    env_after = sha256(ENV_FILE)
    binding_stable = (
        not changed
        and before_git["head"] == after_git["head"]
        and before_git["head_tree"] == after_git["head_tree"]
        and receipt["runner_sha256_before"] == runner_after
        and receipt["environment_helper_sha256_before"] == env_after
    )
    accepted = exit_code == 0 and not interrupted and events["protocol_success"] and binding_stable
    receipt.update({
        "state": "completed",
        "git_after": after_git,
        "sources_after": str(output / "sources-after.json"),
        "source_files_before": before["file_count"],
        "source_files_after": after["file_count"],
        "source_aggregate_sha256_before": before["aggregate_sha256"],
        "source_aggregate_sha256_after": after["aggregate_sha256"],
        "changed_source_or_dependency_files": changed,
        "runner_sha256_after": runner_after,
        "environment_helper_sha256_after": env_after,
        "source_binding_stable": binding_stable,
        "events": str(output / "events.json"),
        "typed_event_counts": events["typed_event_counts"],
        "real_tests": events["real_tests"],
        "hidden_completions_excluded": events["hidden_completions_excluded"],
        "warning_print_events": events["warning_print_events"],
        "stdout_bytes": stdout_path.stat().st_size,
        "stderr_bytes": stderr_path.stat().st_size,
        "stdout_sha256": sha256(stdout_path),
        "stderr_sha256": sha256(stderr_path),
        "accepted": accepted,
    })
    write_json(output / "receipt.json", receipt)
    print(json.dumps({
        "cohort": cohort,
        "exit_code": exit_code,
        "tests": events["real_tests"],
        "source_binding_stable": binding_stable,
        "accepted": accepted,
        "receipt": str(output / "receipt.json"),
    }), flush=True)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("cohorts", nargs="*", metavar="{studio,mail-core}")
    args = parser.parse_args()
    cohorts = args.cohorts or ["studio", "mail-core"]
    if any(cohort not in {"studio", "mail-core"} for cohort in cohorts):
        parser.error("Cohorts must be studio or mail-core.")
    if len(set(cohorts)) != len(cohorts):
        parser.error("Specify each cohort at most once.")
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    output = OUTPUT_ROOT / run_id
    output.mkdir(parents=True, exist_ok=False)
    run = {
        "schema_version": 1,
        "state": "prepared",
        "start_utc": utc_now(),
        "runner_argv": sys.argv,
        "invocation_cwd": str(Path.cwd()),
        "python_version": sys.version,
        "runner": str(Path(__file__).resolve()),
        "runner_sha256": sha256(Path(__file__).resolve()),
        "cohorts": cohorts,
        "output": str(output),
    }
    write_json(output / "run.json", run)
    receipts = []
    try:
        env = load_environment()
        write_json(output / "runtime.json", runtime_record(env))
        for cohort in cohorts:
            receipt = run_cohort(cohort, output / cohort, env)
            receipts.append(receipt)
            if receipt["interrupted"]:
                break
    except (Exception, KeyboardInterrupt) as error:
        run["runner_error"] = f"{type(error).__name__}: {error}"
    accepted = (
        "runner_error" not in run
        and len(receipts) == len(cohorts)
        and all(receipt["accepted"] for receipt in receipts)
    )
    run.update({
        "state": "completed",
        "end_utc": utc_now(),
        "accepted": accepted,
        "receipts": [str(output / receipt["cohort"] / "receipt.json") for receipt in receipts],
    })
    write_json(output / "run.json", run)
    print(json.dumps({"accepted": accepted, "run": str(output / "run.json"),
                      "runner_error": run.get("runner_error")}), flush=True)
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
