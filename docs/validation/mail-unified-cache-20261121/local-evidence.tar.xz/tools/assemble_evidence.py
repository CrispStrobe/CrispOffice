#!/usr/bin/env python3
"""Package this task's preserved receipts; no test results are invented here."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile

workspace = Path(__file__).resolve().parent.parent
validation = workspace / 'validation'
destination = workspace / 'quds_office_suite/docs/validation/mail-unified-cache-20261121'
destination.mkdir(parents=True, exist_ok=True)
entries = {}

def add(path, archive_name):
    if path.is_file():
        entries[archive_name] = path

for pattern in ('cached-*.jsonl', 'cached-*.stderr', 'cached-*.json',
                'cached-*.log', 'studio-*.jsonl', 'studio-*.stderr'):
    for path in validation.glob(pattern):
        add(path, 'mail/' + path.name)
for name in ('run_final_mail.py', 'assemble_evidence.py', 'intake-refresh-20261121.json'):
    add(validation / name, 'tools/' + name)
for directory in ('runtime-baselines-20261121', 'zotero-incoming-20261121',
                  'word-final-integrated-20261121', 'touchid-incoming-20261121',
                  'perf-incoming-20261121', 'final-intake-20261121', 'final-integrated'):
    root = validation / directory
    if root.exists():
        for path in root.rglob('*'):
            if path.is_file() and path.suffix not in ('.js', '.map', '.deps', '.pyc', '.dill'):
                add(path, directory + '/' + path.relative_to(root).as_posix())
logs = workspace / 'toolchains/logs'
for root in logs.iterdir():
    if root.is_dir() and (root.name.startswith('mail-cached-search-widget') or
                         root.name in ('mail-cached-search-local-account-isolated',
                                       'mail-local-accounts-intake-baseline')):
        # Baseline snapshots are an unsuccessful setup experiment, not a
        # second source distribution. Its receipts and logs are retained.
        for path in root.iterdir():
            add(path, 'widgets/' + root.name + '/' + path.name)
for name in ('workspace-pub-get.log', 'sqlite-native-probe.log'):
    add(logs / name, 'runtime/' + name)
add(workspace / 'toolchains/env.sh', 'runtime/env.sh')

manifest = [
    {'path': name, 'bytes': path.stat().st_size,
     'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    for name, path in sorted(entries.items())
]
(destination / 'evidence-files.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = destination / 'local-evidence.tar.xz'
with tarfile.open(archive, mode='w:xz', format=tarfile.PAX_FORMAT, preset=6) as tar:
    for name, path in sorted(entries.items()):
        info = tar.gettarinfo(str(path), arcname=name)
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        info.mtime = 0
        info.mode = 0o644
        with path.open('rb') as stream:
            tar.addfile(info, stream)

captures = destination / 'captures'
captures.mkdir(exist_ok=True)
visuals = []
for source in sorted((logs / 'mail-cached-search-ui-captures-r2').glob('*.png')):
    target = captures / source.name
    shutil.copyfile(source, target)
    visuals.append({'path': target.relative_to(destination).as_posix(),
                    'bytes': target.stat().st_size,
                    'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
(destination / 'visual-files.json').write_text(json.dumps(visuals, indent=2) + '\n')
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
                  'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                  'files': len(manifest), 'captures': len(visuals)}))
