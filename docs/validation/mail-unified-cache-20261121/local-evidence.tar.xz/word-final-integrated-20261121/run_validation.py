import base64
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from urllib.parse import unquote,urlparse
import yaml

root=Path('/workspace/scratch/56d5733a0888')
repo=root/'quds_office_suite'
engine=repo/'packages/quds_office_engine'
out=root/'validation/word-final-integrated-20261121'
dart=str(root/'toolchains/flutter/bin/dart')
packages=repo/'.dart_tool/package_config.json'
config=json.loads(packages.read_text())
package_roots={p['name']:Path(unquote(urlparse(p['rootUri']).path)) if p['rootUri'].startswith('file:') else (packages.parent/p['rootUri']).resolve() for p in config['packages']}
source_paths={}
def add(path,label=None):
 if path.is_file():source_paths[label or 'repo:'+str(path.relative_to(repo))]=path
for p in (engine/'lib').rglob('*'):
 if p.is_file():add(p)
for folder in ['test/support','tool/macros','bin']:
 for p in (engine/folder).rglob('*.dart'):add(p)
for rel in ['test/office_vba_text_conformance_test.dart','test/office_vba_text_intrinsics_test.dart','test/office_vba_word_text_integration_test.dart','test/fixtures/vba_conformance/text_intrinsics_v1.json','example/macros/word_text_report.bas']:
 add(engine/rel)
for p in ['pubspec.lock','pubspec.yaml','.fvmrc','.dart_tool/package_config.json']:add(repo/p)
manifest_paths=subprocess.check_output(['git','ls-files','*pubspec.yaml'],cwd=repo,text=True).splitlines()
for p in manifest_paths:
 if Path(p).name=='pubspec.yaml':add(repo/p)
lock=yaml.safe_load((repo/'pubspec.lock').read_text())['packages']
visited=set();dependency_records=[]
queue=['quds_office_engine']
while queue:
 name=queue.pop()
 if name in visited:continue
 visited.add(name)
 location=package_roots[name]
 spec_path=location/'pubspec.yaml'
 spec=yaml.safe_load(spec_path.read_text())
 is_repo=location.is_relative_to(repo)
 prefix='repo:'+str(location.relative_to(repo)) if is_repo else 'dependency:'+name+'@'+str(spec.get('version','sdk'))
 add(spec_path,prefix+'/pubspec.yaml')
 for p in (location/'lib').rglob('*'):
  if p.is_file():add(p,prefix+'/'+str(p.relative_to(location)))
 deps=spec.get('dependencies',{}) or {}
 if name=='quds_office_engine':deps={**deps,**(spec.get('dev_dependencies',{}) or {})}
 queue.extend(deps)
 dependency_records.append({'name':name,'version':str(spec.get('version','sdk')),'root':str(location),'manifest_sha256':hashlib.sha256(spec_path.read_bytes()).hexdigest(),'lock_entry':lock.get(name)})
def hashes():return {name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in sorted(source_paths.items())}
def digest(data):return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':')).encode()).hexdigest()
before=hashes()
manifest_digest=digest(before)
start_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
(out/'source-sha256-before.json').write_text(json.dumps(before,indent=2)+'\n')
(out/'dependencies.json').write_text(json.dumps({'runtime':json.loads((root/'toolchains/flutter-version.json').read_text()),'packages':sorted(dependency_records,key=lambda d:d['name'])},indent=2)+'\n')
env=os.environ.copy()
env.update({'PATH':str(root/'toolchains/flutter/bin')+':'+env['PATH'],'PUB_CACHE':str(root/'toolchains/pub-cache'),'TMPDIR':str(root/'toolchains/tmp'),'XDG_CONFIG_HOME':str(root/'toolchains/config'),'XDG_CACHE_HOME':str(root/'toolchains/cache'),'XDG_DATA_HOME':str(root/'toolchains/data'),'CI':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','DART_SUPPRESS_ANALYTICS':'true'})
print(json.dumps({'start_head':start_head,'source_files':len(before),'dependency_packages':len(dependency_records),'source_manifest_sha256':manifest_digest}),flush=True)

def finish(name,started,stages,summary,ok):
 after=hashes()
 changed=[p for p in before if before[p]!=after[p]]
 receipt={'cohort':name,'start_head':start_head,'end_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'start_utc':started,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(engine),'stages':stages,'summary':summary,'source_files':len(before),'source_manifest_before_sha256':manifest_digest,'source_manifest_after_sha256':digest(after),'source_manifest_path':str(out/'source-sha256-before.json'),'dependency_receipt_path':str(out/'dependencies.json'),'sources_changed_during_run':changed,'passed':ok and not changed}
 (out/f'{name}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'cohort':name,'passed':receipt['passed'],'summary':summary,'stage_exit_codes':[s['exit_code'] for s in stages],'sources_changed':changed}),flush=True)
 return receipt

def execute(name,stage,command):
 stdout=out/f'{name}-{stage}.stdout'
 stderr=out/f'{name}-{stage}.stderr'
 with stdout.open('wb') as o,stderr.open('wb') as e:
  result=subprocess.run(command,cwd=engine,env=env,stdout=o,stderr=e)
 return {'stage':stage,'argv':command,'exit_code':result.returncode,'stdout':str(stdout),'stderr':str(stderr)}

def native():
 name='word-native';started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 command=[dart,'test','--reporter','expanded','test/office_vba_text_conformance_test.dart','test/office_vba_text_intrinsics_test.dart','test/office_vba_word_text_integration_test.dart']
 stage=execute(name,'test',command)
 log=(out/f'{name}-test.stdout').read_text(errors='replace')+(out/f'{name}-test.stderr').read_text(errors='replace')
 match=re.search(r'\+(\d+): All tests passed!',log)
 count=int(match.group(1)) if match else None
 return finish(name,started,[stage],{'native_tests_passed':count,'scope':'three focused Word text suites'},stage['exit_code']==0 and count==263)

def portable(config):
 name,script,fixture,key=config
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 encoded=base64.b64encode((engine/fixture).read_bytes()).decode()
 define=f'-D{key}={encoded}'
 package_flag='--packages='+str(packages)
 js=out/f'{name}.js'
 commands=[('vm',[dart,package_flag,define,script]),('compile',[dart,'compile','js','-O1',package_flag,define,script,'-o',str(js)]),('node',[shutil.which('node'),'-e','globalThis.self = globalThis; require(process.argv[1])',str(js)])]
 stages=[]
 for label,command in commands:
  stage=execute(name,label,command);stages.append(stage)
  if stage['exit_code']:break
 summary={};ok=False
 if len(stages)==3 and all(s['exit_code']==0 for s in stages):
  vm=(out/f'{name}-vm.stdout').read_bytes();node=(out/f'{name}-node.stdout').read_bytes()
  a=json.loads(vm);b=json.loads(node)
  equal=vm==node
  if name=='text-conformance':summary={'canonical_cases':b['caseCount'],'suite':b['suite'],'vm_node_json_equal':a==b,'vm_node_byte_equal':equal};ok=equal and b['caseCount']==95
  else:summary={**b,'vm_node_json_equal':a==b,'vm_node_byte_equal':equal};ok=equal and b['operations']==6 and b['recordedSteps']==6 and b['opaqueVbaPreserved'] and b['richFormattingPreserved']
 return finish(name,started,stages,summary,ok)
configs=[('text-conformance','tool/macros/web_vba_text_conformance.dart','test/fixtures/vba_conformance/text_intrinsics_v1.json','VBA_CONFORMANCE_BASE64'),('word-report','tool/macros/web_vba_word_text_smoke.dart','example/macros/word_text_report.bas','WORD_TEXT_BAS_BASE64')]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 futures=[pool.submit(native),*[pool.submit(portable,c) for c in configs]]
 results=[future.result() for future in futures]
after=hashes()
(out/'source-sha256-after.json').write_text(json.dumps(after,indent=2)+'\n')
summary={'start_head':start_head,'end_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'native_tests':263 if results[0]['passed'] else None,'portable_runs_overlap_native_cases':True,'cohorts':[{'cohort':r['cohort'],'passed':r['passed'],'summary':r['summary']} for r in results],'source_files':len(before),'dependency_packages':len(dependency_records),'source_manifest_before_sha256':manifest_digest,'source_manifest_after_sha256':digest(after),'source_changes':[p for p in before if before[p]!=after[p]],'runtime':'Flutter3.47.8/Dart3.13.7'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
raise SystemExit(0 if all(r['passed'] for r in results) and before==after else 1)
