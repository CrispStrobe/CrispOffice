import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root=Path('/workspace/scratch/56d5733a0888')
repo=root/'quds_office_suite'
out=root/'validation/runtime-baselines-20261121'
cohort=sys.argv[1]
dart=str(root/'toolchains/flutter/bin/dart')
flutter=str(root/'toolchains/flutter/bin/flutter')
configs={
 'mail-core':('packages/quds_mail_core',[dart,'test','--reporter','expanded'],['packages/quds_mail_core/lib','packages/quds_mail_core/test']),
 'mail-ui':('packages/quds_mail_ui',[flutter,'--no-version-check','test','--no-pub','--reporter','expanded'],['packages/quds_mail_ui/lib','packages/quds_mail_ui/test','packages/quds_mail_ui/example/lib','packages/quds_mail_core/lib','packages/quds_mail_mime/lib','third_party/enough_mail/lib']),
 'word-text':('packages/quds_office_engine',[dart,'test','--reporter','expanded','test/office_vba_text_conformance_test.dart','test/office_vba_text_intrinsics_test.dart','test/office_vba_word_text_integration_test.dart'],['packages/quds_office_engine/lib','packages/quds_office_engine/test/office_vba_text_conformance_test.dart','packages/quds_office_engine/test/office_vba_text_intrinsics_test.dart','packages/quds_office_engine/test/office_vba_word_text_integration_test.dart']),
}
workdir,command,source_roots=configs[cohort]
def hash_sources():
 files={repo/'pubspec.lock',repo/'.fvmrc',repo/'pubspec.yaml',repo/workdir/'pubspec.yaml'}
 for part in source_roots:
  path=repo/part
  if path.is_file():files.add(path)
  else:files.update(path.rglob('*.dart'))
 return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
before=hash_sources()
env=os.environ.copy()
env.update({'PATH':str(root/'toolchains/flutter/bin')+':'+env['PATH'],'PUB_CACHE':str(root/'toolchains/pub-cache'),'TMPDIR':str(root/'toolchains/tmp'),'XDG_CONFIG_HOME':str(root/'toolchains/config'),'XDG_CACHE_HOME':str(root/'toolchains/cache'),'XDG_DATA_HOME':str(root/'toolchains/data'),'CI':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','DART_SUPPRESS_ANALYTICS':'true'})
with (out/f'{cohort}.log').open('wb') as log:
 result=subprocess.run(command,cwd=repo/workdir,env=env,stdout=log,stderr=subprocess.STDOUT)
after=hash_sources()
changed=[p for p in before.keys()|after.keys() if before.get(p)!=after.get(p)]
receipt={'cohort':cohort,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(repo/workdir),'argv':command,'exit_code':result.returncode,'source_sha256_before':before,'source_sha256_after':after,'sources_changed_during_run':changed,'log':str(out/f'{cohort}.log')}
(out/f'{cohort}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'cohort':cohort,'exit_code':result.returncode,'source_files':len(before),'sources_changed_during_run':changed,'log':str(out/f'{cohort}.log')}))
for line in (out/f'{cohort}.log').read_text(errors='replace').splitlines()[-12:]:print(line)
raise SystemExit(result.returncode)
