import base64
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root=Path('/workspace/scratch/56d5733a0888')
repo=root/'quds_office_suite'
engine=repo/'packages/quds_office_engine'
out=root/'validation/runtime-baselines-20261121'
dart=str(root/'toolchains/flutter/bin/dart')
node=shutil.which('node')
packages=str(repo/'.dart_tool/package_config.json')
env=os.environ.copy()
env.update({'PATH':str(root/'toolchains/flutter/bin')+':'+env['PATH'],'PUB_CACHE':str(root/'toolchains/pub-cache'),'TMPDIR':str(root/'toolchains/tmp'),'XDG_CONFIG_HOME':str(root/'toolchains/config'),'XDG_CACHE_HOME':str(root/'toolchains/cache'),'XDG_DATA_HOME':str(root/'toolchains/data'),'CI':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','DART_SUPPRESS_ANALYTICS':'true'})

def run(cohort,script,fixture,key):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 files=set((engine/'lib').rglob('*.dart'))|set((engine/'test/support').rglob('*.dart'))|{engine/script,engine/fixture,engine/'tool/macros/web_vba_conformance.dart',repo/'pubspec.lock',repo/'.fvmrc'}
 before={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
 encoded=base64.b64encode((engine/fixture).read_bytes()).decode()
 define=f'-D{key}={encoded}'
 output_js=out/f'{cohort}.js'
 commands=[
  ([dart,f'--packages={packages}',define,script],out/f'{cohort}-vm.json'),
  ([dart,'compile','js','-O1',f'--packages={packages}',define,script,'-o',str(output_js)],out/f'{cohort}-compile.log'),
  ([node,'-e','globalThis.self = globalThis; require(process.argv[1])',str(output_js)],out/f'{cohort}-node.json'),
 ]
 stages=[]
 for command,logfile in commands:
  with logfile.open('wb') as log:
   result=subprocess.run(command,cwd=engine,env=env,stdout=log,stderr=subprocess.STDOUT)
  stages.append({'argv':command,'exit_code':result.returncode,'log':str(logfile)})
  if result.returncode:break
 after={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
 changed=[p for p,h in before.items() if after.get(p)!=h]
 equal=None
 summary=None
 if len(stages)==3 and all(s['exit_code']==0 for s in stages):
  vm=json.loads((out/f'{cohort}-vm.json').read_text())
  js=json.loads((out/f'{cohort}-node.json').read_text())
  equal=vm==js
  if cohort=='word-text-conformance-web':summary={'suite':js.get('suite'),'cases':len(js.get('cases',[])),'keys':list(js.keys())}
  else:summary=js
 receipt={'cohort':cohort,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(engine),'stages':stages,'vm_node_equal':equal,'summary':summary,'source_sha256_before':before,'source_sha256_after':after,'sources_changed_during_run':changed}
 (out/f'{cohort}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'cohort':cohort,'stage_exit_codes':[s['exit_code'] for s in stages],'vm_node_equal':equal,'summary':summary,'sources_changed':changed}),flush=True)
 return len(stages)==3 and all(s['exit_code']==0 for s in stages) and equal and not changed

configs=[
 ('word-text-conformance-web','tool/macros/web_vba_text_conformance.dart','test/fixtures/vba_conformance/text_intrinsics_v1.json','VBA_CONFORMANCE_BASE64'),
 ('word-text-report-web','tool/macros/web_vba_word_text_smoke.dart','example/macros/word_text_report.bas','WORD_TEXT_BAS_BASE64'),
]
if len(sys.argv)>1:
 configs=[c for c in configs if c[0]==sys.argv[1]]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(lambda c:run(*c),configs))
raise SystemExit(0 if all(results) else 1)
