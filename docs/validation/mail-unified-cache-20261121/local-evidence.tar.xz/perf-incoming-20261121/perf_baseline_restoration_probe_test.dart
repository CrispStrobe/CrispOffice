import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_editor/quds_office_editor.dart';

import 'studio_typing_proofing_benchmark_test.dart' as benchmark;

// Qualification-only wrapper. It runs the unchanged real Studio benchmark,
// then checks that its teardown preserves an already-disabled configuration.
void main() {
  WordLayoutEngine.translateParagraphs = false;
  OfficeController.coalesceEditNotifications = false;
  benchmark.main();
  test('preserves benchmark switches after execution', () {
    expect(WordLayoutEngine.translateParagraphs, isFalse);
    expect(OfficeController.coalesceEditNotifications, isFalse);
  });
}
