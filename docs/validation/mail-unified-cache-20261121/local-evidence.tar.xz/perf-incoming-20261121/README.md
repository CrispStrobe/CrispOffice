# Late performance-branch intake and focused qualification

## Finding

Incoming `origin/perf/wrap-chrome-20261121` was captured at `d76c705ba9e7aefc2428e000d850ef0aba7c6b26`. Against integration HEAD `678e9c619b09153ba7d650c11939c3443c93e8e6`, the sole merge base is `64ebfc1bbc1daf9d3e9fc8a03ff8bf95f9973e04` and exactly one incoming commit remains. Its only changed path is `packages/quds_office_editor/example/test/studio_typing_proofing_benchmark_test.dart`: twelve inserted lines add the runtime `QUDS_TYPING_BENCHMARK_BASELINE=1` switch and report the translation flag. There is no incoming production-source or dependency change.

The much larger diff from historical perf head `8716057` contains history already integrated into current main. The apparent Mail deletions in a direct current-HEAD-to-perf tree comparison are current work-branch additions absent on the incoming branch, not incoming deletions to apply. `intake.json` and `incoming.patch` preserve this distinction.

## Review and minimal correction

The incoming first-test teardown assigned both global optimization flags to `true`, regardless of their values before the test. This overwrote prior disabled configurations, including flags supplied to a compiler baseline. The isolated correction captures each prior value and restores it on teardown. It changes only the benchmark test.

Apply `restore-prior-flags.patch` after merging the incoming commit. Expected incoming blob: `f69f1b6f174dbf9bdcfa5150981ec0cefbf5c361`. Expected corrected blob: `805f2a8c89fd59d1061029103b3182ef7429b252`. Corrected file SHA-256: `4123f9add678a6007a7cf363486c2a508b00a0e6f73b3882a57140cb4f65e80b`. Patch SHA-256: `6ac2c4cddb2ab7cc8d783fdb1b8befbdd0e509cf62391e981c4cd019a126b3b2`.

The runtime baseline switch intentionally remains scoped to the first full-Studio typing test. Other controller/session measurements are not covered by that switch and were not qualified or described as baseline measurements here.

## Executed qualification

A detached worktree at `/workspace/scratch/56d5733a0888/quds_perf_review` supplied all local source packages. Flutter **3.47.8** and Dart **3.13.7** were pinned through the existing toolchain environment. `flutter pub get --offline --enforce-lockfile` succeeded; the dependency lock remained byte-identical to the integrated tree. `runtime.json` confirms all 20 local package roots resolve inside the detached worktree.

| Check | Result | Observed behavior |
|---|---|---|
| Original incoming benchmark analysis | Passed | No diagnostics |
| Corrected benchmark and restoration-probe analysis | Passed | No diagnostics |
| Runtime baseline disabled | 1/1 passed | 300 keystrokes; `translate=true`, `coalesce=true` |
| Runtime baseline enabled | 1/1 passed | 300 keystrokes; `translate=false`, `coalesce=false` |
| Prior-value restoration | 2/2 passed | Real benchmark executes with prior flags false; following assertion confirms both remain false |

All commands returned zero, and all stderr logs were empty. The corrected run froze **2,507** Dart, package/lock and font inputs before/after execution; none changed during qualification. The modified benchmark is intake HEAD plus the recorded patch, not an unmodified-HEAD claim. Raw JSON test streams, diagnostic timing metrics, exact commands, environments and timestamps are retained alongside the input manifests.

The restoration probe is a qualification-only wrapper in `perf_baseline_restoration_probe_test.dart`. To repeat it, copy it beside the original benchmark test in the detached worktree. It imports and runs the real benchmark, then observes its post-test flag state. It is excluded from the merge patch.

The three actual typing runs validate the switch and teardown behavior. Their debug-JIT/fake-clock timing measurements are retained for diagnosis; no release-build speedup or cross-machine performance claim follows from these runs. No GitHub Actions job was consulted or awaited.

## Evidence and replay

- `summary.json`: semantic result and exact merge recommendation.
- `qualification.json`: corrected-source run receipts and frozen-input result.
- `setup.json`, `runtime.json`: offline bootstrap, pinned runtime and dependency routing.
- `optimized.receipt.json`, `baseline.receipt.json`, `restoration.receipt.json`: exact executable commands and environment.
- `*.stdout`, `*.stderr`, `*.metrics.json`: raw outputs and parsed diagnostic metrics.
- `qualified-inputs-before.json`, `qualified-inputs-after.json`: corrected-source SHA-256 manifests.
- `restore-prior-flags.patch`: the sole source correction to apply after the incoming merge.

The root source tree and root Git index were not modified by this review. The detached worktree retains the corrected benchmark plus the temporary restoration probe for replay.
