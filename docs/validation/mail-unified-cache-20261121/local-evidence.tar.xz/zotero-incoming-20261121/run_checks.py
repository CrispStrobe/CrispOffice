import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root=Path('/workspace/scratch/56d5733a0888')
repo=root/'quds_odt_review'
engine=repo/'packages/quds_office_engine'
out=root/'validation/zotero-incoming-20261121'
dart=str(root/'toolchains/flutter/bin/dart')
flutter=str(root/'toolchains/flutter/bin/flutter')
source=['lib/src/odf/odf_zotero.dart','lib/src/odf/odf_zotero_models.dart','lib/src/odf/odf_zotero_preferences.dart','test/odf_zotero_ownership_test.dart','test/odf_zotero_preferences_test.dart','test/odf_zotero_reference_marks_test.dart','tool/zotero/odt_inventory.dart','lib/quds_office_engine.dart']
tracked=[engine/p for p in source]+[repo/'pubspec.lock',repo/'pubspec.yaml',repo/'.fvmrc']
def hashes():return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in tracked}
env=os.environ.copy()
env.update({'PATH':str(root/'toolchains/flutter/bin')+':'+env['PATH'],'PUB_CACHE':str(root/'toolchains/pub-cache'),'TMPDIR':str(root/'toolchains/tmp'),'XDG_CONFIG_HOME':str(root/'toolchains/config'),'XDG_CACHE_HOME':str(root/'toolchains/cache'),'XDG_DATA_HOME':str(root/'toolchains/data'),'CI':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','DART_SUPPRESS_ANALYTICS':'true'})
configs={
 'tests':[dart,'test','--reporter','expanded','test/odf_zotero_ownership_test.dart','test/odf_zotero_preferences_test.dart','test/odf_zotero_reference_marks_test.dart'],
 'analysis':[flutter,'--no-version-check','analyze','--no-pub','--fatal-infos',*source],
 'format':[dart,'format','--output=none','--set-exit-if-changed',*source],
}
def run(item):
 name,command=item
 before=hashes()
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/f'{name}.log').open('wb') as log:
  result=subprocess.run(command,cwd=engine,env=env,stdout=log,stderr=subprocess.STDOUT)
 after=hashes()
 receipt={'target_commit':'0ad43b78ef43d26bc2c97b8b75ad58ca20914617','cohort':name,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(engine),'argv':command,'exit_code':result.returncode,'source_sha256_before':before,'source_sha256_after':after,'sources_changed_during_run':[p for p,h in before.items() if after[p]!=h]}
 (out/f'{name}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'cohort':name,'exit_code':result.returncode,'sources_changed':receipt['sources_changed_during_run']}),flush=True)
 for line in (out/f'{name}.log').read_text(errors='replace').splitlines()[-12:]: print(line,flush=True)
 return result.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 results=list(pool.map(run,configs.items()))
raise SystemExit(1 if any(results) else 0)
