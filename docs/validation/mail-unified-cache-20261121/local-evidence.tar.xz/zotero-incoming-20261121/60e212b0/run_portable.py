import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root=Path('/workspace/scratch/56d5733a0888')
repo=root/'quds_odt_review'
engine=repo/'packages/quds_office_engine'
out=root/'validation/zotero-incoming-20261121/60e212b0'
dart=str(root/'toolchains/flutter/bin/dart')
packages='--packages='+str(repo/'.dart_tool/package_config.json')
script='tool/zotero/odt_inventory_acceptance.dart'
js=out/'odt_inventory_acceptance.js'
paths=set((engine/'lib').rglob('*.dart'))|{engine/script,repo/'pubspec.lock',repo/'.fvmrc'}
def hashes():return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=hashes()
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
env=os.environ.copy()
env.update({'PATH':str(root/'toolchains/flutter/bin')+':'+env['PATH'],'PUB_CACHE':str(root/'toolchains/pub-cache'),'TMPDIR':str(root/'toolchains/tmp'),'XDG_CONFIG_HOME':str(root/'toolchains/config'),'XDG_CACHE_HOME':str(root/'toolchains/cache'),'XDG_DATA_HOME':str(root/'toolchains/data'),'CI':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','DART_SUPPRESS_ANALYTICS':'true'})
commands=[('vm',[dart,packages,script]),('compile',[dart,'compile','js','-O1',packages,script,'-o',str(js)]),('node',[shutil.which('node'),'-e','globalThis.self = globalThis; require(process.argv[1])',str(js)])]
stages=[]
for name,command in commands:
 with (out/f'portable-{name}.stdout').open('wb') as stdout,(out/f'portable-{name}.stderr').open('wb') as stderr:
  result=subprocess.run(command,cwd=engine,env=env,stdout=stdout,stderr=stderr)
 stages.append({'stage':name,'argv':command,'exit_code':result.returncode})
 if result.returncode:break
after=hashes()
summary={}
equal=False
if len(stages)==3 and all(s['exit_code']==0 for s in stages):
 a=(out/'portable-vm.stdout').read_bytes()
 b=(out/'portable-node.stdout').read_bytes()
 equal=a==b
 vm=json.loads(a)
 node=json.loads(b)
 assert vm==node
 summary={key:node[key] for key in ['fixtureKind','nativePluginCommit','sourceBytesPreserved','stableRepeatInventory','malformedPackageRejected','fieldBudgetRejected']}
 summary['field_count']=len(node['inventory']['fields'])
 summary['guarded_cross_cell_eligible']=node['guardedCrossCell']['isImportCandidate']
 summary['editable']=node['inventory']['editable']
receipt={'target_commit':'60e212b0d62f55054a1e77e5b8721564656eaf57','start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(engine),'stages':stages,'vm_node_byte_equal':equal,'summary':summary,'source_sha256_before':before,'source_sha256_after':after,'sources_changed_during_run':[p for p,h in before.items() if after[p]!=h]}
(out/'portable-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'stage_exit_codes':[s['exit_code'] for s in stages],'vm_node_byte_equal':equal,'summary':summary,'sources_changed':receipt['sources_changed_during_run']},indent=2))
raise SystemExit(0 if equal and not receipt['sources_changed_during_run'] else 1)
