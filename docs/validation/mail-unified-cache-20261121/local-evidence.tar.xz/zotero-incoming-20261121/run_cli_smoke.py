import hashlib
import html
import json
import os
from pathlib import Path
import subprocess
import zipfile

root=Path('/workspace/scratch/56d5733a0888')
repo=root/'quds_odt_review'
engine=repo/'packages/quds_office_engine'
out=root/'validation/zotero-incoming-20261121'
payload={'citationID':'audit-c1','citationItems':[{'id':'https://zotero.org/users/1/items/ABCDEFGH'}],'properties':{'plainCitation':'(Audit)','noteIndex':0}}
name='ZOTERO_ITEM CSL_CITATION '+json.dumps(payload,separators=(',',':'))+' RND0123456789'
attribute=html.escape(name,quote=True)
xml='<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0"><office:body><office:text><text:p>Before <text:reference-mark-start text:name="'+attribute+'"/>(Audit)<text:reference-mark-end text:name="'+attribute+'"/> after</text:p></office:text></office:body></office:document-content>'
valid=out/'native-inventory-smoke.odt'
invalid=out/'wrong-mimetype-smoke.odt'
for path,mimetype in [(valid,'application/vnd.oasis.opendocument.text'),(invalid,'application/zip')]:
 with zipfile.ZipFile(path,'w') as z:
  z.writestr('mimetype',mimetype,compress_type=zipfile.ZIP_STORED)
  z.writestr('content.xml',xml,compress_type=zipfile.ZIP_DEFLATED)
input_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [valid,invalid]}
env=os.environ.copy()
env.update({'PATH':str(root/'toolchains/flutter/bin')+':'+env['PATH'],'PUB_CACHE':str(root/'toolchains/pub-cache'),'TMPDIR':str(root/'toolchains/tmp'),'XDG_CONFIG_HOME':str(root/'toolchains/config'),'XDG_CACHE_HOME':str(root/'toolchains/cache'),'XDG_DATA_HOME':str(root/'toolchains/data'),'CI':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','DART_SUPPRESS_ANALYTICS':'true'})
base=[str(root/'toolchains/flutter/bin/dart'),'--packages='+str(repo/'.dart_tool/package_config.json'),'tool/zotero/odt_inventory.dart']
receipts=[]
for label,args,expected in [('help',['--help'],0),('valid',[str(valid)],0),('invalid',[str(invalid)],65)]:
 command=[*base,*args]
 result=subprocess.run(command,cwd=engine,env=env,capture_output=True,text=True)
 (out/f'cli-{label}.stdout').write_text(result.stdout)
 (out/f'cli-{label}.stderr').write_text(result.stderr)
 receipts.append({'case':label,'argv':command,'exit_code':result.returncode,'expected_exit_code':expected})
 assert result.returncode==expected,(label,result.returncode,result.stderr)
 if label=='valid':
  data=json.loads(result.stdout)
  assert data['editable'] is False and data['format']=='odt'
  assert len(data['fields'])==1 and data['issues']==[]
  field=data['fields'][0]
  assert field['isValid'] and field['isImportCandidate']
  assert field['cachedText']=='(Audit)' and field['name']==name
  assert field['starts'][0]['offset']==7 and field['ends'][0]['offset']==14
  assert field['issues']==[]
  assert not data['preferences']['isPresent']
 assert input_hashes=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [valid,invalid]}
receipt={'target_commit':'0ad43b78ef43d26bc2c97b8b75ad58ca20914617','commands':receipts,'valid_result':{'field_count':1,'cached_text':'(Audit)','start_offset':7,'end_offset':14,'editable':False},'input_sha256':input_hashes,'inputs_unchanged':True}
(out/'cli-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
