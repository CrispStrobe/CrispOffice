import datetime,hashlib,json,subprocess
from pathlib import Path
root=Path('/workspace/scratch/56d5733a0888')
repo=root/'quds_office_suite'
out=root/'validation/final-intake-20261121'
capture=json.loads((out/'capture.json').read_text())
checkpoint=capture['comparison_checkpoint']
def git(*args,check=True):
 p=subprocess.run(['git',*args],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 if check and p.returncode: raise RuntimeError(f'git {args}: {p.stderr}')
 return p.stdout.strip()
def entry(sha,path):return git('ls-tree',sha,'--',path)
original_path='docs/validation/mail-unified-cache-20261121/intake.json'
original_bytes=subprocess.check_output(['git','show',checkpoint+':'+original_path],cwd=repo)
original=json.loads(original_bytes)
ancestors=set(git('rev-list',checkpoint).splitlines())
all_heads={p['head'] for key in ['fork_branches','fork_prs','upstream_branches','upstream_prs'] for p in capture[key]['items']}
exists=subprocess.run(['git','cat-file','--batch-check=%(objectname) %(objecttype)'],cwd=repo,input='\n'.join(sorted(all_heads))+'\n',text=True,stdout=subprocess.PIPE,check=True).stdout.splitlines()
missing=[s for s in exists if s.endswith(' missing')]
if missing: raise RuntimeError('Missing Git objects: '+repr(missing))
historical=[]
for old in original['historical_equivalence_proofs']:
 source,replacement=old['source'],old['replacement']
 record={'source':source,'replacement':replacement,'kind':old['kind'],'replacement_ancestor_of_checkpoint':replacement in ancestors}
 if old['kind']=='full_tree':
  record['source_tree']=git('rev-parse',source+'^{tree}')
  record['replacement_tree']=git('rev-parse',replacement+'^{tree}')
  record['exact_equal']=record['source_tree']==record['replacement_tree']
 elif old['kind']=='changed_paths':
  only=git('rev-list',source,'--not',replacement).splitlines()
  actual=set()
  for commit in only:
   parents=git('show','-s','--format=%P',commit).split()
   if len(parents)!=1: raise RuntimeError('Expected ordinary source contribution commit')
   actual.update(git('diff','--name-only',parents[0],commit).splitlines())
  declared=set(old['changed_paths'])
  record['source_only_commits']=only
  record['source_only_commits_match_original']=set(only)==set(old['source_only_commits'])
  record['declared_paths_equal_actual_delta']=declared==actual
  record['blob_comparisons']=[{'path':p,'source_entry':entry(source,p),'replacement_entry':entry(replacement,p)} for p in sorted(actual)]
  record['exact_equal']=declared==actual and record['source_only_commits_match_original'] and all(p['source_entry']==p['replacement_entry'] for p in record['blob_comparisons'])
 else: raise RuntimeError('Unknown proof type')
 record['covered']=record['replacement_ancestor_of_checkpoint'] and record['exact_equal']
 historical.append(record)
proof_map={x['source']:x for x in historical if x['covered']}
def qualify(items):
 result=[]
 for item in items:
  p=dict(item);sha=p['head']
  p['ancestor_of_checkpoint']=sha in ancestors
  if sha in ancestors:p['disposition']='ancestor'
  elif sha in proof_map:
   p['disposition']='exact_historical_equivalent'
   p['replacement']=proof_map[sha]['replacement']
   p['proof_kind']=proof_map[sha]['kind']
  else:p['disposition']='uncovered'
  result.append(p)
 return result
qualified={key:qualify(capture[key]['items']) for key in ['fork_branches','fork_prs','upstream_branches','upstream_prs']}
uncovered=[{'collection':key,**p} for key,items in qualified.items() for p in items if p['disposition']=='uncovered']
open_numbers=[p['number'] for p in capture['fork_open_prs']['items']]
expected_open=[p['number'] for p in capture['fork_prs']['items'] if p['state']=='open']
upstream_open_numbers=[p['number'] for p in capture['upstream_open_prs']['items']]
expected_upstream_open=[p['number'] for p in capture['upstream_prs']['items'] if p['state']=='open']
assert set(open_numbers)==set(expected_open)
assert set(upstream_open_numbers)==set(expected_upstream_open)
assert all(capture[k]['pagination_complete'] for k in ['fork_branches','fork_prs','fork_open_prs','upstream_branches','upstream_prs','upstream_open_prs'])
old_pr={p['number']:p for p in original['pull_requests']}
new_prs=[p for p in qualified['fork_prs'] if p['number'] not in old_pr]
changed_historical_pr_heads=[{'number':p['number'],'old_head':old_pr[p['number']]['head'],'new_head':p['head']} for p in qualified['fork_prs'] if p['number'] in old_pr and p['head']!=old_pr[p['number']]['head']]
old_branches={p['name']:p['head'] for p in original['fork_branches']}
branch_changes=[{'name':p['name'],'original_head':old_branches.get(p['name']),'captured_head':p['head'],'disposition':p['disposition']} for p in qualified['fork_branches'] if old_branches.get(p['name'])!=p['head']]
counts={key:len(items) for key,items in qualified.items()}
counts.update({'fork_pr_heads_ancestors':sum(p['disposition']=='ancestor' for p in qualified['fork_prs']),'fork_pr_heads_exact_historical_equivalents':sum(p['disposition']=='exact_historical_equivalent' for p in qualified['fork_prs']),'fork_open_prs':len(open_numbers),'upstream_open_prs':len(upstream_open_numbers),'uncovered_heads':len(uncovered),'revalidated_historical_proofs':len(historical)})
proof={'schema_version':1,'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':capture['repository'],'capture_start_utc':capture['capture_start_utc'],'capture_end_utc':capture['capture_end_utc'],'comparison_checkpoint':checkpoint,'checkpoint_tree':git('rev-parse',checkpoint+'^{tree}'),'checkpoint_present_remote_as':next((p['name'] for p in capture['fork_branches']['items'] if p['head']==checkpoint),None),'original_intake':{'commit':checkpoint,'path':original_path,'git_blob':git('rev-parse',checkpoint+':'+original_path),'sha256':hashlib.sha256(original_bytes).hexdigest()},'counts':counts,'historical_equivalence_proofs':historical,**qualified,'open_prs':capture['fork_open_prs']['items'],'upstream_open_prs':capture['upstream_open_prs']['items'],'new_prs_since_original_intake':new_prs,'changed_historical_pr_heads':changed_historical_pr_heads,'branch_changes_since_original_intake':branch_changes,'uncovered_heads':uncovered,'new_work_required_beyond_checkpoint':uncovered,'all_captured_heads_covered':not uncovered and all(x['covered'] for x in historical),'verification':{'read_only_source':True,'git_objects_fetched':False,'remote_mutations':False,'index_mutations':False,'ci_endpoints_queried':False,'runtime_tests_claimed':False},'limitations':['The capture is bounded to the recorded UTC interval; later remote advances are outside this receipt.','An ancestry proof records preservation of work; it does not supersede separate runtime qualification.','The 14 historically rewritten PR heads are accounted for by 13 full-tree and one changed-path proof; an additional historical intermediate source proof is also revalidated.']}
(out/'ancestry-equivalence-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
summary={k:proof[k] for k in ['capture_start_utc','capture_end_utc','comparison_checkpoint','checkpoint_tree','counts','all_captured_heads_covered','changed_historical_pr_heads','uncovered_heads','verification']}
summary['open_fork_pull_requests']=[{'number':p['number'],'head':p['head'],'url':p['url']} for p in capture['fork_open_prs']['items']]
summary['new_prs_since_original_intake']=[{'number':p['number'],'head':p['head'],'disposition':p['disposition']} for p in new_prs]
summary['branch_changes_since_original_intake']=branch_changes
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
assert proof['all_captured_heads_covered']
