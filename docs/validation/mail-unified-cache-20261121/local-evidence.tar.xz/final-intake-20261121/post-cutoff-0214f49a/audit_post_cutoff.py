import datetime,hashlib,io,json,subprocess,zipfile
from pathlib import Path
root=Path('/workspace/scratch/56d5733a0888')
repo=root/'quds_odt_review'
shared=root/'quds_office_suite'
out=root/'validation/final-intake-20261121/post-cutoff-0214f49a'
refs={'frozen':'62e9f1af15f2cb00ee67a339cdc6dea48d882aab','main':'0214f49a2e9e5d7b459be90b6ebd948d262c6dd6','zotero':'fb386d6e42a2336f1431e38bf6d713552edd0978','base':'ce4eca72da1698f1b1ce9d2d494f345dbad32827'}
def g(*args,cwd=repo):
 return subprocess.check_output(['git',*args],cwd=cwd).decode().strip()
def blob(ref,path):
 return subprocess.check_output(['git','show',ref+':'+path],cwd=repo)
def tree(ref):
 raw=subprocess.check_output(['git','ls-tree','-rz','--full-tree',ref],cwd=repo)
 result={}
 for item in raw.split(b'\0'):
  if not item:continue
  meta,path=item.split(b'\t',1)
  result[path.decode()]=meta.decode()
 return result
trees={name:tree(ref) for name,ref in refs.items()}
def delta(a,b):
 return [p for p in sorted(set(trees[a])|set(trees[b])) if trees[a].get(p)!=trees[b].get(p)]
incoming=delta('base','main')
assert incoming==delta('base','zotero')
assert trees['main']==trees['zotero']
assert all(p.startswith('docs/') for p in incoming)
root_delta=delta('base','frozen')
non_doc=[p for p in root_delta if not p.startswith('docs/')]
non_doc_full={p:v for p,v in trees['frozen'].items() if not p.startswith('docs/')}
non_doc_base={p:v for p,v in trees['base'].items() if not p.startswith('docs/')}
non_doc_incoming={p:v for p,v in trees['main'].items() if not p.startswith('docs/')}
assert non_doc_base==non_doc_incoming
preserved=[{'path':p,'base_entry':trees['base'].get(p),'incoming_entry':trees['main'].get(p),'frozen_entry':trees['frozen'].get(p),'incoming_unchanged_from_base':trees['base'].get(p)==trees['main'].get(p)} for p in non_doc]
assert all(p['incoming_unchanged_from_base'] for p in preserved)
overlap=sorted(set(root_delta)&set(incoming))
assert overlap==['docs/validation/zotero-odt-inventory-20261121/README.md']
base_path='docs/validation/zotero-odt-inventory-20261121/'
qualified=json.loads(blob(refs['zotero'],base_path+'qualified-source-sha256.json'))
# Read tracked Git blobs in one batch; record local/environment-only inputs separately.
wanted={p:expected for group in qualified.values() for p,expected in group.items() if p in trees['frozen']}
object_ids=sorted({trees['frozen'][p].split()[2] for p in wanted})
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(object_ids)+'\n').encode())
offset=0;content_hashes={}
for oid in object_ids:
 end=raw.index(b'\n',offset)
 header=raw[offset:end].decode().split()
 if len(header)!=3 or header[1]!='blob':raise RuntimeError('Unexpected object response '+repr(header))
 size=int(header[2]);start=end+1;contents=raw[start:start+size]
 assert raw[start+size:start+size+1]==b'\n'
 content_hashes[oid]=hashlib.sha256(contents).hexdigest();offset=start+size+1
binding={}
for group,entries in qualified.items():
 mismatches=[];untracked=[]
 for p,expected in entries.items():
  if p not in trees['frozen']:untracked.append(p);continue
  actual=content_hashes[trees['frozen'][p].split()[2]]
  if actual!=expected:mismatches.append({'path':p,'expected':expected,'actual':actual})
 binding[group]={'declared_inputs':len(entries),'tracked_inputs_verified':len(entries)-len(untracked),'untracked_environment_inputs':untracked,'mismatches':mismatches}
archive_index=json.loads(blob(refs['zotero'],base_path+'evidence-sha256.json'))
archive=blob(refs['zotero'],base_path+'local-validation.zip')
archive_hash=hashlib.sha256(archive).hexdigest()
assert archive_hash==archive_index['archive']['sha256']
z=zipfile.ZipFile(io.BytesIO(archive))
assert z.testzip() is None
member_bad=[]
for name,spec in archive_index['members'].items():
 value=z.read(name)
 if hashlib.sha256(value).hexdigest()!=spec['sha256'] or len(value)!=spec['bytes']:member_bad.append(name)
assert not member_bad
shared_head=g('rev-parse','HEAD',cwd=shared)
working_non_doc_diff=g('diff','--name-status',refs['frozen'],'--','.',':(exclude)docs/**',cwd=shared)
results=json.loads(blob(refs['zotero'],base_path+'results.json'))
proof={
 'schema_version':1,'audited_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'refs':refs,'tree_ids':{k:g('rev-parse',v+'^{tree}') for k,v in refs.items()},
 'merge_bases':g('merge-base','--all',refs['frozen'],refs['main']).splitlines(),
 'incoming_new_commit_count':int(g('rev-list','--count',refs['base']+'..'+refs['zotero'])),
 'incoming_paths':[{'path':p,'base_entry':trees['base'].get(p),'incoming_entry':trees['main'].get(p)} for p in incoming],
 'incoming_non_documentation_changes':[],'incoming_main_tree_equals_zotero_tree':True,
 'frozen_non_documentation_file_count':len(non_doc_full),
 'frozen_non_documentation_manifest_sha256':hashlib.sha256(json.dumps(non_doc_full,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
 'frozen_local_non_documentation_changes_preserved_by_normal_merge':preserved,
 'overlapping_changed_paths':overlap,
 'qualification_binding_against_frozen_test_head':binding,
 'incoming_evidence_archive':{'bytes':len(archive),'sha256':archive_hash,'expected_sha256':archive_index['archive']['sha256'],'zip_crc_check_passed':True,'verified_member_count':len(archive_index['members']),'member_hash_mismatches':member_bad},
 'incoming_reported_results':{'qualified_source_checkpoint':results['qualified_source_checkpoint'],'engine_tests':results['engine_regression']['passed'],'new_inventory_cases_included':results['new_inventory_case_count'],'note':'These are incoming source-bound author receipts; no runtime tests were rerun by this audit.'},
 'observed_shared_root_head':shared_head,
 'shared_worktree_non_documentation_diff_from_frozen':working_non_doc_diff.splitlines(),
 'readme_resolution':{
  'canonical_path':base_path+'README.md',
  'recommendation':'Retain incoming canonical README and all raw evidence; relocate the independently executed Mail qualification record to docs/validation/mail-unified-cache-20261121/zotero-independent-qualification.md and link it from a subsequent integration section.',
  'counting':'Incoming 2,297 includes the same 149 focused inventory cases. Independent repeats and 263 Word portable/native cases overlap; do not add them as distinct tests.',
  'cutoff':'Incoming statements about later Mail/Touch ID/performance work remaining unintegrated describe its ce4 cutoff. Add the subsequent Mail integration update without rewriting historical raw receipts.'},
 'verification':{'source_mutations':False,'index_mutations':False,'head_or_ref_mutations':False,'ci_endpoints_queried':False,'new_runtime_tests_executed':False}
}
(out/'source-preservation-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
summary={k:proof[k] for k in ['audited_at_utc','refs','tree_ids','merge_bases','incoming_new_commit_count','incoming_non_documentation_changes','incoming_main_tree_equals_zotero_tree','frozen_non_documentation_file_count','frozen_non_documentation_manifest_sha256','overlapping_changed_paths','qualification_binding_against_frozen_test_head','incoming_evidence_archive','incoming_reported_results','observed_shared_root_head','shared_worktree_non_documentation_diff_from_frozen','readme_resolution','verification']}
summary['incoming_documentation_paths']=[p['path'] for p in proof['incoming_paths']]
summary['unopposed_frozen_non_documentation_changes']=len(preserved)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
