from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/56d5733a0888')
REPO = ROOT / 'quds_touchid_review'
OUTPUT = ROOT / 'validation/touchid-incoming-20261121'
spec = importlib.util.spec_from_file_location('final_mail_validation', ROOT / 'validation/run_final_mail.py')
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
helpers.REPO = REPO
label = sys.argv[1]
command = sys.argv[2:]
if not command:
    raise SystemExit('Supply a label and command argv.')
output = OUTPUT / label
output.mkdir(exist_ok=False)
cwd = REPO / 'packages/quds_office_editor/example'
before = helpers.source_snapshot('studio')
extra = subprocess.check_output(['git', 'diff', '--name-only', '64ebfc1bbc1daf9d3e9fc8a03ff8bf95f9973e04', 'HEAD'], cwd=REPO, text=True).splitlines()
def include_extra(snapshot):
    for name in extra:
        path = REPO / name
        if path.is_file():
            snapshot['sha256'][name] = helpers.sha256(path)
    snapshot['file_count'] = len(snapshot['sha256'])
    canonical = json.dumps(snapshot['sha256'], sort_keys=True, separators=(',', ':')).encode()
    snapshot['aggregate_sha256'] = hashlib.sha256(canonical).hexdigest()
include_extra(before)
helpers.write_json(output / 'sources-before.json', before)
receipt = {'argv': command, 'cwd': str(cwd), 'git_before': helpers.git_snapshot(output, 'before'),
           'start_utc': helpers.utc_now(), 'source_manifest_before': str(output / 'sources-before.json'),
           'runner_sha256': helpers.sha256(Path(__file__)),
           'helpers_sha256': helpers.sha256(ROOT / 'validation/run_final_mail.py')}
helpers.write_json(output / 'receipt.json', receipt)
started = time.monotonic()
with (output / 'stdout.jsonl').open('wb') as stdout, (output / 'stderr.log').open('wb') as stderr:
    result = subprocess.run(command, cwd=cwd, env=helpers.load_environment(), stdout=stdout, stderr=stderr)
after = helpers.source_snapshot('studio')
include_extra(after)
helpers.write_json(output / 'sources-after.json', after)
events = helpers.event_summary(output / 'stdout.jsonl')
helpers.write_json(output / 'events.json', events)
changed = sorted(name for name in before['sha256'].keys() | after['sha256'].keys()
                 if before['sha256'].get(name) != after['sha256'].get(name))
receipt.update({'end_utc': helpers.utc_now(), 'elapsed_seconds': round(time.monotonic() - started, 3),
                'exit_code': result.returncode, 'git_after': helpers.git_snapshot(output, 'after'),
                'source_manifest_after': str(output / 'sources-after.json'), 'changed_files': changed,
                'stdout': str(output / 'stdout.jsonl'), 'stderr': str(output / 'stderr.log'),
                'stderr_bytes': (output / 'stderr.log').stat().st_size,
                'real_tests': events['real_tests'], 'typed_events': events['typed_event_counts']})
helpers.write_json(output / 'receipt.json', receipt)
print(json.dumps({'label': label, 'exit_code': result.returncode, 'real_tests': events['real_tests'],
                  'changed_files': changed, 'receipt': str(output / 'receipt.json')}))
raise SystemExit(result.returncode)
