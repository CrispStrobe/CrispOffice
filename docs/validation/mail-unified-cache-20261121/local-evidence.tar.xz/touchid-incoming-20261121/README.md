# Incoming Touch ID vault unlock review

The incoming branch tip `38b0dae033e50bd6409ad3a4930b083fb8b5b7c5` is one new
commit above `64ebfc1bbc1daf9d3e9fc8a03ff8bf95f9973e04`, the common ancestor with
both the fetched main and the integrated HEAD observed at review start
(`678e9c619b09153ba7d650c11939c3443c93e8e6`). It changes 15 files (+1854/-127),
including raw vault-key import/export, the Dart/Swift biometric bridge, settings
and Mail unlock flows, signing integration and regression tests. It is useful
new code, not an equivalent historical branch.

Review and execution occurred in the detached sparse checkout
`/workspace/scratch/56d5733a0888/quds_touchid_review`. The original branch commit
was preserved. No shared source, shared index or remote ref was changed.
The already verified dependency configuration was copied into this checkout;
relative local package URIs resolve this checkout, not the main worktree. No pub
resolution, dependency change, real credential access or biometric prompt ran.

## Reproduced and corrected findings

1. A successful keychain write followed by failed preference persistence and
   failed rollback could leave a vault key without an enabled flag. Startup
   and mode-change cleanup previously skipped that item. Enrolment now persists
   the disabled state before storing a key, confirms both writes before enabling,
   refreshes optimistic preference cache after rejected writes and keeps an
   in-process cleanup guard. Disabled enrolments are cleaned on startup even
   while the vault remains selected. Removal independently attempts the
   preference and keychain operations. Incomplete removal is visible with an
   explicit retry action in Credential storage.
2. Preference/vault-handle exceptions could escape the biometric manager and
   bypass the password prompt, or leave its retry dialog busy with Close blocked.
   Expected backend failures now return a failed outcome; the initial and retry
   UI boundaries also catch unexpected manager exceptions and restore password
   and Cancel controls. Returned raw key bytes are cleared even if opening the
   vault handle fails.
3. A retained unlocked vault handle could be re-enrolled after selecting another
   credential backend. Enrolment now requires the selected vault and checks its
   selection generation and exact handle across asynchronous preparation,
   preference writes and key storage. Superseded enrolment rolls back.

Native Swift access-control flags, device-only/non-synchronizing storage and
master-password verification were not weakened or changed by the correction.
The original tests' setup now selects/loads the vault before enrolment, matching
the real UI. The removal-failure expectation now verifies a durable disabled
flag plus pending cleanup, rather than retaining an enabled preference.

## Local qualification

All runtime commands use the pinned Flutter 3.47.8 / Dart 3.13.7 environment
from `toolchains/env.sh`. Exact argv, working directory, timestamps, exit status,
separate raw stdout/stderr, typed JSON events, Git HEAD/tree/status and before/
after source/dependency SHA-256 maps are retained in each run directory.

| Record | Result |
| --- | --- |
| `original-tests` | Incoming biometric suite plus existing selection/selection-race suites: 39 passed on unchanged incoming production code |
| `original-recovery-regressions` | Seven new fake-only regressions: 0 passed, 3 failures and 4 errors on incoming code, reproducing the identified gaps |
| `fixed-regressions` | First correction, before selection-guard additions: 35 passed |
| `final-credential-cohort-strict` | Final source: 85 passed, no failures, errors or skips; six credential and native-Mail test files |
| `final-analysis-strict` | Nine affected/incoming Dart files analyzed with `--fatal-infos`: no issues |
| `final-format` | Nine Dart files: zero formatting changes |
| `static-checks.json` | Signing script passes `bash -n`; correction patch reverse-check and Git whitespace check pass |

The final test command runs these six files in one native Flutter invocation:

```text
flutter --no-version-check test --no-pub --reporter json
  test/studio_credential_biometric_recovery_test.dart
  test/studio_credential_biometric_unlock_test.dart
  test/studio_credential_selection_test.dart
  test/studio_credential_selection_race_test.dart
  test/studio_mail_credentials_test.dart
  test/studio_mail_credential_backend_switch_test.dart
```

All final sources and dependency locks were unchanged across execution.
Hidden loading completions are excluded from real test counts. Intermediate
analysis found two test-only brace lints; they were corrected before the final
strict analysis and 85-test run. Original logs remain intact. Early source
manifests have correct individual file hashes; corrected aggregate totals after
including native/doc files are supplied in `early-manifest-derived-totals.json`.

## Integration payload and remaining platform gate

`touchid-recovery.patch` is based on the preserved incoming commit. Its SHA-256
and the exact final contents of each changed file are in `patch-manifest.json`.
Merge the incoming commit first, then apply this correction as a separate
checkpoint. `summary.json` links the source-bound receipts and per-suite counts.

The Linux environment does not execute macOS Swift frameworks, signed-app
keychain entitlement checks or actual Touch ID. The incoming signing script was
syntax-checked; no app was signed, notarized or uploaded. Actual macOS acceptance
still requires a correctly entitled test build and disposable vault: successful
Touch ID, cancellation/password fallback, changed enrollment, unavailable or
locked biometry, mode/reset cleanup and signing-profile verification. No claim
of native biometric or release-signing qualification is made here.
