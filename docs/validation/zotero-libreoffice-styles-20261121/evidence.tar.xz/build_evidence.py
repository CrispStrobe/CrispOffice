#!/usr/bin/env python3
"""Package completed local receipts without changing the qualified source."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import tarfile

ROOT = pathlib.Path('/workspace/scratch/d565978da184/quds_office_suite')
OUT = pathlib.Path('/workspace/scratch/d565978da184/qualification')
DEST = ROOT / 'docs/validation/zotero-libreoffice-styles-20261121'
STAGE = OUT / 'evidence-staging'
GATES = ('engine', 'engine_integration', 'editor', 'studio')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


receipts = {}
for gate in GATES:
    receipt = json.loads((OUT / f'{gate}-receipt.json').read_text())
    assert receipt['success'] and receipt['exit_code'] == 0, gate
    assert receipt['source_changed'] == [] and receipt['errors'] == [], gate
    receipts[gate] = receipt
    for name in (f'{gate}-receipt.json', f'{gate}.jsonl', f'{gate}.stderr',
                 f'{gate}-source-before.json', f'{gate}-source-after.json'):
        copy(OUT / name, STAGE / 'gates' / gate / name)

final_manifest = json.loads((OUT / 'engine_integration-source-after.json').read_text())
for gate in ('editor', 'studio'):
    assert json.loads((OUT / f'{gate}-source-before.json').read_text()) == final_manifest, gate
    assert json.loads((OUT / f'{gate}-source-after.json').read_text()) == final_manifest, gate
manifest_differences = {
    path: digest(ROOT / path)
    for path, expected in final_manifest.items()
    if digest(ROOT / path) != expected
}
publication = json.loads((DEST / 'publication-reconciliation.json').read_text())
assert manifest_differences == {
    entry['path']: entry['publication_sha256']
    for entry in publication['changed_manifest_inputs']
}
assert publication['selected_qualification_tests_changed'] == []
assert publication['production_sources_changed'] == []
assert publication['dependency_files_changed'] == []
assert publication['incoming_paths_match_main_exactly']
assert subprocess.check_output(
    ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True
).strip() == publication['publication_source']
copy(DEST / 'publication-reconciliation.json', STAGE / 'publication-reconciliation.json')

for name in ('analysis-receipt.json', 'analysis.txt', 'analyze-files.json',
             'format-receipt.json', 'format.txt', 'selection.json', 'run_gate.py',
             'mail-integration-source-comparison.json',
             'git-fetch-main-3397ead3752f65bb3fa0e764c5da1bc2dd0af485.json',
             'git-fetch-main-089d11cd073520208f27a09b2914d57615cef7ff.json',
             'build_evidence.py'):
    copy(OUT / name, STAGE / name)
analysis = json.loads((OUT / 'analysis-receipt.json').read_text())
formatting = json.loads((OUT / 'format-receipt.json').read_text())
assert analysis['exit_code'] == 0 and formatting['exit_code'] == 0
copy(DEST / 'runtime-setup.json', STAGE / 'runtime-setup.json')
for dirname in ('development-review-interrupted', 'development-editor-before-mail-merge'):
    for path in sorted((OUT / dirname).iterdir()):
        if path.is_file():
            copy(path, STAGE / 'development' / dirname / path.name)
for name in ('engine-focused.jsonl', 'engine-focused.stderr'):
    copy(OUT / name, STAGE / 'development' / name)

files = {
    str(path.relative_to(STAGE)): {'sha256': digest(path), 'bytes': path.stat().st_size}
    for path in sorted(STAGE.rglob('*'))
    if path.is_file() and path.relative_to(STAGE).as_posix() != 'evidence-manifest.json'
}
manifest = {'algorithm': 'sha256', 'scope': 'Archive members except this manifest itself', 'files': files}
(STAGE / 'evidence-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(DEST / 'evidence-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = DEST / 'evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for path in sorted(STAGE.rglob('*')):
        if not path.is_file():
            continue
        info = tar.gettarinfo(str(path), arcname=str(path.relative_to(STAGE)))
        info.uid = info.gid = info.mtime = 0
        info.uname = info.gname = ''
        with path.open('rb') as contents:
            tar.addfile(info, contents)

fixture_root = ROOT / 'packages/quds_office_engine/test/fixtures/zotero/odt'
summary = {
    'status': 'passed',
    'broad_engine_source': '69bb63caa0e4a5423ed36f9118b0cfe562f9ea2f',
    'final_integrated_source': '9a3e5021bd9dd6468f5e8f37334d5a02bd9c174e',
    'final_integrated_tree': 'd3735995e30c2325ea689a1e78829f6a99013932',
    'incoming_main': '3397ead3752f65bb3fa0e764c5da1bc2dd0af485',
    'counting': 'Completed visible testDone events. Runs overlap; no aggregate unique-case or parity percentage is claimed.',
    'gates': {gate: {key: r[key] for key in (
        'success', 'exit_code', 'head', 'selected_test_files', 'counts', 'seconds',
        'started_utc', 'finished_utc', 'source_file_count', 'source_changed', 'logs'
    )} for gate, r in receipts.items()},
    'analysis': analysis,
    'formatting': formatting,
    'source_comparison': json.loads((OUT / 'mail-integration-source-comparison.json').read_text()),
    'final_source_manifest_sha256': digest(OUT / 'engine_integration-source-after.json'),
    'final_source_file_count': len(final_manifest),
    'final_source_matches_worktree': not manifest_differences,
    'publication_qualified_code_dependencies_fixtures_and_selected_tests_unchanged': True,
    'publication': {
        'source': publication['publication_source'],
        'tree': publication['publication_tree'],
        'incoming_main': publication['incorporated_main'],
        'reconciliation_file': 'publication-reconciliation.json',
        'reconciliation_sha256': digest(DEST / 'publication-reconciliation.json'),
        'changed_manifest_inputs': publication['changed_manifest_inputs'],
        'selected_qualification_tests_unchanged': publication['selected_qualification_tests'],
        'interpretation': publication['interpretation'],
    },
    'fixtures': {name: {'sha256': digest(fixture_root / name), 'bytes': (fixture_root / name).stat().st_size}
                 for name in ('native-prose.odt', 'native-prose.docx')},
    'runtime_receipt_sha256': digest(DEST / 'runtime-setup.json'),
    'evidence': {'file': archive.name, 'sha256': digest(archive), 'bytes': archive.stat().st_size,
                 'manifest_sha256': digest(DEST / 'evidence-manifest.json')},
    'ci': 'GitHub Actions and commit status endpoints were neither queried nor awaited.',
    'scope': 'Local source qualification of bounded native ODT conversion and existing-script editing. No installed Word/LibreOffice/Zotero plugin or native editable ODT-output acceptance claim.',
}
(DEST / 'qualification.json').write_text(json.dumps(summary, indent=2) + '\n')
with tarfile.open(archive, 'r:xz') as tar:
    for name, entry in files.items():
        data = tar.extractfile(name).read()
        assert hashlib.sha256(data).hexdigest() == entry['sha256'], name
print(json.dumps({'gates': {g: r['counts'] for g, r in receipts.items()},
                  'archive_sha256': summary['evidence']['sha256'],
                  'archive_bytes': summary['evidence']['bytes'],
                  'source_files': len(final_manifest)}, indent=2))
