#!/usr/bin/env python3
"""Local validation receipt; source packages and dependencies are never edited."""
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/workspace/scratch/d565978da184/quds_office_suite')
OUT = pathlib.Path('/workspace/scratch/d565978da184/qualification')
RUNTIME = pathlib.Path('/workspace/scratch/d565978da184/runtime')
SELECTION = json.loads((OUT / 'selection.json').read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manifest():
    paths = subprocess.check_output(
        ['git', 'ls-files', '-z'], cwd=ROOT
    ).decode().split('\0')
    prefixes = ('packages/quds_office_engine/', 'packages/quds_office_editor/')
    selected = {}
    for name in paths:
        if not name:
            continue
        p = ROOT / name
        if p.name in ('pubspec.yaml', 'pubspec.lock', '.fvmrc') or (
            name.startswith(prefixes)
            and p.suffix in ('.dart', '.ttf', '.otf', '.odt', '.docx', '.bas')
        ):
            selected[name] = sha(p)
    return selected


gate = sys.argv[1]
if gate not in SELECTION:
    raise SystemExit('Unknown qualification gate')
is_engine = gate.startswith('engine')
package = ROOT / 'packages/quds_office_engine' if is_engine else (
    ROOT / 'packages/quds_office_editor' if gate == 'editor'
    else ROOT / 'packages/quds_office_editor/example'
)
flutter = pathlib.Path(os.environ['FLUTTER_ROOT'])
if is_engine:
    command = [
        str(flutter / 'bin/cache/dart-sdk/bin/dart'),
        '--packages=' + str(ROOT / '.dart_tool/package_config.json'),
        str(RUNTIME / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'),
        '-j', '1', '--fail-fast', '--reporter=json', *SELECTION[gate],
    ]
else:
    command = [
        str(flutter / 'bin/flutter'), '--no-version-check', 'test',
        '--no-pub', '--concurrency=1', '--reporter=json', *SELECTION[gate],
    ]

before = manifest()
(OUT / f'{gate}-source-before.json').write_text(json.dumps(before, indent=2) + '\n')
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
started = time.monotonic()
print(json.dumps({'gate': gate, 'status': 'started', 'files': len(SELECTION[gate]),
                  'source_files': len(before), 'utc': start}), flush=True)
with (OUT / f'{gate}.jsonl').open('w') as stdout, (OUT / f'{gate}.stderr').open('w') as stderr:
    process = subprocess.run(command, cwd=package, stdout=stdout, stderr=stderr)
after = manifest()
(OUT / f'{gate}-source-after.json').write_text(json.dumps(after, indent=2) + '\n')
events = []
non_json = []
for line in (OUT / f'{gate}.jsonl').read_text().splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        if line.strip():
            non_json.append(line)
test_done = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden')]
counts = {}
for event in test_done:
    key = 'skipped' if event.get('skipped') else event.get('result', 'unknown')
    counts[key] = counts.get(key, 0) + 1
done = [e for e in events if e.get('type') == 'done']
changed = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))
success = process.returncode == 0 and bool(done) and done[-1].get('success') is True and not changed
receipt = {
    'gate': gate,
    'success': success,
    'started_utc': start,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'seconds': round(time.monotonic() - started, 3),
    'exit_code': process.returncode,
    'cwd': str(package),
    'command': command,
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'selected_test_files': len(SELECTION[gate]),
    'source_file_count': len(before),
    'source_changed': changed,
    'counts': counts,
    'done': done,
    'errors': [e for e in events if e.get('type') == 'error'],
    'non_json_output': non_json,
    'logs': {name: sha(OUT / name) for name in (
        f'{gate}.jsonl', f'{gate}.stderr', f'{gate}-source-before.json', f'{gate}-source-after.json'
    )},
}
(OUT / f'{gate}-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(0 if success else 1)
