"""Run explicit local Zotero/host cohorts and retain source-bound JSON evidence."""
from __future__ import annotations

import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/825411e3c403/quds_office_suite')
OUT = Path('/workspace/scratch/825411e3c403/zotero-final-validation')
OUT.mkdir(exist_ok=True)
DART = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/dart-sdk/bin/dart'
TEST = ROOT / '.dart_tool/pub/bin/test/test.dart-3.13.7.snapshot'
CONFIG = ROOT / '.dart_tool/package_config.json'

def emit(value):
    print(json.dumps(value), flush=True)

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()

def fingerprint(tests, package):
    roots = [
        'packages', 'apps', 'third_party', 'tool', 'tools',
        'pubspec.yaml', 'pubspec.lock', '.fvmrc', 'analysis_options.yaml',
    ]
    paths = set(git('ls-files', '-z', '--', *roots).split('\0'))
    paths.discard('')
    paths.update(str(Path(package) / test) for test in tests)
    paths.update(['.dart_tool/package_config.json', '.dart_tool/package_graph.json'])
    result = {}
    for name in sorted(paths):
        path = ROOT / name
        if path.is_file():
            result[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result

def explicit(package, names):
    for name in names:
        assert (ROOT / package / name).is_file(), name
    return names

engine = 'packages/quds_office_engine'
editor = 'packages/quds_office_editor'
studio = editor + '/example'
engine_zotero = sorted(str(p.relative_to(ROOT / engine)) for p in (ROOT / engine / 'test').glob('*zotero*_test.dart'))
editor_zotero = sorted(str(p.relative_to(ROOT / editor)) for p in (ROOT / editor / 'test').glob('*zotero*_test.dart'))
cohorts = {
    'engine-zotero': (engine, 'dart', engine_zotero + explicit(engine, [
        'test/word_inline_picture_test.dart',
        'test/word_list_numbering_snapshot_test.dart',
        'test/numbering_collision_test.dart',
        'test/word_note_numbering_test.dart',
    ])),
    'editor-zotero': (editor, 'flutter', editor_zotero + explicit(editor, [
        'test/word_inline_picture_history_test.dart',
        'test/word_note_numbering_test.dart',
        'test/installed_host_fonts_test.dart',
        'test/office_system_fonts_test.dart',
    ])),
    'studio-host': (studio, 'flutter', explicit(studio, [
        'test/studio_zotero_shortcuts_test.dart',
        'test/studio_zotero_citing_transport_test.dart',
        'test/studio_native_paths_test.dart',
        'test/studio_material_theme_test.dart',
        'test/studio_arabic_morph_web_lifecycle_test.dart',
        'test/studio_mail_ews_test.dart',
        'test/studio_mail_cloud_test.dart',
    ])),
    'mail-workspace': ('packages/quds_mail_ui', 'flutter', [
        'test/message_list_test.dart',
    ]),
    'arabic-lifecycle': ('packages/quds_arabic_morph', 'dart', [
        'test/arabic_morph_lifecycle_test.dart',
        'test/arabic_morph_unit_test.dart',
    ]),
    'spacy-incoming': ('packages/quds_proofing_spacy', 'dart', [
        'test/distribution_test.dart',
        'test/grammar_planner_test.dart',
    ]),
    'engine-pptx': (engine, 'dart', explicit(engine, [
        'test/slide_normal_autofit_test.dart',
        'test/pdf_picture_opacity_test.dart',
        'test/slide_import_fidelity_test.dart',
        'test/slide_render_fidelity_test.dart',
        'test/office_pdf_export_test.dart',
        'test/slide_gradient_merge_test.dart',
        'test/slide_gradient_publication_test.dart',
        'test/slide_picture_background_test.dart',
        'test/slide_geometric_presets_test.dart',
        'test/slide_incoming_pptx_regression_test.dart',
    ])),
    'editor-pptx': (editor, 'flutter', explicit(editor, [
        'test/slide_normal_autofit_test.dart',
        'test/slide_render_fidelity_test.dart',
        'test/slide_incoming_pptx_regression_test.dart',
        'test/slide_transform_orientation_test.dart',
        'test/office_slide_effects_test.dart',
        'test/office_dark_slide_test.dart',
        'test/picture_adjustment_render_test.dart',
        'test/slide_background_publication_test.dart',
        'test/slide_geometric_presets_test.dart',
    ])),
}

selected = sys.argv[1:] or list(cohorts)
for name in selected:
    package, runner, tests = cohorts[name]
    directory = OUT / name
    directory.mkdir(exist_ok=True)
    assert not (directory / 'receipt.json').exists(), 'Use a new output directory for a rerun'
    command = ([str(DART), '--packages=' + str(CONFIG), str(TEST)]
               if runner == 'dart' else ['flutter', 'test', '--no-pub'])
    command += ['--reporter', 'json', '--concurrency', '2', *tests]
    before = fingerprint(tests, package)
    with gzip.open(directory / 'inputs-before.json.gz', 'wt') as handle:
        json.dump(before, handle, sort_keys=True)
    invocation = {
        'source_commit': git('rev-parse', 'HEAD'),
        'source_tree': git('rev-parse', 'HEAD^{tree}'),
        'dirty_paths': git('diff', '--name-only'),
        'package': package, 'command': command, 'test_files': tests,
        'start_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }
    (directory / 'invocation.json').write_text(json.dumps(invocation, indent=2) + '\n')
    emit({'starting': name, 'files': len(tests)})
    cases = {}
    completed = {}
    errors = []
    done = None
    started = time.monotonic()
    with (directory / 'stderr.log').open('w') as stderr, gzip.open(directory / 'events.jsonl.gz', 'wt') as output:
        process = subprocess.Popen(command, cwd=ROOT / package, stdout=subprocess.PIPE,
                                   stderr=stderr, text=True, encoding='utf-8')
        assert process.stdout is not None
        for line in process.stdout:
            output.write(line)
            try:
                event = json.loads(line)
            except ValueError:
                continue
            if event.get('type') == 'testStart':
                cases[event['test']['id']] = event['test']
            elif event.get('type') == 'testDone':
                completed[event['testID']] = event
            elif event.get('type') == 'error':
                errors.append(event)
            elif event.get('type') == 'done':
                done = event
        exit_code = process.wait()
    after = fingerprint(tests, package)
    with gzip.open(directory / 'inputs-after.json.gz', 'wt') as handle:
        json.dump(after, handle, sort_keys=True)
    changed = sorted(path for path in before.keys() | after.keys() if before.get(path) != after.get(path))
    visible = [event for event in completed.values() if not event.get('hidden', False)]
    receipt = {
        **invocation,
        'exit_code': exit_code,
        'seconds': round(time.monotonic() - started, 3),
        'done': done,
        'passed': sum(event['result'] == 'success' and not event.get('skipped', False) for event in visible),
        'failed': sum(event['result'] in ('failure', 'error') for event in visible),
        'skipped': [cases.get(event['testID'], {}).get('name') for event in visible if event.get('skipped', False)],
        'errors': errors,
        'guarded_inputs': len(before),
        'changed_inputs': changed,
        'accepted': exit_code == 0 and done is not None and done.get('success') is True and not errors and not changed,
    }
    (directory / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    (directory / 'cases.json').write_text(json.dumps({'started': cases, 'completed': completed}, indent=2) + '\n')
    emit({key: receipt[key] for key in ['package', 'passed', 'failed', 'skipped', 'seconds', 'accepted', 'changed_inputs']})
    if not receipt['accepted']:
        emit({'errors': errors[:6]})
        sys.exit(1)
