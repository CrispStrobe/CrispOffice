"""Package completed, source-bound receipts without generated runtimes/caches."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

BASE = Path('/workspace/scratch/825411e3c403')
REPO = BASE / 'quds_office_suite'
OUT = BASE / 'zotero-publication-evidence'
OUT.mkdir(exist_ok=True)
SOURCE = '708f2821f5563912642d8062ea4db126462a67a1'
TREE = '447c9f79b2e0cf400ec2c58d7dba18bafab18206'

def read(path):
    return json.loads(path.read_text())

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()

assert git('rev-parse', 'HEAD') == SOURCE
assert git('rev-parse', 'HEAD^{tree}') == TREE
assert not git('status', '--porcelain'), 'Wait for all runners and their temporary directories to finish'

receipts = {}
root_tests = []
for path in sorted((BASE / 'zotero-final-validation').glob('*/receipt.json')):
    value = read(path)
    assert value['accepted'] and value['failed'] == 0 and not value['skipped']
    assert value['source_commit'] == SOURCE and value['source_tree'] == TREE
    assert not value['changed_inputs'] and not value['dirty_paths']
    receipts[path.parent.name] = value
    root_tests += [value['package'] + '/' + test for test in value['test_files']]
assert len(receipts) == 8 and sum(v['passed'] for v in receipts.values()) == 1897
assert len(root_tests) == len(set(root_tests)) == 114
vba_dir = BASE / 'vba-final-validation/attempt-02-serial'
vba = read(vba_dir / 'summary.json')
assert vba['accepted'] and not vba['failures']
assert len(vba['native']['cohorts']) == 8
assert all(c['accepted'] for c in vba['native']['cohorts'])
assert vba['native']['failed'] == vba['native']['skipped'] == vba['native']['errors'] == 0
assert vba['input_check']['head_before'] == vba['input_check']['head_after'] == SOURCE
assert vba['input_check']['all_scoped_inputs_unchanged']
vba_tests = ['packages/quds_office_engine/' + test for test in vba['native']['selected_files']]
assert len(vba_tests) == len(set(vba_tests)) == 37
assert not set(vba_tests) & set(root_tests)
assert [t for c in vba['native']['cohorts'] for t in c['selected_files']] == vba['native']['selected_files']
assert len(vba['smoke_programs']) == 7 and all(s['accepted'] for s in vba['smoke_programs'])
assert vba['canonical_cases_per_runtime'] == 271 and all(c['accepted'] for c in vba['corpora'])
portable = read(BASE / 'zotero-portable-final/receipt.json')
assert portable['accepted'] and portable['source_commit'] == SOURCE and portable['source_tree'] == TREE
static = read(BASE / 'zotero-final-static/summary.json')
assert static['source_guard_passed'] and static['source_commit'] == SOURCE
assert static['analysis']['exit_code'] == static['format']['exit_code'] == 0
assert static['selected_count'] == 106

# Intake is supplied explicitly by the independent audit, not discovered broadly.
intake_source = BASE / 'zotero-intake-audit/intake-coverage.json'
assert intake_source.is_file(), intake_source
intake = read(intake_source)
assert intake['source']['commit'] == SOURCE and intake['source']['tree'] == TREE
assert intake['all_captured_references_covered'] and intake['all_historical_proofs_passed']
assert intake['all_original_and_refreshed_checkpoints_preserve_source_parents']
shutil.copyfile(intake_source, OUT / 'intake.json')

members = {}
def add(path, name):
    assert path.is_file() and not path.is_symlink(), path
    assert name not in members, name
    members[name] = path.read_bytes()

def directory(path, name, exclusions=()):
    for item in sorted(path.rglob('*')):
        relative = item.relative_to(path)
        if not item.is_file() or any(part in exclusions for part in relative.parts):
            continue
        add(item, name + '/' + relative.as_posix())

directory(BASE / 'zotero-final-validation', 'root-cohorts')
directory(BASE / 'zotero-final-static', 'static')
directory(BASE / 'zotero-intake-audit', 'intake')
add(BASE / 'zotero-checkpoints.json', 'intake/checkpoints.json')
directory(vba_dir, 'vba/attempt-02-serial', ('build', 'tmp', '__pycache__'))
directory(BASE / 'vba-final-validation/attempt-01-infrastructure-failure',
          'vba/attempt-01-infrastructure-failure', ('build', 'tmp', '__pycache__'))
for name in ['run_final.py', 'run_final_serial.py', 'selection.json', 'reference-run_validation.py']:
    add(BASE / 'vba-final-validation' / name, 'vba/' + name)
for path in sorted((BASE / 'zotero-portable-final').iterdir()):
    if path.is_file() and path.name not in ('image-note.js', 'image-note.js.deps', 'image-note.js.map'):
        add(path, 'image-and-worker-portable/' + path.name)
for name in ['run_zotero_validation.py', 'run_zotero_portable.py', 'package_zotero_evidence.py']:
    add(BASE / name, 'runners/' + name)
for name in ['runtime-ready.json', 'runtime-receipt.json', 'runtime-omissions.json',
             'material-fonts-receipt.json', 'prefetch-128.json', 'prefetch-101.json', 'env.sh']:
    add(BASE / 'zotero-toolchain' / name, 'runtime/' + name)
for path in sorted(BASE.glob('zotero-list-editor-development*')):
    if path.is_file():
        add(path, 'development/' + path.name)
for path in sorted((BASE / 'zotero-toolchain').glob('image-ownership-final-*')):
    if path.is_file():
        add(path, 'development/' + path.name)
if (BASE / 'zotero-autofit-checks').is_dir():
    directory(BASE / 'zotero-autofit-checks', 'development/superseded-autofit')

archive = OUT / 'local-validation.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w|') as tar:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            tar.addfile(info, io.BytesIO(data))
archive_sha = sha(archive.read_bytes())
index = {'schema': 1, 'archive': archive.name, 'archive_sha256': archive_sha,
         'archive_bytes': archive.stat().st_size,
         'members': [{'path': name, 'bytes': len(data), 'sha256': sha(data)}
                     for name, data in sorted(members.items())]}
(OUT / 'local-validation-index.json').write_text(json.dumps(index, indent=2) + '\n')

qualification = {
    'schema': 1, 'accepted': True, 'source_commit': SOURCE, 'source_tree': TREE,
    'captured_main': '5e38de19ab5af8d6811d601c7317cba7f69d516b',
    'checkpoint_branch': 'codex/zotero-parity-continuation-20261120',
    'test_file_count': 151, 'test_selections_disjoint': True,
    'visible_passed': 1897 + vba['native']['passed'], 'failed': 0, 'skipped': 0,
    'root_visible_passed': 1897,
    'root_cohorts': {name: {k: v[k] for k in ['package', 'test_files', 'passed', 'failed',
                                            'skipped', 'seconds', 'guarded_inputs', 'accepted']}
                     for name, v in receipts.items()},
    'vba': {k: vba[k] for k in ['accepted', 'native', 'input_check', 'smoke_programs', 'corpora',
                              'canonical_cases_per_runtime', 'limitations']},
    'image_and_worker_portable': portable,
    'static': {k: static[k] for k in ['selected_count', 'guarded_file_count',
                                    'source_guard_passed', 'head_unchanged', 'tree_unchanged',
                                    'worktree_clean', 'changed_guarded_files', 'added_guarded_files']},
    'evidence_archive': {'path': archive.name, 'sha256': archive_sha, 'bytes': archive.stat().st_size},
    'limits': ['No new live Zotero, Microsoft Word, LibreOffice or Apache OpenOffice acceptance.',
               'No native release application build or native Mail migration executed.',
               'Node JavaScript is not browser UI acceptance.',
               'Arabic worker uses the real protocol and transfers with a controlled Wasm API.',
               'No native spaCy model acceptance executed.',
               'No active ODT document-transfer qualification.',
               'Only the bounded captured incoming snapshot is included.',
               'GitHub Actions, checks, statuses and workflow runs were neither queried nor awaited.'],
}
(OUT / 'qualification.json').write_text(json.dumps(qualification, indent=2) + '\n')
with tarfile.open(archive, 'r:gz') as tar:
    actual = {}
    for entry in tar:
        data = tar.extractfile(entry).read()
        actual[entry.name] = sha(data)
    assert actual == {name: sha(data) for name, data in members.items()}
print(json.dumps({'files': len(members), 'archive_bytes': archive.stat().st_size,
                  'archive_sha256': archive_sha, 'test_passed': qualification['visible_passed'],
                  'test_files': 151, 'source_commit': SOURCE}))
