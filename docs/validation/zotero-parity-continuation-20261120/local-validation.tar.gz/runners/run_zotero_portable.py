"""Fresh VM/JavaScript image-note replay and controlled real-worker protocol."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/workspace/scratch/825411e3c403/quds_office_suite')
OUT = Path('/workspace/scratch/825411e3c403/zotero-portable-final')
OUT.mkdir(exist_ok=True)
DART = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/dart-sdk/bin/dart'
CONFIG = ROOT / '.dart_tool/package_config.json'
SMOKE = ROOT / 'packages/quds_office_engine/tool/zotero/image_note_portable_smoke.dart'

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()

def inputs():
    paths = git('ls-files', '-z', '--', 'packages/quds_office_engine/lib',
                'packages/quds_office_engine/tool/zotero',
                'packages/quds_arabic_morph/web/arabic_morph_worker.mjs',
                'packages/quds_arabic_morph/tool/worker_lifecycle_test.mjs',
                'pubspec.yaml', 'pubspec.lock', '.fvmrc').split('\0')
    paths += ['.dart_tool/package_config.json', '.dart_tool/package_graph.json']
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest()
            for p in sorted(set(paths)) if p and (ROOT / p).is_file()}

before = inputs()
commands = []
def run(name, command):
    start = time.monotonic()
    with (OUT / (name + '.stdout')).open('w') as stdout, (OUT / (name + '.stderr')).open('w') as stderr:
        result = subprocess.run([str(p) for p in command], cwd=ROOT, stdout=stdout, stderr=stderr)
    record = {'name': name, 'command': [str(p) for p in command],
              'exit_code': result.returncode, 'seconds': round(time.monotonic() - start, 3)}
    commands.append(record)
    print(json.dumps(record), flush=True)
    (OUT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert result.returncode == 0, name

assert not (OUT / 'receipt.json').exists(), 'Do not overwrite a completed run'
(OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
source = {'source_commit': git('rev-parse', 'HEAD'), 'source_tree': git('rev-parse', 'HEAD^{tree}'),
          'dirty_paths': git('diff', '--name-only'),
          'start_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
(OUT / 'invocation.json').write_text(json.dumps(source, indent=2) + '\n')
run('image-vm', [DART, '--packages=' + str(CONFIG), SMOKE])
run('image-compile', [DART, 'compile', 'js', '--packages=' + str(CONFIG), '-O2', '-o', OUT / 'image-note.js', SMOKE])
run('image-js', ['node', OUT / 'image-note.js'])
run('arabic-worker', ['node', ROOT / 'packages/quds_arabic_morph/tool/worker_lifecycle_test.mjs'])
vm = json.loads((OUT / 'image-vm.stdout').read_text())
js = json.loads((OUT / 'image-js.stdout').read_text())
worker = json.loads((OUT / 'arabic-worker.stdout').read_text())
after = inputs()
(OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
changed = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
receipt = {**source, 'commands': commands, 'image_behavior_count': vm['behavior_count'],
           'image_vm_passed': vm['passed'], 'image_js_passed': js['passed'],
           'image_vm_js_identical': vm == js,
           'compiled_js_sha256': hashlib.sha256((OUT / 'image-note.js').read_bytes()).hexdigest(),
           'arabic_worker_controls': len(worker['controls']), 'arabic_worker_scope': worker['scope'],
           'guarded_inputs': len(before), 'changed_inputs': changed,
           'accepted': not changed and vm == js and vm['passed'] == vm['behavior_count'] and worker['accepted']}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
assert receipt['accepted']
