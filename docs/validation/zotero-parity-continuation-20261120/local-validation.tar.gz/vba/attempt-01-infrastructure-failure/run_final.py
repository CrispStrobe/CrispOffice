#!/usr/bin/env python3
"""Source-scoped local VBA qualification; never invokes pub or hosted CI."""
from __future__ import annotations

import base64
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
SDK = ROOT.parent / 'zotero-toolchain/flutter'
DART = SDK / 'bin/cache/dart-sdk/bin/dart'
NODE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')
CONFIG = REPO / '.dart_tool/package_config.json'
SNAPSHOT = REPO / '.dart_tool/pub/bin/test/test.dart-3.13.7.snapshot'
SELECTION = json.loads((ROOT / 'selection.json').read_text())['cohort']['tests']
SMOKES = (
    'web_smoke', 'web_vba_smoke', 'web_vba_procedures_smoke',
    'web_vba_control_flow_smoke', 'web_vba_arrays_smoke',
    'web_vba_dynamic_arrays_smoke', 'web_vba_word_smoke',
)
CORPORA = {
    'string_intrinsics_v1': 69,
    'variant_conversions_v1': 120,
    'variant_composition_v1': 38,
    'word_paragraphs_v1': 44,
}
EXCEL_RECEIPTS = {
    'string_intrinsics_v1': '8703d19a7f50f9dceab688ba49bb657fbc29f34c6eea277807be157ac1f42dbd',
    'variant_conversions_v1': '0ccceebcb1bac7707fa7ba4756f48e29323a03b6840c26e78f054402b11e35bc',
    'variant_composition_v1': '80c295dbff1477d79dd4e1706159ea502ca4c07b26476e00d14e7d0e8d3c4858',
}


def digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path: Path, data: object) -> None:
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def stamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def inputs() -> dict[str, object]:
    """Track the relevant core and engine dependencies separately from history."""
    primary = set((ENGINE / 'lib/src/automation').rglob('*.dart'))
    primary.update((ENGINE / 'lib/src/word/properties').rglob('*.dart'))
    primary.update((
        ENGINE / 'lib/quds_office_automation.dart',
        ENGINE / 'lib/src/word/serial/word_property_io.dart',
    ))
    dependencies = set((ENGINE / 'lib').rglob('*.dart')) - primary
    checks = {ENGINE / test for test in SELECTION}
    checks.update((ENGINE / 'test/support').rglob('*.dart'))
    checks.update((ENGINE / 'test/fixtures/vba_conformance').glob('*.json'))
    checks.update((ENGINE / 'tool/macros').rglob('*.dart'))
    checks.update((ENGINE / 'example/macros').rglob('*'))
    config = {
        REPO / '.fvmrc', REPO / 'pubspec.yaml', REPO / 'pubspec.lock',
        ENGINE / 'pubspec.yaml', CONFIG, SNAPSHOT,
    }
    result: dict[str, object] = {}
    for group, paths in (
        ('vba_automation_word_properties', primary),
        ('other_engine_library_dependencies', dependencies),
        ('tests_fixtures_macro_tools', checks),
        ('runtime_configuration', config),
    ):
        result[group] = {
            str(path.relative_to(REPO)): {
                'sha256': digest(path), 'bytes': path.stat().st_size,
            }
            for path in sorted(paths) if path.is_file()
        }
    return result


def manifest(path: Path, value: object) -> str:
    data = json.dumps(value, sort_keys=True, separators=(',', ':')).encode()
    path.write_bytes(gzip.compress(data, mtime=0))
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    if (ROOT / 'summary.json').exists() or (ROOT / 'commands.json').exists():
        raise SystemExit('This captured run already exists; retain it unchanged.')
    for path in (DART, NODE, CONFIG, SNAPSHOT):
        if not path.is_file():
            raise SystemExit(f'Missing prepared runtime: {path}')
    logs, build, temp = ROOT / 'logs', ROOT / 'build', ROOT / 'tmp'
    for path in (logs, build, temp):
        path.mkdir(exist_ok=True)
    env = dict(os.environ, FLUTTER_ROOT=str(SDK), TMPDIR=str(temp), CI='true',
               PUB_CACHE=str(ROOT.parent / 'zotero-toolchain/pub-cache'),
               FLUTTER_SUPPRESS_ANALYTICS='true', DART_SUPPRESS_ANALYTICS='true',
               DASH__SUPPRESS_ANALYTICS='true')
    env['PATH'] = os.pathsep.join((str(DART.parent), str(SDK / 'bin'), env.get('PATH', '')))
    before = inputs()
    before_sha = manifest(ROOT / 'inputs-before.json.gz', before)
    head_before = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    commands: list[dict[str, object]] = []
    smoke_results: list[dict[str, object]] = []
    corpus_results: list[dict[str, object]] = []
    failures: list[str] = []
    native: dict[str, object] = {}

    def run(name: str, command: list[str], timeout: int = 900) -> tuple[int | str, Path]:
        stdout_path, stderr_path = logs / f'{name}.stdout', logs / f'{name}.stderr'
        record: dict[str, object] = {
            'name': name, 'command': command, 'cwd': str(ENGINE),
            'started_at': stamp(), 'source_head_observed': head_before,
            'input_manifest_sha256': before_sha,
            'stdout': str(stdout_path.relative_to(ROOT)),
            'stderr': str(stderr_path.relative_to(ROOT)),
        }
        write_json(logs / f'{name}.command.json', record)
        print(json.dumps({'started': name}), flush=True)
        start = time.monotonic()
        with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
            try:
                result = subprocess.run(command, cwd=ENGINE, env=env, stdout=stdout,
                                        stderr=stderr, timeout=timeout)
                code: int | str = result.returncode
            except subprocess.TimeoutExpired:
                code = 'timeout'
            except OSError as error:
                code = 'spawn-error'
                record['error'] = str(error)
        record.update(exit_code=code, finished_at=stamp(), seconds=time.monotonic() - start,
                      stdout_sha256=digest(stdout_path), stderr_sha256=digest(stderr_path))
        commands.append(record)
        write_json(logs / f'{name}.command.json', record)
        write_json(ROOT / 'commands.json', commands)
        print(json.dumps({'finished': name, 'exit_code': code}), flush=True)
        return code, stdout_path

    def require(name: str, command: list[str]) -> Path:
        code, output = run(name, command)
        if code != 0:
            raise RuntimeError(f'{name} failed: {code}')
        return output

    def compile_js(name: str, source: Path, defines: list[str]) -> Path:
        target = build / f'{name}.js'
        require(f'{name}-compile', [str(DART), 'compile', 'js', '-O1',
                                   f'--packages={CONFIG}', *defines, str(source), '-o', str(target)])
        return target

    def execute_js(name: str, target: Path) -> Path:
        return require(f'{name}-js', [str(NODE), '-e',
                                      'globalThis.self=globalThis; require(process.argv[1]);', str(target)])

    try:
        dart_version = require('dart-version', [str(DART), '--version'])
        node_version = require('node-version', [str(NODE), '--version'])
        write_json(ROOT / 'runtime.json', {
            'dart': str(DART), 'dart_sha256': digest(DART),
            'node': str(NODE), 'node_sha256': digest(NODE),
            'dart_version': dart_version.read_text(), 'node_version': node_version.read_text(),
            'python': sys.version, 'runner_sha256': digest(Path(__file__)),
        })
        code, raw = run('native-37-files', [str(DART), f'--packages={CONFIG}', str(SNAPSHOT),
                        '--reporter', 'json', '--concurrency', '1', '--timeout', '4x',
                        '--no-chain-stack-traces', *SELECTION], timeout=1800)
        spec = importlib.util.spec_from_file_location('reference_validation', ROOT / 'reference-run_validation.py')
        assert spec is not None and spec.loader is not None
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        native = module.summarize_events(raw)
        write_json(ROOT / 'native-cases.json', native.pop('cases'))
        native.update(exit_code=code, selected_files=SELECTION,
                      accepted=(code == 0 and native['runner_success'] and native['passed'] > 0
                                and native['failed'] == native['errors'] == native['skipped'] == 0))
        write_json(ROOT / 'native-summary.json', native)
        print(json.dumps({'native': {key: native[key] for key in ('passed', 'failed', 'errors', 'skipped', 'accepted')}}), flush=True)
        if not native['accepted']:
            failures.append('Native regression selection did not pass completely.')
        for name in SMOKES:
            try:
                target = compile_js(name, ENGINE / 'tool/macros' / f'{name}.dart', [])
                output = execute_js(name, target)
                smoke_results.append({'name': name, 'accepted': True,
                                      'javascript_sha256': digest(target), 'stdout_sha256': digest(output)})
            except Exception as error:
                failures.append(f'{name}: {error}')
                smoke_results.append({'name': name, 'accepted': False, 'error': str(error)})
        for name, count in CORPORA.items():
            try:
                fixture = ENGINE / 'test/fixtures/vba_conformance' / f'{name}.json'
                raw = fixture.read_bytes()
                suite = json.loads(raw)
                if len(suite['cases']) != count:
                    raise RuntimeError(f'Expected exactly {count} canonical cases.')
                define = '-DVBA_CONFORMANCE_BASE64=' + base64.b64encode(raw).decode('ascii')
                source = ENGINE / 'tool/macros/web_vba_conformance.dart'
                vm = require(f'{name}-vm', [str(DART), f'--packages={CONFIG}', define, str(source)])
                target = compile_js(name, source, [define])
                js = execute_js(name, target)
                if vm.read_bytes() != js.read_bytes():
                    raise RuntimeError('VM and JavaScript receipts differ.')
                baseline = EXCEL_RECEIPTS.get(name)
                if baseline is not None and digest(vm) != baseline:
                    raise RuntimeError('Original accepted Excel receipt hash changed.')
                receipt = json.loads(vm.read_bytes())
                if (receipt.get('suite') != suite['suite'] or receipt.get('caseCount') != count
                        or [case['id'] for case in receipt['cases']] != [case['id'] for case in suite['cases']]):
                    raise RuntimeError('Receipt does not cover the exact canonical suite.')
                corpus_results.append({'name': name, 'case_count': count, 'accepted': True,
                                       'fixture_sha256': digest(fixture), 'receipt_sha256': digest(vm),
                                       'javascript_sha256': digest(target), 'receipts_byte_identical': True,
                                       'original_excel_receipt_sha256': baseline})
            except Exception as error:
                failures.append(f'{name}: {error}')
                corpus_results.append({'name': name, 'accepted': False, 'error': str(error)})
    except Exception as error:
        failures.append(f'{type(error).__name__}: {error}')
    finally:
        after = inputs()
        after_sha = manifest(ROOT / 'inputs-after.json.gz', after)
        groups = {}
        for group in before:
            old, new = before[group], after[group]
            changed = [path for path in sorted(old.keys() | new.keys()) if old.get(path) != new.get(path)]
            groups[group] = {'file_count_before': len(old), 'unchanged': not changed, 'changed': changed}
        head_after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
        check = {'groups': groups, 'all_scoped_inputs_unchanged': all(g['unchanged'] for g in groups.values()),
                 'before_manifest_sha256': before_sha, 'after_manifest_sha256': after_sha,
                 'head_before': head_before, 'head_after': head_after,
                 'scope_note': 'Only the enumerated primary product, engine dependencies, tests/tools/fixtures and runtime configuration are guarded. No whole-repository stability claim.'}
        write_json(ROOT / 'input-check.json', check)
        accepted = (not failures and check['all_scoped_inputs_unchanged'] and native.get('accepted')
                    and len(smoke_results) == len(SMOKES) and len(corpus_results) == len(CORPORA))
        summary = {'accepted': bool(accepted), 'input_check': check, 'native': native,
                   'smoke_programs': smoke_results, 'corpora': corpus_results, 'failures': failures,
                   'canonical_cases_per_runtime': sum(r.get('case_count', 0) for r in corpus_results if r['accepted']),
                   'no_pub_or_hosted_ci_commands': True,
                   'limitations': ['No installed Microsoft Office host executed.',
                                   'JavaScript executes under Node, not a browser UI.',
                                   'Fixtures are specification-derived or intentional dialect contracts.',
                                   'Mail, native spaCy, Zotero Desktop and platform deployment were not exercised.']}
        write_json(ROOT / 'summary.json', summary)
        print(json.dumps({'accepted': bool(accepted), 'native_passed': native.get('passed'),
                          'smokes_passed': sum(r['accepted'] for r in smoke_results),
                          'canonical_cases_per_runtime': summary['canonical_cases_per_runtime'],
                          'failures': failures, 'source_check': groups}), flush=True)
    raise SystemExit(0 if accepted else 1)


if __name__ == '__main__':
    main()
