import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/825411e3c403/quds_office_suite')
OUT = Path('/workspace/scratch/825411e3c403/zotero-final-static')
DART = Path('/workspace/scratch/825411e3c403/zotero-toolchain/flutter/bin/cache/dart-sdk/bin/dart')
BASE_COMMIT = '5e38de19ab5af8d6811d601c7317cba7f69d516b'
EXPECTED_HEAD = '708f2821f5563912642d8062ea4db126462a67a1'
EXPECTED_TREE = '447c9f79b2e0cf400ec2c58d7dba18bafab18206'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=BASE).decode()

def save(name, data):
    (OUT/name).write_text(json.dumps(data, indent=2)+'\n')

def snapshot():
    tracked = git('ls-files','-z').split('\0')
    relevant = [p for p in tracked if p and (p.endswith('.dart') or Path(p).name in {'pubspec.yaml','pubspec.lock','analysis_options.yaml'})]
    config = '.dart_tool/package_config.json'
    if (BASE/config).exists(): relevant.append(config)
    hashes = {p: hashlib.sha256((BASE/p).read_bytes()).hexdigest() for p in sorted(set(relevant)) if (BASE/p).is_file()}
    return {'head':git('rev-parse','HEAD').strip(),'tree':git('rev-parse','HEAD^{tree}').strip(),'status':git('status','--porcelain'), 'sha256':hashes}

mode = sys.argv[1]
if mode == 'prepare':
    changed = sorted(p for p in git('diff','--name-only','--diff-filter=ACMR',BASE_COMMIT,'HEAD','--','*.dart').splitlines() if p)
    excluded = [p for p in changed if p.startswith('docs/validation/')]
    selected = [p for p in changed if p not in excluded]
    before = snapshot()
    assert before['head'] == EXPECTED_HEAD and before['tree'] == EXPECTED_TREE and before['status'] == '', before
    save('before.json',before)
    save('selection.json',{'base_commit':BASE_COMMIT,'expected_head':EXPECTED_HEAD,'expected_tree':EXPECTED_TREE,'selection_command':['git','diff','--name-only','--diff-filter=ACMR',BASE_COMMIT,'HEAD','--','*.dart'],'excluded':excluded,'exclusion_reason':'Archived validation fixtures are historical evidence, not active analyzer inputs.','selected':selected})
    (OUT/'selected-paths.txt').write_text('\n'.join(selected)+'\n')
    print(json.dumps({'selected_count':len(selected),'excluded_count':len(excluded),'guarded_files':len(before['sha256']),'head':before['head']}))
elif mode in {'analysis','format'}:
    paths=json.loads((OUT/'selection.json').read_text())['selected']
    args=([str(DART),'analyze','--fatal-infos','--fatal-warnings'] if mode == 'analysis' else [str(DART),'format','--output=none','--set-exit-if-changed']) + paths
    started=time.time()
    env=dict(os.environ)
    env.update({'DASH__SUPPRESS_ANALYTICS':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','CI':'true'})
    with (OUT/(mode+'.stdout')).open('w') as stdout, (OUT/(mode+'.stderr')).open('w') as stderr:
        result=subprocess.run(args,cwd=BASE,env=env,stdout=stdout,stderr=stderr)
    record={'command':args,'cwd':str(BASE),'started_unix':started,'ended_unix':time.time(),'exit_code':result.returncode,'stdout':mode+'.stdout','stderr':mode+'.stderr'}
    save(mode+'.result.json',record)
    print(json.dumps({'check':mode,'exit_code':result.returncode,'elapsed_seconds':record['ended_unix']-started}))
else:
    before=json.loads((OUT/'before.json').read_text())
    after=snapshot()
    save('after.json',after)
    changed=[p for p,h in before['sha256'].items() if after['sha256'].get(p)!=h]
    added=sorted(set(after['sha256'])-set(before['sha256']))
    summary={'source_commit':EXPECTED_HEAD,'source_tree':EXPECTED_TREE,'base_commit':BASE_COMMIT,'selected_count':len(json.loads((OUT/'selection.json').read_text())['selected']),'guarded_file_count':len(before['sha256']),'head_unchanged':before['head']==after['head'],'tree_unchanged':before['tree']==after['tree'],'worktree_clean':after['status']=='','changed_guarded_files':changed,'added_guarded_files':added,'analysis':json.loads((OUT/'analysis.result.json').read_text()),'format':json.loads((OUT/'format.result.json').read_text())}
    summary['source_guard_passed']=summary['head_unchanged'] and summary['tree_unchanged'] and summary['worktree_clean'] and not changed and not added
    save('summary.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if k not in {'analysis','format'}}))
