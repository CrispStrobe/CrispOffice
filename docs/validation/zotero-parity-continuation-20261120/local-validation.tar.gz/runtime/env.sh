export PATH="/workspace/scratch/825411e3c403/zotero-toolchain/flutter/bin:$PATH"
export PUB_CACHE="/workspace/scratch/825411e3c403/zotero-toolchain/pub-cache"
export FLUTTER_ROOT="/workspace/scratch/825411e3c403/zotero-toolchain/flutter"
export TMPDIR="/workspace/scratch/825411e3c403/zotero-toolchain/tmp"
export DASH__SUPPRESS_ANALYTICS=true
export FLUTTER_SUPPRESS_ANALYTICS=true
export CI=true
