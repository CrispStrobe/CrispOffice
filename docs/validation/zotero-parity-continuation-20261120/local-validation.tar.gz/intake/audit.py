#!/usr/bin/env python3
"""Read-only intake audit of the fixed Zotero continuation source."""

from __future__ import annotations

import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


REPO = Path('/workspace/scratch/825411e3c403/quds_office_suite')
OUT = Path(__file__).resolve().parent
TARGET = '708f2821f5563912642d8062ea4db126462a67a1'
EXPECTED_TREE = '447c9f79b2e0cf400ec2c58d7dba18bafab18206'
CAPTURED_MAIN = '5e38de19ab5af8d6811d601c7317cba7f69d516b'
CONTINUATION = 'refs/remotes/origin/codex/zotero-parity-continuation-20261120'
PRIOR_PATH = 'docs/validation/crispoffice-gui-20261119/reconciliation-final.json'
README_PATH = 'docs/validation/zotero-parity-continuation-20261120/README.md'
ENV = {**os.environ, 'GIT_NO_LAZY_FETCH': '1', 'GIT_OPTIONAL_LOCKS': '0'}


def run(*args: str, input_bytes: bytes | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(
        ['git', *args], cwd=REPO, env=ENV, input=input_bytes,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60,
    )


def git(*args: str) -> bytes:
    result = run(*args)
    if result.returncode:
        raise RuntimeError(f'git {args}: {result.stderr.decode(errors="replace")}')
    return result.stdout


def text(*args: str) -> str:
    return git(*args).decode().strip()


def oid(ref: str) -> str:
    return text('rev-parse', '--verify', ref)


def ancestor(head: str, target: str = TARGET) -> bool:
    result = run('merge-base', '--is-ancestor', head, target)
    if result.returncode not in (0, 1):
        raise RuntimeError(result.stderr.decode(errors='replace'))
    return result.returncode == 0


def tree_entries(ref: str, paths: list[str]) -> dict[str, tuple[str, str, str]]:
    result = {}
    if not paths:
        return result
    for entry in git('ls-tree', '-r', '-z', '--full-tree', ref, '--', *paths).split(b'\0'):
        if not entry:
            continue
        meta, name = entry.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        result[name.decode()] = (mode, kind, blob)
    return result


def canonical_hash(entries: list) -> str:
    return hashlib.sha256(json.dumps(entries, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()


started = datetime.datetime.now(datetime.timezone.utc).isoformat()
status_before = text('status', '--porcelain=v1')
tracked_status_before = text('status', '--porcelain=v1', '--untracked-files=no')
head_before = oid('HEAD')
prior_bytes = git('show', f'{TARGET}:{PRIOR_PATH}')
prior = json.loads(prior_bytes)
proofs = []


def verify_equivalence(original: str, accepted: str, source: str, expected_count: int) -> dict:
    original = oid(original)
    accepted = oid(accepted)
    bases = text('merge-base', '--all', original, accepted).splitlines()
    if len(bases) != 1:
        raise RuntimeError(f'Ambiguous equivalence base: {original} {accepted}: {bases}')
    paths = sorted(p.decode() for p in git('diff', '--no-renames', '--name-only', '-z', bases[0], original).split(b'\0') if p)
    original_entries = tree_entries(original, paths)
    accepted_entries = tree_entries(accepted, paths)
    original_values = [(p, original_entries.get(p)) for p in paths]
    accepted_values = [(p, accepted_entries.get(p)) for p in paths]
    mismatches = [p for p in paths if original_entries.get(p) != accepted_entries.get(p)]
    original_tree = oid(f'{original}^{{tree}}')
    accepted_tree = oid(f'{accepted}^{{tree}}')
    accepted_ancestor = ancestor(accepted)
    result = {
        'original': original,
        'accepted_ancestor': accepted,
        'claim_source': source,
        'common_base': bases[0],
        'complete_original_delta_paths': len(paths),
        'expected_path_count': expected_count,
        'path_count_matches': len(paths) == expected_count,
        'method': 'exact_complete_delta_path_mode_type_blob_identity',
        'original_tree': original_tree,
        'accepted_tree': accepted_tree,
        'complete_tree_identity': original_tree == accepted_tree,
        'original_path_entries_sha256': canonical_hash(original_values),
        'accepted_path_entries_sha256': canonical_hash(accepted_values),
        'accepted_is_ancestor_of_target': accepted_ancestor,
        'mismatches': mismatches,
        'passed': accepted_ancestor and not mismatches and len(paths) == expected_count,
    }
    proofs.append(result)
    return result


prior_proofs = {}
for proof in prior['historical_proofs']:
    result = verify_equivalence(proof['original'], proof['equivalent'], PRIOR_PATH, proof['complete_original_delta_paths'])
    prior_proofs[result['original']] = result

readme_claims = [
    ('c3494576', '2c47165d', 37), ('3abf8f43', '4b2b4e78', 221),
    ('58fdddfb', '4eaca83b', 1), ('69d14f84', '52c73ae4', 1),
    ('74ce9ffb', '4584d5f3', 7), ('0a53b8a7', 'b3f41eb4', 8),
    ('68a0db23', 'd754bf15', 4), ('005c708e', 'c84d5e16', 7),
    ('7ef09f24', '34dc6b68', 7),
]
readme_results = []
for original, accepted, count in readme_claims:
    pair = (oid(original), oid(accepted))
    existing = next((p for p in proofs if (p['original'], p['accepted_ancestor']) == pair), None)
    if existing:
        readme_results.append({'original': pair[0], 'accepted_ancestor': pair[1], 'paths': count, 'passed': existing['passed'] and count == existing['complete_original_delta_paths']})
    else:
        checked = verify_equivalence(original, accepted, README_PATH, count)
        readme_results.append({'original': pair[0], 'accepted_ancestor': pair[1], 'paths': count, 'passed': checked['passed']})

references = []
self_reference = None
for line in text('for-each-ref', '--format=%(refname) %(objectname)', 'refs/remotes').splitlines():
    ref, commit = line.split()
    if ref.endswith('/HEAD'):
        continue
    if ref == CONTINUATION:
        self_reference = {'ref': ref, 'head': commit, 'matches_target': commit == TARGET}
        continue
    if ref.startswith('refs/remotes/origin/'):
        group = 'fork_branches'
    elif ref.startswith('refs/remotes/pull/'):
        group = 'pull_request_heads'
    elif ref.startswith('refs/remotes/upstream/'):
        group = 'upstream_branches'
    else:
        continue
    is_ancestor = ancestor(commit)
    proof = prior_proofs.get(commit)
    disposition = 'ancestor' if is_ancestor else 'historical_equivalent' if proof and proof['passed'] else 'uncovered'
    row = {'group': group, 'ref': ref, 'head': commit, 'disposition': disposition}
    if disposition == 'historical_equivalent':
        row['accepted_ancestor'] = proof['accepted_ancestor']
    references.append(row)

captured = [
    ('saved Zotero image source', '3100725d', 'd6ec077b'),
    ('captured main', '5e38de19', 'd6ec077b'),
    ('VBA / Word / font / background source', '1fe093a2', 'ef09cc41'),
    ('CrispOffice rename', 'afc3524e', '6c6413b3'),
    ('original Android grammar', 'fa8b71b0', '6adf829a'),
    ('original PPTX autofit', '0e1d6d8c', 'a27df5d1'),
    ('refreshed Android grammar workflow', '7ac3d3be', '3eb59a8b'),
    ('refreshed radial PDF source', '20573cab', 'a4ed68f2'),
    ('new Mail workspace source', '6fea99ed', '708f2821'),
]
incoming_checkpoints = []
for name, source, checkpoint in captured:
    source = oid(source)
    checkpoint = oid(checkpoint)
    parents = text('show', '-s', '--format=%P', checkpoint).split()
    incoming_checkpoints.append({
        'name': name, 'source': source, 'integration_checkpoint': checkpoint,
        'source_is_direct_checkpoint_parent': source in parents,
        'source_is_ancestor_of_target': ancestor(source),
        'checkpoint_is_ancestor_of_target': ancestor(checkpoint),
    })

preexisting_names = [
    'origin/codex/zotero-research-materials-20261120',
    'origin/work/mail-attachments-20261120',
    'origin/work/mail-draft-recovery-20261120',
    'origin/ci/android-spacy-grammar-workflow',
]
preexisting = [
    {'ref': name, 'head': oid(name), 'ancestor_of_captured_main': ancestor(oid(name), CAPTURED_MAIN)}
    for name in preexisting_names
]

changed = sorted(p.decode() for p in git('diff', '--no-renames', '--name-only', '-z', CAPTURED_MAIN, TARGET).split(b'\0') if p)
entries = tree_entries(TARGET, changed)
blob_ids = sorted({entry[2] for entry in entries.values() if entry[1] == 'blob'})
size_result = run('cat-file', '--batch-check=%(objectname) %(objecttype) %(objectsize)', input_bytes=('\n'.join(blob_ids) + '\n').encode())
if size_result.returncode:
    raise RuntimeError(size_result.stderr.decode(errors='replace'))
sizes = {}
missing_sizes = []
for line in size_result.stdout.decode().splitlines():
    parts = line.split()
    if len(parts) == 3 and parts[1] == 'blob':
        sizes[parts[0]] = int(parts[2])
    else:
        missing_sizes.append(line)

large = sorted([
    {'path': path, 'bytes': sizes[entry[2]], 'blob': entry[2]}
    for path, entry in entries.items()
    if entry[2] in sizes and sizes[entry[2]] >= 1024 * 1024
], key=lambda row: -row['bytes'])
suspicious_paths = [p for p in changed if re.search(r'(^|/)(\.dart_tool|\.pub-cache|node_modules|build)/|\.(dill|so|a|snapshot|tar\.xz|part)$', p)]
marker_matches = []
scanned = 0
for path, entry in entries.items():
    if entry[1] != 'blob' or entry[2] not in sizes or sizes[entry[2]] > 2 * 1024 * 1024:
        continue
    contents = git('cat-file', 'blob', entry[2])
    if b'\x00' in contents:
        continue
    scanned += 1
    for number, line in enumerate(contents.decode(errors='replace').splitlines(), 1):
        if re.match(r'^(<<<<<<< |>>>>>>> )', line):
            marker_matches.append({'path': path, 'line': number, 'marker': line[:160]})

check = run('diff', '--no-ext-diff', '--no-textconv', '--no-renames', '--check', CAPTURED_MAIN, TARGET)
product_check = run('diff', '--no-ext-diff', '--no-textconv', '--no-renames', '--check', CAPTURED_MAIN, TARGET, '--', '.', ':(exclude)docs/validation/**')
diagnostics = (check.stdout + check.stderr).decode(errors='replace')
whitespace_locations = re.findall(r'^(.+):(\d+): trailing whitespace\.$', diagnostics, re.MULTILINE)
whitespace_evidence = []
for path in sorted({path for path, _ in whitespace_locations}):
    current_blob = oid(f'{TARGET}:{path}')
    saved_blob = oid(f'3100725d:{path}')
    lines_at_path = git('cat-file', 'blob', current_blob).decode().splitlines()
    numbers = [int(number) for p, number in whitespace_locations if p == path]
    whitespace_evidence.append({
        'path': path,
        'diagnostic_count': len(numbers),
        'all_flagged_lines_are_required_blank_patch_context_prefix': all(lines_at_path[number - 1] == ' ' for number in numbers),
        'unchanged_from_saved_image_head_3100725d': current_blob == saved_blob,
        'blob': current_blob,
    })
large_file_provenance = []
for row in large:
    saved = oid(f'3100725d:{row["path"]}')
    large_file_provenance.append({
        **row,
        'saved_image_source_blob': saved,
        'unchanged_from_saved_image_head_3100725d': saved == row['blob'],
        'purpose': 'Preserved incoming qualification/intake evidence archive',
    })
counts = {}
for group in ('fork_branches', 'pull_request_heads', 'upstream_branches'):
    selected = [r for r in references if r['group'] == group]
    counts[group] = {'total': len(selected), **dict(collections.Counter(r['disposition'] for r in selected))}
tree = oid(f'{TARGET}^{{tree}}')
head_after = oid('HEAD')
status_after = text('status', '--porcelain=v1')
tracked_status_after = text('status', '--porcelain=v1', '--untracked-files=no')
all_covered = all(r['disposition'] != 'uncovered' for r in references)
all_proofs = all(p['passed'] for p in proofs) and all(p['passed'] for p in readme_results)
all_incoming = all(p['source_is_direct_checkpoint_parent'] and p['source_is_ancestor_of_target'] and p['checkpoint_is_ancestor_of_target'] for p in incoming_checkpoints)
result = {
    'schema': 'quds-office-intake-coverage-v1',
    'started_utc': started,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Fixed captured local remote refs only; no remote refresh, Actions, tests, source edits, ref changes, or dependency changes.',
    'source': {
        'commit': TARGET, 'tree': tree, 'expected_tree': EXPECTED_TREE,
        'head_before': head_before, 'head_after': head_after,
        'working_tree_status_before': status_before,
        'working_tree_status_after': status_after,
        'clean_and_unchanged': head_before == TARGET == head_after and not status_before and not status_after and tree == EXPECTED_TREE,
        'tracked_status_before': tracked_status_before,
        'tracked_status_after': tracked_status_after,
        'tracked_source_clean_and_unchanged': head_before == TARGET == head_after and not tracked_status_before and not tracked_status_after and tree == EXPECTED_TREE,
        'captured_main': CAPTURED_MAIN,
        'continuation_tracking_ref': self_reference,
    },
    'counts': counts,
    'all_captured_references_covered': all_covered,
    'all_historical_proofs_passed': all_proofs,
    'all_original_and_refreshed_checkpoints_preserve_source_parents': all_incoming,
    'captured_integration_checkpoints': incoming_checkpoints,
    'already_in_captured_main': preexisting,
    'readme_historical_claims': readme_results,
    'historical_proofs': proofs,
    'prior_proof_input': {'path': PRIOR_PATH, 'at_commit': TARGET, 'sha256': hashlib.sha256(prior_bytes).hexdigest()},
    'active_diff_review': {
        'base': CAPTURED_MAIN, 'target': TARGET,
        'changed_paths': len(changed),
        'text_files_scanned_for_conflict_markers': scanned,
        'conflict_marker_matches': marker_matches,
        'git_diff_check_exit': check.returncode,
        'git_diff_check_output': diagnostics,
        'raw_patch_evidence_whitespace': whitespace_evidence,
        'product_diff_check_excludes': ['docs/validation/**'],
        'product_diff_check_exit': product_check.returncode,
        'product_diff_check_output': (product_check.stdout + product_check.stderr).decode(errors='replace'),
        'changed_blobs_with_unavailable_size': missing_sizes,
        'large_changed_files_at_least_1MiB': large_file_provenance,
        'runtime_or_cache_artifact_paths': suspicious_paths,
    },
    'references': references,
    'limitations': [
        'This receipt proves the fixed captured source graph and exact historical tree/delta identities; it does not establish behavior or platform acceptance.',
        'Local tracking refs are the bounded intake snapshot, not a fresh read of GitHub. Root independently checks remote main before publication.',
        'Historical equivalents are not claimed as commit ancestors. Their complete original delta paths match the mode/type/blob entries of accepted ancestors.',
    ],
}
OUT.mkdir(exist_ok=True)
(OUT / 'intake-coverage.json').write_text(json.dumps(result, indent=2) + '\n')
lines = [
    f'Intake audit target: {TARGET}', f'Tree: {tree}',
    f'Clean unchanged tracked source: {result["source"]["tracked_source_clean_and_unchanged"]}',
    f'Entire worktree clean including transient test files: {result["source"]["clean_and_unchanged"]}',
    f'All captured references covered: {all_covered}',
    f'Historical equivalence comparisons: {len(proofs)}; all passed: {all_proofs}',
    f'Original/refreshed direct-parent integration checks: {len(incoming_checkpoints)}; all passed: {all_incoming}',
]
for group, count in counts.items():
    lines.append(f'{group}: {json.dumps(count, sort_keys=True)}')
lines.extend([
    f'Changed paths from captured main: {len(changed)}',
    f'Conflict markers: {len(marker_matches)}; diff --check exit: {check.returncode}',
    f'Product/config/documentation diff --check excluding validation evidence exit: {product_check.returncode}',
    'The broad diff flags only unchanged raw patch context-prefix spaces retained from saved image evidence; see JSON provenance.',
    f'Large changed files >=1MiB: {len(large)}; unavailable sizes: {len(missing_sizes)}',
    f'Runtime/cache artifact path candidates: {len(suspicious_paths)}',
    'No network refresh, CI calls, test runs, source/ref/dependency changes performed.',
    'See intake-coverage.json for each pinned ref and exact proof identities.',
])
(OUT / 'intake-coverage.txt').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
print(json.dumps({'large_changed_files': large, 'artifact_candidates': suspicious_paths, 'marker_matches': marker_matches}))
