import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

root = Path('/workspace/scratch/909600b07261')
repo = root / 'quds_office_suite'
runtime = root / 'runtime'
logs = runtime / 'logs'
engine = repo / 'packages/quds_office_engine'
editor = repo / 'packages/quds_office_editor'
studio = editor / 'example'
dart = runtime / 'bin/dart'
flutter = runtime / 'bin/flutter'

def digest(path):
    hasher = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            hasher.update(chunk)
    return hasher.hexdigest()

engine_tests = [
    'odt_zotero_note_numbering_test.dart', 'odt_reader_styles_test.dart',
    'odt_document_reader_test.dart', 'odt_document_writer_test.dart',
    'odt_note_configuration_styles_test.dart', 'odt_libreoffice_note_offsets_test.dart',
    'odt_note_fidelity_test.dart', 'odt_zotero_writer_test.dart',
    'odt_zotero_export_lifecycle_test.dart', 'odt_footnote_separator_test.dart',
    'odt_footnote_separator_libreoffice_test.dart', 'word_note_numbering_test.dart',
]
editor_tests = [
    'word_zotero_document_actions_test.dart', 'word_zotero_unlink_all_test.dart',
    'word_zotero_unlink_recovery_test.dart', 'word_zotero_recovery_controller_test.dart',
    'word_zotero_recovery_dialog_test.dart', 'word_zotero_controller_test.dart',
    'word_zotero_direct_command_test.dart', 'word_zotero_note_target_test.dart',
    'word_zotero_dialog_test.dart', 'word_odt_note_numbering_test.dart',
    'word_note_numbering_test.dart',
]
studio_tests = ['studio_zotero_shortcuts_test.dart', 'studio_zotero_odt_export_test.dart']
analysis_paths = [
    'packages/quds_office_engine/lib/src/word/serial/odt_document_reader.dart',
    'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart',
    'packages/quds_office_engine/lib/src/word/serial/odt_reader_styles.dart',
    'packages/quds_office_engine/lib/src/word/serial/odt_note_start_convention.dart',
    'packages/quds_office_engine/test/odt_zotero_note_numbering_test.dart',
    'packages/quds_office_engine/test/odt_reader_styles_test.dart',
    'packages/quds_office_editor/lib/src/embed/office_controller.dart',
    'packages/quds_office_editor/lib/src/embed/word_zotero_dialog.dart',
    'packages/quds_office_editor/test/word_zotero_document_actions_test.dart',
    'packages/quds_office_editor/test/word_zotero_unlink_all_test.dart',
    'packages/quds_office_editor/test/word_zotero_unlink_recovery_test.dart',
    'packages/quds_office_editor/test/word_odt_note_numbering_test.dart',
    'packages/quds_office_editor/example/test/studio_zotero_odt_export_test.dart',
]

mode = sys.argv[1]
suffix = sys.argv[2] if len(sys.argv) > 2 else ''
if mode == 'engine':
    cwd, tests = engine, engine_tests
    command = [str(runtime / 'bin/dart-test'), '--reporter', 'json', '--concurrency=2', *['test/' + p for p in tests]]
elif mode == 'editor':
    cwd, tests = editor, editor_tests
    command = [str(flutter), 'test', '--no-pub', '--reporter', 'json', '--concurrency=2', *['test/' + p for p in tests]]
elif mode == 'studio':
    cwd, tests = studio, studio_tests
    command = [str(flutter), 'test', '--no-pub', '--reporter', 'json', '--concurrency=2', *['test/' + p for p in tests]]
elif mode == 'analysis':
    cwd, tests = repo, []
    command = [str(dart), 'analyze', '--fatal-infos', *analysis_paths]
else:
    raise SystemExit('Unknown mode: ' + mode)

def source_paths():
    paths = set((engine / 'lib').rglob('*.dart'))
    paths.update((repo / 'packages/legacy_doc_parser/lib').rglob('*.dart'))
    if mode != 'engine':
        paths.update((editor / 'lib').rglob('*.dart'))
    if mode in ('studio', 'analysis'):
        paths.update((studio / 'lib').rglob('*.dart'))
        for package in ['quds_mail_core', 'quds_mail_store', 'quds_mail_transport']:
            paths.update((repo / 'packages' / package / 'lib').rglob('*.dart'))
        paths.update((repo / 'third_party/enough_mail/lib').rglob('*.dart'))
    paths.update(cwd / 'test' / p for p in tests)
    paths.update((cwd / 'test/support').rglob('*.dart'))
    if mode == 'analysis':
        paths.update(repo / p for p in analysis_paths)
    paths.update([
        repo / 'pubspec.lock', repo / '.dart_tool/package_config.json',
        runtime / 'flutter/bin/cache/dart-sdk/bin/dart',
    ])
    if mode != 'engine':
        paths.add(runtime / 'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester')
    return sorted(path for path in paths if path.is_file())

def snapshot():
    return {str(path.relative_to(root)): digest(path) for path in source_paths()}

name = 'incoming-zotero-' + mode + suffix
out = logs / (name + ('.log' if mode == 'analysis' else '.jsonl'))
err = logs / (name + '.stderr')
record = {
    'schemaVersion': 1,
    'capturedZoteroTip': 'f06afa63a7e321482a60d3f3a4fc39c522fdb29d',
    'startedAt': datetime.now(timezone.utc).isoformat(),
    'gitHeadBefore': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'command': command, 'cwd': str(cwd), 'tests': tests,
    'sourceHashesBefore': snapshot(),
}
receipt = logs / (name + '.receipt.json')
receipt.write_text(json.dumps(record, indent=2) + '\n')
with out.open('w') as stdout, err.open('w') as stderr:
    process = subprocess.run(command, cwd=cwd, env=os.environ, stdout=stdout, stderr=stderr)
record.update({
    'exitCode': process.returncode,
    'gitHeadAfter': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'finishedAt': datetime.now(timezone.utc).isoformat(),
    'stdout': str(out), 'stdoutSha256': digest(out),
    'stderr': str(err), 'stderrSha256': digest(err),
    'sourceHashesAfter': snapshot(),
})
record['sourceStable'] = record['sourceHashesBefore'] == record['sourceHashesAfter']
if mode != 'analysis':
    events = []
    for line in out.read_text().splitlines():
        try:
            event = json.loads(line)
            if isinstance(event, dict): events.append(event)
        except ValueError:
            pass
    names = {e['test']['id']: e['test']['name'] for e in events if e.get('type') == 'testStart'}
    done = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden')]
    record['passed'] = sum(e['result'] == 'success' and not e.get('skipped') for e in done)
    record['failed'] = sum(e['result'] != 'success' for e in done)
    record['skipped'] = sum(bool(e.get('skipped')) for e in done)
    record['errors'] = [{**e, 'testName': names.get(e.get('testID'))} for e in events if e.get('type') == 'error']
    record['runnerDone'] = [e for e in events if e.get('type') == 'done']
    for error in record['errors']:
        print(error['testName'], error.get('error'))
else:
    print(out.read_text()[-12000:])
record['accepted'] = process.returncode == 0 and record['sourceStable'] and not record.get('failed') and not record.get('skipped') and not record.get('errors')
receipt.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record.get(key) for key in ['exitCode', 'passed', 'failed', 'skipped', 'sourceStable', 'accepted']}, indent=2))
if process.returncode:
    print(err.read_text()[-8000:])
sys.exit(0 if record['accepted'] else 1)
