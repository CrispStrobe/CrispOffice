import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

workspace = Path('/workspace/scratch/909600b07261')
runtime = workspace / 'runtime'
repo = workspace / 'quds_office_suite'
engine = repo / 'packages/quds_office_engine'
logs = runtime / 'logs'
dart = runtime / 'flutter/bin/cache/dart-sdk/bin/dart'
fixture = engine / 'test/fixtures/vba_conformance/word_cell_suffix_v1.json'
driver = engine / 'tool/macros/web_vba_word_cell_suffix_conformance.dart'
package_config = repo / '.dart_tool/package_config.json'
receipt = logs / 'word-cell-suffix-portability.json'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    paths = list((engine / 'lib').rglob('*.dart')) + [
        fixture, driver, engine / 'tool/macros/web_vba_conformance.dart',
        engine / 'test/support/vba_conformance.dart',
        repo / 'pubspec.lock', package_config, dart,
    ]
    return {str(path.relative_to(workspace)): digest(path) for path in sorted(paths)}

before = snapshot()
record = {
    'schemaVersion': 1,
    'startedAt': datetime.now(timezone.utc).isoformat(),
    'fixture': str(fixture.relative_to(repo)),
    'fixtureSha256': digest(fixture),
    'fixtureCases': len(json.loads(fixture.read_text())['cases']),
    'sourceHashesBefore': before,
    'runs': [],
}

encoded = base64.b64encode(fixture.read_bytes()).decode()
define = '-DVBA_CONFORMANCE_BASE64=' + encoded
packages = '--packages=' + str(package_config)
js = logs / 'word-cell-suffix-conformance.js'

def run(name, command, stdout):
    stderr = logs / (name + '.stderr')
    with stdout.open('w') as out, stderr.open('w') as err:
        result = subprocess.run(command, cwd=engine, env=os.environ, stdout=out, stderr=err)
    record['runs'].append({
        'name': name,
        'command': [x if not x.startswith('-DVBA_CONFORMANCE_BASE64=') else '-DVBA_CONFORMANCE_BASE64=<base64 of exact fixture bytes>' for x in command],
        'cwd': str(engine),
        'exitCode': result.returncode,
        'stdout': str(stdout),
        'stdoutSha256': digest(stdout),
        'stderr': str(stderr),
        'stderrSha256': digest(stderr),
    })
    receipt.write_text(json.dumps(record, indent=2) + '\n')
    if result.returncode:
        print(name, 'FAILED:', stderr.read_text()[-4000:], stdout.read_text()[-4000:])
        sys.exit(result.returncode)

vm = logs / 'word-cell-suffix-conformance.vm.json'
node = logs / 'word-cell-suffix-conformance.node.json'
run('word-cell-suffix-conformance-vm', [str(dart), define, packages, str(driver)], vm)
run('word-cell-suffix-conformance-js-compile', [str(dart), 'compile', 'js', '-O2', define, packages, '-o', str(js), str(driver)], logs / 'word-cell-suffix-conformance.js-compile.log')
run('word-cell-suffix-conformance-node', ['node', str(js)], node)
vm_result = json.loads(vm.read_text())
node_result = json.loads(node.read_text())
record['semanticReceiptsIdentical'] = vm_result == node_result
record['receiptBytesIdentical'] = vm.read_bytes() == node.read_bytes()
record['sourceHashesAfter'] = snapshot()
record['sourceStable'] = record['sourceHashesAfter'] == before
record['compiledJavaScriptSha256'] = digest(js)
record['finishedAt'] = datetime.now(timezone.utc).isoformat()
record['success'] = record['semanticReceiptsIdentical'] and record['receiptBytesIdentical'] and record['sourceStable']
receipt.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['fixtureCases', 'semanticReceiptsIdentical', 'receiptBytesIdentical', 'sourceStable', 'success']}, indent=2))
sys.exit(0 if record['success'] else 1)
