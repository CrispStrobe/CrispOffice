Final local Quds morphology qualification evidence.

All final-* receipts passed and record unchanged source during execution.
Source commits may have different metadata while the source tree is identical;
the parent report supplies the canonical remote source binding. Every receipt
retains exact source hashes, commands, logs and the observed local HEAD.

Reproduction: use the recorded official Flutter 3.47.8 / Dart 3.13.7 and Node
24.22.1. The setup helper verifies the official complete Flutter archive hash
and pinned Pub archive hashes. Restore the repository as quds_office_suite
next to toolchains, place the setup scripts under toolchains/setup, and adapt
the recorded absolute workspace paths in env.sh/arguments to your location.
The runners derive the workspace root from their toolchains/setup location.
Run run_existing_proofing.py --group engine/editor/analysis/web --output PATH.
Run run_morphology_timing.py --output PATH, adding --text-file
long-valid-control-paragraph.txt for the 60-control long request.
Each final timing folder retains the exact runner/probe used in that run.

Compiler-generated JavaScript, maps and deps are intentionally omitted;
their SHA-256 and regeneration commands remain in receipts and the omitted
outputs inventory. SDK, dependency caches and web build outputs are omitted.
The web notice check retains the extracted notice evidence and bundle hashes.
Earlier failures and exploratory backend/provider checks are in the separate
exploratory-evidence.tar.gz archive. Timing values are local measurements,
not general latency guarantees or German accuracy measurements.
