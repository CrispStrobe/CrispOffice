#!/usr/bin/env python3
"""Create deterministic source qualification evidence without build outputs."""
from __future__ import annotations
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[2]
TOOLS=ROOT/'toolchains'
VALIDATION=TOOLS/'validation'

def digest(data): return hashlib.sha256(data).hexdigest()

def main():
    files={}
    groups={}
    omitted=[]
    license_path=VALIDATION/'final-web/license-collection.json'
    if not license_path.is_file() or json.loads(license_path.read_text()).get('passed') is not True:
        raise RuntimeError('Packaged Unicode license collection did not pass')
    for directory in sorted(VALIDATION.glob('final-*')):
        if not directory.is_dir():continue
        receipt_path=directory/'receipt.json'
        if not receipt_path.is_file():raise RuntimeError('Missing final receipt: '+str(directory))
        receipt=json.loads(receipt_path.read_text())
        if receipt.get('passed') is not True:raise RuntimeError('Final group not passed: '+str(directory))
        groups[directory.name]={'receipt':directory.name+'/receipt.json','receipt_sha256':digest(receipt_path.read_bytes()),'passed':True,'source_unchanged':receipt['source_unchanged'],'source_head':receipt['source_head']}
        for path in sorted(directory.rglob('*')):
            if not path.is_file():continue
            name=str(path.relative_to(VALIDATION))
            if path.suffix in {'.js','.map','.deps'}:
                omitted.append({'path':name,'bytes':path.stat().st_size,'sha256':digest(path.read_bytes()),'reason':'Reproducible compiler output; command, exact source hashes and runtime pins retained'})
                continue
            files[name]=path.read_bytes()
    for path in sorted((VALIDATION/'attempts').rglob('*')):
        if path.is_file(): files[str(path.relative_to(VALIDATION))]=path.read_bytes()
    for name in ['runtime-summary.json','bootstrap-receipt.json','flutter-install-receipt.json','prefetch-162.json','bootstrap_flutter.py','prefetch_pub.py','flutter-version.log','flutter-tools-offline.log','workspace-offline.log','runtime-smoke-vm.log','runtime-smoke-node.log','long-valid-control-paragraph.json','long-valid-control-paragraph.txt','run_existing_proofing.py','run_morphology_timing.py','morphology_timing.dart','check_web_license.py','assemble_final_validation.py']:
        path=TOOLS/'setup'/name
        files['setup/'+name]=path.read_bytes()
    files['setup/env.sh']=(TOOLS/'env.sh').read_bytes()
    files['setup/baseline-replay-receipt.json']=(TOOLS/'setup/baseline-replay/receipt.json').read_bytes()
    files['OMITTED_REPRODUCIBLE_OUTPUTS.json']=(json.dumps(omitted,indent=2)+'\n').encode()
    files['VALIDATION_INDEX.json']=(json.dumps({'groups':groups,'github_actions_used':False,'scope':'Local source qualification, compiled JavaScript executed in Node and Flutter widget tests. No real browser/device/backend Harper acceptance is implied.','long_input':'60 independently authored valid controls joined in source order; construction and source hash retained.','failure_retention':'attempts/timing-long-newline-cli preserves a compiler argument transport failure; exact input was subsequently transported as JSON without product edits. attempts/license-collection-exact-notice preserves an overstrict whitespace comparison in the packaging checker; exact license and attribution blocks pass independently.'},indent=2)+'\n').encode()
    files['README.txt']=b'''Final local Quds morphology qualification evidence.

All final-* receipts passed and record unchanged source during execution.
Source commits may have different metadata while the source tree is identical;
the parent report supplies the canonical remote source binding. Every receipt
retains exact source hashes, commands, logs and the observed local HEAD.

Reproduction: use the recorded official Flutter 3.47.8 / Dart 3.13.7 and Node
24.22.1. The setup helper verifies the official complete Flutter archive hash
and pinned Pub archive hashes. Restore the repository as quds_office_suite
next to toolchains, place the setup scripts under toolchains/setup, and adapt
the recorded absolute workspace paths in env.sh/arguments to your location.
The runners derive the workspace root from their toolchains/setup location.
Run run_existing_proofing.py --group engine/editor/analysis/web --output PATH.
Run run_morphology_timing.py --output PATH, adding --text-file
long-valid-control-paragraph.txt for the 60-control long request.
Each final timing folder retains the exact runner/probe used in that run.

Compiler-generated JavaScript, maps and deps are intentionally omitted;
their SHA-256 and regeneration commands remain in receipts and the omitted
outputs inventory. SDK, dependency caches and web build outputs are omitted.
The web notice check retains the extracted notice evidence and bundle hashes.
Earlier failures and exploratory backend/provider checks are in the separate
exploratory-evidence.tar.gz archive. Timing values are local measurements,
not general latency guarantees or German accuracy measurements.
'''
    inventory={name:{'bytes':len(data),'sha256':digest(data)} for name,data in sorted(files.items())}
    files['CONTENTS_SHA256.json']=(json.dumps(inventory,indent=2)+'\n').encode()
    archive=VALIDATION/'final-validation.tar.gz'
    with archive.open('wb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tar:
                for name,data in sorted(files.items()):
                    member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
                    tar.addfile(member,io.BytesIO(data))
    index={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':digest(archive.read_bytes()),'members':len(files),'groups':groups,'omitted_reproducible_outputs':omitted,'files':inventory}
    (VALIDATION/'final-validation-index.json').write_text(json.dumps(index,indent=2)+'\n')
    print(json.dumps({k:v for k,v in index.items() if k!='files'},indent=2))

if __name__=='__main__':main()
