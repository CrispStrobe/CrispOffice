#!/usr/bin/env python3
"""Measure actual default-service cold/warm checks on VM and compiled JS."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

ROOT=Path(__file__).resolve().parents[2]
REPO=ROOT/'quds_office_suite'
DART=ROOT/'toolchains/flutter/bin/cache/dart-sdk/bin/dart'
NODE=Path(shutil.which('node')).resolve()
PROBE=Path(__file__).with_name('morphology_timing.dart')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source_map():
    paths=sorted((REPO/'packages/quds_office_engine/lib/src/proofing').rglob('*.dart'))
    paths += [REPO/'packages/quds_office_engine/lib/src/opc/zip/deflate_codec.dart', REPO/'pubspec.lock', PROBE, Path(__file__)]
    return {str(p.relative_to(ROOT)):sha(p) for p in paths}

def main():
    global PROBE
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--probe',type=Path,default=PROBE)
    parser.add_argument('--text-file',type=Path)
    args=parser.parse_args()
    PROBE=args.probe.resolve()
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(PROBE,out/PROBE.name)
    shutil.copyfile(Path(__file__),out/Path(__file__).name)
    before=source_map()
    rec={'started_at_utc':datetime.now(timezone.utc).isoformat(),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'source_sha256':before,'dart_sha256':sha(DART),'node_sha256':sha(NODE),'commands':[],'github_actions_used':False}
    defines=[]
    if args.text_file:
        text_path=args.text_file.resolve()
        text=text_path.read_text()
        defines=['-DQUDS_MORPHOLOGY_TIMING_TEXT_JSON='+json.dumps(text,ensure_ascii=False)]
        shutil.copyfile(text_path,out/'input.txt')
        rec['text_file_sha256']=sha(text_path)
        rec['text_characters']=len(text)
    config='--packages='+str(REPO/'.dart_tool/package_config.json')
    js=out/'probe.js'
    commands=[('vm-results.json',[str(DART),config,*defines,str(PROBE)]),('compile.log',[str(DART),'compile','js','-O2',config,*defines,str(PROBE),'-o',str(js)]),('node-results.json',[str(NODE),'-e','globalThis.self=globalThis; require(process.argv[1]);',str(js)])]
    try:
        for name,cmd in commands:
            log=out/name; begin=time.monotonic()
            with log.open('wb') as stream:
                run=subprocess.run(cmd,cwd=REPO,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
            rec['commands'].append({'argv':cmd,'exit_code':run.returncode,'seconds':time.monotonic()-begin,'output':name,'sha256':sha(log)})
            (out/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n')
            if run.returncode:
                print(log.read_text(errors='replace')[-6000:],flush=True)
                raise RuntimeError(name+' failed')
        rec['vm_result']=json.loads((out/'vm-results.json').read_text())
        rec['node_result']=json.loads((out/'node-results.json').read_text())
        rec['compiled_javascript_sha256']=sha(js)
        rec['compiled_javascript_bytes']=js.stat().st_size
    finally:
        after=source_map()
        rec['source_unchanged']=before==after
        rec['changed_inputs']=[k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)]
        rec['passed']=len(rec['commands'])==3 and all(c['exit_code']==0 for c in rec['commands']) and rec['source_unchanged'] and all(rec.get(k,{}).get('all_results_success',False) for k in ['vm_result','node_result'])
        rec['finished_at_utc']=datetime.now(timezone.utc).isoformat()
        (out/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n')
    print(json.dumps({k:v for k,v in rec.items() if k not in ['source_sha256','commands']},indent=2))
    raise SystemExit(0 if rec['passed'] else 1)

if __name__=='__main__':main()
