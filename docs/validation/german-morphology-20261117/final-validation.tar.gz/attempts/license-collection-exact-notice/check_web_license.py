#!/usr/bin/env python3
"""Verify full Unicode notice retention in the actual release web bundle."""
from pathlib import Path
import gzip,hashlib,json,zlib

ROOT=Path(__file__).resolve().parents[2]
REPO=ROOT/'quds_office_suite'
OUT=ROOT/'toolchains/validation/final-web'
WEB=REPO/'packages/quds_office_editor/example/build/web'
SOURCE=REPO/'packages/quds_office_engine/third_party/proofing'

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    notice=next(p for p in [WEB/'assets/NOTICES',WEB/'assets/NOTICES.Z'] if p.is_file())
    payload=notice.read_bytes()
    if notice.name=='NOTICES':
        text=payload.decode();encoding='utf-8'
    else:
        try:text=gzip.decompress(payload).decode();encoding='gzip'
        except (gzip.BadGzipFile,OSError):text=zlib.decompress(payload).decode();encoding='zlib'
    license_text=(SOURCE/'UNICODE_INFLECTION_LICENSE').read_text().strip()
    attribution=(SOURCE/'UNICODE_INFLECTION_NOTICE').read_text().strip()
    assert license_text in text,'Complete verbatim Unicode-3.0 license absent'
    assert attribution in text,'Complete verbatim Inflection attribution absent'
    extracted=OUT/'unicode-license-extracted.txt'
    extracted.write_text(text[text.index(attribution):text.index(attribution)+len(attribution)]+'\n')
    files={str(p.relative_to(WEB)):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(WEB.rglob('*')) if p.is_file()}
    manifest=OUT/'web-bundle-sha256.json'
    manifest.write_text(json.dumps(files,indent=2)+'\n')
    record={'passed':True,'bundle_files':len(files),'bundle_bytes':sum(x['bytes'] for x in files.values()),'notices_path':str(notice.relative_to(WEB)),'notices_encoding':encoding,'notices_sha256':digest(notice),'complete_unicode_license_verbatim_in_notices':True,'complete_inflection_notice_verbatim_in_notices':True,'source_license_sha256':digest(SOURCE/'UNICODE_INFLECTION_LICENSE'),'source_notice_sha256':digest(SOURCE/'UNICODE_INFLECTION_NOTICE'),'extracted_notice_sha256':digest(extracted),'web_manifest_sha256':digest(manifest),'checker_sha256':digest(Path(__file__)),'acceptance_scope':'Successful release web compilation and packaged notice verification; no browser startup/interaction claim.'}
    (OUT/'license-collection.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))

if __name__=='__main__':main()
