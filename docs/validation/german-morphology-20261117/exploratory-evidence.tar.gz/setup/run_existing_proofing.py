#!/usr/bin/env python3
"""Run bounded existing Quds proofing regressions with source-bound receipts."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT / 'quds_office_suite'
SDK = ROOT / 'toolchains/flutter'
DART = SDK / 'bin/cache/dart-sdk/bin/dart'
FLUTTER = SDK / 'bin/flutter'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    result = {}
    for package in ['quds_office_engine', 'quds_office_editor', 'quds_proofing_harper']:
        base = REPO / 'packages' / package
        for folder in ['lib', 'test', 'tool']:
            for path in sorted((base / folder).rglob('*')):
                if path.is_file() and not {'__pycache__', 'failures', 'build', '.dart_tool'}.intersection(path.parts):
                    result[str(path.relative_to(REPO))] = digest(path)
        result[str((base / 'pubspec.yaml').relative_to(REPO))] = digest(base / 'pubspec.yaml')
    for name in ['pubspec.yaml', 'pubspec.lock']:
        result[name] = digest(REPO / name)
    return result

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--group', choices=['engine', 'editor', 'editor-warm', 'harper', 'incoming'], required=True)
    args = p.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    before = snapshot()
    record = {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'source_head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(), 'source_dirty_files': subprocess.check_output(['git','status','--short'],cwd=REPO,text=True).splitlines(), 'group':args.group,'source_before':before,'github_actions_used':False,'commands':[], 'runner_sha256':digest(Path(__file__)), 'dart_sha256':digest(DART), 'dart_version':subprocess.check_output([str(DART),'--version'],text=True,stderr=subprocess.STDOUT).strip(), 'node_version':subprocess.check_output(['node','--version'],text=True).strip()}
    packages = REPO / 'packages'
    if args.group == 'engine':
        commands = [
            ('engine-proofing-vm', packages/'quds_office_engine', [DART,'test','--reporter=expanded','--concurrency=4','test/proofing']),
            ('engine-proofing-node', packages/'quds_office_engine', [DART,'test','--reporter=expanded','--concurrency=4','--platform=node','test/proofing']),
            ('hyphenation-vm', packages/'quds_office_engine', [DART,'test','--reporter=expanded','--concurrency=4','test/proofing_hyphenation_test.dart','test/english_hyphenation_test.dart','test/german_hyphenation_context_test.dart']),
            ('hyphenation-node', packages/'quds_office_engine', [DART,'test','--reporter=expanded','--concurrency=4','--platform=node','test/english_hyphenation_test.dart','test/german_hyphenation_context_test.dart']),
        ]
    elif args.group == 'harper':
        tests = ['test/harper_provider_test.dart','test/harper_source_text_test.dart','test/harper_source_contract_test.dart']
        commands = [
            ('harper-contracts-vm',packages/'quds_proofing_harper',[DART,'test','--reporter=expanded',*tests]),
            ('harper-contracts-node',packages/'quds_proofing_harper',[DART,'test','--reporter=expanded','--platform=node',*tests]),
            ('harper-source-projection',packages/'quds_proofing_harper',['node','tool/source_projection_probe.mjs']),
        ]
    elif args.group == 'incoming':
        tests=['odt_document_writer','odt_paragraph_properties','odt_table_merge','odp_table_fidelity']
        commands=[('incoming-odf',packages/'quds_office_engine',[DART,'test','--reporter=expanded','--concurrency=4',*[f'test/{name}_test.dart' for name in tests]])]
    elif args.group == 'editor-warm':
        tests=['word_proofing_dialog','word_german_grammar_integration']
        commands=[('editor-warm-zone',packages/'quds_office_editor',[FLUTTER,'test','--no-pub','--reporter=expanded','--concurrency=2',*[f'test/{name}_test.dart' for name in tests]])]
    else:
        tests=['word_proofing_session','word_proofing_dialog','word_proofing_correction','word_proofing_geometry','word_proofing_navigation','word_proofing_context','word_german_grammar_integration','word_hyphenation_paint','word_hyphenation_source_presentation','word_hyphenation_resume','word_hyphenation_caret']
        commands=[('editor-proofing',packages/'quds_office_editor',[FLUTTER,'test','--no-pub','--reporter=expanded','--concurrency=2',*[f'test/{name}_test.dart' for name in tests]])]
    try:
        for label,cwd,command in commands:
            print('START '+label,flush=True)
            begin=time.monotonic()
            log=out/(label+'.log')
            with log.open('wb') as stream:
                run=subprocess.run([str(x) for x in command],cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,timeout=600)
            record['commands'].append({'label':label,'argv':[str(x) for x in command],'cwd':str(cwd),'exit_code':run.returncode,'seconds':round(time.monotonic()-begin,3),'log':log.name,'log_sha256':digest(log)})
            (out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
            print('END '+label+' '+str(run.returncode),flush=True)
            if run.returncode:
                print(log.read_text(errors='replace')[-10000:],flush=True)
                break
    finally:
        after=snapshot()
        record['source_unchanged']=before==after
        record['changed_inputs']=[key for key in before.keys()|after.keys() if before.get(key)!=after.get(key)]
        record['passed']=len(record['commands'])==len(commands) and all(x['exit_code']==0 for x in record['commands']) and record['source_unchanged']
        record['finished_at_utc']=datetime.now(timezone.utc).isoformat()
        (out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:v for k,v in record.items() if k not in ['source_before','commands']},indent=2))
    raise SystemExit(0 if record['passed'] else 1)

if __name__=='__main__':
    main()
