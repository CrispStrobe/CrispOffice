// Local measurement harness; execute with the workspace package configuration.
import 'dart:async';
import 'dart:convert';
import 'package:quds_office_engine/src/proofing/german_writing_rules.dart';
import 'package:quds_office_engine/src/proofing/office_proofing.dart';

Future<void> main() async {
  final provider = GermanWritingRulesProvider();
  var revision = 0;
  OfficeProofingRequest request(String text) => OfficeProofingRequest(
    documentId: 'timing', blockId: 'paragraph', revision: revision++,
    text: text, language: 'de-DE',
  );
  const sentence = 'Sie arbeitet mit dem Studenten. Das Dokument enthält die aktuellen Ergebnisse.';
  final watch = Stopwatch()..start();
  var lastTick = 0;
  var maxTickGap = 0;
  var ticks = 0;
  final timer = Timer.periodic(const Duration(milliseconds: 16), (_) {
    final now = watch.elapsedMicroseconds;
    final gap = now-lastTick;
    if (gap > maxTickGap) maxTickGap = gap;
    lastTick = now;
    ticks++;
  });
  final cold = await provider.check(request(sentence));
  final coldMicros = watch.elapsedMicroseconds;
  timer.cancel();
  final warm = <int>[];
  var successful = cold.status == OfficeProofingStatus.success;
  for (var n=0; n<40; n++) {
    final start = watch.elapsedMicroseconds;
    final result = await provider.check(request(sentence));
    warm.add(watch.elapsedMicroseconds-start);
    successful = successful && result.status == OfficeProofingStatus.success;
  }
  warm.sort();
  await provider.dispose();
  print(jsonEncode({
    'purpose':'One cold and 40 warm checks of the same short paragraph; local timing, not a performance guarantee',
    'characters':sentence.length,
    'cold_ms':coldMicros/1000,
    'warm_median_ms':warm[warm.length~/2]/1000,
    'warm_p95_ms':warm[(warm.length*0.95).floor()]/1000,
    'max_16ms_timer_gap_during_cold_ms':maxTickGap/1000,
    'timer_ticks_during_cold':ticks,
    'all_results_success':successful,
    'cold_findings':cold.findings.length,
  }));
}
