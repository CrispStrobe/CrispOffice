from pathlib import Path
import datetime, hashlib, io, json, subprocess, tarfile

repo = Path('/workspace/scratch/107a3658eeb8/quds_office_suite')
base = repo / 'docs/validation/german-morphology-20261117'
frozen = '8649b79efe0f2ad57d8f187233ed3f8b8177b3a0'
recovered = '286bdeb73e4ee0e88f1b4a2e6ecf462c78082c86'
sha = lambda b: hashlib.sha256(b).hexdigest()
get = lambda p, ref=frozen: subprocess.check_output(['git', '-C', str(repo), 'show', f'{ref}:{p}'])
errors = []
report = {
    'schema_version': 1,
    'audited_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Integrity and source binding of previously recorded validation. No tests or benchmarks rerun; later merged source is outside this audit.',
    'recovered_evidence_commit': recovered,
    'qualified_remote_source': frozen,
    'qualified_source_tree': subprocess.check_output(['git', '-C', str(repo), 'rev-parse', frozen+'^{tree}']).decode().strip(),
    'github_actions_used': False,
    'archives': {},
    'receipts': {},
}
contents = {}
for index_name in ['final-validation-index.json', 'morphology-corpora-index.json', 'exploratory-evidence-index.json']:
    index = json.loads((base / index_name).read_text())
    archive_name = index['archive']
    raw = (base / archive_name).read_bytes()
    if len(raw) != index['bytes'] or sha(raw) != index['sha256']:
        errors.append(archive_name + ': archive size or digest differs')
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        entries = {m.name: archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
    expected = index.get('files', index['members'])
    if set(entries) != set(expected):
        errors.append(archive_name + ': indexed member set differs')
    for name, record in expected.items():
        if name not in entries or len(entries[name]) != record['bytes'] or sha(entries[name]) != record['sha256']:
            errors.append(archive_name + ':' + name + ': member size or digest differs')
    original_raw = get('docs/validation/german-morphology-20261117/' + archive_name, recovered)
    if raw != original_raw:
        errors.append(archive_name + ': archive changed since recovered checkpoint')
    contents[archive_name] = entries
    report['archives'][archive_name] = {
        'bytes': len(raw), 'sha256': sha(raw), 'member_digests_verified': len(entries),
        'complete_member_index': set(entries) == set(expected),
        'unchanged_from_recovered_checkpoint': raw == original_raw,
    }

binding = json.loads((base / 'source-binding.json').read_text())
lock_binding = binding['workspace_input_bindings']['pubspec.lock']
lock = get(lock_binding['tracked_evidence_path'])
assert sha(lock) == lock_binding['sha256']
report['workspace_lockfile'] = dict(lock_binding, verified_against_frozen_tree=True)
receipt_locations = {
    'engine': ('final-validation.tar.gz', 'final-engine/receipt.json'),
    'editor': ('final-validation.tar.gz', 'final-editor/receipt.json'),
    'analysis': ('final-validation.tar.gz', 'final-analysis/receipt.json'),
    'web': ('final-validation.tar.gz', 'final-web/receipt.json'),
    'frozen-corpus': ('morphology-corpora.tar.gz', 'morphology-final-frozen/receipt.json'),
    'independent-review': ('morphology-corpora.tar.gz', 'morphology-review-final-frozen/receipt.json'),
    'all-buckets': ('morphology-corpora.tar.gz', 'morphology-final-buckets/receipt.json'),
    'timing-short': ('final-validation.tar.gz', 'final-timing-short/receipt.json'),
    'timing-long': ('final-validation.tar.gz', 'final-timing-long/receipt.json'),
}
# Read recorded repository source inputs from immutable Git objects, not a
# concurrently changing checkout. The current indexes/metadata are the only edits.
cache = {}
for name, (archive_name, archived_path) in receipt_locations.items():
    raw = (base / 'qualification' / (name + '-receipt.json')).read_bytes()
    receipt = json.loads(raw)
    if raw != contents[archive_name][archived_path]:
        errors.append(name + ': standalone and archived receipts differ')
    if sha(raw) != binding['receipts'][name]['receipt_sha256']:
        errors.append(name + ': source-binding receipt digest differs')
    paths = receipt.get('source_before', receipt.get('source_inputs_sha256', receipt.get('source_sha256', {})))
    tracked = preserved_workspace = preserved_harness = 0
    external = []
    mismatches = []
    for original_path, digest in paths.items():
        path = original_path.removeprefix('quds_office_suite/')
        if path == 'pubspec.lock':
            actual = sha(lock)
            preserved_workspace += 1
        elif path.startswith('toolchains/setup/'):
            archived_script = str(Path(archived_path).parent / Path(path).name)
            actual = sha(contents[archive_name][archived_script])
            preserved_harness += 1
        elif path.startswith('dependency:'):
            external.append(path)
            continue
        else:
            if path not in cache:
                cache[path] = sha(get(path))
            actual = cache[path]
            tracked += 1
        if actual != digest:
            mismatches.append(original_path)
    if tracked != binding['receipts'][name]['checked_paths']:
        errors.append(name + ': source-binding tracked count differs')
    checked_logs = 0
    for command in receipt.get('commands', []):
        log = command.get('log')
        digest = command.get('log_sha256')
        if log and digest:
            archived_log = str(Path(archived_path).parent / log)
            if archived_log not in contents[archive_name] or sha(contents[archive_name][archived_log]) != digest:
                errors.append(name + ': command log differs: ' + archived_log)
            else:
                checked_logs += 1
    if mismatches:
        errors.extend(name + ': source mismatch: ' + p for p in mismatches)
    report['receipts'][name] = {
        'sha256': sha(raw), 'standalone_equals_archived': raw == contents[archive_name][archived_path],
        'recorded_passed': receipt.get('passed', receipt.get('status') == 'passed'),
        'tracked_source_paths_verified': tracked,
        'preserved_workspace_inputs_verified': preserved_workspace,
        'preserved_harness_inputs_verified': preserved_harness,
        'external_dependency_paths_not_revalidated': external,
        'command_logs_verified': checked_logs,
        'mismatches': mismatches,
    }

manifest = json.loads(get('packages/quds_office_engine/third_party/proofing/morphology_manifest.json'))
license_data = get('packages/quds_office_engine/third_party/proofing/UNICODE_INFLECTION_LICENSE')
notice_data = get('packages/quds_office_engine/third_party/proofing/UNICODE_INFLECTION_NOTICE')
with_notice = []
for path, digest in manifest['generated_files'].items():
    raw = get('packages/quds_office_engine/' + path)
    if sha(raw) != digest:
        errors.append('generated resource differs: ' + path)
    if path.endswith('.dart'):
        comment_text = '\n'.join(line[3:] if line.startswith('// ') else '' for line in raw.decode().splitlines() if line.startswith('//'))+'\n'
        if notice_data.decode() not in comment_text:
            errors.append('full generated notice missing: ' + path)
        else:
            with_notice.append(path)
for path in ['LICENSE', 'packages/quds_office_engine/LICENSE']:
    if license_data not in get(path):
        errors.append('full Unicode license missing: ' + path)
report['morphology_resources'] = {
    'generated_file_digests_verified': len(manifest['generated_files']),
    'generated_dart_files_with_complete_notice': len(with_notice),
    'upstream_license_revision': manifest['upstream']['revision'],
    'license_sha256': sha(license_data),
    'license_git_blob_sha': subprocess.check_output(['git', '-C', str(repo), 'rev-parse', frozen+':packages/quds_office_engine/third_party/proofing/UNICODE_INFLECTION_LICENSE']).decode().strip(),
    'pinned_upstream_license_git_blob_verified_via_github': 'f6fe7b9e1bcceae1ec0a98676181384f3b1d3d91',
    'note': 'Nineteen generated-resource entries plus the manifest comprise the prior twenty-file regeneration check. This audit verifies saved bytes and notices; it does not rerun source generation or linguistic qualification.',
}
report['metadata_corrections'] = [
    'Added CONTENTS_SHA256.json to final-validation-index.json; the archive itself is unchanged.',
    'Separated ignored workspace pubspec.lock from tracked-source counts and mapped it to its exact preserved historical copy.',
]
report['total_archive_members_verified'] = sum(x['member_digests_verified'] for x in report['archives'].values())
report['verification_method'] = 'Compared SHA-256 and byte lengths of each archive/member, standalone/archived receipt equality, command-log digests, and every recorded repository source input against immutable Git source 8649b79e. Workspace lockfile and timing harnesses use the explicit preserved-file mappings. The seven characters dependency files in corpus receipts remain recorded but were not separately revalidated in this audit.'
report['status'] = 'passed' if not errors else 'failed'
report['errors'] = errors
(base / 'recovery-audit.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'status': report['status'], 'members_verified': report['total_archive_members_verified'], 'unique_tracked_source_paths_verified': len(cache), 'errors': errors}, indent=2))
if errors:
    raise SystemExit(1)
