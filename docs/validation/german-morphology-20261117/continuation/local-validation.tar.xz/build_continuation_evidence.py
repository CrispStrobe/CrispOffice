#!/usr/bin/env python3
"""Package immutable validation files with a complete external member index."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import tarfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--workspace', type=Path, required=True)
parser.add_argument('--repo', type=Path, required=True)
args = parser.parse_args()
workspace = args.workspace.resolve()
repo = args.repo.resolve()
output = repo / 'docs/validation/german-morphology-20261117/continuation'
output.mkdir(parents=True, exist_ok=True)
members = {}
validation = workspace / 'morphology-resume-validation'
for path in sorted(validation.rglob('*')):
    if path.is_file() and '__pycache__' not in path.parts:
        members['validation/' + str(path.relative_to(validation))] = path.read_bytes()
for name in [
    'remote-reference-snapshot-20261117T140500Z.json',
    'remote-reference-frontier-20261117T140500Z.json',
    'remote-reference-coverage-20261117T140500Z.json',
    'final-reference-snapshot.json',
]:
    members['references/' + name] = (workspace / name).read_bytes()
setup = workspace / 'toolchains/setup'
for path in sorted(setup.iterdir()):
    if path.is_file():
        members['toolchain/' + path.name] = path.read_bytes()
members['toolchain/env.sh'] = (workspace / 'toolchains/env.sh').read_bytes()
members['review/audit_morphology_evidence.py'] = (workspace / 'audit_morphology_evidence.py').read_bytes()
members['review/recovery-audit.json'] = (output.parent / 'recovery-audit.json').read_bytes()
members['source-binding.json'] = (output / 'source-binding.json').read_bytes()
members['build_continuation_evidence.py'] = Path(__file__).read_bytes()
digest = lambda data: hashlib.sha256(data).hexdigest()
payload_hashes = {name: digest(data) for name, data in sorted(members.items())}
members['CONTENTS_SHA256.json'] = (json.dumps(payload_hashes, indent=2) + '\n').encode()
archive = output / 'local-validation.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
index = {
    'archive': archive.name,
    'bytes': archive.stat().st_size,
    'sha256': digest(archive.read_bytes()),
    'member_count': len(members),
    'payload_member_count': len(payload_hashes),
    'internal_manifest': 'CONTENTS_SHA256.json',
    'scope': 'Complete fresh local logs, receipts, source manifests, runners, reference inventories, review and toolchain receipts; no SDK binaries or model artifacts.',
    'members': {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(members.items())},
}
with tarfile.open(archive, 'r:xz') as tar:
    actual = {member.name: digest(tar.extractfile(member).read()) for member in tar.getmembers() if member.isfile()}
assert actual == {name: row['sha256'] for name, row in index['members'].items()}
(output / 'evidence-index.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({key: value for key, value in index.items() if key != 'members'}, indent=2))
