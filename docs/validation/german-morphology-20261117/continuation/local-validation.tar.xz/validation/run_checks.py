#!/usr/bin/env python3
"""Focused post-merge Quds validation, retaining input hashes and complete logs."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'quds_office_suite'
SDK = ROOT / 'toolchains/flutter'
DART = SDK / 'bin/cache/dart-sdk/bin/dart'
FLUTTER = [DART, '--packages=' + str(SDK / 'packages/flutter_tools/.dart_tool/package_config.json'), SDK / 'packages/flutter_tools/bin/flutter_tools.dart']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    files = {}
    for name in ['legacy_doc_parser', 'quds_office_engine', 'quds_office_editor', 'quds_proofing_harper']:
        package = REPO / 'packages' / name
        for folder in ['lib', 'test', 'tool']:
            for path in sorted((package / folder).rglob('*')):
                if path.is_file() and not {'__pycache__', 'failures', 'build', '.dart_tool'}.intersection(path.parts):
                    files[str(path.relative_to(REPO))] = sha(path)
        for file in ['pubspec.yaml', 'analysis_options.yaml', 'LICENSE']:
            path = package / file
            if path.is_file():
                files[str(path.relative_to(REPO))] = sha(path)
    for file in ['pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', 'LICENSE']:
        files[file] = sha(REPO / file)
    return files

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--group', choices=['engine', 'editor'], required=True)
    args = parser.parse_args()
    out = Path(__file__).resolve().parent / args.group
    out.mkdir(parents=True, exist_ok=True)
    before = snapshot()
    (out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
    record = {
        'started_at_utc': datetime.now(timezone.utc).isoformat(),
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
        'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO, text=True).strip(),
        'dirty_files_at_start': subprocess.check_output(['git', 'status', '--short'], cwd=REPO, text=True).splitlines(),
        'group': args.group,
        'source_before_sha256': sha(out / 'source-before.json'),
        'source_input_count': len(before),
        'dart_version': subprocess.check_output([str(DART), '--version'], text=True, stderr=subprocess.STDOUT).strip(),
        'dart_sha256': sha(DART),
        'node_version': subprocess.check_output(['node', '--version'], text=True).strip(),
        'workspace_package_config_sha256': sha(REPO / '.dart_tool/package_config.json'),
        'runner_sha256': sha(Path(__file__)),
        'github_actions_used': False,
        'commands': [],
    }
    if args.group == 'engine':
        cwd = REPO / 'packages/quds_office_engine'
        odf = ['odt_document_writer', 'odt_note_fidelity', 'odt_header_footer_fidelity', 'odt_table_merge', 'odp_presentation_writer', 'odp_table_fidelity', 'odf_covered_cell_extraction']
        commands = [
            ('engine-analysis', cwd, [DART, 'analyze', '--fatal-infos', 'lib', 'test', 'tool']),
            ('engine-proofing-vm', cwd, [DART, 'test', '--reporter=expanded', '--concurrency=4', 'test/proofing']),
            ('incoming-odf-vm', cwd, [DART, 'test', '--reporter=expanded', '--concurrency=4', *[f'test/{name}_test.dart' for name in odf]]),
        ]
    else:
        cwd = REPO / 'packages/quds_office_editor'
        tests = ['word_proofing_session', 'word_proofing_dialog', 'word_proofing_correction', 'word_proofing_geometry', 'word_proofing_navigation', 'word_proofing_context', 'word_german_grammar_integration', 'word_hyphenation_paint', 'word_hyphenation_source_presentation', 'word_hyphenation_resume', 'word_hyphenation_caret']
        commands = [('editor-proofing', cwd, [*FLUTTER, 'test', '--no-pub', '--reporter=expanded', '--concurrency=2', *[f'test/{name}_test.dart' for name in tests]])]
    try:
        for label, cwd, command in commands:
            print('START ' + label, flush=True)
            log = out / (label + '.log')
            begin = time.monotonic()
            with log.open('wb') as stream:
                result = subprocess.run([str(x) for x in command], cwd=cwd, stdout=stream, stderr=subprocess.STDOUT, timeout=600)
            record['commands'].append({'label': label, 'argv': [str(x) for x in command], 'cwd': str(cwd), 'exit_code': result.returncode, 'seconds': round(time.monotonic() - begin, 3), 'log': log.name, 'log_sha256': sha(log)})
            (out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
            print('END ' + label + ' ' + str(result.returncode), flush=True)
            if result.returncode:
                print(log.read_text(errors='replace')[-8000:], flush=True)
                break
    finally:
        after = snapshot()
        (out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
        record['source_after_sha256'] = sha(out / 'source-after.json')
        record['source_unchanged'] = before == after
        record['changed_source_inputs'] = [key for key in before.keys() | after.keys() if before.get(key) != after.get(key)]
        record['passed'] = len(record['commands']) == len(commands) and all(item['exit_code'] == 0 for item in record['commands']) and record['source_unchanged']
        record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
        (out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'group': args.group, 'passed': record['passed'], 'source_unchanged': record['source_unchanged'], 'command_count': len(record['commands'])}), flush=True)
    return 0 if record['passed'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
