import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';

const officeNs = 'urn:oasis:names:tc:opendocument:xmlns:office:1.0';
const textNs = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0';
Iterable<XmlElement> named(XmlElement root, String ns, String name) sync* {
  if (root.namespaceUri == ns && root.localName == name) yield root;
  for (final child in root.childElements) {
    yield* named(child, ns, name);
  }
}
void main() {
  final document = WmlDocument(
    sections: [
      WmlSection(blocks: [
        WmlParagraph(inlines: [
          WmlRun(text: 'Annotated', commentIds: [1]),
          WmlRun(text: '7', noteRefId: 7),
        ]),
      ]),
    ],
    comments: [
      WmlComment(id: 1, author: 'Reviewer', paragraphs: [
        WmlParagraph(inlines: [WmlRun(text: '7', noteRefId: 7)]),
      ]),
    ],
    footnotes: [
      WmlNote(id: 7, endnote: false, blocks: [
        WmlParagraph(inlines: [WmlRun(text: 'The body footnote.')]),
      ]),
    ],
  );
  final package = OpcPackage.openBytes(OdtDocumentWriter.writeBytes(document));
  final content = package.getPart('/content.xml')!.readText();
  final root = XmlDocument.parse(content).root!;
  final annotations = named(root, officeNs, 'annotation').toList();
  final noteInAnnotation = annotations.expand((a) => named(a, textNs, 'note')).length;
  final noteRefInAnnotation = annotations.expand((a) => named(a, textNs, 'note-ref')).length;
  final totalNotes = named(root, textNs, 'note').length;
  final totalRefs = named(root, textNs, 'note-ref').length;
  print(const JsonEncoder.withIndent('  ').convert({
    'annotation_count': annotations.length,
    'note_bodies_in_annotations': noteInAnnotation,
    'note_refs_in_annotations': noteRefInAnnotation,
    'note_bodies_outside_annotations': totalNotes - noteInAnnotation,
    'note_refs_outside_annotations': totalRefs - noteRefInAnnotation,
    'expected': {'note_bodies_in_annotations': 0, 'note_bodies_outside_annotations': 1},
    'annotation_text': annotations.single.text,
    'source_body_text': document.sections.single.blocks.whereType<WmlParagraph>().single.text,
  }));
}
