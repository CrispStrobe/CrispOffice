from __future__ import annotations
import contextlib
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import unittest

REPO = Path("/workspace/scratch/107a3658eeb8/quds_office_suite")
OUT = Path("/workspace/scratch/107a3658eeb8/morphology-resume-validation/python")
SOURCE = REPO / "tools/proofing/german_model"
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "tmp").mkdir(exist_ok=True)
os.environ["TMPDIR"] = str(OUT / "tmp")
sys.dont_write_bytecode = True

def utc():
    return datetime.now(timezone.utc).isoformat()
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO, text=True).strip()
def source_hashes():
    paths = sorted(SOURCE.glob("*.py")) + sorted(SOURCE.glob("requirements*.txt"))
    return {str(p.relative_to(REPO)): digest(p) for p in paths}
def version(name):
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None

before = source_hashes()
receipt = {
    "started_at_utc": utc(),
    "source_head": git("rev-parse", "HEAD"),
    "source_dirty_paths": git("diff", "--name-only").splitlines(),
    "command": [sys.executable, "-B", str(Path(__file__).resolve())],
    "scope": "Python unittest discovery of existing german_model test_*.py; no real model downloads or full-model inference",
    "python": sys.version,
    "python_path": sys.executable,
    "python_sha256": digest(Path(sys.executable).resolve()),
    "platform": platform.platform(),
    "packages": {name: version(name) for name in ("numpy", "onnx", "onnxruntime", "tokenizers", "scipy")},
    "source_before_sha256": before,
    "runner_sha256": digest(Path(__file__).resolve()),
    "github_actions_used": False,
}
started = time.monotonic()
with (OUT / "unittest.log").open("w") as log:
    with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        loader = unittest.TestLoader()
        suite = loader.discover(str(SOURCE), pattern="test_*.py")
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
after = source_hashes()
receipt.update({
    "completed_at_utc": utc(),
    "elapsed_seconds": time.monotonic() - started,
    "tests_run": result.testsRun,
    "passed": result.testsRun - len(result.failures) - len(result.errors) - len(result.skipped) - len(result.expectedFailures),
    "failures": [{"test": test.id(), "traceback": message} for test, message in result.failures],
    "errors": [{"test": test.id(), "traceback": message} for test, message in result.errors],
    "skipped": [{"test": test.id(), "reason": reason} for test, reason in result.skipped],
    "expected_failures": len(result.expectedFailures),
    "unexpected_successes": len(result.unexpectedSuccesses),
    "source_after_sha256": after,
    "source_unchanged": before == after,
    "log_sha256": digest(OUT / "unittest.log"),
})
receipt["status"] = "passed" if result.wasSuccessful() and before == after else "failed"
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({key: receipt[key] for key in ("status", "source_head", "tests_run", "passed", "failures", "errors", "skipped", "source_unchanged", "packages")}, indent=2))
raise SystemExit(0 if receipt["status"] == "passed" else 1)
