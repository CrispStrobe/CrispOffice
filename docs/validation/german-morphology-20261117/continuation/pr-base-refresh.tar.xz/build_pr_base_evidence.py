#!/usr/bin/env python3
"""Bind the qualified PR-base refresh to Git and preserve its complete evidence."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

workspace = Path(__file__).resolve().parent
repo = workspace / 'quds_office_suite'
source = workspace / 'pr-base-refresh'
output = repo / 'docs/validation/german-morphology-20261117/continuation'
head = 'b58e66da1ced48f3f87aa85633da9235191a6023'
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
digest = lambda data: hashlib.sha256(data).hexdigest()
tree = {}
for entry in git('ls-tree', '-rz', head).split(b'\0'):
    if entry:
        metadata, path = entry.split(b'\t', 1)
        tree[path.decode()] = metadata.decode().split()[2]
manifest = source / 'source-after.json'
inputs = json.loads(manifest.read_text())
mismatches = []
tracked = 0
external = []
for path, expected in inputs.items():
    data = (repo / path).read_bytes()
    actual_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if digest(data) != expected:
        mismatches.append({'path': path, 'reason': 'receipt hash differs'})
    if path in tree:
        tracked += 1
        if actual_blob != tree[path]:
            mismatches.append({'path': path, 'reason': 'Git blob differs'})
    else:
        external.append(path)
        if path != 'pubspec.lock':
            mismatches.append({'path': path, 'reason': 'unexpected untracked input'})
lock = repo / 'pubspec.lock'
preserved_lock = repo / 'docs/validation/proofing-grammar-expansion-20261117/integration/pubspec.lock'
assert lock.read_bytes() == preserved_lock.read_bytes()
continuity = json.loads((workspace / 'morphology-resume-validation/proofing-continuity.json').read_text())
proofing_changes = [path for path, blob in continuity['source_git_blobs'].items() if tree.get(path) != blob]
ancestors = ['8432238d8a694350d6035f1b3314b51ce4254ce4', '6f9caa0736828dbbb2c4d00d2af89277243dbf2b']
for ancestor in ancestors:
    subprocess.run(['git', 'merge-base', '--is-ancestor', ancestor, head], cwd=repo, check=True)
binding = {
    'qualified_remote_source': head,
    'equivalent_local_source': '6d8981fea1e581c9e697eaa562feebe3467e2574',
    'equal_full_tree': '26cc975675a1efffc995a1c7733f9e22855fd60f',
    'receipt_sha256': digest((source / 'receipt.json').read_bytes()),
    'input_manifest_sha256': digest(manifest.read_bytes()),
    'input_count': len(inputs),
    'tracked_inputs_matched': tracked,
    'workspace_inputs': external,
    'workspace_lock_sha256': digest(lock.read_bytes()),
    'workspace_lock_evidence': str(preserved_lock.relative_to(repo)),
    'mismatches': mismatches,
    'proofing_continuity': {'paths': len(continuity['source_git_blobs']), 'changed_paths': proofing_changes},
    'verified_ancestors': ancestors,
    'scope': 'Final source after integrating main section layouts into PR #105. Complete 279-test and strict-analysis receipt; earlier proofing/editor runs remain separately bound.',
    'github_actions_used': False,
}
assert not mismatches and not proofing_changes
binding_path = output / 'pr-base-binding.json'
binding_path.write_text(json.dumps(binding, indent=2) + '\n')
members = {str(path.relative_to(source)): path.read_bytes() for path in sorted(source.rglob('*')) if path.is_file() and '__pycache__' not in path.parts}
members['source-binding.json'] = binding_path.read_bytes()
members['build_pr_base_evidence.py'] = Path(__file__).read_bytes()
payload_hashes = {path: digest(data) for path, data in sorted(members.items())}
members['CONTENTS_SHA256.json'] = (json.dumps(payload_hashes, indent=2) + '\n').encode()
archive = output / 'pr-base-refresh.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for path, data in sorted(members.items()):
        info = tarfile.TarInfo(path)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
index = {'archive': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()), 'member_count': len(members), 'payload_member_count': len(payload_hashes), 'internal_manifest': 'CONTENTS_SHA256.json', 'members': {path: {'bytes': len(data), 'sha256': digest(data)} for path, data in sorted(members.items())}}
with tarfile.open(archive, 'r:xz') as tar:
    actual = {entry.name: digest(tar.extractfile(entry).read()) for entry in tar.getmembers() if entry.isfile()}
assert actual == {path: row['sha256'] for path, row in index['members'].items()}
(output / 'pr-base-evidence-index.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'binding': binding, 'archive': {key: value for key, value in index.items() if key != 'members'}}, indent=2))
