#!/usr/bin/env python3
"""Validate resolved PR-base refresh with the scoped ODF/search/ODS checks."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import time
import sys
SHARED = Path(__file__).resolve().parent.parent / 'morphology-resume-validation'
sys.path.insert(0, str(SHARED))
from run_checks import DART, REPO, sha, snapshot

OUT = Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)
before = snapshot()
(OUT / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
baseline = json.loads((SHARED / 'final-refresh/source-after.json').read_text())
differences = [
    {'path': path, 'previous_sha256': baseline.get(path), 'final_sha256': before.get(path)}
    for path in sorted(baseline.keys() | before.keys())
    if baseline.get(path) != before.get(path)
]
(OUT / 'source-differences-from-previous-refresh.json').write_text(json.dumps(differences, indent=2) + '\n')
record = {
    'started_at_utc': datetime.now(timezone.utc).isoformat(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO, text=True).strip(),
    'dirty_files_at_start': subprocess.check_output(['git', 'status', '--short'], cwd=REPO, text=True).splitlines(),
    'source_before_sha256': sha(OUT / 'source-before.json'),
    'source_input_count': len(before),
    'differences_from_previous_fixed_source': differences,
    'dart_version': subprocess.check_output([str(DART), '--version'], text=True, stderr=subprocess.STDOUT).strip(),
    'dart_sha256': sha(DART),
    'workspace_package_config_sha256': sha(REPO / '.dart_tool/package_config.json'),
    'runner_sha256': sha(Path(__file__)),
    'shared_runner_sha256': sha(SHARED / 'run_checks.py'),
    'github_actions_used': False,
    'commands': [],
}
cwd = REPO / 'packages/quds_office_engine'
tests = ['odt_document_writer', 'odt_note_fidelity', 'odt_header_footer_fidelity', 'odt_table_merge', 'odp_presentation_writer', 'odp_table_fidelity', 'odf_covered_cell_extraction', 'odf_annotation_extraction', 'office_search_fidelity', 'odf_export_text_fidelity', 'ods_sheet_reader', 'ods_sheet_writer']
commands = [
    ('engine-analysis', [DART, 'analyze', '--fatal-infos', 'lib', 'test', 'tool']),
    ('affected-odf-search-ods-vm', [DART, 'test', '--reporter=expanded', '--concurrency=4', *[f'test/{name}_test.dart' for name in tests]]),
]
try:
    for label, command in commands:
        print('START ' + label, flush=True)
        log = OUT / (label + '.log')
        start = time.monotonic()
        with log.open('wb') as stream:
            result = subprocess.run([str(arg) for arg in command], cwd=cwd, stdout=stream, stderr=subprocess.STDOUT, timeout=600)
        record['commands'].append({'label': label, 'argv': [str(arg) for arg in command], 'cwd': str(cwd), 'exit_code': result.returncode, 'seconds': round(time.monotonic() - start, 3), 'log': log.name, 'log_sha256': sha(log)})
        (OUT / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
        print('END ' + label + ' ' + str(result.returncode), flush=True)
        if result.returncode:
            print(log.read_text(errors='replace')[-8000:], flush=True)
            break
finally:
    after = snapshot()
    (OUT / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    record['source_after_sha256'] = sha(OUT / 'source-after.json')
    record['source_unchanged'] = before == after
    record['changed_source_inputs'] = [path for path in before.keys() | after.keys() if before.get(path) != after.get(path)]
    record['passed'] = len(record['commands']) == len(commands) and all(item['exit_code'] == 0 for item in record['commands']) and record['source_unchanged']
    record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    (OUT / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'passed': record['passed'], 'source_unchanged': record['source_unchanged'], 'command_count': len(record['commands']), 'changed_from_previous_fixed_source_count': len(differences)}), flush=True)
raise SystemExit(0 if record['passed'] else 1)
