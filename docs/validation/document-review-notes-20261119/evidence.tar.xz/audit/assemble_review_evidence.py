"""Preserve the completed review gate and its original setup/diagnostic evidence."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    workspace, output = args.workspace.resolve(), args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise RuntimeError('Preserve earlier publication output; choose an empty directory')
    output.mkdir(parents=True, exist_ok=True)
    files: dict[str, tuple[Path, bytes]] = {}

    def add(path: Path, name: str) -> None:
        if not path.is_file() or path.is_symlink():
            raise RuntimeError('Expected an original regular evidence file: ' + str(path))
        if name in files:
            raise RuntimeError('Duplicate archive path: ' + name)
        files[name] = path, path.read_bytes()

    def directory(path: Path, prefix: str) -> None:
        for source in sorted(path.rglob('*')):
            if source.is_file() and '__pycache__' not in source.parts:
                add(source, prefix + '/' + source.relative_to(path).as_posix())

    checks = workspace / 'continuation_checks'
    receipt = json.loads((checks / 'final/verification.json').read_text())
    if receipt.get('success') is not True:
        raise RuntimeError('The final product gate has not passed')
    directory(checks / 'final', 'final')
    add(checks / 'gate-launch.log', 'final/outer-process.log')
    for name in ('baseline-prefetch.json', 'baseline-prefetch.log', 'missing-baseline-blobs.txt'):
        add(checks / name, 'final/git-materialization/' + name)
    directory(checks / 'python', 'python')
    directory(checks / 'screenshots', 'screenshots')
    directory(workspace / 'runtime-controls', 'runtime-controls')

    runtime = workspace / 'toolchains-fresh'
    for name in ('runtime.json', 'retained-inputs.json', 'pub-cache-receipt.json',
                 'cache-omissions.json', 'archive-members.json', 'env.sh',
                 'bin/dart', 'bin/flutter'):
        add(runtime / name, 'runtime-fresh/' + name)
    directory(runtime / 'logs', 'runtime-fresh/logs')
    add(workspace / 'toolchains-fresh-restore.log', 'runtime-fresh/outer-process.log')
    add(workspace / 'quds_office_suite/.dart_tool/native_assets.yaml',
        'runtime-fresh/native_assets.yaml')
    old = workspace / 'toolchains'
    for path in sorted(old.glob('*.json')):
        add(path, 'runtime-initial/' + path.name)
    directory(old / 'logs', 'runtime-initial/logs')
    add(old / 'diagnostic-native-outputs.tar.xz', 'runtime-initial/diagnostic-native-outputs.tar.xz')

    add(workspace / 'ref-audit/qualified-source-audit.json', 'incoming/qualified-source-audit.json')
    for name in ('final-head-inspection.json', 'final-tip-review.json'):
        add(workspace / 'ref-audit' / name, 'incoming/' + name)
    audit = workspace / 'evidence_audit'
    for name in ('continuation-gate-audit.json', 'audit_continuation_gate.py'):
        add(audit / name, 'audit/' + name)
    directory(audit / 'runtime_provenance', 'audit/runtime_provenance')
    for source in sorted(audit.glob('*.json')):
        if 'audit/' + source.name not in files:
            add(source, 'audit/' + source.name)
    add(Path(__file__).resolve(), 'audit/assemble_review_evidence.py')
    add(checks / 'publication-checkpoints.json', 'audit/publication-checkpoints.json')
    if (checks / 'visual-review.json').exists():
        add(checks / 'visual-review.json', 'screenshots/visual-review.json')

    index = {
        'schema': 1,
        'source_commit': receipt['source_commit'],
        'scope': 'Original completed gate, runtime provenance, failed setup/fixture attempts, independent audits and screenshots; repeated attempts are not added to accepted totals.',
        'files': {name: {'bytes': len(data), 'sha256': digest(data)}
                  for name, (_, data) in sorted(files.items())},
    }
    archive_path = output / 'evidence.tar.xz'
    with tarfile.open(archive_path, mode='w:xz', preset=6) as archive:
        for name, (_, data) in sorted(files.items()):
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
            archive.addfile(entry, io.BytesIO(data))
    archived = {}
    with tarfile.open(archive_path, mode='r:xz') as archive:
        for entry in archive:
            if not entry.isfile() or entry.name in archived:
                raise RuntimeError('Unexpected or duplicate archive entry')
            data = archive.extractfile(entry).read()
            if data != files[entry.name][1]:
                raise RuntimeError('Archive read-back differs from original bytes: ' + entry.name)
            archived[entry.name] = digest(data)
    if set(archived) != set(files):
        raise RuntimeError('Archive file inventory differs')
    for name, (path, data) in files.items():
        if path.read_bytes() != data:
            raise RuntimeError('Original evidence changed during assembly: ' + name)
    archive_data = archive_path.read_bytes()
    index['archive'] = {'path': archive_path.name, 'bytes': len(archive_data),
                        'sha256': digest(archive_data), 'member_count': len(files),
                        'uncompressed_bytes': sum(len(data) for _, data in files.values())}
    index['verification'] = {'all_members_match_original_bytes': True,
                             'original_inputs_unchanged_during_assembly': True}
    (output / 'evidence-index.json').write_text(json.dumps(index, indent=2) + '\n')
    print(json.dumps(index['archive'], indent=2))


if __name__ == '__main__':
    main()
