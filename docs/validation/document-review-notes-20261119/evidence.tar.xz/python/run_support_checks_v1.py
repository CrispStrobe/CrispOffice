#!/usr/bin/env python3
"""Run existing Python harness tests once per target and preserve raw evidence."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/workspace/scratch/55e682a034c1/quds_office_suite')
OUT = Path(__file__).resolve().parent
NOTES = 'docs/validation/document-review-notes-20261118'
FIXTURE = 'docs/validation/thesaurus-20261118/continuation/local/fixtures'
ZOTERO = 'docs/validation/zotero-word-parity-20261118'
TARGETS = {
    'notes-runner': (NOTES, 'test_run_checks.py', [NOTES + '/run_checks.py']),
    'mail-runner': ('tools/mail', 'test_check_store.py', ['tools/mail/check_store.py', 'tools/mail/check_reader.py']),
    'thesaurus-browser': (FIXTURE, 'test_browser_harness.py', [
        *(FIXTURE + '/' + name for name in [
            'lib/main.dart', 'native_pack_test.dart', 'native_visual_test.dart',
            'install_offline.py', 'run_browser.py', 'run_final_validation.py',
            'test_browser_harness.py', 'build_binding.py', 'workspace_binding.py',
            'test_workspace_binding.py']),
        'tools/thesaurus/build_packs.py', 'tools/thesaurus/export_review_packet.py']),
    'thesaurus-workspace': (FIXTURE, 'test_workspace_binding.py', [
        FIXTURE + '/workspace_binding.py',
        'docs/validation/thesaurus-20261118/continuation/local/runtime/prepare_workspace.py']),
    'zotero-runner': (ZOTERO, 'test_run_local.py', [ZOTERO + '/run_local.py']),
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def snapshot(paths):
    return {name: {'bytes': (ROOT / name).stat().st_size,
                   'sha256': sha((ROOT / name).read_bytes())}
            for name in sorted(set(paths))}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    failures = []
    for name in sys.argv[1:]:
        directory, test, imports = TARGETS[name]
        target = OUT / name
        target.mkdir(parents=True, exist_ok=False)
        temporary = target / 'tmp'
        temporary.mkdir()
        paths = [directory + '/' + test, *imports]
        before = snapshot(paths)
        (target / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
        command = [sys.executable, '-B', '-m', 'unittest', 'discover',
                   '-s', str(ROOT / directory), '-p', test, '-v']
        start = now()
        environment = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': str(temporary)}
        with (target / 'raw.log').open('wb') as output:
            result = subprocess.run(command, cwd=OUT, env=environment,
                                    stdout=output, stderr=subprocess.STDOUT)
        end = now()
        after = snapshot(paths)
        (target / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
        raw = (target / 'raw.log').read_bytes()
        log = raw.decode('utf-8', errors='replace')
        cases = []
        for line in log.splitlines():
            match = re.fullmatch(r'(test_\S+) \(([^\n]+)\) \.\.\. (.+)', line)
            if match:
                cases.append({'id': match[2] + '.' + match[1], 'result': match[3]})
        terminal_counts = re.findall(r'^Ran (\d+) tests? in [^\n]+$', log, re.MULTILINE)
        valid = (result.returncode == 0 and len(terminal_counts) == 1
                 and int(terminal_counts[0]) == len(cases) and len(cases) > 0
                 and len({case['id'] for case in cases}) == len(cases)
                 and all(case['result'] == 'ok' for case in cases)
                 and log.rstrip().endswith('\nOK') and before == after)
        receipt = {'schema': 1, 'target': name, 'command': command, 'cwd': str(OUT),
                   'started_at_utc': start, 'finished_at_utc': end,
                   'exit_code': result.returncode, 'raw_log_sha256': sha(raw),
                   'source_unchanged': before == after, 'actual_cases': len(cases),
                   'reported_counts': terminal_counts, 'cases': cases, 'passed': valid,
                   'python_version': sys.version, 'python_executable': sys.executable,
                   'python_executable_sha256': sha(Path(sys.executable).read_bytes()),
                   'runner_sha256': sha(Path(__file__).read_bytes()),
                   'scope': 'Existing Python unit tests; no Dart/Flutter process or browser application was executed.'}
        (target / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        print(json.dumps({key: receipt[key] for key in
                          ['target', 'exit_code', 'actual_cases', 'source_unchanged', 'passed']}), flush=True)
        if not valid:
            failures.append(name)
    return bool(failures)


if __name__ == '__main__':
    raise SystemExit(main())
