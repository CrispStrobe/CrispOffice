#!/usr/bin/env python3
"""Independently recount preserved unittest output without rerunning tests."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/scratch/55e682a034c1/quds_office_suite')
OUT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def recount(receipt_path):
    receipt = json.loads(receipt_path.read_text())
    raw = (receipt_path.parent / 'raw.log').read_bytes()
    assert sha(raw) == receipt['raw_log_sha256']
    log = raw.decode()
    cases = [m.groups() for m in re.finditer(
        r'^(test_\S+) \(([^\n]+)\) \.\.\. (.+)$', log, re.MULTILINE)]
    totals = re.findall(r'^Ran (\d+) tests? in ', log, re.MULTILINE)
    assert len(totals) == 1 and int(totals[0]) == len(cases) == receipt['actual_cases']
    return receipt, raw, log, cases


def main():
    head = git('rev-parse', 'HEAD')
    summary = {
        'schema': 2,
        'scope': ('Existing Python unittest targets on integrated source; actual distinct '
                  'unittest cases, subtest loops not inflated. Includes one Node worker '
                  'control invoked by the Python browser harness. No Dart/Flutter or '
                  'browser application run. Failed diagnostic attempts stay separate.'),
        'targets': [], 'case_ids': [], 'source_inputs': {}, 'git_blobs': {},
        'current_head_at_aggregation': head, 'excluded_attempts': [],
    }
    for receipt_path in sorted(OUT.glob('*/receipt.json')):
        receipt, raw, log, cases = recount(receipt_path)
        assert receipt['passed'] and receipt['exit_code'] == 0
        assert all(case[2] == 'ok' for case in cases) and log.rstrip().endswith('\nOK')
        before = json.loads((receipt_path.parent / 'source-before.json').read_text())
        after = json.loads((receipt_path.parent / 'source-after.json').read_text())
        assert before == after
        assert all(sha((ROOT / path).read_bytes()) == data['sha256']
                   for path, data in before.items())
        for path, data in before.items():
            assert path not in summary['source_inputs'] or summary['source_inputs'][path] == data
            summary['source_inputs'][path] = data
        identities = [f"{receipt['target']}::{case[1]}.{case[0]}" for case in cases]
        summary['case_ids'].extend(identities)
        summary['targets'].append({
            'name': receipt['target'], 'actual_cases': len(cases), 'exit_code': 0,
            'source_unchanged': True, 'matches_current_merged_inputs': True,
            'receipt': str(receipt_path.relative_to(OUT)),
            'receipt_sha256': sha(receipt_path.read_bytes()),
            'log': str((receipt_path.parent / 'raw.log').relative_to(OUT)),
            'log_sha256': sha(raw),
        })
    for receipt_path in sorted((OUT / 'attempts').glob('*/receipt.json')):
        receipt, raw, log, cases = recount(receipt_path)
        summary['excluded_attempts'].append({
            'target': receipt['target'], 'receipt': str(receipt_path.relative_to(OUT)),
            'exit_code': receipt['exit_code'], 'actual_cases': len(cases),
            'passing_cases': sum(case[2] == 'ok' for case in cases),
            'nonpassing_cases': [{'id': case[1] + '.' + case[0], 'result': case[2]}
                                 for case in cases if case[2] != 'ok'],
            'raw_log_sha256': sha(raw),
            'reason': 'Diagnostic attempt before bounded termination observation repair; excluded entirely from accepted totals.',
        })
    assert len(summary['case_ids']) == len(set(summary['case_ids']))
    summary.update(actual_cases=len(summary['case_ids']), failed=0, skipped=0,
                   all_passed=True, bound_input_count=len(summary['source_inputs']))
    matching_head, differing_head = [], []
    for path in summary['source_inputs']:
        blob = git('hash-object', '--', path)
        summary['git_blobs'][path] = blob
        if git('rev-parse', head + ':' + path) == blob:
            matching_head.append(path)
        else:
            differing_head.append(path)
    summary['source_commit_binding'] = {
        'head': head, 'matching_input_count': len(matching_head),
        'working_tree_inputs_differing_from_head': differing_head,
        'all_inputs_match_head': not differing_head,
    }
    summary['aggregation_script_sha256'] = sha(Path(__file__).read_bytes())
    previous = OUT / 'independent-summary.json'
    backup = OUT / 'independent-summary-129.json'
    if previous.exists() and not backup.exists():
        backup.write_bytes(previous.read_bytes())
    previous.write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({key: summary[key] for key in (
        'actual_cases', 'failed', 'skipped', 'bound_input_count',
        'source_commit_binding', 'excluded_attempts')}, indent=2))


if __name__ == '__main__':
    main()
