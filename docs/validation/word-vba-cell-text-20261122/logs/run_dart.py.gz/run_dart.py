from pathlib import Path
import json
import os
import subprocess
import sys
import time

from sync_validation import BASE, SOURCE, TARGET, sync

RUNTIME = BASE / 'toolchain'
DART = RUNTIME / 'dart-sdk/bin/dart'

def environment():
    env = os.environ.copy()
    env.update({
        'PUB_CACHE': str(RUNTIME / 'pub-cache'),
        'TMPDIR': str(RUNTIME / 'tmp'),
        'DART_SUPPRESS_ANALYTICS': 'true',
        'CI': 'true',
        'PATH': str(DART.parent) + os.pathsep + env.get('PATH', ''),
    })
    return env


if __name__ == '__main__':
    if len(sys.argv) < 3:
        raise SystemExit('Usage: python3 toolchain/run_dart.py LABEL test/analyze/run/compile ARGS...')
    label = sys.argv[1]
    changed, manifest = sync()
    output = BASE / 'validation-results'
    output.mkdir(exist_ok=True)
    (output / (label + '.source-manifest.json')).write_text(json.dumps(manifest, sort_keys=True, indent=2)+'\n')
    command = [str(DART), *sys.argv[2:]]
    cwd = TARGET / 'packages/quds_office_engine'
    started = time.time()
    print(json.dumps({'label': label, 'command': command, 'cwd': str(cwd), 'source_files': len(manifest), 'changed_files': len(changed)}), flush=True)
    with (output / (label + '.stdout.log')).open('w') as out, (output / (label + '.stderr.log')).open('w') as err:
        result = subprocess.run(command, cwd=cwd, env=environment(), stdout=out, stderr=err)
    receipt = {'label': label, 'command': command, 'cwd': str(cwd), 'exit_code': result.returncode, 'seconds': round(time.time()-started,2), 'source_manifest': str(output / (label + '.source-manifest.json')), 'stdout': str(output / (label + '.stdout.log')), 'stderr': str(output / (label + '.stderr.log'))}
    events = []
    for line in (output / (label + '.stdout.log')).read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(event, dict):
            events.append(event)
    starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    finished = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden')]
    if finished:
        receipt.update({'passed': sum(e['result']=='success' and not e.get('skipped') for e in finished), 'failed': sum(e['result']!='success' for e in finished), 'skipped': sum(bool(e.get('skipped')) for e in finished), 'failed_tests': [starts.get(e['testID'], {}) for e in finished if e['result']!='success'], 'errors': [e for e in events if e.get('type')=='error']})
    (output / (label + '.receipt.json')).write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt, indent=2), flush=True)
    if not finished:
        print((output / (label + '.stdout.log')).read_text()[-10000:])
        print((output / (label + '.stderr.log')).read_text()[-5000:])
    sys.exit(result.returncode)
