from pathlib import Path
import base64, hashlib, json, shutil, subprocess, sys, time
from run_dart import environment, BASE, TARGET, DART
from sync_validation import sync
label='final-cell-text-controls-portable'; output=BASE/'validation-results'; output.mkdir(exist_ok=True)
changed,manifest=sync(); (output/(label+'.source-manifest.json')).write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
package=TARGET/'packages/quds_office_engine'; env=environment(); node=shutil.which('node',path=env['PATH']); assert node
source=package/'example/macros/word_table_text_controls.bas'; source_bytes=source.read_bytes(); define='-DWORD_CELL_TEXT_BAS_BASE64='+base64.b64encode(source_bytes).decode(); runner='tool/macros/web_vba_word_cell_text_controls_smoke.dart'; js=output/(label+'.js')
commands=[('vm',[str(DART),define,runner]),('compile-js',[str(DART),'compile','js','-O1',define,runner,'-o',str(js)]),('node',[node,'-e','globalThis.self = globalThis; require(process.argv[1]);',str(js)])]
summary={'source':str(source),'source_sha256':hashlib.sha256(source_bytes).hexdigest(),'runtime':str(DART),'node':node,'node_version':subprocess.check_output([node,'--version'],text=True).strip(),'cwd':str(package),'source_manifest':str(output/(label+'.source-manifest.json')),'stages':[]}
for stage,command in commands:
    start=time.time(); stdout=output/(label+'-'+stage+'.stdout.log'); stderr=output/(label+'-'+stage+'.stderr.log')
    with stdout.open('w') as out, stderr.open('w') as err: result=subprocess.run(command,cwd=package,env=env,stdout=out,stderr=err)
    record={'stage':stage,'exit_code':result.returncode,'seconds':round(time.time()-start,2),'command':[part if part!=define else '-DWORD_CELL_TEXT_BAS_BASE64=<base64 of actual word_table_text_controls.bas>' for part in command],'stdout':str(stdout),'stderr':str(stderr)};summary['stages'].append(record);print(json.dumps(record),flush=True)
    if result.returncode:
        print(stderr.read_text()[-6000:]); (output/(label+'.receipt.json')).write_text(json.dumps(summary,indent=2)+'\n');sys.exit(result.returncode)
def equivalent(a,b):
    if isinstance(a,bool) or isinstance(b,bool): return isinstance(a,bool) and isinstance(b,bool) and a is b
    if isinstance(a,(int,float)) and isinstance(b,(int,float)): return a==b
    if isinstance(a,dict) and isinstance(b,dict): return a.keys()==b.keys() and all(equivalent(a[k],b[k]) for k in a)
    if isinstance(a,list) and isinstance(b,list): return len(a)==len(b) and all(equivalent(x,y) for x,y in zip(a,b))
    return type(a) is type(b) and a==b
vm=(output/(label+'-vm.stdout.log')).read_bytes(); javascript=(output/(label+'-node.stdout.log')).read_bytes();vm_json=json.loads(vm); js_json=json.loads(javascript)
summary.update({'vm_js_byte_identical':vm==javascript,'vm_js_structurally_equivalent':equivalent(vm_json,js_json),'source_unchanged':source.read_bytes()==source_bytes,'vm_result':vm_json,'js_result':js_json})
(output/(label+'.receipt.json')).write_text(json.dumps(summary,indent=2)+'\n'); print(json.dumps({k:v for k,v in summary.items() if k not in ('stages','vm_result','js_result')},indent=2));print(json.dumps({'operations':vm_json.get('operations'),'recordedSteps':vm_json.get('recordedSteps'),'additionalReopens':vm_json.get('additionalReopens'),'lateRollback':vm_json.get('lateRollback'),'opaqueVbaPreserved':vm_json.get('opaqueVbaPreserved')}))
assert summary['vm_js_structurally_equivalent'];assert summary['source_unchanged']
