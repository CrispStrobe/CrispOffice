from pathlib import Path
import hashlib
import json
import shutil
import sys

BASE = Path('/workspace/scratch/f21b0fe576fb')
SOURCE = BASE / 'quds_office_suite'
TARGET = BASE / 'engine-validation'
PATHS = (
    'packages/quds_office_engine',
    'packages/legacy_doc_parser',
    'packages/quds_office_editor/fonts',
)
SKIP = {'.dart_tool', 'build', '.git'}


def sync():
    changed = []
    manifest = {}
    for root in PATHS:
        for source in (SOURCE / root).rglob('*'):
            relative = source.relative_to(SOURCE)
            if any(part in SKIP for part in relative.parts) or not source.is_file():
                continue
            target = TARGET / relative
            contents = source.read_bytes()
            manifest[relative.as_posix()] = hashlib.sha256(contents).hexdigest()
            if not target.exists() or target.read_bytes() != contents:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
                changed.append(relative.as_posix())
        for target in (TARGET / root).rglob('*'):
            relative = target.relative_to(TARGET)
            if any(part in SKIP for part in relative.parts) or not target.is_file():
                continue
            if not (SOURCE / relative).exists():
                target.unlink()
                changed.append('-' + relative.as_posix())
    shutil.copy2(SOURCE / 'analysis_options.yaml', TARGET / 'analysis_options.yaml')
    (BASE / 'toolchain' / 'latest-source-manifest.json').write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + '\n'
    )
    return changed, manifest


if __name__ == '__main__':
    changed, manifest = sync()
    print(json.dumps({'files': len(manifest), 'changed': changed}, indent=2))
