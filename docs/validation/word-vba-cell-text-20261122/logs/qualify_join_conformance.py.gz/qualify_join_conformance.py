from pathlib import Path
import base64, hashlib, json, shutil, subprocess, sys, time
from run_dart import environment, BASE, TARGET, DART
from sync_validation import sync
label='join-conformance-portable'; output=BASE/'validation-results'; output.mkdir(exist_ok=True)
changed,manifest=sync(); (output/(label+'.source-manifest.json')).write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
package=TARGET/'packages/quds_office_engine'; env=environment(); node=shutil.which('node',path=env['PATH']); assert node
fixture=package/'test/fixtures/vba_conformance/word_join_v1.json'; fixture_bytes=fixture.read_bytes(); define='-DVBA_CONFORMANCE_BASE64='+base64.b64encode(fixture_bytes).decode(); runner='tool/macros/web_vba_join_conformance.dart'; js=output/(label+'.js')
commands=[('vm',[str(DART),define,runner]),('compile-js',[str(DART),'compile','js','-O1',define,runner,'-o',str(js)]),('node',[node,'-e','globalThis.self = globalThis; require(process.argv[1]);',str(js)])]
summary={'fixture':str(fixture),'fixture_sha256':hashlib.sha256(fixture_bytes).hexdigest(),'runtime':str(DART),'node':node,'cwd':str(package),'source_manifest':str(output/(label+'.source-manifest.json')),'stages':[]}
for stage,command in commands:
    start=time.time(); stdout=output/(label+'-'+stage+'.stdout.log'); stderr=output/(label+'-'+stage+'.stderr.log')
    with stdout.open('w') as out, stderr.open('w') as err: result=subprocess.run(command,cwd=package,env=env,stdout=out,stderr=err)
    record={'stage':stage,'exit_code':result.returncode,'seconds':round(time.time()-start,2),'command':[part if part!=define else '-DVBA_CONFORMANCE_BASE64=<base64 of canonical word_join_v1.json>' for part in command],'stdout':str(stdout),'stderr':str(stderr)};summary['stages'].append(record);print(json.dumps(record),flush=True)
    if result.returncode:
        print(stderr.read_text()[-5000:]); (output/(label+'.receipt.json')).write_text(json.dumps(summary,indent=2)+'\n');sys.exit(result.returncode)
vm=(output/(label+'-vm.stdout.log')).read_bytes(); javascript=(output/(label+'-node.stdout.log')).read_bytes();summary['vm_js_byte_identical']=vm==javascript; summary['case_count']=json.loads(vm)['caseCount'];summary['fixture_unchanged']=fixture.read_bytes()==fixture_bytes
(output/(label+'.receipt.json')).write_text(json.dumps(summary,indent=2)+'\n'); print(json.dumps({k:v for k,v in summary.items() if k!='stages'},indent=2));assert summary['vm_js_byte_identical'];assert summary['fixture_unchanged'];assert summary['case_count']==25
