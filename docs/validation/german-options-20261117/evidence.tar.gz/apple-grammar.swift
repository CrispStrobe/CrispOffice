import AppKit
import Foundation
func jsonValue(_ value: Any) -> Any {
 if value is String || value is NSNumber || value is NSNull { return value }
 if let items = value as? [String: Any] { return items.mapValues(jsonValue) }
 if let items = value as? [Any] { return items.map(jsonValue) }
 if let item = value as? NSValue { return [item.rangeValue.location, item.rangeValue.length] }
 return String(describing: value)
}
let checker = NSSpellChecker.shared
let tag = NSSpellChecker.uniqueSpellDocumentTag()
defer { checker.closeSpellDocument(withTag: tag) }
let file = URL(fileURLWithPath: CommandLine.arguments[1])
let language = CommandLine.arguments.count > 2 ? CommandLine.arguments[2] : "de"
let samples = try JSONSerialization.jsonObject(with: Data(contentsOf: file)) as! [[String: Any]]
var results = [[String: Any]]()
for sample in samples {
 let text = sample["text"] as! String
 var details: NSArray?
 let started = Date()
 let range = checker.checkGrammar(of: text, startingAt: 0, language: language, wrap: false, inSpellDocumentWithTag: tag, details: &details)
 let spelling = checker.checkSpelling(of: text, startingAt: 0, language: language, wrap: false, inSpellDocumentWithTag: tag, wordCount: nil)
 results.append(["spelling_found": spelling.location != NSNotFound,"id": sample["id"]!, "text": text, "expected": sample["expected"] ?? text, "grammar_found": range.location != NSNotFound, "range": [range.location,range.length], "details": jsonValue(details ?? []), "milliseconds": Date().timeIntervalSince(started)*1000])
}
let payload: [String: Any] = ["platform": ProcessInfo.processInfo.operatingSystemVersionString, "api": "NSSpellChecker.checkGrammar", "language": language, "available_languages": checker.availableLanguages, "results": results]
let output = try JSONSerialization.data(withJSONObject: payload, options: [.prettyPrinted,.sortedKeys])
FileHandle.standardOutput.write(output)
