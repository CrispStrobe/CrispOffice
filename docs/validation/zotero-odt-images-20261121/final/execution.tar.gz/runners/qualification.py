#!/usr/bin/env python3
"""Local bounded Zotero/ODT qualification; never accesses GitHub Actions."""
import concurrent.futures, datetime, hashlib, json, os, pathlib, subprocess, sys, time
ROOT=pathlib.Path('/workspace/scratch/81e9cddb3100/quds_office_suite')
OUT=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '/workspace/scratch/81e9cddb3100/qualification/final')
OUT.mkdir(parents=True,exist_ok=False)
ENGINE=ROOT/'packages/quds_office_engine'
EDITOR=ROOT/'packages/quds_office_editor'
STUDIO=EDITOR/'example'
TEST_ENTRY='/workspace/scratch/81e9cddb3100/runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'

def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def inputs():
    files=[]
    for name in git('ls-files').splitlines():
        p=ROOT/name
        if not p.is_file(): continue
        if ('/lib/' in name and name.startswith(('packages/','third_party/'))) or name.endswith(('pubspec.yaml','pubspec.lock')) or name.startswith(('packages/quds_office_engine/test/','packages/quds_office_editor/test/','packages/quds_office_editor/example/lib/','packages/quds_office_editor/example/test/')):
            files.append(p)
    for p in ROOT.glob('packages/quds_office_engine/lib/**/*.dart'):
        if p not in files: files.append(p)
    for p in ROOT.glob('packages/*/test/*odt*test.dart'):
        if p not in files: files.append(p)
    files.extend([ROOT/'.dart_tool/package_config.json', ENGINE/'tool/zotero/odt_image_acceptance.dart'])
    return {str(p.relative_to(ROOT)):digest(p) for p in sorted(set(files)) if p.is_file()}
def save(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n')

def run(name,command,cwd,tests=False):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    print('START '+name,flush=True)
    with (OUT/(name+'.stdout')).open('wb') as out, (OUT/(name+'.stderr')).open('wb') as err:
        result=subprocess.run(command,cwd=cwd,stdout=out,stderr=err)
    record={'name':name,'command':command,'cwd':str(cwd),'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode,'stdout_sha256':digest(OUT/(name+'.stdout')),'stderr_sha256':digest(OUT/(name+'.stderr'))}
    if tests:
        starts={}; complete=[]; errors=[]; done=[]
        for line in (OUT/(name+'.stdout')).read_text().splitlines():
            try: e=json.loads(line)
            except ValueError: continue
            if e.get('type')=='testStart': starts[e['test']['id']]=e['test']
            elif e.get('type')=='testDone' and not e.get('hidden',False): complete.append(e)
            elif e.get('type')=='error': errors.append(e)
            elif e.get('type')=='done': done.append(e)
        record['tests']={'passed':sum(e.get('result')=='success' and not e.get('skipped',False) for e in complete),'failed':sum(e.get('result')!='success' for e in complete),'skipped':sum(e.get('skipped',False) for e in complete),'errors':len(errors),'terminal':done,'cases':[{'name':starts.get(e['testID'],{}).get('name'),'url':starts.get(e['testID'],{}).get('url'),'result':e['result'],'skipped':e.get('skipped',False)} for e in complete]}
        record['accepted']=result.returncode==0 and bool(done) and done[-1].get('success') is True and not errors and record['tests']['failed']==0
    else: record['accepted']=result.returncode==0
    save(name+'.json',record)
    print('END '+name+' '+json.dumps({'accepted':record['accepted'],'exit_code':result.returncode,'tests':{k:v for k,v in record.get('tests',{}).items() if k!='cases'}}),flush=True)
    return record

before=inputs(); save('inputs-before.json',before)
save('source.json',{'head':git('rev-parse','HEAD'),'tree':git('write-tree'),'status':git('status','--short'),'time':datetime.datetime.now(datetime.timezone.utc).isoformat()})
engine=sorted({str(p.relative_to(ENGINE)) for glob in ['odt_*test.dart','odf_zotero_*test.dart','word_zotero_note_image*test.dart','zotero_citing_test.dart','word_zotero_citing_test.dart'] for p in (ENGINE/'test').glob(glob)})
editor=['test/word_odt_image_load_test.dart','test/word_odt_load_test.dart','test/word_odt_merged_table_load_test.dart','test/word_zotero_note_image_controller_test.dart']
studio=['test/studio_zotero_odt_export_test.dart','test/studio_odt_open_test.dart','test/studio_zotero_shortcuts_test.dart','test/studio_zotero_citing_transport_test.dart']
# Keep explicit suite selection available for auditing.
save('selection.json',{'engine':engine,'editor':editor,'studio':studio})
commands=[('engine',['dart','--packages='+str(ROOT/'.dart_tool/package_config.json'),TEST_ENTRY,'--reporter','json','--concurrency','4',*engine],ENGINE,True),('editor',['flutter','test','--no-pub','--reporter','json','--concurrency=2',*editor],EDITOR,True)]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    records=list(pool.map(lambda args:run(*args),commands))
records.append(run('studio',['flutter','test','--no-pub','--reporter','json','--concurrency=2',*studio],STUDIO,True))
changed=[p for p in git('diff','--name-only','4970f71f983535d045ce263e86835b499db4fda9').splitlines() if p.endswith('.dart')]
changed.extend(p for p in git('ls-files','--others','--exclude-standard').splitlines() if p.endswith('.dart'))
changed=sorted(set(changed))
records.append(run('format',['dart','format','--output=none','--set-exit-if-changed',*changed],ROOT))
records.append(run('analyze',['dart','analyze','--fatal-infos',*changed],ROOT))
after=inputs(); save('inputs-after.json',after)
delta=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
summary={'source_unchanged':not delta,'changed_inputs':delta,'input_count':len(before),'accepted':not delta and all(r['accepted'] for r in records),'gates':[{k:v for k,v in r.items() if k!='tests'}|({'tests':{k:v for k,v in r['tests'].items() if k!='cases'}} if 'tests' in r else {}) for r in records]}
save('summary.json',summary)
print(json.dumps(summary,indent=2),flush=True)
sys.exit(0 if summary['accepted'] else 1)
