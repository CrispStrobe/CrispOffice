#!/usr/bin/env python3
"""Record fresh, unmodified LibreOffice ODT conversion acceptance evidence."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

ROOT = Path('/workspace/scratch/81e9cddb3100')
REPO = ROOT / 'quds_office_suite'
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'image-converter' / 'final'
TOOL = REPO / 'packages/quds_office_engine/tool/zotero/odt_image_acceptance.dart'
NAMES = ['png-citations', 'jpeg-citations']


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    sha = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            sha.update(chunk)
    return sha.hexdigest()


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def source_snapshot():
    paths = sorted((REPO / 'packages/quds_office_engine/lib').rglob('*'))
    paths = [path for path in paths if path.is_file()] + [TOOL]
    return {
        'captured_at_utc': now(),
        'files': {
            str(path.relative_to(REPO)): {
                'sha256': digest(path),
                'size': path.stat().st_size,
            }
            for path in paths
        },
    }


def artifact_snapshot(directories):
    return {
        str(path.relative_to(OUT)): {
            'sha256': digest(path),
            'size': path.stat().st_size,
        }
        for name in directories
        for path in sorted((OUT / name).rglob('*'))
        if path.is_file()
    }


OUT.mkdir(exist_ok=False)
(OUT / 'saved').mkdir()
receipt = {
    'started_at_utc': now(),
    'cwd': str(REPO),
    'environment_setup': f'source {ROOT / "runtime/env.sh"}',
    'environment': {
        key: os.environ.get(key)
        for key in ['FLUTTER_ROOT', 'PUB_CACHE', 'TMPDIR', 'XDG_CONFIG_HOME',
                    'XDG_DATA_HOME', 'XDG_CACHE_HOME', 'CI',
                    'DART_SUPPRESS_ANALYTICS', 'FLUTTER_SUPPRESS_ANALYTICS']
    },
    'commands': [],
    'accepted': False,
}
dart = str(Path(shutil.which('dart')).absolute())
soffice = Path(shutil.which('soffice')).absolute()
launcher = (soffice.parent / '../../native/libreoffice-headless/libreoffice/program/soffice').resolve()
binary = launcher.with_name('soffice.bin')
receipt['converter_executables'] = {
    kind: {'path': str(path), 'sha256': digest(path), 'size': path.stat().st_size}
    for kind, path in [('invoked_wrapper', soffice), ('launcher', launcher), ('binary', binary)]
}
save_json(OUT / 'receipt.json', receipt)


def run(label, argv):
    record = {
        'label': label,
        'argv': argv,
        'shell_quoted_argv': shlex.join(argv),
        'cwd': str(REPO),
        'started_at_utc': now(),
        'stdout': f'{label}.stdout.log',
        'stderr': f'{label}.stderr.log',
    }
    receipt['commands'].append(record)
    save_json(OUT / 'receipt.json', receipt)
    print(json.dumps({'started': label, 'at': record['started_at_utc']}), flush=True)
    with (OUT / record['stdout']).open('wb') as stdout, (OUT / record['stderr']).open('wb') as stderr:
        try:
            process = subprocess.run(argv, cwd=REPO, stdout=stdout, stderr=stderr, timeout=300, check=False)
            record['exit_status'] = process.returncode
        except subprocess.TimeoutExpired:
            record['exit_status'] = None
            record['error'] = 'Command timed out after 300 seconds'
            raise
        finally:
            record['finished_at_utc'] = now()
            save_json(OUT / 'receipt.json', receipt)
    print(json.dumps({'finished': label, 'exit_status': record['exit_status']}), flush=True)
    if record['exit_status'] != 0:
        raise RuntimeError(f'{label} failed with exit status {record["exit_status"]}')
    return (OUT / record['stdout']).read_text()


before = source_snapshot()
save_json(OUT / 'source-before.json', before)
try:
    receipt['converter_version'] = run('converter-version', [str(soffice), '--version']).strip()
    receipt['dart_version'] = run('dart-version', [dart, '--version']).strip()
    common = [dart, f'--packages={REPO / ".dart_tool/package_config.json"}', str(TOOL)]
    created_text = run('create', common + ['create', str(OUT / 'original')])
    receipt['create_results'] = [json.loads(line) for line in created_text.splitlines() if line.strip()]
    run('soffice-save', [
        str(soffice), '--headless', f'-env:UserInstallation={(OUT / "profile").as_uri()}',
        '--convert-to', 'odt', '--outdir', str(OUT / 'saved'),
        *[str(OUT / 'original' / f'{name}.odt') for name in NAMES],
    ])
    receipt['actual_saved_odt_files'] = sorted(path.name for path in (OUT / 'saved').glob('*.odt'))
    expected_saved = sorted(f'{name}.odt' for name in NAMES)
    if receipt['actual_saved_odt_files'] != expected_saved:
        raise RuntimeError('Converter did not save exactly the two expected ODT files')
    saved_before = artifact_snapshot(['saved'])
    save_json(OUT / 'saved-before-verification.json', saved_before)
    verified_text = run('verify', common + ['verify', str(OUT / 'saved'), str(OUT / 'original'), str(OUT / 'cycles')])
    results = [json.loads(line) for line in verified_text.splitlines() if line.strip()]
    receipt['verify_results'] = results
    receipt['both_verifier_lines_matched'] = (
        len(results) == 2
        and sorted(result.get('file', '') for result in results) == sorted(NAMES)
        and all(result.get('matched') is True for result in results)
    )
    receipt['saved_bytes_untouched'] = saved_before == artifact_snapshot(['saved'])
    if not receipt['both_verifier_lines_matched']:
        raise RuntimeError('Verifier did not return exactly two matched:true results')
    if not receipt['saved_bytes_untouched']:
        raise RuntimeError('Saved ODT bytes changed during verification')
except Exception as error:
    receipt['error'] = f'{type(error).__name__}: {error}'
finally:
    after = source_snapshot()
    save_json(OUT / 'source-after.json', after)
    receipt['source_unchanged'] = before['files'] == after['files']
    receipt['source_file_count'] = len(before['files'])
    artifacts = artifact_snapshot(['original', 'saved', 'cycles'])
    save_json(OUT / 'artifacts-sha256.json', artifacts)
    receipt['artifact_count'] = len(artifacts)
    receipt['accepted'] = (
        'error' not in receipt
        and receipt.get('both_verifier_lines_matched') is True
        and receipt.get('saved_bytes_untouched') is True
        and receipt['source_unchanged']
        and all(command.get('exit_status') == 0 for command in receipt['commands'])
    )
    receipt['finished_at_utc'] = now()
    save_json(OUT / 'receipt.json', receipt)
    (OUT / 'commands.txt').write_text('\n\n'.join(
        f'[{command["label"]}]\n'
        f'cwd: {command["cwd"]}\n'
        f'argv: {command["shell_quoted_argv"]}\n'
        f'exit_status: {command.get("exit_status")}\n'
        f'started_at_utc: {command["started_at_utc"]}\n'
        f'finished_at_utc: {command.get("finished_at_utc")}\n'
        for command in receipt['commands']
    ) + '\n')
    print(json.dumps({'accepted': receipt['accepted'], 'receipt': str(OUT / 'receipt.json'), 'error': receipt.get('error')}), flush=True)

sys.exit(0 if receipt['accepted'] else 1)
