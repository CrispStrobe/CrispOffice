#!/usr/bin/env python3
"""One focused rerun binding the incoming Word suites' additional source inputs."""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

ROOT = Path('/workspace/scratch/81e9cddb3100')
REPO = ROOT / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
OUT = ROOT / 'qualification/integration-word-binding'
EXPECTED_HEAD = 'ef05b99ec9bbf1d539181c8519eb41455d182603'
EXPECTED_TREE = 'ecbdd52a92fcba1f6bc1daf842faa8040ae9b380'
PRIOR = ROOT / 'qualification/integrated/inputs-before.json'
TEST_ENTRY = ROOT / 'runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
SUITES = [
    'test/office_macro_word_shading_test.dart',
    'test/office_vba_text_construction_test.dart',
    'test/office_vba_word_shading_integration_test.dart',
    'test/office_vba_word_shading_test.dart',
]
DIRECTORIES = [
    'packages/quds_office_engine/lib',
    'packages/quds_office_engine/test/support',
    'packages/quds_office_engine/example/macros',
    'packages/quds_office_engine/tool',
    'packages/quds_office_engine/bin',
    'bin',
]
CRITICAL_EXTRAS = [
    'packages/quds_office_engine/example/macros/word_shading.bas',
    'packages/quds_office_engine/example/macros/word_text_construction.bas',
    'packages/quds_office_engine/tool/macros/web_vba_word_shading_smoke.dart',
    'packages/quds_office_engine/tool/macros/web_vba_text_construction_smoke.dart',
    'packages/quds_office_engine/tool/macros/web_vba_word_text_smoke.dart',
    'packages/quds_office_engine/tool/macros/office_macro.dart',
]


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()


def source_state():
    return {
        'captured_at_utc': now(),
        'head': git('rev-parse', 'HEAD'),
        'tree': git('rev-parse', 'HEAD^{tree}'),
        'status': git('status', '--porcelain=v1'),
    }


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


prior = json.loads(PRIOR.read_text())
tree = {}
for record in subprocess.check_output(['git', 'ls-tree', '-r', '-z', EXPECTED_HEAD], cwd=REPO).split(b'\0'):
    if not record:
        continue
    header, name = record.split(b'\t', 1)
    mode, kind, oid = header.decode().split()
    tree[name.decode()] = {'mode': mode, 'type': kind, 'blob_id': oid}


def inputs():
    # Preserve all previously qualified transitive package and lock coverage.
    names = set(prior)
    names.update(str((ENGINE / suite).relative_to(REPO)) for suite in SUITES)
    names.add('.dart_tool/package_config.json')
    for prefix in DIRECTORIES:
        path = REPO / prefix
        if path.is_dir():
            names.update(str(file.relative_to(REPO)) for file in path.rglob('*') if file.is_file())
    # Include every tracked package manifest/lock previously included by the
    # integrated gate, as well as any newly present tracked manifest or lock.
    names.update(name for name in tree if name.endswith(('pubspec.yaml', 'pubspec.lock')))
    return {name: sha256(REPO / name) for name in sorted(names)}


def bind(manifest):
    rows = {}
    mismatches = []
    untracked = []
    for name, checksum in manifest.items():
        path = REPO / name
        payload = os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
        actual_oid = hashlib.sha1(b'blob ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()
        expected = tree.get(name)
        if expected is None:
            untracked.append(name)
            rows[name] = {'sha256': checksum, 'expected_git_blob_id': None, 'actual_git_blob_id': actual_oid, 'classification': 'runtime' if name == '.dart_tool/package_config.json' else 'unexpected_untracked'}
            continue
        matches = expected['type'] == 'blob' and actual_oid == expected['blob_id']
        rows[name] = {'sha256': checksum, 'expected_git_blob_id': expected['blob_id'], 'actual_git_blob_id': actual_oid, 'matches': matches}
        if not matches:
            mismatches.append(name)
    return rows, mismatches, untracked


OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'runner.py')
state_before = source_state()
save('source-before.json', state_before)
before = inputs()
save('inputs-before.json', before)
bindings_before, mismatches_before, untracked_before = bind(before)
extras = sorted(name for name in before if name not in prior and name in tree)
save('additional-tracked-paths.json', extras)
receipt = {
    'started_at_utc': now(),
    'head': state_before['head'],
    'tree': state_before['tree'],
    'expected_head': EXPECTED_HEAD,
    'expected_tree': EXPECTED_TREE,
    'clean_before': state_before['status'] == '',
    'command': [shutil.which('dart'), '--packages=' + str(REPO / '.dart_tool/package_config.json'), str(TEST_ENTRY), '--reporter', 'json', '--concurrency', '4', *SUITES],
    'cwd': str(ENGINE),
    'stdout': 'tests.stdout.jsonl',
    'stderr': 'tests.stderr.log',
    'process_status': None,
    'input_count': len(before),
    'additional_tracked_path_count': len(extras),
    'source_unchanged': False,
    'accepted': False,
    'scope': 'Supplemental source binding only; these cases overlap the integrated gate and do not increase the total case count.',
    'environment_setup': f'source {ROOT / "runtime/env.sh"}',
    'runtime': {
        'test_entry_sha256': sha256(TEST_ENTRY),
        'dart_invoker_sha256': sha256(Path(shutil.which('dart'))),
        'pubspec_lock_sha256': sha256(REPO / 'pubspec.lock'),
        'package_config_sha256': sha256(REPO / '.dart_tool/package_config.json'),
    },
}
save('receipt.json', receipt)
print(json.dumps({'started': 'incoming-word-source-binding', 'inputs': len(before), 'additional_tracked_paths': len(extras)}), flush=True)
try:
    if (state_before['head'], state_before['tree'], state_before['status']) != (EXPECTED_HEAD, EXPECTED_TREE, ''):
        raise RuntimeError('The checkout does not match the expected clean frozen checkpoint')
    if mismatches_before or set(untracked_before) - {'.dart_tool/package_config.json'}:
        raise RuntimeError('Captured source does not match the expected Git blobs')
    with (OUT / receipt['stdout']).open('wb') as stdout, (OUT / receipt['stderr']).open('wb') as stderr:
        result = subprocess.run(receipt['command'], cwd=ENGINE, stdout=stdout, stderr=stderr, check=False, timeout=600)
        receipt['process_status'] = result.returncode
    starts = {}
    completions = []
    errors = []
    terminal = []
    for line in (OUT / receipt['stdout']).read_text().splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if event.get('type') == 'testStart':
            starts[event['test']['id']] = event['test']
        elif event.get('type') == 'testDone' and not event.get('hidden', False):
            completions.append(event)
        elif event.get('type') == 'error':
            errors.append(event)
        elif event.get('type') == 'done':
            terminal.append(event)
    cases = [{
        'name': starts.get(event['testID'], {}).get('name'),
        'url': starts.get(event['testID'], {}).get('url'),
        'result': event['result'],
        'skipped': event.get('skipped', False),
    } for event in completions]
    suite_counts = collections.Counter(Path(case['url']).name for case in cases if case['result'] == 'success' and not case['skipped'])
    tests = {
        'passed': sum(case['result'] == 'success' and not case['skipped'] for case in cases),
        'failed': sum(case['result'] != 'success' for case in cases),
        'skipped': sum(case['skipped'] for case in cases),
        'errors': len(errors),
        'terminal': terminal,
        'passed_per_suite': dict(sorted(suite_counts.items())),
        'case_count': len(cases),
        'expected_case_count': 338,
    }
    receipt['tests'] = tests
    save('test-cases.json', cases)
    save('test-errors.json', errors)
    receipt['tests_accepted'] = result.returncode == 0 and len(cases) == 338 and tests['passed'] == 338 and tests['failed'] == 0 and tests['skipped'] == 0 and not errors and bool(terminal) and terminal[-1].get('success') is True
except Exception as error:
    receipt['error'] = f'{type(error).__name__}: {error}'
finally:
    after = inputs()
    save('inputs-after.json', after)
    state_after = source_state()
    save('source-after.json', state_after)
    bindings_after, mismatches_after, untracked_after = bind(after)
    changed = sorted(name for name in set(before) | set(after) if before.get(name) != after.get(name))
    prior_delta = sorted(name for name, checksum in prior.items() if before.get(name) != checksum)
    receipt['source_unchanged'] = not changed
    receipt['changed_inputs'] = changed
    receipt['prior_integrated_input_mismatches'] = prior_delta
    receipt['clean_after'] = state_after['status'] == ''
    receipt['head_unchanged'] = state_after['head'] == EXPECTED_HEAD and state_after['tree'] == EXPECTED_TREE
    receipt['git_blob_mismatches'] = {'before': mismatches_before, 'after': mismatches_after}
    receipt['accepted'] = bool(receipt.get('tests_accepted')) and not receipt.get('error') and not changed and not prior_delta and not mismatches_before and not mismatches_after and receipt['head_unchanged'] and receipt['clean_after'] and not (set(untracked_after) - {'.dart_tool/package_config.json'})
    receipt['finished_at_utc'] = now()
    for label in ['stdout', 'stderr']:
        path = OUT / receipt[label]
        if path.exists():
            receipt[label + '_sha256'] = sha256(path)
            receipt[label + '_bytes'] = path.stat().st_size
    save('source-binding.json', {
        'head': EXPECTED_HEAD,
        'tree': EXPECTED_TREE,
        'git_object_format': git('rev-parse', '--show-object-format'),
        'coverage_directories': {name: (REPO / name).is_dir() for name in DIRECTORIES},
        'prior_input_manifest': str(PRIOR),
        'additional_tracked_paths': extras,
        'direct_and_transitive_extra_dependencies': CRITICAL_EXTRAS,
        'cli_helper': 'packages/quds_office_engine/test/support/office_macro_cli.dart',
        'cli_entrypoint': 'packages/quds_office_engine/tool/macros/office_macro.dart',
        'cli_package_config': '.dart_tool/package_config.json',
        'before': bindings_before,
        'after': bindings_after,
        'mismatches': {'before': mismatches_before, 'after': mismatches_after},
        'untracked_runtime_inputs': sorted(set(untracked_before) | set(untracked_after)),
    })
    (OUT / 'command.txt').write_text('cwd: ' + str(ENGINE) + '\n' + shlex.join(receipt['command']) + '\n')
    save('receipt.json', receipt)
    print(json.dumps({key: receipt.get(key) for key in ['accepted', 'process_status', 'input_count', 'additional_tracked_path_count', 'source_unchanged', 'git_blob_mismatches', 'tests', 'error']}), flush=True)

sys.exit(0 if receipt['accepted'] else 1)
