#!/usr/bin/env python3
"""Focused renderer qualification and immutable carry-forward source binding."""
import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

ROOT = Path('/workspace/scratch/81e9cddb3100')
REPO = ROOT / 'quds_office_suite'
EDITOR = REPO / 'packages/quds_office_editor'
OUT = ROOT / 'qualification/paint-integration'
EXPECTED_HEAD = '7086ad80266981d612615710610d66bf3fcfb5cf'
EXPECTED_TREE = 'b76107b64e496820f5550b11d1f6b684f34aa5d3'
PRIOR_HEAD = 'ef05b99ec9bbf1d539181c8519eb41455d182603'
PRIOR_MAP = ROOT / 'qualification/integration-word-binding-accepted/inputs-before.json'
CONVERTER_MAP = ROOT / 'image-converter/integrated/source-before.json'
RENDERER = 'packages/quds_office_editor/lib/src/editor_word/render_word_canvas.dart'
SUITES = [
    'test/word_proofing_geometry_test.dart',
    'test/word_selection_paint_test.dart',
    'test/word_odt_image_load_test.dart',
]


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def checksum(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()


def state():
    return {'captured_at_utc': now(), 'head': git('rev-parse', 'HEAD'),
            'tree': git('rev-parse', 'HEAD^{tree}'),
            'parents': git('show', '-s', '--format=%P', 'HEAD').split(),
            'status': git('status', '--porcelain=v1')}


def tree_blobs(revision):
    result = {}
    for record in subprocess.check_output(['git', 'ls-tree', '-r', '-z', revision], cwd=REPO).split(b'\0'):
        if not record:
            continue
        header, path = record.split(b'\t', 1)
        mode, kind, oid = header.decode().split()
        if kind == 'blob':
            result[path.decode()] = oid
    return result


prior = json.loads(PRIOR_MAP.read_text())
converter = json.loads(CONVERTER_MAP.read_text())['files']
expected_blobs = tree_blobs(EXPECTED_HEAD)
prior_blobs = tree_blobs(PRIOR_HEAD)


def inputs():
    return {name: checksum(REPO / name) for name in sorted(prior)}


def binding(manifest):
    rows = {}
    mismatches = []
    for name, sha in manifest.items():
        data = (REPO / name).read_bytes()
        oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        expected = expected_blobs.get(name)
        runtime = name == '.dart_tool/package_config.json'
        matches = oid == expected if expected is not None else runtime
        rows[name] = {
            'sha256': sha, 'git_blob_id': oid,
            'expected_git_blob_id': expected, 'prior_ef05_git_blob_id': prior_blobs.get(name),
            'matches_current_checkpoint': matches,
            'classification': 'runtime' if runtime else 'tracked',
        }
        if not matches:
            mismatches.append(name)
    return rows, mismatches


def run(name, argv, cwd, tests=False):
    record = {'name': name, 'argv': argv, 'cwd': str(cwd), 'started_at_utc': now(),
              'stdout': name + '.stdout.log', 'stderr': name + '.stderr.log'}
    print(json.dumps({'started': name}), flush=True)
    with (OUT / record['stdout']).open('wb') as stdout, (OUT / record['stderr']).open('wb') as stderr:
        result = subprocess.run(argv, cwd=cwd, stdout=stdout, stderr=stderr, check=False, timeout=600)
    record.update({'finished_at_utc': now(), 'exit_status': result.returncode,
                   'stdout_sha256': checksum(OUT / record['stdout']),
                   'stderr_sha256': checksum(OUT / record['stderr']),
                   'stderr_bytes': (OUT / record['stderr']).stat().st_size,
                   'accepted': result.returncode == 0})
    if tests:
        suites = {}
        starts = {}
        complete = []
        errors = []
        terminal = []
        for line in (OUT / record['stdout']).read_text().splitlines():
            try:
                event = json.loads(line)
            except ValueError:
                continue
            if event.get('type') == 'suite':
                suites[event['suite']['id']] = event['suite']['path']
            elif event.get('type') == 'testStart':
                starts[event['test']['id']] = event['test']
            elif event.get('type') == 'testDone' and not event.get('hidden', False):
                complete.append(event)
            elif event.get('type') == 'error':
                errors.append(event)
            elif event.get('type') == 'done':
                terminal.append(event)
        cases = [{
            'name': starts.get(event['testID'], {}).get('name'),
            'url': starts.get(event['testID'], {}).get('root_url') or starts.get(event['testID'], {}).get('url'),
            'suite_id': starts.get(event['testID'], {}).get('suiteID'),
            'suite_path': suites.get(starts.get(event['testID'], {}).get('suiteID')),
            'result': event['result'], 'skipped': event.get('skipped', False),
            'skip_reason': starts.get(event['testID'], {}).get('metadata', {}).get('skipReason'),
        } for event in complete]
        metrics = {
            'passed': sum(case['result'] == 'success' and not case['skipped'] for case in cases),
            'failed': sum(case['result'] != 'success' for case in cases),
            'skipped': sum(case['skipped'] for case in cases), 'errors': len(errors),
            'terminal': terminal,
            'skipped_cases': [case for case in cases if case['skipped']],
            'per_suite': {},
        }
        for suite in SUITES:
            matching = [case for case in cases if case['suite_path'] and case['suite_path'].endswith('/' + suite)]
            metrics['per_suite'][suite] = {
                'passed': sum(case['result'] == 'success' and not case['skipped'] for case in matching),
                'failed': sum(case['result'] != 'success' for case in matching),
                'skipped': sum(case['skipped'] for case in matching),
            }
        record['tests'] = metrics
        record['accepted'] = record['accepted'] and bool(terminal) and terminal[-1].get('success') is True and not errors and metrics['failed'] == 0
        save('test-cases.json', cases)
        save('test-errors.json', errors)
    save(name + '.json', record)
    print(json.dumps({'finished': name, 'exit_status': record['exit_status'], 'accepted': record['accepted']}), flush=True)
    return record


OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'runner.py')
initial_state = state()
save('source-before.json', initial_state)
before = inputs()
save('inputs-before.json', before)
bound_before, before_mismatches = binding(before)
different_from_ef = sorted(name for name in prior if prior[name] != before[name])
converter_current = {name: checksum(REPO / name) for name in converter}
converter_mismatches = [name for name in converter if converter_current[name] != converter[name]['sha256'] or expected_blobs.get(name) != prior_blobs.get(name)]
other_blob_changes = [name for name in prior if name != RENDERER and name in expected_blobs and expected_blobs[name] != prior_blobs.get(name)]
receipt = {
    'started_at_utc': now(), 'head': initial_state['head'], 'tree': initial_state['tree'],
    'expected_head': EXPECTED_HEAD, 'expected_tree': EXPECTED_TREE, 'prior_head': PRIOR_HEAD,
    'clean_before': initial_state['status'] == '', 'accepted': False,
    'input_count': len(before), 'changed_from_ef05': different_from_ef,
    'converter_input_count': len(converter),
    'converter_input_mismatches': converter_mismatches,
    'all_converter_inputs_unchanged_from_ef05': not converter_mismatches,
    'other_input_git_blob_changes': other_blob_changes,
    'all_other_input_blobs_unchanged_from_ef05': not other_blob_changes,
    'engine_input_count': sum(name.startswith('packages/quds_office_engine/') for name in prior),
    'environment_setup': f'source {ROOT / "runtime/env.sh"}',
    'gates': [],
}
save('receipt.json', receipt)
try:
    if (initial_state['head'], initial_state['tree'], initial_state['status']) != (EXPECTED_HEAD, EXPECTED_TREE, ''):
        raise RuntimeError('Checkout is not the requested clean merged checkpoint')
    if before_mismatches or different_from_ef != [RENDERER] or converter_mismatches or other_blob_changes:
        raise RuntimeError('Source binding or carry-forward evidence does not match the requested narrow renderer change')
    commands = [
        ('flutter-tests', [shutil.which('flutter'), 'test', '--no-pub', '--reporter', 'json', '--concurrency=2', *SUITES], EDITOR, True),
        ('format', [shutil.which('dart'), 'format', '--output=none', '--set-exit-if-changed', RENDERER], REPO, False),
        ('analyze', [shutil.which('dart'), 'analyze', '--fatal-infos', RENDERER], REPO, False),
    ]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        receipt['gates'] = list(pool.map(lambda args: run(*args), commands))
except Exception as error:
    receipt['error'] = f'{type(error).__name__}: {error}'
finally:
    after = inputs()
    save('inputs-after.json', after)
    final_state = state()
    save('source-after.json', final_state)
    bound_after, after_mismatches = binding(after)
    changed = sorted(name for name in set(before) | set(after) if before.get(name) != after.get(name))
    converter_after = {name: checksum(REPO / name) for name in converter}
    receipt['source_unchanged'] = not changed
    receipt['changed_during_run'] = changed
    receipt['source_binding_matches'] = not before_mismatches and not after_mismatches
    receipt['source_binding_mismatches'] = {'before': before_mismatches, 'after': after_mismatches}
    receipt['clean_after'] = final_state['status'] == ''
    receipt['head_unchanged'] = final_state['head'] == EXPECTED_HEAD and final_state['tree'] == EXPECTED_TREE
    receipt['converter_inputs_unchanged_during_run'] = converter_current == converter_after
    receipt['finished_at_utc'] = now()
    receipt['accepted'] = not receipt.get('error') and len(receipt['gates']) == 3 and all(gate['accepted'] for gate in receipt['gates']) and receipt['source_unchanged'] and receipt['source_binding_matches'] and receipt['clean_after'] and receipt['head_unchanged'] and receipt['converter_inputs_unchanged_during_run']
    save('source-binding.json', {
        'head': EXPECTED_HEAD, 'tree': EXPECTED_TREE, 'prior_head': PRIOR_HEAD,
        'prior_input_manifest': str(PRIOR_MAP), 'prior_converter_manifest': str(CONVERTER_MAP),
        'before': bound_before, 'after': bound_after,
        'changed_from_ef05': {name: {'ef05_sha256': prior[name], 'current_sha256': before[name], 'ef05_git_blob': prior_blobs.get(name), 'current_git_blob': expected_blobs.get(name)} for name in different_from_ef},
        'all_other_input_git_blobs_unchanged': not other_blob_changes,
        'converter': {name: {'prior_sha256': converter[name]['sha256'], 'before_sha256': converter_current[name], 'after_sha256': converter_after[name], 'ef05_git_blob': prior_blobs.get(name), 'current_git_blob': expected_blobs.get(name)} for name in sorted(converter)},
        'git_blob_mismatches': {'before': before_mismatches, 'after': after_mismatches},
    })
    (OUT / 'commands.txt').write_text('\n\n'.join('[' + gate['name'] + ']\ncwd: ' + gate['cwd'] + '\n' + shlex.join(gate['argv']) for gate in receipt['gates']) + '\n')
    save('receipt.json', receipt)
    print(json.dumps({key: receipt.get(key) for key in ['accepted', 'head', 'source_unchanged', 'source_binding_matches', 'changed_from_ef05', 'all_converter_inputs_unchanged_from_ef05', 'all_other_input_blobs_unchanged_from_ef05', 'error']}), flush=True)
    for gate in receipt['gates']:
        if 'tests' in gate:
            print(json.dumps(gate['tests']), flush=True)

sys.exit(0 if receipt['accepted'] else 1)
