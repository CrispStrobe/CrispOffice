#!/usr/bin/env python3
"""Capture serial local grammar checks without invoking hosted CI."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

REPO = Path('/workspace/scratch/e5b34feae619/work-accusative')
ENGINE = REPO / 'packages/quds_office_engine'
BASE = Path('/workspace/scratch/e5b34feae619/runtime-recovery/accusative')
RUNTIME = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime')
DART = RUNTIME / 'flutter-sdk/bin/cache/dart-sdk/bin/dart'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()


def sources():
    paths = set(ENGINE.glob('lib/**/*.dart'))
    paths.update(ENGINE.glob('test/proofing/*.dart'))
    paths.update((REPO / 'packages/legacy_doc_parser/lib').rglob('*.dart'))
    paths.update(REPO / name for name in (
        'pubspec.yaml', 'pubspec.lock', '.dart_tool/package_config.json',
        'analysis_options.yaml', 'packages/quds_office_engine/pubspec.yaml',
    ))
    return {str(p.relative_to(REPO)): sha(p) for p in sorted(paths)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('attempt')
    parser.add_argument('kind', choices=['focused', 'regression', 'analysis'])
    args = parser.parse_args()
    out = BASE / args.attempt
    out.mkdir(parents=True, exist_ok=True)
    log = out / (args.kind + ('.log' if args.kind == 'analysis' else '.jsonl'))
    if log.exists():
        raise RuntimeError('Refusing to overwrite attempt: ' + str(log))
    if args.kind == 'analysis':
        command = [str(DART), 'analyze', '--fatal-infos', '--fatal-warnings',
                   'lib/src/proofing/german_grammar.dart',
                   'lib/src/proofing/german_writing_rules.dart',
                   'test/proofing/german_verb_object_case_test.dart']
    else:
        tests = ['test/proofing/german_verb_object_case_test.dart']
        if args.kind == 'regression':
            tests += ['test/proofing/' + name for name in (
                'german_grammar_test.dart', 'german_morphology_grammar_test.dart',
                'german_genitive_noun_test.dart', 'german_agreement_context_test.dart',
                'german_noun_agreement_test.dart', 'german_writing_rules_test.dart',
            )]
        command = [str(DART), 'test', '--reporter=json', *tests]
    config = json.loads((REPO / '.dart_tool/package_config.json').read_text())
    engine_config = next(p for p in config['packages'] if p['name'] == 'quds_office_engine')
    configured_root = ((REPO / '.dart_tool') / engine_config['rootUri']).resolve()
    if configured_root != ENGINE:
        raise RuntimeError('Wrong engine package root: ' + str(configured_root))
    record = {'started_utc': datetime.now(timezone.utc).isoformat(),
              'command': command, 'cwd': str(ENGINE), 'head_before': head(),
              'source_files_before': sources(), 'dart_sha256': sha(DART),
              'package_root_verified': str(configured_root)}
    env = {**os.environ, 'PUB_CACHE': str(RUNTIME / 'pub-cache'),
           'FLUTTER_ROOT': str(RUNTIME / 'flutter-sdk'),
           'TMPDIR': '/workspace/scratch/e5b34feae619/runtime-recovery/tmp',
           'XDG_CONFIG_HOME': '/workspace/scratch/e5b34feae619/runtime-recovery/config',
           'XDG_CACHE_HOME': '/workspace/scratch/e5b34feae619/runtime-recovery/cache',
           'CI': 'true', 'DART_SUPPRESS_ANALYTICS': 'true',
           'FLUTTER_SUPPRESS_ANALYTICS': 'true'}
    started = time.monotonic()
    with log.open('xb') as output:
        process = subprocess.run(command, cwd=ENGINE, env=env, stdout=output,
                                 stderr=subprocess.STDOUT, timeout=600)
    record.update({'exit_code': process.returncode,
                   'elapsed_seconds': time.monotonic() - started,
                   'completed_utc': datetime.now(timezone.utc).isoformat(),
                   'head_after': head(), 'source_files_after': sources(),
                   'log_sha256': sha(log), 'log_file': str(log)})
    record['source_stable'] = record['source_files_before'] == record['source_files_after']
    if args.kind != 'analysis':
        events = []
        for line in log.read_text().splitlines():
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        names = {e['test']['id']: e['test']['name'] for e in events if e.get('type') == 'testStart'}
        tests = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden', False)
                 and not names.get(e['testID'], '').startswith('loading ')]
        record['passed_tests'] = sum(e['result'] == 'success' and not e.get('skipped') for e in tests)
        record['failed_tests'] = sum(e['result'] != 'success' for e in tests)
        record['skipped_tests'] = sum(bool(e.get('skipped')) for e in tests)
        record['done_events'] = [e for e in events if e.get('type') == 'done']
        record['failures'] = [names[e['testID']] for e in tests if e['result'] != 'success']
    else:
        record['no_issues_found'] = 'No issues found!' in log.read_text()
    (out / (args.kind + '-receipt.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({k: v for k, v in record.items() if not k.startswith('source_files')}, indent=2), flush=True)
    return process.returncode


if __name__ == '__main__':
    raise SystemExit(main())
