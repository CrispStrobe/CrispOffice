"""Independent inspection of saved native qualification JSON; no inference."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
import math
import re
import statistics
import unicodedata


def utf16(text):
    return text.encode("utf-16-le")


def units(text):
    return len(utf16(text)) // 2


def source_slice(text, start, end):
    return utf16(text)[start * 2:end * 2].decode("utf-16-le")


def timing(samples):
    ordered = sorted(samples)
    return {"samples_ms": samples, "median_ms": statistics.median(samples),
            "p95_ms": ordered[math.ceil(len(samples) * .95) - 1], "maximum_ms": ordered[-1]}


class IndependentTokenizer:
    """Scalar WordPiece reconstruction independent from the Dart implementation.

    The retained panels use ordinary German, ASCII punctuation and controls,
    combining marks and emoji. Unicode-version-sensitive exotic categories are
    not relied on for this audit. No truncation/admission logic is imported.
    """
    def __init__(self, tokenizer_json, language_rules):
        self.vocab = tokenizer_json["model"]["vocab"]
        self.strip = language_rules.get("stripTerminators", ".!?") if language_rules["stripTrailingTerminator"] else ""
        self.glued = set((language_rules.get("elision") or language_rules).get("nonElidingArticles", []))
        self.word = re.compile(r"\w+(?:'\w+)?|[^\w\s\ufeff]")
        self.special = re.compile(r"\[(?:PAD|UNK|CLS|SEP|MASK)\]")
        self.specials = {"[PAD]", "[UNK]", "[CLS]", "[SEP]", "[MASK]"}

    def words(self, text):
        trimmed = text.rstrip("\t\n\v\f\r \x85\x1c\x1d\x1e\x1f\xa0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u2028\u2029\u202f\u205f\u3000\ufeff")
        core = trimmed[:-1] if trimmed and trimmed[-1] in self.strip else text
        result = []
        for word in self.word.findall(core.replace("’", "'")):
            if "'" in word and word.split("'", 1)[0].lower() in self.glued:
                result.extend(word.split("'", 1))
            else:
                result.append(word)
        return result

    @staticmethod
    def chinese(char):
        value = ord(char)
        return any(a <= value <= b for a, b in [(0x4e00, 0x9fff), (0x3400, 0x4dbf),
            (0xf900, 0xfaff), (0x20000, 0x2a6df), (0x2a700, 0x2b73f),
            (0x2b740, 0x2b81f), (0x2b820, 0x2ceaf), (0x2f800, 0x2fa1f)])

    def ordinary(self, text):
        normalized = []
        for char in text:
            if ord(char) in (0, 0xfffd) or (unicodedata.category(char).startswith("C") and char not in "\t\n\r"):
                continue
            normalized.append(" " if char.isspace() else " " + char + " " if self.chinese(char) else char)
        result, current = [], ""
        for char in "".join(normalized):
            cp = ord(char)
            punct = (33 <= cp <= 47 or 58 <= cp <= 64 or 91 <= cp <= 96 or 123 <= cp <= 126 or
                     unicodedata.category(char).startswith("P"))
            if char == " " or punct:
                if current:
                    result.append(current)
                current = ""
                if punct:
                    result.append(char)
            else:
                current += char
        if current:
            result.append(current)
        return result

    def pretokens(self, word):
        result, cursor = [], 0
        for match in self.special.finditer(word):
            result.extend(self.ordinary(word[cursor:match.start()]))
            result.append(match.group())
            cursor = match.end()
        return result + self.ordinary(word[cursor:])

    def pieces(self, token):
        if token in self.specials:
            return [self.vocab[token]]
        if len(token) > 100:
            return [101]
        result, start = [], 0
        while start < len(token):
            for end in range(len(token), start, -1):
                piece = ("" if start == 0 else "##") + token[start:end]
                if piece in self.vocab:
                    result.append(self.vocab[piece])
                    start = end
                    break
            else:
                return [101]
        return result

    def arrays(self, words):
        ids, first = [102], [0]
        for word in words:
            pretokens = self.pretokens(word)
            if not pretokens:
                raise ValueError("Source word vanished during independent BERT normalization")
            first.append(len(ids))
            for token in pretokens:
                ids.extend(self.pieces(token))
        ids.append(103)
        return [words, ids, [1] * len(ids), first]

    def prepared(self, text):
        key = self.arrays(self.words(text))
        fingerprint = hashlib.sha256(json.dumps(key, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()
        return {"tokens": len(key[1]), "fingerprint": fingerprint, "word_count": len(key[0])}


class Checks:
    def __init__(self):
        self.checks = []

    def add(self, label, passed, detail=None):
        row = {"check": label, "passed": bool(passed)}
        if detail is not None:
            row["detail"] = detail
        self.checks.append(row)

    def result(self):
        return {"passed": all(row["passed"] for row in self.checks),
                "checks_total": len(self.checks), "checks_passed": sum(row["passed"] for row in self.checks),
                "errors": [row for row in self.checks if not row["passed"]], "checks": self.checks}


OUTCOME_FIELDS = ("input", "language", "start_offset", "status", "corrected", "findings")
SECTIONS = ("cases", "controls", "long_complete_check_probes",
            "segmented_long_complete_check_probes", "varied_segmented_long_complete_check_probes", "segmentation_controls")


def audit_outcome(row, label, checks):
    text = row["input"]
    raw = utf16(text)
    edited = raw
    previous_end = -1
    valid = True
    for finding in row["findings"]:
        start, end = finding["start"] - row["start_offset"], finding["end"] - row["start_offset"]
        valid &= 0 <= start <= end <= len(raw) // 2 and start >= previous_end
        valid &= source_slice(text, start, end) == finding["original"]
        previous_end = end
    for finding in reversed(row["findings"]):
        start, end = finding["start"] - row["start_offset"], finding["end"] - row["start_offset"]
        edited = edited[:start * 2] + utf16(finding["replacement"]) + edited[end * 2:]
    valid &= edited == utf16(row["corrected"])
    if row["status"] != "success":
        valid &= not row["findings"] and row["corrected"] == text
    checks.add(label + " UTF-16 source edits and final projection", valid)


def planned_segments(row, mode, configuration, tokenizer, checks, label):
    pieces = row.get("initial_segments")
    if pieces is None:
        if row["status"] == "success":
            pieces = [{"start": 0, "end": units(row["input"]), "tokens": tokenizer.prepared(row["input"])["tokens"]}]
        else:
            return None
    calculated, cursor = [], 0
    valid = True
    for piece in pieces:
        start, end = piece["start"], piece["end"]
        valid &= start == cursor and start <= end <= units(row["input"])
        source = source_slice(row["input"], start, end)
        prepared = tokenizer.prepared(source)
        valid &= piece["tokens"] == prepared["tokens"] <= configuration["maximum_tokens_per_sequence"]
        calculated.append({"start": start, "end": end, **prepared})
        cursor = end
    valid &= cursor == units(row["input"])
    if "initial_segments" in row:
        logical = tokenizer.prepared(row["input"])["tokens"]
        valid &= row["tokens_first_pass"] == logical
        valid &= row["initial_segment_count"] == len(calculated)
        valid &= row["initial_model_tokens_total"] == sum(p["tokens"] for p in calculated)
        valid &= row["initial_distinct_model_inputs"] == len({p["fingerprint"] for p in calculated})
        valid &= row["source_code_units"] == cursor and row["source_coverage_complete"] is True
        if mode != "single":
            settings = configuration["segmentation"]
            valid &= len(calculated) <= settings["maximum_segments"]
            valid &= sum(p["tokens"] for p in calculated) <= settings["maximum_total_initial_tokens"]
            valid &= cursor <= configuration["maximum_text_code_units"]
        checks.add(label + " independent tokens/fingerprints and continuous planned source partition", valid,
                   {"logical_tokens": logical, "segments": len(calculated),
                    "initial_tokens": sum(p["tokens"] for p in calculated),
                    "distinct_inputs": len({p["fingerprint"] for p in calculated})})
        if len(calculated) > 1:
            boundaries = [piece["end"] for piece in calculated[:-1]]
            boundary_valid = all(source_slice(row["input"], 0, end).rstrip().endswith((".", "!", "?")) for end in boundaries)
            boundary_valid &= all(source_slice(row["input"], 0, end).count("`") % 2 == 0 for end in boundaries)
            for finding in row["findings"]:
                start, end = finding["start"] - row["start_offset"], finding["end"] - row["start_offset"]
                boundary_valid &= sum(piece["start"] <= start <= end <= piece["end"] for piece in calculated) == 1
            checks.add(label + " retained long-input sentence/code boundaries and unique edit ownership", boundary_valid)
    return calculated


def decoder_shape(decoded):
    if decoded is None:
        return None
    return {key: decoded[key] for key in ("complete", "stop_reason", "segment_count", "pass_count", "forward_count", "forward_tokens", "decoded_tokens", "reused_pass_count")} | {
        "passes": [{key: p[key] for key in ("source_start", "tokens", "prediction_input_sha256", "reused_inference")} for p in decoded["passes"]]}


def audit_decoder(decoded, observation, status, elapsed, plan, configuration, label, checks):
    checks.add(label + " worker observation agrees with diagnostics", observation["worker_result_received"] == (decoded is not None)
               and observation["diagnostics_available"] == (decoded is not None))
    if decoded is None:
        checks.add(label + " successful checks have actual worker diagnostics", status != "success")
        if status == "unsupported":
            checks.add(label + " unsupported locale never requests worker", observation["worker_requested"] is False and observation["worker_error"] is None)
        return {"diagnostics_available": False, "forward_work": "unknown, not zero"}
    checks.add(label + " actual worker was requested and returned without error", observation["worker_requested"] is True and observation["worker_error"] is None)
    passes = decoded["passes"]
    count = len(passes)
    forwards = [p for p in passes if not p["reused_inference"]]
    reconstructed = {"pass_count": count, "forward_count": len(forwards),
        "forward_tokens": sum(p["tokens"] for p in forwards), "decoded_tokens": sum(p["tokens"] for p in passes),
        "reused_pass_count": count - len(forwards), "inference_microseconds": sum(p["inference_microseconds"] for p in passes)}
    checks.add(label + " independently reconstructed actual counters", all(decoded[key] == value for key, value in reconstructed.items()), reconstructed)
    valid_passes = all(type(p["tokens"]) is int and 2 <= p["tokens"] <= configuration["maximum_tokens_per_sequence"]
        and type(p["inference_microseconds"]) is int and p["inference_microseconds"] >= 0
        and isinstance(p["reused_inference"], bool) and re.fullmatch(r"[0-9a-f]{64}", p["prediction_input_sha256"])
        and (not p["reused_inference"] or p["inference_microseconds"] == 0) for p in passes)
    checks.add(label + " bounded pass records and inference-time accounting", valid_passes and
        reconstructed["inference_microseconds"] <= round(elapsed * 1000) + 1)
    if status == "success":
        checks.add(label + " actual complete stable decoder result", decoded["complete"] is True and decoded["stop_reason"] == "stable")
    first_verified = 0
    if plan is not None:
        by_start = {p["start"]: p for p in plan}
        starts = [p["source_start"] for p in passes]
        counts = Counter(starts)
        valid = starts == sorted(starts) and all(start in by_start for start in starts)
        valid &= all(value <= configuration["maximum_passes"] for value in counts.values())
        valid &= decoded["segment_count"] == len(plan)
        if decoded["complete"]:
            valid &= set(starts) == {p["start"] for p in plan if p["word_count"]}
        for start in counts:
            actual = next(p for p in passes if p["source_start"] == start)
            expected = by_start[start]
            valid &= actual["tokens"] == expected["tokens"] and actual["prediction_input_sha256"] == expected["fingerprint"]
            first_verified += 1
        checks.add(label + " actual first passes independently bind every planned segment", valid,
                   {"verified_initial_fingerprints": first_verified, "later_pass_fingerprints": count - first_verified})
    segmentation = configuration.get("segmentation")
    reuse = segmentation.get("inference_reuse") if segmentation else None
    cache, cached_tokens, valid_cache = {}, 0, True
    token_by_fingerprint = {}
    for p in passes:
        key, tokens = p["prediction_input_sha256"], p["tokens"]
        valid_cache &= key not in token_by_fingerprint or token_by_fingerprint[key] == tokens
        token_by_fingerprint[key] = tokens
        expected_hit = reuse is not None and key in cache
        valid_cache &= p["reused_inference"] == expected_hit
        if reuse is not None and not expected_hit and len(cache) < reuse["maximum_cached_inputs"] and cached_tokens + tokens <= reuse["maximum_cached_tokens"]:
            cache[key] = tokens
            cached_tokens += tokens
    if segmentation:
        valid_cache &= reconstructed["forward_tokens"] <= segmentation["maximum_total_forward_tokens"]
    checks.add(label + " request-local cache admission/hits and actual forward budget", valid_cache,
               {"cached_inputs": len(cache), "cached_tokens": cached_tokens})
    return {"diagnostics_available": True, **reconstructed, "initial_fingerprints_verified": first_verified,
            "later_fingerprints_consistency_only": count - first_verified}


def audit_native(run, mode, frozen_cases, historical, tokenizer, reference):
    checks = Checks()
    cfg = run["decode_configuration"]
    checks.add("native receipt completed all requested checks", all(run.get(k) is True for k in
        ("completed", "source_stable", "operational_passed", "all_requested_checks_passed")))
    checks.add("native runtime is AOT with one warmup and three timed samples", run["runtime"]["product_mode"] is True
        and run["runtime"]["native_threads"] == 2 and run["runtime"]["warmups_per_input"] == 1 and run["runtime"]["repeats_per_input"] == 3)
    checks.add("requested decode mode", (mode == "single" and cfg["mode"] == "single-sequence" and cfg["segmentation"] is None)
        or (mode != "single" and cfg["mode"] == "sentence-segments" and cfg["segmentation"]["target_tokens"] == 64
            and (cfg["segmentation"].get("inference_reuse") is not None) == (mode == "reuse")))
    expected_lengths = {"cases": 30, "controls": 8, "long_complete_check_probes": 3}
    if mode != "single":
        expected_lengths.update(segmented_long_complete_check_probes=2, varied_segmented_long_complete_check_probes=2, segmentation_controls=6)
        checks.add("segmentation operational gates", run.get("segmentation_operational_passed") is True and run.get("varied_segmentation_operational_passed") is True)
    for section, length in expected_lengths.items():
        checks.add(section + " exact row count and unique IDs", len(run.get(section, [])) == length and len({r["id"] for r in run.get(section, [])}) == length)
    diagnostics = {}
    for section in SECTIONS:
        for row in run.get(section, []):
            label = section + "/" + row["id"]
            try:
                audit_outcome(row, label, checks)
                plan = planned_segments(row, mode, cfg, tokenizer, checks, label)
                diagnostics[label] = audit_decoder(row.get("decoder"), row["decoder_observation"], row["status"], row["elapsed_ms"], plan, cfg, label + " first", checks)
                if "timing" in row:
                    samples = row["timing"]["samples_ms"]
                    valid = len(samples) == 3 and all(isinstance(v, (int, float)) and math.isfinite(v) and v >= 0 for v in samples)
                    checks.add(label + " recomputed three-sample statistics", valid and row["timing"] == timing(samples) and row["elapsed_ms"] == samples[0])
                    warm = row["warmup"]
                    audit_outcome(warm, label + " warmup", checks)
                    checks.add(label + " saved warmup equals first timed outcome", row["stable_repeats"] is True and all(warm[k] == row[k] for k in OUTCOME_FIELDS))
                    audit_decoder(warm.get("decoder"), warm["decoder_observation"], warm["status"], warm["elapsed_ms"], plan, cfg, label + " warmup", checks)
                    decoders, observations = row["decoder_samples"], row["decoder_observation_samples"]
                    checks.add(label + " three retained actual decoder samples", len(decoders) == len(observations) == 3 and decoders[0] == row["decoder"] and observations[0] == row["decoder_observation"])
                    for index, (decoder, observed, sample) in enumerate(zip(decoders, observations, samples)):
                        audit_decoder(decoder, observed, row["status"], sample, plan, cfg, label + f" sample-{index + 1}", checks)
                    checks.add(label + " actual decoder trajectories repeat", all(decoder_shape(d) == decoder_shape(row["decoder"]) for d in [warm["decoder"], *decoders]))
                if "matches_expected" in row:
                    checks.add(label + " expected-output flag recomputes", row["matches_expected"] == (row["corrected"] == row["expected"]))
                if section == "controls":
                    checks.add(label + " frozen operational control passes", row["passed"] is True)
                if section == "segmentation_controls":
                    valid = row["passed"] is True and row["status"] == row["expected_status"] and row["corrected"] == row["expected"]
                    valid &= row["findings"] == row.get("expected_findings", row["findings"])
                    if row["status"] == "success":
                        valid &= row["planning_admitted"] is True and row["source_coverage_complete"] is True
                    else:
                        valid &= row["planning_admitted"] is False and row["planning_rejection"] in row["message"] and not row["findings"]
                    checks.add(label + " explicit status/admission/atomic-result expectations", valid)
                if section == "varied_segmented_long_complete_check_probes":
                    checks.add(label + " distinct synthetic probe admitted completely", row["initial_inputs_all_distinct"] is True
                        and row["initial_distinct_model_inputs"] == row["initial_segment_count"] and row["exceeds_single_sequence_capacity"] is True
                        and row["tokens_first_pass"] > 512 and row["tokens_first_pass"] <= row["logical_token_budget"])
            except Exception as error:
                checks.add(label + " audit reconstruction", False, repr(error))
    frozen = {case["id"]: case for case in frozen_cases}
    references = {case["id"]: case for case in reference["cases"]}
    checks.add("frozen thirty case identities", {case["id"] for case in run["cases"]} == set(frozen))
    for row in run["cases"]:
        case = frozen[row["id"]]
        locale = case.get("locale", "de-DE")
        checks.add("immutable case " + row["id"], row["input"] == case["input"] and row["kind"] == case["kind"]
            and row["language"] == row["source_locale"] == row["evaluation_locale"] == locale
            and row["expected"] == case.get("expected", case["input"])
            and row["status"] == ("success" if locale == "de-DE" else "unsupported")
            and row["reference_unguarded"] == references[row["id"]]["corrected"]
            and row["matches_unguarded_reference"] == (row["corrected"] == row["reference_unguarded"]))
    historical_differences = []
    for section in ("cases", "controls", "long_complete_check_probes", "segmented_long_complete_check_probes", "segmentation_controls"):
        if section not in historical or section not in run:
            continue
        old = {r["id"]: r for r in historical[section]}
        new = {r["id"]: r for r in run[section]}
        checks.add(section + " preserves historical row identities", set(old) == set(new))
        for key in set(old) & set(new):
            differing = [field for field in OUTCOME_FIELDS if old[key].get(field) != new[key].get(field)]
            if differing:
                historical_differences.append({"section": section, "id": key, "fields": differing})
    checks.add("all original native outcomes and controls preserved", not historical_differences, historical_differences)
    short = [sample for row in run["cases"] if row["status"] == "success" and row["tokens_first_pass"] <= 64 for sample in row["timing"]["samples_ms"]]
    short += next(row for row in run["long_complete_check_probes"] if row["token_budget"] == 64)["timing"]["samples_ms"]
    short_timing = timing(short)
    checks.add("short aggregate reconstructed from all raw samples", run["warm_checks_up_to_64_wordpieces"] == short_timing)
    budgets = run["engineering_budgets"]
    checks.add("engineering flags match their declared short/memory/file scope", budgets["p95_at_most_500_ms"] == (short_timing["p95_ms"] <= 500)
        and budgets["peak_rss_at_most_768_mib"] == (run["peak_process_rss_bytes"] <= 768 * 1024 * 1024)
        and budgets["gguf_at_most_160_mib"] == (run["model"]["bytes"] <= 160 * 1024 * 1024))
    errors = [r for r in run["cases"] if r["kind"] == "error" and r["language"] == "de-DE"]
    clean = [r for r in run["cases"] if r["kind"] == "clean" and r["language"] == "de-DE"]
    summary = {"short_timing": short_timing, "setup_ms": run["setup_ms"], "peak_process_rss_bytes": run["peak_process_rss_bytes"],
        "exact_error_ids": [r["id"] for r in errors if r["corrected"] == r["expected"]], "error_count": len(errors),
        "clean_count": len(clean), "changed_clean_ids": [r["id"] for r in clean if r["corrected"] != r["input"]],
        "flagged_clean_ids": [r["id"] for r in clean if r["findings"]],
        "probes": {section: [{key: row[key] for key in ("id", "tokens_first_pass", "initial_segment_count", "initial_distinct_model_inputs", "timing")} |
            {"decoder": diagnostics.get(section + "/" + row["id"]), "corrected": row["corrected"], "findings": row["findings"]}
            for row in run.get(section, [])] for section in ("long_complete_check_probes", "segmented_long_complete_check_probes", "varied_segmented_long_complete_check_probes")}}
    return {**checks.result(), "summary": summary, "diagnostics": diagnostics}


def compare_native_modes(segmented, reuse):
    checks = Checks()
    comparisons = {}
    for section in SECTIONS:
        left = {row["id"]: row for row in segmented.get(section, [])}
        right = {row["id"]: row for row in reuse.get(section, [])}
        checks.add(section + " same paired input IDs", set(left) == set(right))
        for ident in set(left) & set(right):
            a, b = left[ident], right[ident]
            checks.add(section + "/" + ident + " paired output equality", all(a.get(k) == b.get(k) for k in OUTCOME_FIELDS))
            if "timing" not in a:
                continue
            label = section + "/" + ident
            comparisons[label] = {"segmented": a["timing"], "reuse": b["timing"],
                "median_ratio_reuse_over_segmented": b["timing"]["median_ms"] / a["timing"]["median_ms"] if a["timing"]["median_ms"] else None,
                "segmented_forward_counts": [d["forward_count"] if d else None for d in a["decoder_samples"]],
                "reuse_forward_counts": [d["forward_count"] if d else None for d in b["decoder_samples"]],
                "reuse_hit_counts": [d["reused_pass_count"] if d else None for d in b["decoder_samples"]]}
            shapes_a = [None if d is None else [(p["source_start"], p["tokens"], p["prediction_input_sha256"]) for p in d["passes"]] for d in a["decoder_samples"]]
            shapes_b = [None if d is None else [(p["source_start"], p["tokens"], p["prediction_input_sha256"]) for p in d["passes"]] for d in b["decoder_samples"]]
            checks.add(label + " equal actual pass trajectories across reuse modes", shapes_a == shapes_b)
    return {**checks.result(), "comparisons": comparisons,
            "interpretation": "Repeated boilerplate and varied synthetic paragraphs are separate operational/performance controls. Equal outputs are not representative German quality qualification."}
