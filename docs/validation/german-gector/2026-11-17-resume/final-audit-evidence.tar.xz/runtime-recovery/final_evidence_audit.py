#!/usr/bin/env python3
"""Audit retained final build/native/quality evidence without running inference.

Only file reads, SHA256 reconstruction and git/ldd metadata commands are used.
Results must already exist. --plan lists expected inputs without auditing them.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import traceback
from urllib.parse import unquote, urljoin, urlparse

from final_native_audit import Checks, IndependentTokenizer, audit_native, compare_native_modes


PROVIDER_ENTRY = "tools/proofing/german_model/run_gector_dart.dart"
QUALITY_ENTRY = "tools/proofing/german_model/run_incremental_quality.dart"
PROVIDER_FIXED = {"pubspec.yaml", "pubspec.lock", "packages/quds_proofing_gector/pubspec.yaml",
    "packages/quds_office_engine/lib/src/proofing/german_spelling.dart",
    "packages/quds_office_engine/lib/src/proofing/office_proofing.dart",
    "packages/quds_office_engine/lib/src/proofing/proofing_text_ranges.dart", PROVIDER_ENTRY,
    "tools/proofing/german_model/cases.json", "tools/proofing/german_model/artifacts.json"}
QUALITY_FIXED = {"pubspec.yaml", "pubspec.lock", "packages/quds_office_engine/pubspec.yaml",
    "packages/quds_proofing_gector/pubspec.yaml", ".dart_tool/package_config.json", QUALITY_ENTRY,
    "tools/proofing/german_model/incremental_quality.dart", "tools/proofing/german_model/artifacts.json"}
PROVIDER_DIRS = ("packages/quds_proofing_gector/lib", "packages/quds_office_engine/lib/src/proofing/data", "packages/quds_office_engine/lib/src/opc/zip")
QUALITY_DIRS = ("packages/quds_proofing_gector/lib", "packages/quds_office_engine/lib/src/proofing", "packages/quds_office_engine/lib/src/opc/zip")
PANELS = ("original-30", "development-76", "syntax-56")


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def pin(path):
    path = Path(path)
    return {"file": path.name, "bytes": path.stat().st_size, "sha256": digest(path)}


def load(path):
    path = Path(path)
    raw = path.read_bytes()
    if path.suffix == ".gz":
        raw = gzip.decompress(raw)
    return json.loads(raw)


def tree_dart(directory, ancestors=frozenset()):
    target = directory.resolve()
    if target in ancestors:
        return
    for path in directory.iterdir():
        if path.is_dir():
            yield from tree_dart(path, ancestors | {target})
        elif path.is_file() and path.suffix == ".dart":
            yield path


def sources(root, target):
    names = set(PROVIDER_FIXED if target == "provider" else QUALITY_FIXED)
    for relative in PROVIDER_DIRS if target == "provider" else QUALITY_DIRS:
        names.update(path.relative_to(root).as_posix() for path in tree_dart(root / relative))
    return {name: digest(root / name) for name in sorted(names)}


def dependencies(root):
    config_path = root / ".dart_tool/package_config.json"
    config = load(config_path)
    if config.get("configVersion") != 2:
        raise ValueError("Expected resolved package configuration version 2")
    result = {}
    locations = {}
    for package in config["packages"]:
        name = package["name"]
        if not re.fullmatch(r"[A-Za-z0-9_]+", name) or name in result:
            raise ValueError("Invalid or repeated package name")
        root_uri = urljoin(config_path.as_uri(), package["rootUri"])
        library_uri = urljoin(root_uri.rstrip("/") + "/", package.get("packageUri", ""))
        uri = urlparse(library_uri)
        if uri.scheme != "file" or uri.netloc not in ("", "localhost"):
            raise ValueError("Dependency library is not a resolved local directory")
        directory = Path(unquote(uri.path))
        files = {path.relative_to(directory).as_posix(): digest(path) for path in tree_dart(directory)} if directory.is_dir() else {}
        fingerprint = hashlib.sha256(json.dumps(files, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        result[name] = {"library_directory_present": directory.is_dir(), "dart_file_count": len(files), "sha256": fingerprint}
        locations[name] = str(directory)
    return {"package_config": pin(config_path), "packages": dict(sorted(result.items()))}, locations


def sdk_snapshot(dart):
    dart = dart.resolve()
    sdk = dart.parent.parent
    suffix = ".exe" if dart.name.endswith(".exe") else ""
    paths = {"dart": dart, "dartaotruntime": dart.parent / ("dartaotruntime" + suffix), "gen_snapshot": dart.parent / "utils" / ("gen_snapshot" + suffix)}
    for relative in ("bin/snapshots/dartdev_aot.dart.snapshot", "bin/snapshots/dartdev.dart.snapshot",
        "bin/snapshots/gen_kernel_aot.dart.snapshot", "bin/snapshots/gen_kernel.dart.snapshot",
        "bin/dartvm", "bin/dartvm.exe", "lib/_internal/vm_platform.dill", "lib/_internal/vm_platform_product.dill",
        "lib/_internal/vm_platform_strong.dill", "version"):
        path = sdk / relative
        if path.is_file():
            paths[relative] = path
    return {name: pin(path) for name, path in paths.items()}


def git(root, *arguments):
    return subprocess.check_output(["git", *arguments], cwd=root)


def committed_sources(root, commit, selected):
    requests = [commit + ":" + path for path in selected]
    data = git_batch(root, requests)
    return {path: value for path, value in zip(selected, data)}


def git_batch(root, requests):
    process = subprocess.run(["git", "cat-file", "--batch"], cwd=root,
        input=("\n".join(requests) + "\n").encode(), capture_output=True, check=True)
    raw, cursor, result = process.stdout, 0, []
    for _ in requests:
        end = raw.index(b"\n", cursor)
        header = raw[cursor:end].decode()
        cursor = end + 1
        if header.endswith(" missing"):
            result.append(None)
            continue
        _, kind, length = header.split()
        if kind != "blob":
            raise ValueError("Expected a committed file blob")
        length = int(length)
        result.append(hashlib.sha256(raw[cursor:cursor + length]).hexdigest())
        cursor += length + 1
    return result


def mismatches(left, right):
    return [key for key in sorted(set(left) | set(right)) if left.get(key) != right.get(key)]


def binary_path(receipt_path, build, explicit=None):
    if explicit:
        return explicit
    name = build["runtime"]["entrypoint"]["file"]
    candidates = [receipt_path.parent / name, receipt_path.parent.parent / name]
    found = [path for path in candidates if path.is_file()]
    if len(found) != 1:
        raise ValueError("Cannot uniquely locate retained AOT file " + name)
    return found[0]


def audit_build(build, label, target, root, implementation, sdk, dependency_map, checks,
                actual_aot, actual_source=None, compare_current=True):
    checks.add(label + " complete stable successful build", all(build.get(k) is True for k in
        ("completed", "passed", "source_stable", "dependencies_stable", "sdk_stable"))
        and build.get("stage") == "complete" and build.get("compile", {}).get("returncode") == 0)
    checks.add(label + " before/after source dependency SDK maps agree", build["source_files"] == build["source_files_after"]
        and build["dependency_inputs"] == build["dependency_inputs_after"] and build["sdk_inputs"] == build["sdk_inputs_after"])
    checks.add(label + " actual recovered SDK matches all compiler inputs", sdk == build["sdk_inputs"], mismatches(sdk, build["sdk_inputs"]))
    checks.add(label + " compiler executable identity", build["compiler"]["executable"] == sdk["dart"])
    checks.add(label + " actual AOT artifact/runtime identities", build["runtime"] == {"executable": sdk["dartaotruntime"], "entrypoint": pin(actual_aot)})
    entry = PROVIDER_ENTRY if target == "provider" else QUALITY_ENTRY
    if compare_current:
        checks.add(label + " complete expected source inventory equals actual files", actual_source == build["source_files"], mismatches(actual_source, build["source_files"]))
        checks.add(label + " actual source entrypoint identity", build["source_entrypoint"] == pin(root / entry))
        checks.add(label + " all resolved package libraries equal actual dependencies", dependency_map == build["dependency_inputs"],
                   {"package_differences": mismatches(dependency_map["packages"], build["dependency_inputs"]["packages"]),
                    "package_config_matches": dependency_map["package_config"] == build["dependency_inputs"]["package_config"]})
    selected = list(build["source_files"])
    committed = committed_sources(root, implementation, selected)
    allowed_resolved = {"pubspec.lock", ".dart_tool/package_config.json"}
    changed = [path for path in selected if committed[path] != build["source_files"][path]
               and not (committed[path] is None and path in allowed_resolved)]
    checks.add(label + " source map bound to declared git implementation", not changed,
               {"implementation": implementation, "changed": changed, "resolved_untracked": [path for path in selected if committed[path] is None and path in allowed_resolved]})


def audit_pack(pack_dir, checks):
    manifest = load(pack_dir / "pack.json")
    errors = []
    for entry in manifest["files"]:
        path = pack_dir / entry["path"]
        if not path.resolve().is_relative_to(pack_dir.resolve()) or path.is_symlink() or not path.is_file() or path.stat().st_size != entry["bytes"] or digest(path) != entry["sha256"]:
            errors.append(entry["path"])
    checks.add("all declared native development-pack payloads match actual pins", not errors, errors)
    expected = {"pack.json", *(entry["path"] for entry in manifest["files"])}
    actual = {path.relative_to(pack_dir).as_posix() for path in pack_dir.rglob("*") if path.is_file()}
    checks.add("native pack contains exactly the declared payload", actual == expected)
    sizes = {"file_count": len(actual), "manifest_bytes": (pack_dir / "pack.json").stat().st_size,
             "payload_bytes": sum((pack_dir / entry["path"]).stat().st_size for entry in manifest["files"])}
    sizes["total_bytes"] = sizes["manifest_bytes"] + sizes["payload_bytes"]
    checks.add("native pack size accounting", sizes == manifest["sizes"])
    model_dir = pack_dir / manifest["model"]["directory"]
    native = pack_dir / manifest["native"]["path"]
    dynamic = []
    listing = subprocess.check_output(["ldd", str(native)], text=True)
    for entry in manifest["native"]["system_dependencies"]:
        match = re.search(r"(?:^|\n)\s*" + re.escape(entry["soname"]) + r"\s+=>\s+(\S+)", listing)
        if match:
            path = Path(match.group(1))
        else:
            match = re.search(r"(?:^|\n)\s*(/\S*/" + re.escape(entry["soname"]) + r")\s", listing)
            path = Path(match.group(1)) if match else None
        dynamic.append({"soname": entry["soname"], "path": str(path) if path else None,
                        "matches": path is not None and path.is_file() and digest(path) == entry["sha256"]})
    checks.add("actual dynamic system libraries match declared native dependencies", all(row["matches"] for row in dynamic), dynamic)
    return manifest, model_dir, native, sizes


def bind_run(run, build, label, expected_sources, model_dir, native, pack, assets, checks, corpus=None):
    selected = dict(run["source_files"])
    if corpus is not None:
        checks.add(label + " declared corpus matches actual bytes", selected.pop("declared-corpus", None) == digest(corpus) == run["cases_sha256"])
        checks.add(label + " before/after quality sources stable", run["source_files"] == run["source_files_after"])
    checks.add(label + " selected sources equal independently reconstructed build inputs", selected == expected_sources and run["source_stable"] is True, mismatches(selected, expected_sources))
    checks.add(label + " actual compiled program/runtime pins match build", all(run["runtime"][key] == value for key, value in build["runtime"].items()))
    expected_model = {"file": pack["model"]["file"], "sha256": pack["model"]["sha256"], "bytes": pack["model"]["size_bytes"],
                      "revision": pack["model"]["revision"], "source_model_sha256": pack["model"]["source_model_sha256"]}
    checks.add(label + " exact native model and library identities", run["model"] == expected_model and run["native_library_sha256"] == digest(native))
    mismatched_assets = [name for name, sha in run["bundle_assets"].items() if not (model_dir / name).is_file() or digest(model_dir / name) != sha]
    checks.add(label + " full verified bundle asset inventory and actual hashes", set(run["bundle_assets"]) == assets and not mismatched_assets, mismatched_assets)


def audit(args):
    from final_quality_audit import audit_quality
    checks = Checks()
    root, final, baseline = args.root.resolve(), args.final_dir.resolve(), args.baseline_dir.resolve()
    report = {"schema_version": 1, "kind": "quds-independent-final-native-quality-audit", "started_utc": datetime.now(timezone.utc).isoformat(),
        "implementation_commit": args.implementation, "baseline_implementation_commit": args.baseline_implementation,
        "completed": False, "passed": False,
        "method": "Read saved JSON and actual source, dependency, SDK, pack and AOT files; independently reconstruct pins, UTF-16 findings, initial WordPiece fingerprints, actual pass/cache accounting, statistics and quality projections. No inference, compiler, test suite or CI commands invoked.",
        "limits": [
            "The original 30, development 76 and syntax 56 inputs are separately labeled synthetic regression panels. They do not establish population-level German accuracy.",
            "The former prospective 76-case panel has now informed development. Its frozen input identity is preserved, but this continuation is not a fresh prospective evaluation.",
            "Repeated boilerplate and varied synthetic paragraphs are separate structural/performance controls; neither is a representative long-document quality corpus.",
            "Three timing samples per structural input make nearest-rank p95 the maximum sample. No intended-device responsiveness conclusion follows from local-host measurements.",
            "Initial pass fingerprints are independently reconstructed from original segment text. Later-pass words and raw tags are not retained, so their fingerprints receive trajectory/cache-consistency checks only.",
            "Second and third timed corrected strings/findings are not individually retained. Their durations and actual decoder pass trajectories are retained and checked; complete repeated-output stability is still producer-reported.",
            "Failed checks with no worker result expose unavailable diagnostic counters, not zero forward work.",
            "The short-check 500 ms engineering flag applies only to the declared <=64 logical-token sample aggregate; long probes are reported separately.",
            "Native FFI calls themselves are not interruptible; cancellation is checked between calls. Correctness bounds are supported by reviewed source and separately retained regression tests.",
        ]}
    observed = git(root, "rev-parse", "HEAD").decode().strip()
    report["observed_head"] = observed
    report["audit_inputs"] = {}
    def read(path):
        report["audit_inputs"][str(path)] = pin(path)
        return load(path)
    try:
        report["audit_scripts"] = {name: pin(Path(__file__).with_name(name)) for name in
                                  ("final_evidence_audit.py", "final_native_audit.py", "final_quality_audit.py")}
        provider_path, quality_path = final / "build/provider-build.json", final / "build/quality-build.json"
        provider_build, quality_build = read(provider_path), read(quality_path)
        baseline_build_path = baseline / "quality-build.json"
        baseline_build = read(baseline_build_path)
        provider_sources, quality_sources = sources(root, "provider"), sources(root, "incremental-quality")
        dependency_map, locations = dependencies(root)
        sdk = sdk_snapshot(args.dart)
        report["identity_summary"] = {"provider_source_files": len(provider_sources), "quality_source_files": len(quality_sources),
            "resolved_packages": len(dependency_map["packages"]), "dependency_dart_files": sum(v["dart_file_count"] for v in dependency_map["packages"].values()),
            "sdk_inputs": len(sdk), "dependency_locations": locations}
        provider_aot = binary_path(provider_path, provider_build, args.provider_aot)
        quality_aot = binary_path(quality_path, quality_build, args.quality_aot)
        baseline_aot = binary_path(baseline_build_path, baseline_build)
        for target, build, aot, selected in [("provider", provider_build, provider_aot, provider_sources), ("incremental-quality", quality_build, quality_aot, quality_sources)]:
            audit_build(build, target, target, root, args.implementation, sdk, dependency_map, checks, aot, selected)
            report["audit_inputs"][str(aot)] = pin(aot)
        audit_build(baseline_build, "archived43d quality", "incremental-quality", root, args.baseline_implementation,
                    sdk, dependency_map, checks, baseline_aot, compare_current=False)
        report["audit_inputs"][str(baseline_aot)] = pin(baseline_aot)
        pack, model_dir, native, sizes = audit_pack(args.pack.resolve(), checks)
        report["pack"] = {"manifest": pin(args.pack / "pack.json"), "sizes": sizes, "model": pack["model"], "native_library": pin(native)}
        artifacts = read(root / "tools/proofing/german_model/artifacts.json")
        expected_assets = {entry["file"] for entry in artifacts if entry["file"] != "model.onnx"} | {pack["model"]["file"]}
        tokenizer = IndependentTokenizer(load(model_dir / "tokenizer.json"), load(model_dir / "language-rules.json"))
        tokenizer_oracle = read(root / "packages/quds_proofing_gector/test/fixtures/tokenizer_oracle.json")
        oracle_errors = []
        for example in tokenizer_oracle:
            try:
                arrays = tokenizer.arrays(example["words"])
                if example["missing_word"] or arrays[1] != example["input_ids"] or arrays[3] != example["first_subword_indices"]:
                    oracle_errors.append(example["id"])
            except ValueError:
                if not example["missing_word"]:
                    oracle_errors.append(example["id"])
        checks.add("independent scalar tokenizer agrees with saved pinned input oracle", not oracle_errors,
                   {"cases": len(tokenizer_oracle), "mismatched_ids": oracle_errors})
        reference_path = args.reference or args.pack.parent / "reference-f32/reference.json"
        reference = read(reference_path)
        frozen_path = root / "tools/proofing/german_model/cases.json"
        frozen = read(frozen_path)
        historical_dir = args.historical_native_dir or root / "docs/validation/german-gector/2026-11-17-long-input"
        historical = {mode: read(historical_dir / ("provider-" + mode + ".json.gz")) for mode in ("single", "segmented")}
        native_runs, native_audits = {}, {}
        for mode in ("single", "segmented", "reuse"):
            run = read(final / "native" / (mode + ".json"))
            native_runs[mode] = run
            bind_run(run, provider_build, "native " + mode, provider_sources, model_dir, native, pack, expected_assets, checks)
            checks.add("native " + mode + " exact reference and immutable corpus hashes", run["reference_sha256"] == digest(reference_path) and run["cases_sha256"] == digest(frozen_path))
            native_audits[mode] = audit_native(run, mode, frozen, historical["single" if mode == "single" else "segmented"], tokenizer, reference)
            checks.add("native " + mode + " independent reconstruction", native_audits[mode]["passed"], native_audits[mode]["errors"])
        report["native"] = native_audits
        report["reuse_comparison"] = compare_native_modes(native_runs["segmented"], native_runs["reuse"])
        checks.add("paired segmented/reuse inputs and decoder results", report["reuse_comparison"]["passed"], report["reuse_comparison"]["errors"])
        quality_audits, quality_runs = {}, {}
        corpora = {"original-30": frozen_path, "development-76": root / "tools/proofing/german_model/prospective_cases_20261117.json",
                   "syntax-56": args.syntax_corpus or root / "docs/validation/german-gector/2026-11-17-resume/corpora/syntax-56-quality.json"}
        raw_syntax_path = root / "tools/proofing/german_model/syntax_cases_20261117.json"
        raw_syntax = read(raw_syntax_path)
        adapted = load(corpora["syntax-56"])
        expected_adapted = [{**{key: value for key, value in row.items() if key != "area"}, "category": row["area"]} for row in raw_syntax]
        checks.add("syntax adaptation changes metadata name only, preserving source and gold", adapted == expected_adapted and len(adapted) == 56)
        corpus_paths = [frozen_path, corpora["development-76"], raw_syntax_path]
        for path in corpus_paths:
            relative = path.relative_to(root).as_posix()
            committed = git_batch(root, [args.baseline_implementation + ":" + relative, args.implementation + ":" + relative])
            checks.add(relative + " unchanged from archived integration through final implementation", committed[0] == committed[1] == digest(path))
        for panel in PANELS:
            corpus_path = corpora[panel]
            corpus = read(corpus_path)
            baseline_path = baseline / ("syntax-adapted/syntax-56.json" if panel == "syntax-56" else "quality/" + panel + ".json")
            old = read(baseline_path)
            run = read(final / "quality" / (panel + ".json"))
            quality_runs[panel] = run
            bind_run(run, quality_build, "quality " + panel, quality_sources, model_dir, native, pack, expected_assets, checks, corpus_path)
            baseline_sources = dict(old["source_files"])
            baseline_declared = baseline_sources.pop("declared-corpus")
            checks.add(panel + " archived43d baseline source/build/runtime/corpus binding", baseline_sources == baseline_build["source_files"]
                and old["source_files"] == old["source_files_after"]
                and all(old["runtime"][key] == value for key, value in baseline_build["runtime"].items())
                and old["completed"] is True and old["source_stable"] is True and old["operational_passed"] is True
                and baseline_declared == old["cases_sha256"] == run["cases_sha256"] == digest(corpus_path))
            checks.add(panel + " final and baseline model/library/assets identical", all(run[key] == old[key] for key in ("model", "native_library_sha256", "bundle_assets")))
            quality_audits[panel] = audit_quality(run, old, {"cases": corpus, "sha256": digest(corpus_path)})
            checks.add(panel + " independent quality projection/summary reconstruction", not quality_audits[panel].get("errors"), quality_audits[panel].get("errors"))
        report["quality"] = quality_audits
        model_rows = {row["id"]: row for row in quality_runs["original-30"]["cases"]}
        cross_differences = []
        for row in native_runs["single"]["cases"]:
            other = model_rows[row["id"]]
            lane = other["outcomes"]["model_only"]
            actual_findings = [(f["start"] - row["start_offset"], f["end"] - row["start_offset"], f["original"], f["replacement"], f["rule_id"]) for f in row["findings"]]
            quality_findings = [(f["start"] - other["start_offset"], f["end"] - other["start_offset"], f["original"], f["replacements"][0], f["rule_id"]) for f in lane["displayed_findings"]]
            same_projection = (row["corrected"] == lane["corrected"] if row["status"] == "success" else
                               not lane["complete"] and lane["corrected"] is None and row["corrected"] == row["input"])
            if row["input"] != other["input"] or not same_projection or row["status"] != lane["results"][0]["status"] or actual_findings != quality_findings:
                cross_differences.append(row["id"])
        checks.add("independent quality model lane agrees with native single-sequence original panel", not cross_differences, cross_differences)
        failed_syntax = baseline / "quality/syntax-56.json"
        if failed_syntax.is_file():
            failed = read(failed_syntax)
            report["excluded_failed_baseline_attempt"] = {"path": str(failed_syntax), "completed": failed.get("completed"), "error": failed.get("error"),
                "reason": "Preserved failed metadata admission; the completed syntax-adapted baseline is audited instead."}
            checks.add("failed baseline attempt remains explicitly excluded", failed.get("completed") is False)
        report["completed"] = True
    except Exception as error:
        checks.add("audit execution completed", False, {"error": repr(error), "traceback": traceback.format_exc()})
    report.update(checks.result())
    report["finished_utc"] = datetime.now(timezone.utc).isoformat()
    report["passed"] = report["completed"] and report["passed"]
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--final-dir", type=Path, required=True)
    parser.add_argument("--baseline-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--implementation", default="143bad2f69976c331ac98ea7b4adbaec430af916")
    parser.add_argument("--baseline-implementation", default="43d43061ac33e2e3b336a79fb4b07b036bc617a8")
    parser.add_argument("--dart", type=Path, default=Path(os.environ.get("FLUTTER_ROOT", ".")) / "bin/cache/dart-sdk/bin/dart")
    parser.add_argument("--pack", type=Path, default=Path(os.environ.get("GECTOR_PACK", ".")))
    parser.add_argument("--reference", type=Path)
    parser.add_argument("--provider-aot", type=Path)
    parser.add_argument("--quality-aot", type=Path)
    parser.add_argument("--syntax-corpus", type=Path)
    parser.add_argument("--historical-native-dir", type=Path)
    parser.add_argument("--plan", action="store_true")
    args = parser.parse_args()
    if args.plan:
        print(json.dumps({"executes_inference": False, "expected_final": [str(args.final_dir / relative) for relative in
            ["build/provider-build.json", "build/quality-build.json", *["native/" + mode + ".json" for mode in ("single", "segmented", "reuse")],
             *["quality/" + panel + ".json" for panel in PANELS]]],
            "baseline_syntax": str(args.baseline_dir / "syntax-adapted/syntax-56.json"), "output": str(args.output)}, indent=2))
        return 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x") as destination:
        result = audit(args)
        json.dump(result, destination, ensure_ascii=False, indent=2)
        destination.write("\n")
    print(json.dumps({"output": str(args.output), "completed": result["completed"], "passed": result["passed"],
        "checks_passed": result["checks_passed"], "checks_total": result["checks_total"], "errors": result["errors"]}, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
