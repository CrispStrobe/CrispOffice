"""Independent reconstruction of saved German quality receipts.

audit_quality(final_data, baseline_data, corpus_data) consumes parsed JSON and
does no I/O, inference, subprocess, source mutation or network operation.
corpus_data is the raw list, or {"cases": raw_list, "sha256": exact_byte_digest}.
"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
import json
import math
import re

LANES = ("writing_only", "deterministic", "model_only", "combined")
PROVIDERS = {
    "writing_only": ["german-writing"],
    "deterministic": ["german-spelling", "german-writing"],
    "model_only": ["gector-de"],
    "combined": ["german-spelling", "german-writing", "gector-de"],
}
STATUSES = {"success", "unsupported", "failed", "unavailable"}
POLICY = (
    "Single pass over the original snapshot; first replacement only; "
    "provider/result order gives precedence; overlapping proposals and "
    "advisories without replacements are skipped explicitly. Insertions "
    "conflict at either endpoint. Expected text never selects a replacement. "
    "Incomplete reports have no projected correction."
)


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _small(value):
    rendered = _canonical(value)
    return value if len(rendered) <= 360 else rendered[:360] + "…"


def _error(errors, path, message, expected=None, actual=None):
    errors.append({"path": path, "message": message,
                   "expected": _small(expected), "actual": _small(actual)})


def _compare(expected, actual, path, errors):
    if isinstance(expected, dict) and isinstance(actual, dict):
        for key in expected.keys() - actual.keys():
            _error(errors, path + "." + key, "Missing field", expected[key], None)
        for key in actual.keys() - expected.keys():
            _error(errors, path + "." + key, "Unexpected field", None, actual[key])
        for key in expected.keys() & actual.keys():
            _compare(expected[key], actual[key], path + "." + key, errors)
    elif isinstance(expected, list) and isinstance(actual, list):
        if len(expected) != len(actual):
            _error(errors, path, "List length differs", len(expected), len(actual))
        for index, (left, right) in enumerate(zip(expected, actual)):
            _compare(left, right, f"{path}[{index}]", errors)
    elif type(expected) is not type(actual) or expected != actual:
        _error(errors, path, "Value differs", expected, actual)


def normalize_language(language):
    parts = language.strip().replace("_", "-").split("-")
    base = parts[0].lower()
    canonical = [base] + [p.upper() if len(p) == 2 else p.lower() for p in parts[1:]]
    if base not in {"de", "en"}:
        return "-".join(canonical)
    index = 1
    if index < len(canonical) and canonical[index] == "latn":
        index += 1
    region = "DE" if base == "de" else "US"
    if index < len(canonical) and re.fullmatch(r"[A-Z]{2}", canonical[index]):
        region = canonical[index]
        index += 1
    if base == "de" and index < len(canonical) and canonical[index] == "1996":
        index += 1
    if index < len(canonical) and canonical[index] == "u" and index + 1 < len(canonical):
        attributes, keys, valid = set(), set(), True
        for part in canonical[index + 1:]:
            if re.fullmatch(r"[a-z0-9][a-z]", part, re.IGNORECASE):
                valid = valid and part not in keys
                keys.add(part)
            elif re.fullmatch(r"[a-z0-9]{3,8}", part, re.IGNORECASE):
                if not keys:
                    valid = valid and part not in attributes
                    attributes.add(part)
            else:
                valid = False
        if valid:
            index = len(canonical)
    return f"{base}-{region}" if index == len(canonical) else "-".join(canonical)


def _utf16(text):
    # Strict conversion rejects unpaired surrogates in parsed JSON strings.
    return text.encode("utf-16-le")


def _cases(raw, errors):
    if not isinstance(raw, list) or not 1 <= len(raw) <= 2000:
        _error(errors, "corpus", "Expected a nonempty bounded raw case list")
        return []
    result, ids = [], set()
    allowed = {"id", "kind", "input", "expected", "locale", "category", "pair_id", "expected_model_status"}
    for index, value in enumerate(raw):
        try:
            if not isinstance(value, dict) or value.keys() - allowed:
                raise ValueError("Unexpected fields; supply the metadata-adapted syntax corpus")
            for key in ("id", "kind", "input"):
                if not isinstance(value[key], str) or not value[key].strip():
                    raise ValueError(f"{key} must be nonempty text")
                _utf16(value[key])
            if value["id"] in ids or value["kind"] not in {"error", "clean"}:
                raise ValueError("Duplicate ID or invalid kind")
            expected = value.get("expected", value["input"] if value["kind"] == "clean" else None)
            if not isinstance(expected, str) or not expected.strip():
                raise ValueError("Expected text is missing or empty")
            _utf16(expected)
            if (value["kind"] == "error") == (expected == value["input"]):
                raise ValueError("Kind disagrees with expected text")
            locale = value.get("locale", "de-DE")
            if not isinstance(locale, str) or not locale.strip():
                raise ValueError("Invalid locale")
            _utf16(locale)
            language = normalize_language(locale)
            model_status = "success" if language == "de-DE" else "unsupported"
            if value.get("expected_model_status", model_status) != model_status:
                raise ValueError("Model status disagrees with locale policy")
            case = {"id": value["id"], "kind": value["kind"], "input": value["input"],
                    "expected": expected, "locale": locale, "language": language,
                    "expected_model_status": model_status}
            for key in ("category", "pair_id"):
                if value.get(key) is not None:
                    if not isinstance(value[key], str) or not value[key].strip():
                        raise ValueError(f"Invalid {key}")
                    _utf16(value[key])
                    case[key] = value[key]
            result.append(case)
            ids.add(value["id"])
        except (KeyError, TypeError, ValueError, UnicodeError) as error:
            _error(errors, f"corpus[{index}]", str(error))
    return result


def _conflict(a, b):
    if a["start"] == a["end"]:
        return b["start"] <= a["start"] <= b["end"]
    if b["start"] == b["end"]:
        return a["start"] <= b["start"] <= a["end"]
    return a["start"] < b["end"] and b["start"] < a["end"]


def _displayed(results):
    return sorted([f for r in results if r["status"] == "success" for f in r["findings"]],
                  key=lambda f: (f["start"], f["end"]))


def _compare_displayed(expected, actual, path, errors):
    # Dart does not guarantee stable sorting at tied coordinates. Compare full
    # multisets and coordinate order without inventing a tie-breaking policy.
    if not isinstance(actual, list):
        _error(errors, path, "Expected finding list", expected, actual)
        return
    keys = [(f.get("start"), f.get("end")) for f in actual]
    try:
        ordered = keys == sorted(keys)
    except TypeError:
        ordered = False
    if not ordered:
        _error(errors, path, "Displayed findings are not sorted by coordinates")
    if Counter(map(_canonical, expected)) != Counter(map(_canonical, actual)):
        _error(errors, path, "Displayed finding multiset differs", expected, actual)


def _validate_results(results, case, offset, path, errors):
    if not isinstance(results, list):
        raise ValueError("Provider results must be a list")
    source, seen = _utf16(case["input"]), set()
    for index, result in enumerate(results):
        prefix, provider = f"{path}[{index}]", result["provider_id"]
        if not isinstance(provider, str) or provider in seen:
            _error(errors, prefix, "Invalid or duplicate provider ID", None, provider)
        seen.add(provider)
        status = result["status"]
        if status not in STATUSES:
            _error(errors, prefix + ".status", "Unknown status", sorted(STATUSES), status)
        if status != "success" and result["findings"]:
            _error(errors, prefix, "Unsuccessful provider returned findings")
        if result.get("message") is not None and not isinstance(result["message"], str):
            _error(errors, prefix + ".message", "Invalid provider message")
        for finding_index, finding in enumerate(result["findings"]):
            item = f"{prefix}.findings[{finding_index}]"
            _compare(provider, finding["provider_id"], item + ".provider_id", errors)
            if type(finding["start"]) is not int or type(finding["end"]) is not int:
                raise ValueError("Finding coordinates must be integers")
            start, end = finding["start"] - offset, finding["end"] - offset
            if not 0 <= start <= end <= len(source) // 2:
                raise ValueError("Finding is outside original UTF-16 source")
            _compare(source[start * 2:end * 2].decode("utf-16-le"), finding["original"], item + ".original", errors)
            if not isinstance(finding["replacements"], list):
                raise ValueError("Replacements must be a list")
            for replacement in finding["replacements"]:
                _utf16(replacement)
            if finding["category"] not in {"spelling", "grammar", "style"}:
                _error(errors, item + ".category", "Unknown category")
            for key in ("rule_id", "message"):
                if not isinstance(finding[key], str):
                    _error(errors, item + "." + key, "Expected text")


def _projection(results, case, offset):
    statuses = [r["status"] for r in results]
    complete = "success" in statuses and all(s in {"success", "unsupported"} for s in statuses)
    displayed, accepted, skipped = _displayed(results), [], []
    for result in results:
        if result["status"] != "success":
            continue
        for finding in result["findings"]:
            if not complete:
                reason = "incomplete-report"
            elif not finding["replacements"]:
                reason = "no-replacement-advisory"
            elif any(_conflict(previous, finding) for previous in accepted):
                reason = "overlap-with-earlier-projection"
            else:
                reason = None
            if reason is None:
                accepted.append(finding)
            else:
                skipped.append({**finding, "reason": reason})
    corrected = None
    if complete:
        data = _utf16(case["input"])
        for finding in sorted(accepted, key=lambda f: f["start"], reverse=True):
            start, end = (finding["start"] - offset) * 2, (finding["end"] - offset) * 2
            data = data[:start] + _utf16(finding["replacements"][0]) + data[end:]
        corrected = data.decode("utf-16-le")
    return {"complete": complete, "clean_report": complete and not displayed, "flagged": bool(displayed),
            "corrected": corrected, "changed": corrected is not None and corrected != case["input"],
            "exact_expected": complete and corrected == case["expected"], "results": deepcopy(results),
            "displayed_findings": displayed,
            "projected_findings": [{**f, "replacement_index": 0} for f in accepted], "skipped_findings": skipped,
            "unsupported_only": bool(statuses) and all(s == "unsupported" for s in statuses),
            "operational_failure": any(s in {"failed", "unavailable"} for s in statuses)}


def _merge(primary, secondary):
    accepted = list(_displayed(primary))
    results, kept_model, suppressed = deepcopy(primary), [], []
    for result in secondary:
        kept = []
        for finding in result["findings"]:
            if any(_conflict(previous, finding) for previous in accepted):
                suppressed.append(finding)
            else:
                kept.append(finding)
                accepted.append(finding)
                kept_model.append(finding)
        results.append({**deepcopy(result), "findings": kept})
    suppressed.sort(key=lambda f: (f["start"], f["end"]))
    return results, kept_model, suppressed


def _summarize(cases, rows, include_languages=True):
    def ids(predicate):
        return [case["id"] for case in cases if predicate(case, rows[case["id"]])]
    def comparable(row):
        return all(row["outcomes"][lane]["complete"] for lane in ("model_only", "deterministic", "combined"))
    result = {"case_count": len(cases), "error_count": sum(c["kind"] == "error" for c in cases),
              "clean_count": sum(c["kind"] == "clean" for c in cases), "lanes": {}}
    for lane in LANES:
        predicates = {
            "completed": lambda c, p: p["complete"],
            "completed_error": lambda c, p: c["kind"] == "error" and p["complete"],
            "completed_clean": lambda c, p: c["kind"] == "clean" and p["complete"],
            "exact_error": lambda c, p: c["kind"] == "error" and p["exact_expected"],
            "changed_nonexact_error": lambda c, p: c["kind"] == "error" and p["changed"] and not p["exact_expected"],
            "changed_clean": lambda c, p: c["kind"] == "clean" and p["changed"],
            "flagged_clean": lambda c, p: c["kind"] == "clean" and p["flagged"],
            "unchanged_clean": lambda c, p: c["kind"] == "clean" and p["complete"] and not p["changed"],
            "unflagged_clean": lambda c, p: c["kind"] == "clean" and p["clean_report"],
            "unsupported_only": lambda c, p: p["unsupported_only"],
            "incomplete": lambda c, p: not p["complete"],
            "operational_failure": lambda c, p: p["operational_failure"],
        }
        metrics = {}
        for key, predicate in predicates.items():
            chosen = ids(lambda c, row: predicate(c, row["outcomes"][lane]))
            metrics[key + "_ids"], metrics[key + "_count"] = chosen, len(chosen)
        result["lanes"][lane] = metrics
    predicates = {
        "comparable": lambda c, r: comparable(r),
        "not_comparable": lambda c, r: not comparable(r),
        "added_exact_error": lambda c, r: comparable(r) and c["kind"] == "error" and not r["outcomes"]["deterministic"]["exact_expected"] and r["outcomes"]["combined"]["exact_expected"],
        "lost_exact_error": lambda c, r: comparable(r) and c["kind"] == "error" and r["outcomes"]["deterministic"]["exact_expected"] and not r["outcomes"]["combined"]["exact_expected"],
        "model_unique_exact_error": lambda c, r: comparable(r) and c["kind"] == "error" and r["outcomes"]["model_only"]["exact_expected"] and not r["outcomes"]["deterministic"]["exact_expected"],
        "new_changed_clean": lambda c, r: comparable(r) and c["kind"] == "clean" and not r["outcomes"]["deterministic"]["changed"] and r["outcomes"]["combined"]["changed"],
        "new_flagged_clean": lambda c, r: comparable(r) and c["kind"] == "clean" and not r["outcomes"]["deterministic"]["flagged"] and r["outcomes"]["combined"]["flagged"],
        "model_changed_clean": lambda c, r: c["kind"] == "clean" and r["outcomes"]["model_only"]["changed"],
    }
    result["incremental"] = {name + "_ids": ids(predicate) for name, predicate in predicates.items()}
    result["incremental"].update({
        "accepted_model_finding_count": sum(len(rows[c["id"]]["accepted_model_findings"]) for c in cases),
        "suppressed_model_finding_count": sum(len(rows[c["id"]]["suppressed_model_findings"]) for c in cases)})
    result["operational_passed"] = all(not p["operational_failure"] and (p["complete"] or p["unsupported_only"])
                                       for case in cases for p in rows[case["id"]]["outcomes"].values())
    if include_languages:
        result["by_language"] = {lang: _summarize([c for c in cases if c["language"] == lang], rows, False)
                                 for lang in dict.fromkeys(c["language"] for c in cases)}
    return result


def _categories(cases, rows):
    return {category: _summarize([c for c in cases if c.get("category", "unclassified") == category], rows, False)
            for category in dict.fromkeys(c.get("category", "unclassified") for c in cases)}


def _pairs(cases, rows):
    pairs = {}
    for pair in dict.fromkeys(c["pair_id"] for c in cases if "pair_id" in c):
        members = [c for c in cases if c.get("pair_id") == pair]
        errors, controls = [c for c in members if c["kind"] == "error"], [c for c in members if c["kind"] == "clean"]
        eligible, lanes = bool(errors and controls), {}
        for lane in LANES:
            exact = bool(errors) and all(rows[c["id"]]["outcomes"][lane]["exact_expected"] for c in errors)
            unchanged = bool(controls) and all(rows[c["id"]]["outcomes"][lane]["complete"] and
                                              not rows[c["id"]]["outcomes"][lane]["changed"] for c in controls)
            unflagged = bool(controls) and all(rows[c["id"]]["outcomes"][lane]["clean_report"] for c in controls)
            lanes[lane] = {"all_errors_exact": exact, "all_clean_unchanged": unchanged,
                           "all_clean_unflagged": unflagged, "strict_pair_success": eligible and exact and unflagged}
        pairs[pair] = {"case_ids": [c["id"] for c in members], "error_ids": [c["id"] for c in errors],
                       "clean_ids": [c["id"] for c in controls], "eligible_error_clean_pair": eligible, "lanes": lanes}
    return {"paired_case_count": sum("pair_id" in c for c in cases),
            "unpaired_case_ids": [c["id"] for c in cases if "pair_id" not in c],
            "pair_count": len(pairs), "eligible_pair_count": sum(p["eligible_error_clean_pair"] for p in pairs.values()),
            "strict_success_count": {lane: sum(p["lanes"][lane]["strict_pair_success"] for p in pairs.values()) for lane in LANES},
            "pairs": pairs}


def _audit_one(data, cases, corpus_sha, label, errors):
    expected_cases, rows = {c["id"]: c for c in cases}, {}
    if not isinstance(data, dict):
        _error(errors, label, "Receipt must be a JSON object")
        return None
    _compare("quds-german-incremental-quality", data.get("kind"), label + ".kind", errors)
    _compare(True, data.get("completed"), label + ".completed", errors)
    _compare("complete", data.get("stage"), label + ".stage", errors)
    _compare(True, data.get("live_native_provider"), label + ".live_native_provider", errors)
    _compare(POLICY, data.get("projection_policy"), label + ".projection_policy", errors)
    _compare(cases, data.get("declared_cases"), label + ".declared_cases", errors)
    if corpus_sha is not None:
        _compare(corpus_sha, data.get("cases_sha256"), label + ".cases_sha256", errors)
    _compare(data.get("cases_sha256"), data.get("source_files", {}).get("declared-corpus"),
             label + ".declared_corpus_source_hash", errors)
    stable = isinstance(data.get("source_files"), dict) and data.get("source_files") == data.get("source_files_after")
    _compare(stable, data.get("source_stable"), label + ".source_stable", errors)
    raw_rows = data.get("cases", [])
    if not isinstance(raw_rows, list):
        _error(errors, label + ".cases", "Expected case rows")
        return None
    _compare([c["id"] for c in cases], [r.get("id") for r in raw_rows], label + ".case_order", errors)
    statuses_passed = True
    for row_index, raw in enumerate(raw_rows):
        case_id = raw.get("id")
        path = f"{label}.cases[{row_index}]({case_id})"
        if case_id not in expected_cases or case_id in rows:
            _error(errors, path, "Foreign or duplicated case ID")
            continue
        case = expected_cases[case_id]
        try:
            for key, value in case.items():
                _compare(value, raw.get(key), path + "." + key, errors)
            for key in ("category", "pair_id"):
                if key not in case and key in raw:
                    _error(errors, path + "." + key, "Undeclared metadata")
            offset = raw["start_offset"]
            _compare(37, offset, path + ".start_offset", errors)
            if type(offset) is not int or offset < 0:
                raise ValueError("Invalid source offset")
            if set(raw["outcomes"]) != set(LANES):
                raise ValueError("Exactly four quality lanes are required")
            computed = {}
            for lane in LANES:
                lane_path = path + ".outcomes." + lane
                results = raw["outcomes"][lane]["results"]
                _validate_results(results, case, offset, lane_path + ".results", errors)
                _compare(PROVIDERS[lane], [r["provider_id"] for r in results], lane_path + ".provider_order", errors)
                projection = _projection(results, case, offset)
                for key, value in projection.items():
                    if key == "displayed_findings":
                        _compare_displayed(value, raw["outcomes"][lane].get(key), lane_path + "." + key, errors)
                    elif key not in {"unsupported_only", "operational_failure"}:
                        _compare(value, raw["outcomes"][lane].get(key), lane_path + "." + key, errors)
                computed[lane] = projection
            deterministic, model = computed["deterministic"]["results"], computed["model_only"]["results"]
            _compare([r for r in deterministic if r["provider_id"] == "german-writing"],
                     computed["writing_only"]["results"], path + ".writing_matches_deterministic", errors)
            merged, accepted, suppressed = _merge(deterministic, model)
            _compare(merged, computed["combined"]["results"], path + ".actual_manual_merge", errors)
            _compare(accepted, raw["accepted_model_findings"], path + ".accepted_model_findings", errors)
            _compare_displayed(suppressed, raw["suppressed_model_findings"], path + ".suppressed_model_findings", errors)
            status = "success" if case["language"] in {"de-DE", "de-AT", "de-CH"} else "unsupported"
            expected_statuses = {"german-spelling": status, "german-writing": status, "gector-de": case["expected_model_status"]}
            _compare(expected_statuses, raw["expected_statuses"], path + ".expected_statuses", errors)
            correct_status = all(r["status"] == expected_statuses.get(r["provider_id"]) for r in deterministic + model)
            _compare(correct_status, raw["status_contract_passed"], path + ".status_contract_passed", errors)
            if not correct_status:
                _error(errors, path, "Actual provider status violates declared contract")
            statuses_passed = statuses_passed and correct_status
            for name in ("deterministic", "model"):
                number = raw["timing_ms"][name]
                if type(number) not in {int, float} or not math.isfinite(number) or number < 0:
                    _error(errors, path + ".timing_ms." + name, "Invalid retained duration")
            rows[case_id] = {"outcomes": computed, "accepted_model_findings": accepted, "suppressed_model_findings": suppressed}
        except (KeyError, TypeError, ValueError, UnicodeError, AttributeError) as error:
            _error(errors, path, "Cannot reconstruct row: " + str(error))
    if len(rows) != len(cases):
        _error(errors, label, "Incomplete reconstructed coverage", len(cases), len(rows))
        return None
    summary = _summarize(cases, rows)
    _compare(summary, data.get("summary"), label + ".summary", errors)
    _compare(statuses_passed, data.get("status_contract_passed"), label + ".status_contract_passed", errors)
    _compare(stable and statuses_passed and summary["operational_passed"], data.get("operational_passed"),
             label + ".operational_passed", errors)
    _compare(True, data.get("operational_passed"), label + ".required_operational_pass", errors)
    return {"summary": summary, "by_category": _categories(cases, rows), "pairs": _pairs(cases, rows), "rows": rows}


def _delta(before, after):
    result = {"case_count": after["case_count"], "error_count": after["error_count"], "clean_count": after["clean_count"], "lanes": {}}
    for lane in LANES:
        prior, current = before["lanes"][lane], after["lanes"][lane]
        item = {"counts": {key: {"baseline": prior[key], "final": current[key], "delta": current[key] - prior[key]}
                           for key in prior if key.endswith("_count")}}
        for metric in ("exact_error", "changed_nonexact_error", "changed_clean", "flagged_clean", "operational_failure", "incomplete"):
            old, new = prior[metric + "_ids"], current[metric + "_ids"]
            item[metric + "_added_ids"] = [value for value in new if value not in old]
            item[metric + "_removed_ids"] = [value for value in old if value not in new]
        item.update(
            gained_exact_error_ids=item["exact_error_added_ids"],
            lost_exact_error_ids=item["exact_error_removed_ids"],
            new_changed_clean_ids=item["changed_clean_added_ids"],
            resolved_changed_clean_ids=item["changed_clean_removed_ids"],
            new_flagged_clean_ids=item["flagged_clean_added_ids"],
            resolved_flagged_clean_ids=item["flagged_clean_removed_ids"],
        )
        result["lanes"][lane] = item
    return result


def audit_quality(final_data, baseline_data, corpus_data):
    """Return JSON-serializable audit evidence with errors rather than assertions."""
    errors = []
    if isinstance(corpus_data, dict):
        corpus_sha, raw_cases = corpus_data.get("sha256"), corpus_data.get("cases")
    else:
        corpus_sha, raw_cases = None, corpus_data
    cases = _cases(raw_cases, errors)
    report = {"schema_version": 1, "kind": "independent-saved-german-quality-audit",
              "interpretation": "Synthetic regression/development panels; exact first-replacement projection is a measurement convention, not automatic application or representative German accuracy.",
              "case_count": len(cases), "errors": errors, "passed": False, "corpus_byte_hash_supplied": corpus_sha is not None,
              "limits": [
                  "Pass {cases,sha256} to check the exact recorded corpus-byte digest; a raw parsed list supports semantic case identity only.",
                  "UTF-16 bounds, source substrings and surrogate boundaries are independently checked; full extended-grapheme segmentation is not reimplemented.",
                  "The outer audit checks source/dependency/SDK/model/binary authenticity; this module checks saved quality semantics and internal consistency.",
                  "One check per quality input is not a latency benchmark; durations are only validated as finite nonnegative values.",
                  "Category and paired-control metrics are additional independent views; unpaired and regional controls remain visible."]}
    if not cases:
        return report
    try:
        baseline = _audit_one(baseline_data, cases, corpus_sha, "baseline", errors)
        final = _audit_one(final_data, cases, corpus_sha, "final", errors)
        _compare(baseline_data.get("cases_sha256"), final_data.get("cases_sha256"), "unchanged_corpus_digest", errors)
        if baseline is None or final is None:
            return report
        for label, data in (("baseline", baseline), ("final", final)):
            report[label] = {key: value for key, value in data.items() if key != "rows"}
        delta = _delta(baseline["summary"], final["summary"])
        delta["by_language"] = {lang: _delta(baseline["summary"]["by_language"][lang], final["summary"]["by_language"][lang])
                                for lang in final["summary"]["by_language"]}
        delta["by_category"] = {cat: _delta(baseline["by_category"][cat], final["by_category"][cat]) for cat in final["by_category"]}
        delta["paired_strict_success"] = {lane: {
            "baseline": baseline["pairs"]["strict_success_count"][lane], "final": final["pairs"]["strict_success_count"][lane],
            "delta": final["pairs"]["strict_success_count"][lane] - baseline["pairs"]["strict_success_count"][lane]} for lane in LANES}
        changes = []
        for case in cases:
            before, after = baseline["rows"][case["id"]], final["rows"][case["id"]]
            lane_changes = {}
            for lane in LANES:
                old, new = before["outcomes"][lane], after["outcomes"][lane]
                keys = ("complete", "corrected", "changed", "flagged", "exact_expected", "results")
                if any(old[key] != new[key] for key in keys):
                    lane_changes[lane] = {"baseline": {k: old[k] for k in keys}, "final": {k: new[k] for k in keys}}
            if lane_changes:
                changes.append({**case, "lanes": lane_changes})
        report.update(delta=delta, changed_case_count=len(changes), changed_cases=changes, passed=not errors)
    except (KeyError, TypeError, ValueError, UnicodeError, AttributeError) as error:
        _error(errors, "audit", "Cannot finish reconstruction: " + str(error))
    return report
