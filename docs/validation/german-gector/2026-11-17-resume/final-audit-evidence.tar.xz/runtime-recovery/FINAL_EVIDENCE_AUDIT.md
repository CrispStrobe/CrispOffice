# Independent final evidence audit

The three Python modules inspect saved build, native and quality receipts and
actual pinned files. They do not launch inference, Dart/Flutter, tests, a
compiler, or CI. The outer script uses `git cat-file` for committed source
identity and `ldd` for resolved system-library identity.

## Expected inputs

The default final implementation is `143bad2f` (the final validated source and
tests; production matches `a28135ec`); the baseline implementation is
`43d43061ac33e2e3b336a79fb4b07b036bc617a8`.

Under the supplied final directory:

- `build/provider-build.json` and its retained AOT file;
- `build/quality-build.json` and its retained AOT file;
- `native/single.json`, `native/segmented.json`, `native/reuse.json`;
- `quality/original-30.json`, `quality/development-76.json`,
  `quality/syntax-56.json`.

The expected baseline directory is `validation/baseline/recovered`. Its
completed syntax receipt is **`syntax-adapted/syntax-56.json`**. The receipt at
`quality/syntax-56.json` is the preserved failed metadata-admission attempt;
the audit records and excludes it explicitly.

The adapted syntax corpus is checked against the original source corpus: only
the metadata key `area` becomes `category`; IDs, inputs, expected strings,
kinds and locales must remain equal. Original 30, development 76 and original
syntax 56 corpus hashes are also bound to both declared implementation commits.

## Invocation after results exist

```bash
source /workspace/scratch/e5b34feae619/runtime-recovery/activate.sh
python3 /workspace/scratch/e5b34feae619/runtime-recovery/final_evidence_audit.py \
  --root /workspace/scratch/e5b34feae619/quds_office_suite \
  --final-dir /workspace/scratch/e5b34feae619/validation/final \
  --baseline-dir /workspace/scratch/e5b34feae619/validation/baseline/recovered \
  --dart "$FLUTTER_ROOT/bin/cache/dart-sdk/bin/dart" \
  --pack "$GECTOR_PACK" \
  --output /workspace/scratch/e5b34feae619/validation/final/independent-evidence-audit.json
```

The output must be a fresh file. A failed or incomplete audit is retained and
returns exit status 1. `--plan` lists expected paths without running the audit.
Optional flags override the implementation commits, AOT paths, reference,
adapted syntax corpus and historical native directory. Normally AOT files are
located beside the build receipt using the receipt's exact artifact filename.

## What is independently reconstructed

`final_evidence_audit.py` reconstructs selected source inventories, all resolved
package-library Dart hashes, resolved package configuration, SDK compiler and
runtime pins, actual AOT hashes, git source bindings, every development-pack
payload and system-library identity. Final runtime receipts must bind to those
builds and assets. The archived baseline build/runtime/source binding is checked
separately.

`final_native_audit.py` reconstructs original UTF-16 edits, first-pass WordPiece
arrays and fingerprints, planned source partition coverage, actual per-segment
pass coverage, request-local cache insertion/hit behavior and bounds, real
forward versus logical decoded-token counters, sample timing statistics, and
the short aggregate. It compares original outcomes and controls with the prior
saved native qualification. Segmented versus reuse outputs and actual pass
trajectories must agree. Repeated and varied paragraph measurements remain
separate groups.

`final_quality_audit.py` reconstructs first-replacement projections, overlap
handling, provider status/locale contracts, the actual deterministic-first merge,
accepted/suppressed model proposals, every recorded summary list/count, and
baseline deltas. It also supplies language/category/pair views. Quality misses
or regressions are visible outcomes, not mislabeled as receipt-integrity errors.

## Limits that remain explicit

Initial pass fingerprints are independently reconstructed. Later-pass words and
raw tags are not stored in native receipts, so later hashes receive consistency
and cache-trajectory checks rather than reconstruction from missing data.

The second and third timed corrected outputs are not stored individually.
Their times and actual decoder pass trajectories can be audited; full repeated
corrected-output stability remains producer-reported. Null decoder diagnostics
after failures mean unavailable forward evidence, not zero work.

UTF-16 bounds, source strings and surrogate boundaries are checked. The Python
auditor does not independently implement full extended-grapheme segmentation.

The three quality panels are synthetic regression/development panels. The 76
cases have now informed development and are no longer a fresh prospective
evaluation. Unique synthetic paragraph combinations are operational/performance
controls, not representative prose quality samples. Three timing samples and
local host results do not establish intended-device responsiveness.

## Preparation verification

Only saved-data reconstruction and syntax checks were performed while preparing
the auditor. The independent tokenizer matches all 28 saved oracle cases and
historical token counts for 70 rows and 127 source segments. The quality helper
reconstructs the completed 30/76/56 baseline receipts with zero integrity errors
and zero spurious self-comparison deltas. No new inference or test runs were
performed. Final receipts remain unaudited until this script is explicitly run.
