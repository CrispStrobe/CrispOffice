#!/usr/bin/env python3
"""Inspect saved execution order, test events and historical comparison receipts."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    return json.loads(path.read_text())


def when(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def pin(path):
    return {"file": path.name, "bytes": path.stat().st_size, "sha256": digest(path)}


def event_counts(path):
    events = []
    for line in path.read_text().splitlines():
        try:
            item = json.loads(line)
            if isinstance(item, dict):
                events.append(item)
        except json.JSONDecodeError:
            pass
    names = {event["test"]["id"]: event["test"]["name"] for event in events if event.get("type") == "testStart"}
    finished = [event for event in events if event.get("type") == "testDone"]
    loading = [event for event in finished if names.get(event["testID"], "").startswith("loading ")]
    ordinary = [event for event in finished if event not in loading and not event.get("hidden", False)]
    return {"passed": sum(e.get("result") == "success" and not e.get("skipped", False) for e in ordinary),
            "failed": sum(e.get("result") != "success" for e in ordinary),
            "skipped": sum(bool(e.get("skipped", False)) for e in ordinary),
            "loading_failures": sum(e.get("result") != "success" for e in loading),
            "hidden_failures": sum(e.get("hidden", False) and e.get("result") != "success" for e in finished),
            "done": [event for event in events if event.get("type") == "done"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--final-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--implementation", default="143bad2f69976c331ac98ea7b4adbaec430af916")
    args = parser.parse_args()
    root, final = args.root.resolve(), args.final_dir.resolve()
    checks, inputs = [], {}
    def read(path):
        inputs[str(path)] = pin(path)
        return load(path)
    def check(name, passed, detail=None):
        checks.append({"check": name, "passed": bool(passed), "detail": detail})
    serial = read(final / "native/serial-receipt.json")
    provider_build_path = final / "build/provider-build.json"
    provider_build = read(provider_build_path)
    main_audit_path = final / "independent-evidence-audit.json"
    main_audit = read(main_audit_path)
    check("main source/native/quality audit passed", main_audit["completed"] is True and main_audit["passed"] is True)
    check("serial run receipt pins actual final build", serial["build_receipt_sha256"] == digest(provider_build_path))
    check("all three requested modes completed in declared serial order", serial["passed"] is True and serial["dependencies_stable"] is True
          and serial["mode_order"] == ["single", "segmented", "reuse"] == [row["mode"] for row in serial["runs"]])
    changes = subprocess.check_output(["git", "diff", "--name-only", args.implementation + ".." + serial["source_commit"]], cwd=root, text=True).splitlines()
    check("serial source is only a documentation descendant of validated implementation", all(path.startswith("docs/") for path in changes), changes)
    previous_end = when(serial["started_utc"])
    intervals = []
    prior_native = read(root / "docs/validation/german-gector/2026-11-17-native-dart/provider-aot-v1.json")
    prior_native_path = root / "docs/validation/german-gector/2026-11-17-native-dart/provider-aot-v1.json"
    old_exact = {row["id"] for row in prior_native["cases"] if row["kind"] == "error" and row["status"] == "success" and row["corrected"] == row["expected"]}
    for run in serial["runs"]:
        mode = run["mode"]
        start, end = when(run["started_utc"]), when(run["completed_utc"])
        path = final / "native" / (mode + ".json")
        log = final / "native" / (mode + ".log")
        receipt = read(path)
        comparison = read(final / "native" / (mode + "-comparison.json"))
        inputs[str(log)] = pin(log)
        check(mode + " nonoverlapping execution interval and successful exits", previous_end <= start < end and run["exit_code"] == 0 and run["comparison_exit_code"] == 0 and run["passed"] is True)
        check(mode + " actual saved native receipt/log hashes", run["receipt_sha256"] == digest(path) and run["log_sha256"] == digest(log))
        check(mode + " final native completion falls within recorded process interval", start <= when(receipt["timestamp_utc"]) <= end)
        command = run["command"]
        flags = dict(zip(command[2::2], command[3::2]))
        check(mode + " command uses the recorded built runtime and final source", pin(Path(command[0])) == provider_build["runtime"]["executable"]
              and pin(Path(command[1])) == provider_build["runtime"]["entrypoint"] and Path(flags["--source-root"]).resolve() == root
              and Path(flags["--output"]).resolve() == path)
        if mode == "single":
            check(mode + " explicit single-sequence command", "--segment-target-tokens" not in flags and "--reuse-identical-inputs" not in flags)
        else:
            check(mode + " explicit segmented/reuse command", flags["--segment-target-tokens"] == "64" and flags["--reuse-identical-inputs"] == ("true" if mode == "reuse" else "false"))
        check(mode + " actual reference identity", digest(Path(flags["--reference"])) == serial["reference_sha256"] == receipt["reference_sha256"])
        check(mode + " saved strict comparison binds actual input files and succeeds", comparison["candidate_sha256"] == digest(path)
              and comparison["baseline_sha256"] == comparison["frozen_baseline_sha256"] == digest(prior_native_path)
              and comparison["cases_sha256"] == digest(root / "tools/proofing/german_model/cases.json")
              and all(comparison[k] is True for k in ("evidence_valid", "operational_passed", "guarded_nonregression_passed", "passed"))
              and not comparison["evidence_errors"] and all(comparison["gates"].values()))
        new_exact = {row["id"] for row in receipt["cases"] if row["kind"] == "error" and row["status"] == "success" and row["corrected"] == row["expected"]}
        check(mode + " historical exact-fix delta reconstructs", set(comparison["added_exact_fixes"]) == new_exact - old_exact
              and set(comparison["lost_exact_fixes"]) == old_exact - new_exact,
              {"baseline_exact": len(old_exact), "final_exact": len(new_exact), "added": sorted(new_exact - old_exact), "lost": sorted(old_exact - new_exact)})
        intervals.append({"mode": mode, "started_utc": run["started_utc"], "completed_utc": run["completed_utc"], "wall_seconds": (end - start).total_seconds()})
        previous_end = end
    check("serial receipt completion follows all native exits", previous_end <= when(serial["completed_utc"]))
    native_start = when(serial["runs"][0]["started_utc"])
    local, selected_owners = {}, {}
    for path in sorted((final / "local").glob("*/receipt.json")):
        receipt = read(path)
        name = path.parent.name
        check(name + " final local validation passed before native timing", receipt["passed"] is True and when(receipt["completed_utc"]) < native_start)
        check(name + " local receipt retains stable source/runtime/input identities", all(receipt[key] is True for key in
              ("source_stable", "runtime_stable", "head_stable", "validation_inputs_stable")))
        if receipt["selected_tests"]:
            log = path.parent / "events.jsonl"
            observed = event_counts(log)
            recorded = receipt["events"]
            check(name + " independently reconstructed JSON event totals", observed["passed"] == recorded["passed_tests"]
                  and observed["failed"] == recorded["failed_tests"] == 0 and observed["skipped"] == recorded["skipped_tests"] == 0
                  and observed["loading_failures"] == observed["hidden_failures"] == 0 and len(observed["done"]) == 1 and observed["done"][0]["success"] is True)
            local[name] = {"passed": observed["passed"], "failed": observed["failed"], "skipped": observed["skipped"],
                           "selected_test_files": receipt["selected_tests"], "started_utc": receipt["started_utc"], "completed_utc": receipt["completed_utc"]}
            if name != "german-web":
                for selected in receipt["selected_tests"]:
                    selected_owners.setdefault(selected, []).append(name)
        else:
            log = path.parent / "analysis.log"
            check(name + " strict analysis result", receipt["no_issues_found"] is True and "No issues found!" in log.read_text())
            local[name] = {"analysis_passed": True, "started_utc": receipt["started_utc"], "completed_utc": receipt["completed_utc"]}
        check(name + " actual raw log matches recorded pin", digest(log) == receipt["log"]["sha256"] and log.stat().st_size == receipt["log"]["bytes"])
        inputs[str(log)] = pin(log)
    duplicates = {name: owners for name, owners in selected_owners.items() if len(owners) != 1}
    check("distinct non-Node cohorts do not repeat selected test files", not duplicates, duplicates)
    total = sum(row.get("passed", 0) for name, row in local.items() if name != "german-web")
    web = local["german-web"]["passed"]
    check("Node cohort is separately counted repeat coverage", set(local["german-web"]["selected_test_files"]).issubset(set(selected_owners)))
    check("final distinct and Node totals reconstruct", total == 1968 and web == 196,
          {"distinct": total, "additional_Node": web, "all_executions": total + web})
    quality_intervals = []
    previous_end = when(serial["completed_utc"])
    for panel in ("original-30", "development-76", "syntax-56"):
        receipt = read(final / "quality" / (panel + ".json"))
        start, end = when(receipt["started_at_utc"]), when(receipt["finished_at_utc"])
        check(panel + " quality executed after native timing and previous panel", previous_end <= start < end)
        quality_intervals.append({"panel": panel, "started_utc": receipt["started_at_utc"], "finished_utc": receipt["finished_at_utc"]})
        previous_end = end
    # Build receipts are rewritten at completion. Their retained file mtimes
    # supply an additional local observation; no stronger time attestation is
    # inferred from mutable filesystem metadata alone.
    build_times = []
    for path in sorted((final / "build").glob("*-build.json")):
        receipt = read(path)
        build_times.append({"file": path.name, "started_utc": receipt["timestamp_utc"],
                            "receipt_mtime_utc": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()})
        check(path.name + " retained build completion file predates native timing", when(receipt["timestamp_utc"]) < native_start
              and datetime.fromtimestamp(path.stat().st_mtime, timezone.utc) < native_start and receipt["passed"] is True)
    result = {"schema_version": 1, "kind": "independent-saved-execution-order-and-validation-audit",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(), "implementation_commit": args.implementation,
        "passed": all(row["passed"] for row in checks), "checks_total": len(checks), "checks_passed": sum(row["passed"] for row in checks),
        "errors": [row for row in checks if not row["passed"]], "checks": checks, "inputs": inputs,
        "native_intervals": intervals, "quality_intervals": quality_intervals, "local_validation": local,
        "distinct_tests": total, "additional_Node_tests": web, "analysis_suites": sum("analysis_passed" in row for row in local.values()),
        "build_time_observations": build_times,
        "limits": ["Saved timestamps and serial command/exit receipts verify this recorded execution order. They do not attest exclusive control of the entire host or unrelated external processes.",
                   "Build completion mtimes are supplementary local observations; source/SDK/dependency/binary identity is independently established by the primary audit.",
                   "No compiler, inference, test suite or GitHub Actions were invoked by this audit."]}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"output": str(args.output), "passed": result["passed"], "checks": [result["checks_passed"], result["checks_total"]],
                      "distinct_tests": total, "Node_tests": web, "errors": result["errors"]}, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
