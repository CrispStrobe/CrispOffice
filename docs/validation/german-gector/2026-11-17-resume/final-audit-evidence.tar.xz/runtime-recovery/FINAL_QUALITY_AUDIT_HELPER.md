# Saved quality receipt audit helper

Import final_quality_audit.py and call:

    report = audit_quality(
        final_data,
        baseline_data,
        {"cases": parsed_raw_corpus, "sha256": sha256_of_exact_corpus_bytes},
    )

The function returns a JSON-serializable report containing passed, errors,
independently reconstructed baseline/final summaries, language and category
views, paired-control metrics, lane deltas, and all changed case projections.
It performs no I/O, inference, subprocess or network operations. It does not
import the application or the evaluation code being checked.

A plain parsed corpus list is also accepted, but that provides semantic case
identity only. The envelope is recommended so the receipt's declared byte hash
is also checked. Preserve corpus order and supply raw allowed case metadata.

## Exact baseline paths

- validation/baseline/recovered/quality/original-30.json
- validation/baseline/recovered/quality/development-76.json
- validation/baseline/recovered/syntax-adapted/syntax-56.json

validation/baseline/recovered/quality/syntax-56.json is the preserved failed
admission attempt. Do not use it as the completed syntax baseline.

The syntax source supplied to this helper must be
docs/validation/german-gector/2026-11-17-resume/corpora/syntax-56-quality.json.
Its metadata was adapted to the quality runner's allowed fields; source strings
and gold corrections remain independently checkable against the original syntax
corpus by the outer audit.

## What is reconstructed

For every provider and lane, the helper validates original UTF-16 source ranges
and substrings, first-replacement projections, incomplete/advisory/overlap
skips, displayed finding order and membership, completion, clean/changed/flagged
state, and exact expected projections. Insertion conflicts include both range
endpoints.

Writing-only must retain exactly the writing result from the deterministic
request. Combined results are rebuilt from deterministic precedence and actual
model finding conflicts; accepted and suppressed model findings are checked.
Provider order, language normalization, regional model abstention, declared
statuses, case identity, coverage, row order, recorded summaries and source-seal
consistency are verified. Timings are checked only as nonnegative finite saved
values; quality measurements are not latency benchmarks.

All stored summary ID lists and counts are independently reconstructed.
Additional category and error/clean-pair views are included. Deltas list gained
and lost exact error fixes, changed/flagged clean cases, operational changes,
language/category breakdowns and full changed outputs/findings.

## Limits and interpretation

These are synthetic regression/development panels. The original 76 cases were
previously prospective but have since informed implementation; call them a
development panel in the new report. The 56 syntax cases are a separate synthetic
regression panel. None establishes representative German accuracy.

The helper verifies UTF-16 and surrogate boundaries. It does not reimplement
complete extended-grapheme segmentation. Source/dependency/SDK/model/binary
authenticity and byte-identical frozen-corpus ancestry belong to the outer audit.
Displayed findings are compared as complete multisets in source-coordinate
order because Dart sorting does not promise a stable order at tied coordinates.

The errors list concerns evidence/operational consistency, not remaining quality
misses. A recorded failure to correct a declared error is a legitimate measured
outcome. Quality regressions appear in delta and changed_cases for the caller's
separate quality decision.

The helper was exercised only on the three completed saved baseline receipts
compared with themselves and their actual corpus bytes. All 30/76/56 records,
projections, merges and summary metrics reconstructed with zero audit errors and
zero spurious deltas. This was saved-evidence analysis; no tests or model
inference were launched. Evidence:
final-quality-helper-baseline-reconstruction.json.
