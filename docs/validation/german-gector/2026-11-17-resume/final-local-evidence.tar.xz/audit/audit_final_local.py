#!/usr/bin/env python3
"""Independent read-only receipt audit; never runs tests, compilers, or CI."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
from urllib.parse import unquote, urljoin, urlparse

ROOT = Path('/workspace/scratch/e5b34feae619/quds_office_suite')
BASE = Path('/workspace/scratch/e5b34feae619/validation/final/local')
EXPECTED = '143bad2f69976c331ac98ea7b4adbaec430af916'
OUT = Path('/workspace/scratch/e5b34feae619/runtime-recovery/final-local-receipt-audit.json')
ERRORS = []
HASHES = {}


def require(condition, message):
    if not condition:
        ERRORS.append(message)


def hashed(path):
    path = Path(path)
    if path not in HASHES:
        raw = path.read_bytes()
        HASHES[path] = {
            'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
        }
    return HASHES[path]


def pin_matches(pin):
    actual = hashed(pin['path'])
    return actual['bytes'] == pin['bytes'] and actual['sha256'] == pin['sha256']


def recursive_pins(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            yield value
        else:
            for child in value.values():
                yield from recursive_pins(child)
    elif isinstance(value, list):
        for child in value:
            yield from recursive_pins(child)


def files_following_links(directory, ancestry=frozenset()):
    target = directory.resolve()
    if target in ancestry:
        return
    for entry in directory.iterdir():
        if entry.is_dir():
            yield from files_following_links(entry, ancestry | {target})
        elif entry.is_file() and entry.suffix == '.dart':
            yield entry


def main():
    summary = json.loads((BASE / 'summary.json').read_text())
    if not summary['completed']:
        print(json.dumps({'audit_completed': False, 'reason': 'Full local summary is not complete yet',
                          'completed_suites': list(summary['results'])}))
        return 2
    manifest_path = ROOT / 'docs/validation/german-gector/2026-11-17-resume/final_validation_suites.json'
    manifest = json.loads(manifest_path.read_text())
    frozen_manifest = json.loads((BASE / 'suite-definitions.json').read_text())
    require(manifest == frozen_manifest, 'Live and frozen suite manifests differ')
    require(summary['requested_suites'] == list(manifest['suites']), 'Requested suites differ from manifest')
    require(summary['passed'] and all(summary['results'].values()), 'Final summary has unsuccessful suites')
    tree = {}
    raw_tree = subprocess.check_output(['git', 'ls-tree', '-rz', '--full-tree', EXPECTED], cwd=ROOT)
    for entry in raw_tree.split(b'\0'):
        if entry:
            metadata, name = entry.split(b'\t', 1)
            _, kind, oid = metadata.split()
            if kind == b'blob':
                tree[name.decode()] = oid.decode()
    verified_sources, untracked_inputs = set(), set()
    report = {}
    principal_identities = {}
    supplemental_identities = {}
    selected_by_suite = {}
    first_dependencies = None
    common_runtime = None
    native_fixture = []
    for name, suite in manifest['suites'].items():
        receipt_path = BASE / name / 'receipt.json'
        receipt = json.loads(receipt_path.read_text())
        require(receipt['completed'] and receipt['passed'], name + ': receipt is not complete/successful')
        require(receipt['head_before'] == receipt['head_after'] == EXPECTED, name + ': source commit differs')
        require(receipt['exit_code'] == 0 and not receipt.get('timed_out'), name + ': process exit/timeout')
        require(receipt['worktree_status_before'] == receipt['worktree_status_after'] == '', name + ': tracked worktree was dirty')
        require(receipt['suite_definition'] == suite, name + ': suite definition mismatch')
        require(receipt['source_files_before'] == receipt['source_files_after'], name + ': source map changed')
        require(receipt['dependencies_before'] == receipt['dependencies_after'], name + ': resolved libraries changed')
        require(receipt['runtime_before'] == receipt['runtime_after'], name + ': runtime changed')
        require(receipt['validation_inputs_stable'], name + ': harness/manifest/activation changed')
        for source, expected_pin in receipt['source_files_before'].items():
            actual = hashed(ROOT / source)
            require(all(actual[k] == expected_pin[k] for k in ('bytes', 'sha256')), name + ': source mismatch ' + source)
            if source in tree:
                require(actual['git_blob'] == tree[source], name + ': input differs from143bad2f ' + source)
                verified_sources.add(source)
            else:
                untracked_inputs.add(source)
        for key in ('harness', 'manifest', 'activation', 'log'):
            require(pin_matches(receipt[key]), name + ': recorded pin differs: ' + key)
        for phase in ('before', 'after'):
            for relative in ('pubspec.lock', '.dart_tool/package_config.json'):
                record = receipt['resolved_inputs_' + phase][relative]
                copy = BASE / name / record['copy']
                require(hashed(copy)['sha256'] == hashed(ROOT / relative)['sha256'], name + ': resolved input copy mismatch')
                require(pin_matches(record), name + ': resolved input copy pin mismatch')
        deps = receipt['dependencies_before']
        require(len(deps['workspace_roots']) == 11, name + ': expected11 workspace roots')
        require(len(deps['resolved_libraries']['packages']) == 110, name + ': expected110 libraries')
        if first_dependencies is None:
            first_dependencies = deps
        require(deps == first_dependencies, name + ': dependencies differ between cohorts')
        runtime = receipt['runtime_before']
        for pin in recursive_pins(runtime):
            require(pin_matches(pin), name + ': runtime payload differs ' + pin['path'])
        require(runtime['python_invoked'].endswith('/.venv-ref/bin/python'), name + ': wrong Python invocation')
        require(runtime['python_prefix'].endswith('/.venv-ref'), name + ': wrong Python prefix')
        require(len(runtime['sdk_payloads']) == 9, name + ': missing expanded Dart payload pins')
        require(receipt['runtime_environment']['CRISPEMBED_GECTOR'] == '1', name + ': native gate disabled')
        for kind in ('MODEL', 'LIBRARY'):
            require(runtime['GECTOR_TEST_' + kind]['sha256'] == receipt['runtime_environment']['GECTOR_TEST_' + kind + '_SHA256'],
                    name + ': declared native pin does not match actual payload')
        reduced_runtime = {k: v for k, v in runtime.items() if k not in ('flutter_tools_snapshot', 'flutter_engine')}
        if common_runtime is None:
            common_runtime = reduced_runtime
        require(reduced_runtime == common_runtime, name + ': common runtime differs across cohorts')
        if suite['runner'] == 'flutter-test':
            require(set(runtime['flutter_engine']) == {'flutter_tester', 'frontend_server_aot.dart.snapshot', 'icudtl.dat'},
                    name + ': missing Flutter engine pins')
            require(receipt['command'][:2] == [runtime['dart']['path'], runtime['flutter_tools_snapshot']['path']], name + ': wrong Flutter command')
            require('--no-pub' in receipt['command'], name + ': Flutter command can run pub')
        elif suite['runner'].startswith('dart-'):
            require(receipt['command'][0] == runtime['dart']['path'], name + ': shell-wrapper Dart invocation')
        else:
            require(receipt['command'][0] == runtime['python_invoked'], name + ': wrong Python worker command')
        selected = [str((Path(suite['cwd']) / p).as_posix()) for p in suite.get('tests', suite.get('paths', []))]
        field = 'selected_analysis_paths' if suite['runner'] == 'dart-analyze' else 'selected_tests'
        require(selected == receipt[field], name + ': selected file list differs')
        selected_by_suite[name] = selected
        if suite['runner'] == 'dart-analyze':
            text = Path(receipt['log']['path']).read_text()
            require('No issues found!' in text, name + ': no successful analysis diagnostic')
            require('--fatal-infos' in receipt['command'] and '--fatal-warnings' in receipt['command'], name + ': analysis is not strict')
            report[name] = {'kind': 'strict-analysis', 'selected_file_count': len(selected), 'passed': True}
            continue
        events = []
        for line in Path(receipt['log']['path']).read_text().splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(event, dict) and 'type' in event:
                events.append(event)
        starts = {e['test']['id']: e['test'] for e in events if e['type'] == 'testStart'}
        suites = {e['suite']['id']: e['suite'] for e in events if e['type'] == 'suite'}
        finishes = [e for e in events if e['type'] == 'testDone']
        require(len(finishes) == len({e['testID'] for e in finishes}), name + ': duplicate completion IDs')
        require(not [e for e in events if e['type'] == 'error'], name + ': error events present')
        done = [e for e in events if e['type'] == 'done']
        require(len(done) == 1 and done[0]['success'], name + ': completion not successful')
        actual_counts = Counter(passed_tests=0, failed_tests=0, skipped_tests=0)
        identities = []
        for e in finishes:
            require(e['testID'] in starts, name + ': completion without test start')
            test = starts[e['testID']]
            if test['name'].startswith('loading ') or e.get('hidden', False):
                require(e['result'] == 'success', name + ': hidden/loading failure')
                continue
            if e.get('skipped', False):
                actual_counts['skipped_tests'] += 1
            elif e['result'] == 'success':
                actual_counts['passed_tests'] += 1
            if e['result'] != 'success':
                actual_counts['failed_tests'] += 1
            if suite['runner'] == 'python-unittest':
                path = Path(suite['cwd']) / (test['name'].split('.')[0] + '.py')
            else:
                path = Path(suites[test['suiteID']]['path'])
                path = path if path.is_absolute() else Path(receipt['cwd']) / path
                path = path.relative_to(ROOT)
            identity = (str(path), test['name'])
            identities.append(identity)
            if 'real native dual heads own their output and reject use after dispose' == test['name']:
                native_fixture.append({'suite': name, 'path': str(path), 'result': e['result'], 'skipped': e.get('skipped', False)})
        require(len(identities) == len(set(identities)), name + ': duplicate source/name identities')
        require({path for path, _ in identities} == set(selected), name + ': actual tests do not cover exact selected files')
        require(actual_counts['failed_tests'] == actual_counts['skipped_tests'] == 0, name + ': failure or skip')
        for key, value in actual_counts.items():
            require(receipt['events'][key] == value, name + ': reported count differs ' + key)
        target = supplemental_identities if suite.get('supplemental_runtime', False) else principal_identities
        target[name] = identities
        report[name] = {'kind': suite['runner'], **dict(actual_counts), 'selected_file_count': len(selected),
                        'supplemental_runtime': suite.get('supplemental_runtime', False)}
    require(len(native_fixture) == 1 and native_fixture[0]['result'] == 'success' and not native_fixture[0]['skipped'],
            'Exactly one real native fixture must have run and passed')
    principal = defaultdict(list)
    for cohort, identities in principal_identities.items():
        for identity in identities:
            principal[identity].append(cohort)
    duplicates = [{'file': identity[0], 'name': identity[1], 'suites': owners}
                  for identity, owners in principal.items() if len(owners) > 1]
    require(not duplicates, 'Distinct principal cohorts overlap')
    supplemental = {}
    for cohort, identities in supplemental_identities.items():
        repeats = [identity for identity in identities if identity in principal]
        require(len(repeats) == len(identities), cohort + ': supplemental tests not represented in principal totals')
        supplemental[cohort] = {'executed': len(identities), 'repeated_principal_cases': len(repeats), 'additional_distinct_cases': len(identities) - len(repeats)}
    # Reconstruct dependency fingerprints without importing the producing harness.
    config_path = ROOT / '.dart_tool/package_config.json'
    config = json.loads(config_path.read_text())
    independent_packages = {}
    for package in config['packages']:
        root_uri = urljoin(config_path.as_uri(), package['rootUri'])
        library_uri = urljoin(root_uri.rstrip('/') + '/', package.get('packageUri', ''))
        parsed = urlparse(library_uri)
        require(parsed.scheme == 'file', 'Nonlocal package library')
        library = Path(unquote(parsed.path))
        files = {str(p.relative_to(library)): hashed(p)['sha256'] for p in files_following_links(library)} if library.is_dir() else {}
        if library.is_relative_to(ROOT):
            for relative in files:
                full = library / relative
                relative_root = str(full.relative_to(ROOT))
                if relative_root in tree:
                    require(hashed(full)['git_blob'] == tree[relative_root], 'Resolved workspace library differs from143bad2f: ' + relative_root)
                    verified_sources.add(relative_root)
        encoded = json.dumps(files, sort_keys=True, separators=(',', ':')).encode()
        independent_packages[package['name']] = {'library_directory_present': library.is_dir(), 'dart_file_count': len(files),
                                                  'sha256': hashlib.sha256(encoded).hexdigest()}
    require(independent_packages == first_dependencies['resolved_libraries']['packages'], 'Independent dependency fingerprints differ')
    python_receipt = json.loads(Path('/workspace/scratch/e5b34feae619/runtime-recovery/python-reference-verification.json').read_text())
    require(python_receipt['python_executable'] == common_runtime['python_invoked'], 'Qualified Python verification differs')
    require(python_receipt['python_sha256'] == common_runtime['python']['sha256'], 'Qualified Python executable changed')
    for package, pin in python_receipt['packages'].items():
        require(hashed(pin['module_file'])['sha256'] == pin['module_sha256'], 'Python package entry changed: ' + package)
    result = {
        'kind': 'independent-final-local-receipt-audit', 'observed_utc': datetime.now(timezone.utc).isoformat(),
        'expected_source_commit': EXPECTED, 'tests_or_compilers_launched_by_auditor': False,
        'summary_complete': True, 'passed': not ERRORS, 'errors': ERRORS,
        'counts': report, 'distinct_principal_tests': len(principal), 'principal_overlap': duplicates,
        'supplemental_runtimes': supplemental, 'native_fixture': native_fixture,
        'resolved_library_count': len(independent_packages), 'independent_resolved_fingerprints_match_all_cohorts': independent_packages == first_dependencies['resolved_libraries']['packages'],
        'verified_source_count_against_git_tree': len(verified_sources), 'verified_source_files': sorted(verified_sources),
        'untracked_resolved_inputs': sorted(untracked_inputs),
        'runtime': common_runtime,
        'python_packages': {name: entry['version'] for name, entry in python_receipt['packages'].items()},
        'receipts': {name: {'file': str(BASE / name / 'receipt.json'), 'sha256': hashed(BASE / name / 'receipt.json')['sha256']} for name in report},
        'summary_sha256': hashed(BASE / 'summary.json')['sha256'], 'manifest_sha256': hashed(manifest_path)['sha256'],
    }
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key in {'passed','errors','counts','distinct_principal_tests','supplemental_runtimes','native_fixture','resolved_library_count','verified_source_count_against_git_tree'}}, ensure_ascii=False, indent=2))
    print(str(OUT))
    return 0 if not ERRORS else 1


if __name__ == '__main__':
    raise SystemExit(main())
