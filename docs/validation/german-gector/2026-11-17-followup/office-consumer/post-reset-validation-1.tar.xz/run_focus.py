from pathlib import Path
import subprocess,json,hashlib,datetime,sys
r=Path('/workspace/office-validation'); e=r/'packages/quds_office_engine'; out=Path('/workspace/office-results'); phase=sys.argv[1]
paths=list((e/'lib').rglob('*.dart'))+list((r/'packages/legacy_doc_parser/lib').rglob('*.dart'))+[e/'test/odt_header_variant_comment_fidelity_test.dart',r/'pubspec.yaml',r/'pubspec.lock',r/'.dart_tool/package_config.json',Path('/workspace/runtime/dart-sdk/bin/dart'),Path('/workspace/runtime/bin/dart')]
def seal(): return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=seal(); start=datetime.datetime.now(datetime.timezone.utc).isoformat()
cmd=['dart','test','test/odt_header_variant_comment_fidelity_test.dart','--reporter=json']
with (out/(phase+'.jsonl')).open('w') as f, (out/(phase+'.stderr')).open('w') as err:
 p=subprocess.run(cmd,cwd=e,stdout=f,stderr=err,timeout=120)
after=seal(); events=[json.loads(l) for l in (out/(phase+'.jsonl')).read_text().splitlines() if l.startswith('{')]
tests={x['test']['id']:x['test'] for x in events if x['type']=='testStart'}
results=[x for x in events if x['type']=='testDone' and not x.get('hidden')]
record={'phase':phase,'command':cmd,'cwd':str(e),'started_at_utc':start,'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'before':before,'after':after,'inputs_unchanged':before==after,'results':[dict(x,name=tests.get(x['testID'],{}).get('name')) for x in results]}
(out/(phase+'-receipt.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['phase','exit','inputs_unchanged','results']}),flush=True)
