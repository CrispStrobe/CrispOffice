#!/bin/sh
export DASH__SUPPRESS_ANALYTICS=true
export CI=true
case "$1" in
  --packages=*|*.dart) exec /workspace/runtime/dart-sdk/bin/dart "$@" ;;
  *) exec /workspace/runtime/dart-sdk/bin/dart --suppress-analytics "$@" ;;
esac
