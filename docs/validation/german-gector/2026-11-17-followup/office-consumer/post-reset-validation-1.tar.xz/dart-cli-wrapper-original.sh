#!/bin/sh
export DASH__SUPPRESS_ANALYTICS=true
export CI=true
exec /workspace/runtime/dart-sdk/bin/dart --suppress-analytics "$@"
