# Incoming Word shading qualification

The captured Word branch `85033b80` introduced compiler/test work before its native operation was available. During Mail integration the native continuation arrived as `655b2722e9a11df4da129e2de36016f2f60b9c0b`. That incoming implementation supersedes the locally prepared fallback; no fallback behavior was retained.

## Accepted result

The final bounded qualification passed **933 tests across 12 suites**, with zero failures or skips. This covers native shading, compiler and integration workflows, shared text construction, existing Excel/Word/PowerPoint compiler entry points, paragraph style/spacing, native style layout and package preservation. The 937 engine Dart input hashes remained unchanged through that test cohort. Fatal-info analysis and the formatter pass for all 11 affected Dart paths.

The production delta over incoming `655b2722` consists solely of six mandatory flow-control braces. A later formatter-only correction in `office_vba_word_shading_test.dart` was followed by another successful execution of its 125 cases. Those executions overlap the 933 and are not additional distinct coverage. `final-source-after.json` is the final input manifest; `qualification.json` records the exact cohort split.

Both new portable workflows compile to JavaScript and run in Node. Their JSON outputs exactly match native VM execution, including native payload hashes for the shading workflow. The first plain Node launch exited without output; the retained failed-attempt files are not counted as passing. The corrected runner supplies the repository-established `globalThis.self=globalThis` bootstrap and asserts nonempty valid JSON and exact VM equality.

## Earlier attempts

The fallback/native development attempt recorded 307 passes, four assertion failures and one error. It exposed incomplete upstream test expectations and a fallback alternative-packet guard; it is superseded and is not qualification evidence. The incoming `655b2722` run then passed the same 933-case scope but strict analysis found six missing braces. The final run repeats the complete scope after those braces were fixed. Original raw logs remain separate.

## Reproduce

With the pinned Flutter 3.47.8 / Dart 3.13.7 SDK and unchanged locked dependencies, execute from `packages/quds_office_engine`:

```sh
dart test --reporter=json --concurrency=2 test/office_macro_word_shading_test.dart test/office_vba_word_shading_test.dart test/office_vba_word_shading_integration_test.dart test/office_vba_text_construction_test.dart test/office_vba_language_test.dart test/office_vba_string_intrinsics_test.dart test/office_vba_word_language_test.dart test/office_vba_powerpoint_test.dart test/office_macro_word_line_spacing_test.dart test/office_macro_word_paragraph_style_test.dart test/word_styles_layout_test.dart test/word_package_preservation_test.dart
```

`qualify_portable.py` reproduces both VM/Node workflows with the committed BAS examples and preserves compile and execution outputs. Set `FLUTTER_ROOT` to the pinned SDK directory before running it. No GitHub Actions runs, checks or statuses were queried or awaited. These are local engine checks; no installed Office application interoperability is claimed.
