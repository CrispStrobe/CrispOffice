from pathlib import Path
import base64
import json
import os
import subprocess

out = Path(__file__).resolve().parent
dart = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/dart-sdk/bin/dart'
receipts = []
for label, source, define, example in [
    ('shading', 'web_vba_word_shading_smoke.dart', 'WORD_SHADING_BAS_BASE64', 'word_shading.bas'),
    ('text', 'web_vba_text_construction_smoke.dart', 'WORD_TEXT_CONSTRUCTION_BAS_BASE64', 'word_text_construction.bas'),
]:
    value = base64.b64encode(Path('example/macros', example).read_bytes()).decode()
    js = out / (label + '.js')
    source_path = 'tool/macros/' + source
    command = [str(dart), 'compile', 'js', '-D' + define + '=' + value, source_path, '-o', str(js)]
    with (out / (label + '-compile-final.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(label + ' compile failed')
    for platform, command in [
        ('node', ['node', '-e', 'globalThis.self=globalThis; require(process.argv[1]);', str(js)]),
        ('vm', [str(dart), '-D' + define + '=' + value, source_path]),
    ]:
        with (out / (label + '-' + platform + '-final.json')).open('w') as output, (out / (label + '-' + platform + '-final.stderr')).open('w') as error:
            result = subprocess.run(command, stdout=output, stderr=error)
        if result.returncode:
            raise RuntimeError(label + ' ' + platform + ' execution failed')
    node = json.loads((out / (label + '-node-final.json')).read_text())
    vm = json.loads((out / (label + '-vm-final.json')).read_text())
    if node != vm:
        raise RuntimeError(label + ' VM/JavaScript projections differ')
    receipts.append({'label': label, 'compile_exit': 0, 'node_exit': 0, 'vm_exit': 0, 'vm_node_equal': True, 'result': node})
(out / 'portable-results.json').write_text(json.dumps(receipts, indent=2) + '\n')
print(json.dumps([{'label': row['label'], 'vm_node_equal': row['vm_node_equal']} for row in receipts]))
