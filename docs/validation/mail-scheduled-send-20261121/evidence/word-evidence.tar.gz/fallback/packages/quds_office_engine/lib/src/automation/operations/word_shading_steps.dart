import 'package:quds_office_engine/quds_office_engine.dart';

/// Set an explicit solid paragraph background, including automatic shading.
///
/// Patterned shading is not represented by the scalar native model. Refuse it
/// before replacing any properties, and preserve the original XML packet for
/// the serializer's attribute-level merge of a supported solid background.
void setWordParagraphShading(
  WmlDocument document,
  WmlParagraph paragraph,
  String color,
) {
  if (color != 'auto' && !RegExp(r'^[0-9a-fA-F]{6}$').hasMatch(color)) {
    throw ArgumentError('color must be auto or a six-digit RGB hex color');
  }
  if (WordFieldSpans.unbalanced(document).isNotEmpty) {
    throw UnsupportedError(
      'Paragraph shading cannot preserve unbalanced modeled fields.',
    );
  }
  final source = paragraph.properties.sourcePropertiesXml;
  if (source != null && source.isNotEmpty) {
    final context = XmlDocument.parse(
      '<w:context xmlns:w="${OfficeNamespaces.w}">$source</w:context>',
    ).root!;
    final roots = context.childElements.toList(growable: false);
    if (roots.length != 1 || !_word(roots.single, 'pPr')) {
      throw UnsupportedError('Shading requires native paragraph properties.');
    }
    final properties = roots.single;
    final shading = properties.childElements
        .where((node) => _word(node, 'shd'))
        .toList(growable: false);
    if (shading.length > 1) {
      throw UnsupportedError('Duplicate paragraph shading is ambiguous.');
    }
    _checkAlternatives(properties);
    if (shading.isNotEmpty) _checkShading(shading.single);
  }
  final properties = paragraph.properties.copy();
  // A same-value assignment must still become direct formatting when the
  // imported effective value came from a paragraph style.
  properties.importedValues?.remove('shd');
  properties.shadingFill = color == 'auto' ? color : color.toUpperCase();
  paragraph.properties = properties;
}

bool _word(XmlElement node, String name) =>
    node.localName == name && node.namespaceUri == OfficeNamespaces.w;

void _checkShading(XmlElement shading) {
  final names = <String>{};
  const allowed = {
    'val',
    'color',
    'fill',
    'themeColor',
    'themeTint',
    'themeShade',
    'themeFill',
    'themeFillTint',
    'themeFillShade',
  };
  for (final attribute in shading.attributes) {
    if (attribute.namespaceUri != OfficeNamespaces.w) continue;
    if (!allowed.contains(attribute.localName) ||
        !names.add(attribute.localName)) {
      throw UnsupportedError(
        'Unsupported or duplicate native shading attribute.',
      );
    }
  }
  final pattern = shading.getAttribute('val', namespaceUri: OfficeNamespaces.w);
  if (pattern != null && pattern != 'clear' && pattern != 'nil') {
    throw UnsupportedError('Only solid paragraph backgrounds can be edited.');
  }
  if (shading.childElements.any(
    (node) => node.namespaceUri == OfficeNamespaces.w,
  )) {
    throw UnsupportedError('Native shading children are unsupported.');
  }
}

void _checkAlternatives(XmlElement node, {bool alternative = false}) {
  final insideAlternative =
      alternative ||
      (node.localName == 'AlternateContent' &&
          node.namespaceUri == OfficeNamespaces.mc);
  if (insideAlternative && _word(node, 'shd')) {
    throw UnsupportedError('Alternative paragraph shading is unsupported.');
  }
  for (final child in node.childElements) {
    _checkAlternatives(child, alternative: insideAlternative);
  }
}
