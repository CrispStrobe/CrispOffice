import 'dart:typed_data';

import 'package:quds_office_engine/quds_office_automation.dart';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart'
    as native;
import 'package:test/test.dart';

const _w = OfficeNamespaces.w;
const _x = 'urn:paragraph-shading-test';

Uint8List _fixture(String properties, {String? styles, String prefix = 'w'}) {
  final package = OpcPackage.openBytes(
    (DocxDocumentBuilder()..paragraph('Template')).build(),
  );
  package
      .getPart('/word/document.xml')!
      .writeText(
        '<$prefix:document xmlns:$prefix="$_w" xmlns:x="$_x" '
        'xmlns:mc="${OfficeNamespaces.mc}">'
        '<$prefix:body><$prefix:p><$prefix:pPr>$properties</$prefix:pPr>'
        '<$prefix:r><$prefix:rPr><$prefix:b/></$prefix:rPr>'
        '<$prefix:t>Original 😀 العربية</$prefix:t></$prefix:r>'
        '</$prefix:p><$prefix:sectPr/></$prefix:body></$prefix:document>',
      );
  if (styles != null) {
    package
        .getPart('/word/styles.xml')!
        .writeText('<w:styles xmlns:w="$_w">$styles</w:styles>');
  }
  return package.save();
}

XmlElement _properties(Uint8List bytes) =>
    XmlDocument.parse(
          OpcPackage.openBytes(bytes).getPart('/word/document.xml')!.readText(),
        ).root!
        .firstChild('body', namespaceUri: _w)!
        .firstChild('p', namespaceUri: _w)!
        .firstChild('pPr', namespaceUri: _w)!;

XmlElement _shading(Uint8List bytes) =>
    _properties(bytes).firstChild('shd', namespaceUri: _w)!;

Map<String, Object?> _step(Object? color) => {
  'op': 'paragraphShading',
  'paragraph': 0,
  'color': color,
};

void _refuses(
  WmlDocument document,
  Map<String, Object?> step,
  Matcher matcher,
) {
  final original = document.paragraphs.single.properties;
  final imported = Map<String, String>.from(original.importedValues ?? {});
  final source = original.sourcePropertiesXml;
  final bytes = document.package!.getPart('/word/document.xml')!.readBytes();
  expect(() => native.applyStep(document, step), matcher);
  expect(identical(document.paragraphs.single.properties, original), isTrue);
  expect(original.importedValues ?? {}, imported);
  expect(original.sourcePropertiesXml, source);
  expect(document.package!.getPart('/word/document.xml')!.readBytes(), bytes);
}

void main() {
  for (final color in ['000000', 'FFFFFF', '12abEF', 'auto']) {
    test('native $color becomes a direct solid background through reopens', () {
      final document = WordDeserializer().readBytes(
        _fixture('<w:spacing w:after="180"/><w:jc w:val="right"/>'),
      );
      native.applyStep(document, _step(color));
      var bytes = WordSerializer().writeBytes(document);
      for (var cycle = 0; cycle < 3; cycle++) {
        final shading = _shading(bytes);
        expect(shading.getAttribute('val', namespaceUri: _w), 'clear');
        expect(shading.getAttribute('color', namespaceUri: _w), 'auto');
        expect(
          shading.getAttribute('fill', namespaceUri: _w),
          color == 'auto' ? color : color.toUpperCase(),
        );
        final reopened = WordDeserializer().readBytes(bytes);
        final paragraph = reopened.paragraphs.single;
        expect(paragraph.text, 'Original 😀 العربية');
        expect(
          paragraph.inlines.whereType<WmlRun>().single.properties.bold,
          isTrue,
        );
        expect(paragraph.properties.spacingAfter, 9);
        expect(paragraph.properties.justification, WmlJustification.right);
        bytes = WordSerializer().writeBytes(reopened);
      }
    });
  }

  test(
    'native metadata and namespace lookalikes survive a themed fill override',
    () {
      final document = WordDeserializer().readBytes(
        _fixture(
          '<w:shd w:val="clear" w:fill="123456" w:color="auto" '
          'w:themeFill="accent1" w:themeFillTint="80" w:themeFillShade="40" '
          'w:themeColor="accent2" w:themeTint="10" w:themeShade="20" '
          'x:fill="foreign-fill" x:token="keep">'
          '<x:metadata x:token="child"/></w:shd>'
          '<x:shd w:fill="EEEEEE" x:token="foreign-shading"/>'
          '<x:metadata><w:shd w:fill="AAAAAA"/></x:metadata>',
        ),
      );
      expect(document.paragraphs.single.properties.shadingFill, '123456');
      native.applyStep(document, _step('ABCDEF'));
      var bytes = WordSerializer().writeBytes(document);
      for (var cycle = 0; cycle < 3; cycle++) {
        final properties = _properties(bytes);
        final shading = _shading(bytes);
        expect(shading.getAttribute('fill', namespaceUri: _w), 'ABCDEF');
        expect(shading.getAttribute('fill', namespaceUri: _x), 'foreign-fill');
        expect(shading.getAttribute('token', namespaceUri: _x), 'keep');
        expect(
          shading
              .firstChild('metadata', namespaceUri: _x)!
              .getAttribute('token', namespaceUri: _x),
          'child',
        );
        for (final name in [
          'themeFill',
          'themeFillTint',
          'themeFillShade',
          'themeColor',
          'themeTint',
          'themeShade',
        ]) {
          expect(shading.getAttribute(name, namespaceUri: _w), isNull);
        }
        expect(
          properties
              .firstChild('shd', namespaceUri: _x)!
              .getAttribute('token', namespaceUri: _x),
          'foreign-shading',
        );
        expect(
          properties
              .firstChild('metadata', namespaceUri: _x)!
              .firstChild('shd', namespaceUri: _w)!
              .getAttribute('fill', namespaceUri: _w),
          'AAAAAA',
        );
        final reopened = WordDeserializer().readBytes(bytes);
        expect(reopened.paragraphs.single.properties.shadingFill, 'ABCDEF');
        bytes = WordSerializer().writeBytes(reopened);
      }
    },
  );

  test('nonstandard Word prefixes retain foreign w bindings and children', () {
    final document = WordDeserializer().readBytes(
      _fixture(
        '<n:shd xmlns:w="$_x" n:val="clear" n:fill="112233" '
        'w:fill="opaque"><w:metadata/></n:shd>',
        prefix: 'n',
      ),
    );
    native.applyStep(document, _step('auto'));
    final bytes = WordSerializer().writeBytes(document);
    final shading = _shading(bytes);
    expect(shading.getAttribute('fill', namespaceUri: _w), 'auto');
    expect(shading.getAttribute('fill', namespaceUri: _x), 'opaque');
    expect(shading.firstChild('metadata', namespaceUri: _x), isNotNull);
    expect(
      WordDeserializer()
          .readBytes(bytes)
          .paragraphs
          .single
          .properties
          .shadingFill,
      'auto',
    );
  });

  for (final color in ['CCDDFF', 'auto']) {
    test(
      '$color overrides inherited shading without freezing other style values',
      () {
        final document = WordDeserializer().readBytes(
          _fixture(
            '<w:pStyle w:val="Custom"/>',
            styles:
                '<w:style w:type="paragraph" w:styleId="Custom">'
                '<w:name w:val="Custom"/><w:pPr>'
                '<w:shd w:val="clear" w:fill="CCDDFF"/>'
                '<w:spacing w:after="240"/></w:pPr></w:style>',
          ),
        );
        expect(document.paragraphs.single.properties.shadingFill, 'CCDDFF');
        native.applyStep(document, _step(color));
        final bytes = WordSerializer().writeBytes(document);
        expect(_shading(bytes).getAttribute('fill', namespaceUri: _w), color);
        expect(
          _properties(bytes).firstChild('spacing', namespaceUri: _w),
          isNull,
        );
        expect(
          WordDeserializer()
              .readBytes(bytes)
              .paragraphs
              .single
              .properties
              .spacingAfter,
          12,
        );
      },
    );
  }

  for (final color in [
    null,
    123456,
    '',
    '#112233',
    'auto ',
    'AUTO',
    '12345G',
  ]) {
    test(
      'invalid native color $color leaves source and properties unchanged',
      () {
        final document = WordDeserializer().readBytes(_fixture(''));
        _refuses(document, _step(color), throwsArgumentError);
      },
    );
  }

  for (final properties in [
    '<w:shd w:val="pct25" w:fill="123456"/>',
    '<w:shd w:val="solid" w:fill="123456"/>',
    '<w:shd w:val="clear" w:fill="123456"/><w:shd w:fill="654321"/>',
    '<w:shd w:val="clear" w:fill="123456" w:unknown="value"/>',
    '<w:shd w:val="clear" w:fill="123456"><w:shd w:fill="654321"/></w:shd>',
    '<mc:AlternateContent><mc:Choice Requires="x"><w:shd w:fill="123456"/>'
        '</mc:Choice><mc:Fallback><w:shd w:fill="654321"/></mc:Fallback></mc:AlternateContent>',
  ]) {
    test(
      'ambiguous or unsupported shading refuses before mutation: $properties',
      () {
        final document = WordDeserializer().readBytes(_fixture(properties));
        _refuses(document, _step('ABCDEF'), throwsUnsupportedError);
      },
    );
  }

  test(
    'a late unsupported background rolls back an earlier valid macro edit',
    () async {
      final package = OpcPackage.openBytes(_fixture(''));
      final part = package.getPart('/word/document.xml')!;
      part.writeText(
        part.readText().replaceFirst(
          '<w:sectPr/>',
          '<w:p><w:pPr><w:shd w:val="pct25" w:fill="123456"/></w:pPr>'
              '<w:r><w:t>Second</w:t></w:r></w:p><w:sectPr/>',
        ),
      );
      final bytes = package.save();
      final session = OfficeMacroSession(bytes, format: OfficeMacroFormat.docx);
      final plan = OfficeMacro(
        name: 'Shading rollback',
        format: OfficeMacroFormat.docx,
        steps: [
          OfficeMacroStep(
            tool: 'docx.paragraphShading',
            arguments: {'paragraph': 0, 'color': 'ABCDEF'},
          ),
          OfficeMacroStep(
            tool: 'docx.paragraphShading',
            arguments: {'paragraph': 1, 'color': 'FFFFFF'},
          ),
        ],
      );
      for (final action in [session.validate, session.run]) {
        await expectLater(action(plan), throwsA(isA<OfficeMacroException>()));
        expect(session.bytes, bytes);
        expect(session.revision, 0);
      }
    },
  );
}
