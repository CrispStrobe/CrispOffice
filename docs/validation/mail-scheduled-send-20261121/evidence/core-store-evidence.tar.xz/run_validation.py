import concurrent.futures
import datetime
import hashlib
import json
import pathlib
import platform
import shutil
import subprocess
import time

REPO = pathlib.Path('/workspace/scratch/faef92d47725/quds_office_suite')
OUT = pathlib.Path(__file__).parent
FILES = [
    'packages/quds_mail_core/lib/src/sync/outbox.dart',
    'packages/quds_mail_core/lib/src/ports/repository.dart',
    'packages/quds_mail_core/test/outbox_schedule_test.dart',
    'packages/quds_mail_store/lib/src/codec.dart',
    'packages/quds_mail_store/lib/src/repository.dart',
    'packages/quds_mail_store/test/codec_test.dart',
    'packages/quds_mail_store/test/outbox_schedule_test.dart',
    'pubspec.lock',
]

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def capture(args, cwd=REPO):
    result = subprocess.run(args, cwd=cwd, text=True, capture_output=True)
    return {'command': args, 'exit_code': result.returncode,
            'stdout': result.stdout, 'stderr': result.stderr}

def sources():
    return {name: sha(REPO / name) for name in FILES}

receipt = {
    'kind': 'mail_scheduling_core_store_final_validation',
    'started_at_utc': utc(),
    'environment_setup': 'source /workspace/scratch/faef92d47725/runtime/env.sh',
    'repository': str(REPO),
    'original_repository_git_head': capture(['git', 'rev-parse', 'HEAD'])['stdout'].strip(),
    'original_package_git_status': capture([
        'git', 'status', '--short', '--', 'packages/quds_mail_core',
        'packages/quds_mail_store'])['stdout'],
    'source_sha256_before': sources(),
    'toolchain': {
        'dart_executable': shutil.which('dart'),
        'flutter_executable': shutil.which('flutter'),
        'dart': capture(['dart', '--version']),
        'flutter': capture(['flutter', '--version', '--machine']),
        'platform': platform.platform(),
    },
    'validation_source': 'Local full package suites; no GitHub Actions used.',
}
(OUT / 'receipt.in-progress.json').write_text(json.dumps(receipt, indent=2) + '\n')

JOBS = [
    ('core-full', REPO / 'packages/quds_mail_core', ['dart', 'test', '--reporter', 'json']),
    ('store-full', REPO / 'packages/quds_mail_store', ['dart', 'test', '--reporter', 'json']),
    ('package-analysis', REPO, ['dart', 'analyze', '--fatal-infos',
                              'packages/quds_mail_core', 'packages/quds_mail_store']),
]

def run(job):
    name, cwd, args = job
    started = utc()
    before = time.monotonic()
    stdout_path = OUT / f'{name}.stdout.log'
    stderr_path = OUT / f'{name}.stderr.log'
    with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
        result = subprocess.run(args, cwd=cwd, stdout=stdout, stderr=stderr)
    item = {'name': name, 'cwd': str(cwd), 'command': args,
            'started_at_utc': started, 'finished_at_utc': utc(),
            'elapsed_seconds': round(time.monotonic() - before, 3),
            'exit_code': result.returncode,
            'stdout_path': str(stdout_path), 'stderr_path': str(stderr_path)}
    if name.endswith('-full'):
        events = []
        other = []
        records = []
        for raw in stdout_path.read_text().splitlines(keepends=True):
            try:
                event = json.loads(raw)
            except json.JSONDecodeError:
                other.append(raw)
            else:
                if isinstance(event, dict) and 'type' in event:
                    events.append(raw)
                    records.append(event)
                else:
                    other.append(raw)
        events_path = OUT / f'{name}.events.jsonl'
        events_path.write_text(''.join(events))
        chatter_path = OUT / f'{name}.runner-output.log'
        chatter_path.write_text(''.join(other))
        # Preserve raw JSON event lines byte-for-byte; keep build-hook chatter
        # separately while also retaining the complete original stdout log.
        done = [record for record in records if record['type'] == 'done']
        tests = [record for record in records
                 if record['type'] == 'testDone' and not record.get('hidden', False)]
        item.update({
            'raw_json_events_path': str(events_path),
            'runner_output_path': str(chatter_path),
            'done_event': done[-1] if done else None,
            'visible_test_count': len(tests),
            'passed': sum(not event.get('skipped', False) and event.get('result') == 'success'
                          for event in tests),
            'skipped': sum(bool(event.get('skipped', False)) for event in tests),
            'failed': sum(not event.get('skipped', False) and event.get('result') != 'success'
                          for event in tests),
            'error_events': [record for record in records if record['type'] == 'error'],
        })
    print(json.dumps({key: item.get(key) for key in
                      ['name', 'exit_code', 'elapsed_seconds', 'passed', 'skipped', 'failed']}),
          flush=True)
    return item

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    receipt['checks'] = list(pool.map(run, JOBS))

receipt['source_sha256_after'] = sources()
receipt['selected_sources_unchanged'] = receipt['source_sha256_before'] == receipt['source_sha256_after']
receipt['repository_git_head_after'] = capture(['git', 'rev-parse', 'HEAD'])['stdout'].strip()
receipt['finished_at_utc'] = utc()
receipt['all_checks_passed'] = receipt['selected_sources_unchanged'] and all(
    check['exit_code'] == 0 and
    (not check['name'].endswith('-full') or
     (check['done_event'] is not None and check['done_event'].get('success') is True and
      check['failed'] == 0)) for check in receipt['checks'])
receipt['log_sha256'] = {
    file.name: sha(file) for file in sorted(OUT.iterdir())
    if file.is_file() and file.suffix in {'.log', '.jsonl'}
}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt': str(OUT / 'receipt.json'),
                  'all_checks_passed': receipt['all_checks_passed']}), flush=True)
raise SystemExit(0 if receipt['all_checks_passed'] else 1)
