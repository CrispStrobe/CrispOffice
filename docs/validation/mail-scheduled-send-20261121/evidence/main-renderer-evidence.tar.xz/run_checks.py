import hashlib,json,pathlib,subprocess,sys,time
ROOT=pathlib.Path('/workspace/scratch/faef92d47725/quds_office_suite')
OUT=pathlib.Path('/workspace/scratch/faef92d47725/runtime/main-publication-followup')
EDITOR=ROOT/'packages/quds_office_editor'
MODE=sys.argv[1]
TESTS=['test/'+name+'_test.dart' for name in ['word_selection_paint','word_selection_path_cache','word_proofing_geometry','word_proofing_navigation','word_header_footer_navigation','word_hyphenation_paint','word_hyphenation_caret','word_underline_paint','word_live_review_selection','word_table_grid_history']]
FILES=['lib/src/editor_word/render_word_canvas.dart','test/word_selection_path_cache_test.dart']
COMMANDS={'editor':['flutter','test','--no-pub','--reporter=json','--concurrency=1',*TESTS],'analyze':['dart','analyze','--fatal-infos',*FILES],'format':['dart','format','--output=none','--set-exit-if-changed',*FILES]}
def snapshot():
 paths=[]
 for package in ['quds_office_engine','quds_office_editor']:
  for subdir in ['lib','test','tool']:paths.extend((ROOT/'packages'/package/subdir).rglob('*.dart'))
 return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=snapshot()
(OUT/f'{MODE}-source-before.json').write_text(json.dumps(before,indent=2)+'\n')
manifest={'mode':MODE,'cwd':str(EDITOR),'command':COMMANDS[MODE],'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'source_input_count':len(before),'editor_suites':len(TESTS),'incoming_main':'a97295f9734eca570392dfead123bebcc93747cd','initial_merge_checkpoint':'d4aa0709f811846cf04a98a99800975a82a92600'}
(OUT/f'{MODE}-command.json').write_text(json.dumps(manifest,indent=2)+'\n')
with (OUT/f'{MODE}.stdout').open('w') as stdout,(OUT/f'{MODE}.stderr').open('w') as stderr:
 result=subprocess.run(COMMANDS[MODE],cwd=EDITOR,stdout=stdout,stderr=stderr)
after=snapshot()
(OUT/f'{MODE}-source-after.json').write_text(json.dumps(after,indent=2)+'\n')
manifest.update(exit_code=result.returncode,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),source_unchanged=before==after)
if MODE=='editor':
 events=[]
 for line in (OUT/f'{MODE}.stdout').read_text().splitlines():
  try:
   event=json.loads(line)
   if event.get('type')=='testDone' and not event.get('hidden'):events.append(event)
  except (ValueError,AttributeError):pass
 manifest['test_summary']={'total':len(events),'success':sum(e.get('result')=='success' and not e.get('skipped') for e in events),'skipped':sum(bool(e.get('skipped')) for e in events),'failure':sum(e.get('result')=='failure' for e in events),'error':sum(e.get('result')=='error' for e in events)}
(OUT/f'{MODE}-result.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2));sys.exit(result.returncode)
