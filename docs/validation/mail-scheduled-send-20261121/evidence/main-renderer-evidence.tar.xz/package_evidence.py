import datetime,hashlib,json,pathlib,shutil,subprocess,tarfile
ROOT=pathlib.Path('/workspace/scratch/faef92d47725/quds_office_suite')
OUT=pathlib.Path('/workspace/scratch/faef92d47725/runtime/main-publication-followup')
COMMIT='6426d8877d5a7a2405bdd9060a1b6c443a731cb0'
PRIOR='964783488cfa8079464e7dc80c1df6bb139323f5'
MERGED='d4aa0709f811846cf04a98a99800975a82a92600'
MAIN_CODE='a97295f9734eca570392dfead123bebcc93747cd'
MAIN_DOCS='3440c90bc63f9d43edb7e64172bfec3d82036fee'
INCOMING='d7c44360304f9f2bb96e021d36da4db4906b4307'
checks={name:json.loads((OUT/f'{name}-result.json').read_text()) for name in ['editor','analyze','format']}
source=json.loads((OUT/'editor-source-before.json').read_text())
for name,result in checks.items():
 assert result['exit_code']==0 and result['source_unchanged'],name
 for when in ['before','after']:assert source==json.loads((OUT/f'{name}-source-{when}.json').read_text()),(name,when)
assert checks['editor']['test_summary']=={'total':76,'success':76,'skipped':0,'failure':0,'error':0}
assert len(source)==1251
blobs={}
for line in subprocess.check_output(['git','ls-tree','-r',COMMIT],cwd=ROOT,text=True).splitlines():
 metadata,path=line.split('\t',1);blobs[path]=metadata.split()[2]
for path,digest in source.items():
 data=(ROOT/path).read_bytes()
 assert hashlib.sha256(data).hexdigest()==digest,path
 assert hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest()==blobs[path],path
previous=json.loads((ROOT.parent/'runtime/publication-refresh/final/engine-source-before.json').read_text())
continuity={'previous_qualified_source':PRIOR,'changed_inputs':[p for p in previous if p in source and previous[p]!=source[p]],'added_inputs':[p for p in source if p not in previous],'removed_inputs':[p for p in previous if p not in source]}
assert continuity['changed_inputs']==['packages/quds_office_editor/lib/src/editor_word/render_word_canvas.dart']
assert continuity['added_inputs']==['packages/quds_office_editor/test/word_selection_path_cache_test.dart']
assert not continuity['removed_inputs']
for head in [MAIN_CODE,MAIN_DOCS,INCOMING,PRIOR]:
 assert subprocess.run(['git','merge-base','--is-ancestor',head,COMMIT],cwd=ROOT).returncode==0,head
assert subprocess.check_output(['git','diff','--name-only',MAIN_CODE,MAIN_DOCS],cwd=ROOT,text=True).splitlines()==['docs/roadmaps/typing-autocorrect-performance.md']
for name,args in {
 'incoming-renderer.patch':['git','diff',INCOMING+'^',INCOMING,'--','packages/quds_office_editor/lib/src/editor_word/render_word_canvas.dart'],
 'cache-correction.patch':['git','diff',MERGED,COMMIT,'--','packages/quds_office_editor/lib/src/editor_word/render_word_canvas.dart','packages/quds_office_editor/test/word_selection_path_cache_test.dart'],
 'main-documentation-followup.patch':['git','diff',MAIN_CODE,MAIN_DOCS,'--','docs/roadmaps/typing-autocorrect-performance.md'],
}.items():(OUT/name).write_bytes(subprocess.check_output(args,cwd=ROOT))
report={
 'schema':'quds-main-publication-followup/v1','qualified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'qualified_source_commit':COMMIT,'qualified_tree':subprocess.check_output(['git','rev-parse',COMMIT+'^{tree}'],cwd=ROOT,text=True).strip(),
 'source_input_count':len(source),'source_manifest':'editor-source-before.json','all_final_command_source_snapshots_identical':True,'all_source_inputs_match_qualified_git_blobs':True,
 'main_continuations_beyond_finite380_snapshot':[{'main':MAIN_CODE,'incoming_commit':INCOMING,'pr':335,'scope':'One editor renderer file: bounded proofing and selection path caches.'},{'main':MAIN_DOCS,'scope':'Documentation-only typing performance continuation, no additional renderer source.'}],
 'all_main_continuation_heads_are_ancestors':True,
 'capture_boundary':'No rescan of other remote branches or PR refs; these are explicit main-lease continuations beyond the separate finite380-ref publication snapshot.',
 'source_continuity':continuity,
 'cache_regression':json.loads((OUT/'cache-regression.json').read_text()),
 'correction':'Selection-path geometry depends on selectedTableBand.table. Replace redundant allowsSelection boolean cache component with the active table identity, retaining the bounded cache and main implementation.',
 'checks':checks,'final_editor_tests':76,'final_editor_suites':10,'strict_analyzed_dart_paths':2,'formatted_dart_paths':2,
 'runtime':{'flutter':'3.47.8','dart':'3.13.7'},
 'boundaries':['Prior1725-engine/19ODT-editor gate is retained and engine inputs are byte-identical, so it was not repeated.','The76-case gate includes existing Linux selection goldens, proofing pixels, header/footer navigation, hyphenation, underline, selection and table-history cases.','No GitHub Actions were queried or awaited.','Runtime agent performs final Studio Mail qualification separately after this isolated renderer run.','The focused regression pass overlaps the final76-case run; do not count it twice.']
}
(OUT/'main-followup.json').write_text(json.dumps(report,indent=2)+'\n')
review='''# Final main follow-up

Qualified source is **`6426d8877d5a7a2405bdd9060a1b6c443a731cb0`**, tree `01152f796d3e1bcc0b7a128433661f2f0d4fc33d`. **76 editor tests across10 focused suites pass**, with zero failures or skips. Strict analysis and formatting pass the renderer and its new regression test. All1,251 engine/editor Dart inputs match before/after checks and the qualified Git commit.

Two explicit main continuations arrived after the separate finite380-ref publication snapshot:

- **`a97295f9734eca570392dfead123bebcc93747cd`**, merging PR#335 / commit `d7c44360304f9f2bb96e021d36da4db4906b4307`, adds bounded proofing/selection path caches in `render_word_canvas.dart`.
- **`3440c90bc63f9d43edb7e64172bfec3d82036fee`** adds only typing-performance documentation. It introduces no further renderer source change.

Both main heads and the incoming implementation are ancestors of the qualified checkpoint. Other branches were not rescanned; the finite380-ref snapshot remains separate and unchanged.

## Confirmed regression and correction

The new selection cache originally keyed geometry by page, caret endpoints and an always-true selection flag. Selection painting also depends on the active table band. A retained canvas therefore reused old text-selection tint after switching to a row/column band without changing its page or caret.

A new pixel regression compares the retained renderer with a fresh renderer using the same final document, layout and caret. It failed on incoming source (first differing byte108080:31 versus36), then passed after the cache key included `selectedTableBand?.table` instead of the redundant flag. The bounded cache and the incoming optimization remain. No golden references were changed.

The10-suite final gate covers selection geometry and Linux goldens, the new cache regression, proofing geometry/navigation, header/footer navigation, hyphenation paint/carets, underline paint, live review selection and table-grid history. The initial failing log and corrected one-test pass are retained; the one-test pass overlaps the final76 cases.

## Source continuity and evidence

Compared with publication checkpoint `964783488cfa8079464e7dc80c1df6bb139323f5`, the only changed input is `render_word_canvas.dart`, and the only added input is `word_selection_path_cache_test.dart`. All engine inputs are unchanged, so the preceding1,725-case engine qualification was not repeated. Final Studio Mail qualification is recorded separately by the runtime agent after this renderer run.

The archive contains exact incoming/correction/documentation patches, raw JSON events, commands, analysis/format output, immutable source hashes and `main-followup.json`. No GitHub Actions were queried or awaited.
'''
for old,new in [('across10','across 10'),('All1,251','All 1,251'),('finite380','finite 380'),('PR#','PR #'),('byte108080:31 versus36','byte 108080: 31 versus 36'),('The10','The 10'),('final76','final 76'),('preceding1,725','preceding 1,725')]:review=review.replace(old,new)
(OUT/'main-followup.md').write_text(review)
shutil.copy2(OUT/'main-followup.json',ROOT.parent/'main-followup.json')
shutil.copy2(OUT/'main-followup.md',ROOT.parent/'main-followup.md')
archive=OUT/'main-renderer-evidence.tar.xz';index_path=OUT/'evidence-index.json'
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p not in [archive,index_path])
index={'archive':archive.name,'files':{str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}}
index_path.write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(archive,'w:xz') as tar:
 for p in files+[index_path]:tar.add(p,arcname=str(p.relative_to(OUT)))
with tarfile.open(archive) as tar:
 for member in tar.getmembers():
  data=tar.extractfile(member).read()
  if member.name!='evidence-index.json':assert hashlib.sha256(data).hexdigest()==index['files'][member.name]['sha256'],member.name
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files)+1,'final_editor_passes':76,'source_inputs':len(source)},indent=2))
