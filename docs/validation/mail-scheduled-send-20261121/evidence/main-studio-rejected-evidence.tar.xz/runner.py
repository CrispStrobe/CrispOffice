"""Main publication Studio qualification after concurrent PR 335 renderer integration; no remote CI reads or writes."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
from urllib.parse import unquote, urljoin, urlsplit

BASE = Path('/workspace/scratch/faef92d47725')
ROOT = BASE / 'quds_office_suite'
STUDIO = ROOT / 'packages/quds_office_editor/example'
OUTPUT = Path(__file__).resolve().parent
SDK = BASE / 'runtime/flutter'
sys.path.insert(0, str(ROOT / 'tools/mail'))
from check_store import test_summary

SUITES = [
    'studio_mail_outbox_submission_test.dart',
    'studio_mail_outbox_store_test.dart',
    'studio_mail_outbox_management_test.dart',
    'studio_mail_outbox_host_test.dart',
    'studio_mail_outbox_export_test.dart',
    'studio_mail_outbox_dialog_test.dart',
    'studio_mail_outbox_schedule_dialog_test.dart',
    'studio_mail_outbox_schedule_session_test.dart',
    'studio_mail_outbox_scheduling_store_test.dart',
    'studio_mail_schedule_picker_test.dart',
    'studio_mail_compose_tools_test.dart',
    'studio_mail_compose_tools_dialog_test.dart',
    'studio_mail_compose_tools_store_test.dart',
]
TARGETS = [
    'lib/studio_mail_draft_store.dart',
    'lib/studio_mail_outbox.dart',
    'lib/studio_mail_outbox_dialog.dart',
    'lib/studio_mail_outbox_schedule_session.dart',
    'lib/studio_mail_schedule_dialog.dart',
    'lib/studio_mail_schedule_strings.dart',
    'test/studio_mail_outbox_schedule_dialog_test.dart',
    'test/studio_mail_outbox_schedule_session_test.dart',
    'test/studio_mail_outbox_scheduling_store_test.dart',
    'test/studio_mail_schedule_picker_test.dart',
    'tool/mail_schedule_visual_test.dart',
]
ROOT_INPUTS = {'.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
               'tools/mail/check_store.py', 'tools/mail/check_reader.py'}

def digest(path: Path):
    if path.is_symlink():
        return {'type': 'symlink', 'target': os.readlink(path)}
    if not path.is_file():
        return {'type': 'missing'}
    value = hashlib.sha256()
    with path.open('rb') as source:
        while block := source.read(1024 * 1024):
            value.update(block)
    return {'type': 'file', 'size': path.stat().st_size, 'sha256': value.hexdigest()}

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT)

def workspace_inputs():
    paths = set()
    for arguments in [('ls-files', '-z'), ('ls-files', '--others', '--exclude-standard', '-z')]:
        paths.update(item.decode() for item in git(*arguments).split(b'\0') if item)
    selected = sorted(path for path in paths if path in ROOT_INPUTS or path.startswith(('packages/', 'apps/', 'third_party/')))
    return {path: digest(ROOT / path) for path in selected}

def dependency_inputs():
    configuration = ROOT / '.dart_tool/package_config.json'
    names = set()
    for entry in json.loads(configuration.read_text())['packages']:
        uri = urlsplit(urljoin(configuration.as_uri(), entry['rootUri']))
        if uri.scheme != 'file':
            raise ValueError('Expected local resolved package: ' + entry['name'])
        package = Path(unquote(uri.path)).resolve()
        if package.is_relative_to(ROOT):
            continue
        for folder in ('lib', 'bin', 'hook'):
            names.update(path for path in (package / folder).rglob('*') if path.is_file() or path.is_symlink())
        names.update(package / name for name in ('pubspec.yaml', 'pubspec.lock') if (package / name).exists())
    names.update([
        configuration,
        ROOT / '.dart_tool/native_assets.yaml',
        ROOT / '.dart_tool/lib/libsqlite3.so',
        SDK / 'bin/cache/flutter.version.json',
        SDK / 'bin/cache/flutter_tools.snapshot',
        SDK / 'bin/cache/dart-sdk/bin/dart',
        SDK / 'bin/cache/dart-sdk/bin/dartvm',
        SDK / 'bin/cache/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot',
        SDK / 'bin/cache/artifacts/engine/linux-x64/flutter_tester',
        SDK / 'bin/cache/artifacts/engine/common/flutter_patched_sdk/platform_strong.dill',
        SDK / 'bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf',
    ])
    return {str(path): digest(path) for path in sorted(names)}

def save(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2) + '\n')

def differences(before, after):
    return [key for key in sorted(before.keys() | after.keys()) if before.get(key) != after.get(key)]

receipt = {
    'status': 'RUNNING',
    'started_utc': datetime.now(timezone.utc).isoformat(),
    'starting_commit': git('rev-parse', 'HEAD').decode().strip(),
    'runner_sha256': digest(Path(__file__))['sha256'],
    'scope': {
        'tests': SUITES,
        'analysis_and_format': TARGETS,
        'source_map': 'All tracked and non-ignored untracked workspace package/app/third_party files, plus root SDK/dependency/analyzer inputs and qualification parser sources. Broad superset, not a minimal import closure.',
        'dependencies': 'All currently resolved external package lib/bin/hook sources and manifests, package configuration, SQLite native mapping/library, and selected Dart/Flutter compiler, framework and engine artifacts. Does not claim every OS runtime file or a browser/provider acceptance run.',
    },
    'github_actions_used': False,
    'checks': [],
}
save('receipt.json', receipt)
before = workspace_inputs()
dependencies_before = dependency_inputs()
selected_before = {name: digest(STUDIO / name) for name in TARGETS}
save('source-before.json', before)
save('dependencies-before.json', dependencies_before)
save('selected-before.json', selected_before)
print('Captured', len(before), 'workspace files and', len(dependencies_before), 'dependency inputs', flush=True)

def run(name, command, *, tests=False, timeout=360):
    stdout = OUTPUT / (name + ('.jsonl' if tests else '.stdout'))
    stderr = OUTPUT / (name + '.stderr')
    check = {'name': name, 'command': command, 'cwd': str(STUDIO), 'timeout_seconds': timeout,
             'stdout': stdout.name, 'stderr': stderr.name, 'status': 'RUNNING'}
    receipt['checks'].append(check)
    save('receipt.json', receipt)
    print('Running', name, flush=True)
    with stdout.open('wb') as out, stderr.open('wb') as err:
        process = subprocess.Popen(command, cwd=STUDIO, env=os.environ.copy(), stdout=out, stderr=err, start_new_session=True)
        try:
            check['exit_code'] = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            check['exit_code'] = 124
            check['timed_out'] = True
    check['stdout_sha256'] = digest(stdout)['sha256']
    check['stderr_sha256'] = digest(stderr)['sha256']
    check['stderr_bytes'] = stderr.stat().st_size
    ok = check['exit_code'] == 0
    if tests:
        summary = test_summary(stdout)
        save(name + '-cases.json', summary)
        check['tests'] = {key: value for key, value in summary.items() if key != 'cases'}
        ok = ok and summary['valid'] and summary['passed'] == 143
        check['expected_passed_cases'] = 143
    check['status'] = 'PASS' if ok else 'FAIL'
    save('receipt.json', receipt)
    print(name, check['status'], check.get('tests', {}).get('passed', ''), flush=True)
    return ok

ok = run('studio-combined', [str(SDK / 'bin/flutter'), '--no-version-check', '--suppress-analytics', 'test', '--no-pub', *['test/' + name for name in SUITES], '--reporter', 'json'], tests=True)
ok = run('scheduling-analysis', [str(SDK / 'bin/cache/dart-sdk/bin/dart'), 'analyze', '--fatal-infos', *TARGETS]) and ok
ok = run('scheduling-format', [str(SDK / 'bin/cache/dart-sdk/bin/dart'), 'format', '--output=none', '--set-exit-if-changed', *TARGETS]) and ok

after = workspace_inputs()
dependencies_after = dependency_inputs()
selected_after = {name: digest(STUDIO / name) for name in TARGETS}
save('source-after.json', after)
save('dependencies-after.json', dependencies_after)
save('selected-after.json', selected_after)
receipt.update(
    source_changes=differences(before, after),
    dependency_changes=differences(dependencies_before, dependencies_after),
    selected_changes=differences(selected_before, selected_after),
    finishing_commit=git('rev-parse', 'HEAD').decode().strip(),
    finished_utc=datetime.now(timezone.utc).isoformat(),
    workspace_input_count=len(before),
    dependency_input_count=len(dependencies_before),
)
unchanged = not any(receipt[key] for key in ('source_changes','dependency_changes','selected_changes'))
receipt['status'] = 'PASS' if ok and unchanged else 'FAIL'
save('receipt.json', receipt)
print(receipt['status'], 'source unchanged:', unchanged, flush=True)
raise SystemExit(0 if receipt['status'] == 'PASS' else 1)
