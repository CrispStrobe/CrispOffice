import hashlib
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/workspace/scratch/faef92d47725/quds_office_suite')
OUT = pathlib.Path('/workspace/scratch/faef92d47725/runtime/odt-integration')
BASE = 'cb56910da89751bb572d4448dfec5e66b38c0662'
MERGE = '44a980b089b6b452e73bcc3a51ed8f820d83fd7a'
MODE = sys.argv[1]
OUT = OUT / (sys.argv[2] if len(sys.argv) > 2 else 'final')
OUT.mkdir(parents=True, exist_ok=True)
engine = ROOT / 'packages/quds_office_engine'
editor = ROOT / 'packages/quds_office_editor'
changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, MERGE], cwd=ROOT, text=True).splitlines()
changed = sorted(set(changed + ['packages/quds_office_engine/test/odt_section_fidelity_test.dart']))
engine_changed = [str(pathlib.Path(p).relative_to(engine.relative_to(ROOT))) for p in changed if p.startswith('packages/quds_office_engine/') and p.endswith('.dart')]
editor_changed = [str(pathlib.Path(p).relative_to(editor.relative_to(ROOT))) for p in changed if p.startswith('packages/quds_office_editor/') and p.endswith('.dart')]
engine_tests = sorted(str(p.relative_to(engine)) for p in (engine / 'test').glob('*_test.dart') if p.name.startswith(('odt_', 'odf_zotero')))
editor_tests = sorted(str(p.relative_to(editor)) for p in (editor / 'test').glob('*odt*_test.dart'))
profiles = {
    'engine-focused': (engine, ['dart', 'test', '--reporter=json', '--concurrency=2', 'test/odt_comment_fidelity_test.dart', 'test/odt_section_fidelity_test.dart', 'test/odt_story_visual_fidelity_test.dart', 'test/odt_reader_images_test.dart', 'test/odt_libreoffice_bibliography_test.dart']),
    'engine': (engine, ['dart', 'test', '--reporter=json', '--concurrency=2', *engine_tests]),
    'editor': (editor, ['flutter', 'test', '--no-pub', '--reporter=json', '--concurrency=1', *editor_tests]),
    'engine-analyze': (engine, ['dart', 'analyze', '--fatal-infos', *engine_changed]),
    'editor-analyze': (editor, ['dart', 'analyze', '--fatal-infos', *editor_changed]),
    'format': (ROOT, ['dart', 'format', '--output=none', '--set-exit-if-changed', *(p for p in changed if p.endswith('.dart'))]),
}
cwd, command = profiles[MODE]

def snapshot():
    paths = []
    for package in (engine, editor):
        for subdir in ('lib', 'test', 'tool'):
            paths.extend((package / subdir).rglob('*.dart'))
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}

before = snapshot()
(OUT / f'{MODE}-source-before.json').write_text(json.dumps(before, indent=2) + '\n')
manifest = {
    'mode': MODE, 'merge_commit': MERGE, 'cwd': str(cwd), 'command': command,
    'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    'engine_suites': len(engine_tests), 'editor_suites': len(editor_tests),
    'source_input_count': len(before),
}
(OUT / f'{MODE}-command.json').write_text(json.dumps(manifest, indent=2) + '\n')
with (OUT / f'{MODE}.stdout').open('w') as stdout, (OUT / f'{MODE}.stderr').open('w') as stderr:
    proc = subprocess.run(command, cwd=cwd, stdout=stdout, stderr=stderr)
after = snapshot()
(OUT / f'{MODE}-source-after.json').write_text(json.dumps(after, indent=2) + '\n')
manifest.update(exit_code=proc.returncode, finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), source_unchanged=before == after)
if MODE in ('engine', 'engine-focused', 'editor'):
    events = []
    for line in (OUT / f'{MODE}.stdout').read_text().splitlines():
        try:
            event = json.loads(line)
            if event.get('type') == 'testDone':
                events.append(event)
        except (ValueError, AttributeError):
            pass
    visible = [e for e in events if not e.get('hidden')]
    manifest['test_summary'] = {
        'total': len(visible),
        'success': sum(e.get('result') == 'success' and not e.get('skipped') for e in visible),
        'skipped': sum(bool(e.get('skipped')) for e in visible),
        'failure': sum(e.get('result') == 'failure' for e in visible),
        'error': sum(e.get('result') == 'error' for e in visible),
    }
(OUT / f'{MODE}-result.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
sys.exit(proc.returncode)
