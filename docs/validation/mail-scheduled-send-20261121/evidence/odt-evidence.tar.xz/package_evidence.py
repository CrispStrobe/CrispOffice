import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import tarfile

ROOT = pathlib.Path('/workspace/scratch/faef92d47725/quds_office_suite')
OUT = pathlib.Path('/workspace/scratch/faef92d47725/runtime/odt-integration')
MERGE = '44a980b089b6b452e73bcc3a51ed8f820d83fd7a'
SOURCE_COMMIT = 'e9a95d7795812a8322c3a0c1d508cf05553bfe82'
checks = {name: json.loads((OUT / 'final' / f'{name}-result.json').read_text()) for name in ['engine','editor','engine-analyze','editor-analyze','format']}
source = json.loads((OUT / 'final/engine-source-before.json').read_text())
for name, result in checks.items():
    assert result['exit_code'] == 0 and result['source_unchanged'], name
    for when in ['before','after']:
        assert source == json.loads((OUT / 'final' / f'{name}-source-{when}.json').read_text()), (name,when)
commit_blobs = {}
for line in subprocess.check_output(['git','ls-tree','-r',SOURCE_COMMIT],cwd=ROOT,text=True).splitlines():
    metadata,path = line.split('\t',1)
    commit_blobs[path] = metadata.split()[2]
for path, digest in source.items():
    data = (ROOT/path).read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest, path
    assert hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest() == commit_blobs[path], path
assert checks['engine']['test_summary'] == {'total':1206,'success':1206,'skipped':0,'failure':0,'error':0}
assert checks['editor']['test_summary'] == {'total':19,'success':19,'skipped':0,'failure':0,'error':0}
qualification = {
    'schema': 'quds-odt-integration-qualification/v1',
    'qualified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'integration_commit': MERGE,
    'qualified_source_commit': SOURCE_COMMIT,
    'all_source_inputs_match_qualified_commit_blobs': True,
    'integration_tree': subprocess.check_output(['git','rev-parse',MERGE+'^{tree}'],cwd=ROOT,text=True).strip(),
    'source': 'Integration commit plus integration-corrections.patch. Exact file hashes recorded before and after every final command.',
    'source_input_count': len(source),
    'source_snapshot_scope': 'All Dart source files under engine and editor lib, test, and tool; excludes editor/example Mail work.',
    'source_snapshot': 'final/engine-source-before.json',
    'all_final_source_snapshots_identical': True,
    'current_worktree_hashes_match': True,
    'runtime': {'flutter':'3.47.8','dart':'3.13.7','enforced_lock':'Runtime setup independently completed offline enforced-lock resolution.'},
    'merge_heads': ['37afb04e1167fe306e4d124368a08e372638f4ab','bf54a8e7d976670af87dd3d36f3afc26c1821d3b','81e478ca0ffe249a908362cd233790b8920d439c'],
    'merge_commits': ['056970556f6c821c3070b8e4213769bc81bbf499','ba615eaa13d8fc08d423767366275e8a293cb4ce',MERGE],
    'conflict': {'path':'packages/quds_office_engine/lib/src/word/serial/odt_document_reader.dart','hunks':2,'resolution':'Combine ZipReader positional parameter with required libreOfficeNoteOffsets named parameter; initialize images then index content.'},
    'corrections': [
        'Normalize generated draw:name picture identities only inside story comparison copies, retaining package-wide unique frame names in emitted ODT and avoiding spurious continuous-section page breaks.',
        'Keep annotation picture frame structure unchanged while ordinary/native pictures retain run-style spans.',
        'Remove redundant nullable access on non-null bibliography indentation in incoming test.',
        'Strengthen the existing continuous-header regression with assertions that two emitted picture identities remain distinct.'
    ],
    'checks': checks,
    'distinct_final_tests': 1225,
    'focused_overlap_tests': 165,
    'initial_failure_evidence': 'initial/ includes full pre-correction run (1203 passes,3 failures), one strict analyzer warning, and failed flutter analyze wrapper invocation. No rejected run is counted as a pass.',
    'environment_retry': 'editor-startup-race/ records a Flutter shell cache temp-file race from concurrent startup. No tests executed; retry serialized startup and passed19 editor cases.',
    'limitations': [
        'No GitHub Actions queried or awaited.',
        'No actual external LibreOffice converter or installed Zotero plugin/CSL session executed in this intake task. Retained LibreOffice fixture tests passed locally.',
        'Validation is focused ODT/ODF-Zotero engine and ODT editor scope, not the complete repository test suite.',
        'The fixed intake snapshot is finite; later remotely advancing branches are outside its captured cutoff.'
    ],
}
(OUT/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
intake_path = pathlib.Path('/workspace/scratch/faef92d47725/final-intake.json')
intake = json.loads(intake_path.read_text())
intake['qualification'] = {'status':'passed','engine_tests':1206,'engine_suites':63,'editor_tests':19,'editor_suites':3,'analyzed_dart_paths':15,'formatted_dart_paths':15,'qualified_source_commit':SOURCE_COMMIT,'source':'All1247 input hashes match the committed source; immutable hashes in separate evidence archive.'}
intake_path.write_text(json.dumps(intake,indent=2)+'\n')
review = '''# Final incoming-history reconciliation

The frozen **377-ref snapshot is fully reconciled** at `44a980b089b6b452e73bcc3a51ed8f820d83fd7a`: **363 captured refs are ancestors and14 historical PR refs have verified equivalents**. No captured current production branch remains unintegrated. The snapshot was captured2026-11-21 at18:56:54 UTC; later remote advances are outside this finite checkpoint.

| Source | Captured | Ancestors | Verified equivalents |
|---|---:|---:|---:|
| Fork branches |41|41|0|
| Fork PR heads |332|318|14|
| Original upstream branches |4|4|0|
| Total |377|363|14|

The historical PRs are #134,135,136,137,138,140,141,142,145,146,147,149,151,152. Thirteen have exact whole-tree equality with accepted ancestors. PR#140 has exact equality for all37 paths changed by its original commit. Every replacement is an ancestor of the integrated checkpoint. Full object IDs, paths, trees and proofs are in `final-intake.json`.

## Preserved incoming heads

| Head | Scope | Local merge commit |
|---|---|---|
| `37afb04e1167fe306e4d124368a08e372638f4ab` | Word merge ancestry and intake docs; native Word655 source already qualified | `056970556f6c821c3070b8e4213769bc81bbf499` |
| `bf54a8e7d976670af87dd3d36f3afc26c1821d3b` | Native ODT bibliography wrappers, producer-specific note offsets, table geometry | `ba615eaa13d8fc08d423767366275e8a293cb4ce` |
| `81e478ca0ffe249a908362cd233790b8920d439c` | Embedded inline PNG/JPEG import/export, image ownership/styles, distinct drawing names | `44a980b089b6b452e73bcc3a51ed8f820d83fd7a` |

Each merge retains its original incoming head as a parent. The only merge conflict was two constructor hunks in `odt_document_reader.dart`: the resolved call and constructor preserve both the ZIP image input and the LibreOffice note-offset flag. Shared writer/style changes merged automatically and received combined runtime validation.

## Combined qualification and corrections

All **1,206 engine tests in63 focused ODT/ODF-Zotero suites** and **19 editor tests in3 ODT suites** passed on the final source. Fatal-info analysis and formatting passed on15 relevant Dart paths. All source inputs also match committed source `e9a95d7795812a8322c3a0c1d508cf05553bfe82`. Hashes for1,247 engine/editor Dart inputs are identical before and after every final command, and all final commands share the same source snapshot.

The first combined engine run exposed three incoming failures: two continuous-section page-break regressions caused by newly allocated picture names leaking into story comparisons, and one annotation picture structure regression. A narrow writer correction ignores picture identity only in comparison copies, preserving unique names in emitted packages, and retains existing comment-picture structure while ordinary picture style spans remain. The existing continuous-header regression now also checks emitted identities remain distinct. One redundant nullable operator in an incoming bibliography test was corrected for strict analysis. These changes are captured as a three-file patch in the evidence archive; no incoming production capability was dropped.

Raw initial failures, the overlapping165-test focused rerun, final1,225 passing tests, strict analysis/format logs, source hashes and exact commands are retained in the ODT evidence package. No external LibreOffice conversion or installed Zotero/CSL session was run here; the committed LibreOffice fixture tests passed. GitHub Actions were neither queried nor awaited.
'''
# Keep spacing readable in prose and tables without changing identifiers.
for old,new in [('and14','and 14'),('captured2026','captured 2026'),('at18:','at 18:'),('PR#','PR #'),('all37','all 37'),('Word655','Word 655'),('in63','in 63'),('in3','in 3'),('on15','on 15'),('for1,247','for 1,247'),('overlapping165','overlapping 165'),('final1,225','final 1,225')]:
    review = review.replace(old,new)
pathlib.Path('/workspace/scratch/faef92d47725/final-intake-review.md').write_text(review)
shutil.copy2(intake_path,OUT/'final-intake.json')
shutil.copy2('/workspace/scratch/faef92d47725/final-intake-review.md',OUT/'final-intake-review.md')
(OUT/'README.md').write_text('''# Combined ODT intake qualification

Final source passes **1,206 engine cases across63 suites** and **19 editor cases across3 suites**, with zero skips or failures. Strict Dart analysis and formatting pass15 relevant paths. The evidence binds source to integration commit `44a980b089b6b452e73bcc3a51ed8f820d83fd7a` plus `integration-corrections.patch` (committed as `e9a95d7795812a8322c3a0c1d508cf05553bfe82`); all1,247 engine/editor input hashes match across final commands and the current worktree.

`qualification.json` describes the merged heads, constructor conflict resolution, narrow regressions repaired, runtime and claim boundaries. `final-intake.json` contains the frozen377-ref inventory and historical-equivalence proofs; its review is in `final-intake-review.md`.

- `initial/`: original combined1206-case engine run with1203 passes and3 failures; first19-case editor pass; initial analyzer warning and Flutter analyzer wrapper error.
- `focused/`:165 passing cases after the narrow correction, overlapping the final full scope.
- `final/`:63engine suites/3editor suites, both strict analyzers, formatting, exact commands, JSON events and before/after source hashes.
- `editor-startup-race/`: zero-test Flutter shell startup failure from a shared SDK temp filename; later serialized startup retry passed.
- `correction-source-manifest.json`: exact three-file correction and runtime input hashes.
- `run_checks.py`: reproducible scoped runner; use the pinned runtime environment, then select engine, editor, engine-analyze, editor-analyze or format. The runner requires the source checkout and configured package metadata.

No GitHub Actions were queried or awaited. No external LibreOffice converter or installed Zotero plugin was executed in this task. Existing fixture-based interoperability tests ran locally. This archive qualifies the stated focused scope, not the entire repository.
'''.replace('across63','across 63').replace('across3','across 3').replace('pass15','pass 15').replace('all1,247','all 1,247').replace('frozen377','frozen 377').replace('combined1206','combined 1206').replace('with1203','with 1203').replace('and3','and 3').replace('first19','first 19').replace('`:165','`: 165').replace(':63engine',': 63 engine').replace('/3editor','/3 editor'))
archive=OUT/'odt-integration-evidence.tar.xz'
index_path=OUT/'evidence-index.json'
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name not in {'odt-integration-evidence.tar.gz','odt-integration-evidence.tar.xz','evidence-index.json'})
index={'archive':archive.name,'files':{str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}}
index_path.write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(archive,'w:xz') as tar:
    for file in files+[index_path]:
        tar.add(file,arcname=str(file.relative_to(OUT)))
with tarfile.open(archive) as tar:
    for item in tar.getmembers():
        data=tar.extractfile(item).read()
        if item.name != 'evidence-index.json':
            assert hashlib.sha256(data).hexdigest() == index['files'][item.name]['sha256'], item.name
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files)+1,'distinct_final_tests':1225,'source_inputs':len(source)},indent=2))
