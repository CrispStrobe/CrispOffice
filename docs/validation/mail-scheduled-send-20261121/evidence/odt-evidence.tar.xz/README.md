# Combined ODT intake qualification

Final source passes **1,206 engine cases across 63 suites** and **19 editor cases across 3 suites**, with zero skips or failures. Strict Dart analysis and formatting pass 15 relevant paths. The evidence binds source to integration commit `44a980b089b6b452e73bcc3a51ed8f820d83fd7a` plus `integration-corrections.patch` (committed as `e9a95d7795812a8322c3a0c1d508cf05553bfe82`); all 1,247 engine/editor input hashes match across final commands and the current worktree.

`qualification.json` describes the merged heads, constructor conflict resolution, narrow regressions repaired, runtime and claim boundaries. `final-intake.json` contains the frozen 377-ref inventory and historical-equivalence proofs; its review is in `final-intake-review.md`.

- `initial/`: original combined 1206-case engine run with 1203 passes and 3 failures; first 19-case editor pass; initial analyzer warning and Flutter analyzer wrapper error.
- `focused/`: 165 passing cases after the narrow correction, overlapping the final full scope.
- `final/`: 63 engine suites/3 editor suites, both strict analyzers, formatting, exact commands, JSON events and before/after source hashes.
- `editor-startup-race/`: zero-test Flutter shell startup failure from a shared SDK temp filename; later serialized startup retry passed.
- `correction-source-manifest.json`: exact three-file correction and runtime input hashes.
- `run_checks.py`: reproducible scoped runner; use the pinned runtime environment, then select engine, editor, engine-analyze, editor-analyze or format. The runner requires the source checkout and configured package metadata.

No GitHub Actions were queried or awaited. No external LibreOffice converter or installed Zotero plugin was executed in this task. Existing fixture-based interoperability tests ran locally. This archive qualifies the stated focused scope, not the entire repository.
