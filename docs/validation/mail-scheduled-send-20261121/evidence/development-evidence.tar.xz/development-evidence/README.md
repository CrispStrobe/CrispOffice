# Mail scheduling development evidence

This archive retains superseded intermediate runs from the Send later/Undo
implementation. These files explain development failures and subsequent
iterations. They are **not the final accepted qualification**, and their counts
must not be added to the accepted core/store, combined Studio or Office totals.
The final accepted scopes and source identities are recorded in the separate
core/store and Studio evidence archives and the repository validation README.

## Retained runs

| Files | Recorded intermediate result |
| --- | --- |
| `schedule-session-store-events.jsonl` and `schedule-session-store-stderr.log` | Compilation/loading failed: the initial fixtures passed a `List<int>` where `Uint8List` was required and a string where `MailProviderKind` was required. No successful behavioral cases are claimed. |
| `schedule-session-store-v2-events.jsonl` and matching stderr | 14 successful cases and two errors while reopening fixture storage; the failures remain in the raw stream. |
| `schedule-session-store-v3-events.jsonl` and matching stderr | 16 successful session/adapter cases, superseded by their inclusion in the final combined Studio cohort. |
| `core-schedule-tests.log` | Earlier full-core run reporting 482 passes; overlaps the final 482-case core result. |
| `store-schedule-tests.log` | Earlier 107-case codec/repository/Outbox cohort; overlaps the final full-store result. |
| `core-store-schedule-analyze.log` | Earlier successful core/store analysis. |
| `outbox-existing-regression.log` | Earlier 66-case existing Outbox cohort; overlaps the final combined Studio result. |
| `runtime/logs/scheduling-widgets.jsonl` and matching stderr | First widget iteration: 17 successful cases and one error. |
| `runtime/logs/scheduling-widgets-final.jsonl` and matching stderr | Second widget iteration: 22 successful cases and two errors. The original filename contains `final`; its terminal result is **false**, so it is not accepted final evidence. |
| `runtime/logs/scheduling-widgets-v3.jsonl`, matching stderr and summary | Third widget iteration: 24 successful cases. These cases subsequently run within the final combined Studio cohort. |
| `runtime/logs/scheduling-widgets-verified-inputs.json` | Retained selected input hashes from the widget iteration. It does not bind every earlier failed run to final source. |

The widget files were originally named without `v1`/`v2` suffixes: the base
filename is the first iteration, and the historical `-final` filename is the
second. Their names and raw contents are preserved. Empty stderr files are
included rather than omitted. JSON error events and non-success terminal events
are not removed or reclassified as passes.

`index.json` lists every copied source file, its workspace-relative origin,
byte length and SHA-256. `SHA256SUMS` covers all payload files, this README and
the index. No tests were rerun while assembling this archive. No SDK, package
cache, unrelated project files, credentials or live mail data are included.
