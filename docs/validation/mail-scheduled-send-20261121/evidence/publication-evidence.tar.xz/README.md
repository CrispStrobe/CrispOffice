# Publication refresh evidence

Qualified source: **`964783488cfa8079464e7dc80c1df6bb139323f5`**.

- **1,725 engine tests** across 86 suites (64 ODT/ODF-Zotero + 22 affected Word table/style/layout/package suites).
- **19 editor tests** across 3 ODT suites.
- Zero failures or skips; strict analysis and formatting pass 11 changed Dart paths.
- All 1,250 recorded engine/editor Dart source inputs match every final run and the qualified Git commit.
- No source or formatting edits were necessary during this qualification.

`publication-intake.json` and `publication-intake.md` account for the separate 380-ref publication snapshot. The original 377-ref intake and previous ODT archive remain unchanged. `qualification.json` supplies exact scope and claim boundaries. `publication-source.patch` records the complete source delta from prior qualified checkpoint e9a95d77. `final/` contains exact commands, raw JSON event/stdout/stderr, result summaries, and before/after SHA-256 source manifests. `open-pr-metadata.json` retains the observed draft PR #333 snapshot.

The runtime is pinned Flutter 3.47.8/Dart 3.13.7 with the previously prepared locked package configuration. No GitHub Actions were queried or awaited, and no external LibreOffice converter or installed Zotero plugin was run by this task. The new gate overlaps prior qualification; counts are not additive across earlier runs.
