import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import tarfile

ROOT=pathlib.Path('/workspace/scratch/faef92d47725/quds_office_suite')
OUT=pathlib.Path('/workspace/scratch/faef92d47725/runtime/publication-refresh')
COMMIT='964783488cfa8079464e7dc80c1df6bb139323f5'
checks={name:json.loads((OUT/'final'/f'{name}-result.json').read_text()) for name in ['engine','editor','analyze','format']}
source=json.loads((OUT/'final/engine-source-before.json').read_text())
for name,result in checks.items():
 assert result['exit_code']==0 and result['source_unchanged'],name
 for when in ['before','after']:
  assert source==json.loads((OUT/'final'/f'{name}-source-{when}.json').read_text()),(name,when)
blobs={}
for line in subprocess.check_output(['git','ls-tree','-r',COMMIT],cwd=ROOT,text=True).splitlines():
 metadata,path=line.split('\t',1);blobs[path]=metadata.split()[2]
for path,digest in source.items():
 data=(ROOT/path).read_bytes()
 assert hashlib.sha256(data).hexdigest()==digest,path
 assert hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest()==blobs[path],path
assert checks['engine']['test_summary']=={'total':1725,'success':1725,'skipped':0,'failure':0,'error':0}
assert checks['editor']['test_summary']=={'total':19,'success':19,'skipped':0,'failure':0,'error':0}
assert len(source)==1250
qualification={
 'schema':'quds-office-publication-qualification/v1',
 'qualified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'qualified_source_commit':COMMIT,
 'qualified_tree':subprocess.check_output(['git','rev-parse',COMMIT+'^{tree}'],cwd=ROOT,text=True).strip(),
 'prior_qualified_source':'e9a95d7795812a8322c3a0c1d508cf05553bfe82',
 'source_patch':'publication-source.patch',
 'source_patch_sha256':hashlib.sha256((OUT/'publication-source.patch').read_bytes()).hexdigest(),
 'source_input_count':len(source),
 'source_scope':'All Dart source files under engine and editor lib, test, and tool; Studio Mail example is separately qualified by runtime_setup.',
 'source_manifest':'final/engine-source-before.json',
 'all_final_command_source_snapshots_identical':True,
 'all_source_inputs_match_qualified_git_blobs':True,
 'runtime':{'flutter':'3.47.8','dart':'3.13.7'},
 'checks':checks,
 'final_engine_tests':1725,'final_editor_tests':19,'distinct_final_tests':1744,
 'engine_suite_breakdown':{'odt_odf_zotero':64,'affected_word_table_style_package_layout':22},
 'prior_scope_overlap':'This fresh gate overlaps earlier ODT and Word qualification; do not sum it with earlier counts as unique tests.',
 'source_edits_during_qualification':False,
 'incoming_resolution':'Root preserved new main5c59a062 and both Zotero heads as explicit parents; adopted source-name map/comment style spans from58fe and native margin/soft-break source from3eac while preserving prior table alignment/uniqueness assertions.',
 'claim_boundaries':[
  'No GitHub Actions queried or awaited.',
  'No actual external LibreOffice converter or installed Zotero plugin/CSL acceptance session executed by this qualification; committed fixture tests ran locally.',
  'Focused changed-source validation; no claim that the entire repository test suite ran.',
  'Remote ref capture is a finite publication snapshot, not a claim about later concurrent advances.'
 ],
}
(OUT/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
intake_path=OUT/'publication-intake.json'
intake=json.loads(intake_path.read_text())
intake['validation']={'status':'passed','source_commit':COMMIT,'engine_tests':1725,'engine_suites':86,'editor_tests':19,'editor_suites':3,'strict_analyzed_dart_paths':11,'formatted_dart_paths':11,'source_input_count':1250,'all_input_hashes_match_commit':True,'source_edits_during_qualification':False}
intake_path.write_text(json.dumps(intake,indent=2)+'\n')
review='''# Publication refresh: incoming history and source qualification

The separate publication snapshot captures **380 refs** and is fully reconciled at **`964783488cfa8079464e7dc80c1df6bb139323f5`**, tree `47ec5e720309a1efeb3a91824ab49b5700b16b27`. **366 refs are ancestors;14 historical PR heads have independently reverified equivalents.** All captured current branch and PR work is accounted for.

This refresh preserves the original377-ref report and its source-specific qualification unchanged. It captures the already-fetched publication refs, including new PRs#333/#334 and the typography branch, without continuing to chase concurrent branch changes.

| Source | Captured | Ancestors | Historical equivalents |
|---|---:|---:|---:|
| Fork branch tips |42|42|0|
| Fork PR heads |334|320|14|
| Original upstream branches |4|4|0|
| **Total** |**380**|**366**|**14**|

The14 historical exceptions retain the original proof:13 identical whole trees, and PR#140 with all37 original changed paths identical to an accepted ancestor. The corresponding replacement commits remain ancestors of this publication source. The four upstream branch heads are unchanged.

## Newly integrated source and ancestry

| Captured head | Disposition and source delta |
|---|---|
| Main `5c59a062e86e24d043ba06cfe8f0a69074c44f62` | Explicit publication parent. Includes merged PR#334 and Word `26748a56`; its two changed Word Dart files are byte-identical to the prior qualified source, so effective additions are provenance/documentation. |
| Word `26748a56f9597d3198c7652c26eade6a97da7c2f` | Ancestor through main. PR#334 was merged2026-11-21 at18:57:33 UTC. |
| Typography branch | Its captured tip equals main `5c59a062`; no separate typography implementation exists in this capture. |
| Zotero images `58fe5b978f63af282ccd3f3406f86e431e440030` | Explicit publication parent. Uses an allocated-to-authored picture-name map for continuous-story comparison, with collision/title regression coverage. Comment picture tests now verify preserved character styling. |
| Zotero native ODT `3eac83d12180f189430e8c81bfef4bf438087c5d` | Explicit publication parent. Adds uniform native DOCX table-cell margins, bounded direct/style/default inheritance, optional ODF soft-page-break hints and valid negative-zero sequence syntax. PR#333 was open/draft when inspected; its captured head is fully included in the publication commit. |

The publication commit's first parent is prior qualified source `e9a95d7795812a8322c3a0c1d508cf05553bfe82`, followed by main and both Zotero heads. Root reconciled documentation conflicts preserving both feature records. The incoming picture-name map and styled comment-picture behavior supersede the earlier local temporary workarounds; table-alignment changes and the independent emitted-name uniqueness assertion remain.

The margin importer projects only complete uniform physical edges with admitted values. Unsupported, partial, asymmetric, foreign, duplicate and historical declarations retain opaque source rather than being guessed into a scalar. Named/default style behavior, zero margin and repeated DOCX cycles are covered. The soft-break hint permits only XML boolean syntax; authored hard breaks and citation offsets are retained.

## Fresh combined qualification

**1,725 engine cases across86 suites** and **19 editor cases across3 suites** passed, with zero failures or skips. The engine set combines all64 ODT/ODF-Zotero suites and22 affected native Word table, style, layout and package-preservation suites. Strict analysis and formatting passed all11 changed Dart files. No source or formatting repairs were needed during this qualification.

All **1,250 engine/editor Dart inputs** are identical across before/after snapshots for every final command and match the Git blobs of the publication commit. The unchanged broad VBA cohort was not repeated. These counts overlap earlier tests and must not be added to prior gates as distinct cases.

`qualification.json`, `publication-source.patch`, raw command/event logs and immutable input manifests are retained in the publication evidence archive. No GitHub Actions were queried or awaited. No external LibreOffice converter or installed Zotero/CSL session was executed here; the existing retained-fixture tests ran locally. Studio Mail source/tests are separately qualified by the runtime agent.
'''
for old,new in [('ancestors;14','ancestors; 14'),('original377','original 377'),('PRs#','PRs #'),('The14','The 14'),('proof:13','proof: 13'),('PR#','PR #'),('all37','all 37'),('merged2026','merged 2026'),('at18:','at 18:'),('across86','across 86'),('across3','across 3'),('all64','all 64'),('and22','and 22'),('all11','all 11')]:review=review.replace(old,new)
(OUT/'publication-intake.md').write_text(review)
(OUT/'README.md').write_text('''# Publication refresh evidence

Qualified source: **`964783488cfa8079464e7dc80c1df6bb139323f5`**.

- **1,725 engine tests** across86 suites (64 ODT/ODF-Zotero +22 affected Word table/style/layout/package suites).
- **19 editor tests** across3 ODT suites.
- Zero failures or skips; strict analysis and formatting pass11 changed Dart paths.
- All1,250 recorded engine/editor Dart source inputs match every final run and the qualified Git commit.
- No source or formatting edits were necessary during this qualification.

`publication-intake.json` and `publication-intake.md` account for the separate380-ref publication snapshot. The original377-ref intake and previous ODT archive remain unchanged. `qualification.json` supplies exact scope and claim boundaries. `publication-source.patch` records the complete source delta from prior qualified checkpointe9a95d77. `final/` contains exact commands, raw JSON event/stdout/stderr, result summaries, and before/after SHA-256 source manifests. `open-pr-metadata.json` retains the observed draft PR#333 snapshot.

The runtime is pinned Flutter3.47.8/Dart3.13.7 with the previously prepared locked package configuration. No GitHub Actions were queried or awaited, and no external LibreOffice converter or installed Zotero plugin was run by this task. The new gate overlaps prior qualification; counts are not additive across earlier runs.
'''.replace('across86','across 86').replace('+22','+ 22').replace('across3','across 3').replace('pass11','pass 11').replace('All1,250','All 1,250').replace('separate380','separate 380').replace('original377','original 377').replace('checkpointe9','checkpoint e9').replace('PR#','PR #').replace('Flutter3','Flutter 3').replace('/Dart3','/Dart 3'))
shutil.copy2(OUT/'publication-intake.json','/workspace/scratch/faef92d47725/publication-intake.json')
shutil.copy2(OUT/'publication-intake.md','/workspace/scratch/faef92d47725/publication-intake.md')
archive=OUT/'publication-refresh-evidence.tar.xz'
index_path=OUT/'evidence-index.json'
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p not in [archive,index_path])
index={'archive':archive.name,'files':{str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}}
index_path.write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(archive,'w:xz') as tar:
 for p in files+[index_path]:tar.add(p,arcname=str(p.relative_to(OUT)))
with tarfile.open(archive) as tar:
 for member in tar.getmembers():
  data=tar.extractfile(member).read()
  if member.name!='evidence-index.json':assert hashlib.sha256(data).hexdigest()==index['files'][member.name]['sha256'],member.name
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files)+1,'engine_passes':1725,'editor_passes':19,'source_inputs':len(source)},indent=2))
