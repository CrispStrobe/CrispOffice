import collections
import datetime
import json
import pathlib
import subprocess

ROOT=pathlib.Path('/workspace/scratch/faef92d47725/quds_office_suite')
OUT=pathlib.Path('/workspace/scratch/faef92d47725/runtime/publication-refresh')
TARGET='964783488cfa8079464e7dc80c1df6bb139323f5'
PREVIOUS=pathlib.Path('/workspace/scratch/faef92d47725/final-intake.json')
old=json.loads(PREVIOUS.read_text())
previous={r['ref']:r for r in old['refs']}
proofs=old['historical_equivalence_proofs']
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def ancestor(sha):return subprocess.run(['git','merge-base','--is-ancestor',sha,TARGET],cwd=ROOT).returncode==0
for sha,proof in proofs.items():
 assert ancestor(proof['replacement']),sha
 if proof['kind']=='full_tree':assert git('rev-parse',sha+'^{tree}')==git('rev-parse',proof['replacement']+'^{tree}'),sha
 else:
  for p in proof['changed_paths']:assert git('ls-tree',sha,'--',p)==git('ls-tree',proof['replacement'],'--',p),p
rows=[];advanced=[];summary=collections.defaultdict(collections.Counter)
for line in git('for-each-ref','--format=%(refname) %(objectname)','refs/remotes/origin','refs/remotes/intake-pr','refs/remotes/intake-upstream').splitlines():
 ref,sha=line.split()
 if ref=='refs/remotes/origin/HEAD':continue
 category='fork_branches' if ref.startswith('refs/remotes/origin/') else 'fork_pr_heads' if ref.startswith('refs/remotes/intake-pr/') else 'upstream_branches'
 disposition='ancestor' if ancestor(sha) else 'verified_historical_equivalent' if sha in proofs else 'unintegrated'
 row={'ref':ref,'sha':sha,'category':category,'disposition':disposition}
 rows.append(row);summary[category][disposition]+=1
 if ref not in previous or previous[ref]['sha']!=sha:advanced.append({**row,'previous_sha':previous.get(ref,{}).get('sha')})
heads={
 'main':('4970f71f983535d045ce263e86835b499db4fda9','5c59a062e86e24d043ba06cfe8f0a69074c44f62'),
 'word':('37afb04e1167fe306e4d124368a08e372638f4ab','26748a56f9597d3198c7652c26eade6a97da7c2f'),
 'zotero_bibliography':('bf54a8e7d976670af87dd3d36f3afc26c1821d3b','3eac83d12180f189430e8c81bfef4bf438087c5d'),
 'zotero_images':('81e478ca0ffe249a908362cd233790b8920d439c','58fe5b978f63af282ccd3f3406f86e431e440030')}
changes={name:{'previous_head':before,'head':after,'is_ancestor':ancestor(after),'changed_paths_since_previous_capture':git('diff','--name-only',before,after).splitlines(),'new_commits_relative_to_qualified_source':git('log','--format=%H %s','e9a95d7795812a8322c3a0c1d508cf05553bfe82..'+after).splitlines()} for name,(before,after) in heads.items()}
doc={
 'schema':'quds-mail-publication-intake/v1','captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'repository':'CrispStrobe/quds_office_suite','upstream':'MohammedAsaadAsaad/quds_office_suite',
 'previous_snapshot':'Prior377-ref snapshot and qualification remain separately preserved; this is a publication refresh.',
 'target_commit':TARGET,'target_tree':git('rev-parse',TARGET+'^{tree}'),'target_parents':git('show','-s','--format=%P',TARGET).split(),
 'previous_qualified_source':'e9a95d7795812a8322c3a0c1d508cf05553bfe82','captured_ref_count':len(rows),
 'summary':{k:dict(v) for k,v in summary.items()},'refs':rows,'new_or_advanced_refs':advanced,'incoming_changes':changes,
 'historical_equivalence_proofs':proofs,'upstream_heads_unchanged':True,
 'pr_metadata':[{'number':333,'state':'open','draft':True,'head':'3eac83d12180f189430e8c81bfef4bf438087c5d','source':'Connector search_prs; raw open-pr-metadata.json retained.'},{'number':334,'state':'closed','merged':True,'head':'26748a56f9597d3198c7652c26eade6a97da7c2f','merged_at':'2026-11-21T18:57:33Z','source':'Connector search_prs updated6 results.'}],
 'new_typography_branch':'codex/word-vba-typography-20261121 equals captured main5c59a062; no additional typography source.',
 'main_effective_dart_delta':'The2 Word Dart files changed by26748a56 are byte-identical to prior qualified sourcee9a95d77; incoming main adds provenance/docs only relative to current Word source.',
 'image_integration':'Adopted incoming generated-to-original name map for story comparison and styled non-link comment pictures, replacing temporary broad-name normalization/comment shape correction. Retained table alignment and emitted-name uniqueness assertion.',
 'new_native_changes':'Bounded uniform DOCX table-cell margins with sparse-source/style inheritance; optional ODF soft-page-break boolean hint; negative zero declaration syntax; native roundtrip acceptance runner.',
 'validation':'86 engine suites (64ODT+22affected Word table/style/layout/package),3editor suites,11changed Dart paths under qualification. Final result recorded separately.',
 'github_actions':'Neither queried nor awaited',
 'capture_policy':'Finite refreshed snapshot; no remote source head was moved or rewritten by this audit.'
}
assert len(rows)==380
assert sum(r['disposition']=='ancestor' for r in rows)==366
assert sum(r['disposition']=='verified_historical_equivalent' for r in rows)==14
(OUT/'publication-intake.json').write_text(json.dumps(doc,indent=2)+'\n')
print(json.dumps({k:doc[k] for k in ['target_commit','target_tree','captured_ref_count','summary']},indent=2))
