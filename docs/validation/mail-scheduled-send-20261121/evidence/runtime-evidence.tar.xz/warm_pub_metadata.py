"""Fetch official pub.dev package metadata for the two unchanged lockfiles."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import json
from pathlib import Path
import subprocess
import tempfile
import yaml

base = Path('/workspace/scratch/faef92d47725')
cache = base / 'runtime/pub-cache/hosted/pub.dev/.cache'
cache.mkdir(parents=True, exist_ok=True)
names = set()
for lock in [base / 'quds_office_suite/pubspec.lock', base / 'runtime/flutter/packages/flutter_tools/pubspec.lock']:
    entries = yaml.safe_load(lock.read_text())['packages']
    names.update(name for name, item in entries.items() if item['source'] == 'hosted')

def fetch(name):
    target = cache / (name + '-versions.json')
    if target.exists():
        return name, 'already fetched'
    completed = subprocess.run(['curl', '--silent', '--show-error', '--fail', '--location', '--max-time', '45', 'https://pub.dev/api/packages/' + name], capture_output=True, check=True)
    data = json.loads(completed.stdout)
    if data.get('name') != name:
        raise ValueError('Mismatched official package metadata: ' + name)
    data['_fetchedAt'] = datetime.now().isoformat()
    with tempfile.NamedTemporaryFile('w', dir=cache, delete=False) as out:
        json.dump(data, out)
        temporary = Path(out.name)
    if target.exists():
        temporary.unlink()
    else:
        temporary.replace(target)
    return name, 'fetched official metadata'

with ThreadPoolExecutor(max_workers=10) as pool:
    tasks = {pool.submit(fetch, name): name for name in names}
    for task in as_completed(tasks):
        try:
            print(*task.result(), flush=True)
        except Exception as error:
            print(tasks[task], type(error).__name__, str(error), flush=True)
