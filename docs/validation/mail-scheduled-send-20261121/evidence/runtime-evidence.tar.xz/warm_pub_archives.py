"""Warm a pub cache from official archives, checking unchanged lock hashes."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile
import yaml

base = Path('/workspace/scratch/faef92d47725')
runtime = base / 'runtime'
cache = runtime / 'pub-cache/hosted/pub.dev'
hashes = runtime / 'pub-cache/hosted-hashes/pub.dev'
hashes.mkdir(parents=True, exist_ok=True)
specs = {}
for lock in [base / 'quds_office_suite/pubspec.lock', runtime / 'flutter/packages/flutter_tools/pubspec.lock']:
    for name, item in yaml.safe_load(lock.read_text())['packages'].items():
        if item['source'] == 'hosted':
            description = item['description']
            assert description['url'] == 'https://pub.dev'
            specs[(name, item['version'])] = description['sha256']

def fetch(key, digest):
    name, version = key
    target = cache / f'{name}-{version}'
    if target.is_dir():
        return dict(name=name, version=version, status='already installed', expected_sha256=digest)
    temporary = Path(tempfile.mkdtemp(prefix='pub-warm-',dir=runtime/'tmp'))
    try:
        archive = temporary / 'package.tar.gz'
        subprocess.run(['curl','--silent','--show-error','--fail','--location','--retry','2','--max-time','90','--output',str(archive),f'https://pub.dev/api/archives/{name}-{version}.tar.gz'],capture_output=True,check=True)
        actual = hashlib.sha256(archive.read_bytes()).hexdigest()
        if actual != digest:
            raise ValueError(f'Archive hash mismatch: {name}-{version}')
        contents = temporary / 'contents'
        contents.mkdir()
        with tarfile.open(archive) as tar:
            tar.extractall(contents, filter='data')
        if not target.exists():
            contents.replace(target)
        (hashes / f'{name}-{version}.sha256').write_text(digest)
        return dict(name=name,version=version,status='verified and cached',archive_sha256=actual)
    finally:
        shutil.rmtree(temporary)

results=[]
with ThreadPoolExecutor(max_workers=10) as pool:
    tasks={pool.submit(fetch,key,digest):key for key,digest in specs.items()}
    for task in as_completed(tasks):
        key=tasks[task]
        try:
            result=task.result()
        except Exception as error:
            result=dict(name=key[0],version=key[1],status='error',error=str(error))
        results.append(result)
        print(result['name'],result['version'],result['status'],flush=True)
(runtime/'archive-verification.json').write_text(json.dumps(sorted(results,key=lambda item:(item['name'],item['version'])),indent=2)+'\n')
raise SystemExit(any(item['status']=='error' for item in results))
