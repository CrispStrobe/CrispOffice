"""Independently validate raw Flutter JSON events after the process-level run."""
import hashlib
import json
from pathlib import Path
import sys

OUTPUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/faef92d47725/quds_office_suite')
sys.path.insert(0, str(ROOT / 'tools/mail'))
from check_store import test_summary

receipt_path = OUTPUT / 'receipt.json'
receipt = json.loads(receipt_path.read_text())
check = next(item for item in receipt['checks'] if item['name'] == 'studio-combined')
raw = OUTPUT / check['stdout']
summary = test_summary(raw)
(OUTPUT / 'studio-combined-cases.json').write_text(json.dumps(summary, indent=2) + '\n')
suites = {}
test_suites = {}
counts = {}
for line in raw.read_text().split('\n'):
    if not line.strip():
        continue
    event = json.loads(line)
    if event.get('type') == 'suite':
        suite = event['suite']
        suites[suite['id']] = suite['path']
    elif event.get('type') == 'testStart':
        case = event['test']
        test_suites[case['id']] = case['suiteID']
    elif event.get('type') == 'testDone' and not event.get('hidden', False):
        path = suites[test_suites[event['testID']]]
        counts[path] = counts.get(path, 0) + (event['result'] == 'success' and not event['skipped'])
expected = {str(ROOT / 'packages/quds_office_editor/example/test' / name) for name in receipt['scope']['tests']}
suite_match = set(suites.values()) == expected
check['tests'] = {key: value for key, value in summary.items() if key != 'cases'}
receipt['test_event_audit'] = {
    'command': ['python3', str(Path(__file__).resolve())],
    'audit_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'raw_event_file': check['stdout'],
    'raw_sha256_matches_original_receipt': hashlib.sha256(raw.read_bytes()).hexdigest() == check['stdout_sha256'],
    'selected_suites_match': suite_match,
    'suite_count': len(suites),
    'passed_by_suite': counts,
    'note': 'The driver recorded strict protocol and 143-case validation. This separate audit checks the exact thirteen suite identities against the same unmodified raw JSON stream without another execution.',
}
ok = (summary['valid'] and suite_match and receipt['test_event_audit']['raw_sha256_matches_original_receipt'] and receipt['status'] == 'PASS')
receipt['test_event_audit']['status'] = 'PASS' if ok else 'FAIL'
if not ok:
    receipt['status'] = 'FAIL'
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status':receipt['status'],'tests':check['tests'],'suite_count':len(suites),'passed_by_suite':counts},indent=2))
raise SystemExit(0 if ok else 1)
