"""Run one unchanged consumer gate with frozen-source guard and outer timeout."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

parser=argparse.ArgumentParser()
parser.add_argument('--gate',choices=['retained33','current7','boundary5','frame5'],required=True)
parser.add_argument('--commit',required=True)
parser.add_argument('--workspace',type=Path,required=True)
parser.add_argument('--timeout',type=int,default=1200)
args=parser.parse_args()
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'quds_office_suite'
WORK=args.workspace.resolve()
DART=ROOT.parent/'toolchains/flutter-sdk/bin/cache/dart-sdk/bin/dart'
REF=ROOT/'consumer-runtime/retained-reference'
RUN=ROOT/(args.gate+'-'+args.commit[:8])
RUN.mkdir(exist_ok=False)
OUT=RUN/'result'
GUARD=RUN/'guard'
PY=Path(sys.executable)
common=['--output',OUT,'--schemas',REF/'schemas','--dart',DART,'--repo',WORK,'--source-repo',REPO,'--expected-head',args.commit]
if args.gate=='retained33':
    child=[PY,REF/'wave3-runner/verify_consumers.py',*common]
elif args.gate=='current7':
    child=[PY,REF/'verify_current_consumers.py',*common]
elif args.gate=='boundary5':
    child=[PY,REPO/'docs/validation/office-reconciled-20261117/resume/consumer-new/verify_boundary_consumers.py','--repo',REPO,'--workspace',WORK,'--dart',DART,'--schemas',REF/'schemas','--output',OUT,'--commit',args.commit]
else:
    child=[PY,ROOT/'frame-consumers/harness/run_consumers.py','--repo',REPO,'--package-config',WORK/'.dart_tool/package_config.json','--jing',REF/'tools/jing-20241231.jar','--schemas',REF/'schemas','--output',OUT]
guard=[PY,REPO/'docs/validation/office-union-20261117/setup/guard_frozen_run.py','--repo',REPO,'--workspace',WORK,'--dart',DART,'--consumer-root',REF,'--commit',args.commit,'--output',GUARD]
if args.gate=='frame5':
    for name in ['make_fixtures.dart','run_consumers.py']:
        guard.extend(['--extra-input',ROOT/'frame-consumers/harness'/name])
command=list(map(str,[*guard,'--',*child]))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',CI='true',DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true',TMPDIR=str(WORK/'tmp'),XDG_CONFIG_HOME=str(WORK/'config'))
env['PATH']=str(DART.parent)+os.pathsep+env.get('PATH','')
receipt={'gate':args.gate,'source_commit':args.commit,'argv':command,'started_utc':datetime.now(timezone.utc).isoformat(),'timeout_seconds':args.timeout,'passed':False}
(RUN/'orchestration.json').write_text(json.dumps(receipt,indent=2)+'\n')
with (RUN/'guard.stdout.log').open('wb') as stdout,(RUN/'guard.stderr.log').open('wb') as stderr:
    proc=subprocess.Popen(command,cwd=REPO,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
    try:
        receipt['exit_code']=proc.wait(timeout=args.timeout)
    except subprocess.TimeoutExpired:
        receipt['timeout']=True
        os.killpg(proc.pid,signal.SIGTERM)
        try:proc.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
        receipt['exit_code']=proc.returncode
receipt['finished_utc']=datetime.now(timezone.utc).isoformat()
receipt['passed']=receipt['exit_code']==0 and json.loads((GUARD/'receipt.json').read_text())['passed']
(RUN/'orchestration.json').write_text(json.dumps(receipt,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('package_evidence',REPO/'docs/validation/office-reconciled-20261117/resume/package_checkpoint.py')
pack=importlib.util.module_from_spec(spec);spec.loader.exec_module(pack)
files={str(p.relative_to(RUN)):p for p in RUN.rglob('*') if p.is_file() and not p.is_symlink() and not any(part.startswith('profile') for part in p.relative_to(RUN).parts) and '__pycache__' not in p.parts}
files['run_guarded_consumer.py']=Path(__file__).resolve()
pack.pack(RUN.with_suffix('.tar.xz'),files,('Passed ' if receipt['passed'] else 'Failed/incomplete ')+args.gate+' consumer gate on frozen '+args.commit)
print(json.dumps({'gate':args.gate,'passed':receipt['passed'],'source_commit':args.commit,'output':str(RUN),'archive':str(RUN.with_suffix('.tar.xz'))}),flush=True)
raise SystemExit(0 if receipt['passed'] else 1)
