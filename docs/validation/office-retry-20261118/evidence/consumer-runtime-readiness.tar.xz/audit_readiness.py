#!/usr/bin/env python3
"""Audit restored consumers without running a product qualification gate."""
import ast
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
TASK = ROOT.parent.parent
REPO = TASK / 'quds_office_suite'
REF = ROOT / 'retained-reference'
OUT = ROOT / 'readiness-audit'

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def main():
    OUT.mkdir(exist_ok=False)
    archived = REPO / 'docs/validation/office-reconciled-20261117/recovered/consumer-intermediate-1d8325d4.tar.index.json'
    index = json.loads(archived.read_text())
    members = [dict(path=r['path'], expected=r['sha256'], actual=digest(REF / r['path'])) for r in index['members']]
    assert len(members) == 710 and all(r['expected'] == r['actual'] for r in members)
    old = json.loads(gzip.decompress((REF / 'qualification-1d8325d4-current7/inputs.json.gz').read_bytes()))['runtime']
    immutable_paths = {p: h for p,h in old.items() if p.startswith(('/opt/codex/runtimes/codex-primary-runtime/', '/usr/share/fonts/', '/usr/share/texmf/fonts/', '/usr/lib/jvm/')) or p in ('/usr/bin/pdftotext', '/usr/bin/fc-list')}
    comparison = []
    for path, expected in immutable_paths.items():
        file = Path(path)
        actual = digest(file) if file.is_file() else None
        comparison.append(dict(path=path, expected=expected, actual=actual, matches=actual==expected))
    assert all(r['matches'] for r in comparison), [r for r in comparison if not r['matches']]
    previous_font_files = {p:h for p,h in old.items() if p.startswith(('/usr/share/fonts/', '/usr/share/texmf/fonts/'))}
    current_font_files = sorted(set(subprocess.check_output(['fc-list', '--format=%{file}\n'], text=True).splitlines()))
    fonts = {'retained_file_count': len(previous_font_files), 'registered_file_count': len(current_font_files),
             'all_retained_fonts_present_and_byte_identical': all(Path(p).is_file() and digest(p)==h for p,h in previous_font_files.items()),
             'extra_registered_font_paths': sorted(set(current_font_files)-set(previous_font_files)),
             'missing_registered_font_paths': sorted(set(previous_font_files)-set(current_font_files)),
             'selected_families': {family:subprocess.check_output(['fc-match','--format=%{family}\t%{file}\n',family],text=True).strip() for family in ('Arial','Times New Roman','Calibri','Liberation Sans','Liberation Serif','DejaVu Sans')}}
    assert fonts['all_retained_fonts_present_and_byte_identical'] and not fonts['missing_registered_font_paths']
    harness = ROOT.parent / 'frame-consumers/harness'
    origin = json.loads((harness/'origin.json').read_text())
    harness_matches = {name: digest(harness/name)==expected for name,expected in origin['unchanged_extracted_members'].items()}
    assert all(harness_matches.values())
    scripts = [REF/'wave3-runner/verify_consumers.py',REF/'verify_current_consumers.py',
               REPO/'docs/validation/office-reconciled-20261117/resume/consumer-new/verify_boundary_consumers.py',
               harness/'run_consumers.py', ROOT.parent/'run_guarded_consumer.py',
               REPO/'docs/validation/office-union-20261117/setup/guard_frozen_run.py']
    for p in scripts:
        ast.parse(p.read_text(),filename=str(p))
    controls=[]
    for name,expected in [('unchanged-styled-page-count',True),('linked-styled-page-count',True),('invalid-field-child-span',False),('invalid-field-attribute',False)]:
        source=REF/'schema-controls'/(name+'.xml')
        command=['java','-jar',str(REF/'tools/jing-20241231.jar'),'-i',str(REF/'schemas/OpenDocument-v1.3-schema.rng'),str(source)]
        result=subprocess.run(command,capture_output=True,timeout=30)
        (OUT/(name+'.stdout')).write_bytes(result.stdout)
        (OUT/(name+'.stderr')).write_bytes(result.stderr)
        controls.append({'name':name,'expected_valid':expected,'actual_valid':result.returncode==0,'exit_code':result.returncode,'input_sha256':digest(source),'command':command})
        assert (result.returncode==0)==expected
    import fitz, PIL
    from lxml import etree
    dart=TASK/'toolchains/flutter-sdk/bin/cache/dart-sdk/bin/dart'
    receipt={'kind':'consumer-runtime-readiness-audit','completed_utc':datetime.now(timezone.utc).isoformat(),
             'product_qualification_executed':False,'product_qualification_accepted':False,
             'restored_members':len(members),'restored_members_match_archive':True,
             'immutable_runtime_file_count':len(comparison),'immutable_runtime_all_match':True,
             'font_inventory':fonts,'frame_harness_matches_origin':harness_matches,
             'syntax_checked_scripts':{str(p):digest(p) for p in scripts},'jing_control_count':len(controls),'jing_controls':controls,
             'python_versions':{'pymupdf':fitz.version,'Pillow':PIL.__version__,'lxml':list(etree.LXML_VERSION),'libxml2':list(etree.LIBXML_VERSION)},
             'dart_requested_path':str(dart),'dart_resolved_path':str(dart.resolve()),'dart_present':dart.is_file(),
             'gates_ready_after_workspace_frozen':['retained33','current7','boundary5','frame5'],
             'consumer_environment_file':str(ROOT/'env.sh'),
             'no_harness_or_source_modifications':True,
             'font_note':'The current registered font path set exactly matches the retained current7 input map, including OpenAI Sans. All 557 retained font files remain byte-identical. Fresh qualification will seal the actual full font set before and after each gate.'}
    (OUT/'retained-runtime-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
    (OUT/'restored-member-comparison.json').write_text(json.dumps(members,indent=2)+'\n')
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'restored_members':len(members),'runtime_files':len(comparison),'retained_fonts':len(previous_font_files),'extra_fonts':len(fonts['extra_registered_font_paths']),'jing_controls':len(controls),'dart_present':dart.is_file(),'product_qualification_executed':False}))

if __name__=='__main__': main()
