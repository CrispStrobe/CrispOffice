export OFFICE_CONSUMER_ROOT=/workspace/scratch/eddfdfc8cc56/native-consumers/consumer-runtime
export OFFICE_CONSUMER_REFERENCE=/workspace/scratch/eddfdfc8cc56/native-consumers/consumer-runtime/retained-reference
export ODF_SCHEMAS=/workspace/scratch/eddfdfc8cc56/native-consumers/consumer-runtime/retained-reference/schemas
export JING_JAR=/workspace/scratch/eddfdfc8cc56/native-consumers/consumer-runtime/retained-reference/tools/jing-20241231.jar
export OFFICE_PYTHON=/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3
export TMPDIR=/workspace/scratch/eddfdfc8cc56/native-consumers/consumer-runtime/tmp
export XDG_CONFIG_HOME=/workspace/scratch/eddfdfc8cc56/native-consumers/consumer-runtime/config
