import 'dart:convert';
void main() { print(jsonEncode([for (final month in [1, 7, 11]) {'month':month, 'iso':DateTime(2026, month, 17, 0, 30).toIso8601String(), 'zone':DateTime(2026, month, 17, 0, 30).timeZoneName, 'offsetMinutes':DateTime(2026, month, 17, 0, 30).timeZoneOffset.inMinutes}])); }
