from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import urllib.request

ROOT = Path(__file__).resolve().parent
OLD = ROOT / 'historical/native-runtime-recovery/model-and-python'
OUT = ROOT / 'native-qualification-runtime'
OUT.mkdir(exist_ok=True)
BUNDLE = OUT / 'proofbird'
BUNDLE.mkdir(exist_ok=True)
MANIFEST = json.loads((OLD/'model-download-verification.json').read_text())

def sha(path):
    with path.open('rb') as h: return hashlib.file_digest(h, 'sha256').hexdigest()

def download(row):
    dest = BUNDLE/row['file']
    if dest.exists():
        assert dest.stat().st_size == row['size'] and sha(dest) == row['sha256']
        return row
    partial = dest.with_name(dest.name + '.partial')
    with urllib.request.urlopen(row['url'], timeout=90) as response, partial.open('xb') as target:
        while block := response.read(2**20): target.write(block)
    assert partial.stat().st_size == row['size'] and sha(partial) == row['sha256'], row
    partial.rename(dest)
    print('MODEL FILE VERIFIED', row['file'], row['size'], flush=True)
    return row

def setup_python():
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PIP_DISABLE_PIP_VERSION_CHECK='1')
    venv = OUT/'venv'
    with (OUT/'python-install.log').open('w') as log:
        subprocess.run([sys.executable, '-m', 'venv', str(venv)], stdout=log, stderr=subprocess.STDOUT, env=env, check=True, timeout=120)
        subprocess.run([str(venv/'bin/python'), '-m', 'pip', 'install', '--no-cache-dir', '--only-binary=:all:', '-r', str(OLD/'python-freeze.txt')], stdout=log, stderr=subprocess.STDOUT, env=env, check=True, timeout=600)
    freeze = subprocess.check_output([str(venv/'bin/python'), '-m', 'pip', 'freeze'], env=env).decode()
    (OUT/'python-freeze.txt').write_text(freeze)
    assert freeze == (OLD/'python-freeze.txt').read_text()
    print('PYTHON VERIFIED 27 PACKAGES', flush=True)

with ThreadPoolExecutor(max_workers=5) as pool:
    py = pool.submit(setup_python)
    jobs = [pool.submit(download, row) for row in MANIFEST['manifest']]
    rows = [job.result() for job in jobs]
    py.result()
(OUT/'model-download-verification.json').write_text(json.dumps(dict(MANIFEST, manifest=rows), indent=2)+'\n')
(OUT/'download-python-ready.json').write_text(json.dumps({'completed_utc':datetime.now(timezone.utc).isoformat(), 'passed':True, 'python_frozen_packages':27, 'model_files':len(rows)},indent=2)+'\n')
print('DOWNLOAD AND PYTHON READY',flush=True)
