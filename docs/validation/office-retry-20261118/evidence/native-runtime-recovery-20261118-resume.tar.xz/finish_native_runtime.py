from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'quds_office_suite'
OUT=ROOT/'native-qualification-runtime'
BUILD=ROOT/'native-binary-recovery'
PY=OUT/'venv/bin/python'
commands=[]
env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1')

def sha(path):
    with path.open('rb') as h: return hashlib.file_digest(h,'sha256').hexdigest()

def run(label, argv):
    print('START',label,flush=True)
    row={'label':label,'argv':list(map(str,argv)),'started_utc':datetime.now(timezone.utc).isoformat()}
    commands.append(row)
    (OUT/'finish-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    with (OUT/(label+'.log')).open('wb') as log:
        result=subprocess.run(row['argv'],stdout=log,stderr=subprocess.STDOUT,env=env,timeout=300)
    row.update(exit_code=result.returncode,log_sha256=sha(OUT/(label+'.log')))
    (OUT/'finish-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    assert result.returncode==0, label

assert json.loads((BUILD/'recovery.json').read_text())['passed']
assert json.loads((OUT/'download-python-ready.json').read_text())['passed']
f32=OUT/'gector-de-f32.gguf'
mixed=OUT/'gector-de-mixed-q4_k.gguf'
run('convert-f32',[PY,BUILD/'CrispEmbed/models/convert-gector-onnx-to-gguf.py','--bundle',OUT/'proofbird','--output',f32])
assert sha(f32)=='497657528f3a660b85b807a7da0db663abb5964ada81f819e26ed48b6e96b6c1'
argv=[BUILD/'build/crispembed-gector-quantize',f32,mixed,'q4_k','--standard-file-type']
for rule in ['*=f32','enc.*.attn.*.weight=q4_k','enc.*.ffn.*.weight=q4_k','token_embd.weight=q8_0','position_embd.weight=f16','gector.*.weight=f16']:
    argv.extend(['--tensor-type',rule])
argv.extend(['--metadata-string','gector.precision=mixed-q4_k'])
run('quantize',argv)
assert sha(mixed)=='549ee3a5272726d48608cebdb435aaea6a984f3f53508b20b3194a7175a5ef5b'
for path in [OUT/'proofbird/model.onnx',f32]:
    print('RELEASING REPRODUCIBLE INPUT',path.name,flush=True)
    path.unlink()
run('pack-build',[PY,REPO/'tools/proofing/german_model/build_native_pack.py','build','--model',mixed,'--bundle',OUT/'proofbird','--native-install',BUILD/'install','--output',OUT/'native-development-pack'])
pack=json.loads((OUT/'pack-build.log').read_text())
assert pack['verified'] and pack['manifest_sha256']=='70187da9248c829ab511f566ba4db9093a0ec5a9c922ad4438d63db372880841'
mixed.unlink()
reference=OUT/'reference-f32.json'
reference.write_bytes(gzip.decompress((REPO/'docs/validation/german-gector/2026-11-17-native/reference-f32.json.gz').read_bytes()))
assert sha(reference)=='9d33a0be66e68284277bd3d9e0e0fe404936cf804e2e715a8999b7ece14155d8'
settings={'GECTOR_TEST_LIBRARY':pack['library'],'GECTOR_TEST_LIBRARY_SHA256':pack['library_sha256'],'GECTOR_TEST_MODEL':str(Path(pack['model_directory'])/pack['model']['file']),'GECTOR_TEST_MODEL_SHA256':pack['model']['sha256'],'CRISPEMBED_GECTOR':'1','QUALIFICATION_PYTHON':str(PY)}
(OUT/'native-env.sh').write_text('\n'.join(f'export {key}={shlex.quote(value)}' for key,value in settings.items())+'\n')
(OUT/'ready.json').write_text(json.dumps({'passed':True,'completed_utc':datetime.now(timezone.utc).isoformat(),'pack':pack,'reference_sha256':sha(reference),'source_revision':'853a1ce6089e5d5486e37307f37051ad6a928745','python_frozen_packages':27,'large_conversion_inputs_released_after_hash_verification':True,'scope':'Exact pinned native runtime recovery; current-source qualification not yet claimed.'},indent=2)+'\n')
print('NATIVE READY',flush=True)
