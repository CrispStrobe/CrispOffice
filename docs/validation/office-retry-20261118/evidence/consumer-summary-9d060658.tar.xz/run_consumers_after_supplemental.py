#!/usr/bin/env python3
"""Run unchanged guarded consumers after supplemental Dart gates have finished."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
TASK = ROOT.parent
SOURCE = '9d060658ee6be8ec97d73f56b9aec10d346b7952'
WORK = TASK/'flutter-qualification/workspace'
RUNS = TASK/'flutter-qualification/runs'
RECEIPT = ROOT/'consumer-sequence-9d060658.json'

def now(): return datetime.now(timezone.utc).isoformat()
def write(data): RECEIPT.write_text(json.dumps(data,indent=2)+'\n')

def main():
    assert not RECEIPT.exists(), 'Do not overwrite sequence evidence'
    receipt={'kind':'sequential-consumer-orchestration','source_commit':SOURCE,'started_utc':now(),'gates':[],'passed':False,'waiting_for_supplemental':True}
    write(receipt)
    deadline=time.monotonic()+1800
    while True:
        dependencies={}
        for gate in ('portable','editor-example','calendar-timezones'):
            path=RUNS/(gate+'-'+SOURCE[:8])/'orchestration.json'
            if path.is_file():
                try: value=json.loads(path.read_text())
                except json.JSONDecodeError: continue
                if value.get('finished_utc') and not value.get('passed'):
                    raise RuntimeError('Supplemental gate failed: '+gate)
                if value.get('passed'):
                    assert value.get('source_commit')==SOURCE
                    dependencies[gate]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'passed':True}
        if len(dependencies)==3: break
        assert time.monotonic()<deadline,'Timed out waiting for supplemental marker'
        time.sleep(5)
    receipt.update(waiting_for_supplemental=False,supplemental_dependencies=dependencies,consumers_started_utc=now())
    write(receipt)
    print(json.dumps({'event':'supplemental_gates_all_passed','at':now()}),flush=True)
    env=os.environ.copy()
    for line in (ROOT/'consumer-runtime/env.sh').read_text().splitlines():
        if not line.startswith('export '): continue
        key,value=line[7:].split('=',1)
        env[key]=shlex.split(value)[0]
    env.update(FLUTTER_ROOT=str((TASK/'toolchains/flutter').resolve()),PUB_CACHE=str((TASK/'toolchains/pub-cache').resolve()),PYTHONDONTWRITEBYTECODE='1')
    for gate in ('retained33','current7','boundary5','frame5'):
        command=[sys.executable,str(ROOT/'run_guarded_consumer.py'),'--gate',gate,'--commit',SOURCE,'--workspace',str(WORK),'--timeout','1200']
        item={'gate':gate,'started_utc':now(),'command':command,'passed':False}
        receipt['gates'].append(item); write(receipt)
        print(json.dumps({'event':'consumer_started','gate':gate,'at':now()}),flush=True)
        with (ROOT/(gate+'-'+SOURCE[:8]+'.driver.log')).open('xb') as log:
            result=subprocess.run(command,cwd=TASK/'quds_office_suite',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1250)
        item.update(finished_utc=now(),exit_code=result.returncode)
        archive=ROOT/(gate+'-'+SOURCE[:8]+'.tar.xz')
        index=archive.with_suffix('.index.json')
        if index.is_file():
            idx=json.loads(index.read_text())
            item.update(archive=str(archive),index=str(index),bytes=idx['bytes'],sha256=idx['sha256'],member_count=idx['member_count'],archive_readback_verified=idx['all_members_read_back_and_verified'])
        orchestration=ROOT/(gate+'-'+SOURCE[:8])/'orchestration.json'
        if orchestration.is_file(): item['passed']=result.returncode==0 and json.loads(orchestration.read_text())['passed']
        write(receipt)
        print(json.dumps({'event':'consumer_finished',**item}),flush=True)
        if not item['passed']:
            receipt.update(finished_utc=now(),stopped_on_failure=gate)
            write(receipt)
            return 1
    receipt.update(passed=True,finished_utc=now())
    write(receipt)
    print(json.dumps({'event':'all_consumers_passed','receipt':str(RECEIPT),'at':now()}),flush=True)
    return 0

if __name__=='__main__':
    raise SystemExit(main())
