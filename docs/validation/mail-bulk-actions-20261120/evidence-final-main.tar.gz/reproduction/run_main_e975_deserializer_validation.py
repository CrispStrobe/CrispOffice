import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


records = Path(__file__).resolve().parent
repo = records.parent.parent / 'quds_office_suite'
package = repo / 'packages/quds_office_engine'
dart = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/dart-sdk/bin/dart'
tests = [
    'test/word_table_style_precedence_test.dart',
    'test/word_styles_layout_test.dart',
    'test/table_border_fidelity_test.dart',
    'test/word_paragraph_style_identity_test.dart',
    'test/word_style_introduction_test.dart',
]
inputs = [
    *sorted((package / 'lib').rglob('*.dart')),
    *(package / path for path in tests),
    package / 'pubspec.yaml',
    repo / 'pubspec.yaml',
    repo / 'pubspec.lock',
    repo / '.dart_tool/package_config.json',
]


def hashes():
    return {
        str(path.relative_to(repo)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in inputs
    }


commands = [
    ('format', [str(dart), 'format', '--output=none', '--set-exit-if-changed',
                'lib/src/word/serial/word_deserializer.dart', tests[0]]),
    ('analyze', [str(dart), 'analyze', '--fatal-infos',
                 'lib/src/word/serial/word_deserializer.dart', tests[0]]),
    ('tests-vm', [str(dart), '--packages=' + str(repo / '.dart_tool/package_config.json'),
                  str(Path(os.environ['PUB_CACHE']) / 'hosted/pub.dev/test-1.31.1/bin/test.dart'),
                  '--reporter', 'expanded', '--concurrency=1', *tests]),
]
receipt = {
    'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'source_before': hashes(),
    'commands': [],
    'scope': 'e975 table-style precedence correction: focused regressions plus existing style/border coverage',
    'diagnostic_interpretation': {
        'main-e975-deserializer-before.log': '21 cases: 12 passed, 9 failed. Failures reproduce direct color/bold overwrites (three false spellings), child false overridden by parent, outer header formatting leaking into a nested table, and four automatic/omitted-color direct-width overwrites.',
        'main-e975-deserializer-spacing-before.log': 'One case failed: the compact fallback was exported as direct spacing, because importedValues still represented the preceding cascade.',
        'corrected_suspicion': 'Inherited spacing precedence was initially suspected but the document-default, table-style, paragraph-style, and direct-zero cases all passed before the fix. The existing fallback remains; only its imported snapshot ownership is corrected.',
        'retained_behavior': 'Header color/bold work through the existing sparse cascade even without shading. Automatic border color and omitted-width inheritance remain. Styled cells retain compact undeclared spacing, while future style changes remain live after export.',
    },
}
failed = False
for name, command in commands:
    log = records / ('main-e975-deserializer-' + name + '.log')
    start = time.time()
    with log.open('w') as output:
        result = subprocess.run(command, cwd=package, stdout=output, stderr=subprocess.STDOUT)
    contents = log.read_text()
    item = {
        'name': name,
        'command': command,
        'cwd': str(package),
        'raw_log': str(log),
        'exit_code': result.returncode,
        'elapsed_seconds': time.time() - start,
        'terminal_lines': contents.splitlines()[-8:],
    }
    totals = re.findall(r'\+(\d+)(?:\s+~(\d+))?(?:\s+-(\d+))?: All tests passed!', contents)
    if totals:
        item['passed'] = int(totals[-1][0])
        item['skipped'] = int(totals[-1][1] or '0')
        item['failed'] = int(totals[-1][2] or '0')
    receipt['commands'].append(item)
    failed = failed or result.returncode != 0
    print(json.dumps(item), flush=True)
receipt['source_after'] = hashes()
receipt['source_unchanged'] = receipt['source_before'] == receipt['source_after']
receipt['all_passed'] = not failed and receipt['source_unchanged']
path = records / 'main-e975-deserializer-validation-receipt.json'
path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt': str(path), 'all_passed': receipt['all_passed'],
                  'input_count': len(receipt['source_before'])}), flush=True)
sys.exit(0 if receipt['all_passed'] else 1)
