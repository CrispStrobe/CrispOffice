#!/usr/bin/env python3
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
runtime=Path(__file__).resolve().parent
repo=runtime.parent/'quds_office_suite'
cwd=repo/'packages/quds_office_editor/example'
prefix=sys.argv[1] if len(sys.argv)>1 else 'host-initial'
out=runtime/'records';out.mkdir(exist_ok=True)
files=['lib/studio_mail_native.dart','lib/studio_mail_ews.dart','lib/studio_mail_message_loader.dart','lib/studio_mail_bulk_status.dart','test/studio_mail_workspace_test.dart','test/studio_mail_ews_test.dart','test/studio_mail_message_loader_test.dart','test/studio_mail_bulk_provider_test.dart']
suites=['test/studio_mail_workspace_test.dart','test/studio_mail_ews_test.dart','test/studio_mail_cloud_test.dart','test/studio_mail_cached_mail_test.dart','test/studio_mail_message_loader_test.dart','test/studio_mail_bulk_provider_test.dart']
analysis_only='--analyze-only' in sys.argv
if '--fixture-rerun' in sys.argv:
 files=['test/studio_mail_workspace_test.dart','test/studio_mail_bulk_provider_test.dart']
 suites=list(files)
suite_paths={str(cwd.relative_to(repo)/p) for p in suites}
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
tracked=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','*.dart','pubspec.lock','pubspec.yaml','**/pubspec.yaml'],cwd=repo,text=True).splitlines()
tracked=[p for p in tracked if '/lib/' in p or p.endswith(('pubspec.yaml','pubspec.lock')) or p in suite_paths or p.startswith('packages/quds_office_editor/example/test/support/')]
inputs={p:sha(repo/p) for p in tracked if (repo/p).is_file()}
receipt={'purpose':'Scoped Studio host local validation','input_scope':'All materialized workspace production lib Dart sources, manifests/lock, selected complete suites and their local test/support fixtures','test_suites':suites,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'inputs':inputs,'omitted_sparse_paths':[p for p in tracked if not (repo/p).is_file()],'package_config_sha256':sha(repo/'.dart_tool/package_config.json'),'environment':{k:os.environ.get(k) for k in ['FLUTTER_ROOT','PUB_CACHE','TMPDIR','CI','TZ']},'checks':[]}
record=out/(prefix+'-receipt.json')
def save():record.write_text(json.dumps(receipt,indent=2)+'\n')
save()
dart=str(runtime/'flutter/bin/cache/dart-sdk/bin/dart')
commands=[([dart,'analyze','--fatal-infos',p],f'analyze-{i}') for i,p in enumerate(files)]
if not analysis_only:
 commands += [([dart,str(runtime/'flutter/bin/cache/flutter_tools.snapshot'),'test','--no-pub','--concurrency=1','--reporter=json',*suites],'tests')]
for args,name in commands:
 stdout=out/f'{prefix}-{name}.log';stderr=out/f'{prefix}-{name}.stderr'
 print('Running',name,flush=True);t=time.monotonic()
 with stdout.open('w') as o,stderr.open('w') as e:r=subprocess.run(args,cwd=cwd,stdout=o,stderr=e)
 check={'name':name,'argv':args,'cwd':str(cwd),'exit_code':r.returncode,'elapsed_seconds':round(time.monotonic()-t,3),'stdout':{'path':str(stdout),'sha256':sha(stdout)},'stderr':{'path':str(stderr),'sha256':sha(stderr)}}
 if name=='tests':
  events=[]
  for line in stdout.read_text().splitlines():
   try:events.append(json.loads(line))
   except json.JSONDecodeError:pass
  cases=[e for e in events if e.get('type')=='testDone' and not e.get('hidden',False)]
  check['summary']={'passed':sum(e.get('result')=='success' and not e.get('skipped',False) for e in cases),'failed':sum(e.get('result') in ['failure','error'] for e in cases),'skipped':sum(e.get('skipped',False) for e in cases),'done':[e for e in events if e.get('type')=='done'],'errors':[e for e in events if e.get('type')=='error']}
 receipt['checks'].append(check);save();print(name,'exit',r.returncode,flush=True)
 if r.returncode:
  print(stdout.read_text()[-7000:]);print(stderr.read_text()[-3000:]);break
receipt['completed_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt['changed_inputs']=[p for p,digest in inputs.items() if not (repo/p).is_file() or sha(repo/p)!=digest]
receipt['success']=len(receipt['checks'])==len(commands) and all(c['exit_code']==0 for c in receipt['checks']) and not receipt['changed_inputs']
save();print(json.dumps({k:v for k,v in receipt.items() if k in ['success','changed_inputs','checks']},indent=2),flush=True)
raise SystemExit(0 if receipt['success'] else 1)
