#!/usr/bin/env python3
"""Qualify the captured main font aliases without touching earlier evidence."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

runtime = Path(__file__).resolve().parents[1]
repo = runtime.parent / "quds_office_suite"
cwd = repo / "packages/quds_office_editor"
out = runtime / "records"
dart = runtime / "flutter/bin/cache/dart-sdk/bin/dart"
tool = runtime / "flutter/bin/cache/flutter_tools.snapshot"
prefix = "final-main-font"
selected = {
    "packages/quds_office_editor/lib/src/embed/office_system_fonts_io.dart",
    "packages/quds_office_editor/lib/src/embed/office_system_font_validation.dart",
    "packages/quds_office_editor/lib/src/embed/office_system_font_face.dart",
    "packages/quds_office_editor/test/office_system_fonts_test.dart",
    "packages/quds_office_editor/test/support/installed_font_fixture.dart",
    "packages/quds_office_engine/lib/quds_office_engine.dart",
    "packages/quds_office_engine/lib/src/fonts/sfnt_parser.dart",
    "packages/quds_office_engine/lib/src/io/byte_source.dart",
    "packages/quds_office_editor/pubspec.yaml",
    "packages/quds_office_engine/pubspec.yaml",
    "pubspec.yaml", "pubspec.lock", "analysis_options.yaml",
    ".dart_tool/package_config.json",
}
paths = sorted(selected | {
    str(path.relative_to(repo))
    for path in (cwd / "fonts").glob("*.ttf")
})


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs():
    return {p: sha(repo / p) for p in paths}


receipt = {
    "purpose": "Post-main lowercase font alias and canonical precedence gate",
    "input_scope": "Font loader/validation/model, SFNT parser and byte source, test fixture, licensed font assets and package configuration; no unrelated Word layout sources",
    "head_at_start": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=repo, text=True
    ).strip(),
    "started_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "inputs": inputs(),
    "steps": [],
    "expected_tests": 9,
}
commands = [
    ("format", [str(dart), "format", "--output=none", "--set-exit-if-changed",
                "lib/src/embed/office_system_fonts_io.dart",
                "test/office_system_fonts_test.dart"]),
    ("analyze-loader", [str(dart), "analyze", "--fatal-infos",
                        "lib/src/embed/office_system_fonts_io.dart"]),
    ("analyze-tests", [str(dart), "analyze", "--fatal-infos",
                       "test/office_system_fonts_test.dart"]),
    ("tests", [str(dart), str(tool), "test", "--no-pub", "--concurrency=1",
               "--reporter=json", "test/office_system_fonts_test.dart"]),
]
for label, args in commands:
    log = out / f"{prefix}-{label}.log"
    error = out / f"{prefix}-{label}.stderr"
    print("Running font " + label, flush=True)
    started = time.monotonic()
    with log.open("w") as stdout, error.open("w") as stderr:
        process = subprocess.run(
            args, cwd=cwd, env=dict(os.environ, TZ="Europe/Berlin"),
            stdout=stdout, stderr=stderr,
        )
    step = {
        "name": label, "argv": args, "cwd": str(cwd),
        "exit_code": process.returncode,
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "stdout": log.name, "stderr": error.name,
        "stdout_sha256": sha(log), "stderr_sha256": sha(error),
    }
    if label == "tests":
        events = []
        for line in log.read_text().splitlines():
            try:
                events.append(json.loads(line))
            except ValueError:
                pass
        done = [event for event in events
                if event.get("type") == "testDone" and not event.get("hidden")]
        step["counts"] = {
            "passed": sum(event.get("result") == "success"
                          and not event.get("skipped") for event in done),
            "failed": sum(event.get("result") != "success" for event in done),
            "skipped": sum(bool(event.get("skipped")) for event in done),
        }
        step["terminal_done"] = [event for event in events if event.get("type") == "done"]
    receipt["steps"].append(step)
    receipt["inputs_after"] = inputs()
    receipt["inputs_unchanged"] = receipt["inputs"] == receipt["inputs_after"]
    receipt["success"] = (
        len(receipt["steps"]) == len(commands)
        and all(row["exit_code"] == 0 for row in receipt["steps"])
        and receipt["inputs_unchanged"]
        and receipt["steps"][-1].get("counts", {}).get("passed") == 9
        and receipt["steps"][-1].get("counts", {}).get("skipped") == 0
    )
    (out / f"{prefix}-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(step), flush=True)
    if process.returncode:
        print(log.read_text()[-6000:])
        print(error.read_text()[-4000:])
        raise SystemExit(process.returncode)
if not receipt["success"]:
    raise SystemExit("Font acceptance is incomplete or source inputs changed")
