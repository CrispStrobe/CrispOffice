# Main reconciliation evidence supplement

The published evidence.tar.gz and its original manifest are immutable baseline evidence. This separate archive qualifies the integrated main font and Word changes and proves the baseline core/transport and shared-UI source scopes unchanged.

The new six-suite host run supersedes the earlier combined host acceptance for source applicability. New font, Word and eight visual probes bind the reconciled source. The visual inspection record compares new images with the directly inspected baseline; changed images require separate inspection. Historical red tests remain under history/ and never contribute final pass totals.

No SDK, package-cache archives, native libraries or compiled JavaScript are included. Run the included builder from its repository location with the exact current runtime root.
