# Publication reconciliation evidence

This compact supplement preserves evidence.tar.gz and evidence-final-main.tar.gz unchanged. It contains fresh Zotero editor, Studio host and localized visual qualification after the final captured main advance, plus six-suite Zotero engine acceptance and source applicability.

The initial engine suite run passed 282 tests while strict analysis failed on one unbraced test conditional. Its exact two-brace correction, clean full strict analysis and complete 48-case protocol rerun are preserved. The other 234 unchanged cases are retained once. An intervening receipt-parser diagnostic remains separate; no failed or interrupted result is represented as a pass.

All 21 fresh PNGs are byte-identical to the individually inspected original archive members. source-bindings.json names and hashes each reusable member; no duplicate PNG bytes are included. The previous broad Word map is retained with its four known Zotero changes explicitly identified. Unchanged acceptance and new affected-scope gates are distinguished.

Run the included builder from its repository location with the exact --runtime directory. Runners and package/native-asset maps are included; the genuine SDK, locked packages and native library are described by the immutable baseline runtime records and are not duplicated here.
