import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


records = Path(__file__).resolve().parent
repo = records.parent.parent / 'quds_office_suite'
package = repo / 'packages/quds_office_engine'
dart = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/dart-sdk/bin/dart'
production = [
    'lib/src/word/model/word_zotero.dart',
    'lib/src/word/model/word_zotero_citing.dart',
    'lib/src/word/model/word_zotero_note.dart',
    'lib/src/zotero/zotero_citing.dart',
]
tests = [
    'test/word_zotero_adjacent_citations_test.dart',
    'test/word_zotero_note_table_test.dart',
    'test/word_zotero_note_tables_integration_test.dart',
    'test/word_zotero_citing_test.dart',
    'test/word_zotero_add_note_test.dart',
    'test/zotero_citing_test.dart',
]
inputs = [
    *sorted((package / 'lib').rglob('*.dart')),
    *sorted((repo / 'packages/legacy_doc_parser/lib').rglob('*.dart')),
    *(package / path for path in tests),
    package / 'test/fixtures/zotero/citing/protocol-contract.json',
    package / 'test/fixtures/zotero/citing/processor-output.json',
    package / 'pubspec.yaml',
    repo / 'packages/legacy_doc_parser/pubspec.yaml',
    repo / 'pubspec.yaml',
    repo / 'pubspec.lock',
    repo / '.dart_tool/package_config.json',
]
for path in [package / 'analysis_options.yaml', repo / 'analysis_options.yaml']:
    if path.is_file():
        inputs.append(path)


def hashes():
    return {
        str(path.relative_to(repo)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in inputs
    }


commands = [
    ('format', [str(dart), 'format', '--output=none', '--set-exit-if-changed',
                *production, *tests]),
    ('analyze', [str(dart), 'analyze', '--fatal-infos', *production, *tests]),
    ('tests-vm', [str(dart), '--packages=' + str(repo / '.dart_tool/package_config.json'),
                  str(Path(os.environ['PUB_CACHE']) / 'hosted/pub.dev/test-1.31.1/bin/test.dart'),
                  '--reporter', 'expanded', '--concurrency=1', *tests]),
]
receipt = {
    'incoming_main': '698209aaa6e7f1350b6541df5eb192b7b233443d',
    'head_at_start': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'binding': 'Exact working file SHA-256 values are authoritative; the documentation-only merge commit may be published during this gate.',
    'runtime': subprocess.check_output([str(dart), '--version'], text=True, stderr=subprocess.STDOUT).strip(),
    'source_before': hashes(),
    'commands': [],
    'scope': 'Six complete engine Zotero suites after integration, including protocol fixtures and retained e975 corrections.',
    'expected_historical_cases': 282,
}
failed = False
for name, command in commands:
    log = records / ('publication-zotero-engine-' + name + '.log')
    start = time.time()
    with log.open('w') as output:
        result = subprocess.run(command, cwd=package, stdout=output, stderr=subprocess.STDOUT)
    contents = log.read_text()
    item = {
        'name': name,
        'command': command,
        'cwd': str(package),
        'raw_log': str(log),
        'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
        'exit_code': result.returncode,
        'elapsed_seconds': time.time() - start,
        'terminal_lines': contents.splitlines()[-8:],
    }
    totals = re.findall(r'\+(\d+)(?:\s+~(\d+))?(?:\s+-(\d+))?: All tests passed!', contents)
    if totals:
        item['passed'] = int(totals[-1][0])
        item['skipped'] = int(totals[-1][1] or '0')
        item['failed'] = int(totals[-1][2] or '0')
    receipt['commands'].append(item)
    failed = failed or result.returncode != 0
    print(json.dumps(item), flush=True)
receipt['source_after'] = hashes()
receipt['source_unchanged'] = receipt['source_before'] == receipt['source_after']
receipt['head_at_finish'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
receipt['all_passed'] = not failed and receipt['source_unchanged']
path = records / 'publication-zotero-engine-validation-receipt.json'
path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt': str(path), 'all_passed': receipt['all_passed'],
                  'input_count': len(receipt['source_before'])}), flush=True)
sys.exit(0 if receipt['all_passed'] else 1)
