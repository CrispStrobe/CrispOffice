#!/usr/bin/env python3
"""Qualify both controller suites changed by the captured Zotero merge."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

runtime = Path(__file__).resolve().parents[1]
repo = runtime.parent / "quds_office_suite"
cwd = repo / "packages/quds_office_editor"
out = runtime / "records"
dart = runtime / "flutter/bin/cache/dart-sdk/bin/dart"
tool = runtime / "flutter/bin/cache/flutter_tools.snapshot"
tests = ["test/word_zotero_add_note_controller_test.dart",
         "test/word_zotero_adjacent_citations_controller_test.dart"]
selected = {"packages/quds_office_editor/" + path for path in tests}
tracked = subprocess.check_output(
    ["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"], cwd=repo
).decode().split("\0")
paths = sorted({
    path for path in tracked if path and (repo / path).is_file() and (
        ("/lib/" in path and path.endswith(".dart"))
        or path.startswith("packages/quds_office_editor/test/support/")
        or path.endswith(("pubspec.yaml", ".ttf", ".otf"))
        or path in selected | {"pubspec.lock", "analysis_options.yaml"}
    )
}) + [".dart_tool/package_config.json"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs():
    return {path: sha(repo / path) for path in paths}


receipt = {
    "purpose": "Captured Zotero main merge: both complete changed editor/controller suites",
    "head_at_start": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=repo, text=True
    ).strip(),
    "started_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "inputs": inputs(), "suites": tests, "steps": [], "historical_expected_cases": 114,
}
commands = [
    ("format", [str(dart), "format", "--output=none", "--set-exit-if-changed", *tests]),
    ("analyze-notes", [str(dart), "analyze", "--fatal-infos", tests[0]]),
    ("analyze-citations", [str(dart), "analyze", "--fatal-infos", tests[1]]),
    ("tests", [str(dart), str(tool), "test", "--no-pub", "--concurrency=1", "--reporter=json", *tests]),
]
for label, args in commands:
    log = out / f"publication-editor-{label}.log"
    error = out / f"publication-editor-{label}.stderr"
    print("Running publication editor " + label, flush=True)
    started = time.monotonic()
    with log.open("w") as stdout, error.open("w") as stderr:
        process = subprocess.run(args, cwd=cwd, env=dict(os.environ, TZ="Europe/Berlin"),
                                 stdout=stdout, stderr=stderr)
    step = {"name": label, "argv": args, "cwd": str(cwd), "exit_code": process.returncode,
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "stdout": log.name, "stderr": error.name,
            "stdout_sha256": sha(log), "stderr_sha256": sha(error)}
    if label == "tests":
        events = []
        for line in log.read_text().splitlines():
            try:
                events.append(json.loads(line))
            except ValueError:
                pass
        done = [event for event in events if event.get("type") == "testDone" and not event.get("hidden")]
        step["counts"] = {
            "passed": sum(event.get("result") == "success" and not event.get("skipped") for event in done),
            "failed": sum(event.get("result") != "success" for event in done),
            "skipped": sum(bool(event.get("skipped")) for event in done),
        }
        step["terminal_done"] = [event for event in events if event.get("type") == "done"]
    receipt["steps"].append(step)
    receipt["inputs_after"] = inputs()
    receipt["inputs_unchanged"] = receipt["inputs"] == receipt["inputs_after"]
    receipt["success"] = (len(receipt["steps"]) == len(commands)
                          and all(row["exit_code"] == 0 for row in receipt["steps"])
                          and receipt["inputs_unchanged"]
                          and receipt["steps"][-1].get("counts", {}).get("failed") == 0
                          and receipt["steps"][-1].get("counts", {}).get("skipped") == 0
                          and bool(receipt["steps"][-1].get("terminal_done", []))
                          and receipt["steps"][-1]["terminal_done"][-1]["success"])
    (out / "publication-editor-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(step), flush=True)
    if process.returncode:
        print(log.read_text()[-6000:])
        print(error.read_text()[-4000:])
        raise SystemExit(process.returncode)
if not receipt["success"]:
    raise SystemExit("Publication editor acceptance is incomplete or source changed")
