import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time


records = Path(__file__).resolve().parent
repo = records.parent.parent / 'quds_office_suite'
package = repo / 'packages/quds_office_engine'
initial_path = records / 'publication-zotero-engine-validation-receipt.json'
initial = json.loads(initial_path.read_text())
protocol = 'packages/quds_office_engine/test/zotero_citing_test.dart'
old = subprocess.check_output(['git', 'show', initial['incoming_main'] + ':' + protocol], cwd=repo)
new = (repo / protocol).read_bytes()
before_if = (b"            if (requests == 1)\n"
             b"              return _command('Application.getActiveDocument', []);\n")
after_if = (b"            if (requests == 1) {\n"
            b"              return _command('Application.getActiveDocument', []);\n"
            b"            }\n")
assert old.count(before_if) == 1
assert old.replace(before_if, after_if, 1) == new
assert hashlib.sha256(old).hexdigest() == initial['source_before'][protocol]
assert initial['source_unchanged']


def hashes():
    return {path: hashlib.sha256((repo / path).read_bytes()).hexdigest()
            for path in initial['source_before']}


before = hashes()
changed = [path for path, digest in before.items()
           if digest != initial['source_before'][path]]
assert changed == [protocol], changed
initial_commands = {item['name']: item for item in initial['commands']}
assert initial_commands['tests-vm']['exit_code'] == 0
assert initial_commands['tests-vm']['passed'] == 282
initial_log = Path(initial_commands['tests-vm']['raw_log'])
assert hashlib.sha256(initial_log.read_bytes()).hexdigest() == initial_commands['tests-vm']['log_sha256']


def test_names(contents):
    result = {}
    for line in contents.splitlines():
        match = re.match(r'^\d+:\d+ \+\d+: (test/[^:]+\.dart): (.+)$', line)
        if match and not match[2].endswith(('(setUpAll)', '(tearDownAll)')):
            result.setdefault(match[1], set()).add(match[2])
    return result


previous_names = test_names(initial_log.read_text())
assert sum(len(names) for names in previous_names.values()) == 282
assert len(previous_names['test/zotero_citing_test.dart']) == 48
commands = [
    ('format', initial_commands['format']['command']),
    ('analyze', initial_commands['analyze']['command']),
    ('protocol-tests-vm', initial_commands['tests-vm']['command'][:-6] + ['test/zotero_citing_test.dart']),
]
receipt = {
    'initial_receipt': str(initial_path),
    'initial_receipt_sha256': hashlib.sha256(initial_path.read_bytes()).hexdigest(),
    'initial_state': 'All six suites passed; strict analysis rejected the new unbraced if in the protocol test. The diagnostic receipt/logs are retained unchanged.',
    'source_before': before,
    'changed_inputs_since_initial': changed,
    'exact_braces_only_proof': {
        'incoming_source': initial['incoming_main'] + ':' + protocol,
        'old_sha256': hashlib.sha256(old).hexdigest(),
        'new_sha256': hashlib.sha256(new).hexdigest(),
        'exact_single_replacement_verified': True,
        'changes_test_behavior_or_assertions': False,
    },
    'retained_suite_counts': {path: len(names) for path, names in previous_names.items()
                              if path != 'test/zotero_citing_test.dart'},
    'commands': [],
}
failed = False
for name, command in commands:
    log = records / ('publication-zotero-engine-followup-' + name + '.log')
    start = time.time()
    with log.open('w') as output:
        result = subprocess.run(command, cwd=package, stdout=output, stderr=subprocess.STDOUT)
    contents = log.read_text()
    item = {'name': name, 'command': command, 'cwd': str(package), 'raw_log': str(log),
            'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
            'exit_code': result.returncode, 'elapsed_seconds': time.time() - start,
            'terminal_lines': contents.splitlines()[-8:]}
    totals = re.findall(r'\+(\d+)(?:\s+~(\d+))?(?:\s+-(\d+))?: All tests passed!', contents)
    if totals:
        item.update(passed=int(totals[-1][0]), skipped=int(totals[-1][1] or '0'),
                    failed=int(totals[-1][2] or '0'))
    if name == 'protocol-tests-vm' and result.returncode == 0:
        current_names = test_names(contents)
        assert current_names['test/zotero_citing_test.dart'] == previous_names['test/zotero_citing_test.dart']
        assert item['passed'] == 48 and item['skipped'] == item['failed'] == 0
        item['same_48_case_names_as_initial'] = True
    receipt['commands'].append(item)
    failed = failed or result.returncode != 0
    print(json.dumps(item), flush=True)
receipt['source_after'] = hashes()
receipt['source_unchanged_during_followup'] = before == receipt['source_after']
receipt['all_passed'] = not failed and receipt['source_unchanged_during_followup']
receipt['consolidated_acceptance'] = {
    'passed': 282 if receipt['all_passed'] else None,
    'skipped': 0,
    'failed': 0 if receipt['all_passed'] else None,
    'unchanged_five_suites_retained': 234,
    'corrected_protocol_suite_rerun': 48,
    'counting_rule': 'The repeated 48 protocol cases replace their initial outcomes and are not added again.',
}
path = records / 'publication-zotero-engine-followup-receipt.json'
path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt': str(path), 'all_passed': receipt['all_passed'],
                  'input_count': len(before), 'consolidated_acceptance': receipt['consolidated_acceptance']}), flush=True)
sys.exit(0 if receipt['all_passed'] else 1)
