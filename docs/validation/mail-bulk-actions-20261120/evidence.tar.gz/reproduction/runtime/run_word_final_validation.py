import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone

root = Path('/home/agent/.codex/skills/remote-skills/quds-mail-work-20261120')
repo = root / 'quds_office_suite'
engine = repo / 'packages/quds_office_engine'
runtime = root / 'runtime'
out = repo / 'docs/validation/mail-bulk-actions-20261120'
prefix = 'intake-local-word-final'
receipt_path = out / f'{prefix}-validation.json'
dart = str(runtime / 'flutter/bin/cache/dart-sdk/bin/dart')
package_config = repo / '.dart_tool/package_config.json'
test_runner = runtime / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
names = ['bulk_intake_conversions', 'line_spacing', 'line_spacing_integration',
         'measurements', 'measurements_integration', 'named_measurements',
         'named_measurements_integration', 'unit_conversions',
         'unit_conversions_integration']
test_files = [f'test/office_vba_word_{name}_test.dart' for name in names]
node_files = [path for path in test_files if '_integration_' not in path]
probes = ['line_spacing', 'measurements', 'named_measurements']
driver_files = [f'tool/macros/web_vba_word_{name}_smoke.dart' for name in probes]
format_files = ['lib/src/automation/office_vba_language.dart', *test_files, *driver_files]
env = os.environ.copy()
env.update({
    'FLUTTER_ROOT': str(runtime / 'flutter'),
    'PUB_CACHE': str(runtime / 'pub-cache'),
    'XDG_DATA_HOME': str(runtime / 'data'),
    'XDG_CONFIG_HOME': str(runtime / 'config'),
    'XDG_CACHE_HOME': str(runtime / 'cache'),
    'TMPDIR': str(runtime / 'tmp'),
    'CI': 'true', 'DART_SUPPRESS_ANALYTICS': 'true',
    'FLUTTER_SUPPRESS_ANALYTICS': 'true', 'DASH__SUPPRESS_ANALYTICS': 'true',
})

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()

source_paths = sorted(set([
    repo / 'pubspec.lock', repo / 'pubspec.yaml', engine / 'pubspec.yaml',
    *engine.joinpath('lib').rglob('*.dart'),
    *(engine / path for path in test_files),
    *(engine / path for path in driver_files),
    *(engine / f'example/macros/word_{name}.bas' for name in [*probes, 'unit_conversions']),
]))

def sources():
    return {str(path.relative_to(repo)): sha(path.read_bytes()) for path in source_paths}

receipt = {
    'schema': 'quds-mail-bulk-integrated-word-validation/v1',
    'started_at_utc': now(), 'initial_head': head(),
    'scope': 'Combined main b01cb23d named/ratio measurement implementation, 8ca1958d large-scalar regression and all related compiler, integration, and portable BAS probes. Concurrent Mail-only edits are outside this source scope.',
    'historical_receipt': 'intake-local-word-validation.json',
    'source_sha256_before': sources(),
    'runtime': subprocess.check_output([dart, '--version'], text=True).strip(),
    'node': subprocess.check_output(['node', '--version'], text=True).strip(),
    'package_config_sha256': sha(package_config.read_bytes()),
    'commands': [], 'portable_results': {},
    'github_actions': 'NOT QUERIED OR AWAITED',
    'status': 'RUNNING',
}

def save():
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')

def command(label, args, tests=False):
    start = time.monotonic()
    stdout_path = out / f'{prefix}-{label}.stdout.log'
    stderr_path = out / f'{prefix}-{label}.stderr.log'
    print(f'START {label}', flush=True)
    with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
        run = subprocess.run(args, cwd=engine, env=env, stdout=stdout, stderr=stderr)
    record = {
        'label': label, 'command': args, 'cwd': 'packages/quds_office_engine',
        'exit_code': run.returncode, 'elapsed_seconds': round(time.monotonic() - start, 3),
        'stdout': stdout_path.name, 'stderr': stderr_path.name,
        'stdout_sha256': sha(stdout_path.read_bytes()),
        'stderr_sha256': sha(stderr_path.read_bytes()),
        'accepted': run.returncode == 0,
    }
    if tests:
        events = []
        for line in stdout_path.read_text().splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(event, dict):
                events.append(event)
        outcomes = [event for event in events if event.get('type') == 'testDone' and not event.get('hidden')]
        record['tests'] = {
            'passed': sum(event.get('result') == 'success' and not event.get('skipped') for event in outcomes),
            'failed': sum(event.get('result') != 'success' and not event.get('skipped') for event in outcomes),
            'skipped': sum(bool(event.get('skipped')) for event in outcomes),
            'runner_done': [event for event in events if event.get('type') == 'done'],
        }
        record['accepted'] = record['accepted'] and bool(record['tests']['runner_done']) and all(event.get('success') for event in record['tests']['runner_done']) and record['tests']['failed'] == 0
    receipt['commands'].append(record)
    save()
    print(f'DONE {label}: exit={run.returncode} accepted={record["accepted"]}' + (f' tests={record["tests"]}' if tests else ''), flush=True)
    if not record['accepted']:
        raise RuntimeError(f'{label} failed; source untouched; inspect {stdout_path.name} and {stderr_path.name}')
    return stdout_path

save()
try:
    command('format', [dart, 'format', '--output=none', '--set-exit-if-changed', *format_files])
    command('analyze', [dart, 'analyze', '--fatal-infos', *format_files])
    common = [dart, f'--packages={package_config}', str(test_runner), '--concurrency=1', '--reporter=json']
    command('vm', [*common, *test_files], tests=True)
    command('node', [*common, '--platform=node', *node_files], tests=True)
    for name in probes:
        source = engine / f'example/macros/word_{name}.bas'
        define = f'-DWORD_{name.upper()}_BAS_BASE64=' + base64.b64encode(source.read_bytes()).decode('ascii')
        driver = f'tool/macros/web_vba_word_{name}_smoke.dart'
        target = runtime / f'records/intake-word-final-{name}.js'
        vm = command(f'{name}-portable-vm', [dart, f'--packages={package_config}', define, driver])
        command(f'{name}-portable-compile', [dart, 'compile', 'js', '-O1', f'--packages={package_config}', define, driver, '-o', str(target)])
        node = command(f'{name}-portable-node', ['node', '-e', 'globalThis.self = globalThis; require(process.argv[1]);', str(target)])
        vm_json = json.loads(vm.read_text())
        node_json = json.loads(node.read_text())
        result = {
            'semantic_equal': vm_json == node_json,
            'result_sections': list(vm_json) if isinstance(vm_json, dict) else None,
            'compiled_javascript_sha256': sha(target.read_bytes()),
            'bas_sha256': sha(source.read_bytes()),
        }
        receipt['portable_results'][name] = result
        save()
        if not result['semantic_equal']:
            raise RuntimeError(f'{name} portable VM/Node JSON differs')
    receipt['status'] = 'PASS'
except BaseException as exc:
    receipt['status'] = 'FAIL'
    receipt['error'] = f'{type(exc).__name__}: {exc}'
    raise
finally:
    receipt['source_sha256_after'] = sources()
    receipt['source_unchanged'] = receipt['source_sha256_after'] == receipt['source_sha256_before']
    if not receipt['source_unchanged']:
        receipt['status'] = 'FAIL'
        receipt['source_change_error'] = 'Word source changed during qualification'
    receipt['final_head'] = head()
    receipt['completed_at_utc'] = now()
    save()
    print(json.dumps({'status': receipt['status'], 'source_unchanged': receipt['source_unchanged'], 'source_count': len(source_paths), 'receipt': str(receipt_path)}), flush=True)
