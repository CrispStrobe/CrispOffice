import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

repo = Path(__file__).resolve().parents[2] / "quds_office_suite"
records = Path(__file__).resolve().parent
dart = Path(os.environ["FLUTTER_ROOT"]) / "bin/cache/dart-sdk/bin/dart"
runner = Path(os.environ["PUB_CACHE"]) / "hosted/pub.dev/test-1.31.1/bin/test.dart"
config = repo / ".dart_tool/package_config.json"
paths = [
    *sorted((repo / "packages/quds_mail_core/lib").rglob("*.dart")),
    *sorted((repo / "packages/quds_mail_core/test").rglob("*.dart")),
    repo / "packages/quds_mail_core/pubspec.yaml",
    repo / "pubspec.yaml",
    repo / "pubspec.lock",
    repo / "analysis_options.yaml",
    config,
]
inputs = {
    str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in paths
}
steps = [
    (
        "core-format",
        [str(dart), "format", "--output=none", "--set-exit-if-changed",
         "packages/quds_mail_core/lib/src/sync/bulk_flags.dart",
         "packages/quds_mail_core/lib/quds_mail_core.dart",
         "packages/quds_mail_core/test/bulk_flags_test.dart"],
        repo,
    ),
    (
        "core-analyze",
        [str(dart), "analyze", "--fatal-infos", "packages/quds_mail_core"],
        repo,
    ),
    (
        "core-tests-vm",
        [str(dart), "--packages=" + str(config), str(runner),
         "--reporter", "expanded"],
        repo / "packages/quds_mail_core",
    ),
    (
        "core-bulk-tests-node",
        [str(dart), "--packages=" + str(config), str(runner),
         "--platform=node", "--concurrency=1", "--reporter", "expanded",
         "test/bulk_flags_test.dart"],
        repo / "packages/quds_mail_core",
    ),
]
receipt = {
    "source_inputs": inputs,
    "head_at_start": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=repo, text=True
    ).strip(),
    "environment": {
        "TZ": "Europe/Berlin",
        "FLUTTER_ROOT": os.environ["FLUTTER_ROOT"],
        "PUB_CACHE": os.environ["PUB_CACHE"],
    },
    "steps": [],
}
for name, args, cwd in steps:
    start = time.time()
    print("Running " + name, flush=True)
    with (records / (name + ".log")).open("w") as output:
        process = subprocess.run(
            args, cwd=cwd, env=dict(os.environ, TZ="Europe/Berlin"),
            stdout=output, stderr=subprocess.STDOUT
        )
    row = {
        "name": name, "args": args, "cwd": str(cwd),
        "exit_code": process.returncode,
        "duration_seconds": round(time.time() - start, 3),
        "log": name + ".log",
    }
    receipt["steps"].append(row)
    receipt["source_unchanged"] = {
        str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest()
        == inputs[str(p.relative_to(repo))] for p in paths
    }
    (records / "core-bulk-validation-receipt.json").write_text(
        json.dumps(receipt, indent=2) + "\n"
    )
    print(json.dumps(row), flush=True)
    print("\n".join((records / (name + ".log")).read_text().splitlines()[-8:]), flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)
