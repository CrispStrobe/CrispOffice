import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

repo = Path(__file__).resolve().parents[2] / "quds_office_suite"
records = Path(__file__).resolve().parent
dart = Path(os.environ["FLUTTER_ROOT"]) / "bin/cache/dart-sdk/bin/dart"
runner = Path(os.environ["PUB_CACHE"]) / "hosted/pub.dev/test-1.31.1/bin/test.dart"
config = repo / ".dart_tool/package_config.json"
paths = []
for package in ("quds_mail_core", "quds_mail_transport", "quds_mail_mime", "quds_mail_store"):
    root = repo / "packages" / package
    paths.extend(sorted((root / "lib").rglob("*.dart")))
    paths.append(root / "pubspec.yaml")
    if package in ("quds_mail_core", "quds_mail_transport"):
        paths.extend(sorted(path for path in (root / "test").rglob("*") if path.is_file()))
        if (root / "analysis_options.yaml").exists():
            paths.append(root / "analysis_options.yaml")
paths.extend(sorted((repo / "third_party/enough_mail/lib").rglob("*.dart")))
paths.extend([repo / "pubspec.yaml", repo / "pubspec.lock", repo / "analysis_options.yaml", config])
native_assets = repo / ".dart_tool/native_assets.yaml"
if native_assets.exists():
    paths.append(native_assets)
    asset_map = json.loads(native_assets.read_text())
    paths.append(Path(asset_map["native-assets"]["linux_x64"]["package:sqlite3/src/ffi/libsqlite3.g.dart"][1]))
inputs = {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
test_command = [str(dart), "--packages=" + str(config), str(runner), "--reporter", "expanded", "--concurrency=1"]
steps = [
    ("core-converged-format", [str(dart), "format", "--output=none", "--set-exit-if-changed", "packages/quds_mail_core/lib", "packages/quds_mail_core/test"], repo),
    ("core-converged-analyze", [str(dart), "analyze", "--fatal-infos", "packages/quds_mail_core"], repo),
    ("transport-converged-format", [str(dart), "format", "--output=none", "--set-exit-if-changed", "packages/quds_mail_transport/lib", "packages/quds_mail_transport/test"], repo),
    ("transport-converged-analyze", [str(dart), "analyze", "--fatal-infos", "packages/quds_mail_transport"], repo),
    ("core-converged-tests-vm", test_command, repo / "packages/quds_mail_core"),
    ("core-converged-tests-node", test_command + ["--platform=node", "test/bulk_flags_test.dart", "test/bulk_flags_provider_results_test.dart", "test/bulk_flags_compatibility_test.dart"], repo / "packages/quds_mail_core"),
    ("transport-converged-tests-vm", test_command, repo / "packages/quds_mail_transport"),
    ("transport-converged-tests-node", test_command + ["--platform=node", "test/cloud_provider_test.dart", "test/unsupported_test.dart", "test/cloud_unsupported_test.dart", "test/ews_unsupported_test.dart"], repo / "packages/quds_mail_transport"),
]
receipt = {
    "source_inputs": inputs,
    "head_at_start": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip(),
    "environment": {key: os.environ.get(key) for key in ("FLUTTER_ROOT", "PUB_CACHE", "TMPDIR")},
    "TZ": "Europe/Berlin",
    "steps": [],
}
for name, args, cwd in steps:
    start = time.time()
    print("Running " + name, flush=True)
    with (records / (name + ".log")).open("w") as output:
        result = subprocess.run(args, cwd=cwd, env=dict(os.environ, TZ="Europe/Berlin"), stdout=output, stderr=subprocess.STDOUT)
    row = {"name": name, "args": args, "cwd": str(cwd), "exit_code": result.returncode, "duration_seconds": round(time.time() - start, 3), "log": name + ".log"}
    receipt["steps"].append(row)
    receipt["source_unchanged"] = {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() == inputs[str(p.relative_to(repo))] for p in paths}
    (records / "converged-mail-validation-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(row), flush=True)
    print("\n".join((records / (name + ".log")).read_text().splitlines()[-10:]), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
