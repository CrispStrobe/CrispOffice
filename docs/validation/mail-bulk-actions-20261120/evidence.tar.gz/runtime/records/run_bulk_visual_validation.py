import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
runtime=Path(__file__).resolve().parents[1]; repo=runtime.parent/'quds_office_suite'; out=runtime/'records'; images=out/'bulk-visuals'; images.mkdir(exist_ok=True)
cwd=repo/'packages/quds_office_editor/example'; dart=runtime/'flutter/bin/cache/dart-sdk/bin/dart'; tool=runtime/'flutter/bin/cache/flutter_tools.snapshot'; test='test/studio_mail_bulk_visual_test.dart'
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
paths=sorted(p for p in tracked if p and (repo/p).is_file() and (('/lib/' in p and p.endswith('.dart')) or p.endswith('pubspec.yaml') or p.endswith(('.ttf','.otf')) or p in ['pubspec.lock','analysis_options.yaml','packages/quds_office_editor/example/'+test]))+['.dart_tool/package_config.json']
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def inputs():return {p:sha(repo/p) for p in paths}
r={'purpose':'Actual localized mail controls and per-message receipt visual qualification','head_at_start':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs':inputs(),'steps':[],'expected_tests':8,'expected_pngs':21}
commands=[('format',[str(dart),'format','--output=none','--set-exit-if-changed',test]),('analyze',[str(dart),'analyze','--fatal-infos',test]),('tests',[str(dart),str(tool),'test','--no-pub','--concurrency=1','--reporter=json','--dart-define=MAIL_BULK_SCREENSHOT_DIR='+str(images),test])]
for label,args in commands:
 start=time.time(); log=out/f'visual-final-{label}.log'; err=out/f'visual-final-{label}.stderr';print('Running visual '+label,flush=True)
 with log.open('w') as stdout,err.open('w') as stderr:proc=subprocess.run(args,cwd=cwd,env=dict(os.environ,TZ='Europe/Berlin'),stdout=stdout,stderr=stderr)
 row={'name':label,'argv':args,'cwd':str(cwd),'exit_code':proc.returncode,'duration_seconds':round(time.time()-start,3),'stdout':log.name,'stderr':err.name}
 if label=='tests':
  events=[]
  for line in log.read_text().splitlines():
   try:events.append(json.loads(line))
   except ValueError:pass
  done=[e for e in events if e.get('type')=='testDone' and not e.get('hidden')]
  row['counts']={'passed':sum(e.get('result')=='success' and not e.get('skipped') for e in done),'failed':sum(e.get('result')!='success' for e in done),'skipped':sum(bool(e.get('skipped')) for e in done)}
  row['terminal_done']=[e for e in events if e.get('type')=='done']
 r['steps'].append(row);r['inputs_after']=inputs();r['inputs_unchanged']=r['inputs']==r['inputs_after'];r['images']={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(images.glob('*.png'))};r['success']=len(r['steps'])==3 and all(s['exit_code']==0 for s in r['steps']) and r['inputs_unchanged'] and len(r['images'])==21
 (out/'visual-final-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(row),flush=True)
 if proc.returncode:
  print('\n'.join(log.read_text().splitlines()[-18:]));print(err.read_text()[-5000:]);raise SystemExit(proc.returncode)
if not r['success']:raise SystemExit('Visual acceptance missing expected evidence or source unchanged check')
