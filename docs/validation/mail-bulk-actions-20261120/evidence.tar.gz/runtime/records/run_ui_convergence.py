import datetime, hashlib, json, os, subprocess, time
from pathlib import Path
repo=Path(__file__).resolve().parents[2]/'quds_office_suite'
records=Path(__file__).resolve().parent
prefix='ui-converged'
dart=Path(os.environ['FLUTTER_ROOT'])/'bin/cache/dart-sdk/bin/dart'
flutter=Path(os.environ['FLUTTER_ROOT'])/'bin/cache/flutter_tools.snapshot'
tracked=subprocess.check_output(['git','ls-files','-z','--','packages/quds_mail_ui','packages/quds_mail_core/lib','packages/quds_mail_mime/lib','packages/quds_mail_core/pubspec.yaml','packages/quds_mail_mime/pubspec.yaml','pubspec.yaml','pubspec.lock','analysis_options.yaml'],cwd=repo).decode().split('\0')
paths=sorted({p for p in tracked if p and (repo/p).is_file()})+['.dart_tool/package_config.json']
def inputs():return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
receipt={'purpose':'Converged full shared mail UI package acceptance','started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head_at_start':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'inputs':inputs(),'steps':[]}
steps=[('format',[str(dart),'format','--output=none','--set-exit-if-changed','lib/src/workspace/message_list.dart','test/bulk_message_list_test.dart','test/message_list_bulk_test.dart','tool/bulk_flags_visual_test.dart']),('analyze',[str(dart),'analyze','--fatal-infos','.']),('tests',[str(dart),str(flutter),'test','--no-pub','--concurrency=1','--reporter=json'])]
for name,args in steps:
    log=records/f'{prefix}-{name}.log';error=records/f'{prefix}-{name}.stderr';started=time.time()
    print('Running '+name,flush=True)
    with log.open('w') as stdout,error.open('w') as stderr:
        proc=subprocess.run(args,cwd=repo/'packages/quds_mail_ui',env=dict(os.environ,TZ='Europe/Berlin'),stdout=stdout,stderr=stderr)
    row={'name':name,'args':args,'cwd':str(repo/'packages/quds_mail_ui'),'exit_code':proc.returncode,'duration_seconds':round(time.time()-started,3),'stdout':log.name,'stderr':error.name}
    if name=='tests':
        events=[]
        for line in log.read_text().splitlines():
            try:events.append(json.loads(line))
            except ValueError:pass
        done=[e for e in events if e.get('type')=='testDone' and not e.get('hidden')]
        row['counts']={'passed':sum(e.get('result')=='success' and not e.get('skipped') for e in done),'failed':sum(e.get('result')!='success' for e in done),'skipped':sum(bool(e.get('skipped')) for e in done)}
        row['terminal_done']=[e for e in events if e.get('type')=='done']
    receipt['steps'].append(row);receipt['inputs_after']=inputs();receipt['inputs_unchanged']=receipt['inputs']==receipt['inputs_after']
    (records/f'{prefix}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if proc.returncode:
        print('\n'.join(log.read_text().splitlines()[-12:]),flush=True)
        print(error.read_text()[-4000:],flush=True)
        raise SystemExit(proc.returncode)
