# Current-turn mail bulk-actions evidence

The adjacent evidence-manifest.json records every member digest and size, the archive digest, and final source bindings. Rebuild with the included build_evidence.py and the exact current-turn runtime.

Files under history/ are earlier, interrupted, failed, superseded, or mixed attempts. Their original outcomes remain intact. In particular, host-final is a failed mixed run; the consolidated host receipt explicitly retains four unchanged complete suites and substitutes two complete clean reruns. No test totals are summed by this packer. Runtime smoke checks are setup evidence, not new feature acceptance.

The fresh bootstrap script was reused from previously committed evidence and rerun against the current locks; runtime-ready.json and the fresh manifest record this provenance. Inherited records from the previous header-search archive, the SDK, dependency cache, downloaded archives, SQLite binaries and compiled JavaScript are excluded. Genuine native-assets mappings and library hashes are retained.
