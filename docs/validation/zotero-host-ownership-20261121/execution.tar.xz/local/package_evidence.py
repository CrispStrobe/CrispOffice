#!/usr/bin/env python3
import hashlib, io, json, pathlib, shutil, subprocess, tarfile
root=pathlib.Path('/workspace/scratch/1a4f82921a71')
repo=root/'quds_office_suite'
work=root/'followup'
out=repo/'docs/validation/zotero-host-ownership-20261121'
out.mkdir(parents=True,exist_ok=True)
def sha(data): return hashlib.sha256(data).hexdigest()
receipt=json.loads((work/'accepted/receipt.json').read_text())
assert receipt['accepted'] is True and receipt['source_inputs_unchanged'] is True
assert receipt['initial_status']=='' and receipt['final_status']==''
before=json.loads((work/'accepted/source-inputs.before.json').read_text())
after=json.loads((work/'accepted/source-inputs.after.json').read_text())
assert before==after
source=receipt['source_commit']; tree=receipt['source_tree']
runs=receipt['runs']
assert len(runs)==17
assert all(r['exit_code']==0 and r['fail']==0 and r['skip']==0 and not r['errors'] and not r['unfinished_ids'] for r in runs)
contents={}
for directory in ['baseline','attempt-1','attempt-2-compiler','retry-odt-open','accepted']:
    for p in sorted((work/directory).iterdir()):
        if p.is_file() and p.suffix in ['.json','.jsonl','.log']:
            contents[directory+'/'+p.name]=p.read_bytes()
for name in ['run_local.py','package_evidence.py','retry_single.py','retry-run.log','format.log','format-check.log','analyze.log','analyze.initial-failure.log','analyze.before-harness-fix.log','static-checks.json','static-checks.before-harness-fix.json','qualification-run.log','qualification-isolated.log','baseline-run.log']:
    p=work/name
    if p.exists(): contents['local/'+name]=p.read_bytes()
for name in ['runtime.json','pub-cache-receipt.json','env.sh']:
    contents['runtime/'+name]=(root/'toolchains'/name).read_bytes()
contents['runtime/bootstrap_runtime.py']=(root/'bootstrap_runtime.py').read_bytes()
contents['runtime/package_config.json']=(repo/'.dart_tool/package_config.json').read_bytes()
contents['runtime/reconstruction.log']=(root/'setup.log').read_bytes()
for p in sorted((root/'toolchains/logs').glob('*.log')):
    contents['runtime/logs/'+p.name]=p.read_bytes()
members=[]
archive=out/'execution.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as t:
    for name,data in sorted(contents.items()):
        info=tarfile.TarInfo(name)
        info.size=len(data); info.mode=0o644; info.mtime=0
        t.addfile(info,io.BytesIO(data))
        members.append({'path':name,'bytes':len(data),'sha256':sha(data)})
index={'schema':1,'production_commit':source,'production_tree':tree,'repository_root_at_execution':str(repo),'tracked_sources':before,'untracked_runtime_inputs':{'.dart_tool/package_config.json':sha(contents['runtime/package_config.json'])},'archives':[{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':members}],'test_runs':[{'archive':archive.name,'member':'accepted/'+r['log'],'name':r['name'],'package_root':r['cwd'],'expected_passed':r['pass'],'expected_suites':len({t['suite'] for t in r['visible_tests']})} for r in runs]}
(out/'index.json').write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
(out/'run_local.py').write_bytes((work/'run_local.py').read_bytes())
with (out/'verification.json').open('wb') as stdout, (work/'verify.log').open('wb') as stderr:
    checked=subprocess.run(['python3',str(repo/'docs/validation/zotero-table-layout-20261121/verify_evidence.py'),'--index',str(out/'index.json')],cwd=repo,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
assert checked.returncode==0,(work/'verify.log').read_text()
verified=json.loads((out/'verification.json').read_text())
assert verified['verified'] and verified['repeated_executions']==0
studio=[r for r in runs if r['name'].startswith('studio-')]
editor=[r for r in runs if r['name'].startswith('editor-')]
readme="# Zotero host ownership and workspace shortcuts\n\nThis follow-up keeps an open Zotero operation attached to the Word view that\nstarted it and preserves citation shortcuts when workspace commands are\ncustomized. It is built on the integrated Office main, including the earlier\ntable-margin/ODT work, Mail refresh and Word VBA authoring.\n\n**Local acceptance: @@TOTAL@@ distinct passing cases in @@SUITES@@ suites,\nwith no failures, errors or skips.** The source is\n[`@@SOURCE@@`](https://github.com/CrispStrobe/quds_office_suite/commit/@@SOURCE@@),\ntree `@@TREE@@`. Publication is [PR #347](https://github.com/CrispStrobe/quds_office_suite/pull/347).\n\n## Delivered behavior\n\n- `showWordZoteroDialog` accepts an optional `isCurrent` host predicate. It is\n  checked before committing pending edits, through the existing protocol and\n  publication guards, and before field reveal or return of editing focus.\n- Studio captures its navigation generation when Zotero opens. Opening Mail\n  invalidates it before the asynchronous title update; switching applications\n  and closing Mail also advance it. Returning to Word cannot reactivate an\n  operation that belonged to an earlier view.\n- Reserved Ctrl/Cmd+Alt+C/R citation commands and other uncatalogued workspace\n  chords cannot be replaced by a conflicting stored override. The recorder\n  explains reserved conflicts and the effective settings display reflects\n  accepted bindings.\n- Reassigning redo or zoom retires their previous alternate keys. Structural\n  deduplication and the incoming precedence of explicit configurable overrides\n  remain intact. The established zoom-in chord is preserved; subscript is\n  shown as unassigned until the user chooses a binding.\n- Persisted modifier-only triggers are rejected before constructing Flutter\n  activators. Bare F1\u2013F24 and valid modified shortcuts remain supported.\n- Word mutations require the current editable Word view and the appropriate\n  body/comment formatting capability. Native text actions go to their focused\n  control, including dialogs and Mail; fallback commands cannot reach a hidden\n  document. Comment bold, italic and underline remain available.\n\nThe optional predicate lets existing embedders retain their document/caret\nguards. Hosts with multiple views can opt into the stronger lifetime contract.\nIt must remain true while the Zotero workspace's own dialogs are open.\n\n## Demonstrated regression\n\nThe tests-only checkpoint\n[`08f23ace`](https://github.com/CrispStrobe/quds_office_suite/commit/08f23acef7b170d04428d524585bd1982c0ca011)\nparents main `52e72ca` without changing production code. Two tests hold a\nterminal `Document.complete` response after it has staged changed document\npreferences, navigate to Mail, and optionally return to Word before releasing\nthe response. Both fail on that production source because the old dialog\nwrites the new metadata. The complete before/after source manifest is stable.\n\nBoth cases pass in the accepted source: document identity, metadata and undo\nhistory remain unchanged, and the operation reports its stale target. Their\nraw failing baseline is retained separately from the passing qualification.\n\n## Fresh local qualification\n\n| Cohort | Suites | Passing cases |\n| --- | ---: | ---: |\n| Studio catalog, settings, dispatch, Mail isolation and Zotero/ODT workflows | @@STUDIO_SUITES@@ | @@STUDIO@@ |\n| Shared Zotero dialogs and note preview | @@EDITOR_SUITES@@ | @@EDITOR@@ |\n| Total distinct cases | @@SUITES@@ | @@TOTAL@@ |\n\nAll seven changed Dart files pass formatter verification and fatal-info,\nfatal-warning analysis. The Git whitespace check also passes.\n@@INPUTS@@ tracked package/application files have identical SHA-256 manifests\nbefore and after the accepted execution. The evidence verifier checks every\nindexed file against the recorded Git commit and tree, verifies all archive\nmembers, and independently recounts complete raw JSON reporter events.\n\nRuntime: genuine Flutter 3.47.8 / Dart 3.13.7. The official SDK archive and\nexecutables were hash-verified; all 204 hosted dependency archives were\nverified against the lockfiles, and offline enforced-lockfile resolution\npreserved the workspace lock. Runtime receipts, the reconstruction script,\npackage configuration and dependency hashes are retained.\n\nEach accepted suite runs in its own local Flutter process. An earlier grouped\nattempt exposed an incorrect null-anchor assumption in a newly reconstructed\ntest and stopped advancing while loading later suites. Its raw prefix and\nunchanged-source receipt are retained as an excluded attempt. The corrected\ntest compares the complete numeric caret/anchor tuple and asserts a collapsed\nselection. An earlier static-check failure concerned test accessors and braces\nonly; both the failed and corrected logs are preserved.\n\nThe first isolated ODT-open run passed its three visible cases but reported a\nDart compiler exit. That raw run remains excluded. A single-suite retry passed\ncleanly on the same commit and identical input manifest. The accepted receipt\ncombines the sixteen other successful process runs with this successful retry;\nthe prior receipt and both ODT logs are preserved.\n\nNo GitHub Actions, check-status or workflow queue was queried or awaited.\n\n## Earlier evidence and integration\n\nThe [table-layout record](../zotero-table-layout-20261121/README.md) retains\n**4,635 cases across 239 suites** on D112, including the two actual\nLibreOfficeDev saves of the six-table/nine-active-field fixture. Those are\nhistorical executions on their recorded source; they are not added to this\nfollow-up count.\n\nThe independently checked\n[incoming-source continuity record](../zotero-table-layout-20261121/main-source-continuity-52e72ca0.json)\nfinds 1,516 of 1,527 indexed baseline inputs unchanged at main `52e72ca`,\nenumerates all eleven changes and thirteen new relevant paths, and verifies\n344 archived members from incoming qualification. Incoming Word evidence\ncontains 6,665 engine passes, including 376 table/ODT continuation cases, plus\n73 final-source UI passes. The separate Mail shortcut record contains 46\npasses. These scopes overlap older work and remain separate.\n\nMain `cc797dc2` subsequently changed sixteen Markdown files only. Its scannable\nguides and detailed archives are retained. This follow-up changes three\nproduction Dart files in the editor/Studio; the engine library, tests and\ntools retain the incoming qualified identities. Both recovered implementation\nbranches and the independent continuity branch are retained as merge parents.\n\n## Reproduce and verify\n\nFrom a checkout containing the recorded commits:\n\n```sh\npython3 docs/validation/zotero-table-layout-20261121/verify_evidence.py \\\n  --index docs/validation/zotero-host-ownership-20261121/index.json\n```\n\nAfter preparing the recorded Flutter/Dart runtime and enforced workspace\ndependencies, set `FLUTTER_ROOT` and the corresponding `PUB_CACHE`, then run:\n\n```sh\npython3 docs/validation/zotero-host-ownership-20261121/run_local.py \\\n  --repo \"$PWD\" --out \"$PWD/../zotero-host-replay\" --phase all\n```\n\n`run_local.py` records the source commit/tree, complete input manifests,\ncommands, raw events and outcome receipts. The archived runtime bootstrap\nrecords the exact pinned downloads; its task-specific root can be adapted for\na new checkout. Archive verification requires no network or installed Flutter.\n\n## Remaining parity limits\n\nThis establishes local command, dialog and host-lifetime behavior. It does\nnot claim an installed Zotero/Word or supported-release Writer plugin session.\nThe external converter was not rerun after the incoming Word deserializer\nchange or this follow-up; the earlier development-converter results retain\ntheir original attribution.\n\nActive footnote separator modeling/layout/interchange remains the next\ndocument-fidelity milestone. Asymmetric or per-cell ODT padding, unsupported\ntable styles/borders and arbitrary native ODF rewriting remain outside the\nbounded editable profile. Installed Word/Zotero and Writer/Zotero interchange\nmust be qualified separately before claiming full plugin parity.\n"
substitutions={'SOURCE':source,'TREE':tree,'TOTAL':str(verified['distinct_cases']),'SUITES':str(verified['distinct_suites']),'STUDIO_SUITES':str(len(studio)),'STUDIO':str(sum(r['pass'] for r in studio)),'EDITOR_SUITES':str(len(editor)),'EDITOR':str(sum(r['pass'] for r in editor)),'INPUTS':f"{len(before):,}"}
for key,value in substitutions.items(): readme=readme.replace('@@'+key+'@@',value)
assert '@@' not in readme
(out/'README.md').write_text(readme)
qualification={'source_commit':source,'source_tree':tree,'accepted':True,'distinct_cases':verified['distinct_cases'],'distinct_suites':verified['distinct_suites'],'studio_cases':sum(r['pass'] for r in studio),'editor_cases':sum(r['pass'] for r in editor),'tracked_inputs_unchanged':len(before),'archives':index['archives'],'strict_static_checks':json.loads((work/'static-checks.json').read_text()),'not_executed':['GitHub Actions/check-status/workflow queues','Installed Zotero/Word or supported-release Writer plugin acceptance','External converter replay after the incoming Word deserializer change'],'excluded_attempts':['baseline: two expected stale-publication failures on previous production source','attempt-1: incomplete grouped run with an invalid test null-anchor assertion','initial static preflight: test accessor/braces corrections','first isolated ODT-open run: compiler error despite three visible passes; replaced by a successful same-source single-suite retry']}
(out/'qualification.json').write_text(json.dumps(qualification,indent=2,sort_keys=True)+'\n')
p=repo/'docs/validation/zotero-table-layout-20261121/README.md'
s=p.read_text()
old='Subsequent publication changes contain documentation and evidence.'
new='Later main integration includes separately qualified Mail, shortcut and Word\nVBA changes. Their exact applicability is recorded in\n[the incoming-source continuity audit](main-source-continuity-52e72ca0.json).\n[The host-ownership follow-up](../zotero-host-ownership-20261121/README.md)\nadds fresh focused dialog and Studio qualification on its own recorded source.\nThe 4,635 cases and converter saves above remain attributed to D112.'
assert s.count(old)==1
p.write_text(s.replace(old,new))
p=repo/'docs/zotero-validation.md'
s=p.read_text(); marker='# Zotero validation\n'
assert s.startswith(marker)
addition=f"""
## 21 November 2026 — host ownership and shortcut continuity

The [host-ownership follow-up](validation/zotero-host-ownership-20261121/README.md)
qualifies {verified['distinct_cases']} distinct passing cases across {verified['distinct_suites']} suites on
source `{source}`, with no failures, errors or skips.
It prevents delayed Zotero publication after leaving Word, protects reserved
citation chords and preserves focused native text editing. Two pre-fix
regressions reproduce the metadata mutation; both pass in the accepted source.
Seven changed Dart files pass strict static checks. All {len(before):,} tracked
package/application inputs remain unchanged during the accepted run.

Earlier totals below retain their recorded source scopes and are not added to
this follow-up. The new source-continuity audit separately verifies incoming
Word/Mail evidence and identifies exactly which older inputs changed. No
GitHub Actions queue or external converter replay is claimed by this increment.

"""
p.write_text(marker+addition+s[len(marker):])
p=repo/'docs/zotero-support.md'
s=p.read_text()
old='composition before starting a command.\n'
new='composition before starting a command.\n\nSwitching from Word to Mail or another app cancels the pending operation for\nthat Word view, including when you return before Zotero responds. Close and\nreopen the Zotero workspace to start a new operation. The citation and refresh\nchords remain reserved when customizing workspace shortcuts.\n'
assert s.count(old)==1
s=s.replace(old,new)
old='- undo transactions and source-bound saving.\n'
new='- undo transactions and source-bound saving.\n\nHosts that keep a document mounted across view changes can pass an optional\n`isCurrent` predicate to `showWordZoteroDialog`. Tie it to the originating\ndocument view and navigation generation; it stays true while Zotero\'s own\nmodal dialogs are open. A stale operation cannot publish changes or take\nediting focus after completion. See the\n[host-ownership qualification](validation/zotero-host-ownership-20261121/README.md).\n'
assert s.count(old)==1
p.write_text(s.replace(old,new))
summary={'source_commit':source,'source_tree':tree,'distinct_cases':verified['distinct_cases'],'distinct_suites':verified['distinct_suites'],'studio_cases':sum(r['pass'] for r in studio),'editor_cases':sum(r['pass'] for r in editor),'tracked_inputs':len(before),'archive_bytes':archive.stat().st_size,'members':len(members),'files':[str(p.relative_to(repo)) for p in sorted(out.iterdir())]}
(work/'packaging-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
