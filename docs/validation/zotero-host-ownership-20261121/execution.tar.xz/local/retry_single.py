#!/usr/bin/env python3
import datetime,hashlib,json,os,pathlib,shutil,subprocess,time
import run_local as helpers
work=pathlib.Path(__file__).resolve().parent
repo=work.parent/'quds_office_suite'
accepted=work/'accepted'
original=json.loads((accepted/'receipt.json').read_text())
assert original['accepted'] is False and original['source_inputs_unchanged'] is True
failed=[r for r in original['runs'] if r['exit_code']!=0]
assert len(failed)==1 and failed[0]['name']=='studio-studio_odt_open_test'
assert failed[0]['fail']==0 and len(failed[0]['errors'])==1
assert 'compiler exited unexpectedly' in failed[0]['errors'][0]['error']
prior=work/'attempt-2-compiler'
prior.mkdir(exist_ok=True)
(prior/'receipt.json').write_bytes((accepted/'receipt.json').read_bytes())
(prior/failed[0]['log']).write_bytes((accepted/failed[0]['log']).read_bytes())
out=work/'retry-odt-open';out.mkdir(exist_ok=True)
before=helpers.snapshot(repo)
assert before==json.loads((accepted/'source-inputs.before.json').read_text())
assert helpers.git(repo,'rev-parse','HEAD')==original['source_commit']
(out/'source-inputs.before.json').write_text(json.dumps(before,indent=2)+'\n')
tmp=out/'tmp';tmp.mkdir(exist_ok=True)
env=dict(os.environ,TMPDIR=str(tmp))
command=failed[0]['command']
cwd=repo/failed[0]['cwd']
log=out/failed[0]['log']
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
start=time.monotonic()
with log.open('wb') as stream:
    result=subprocess.run(command,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT)
events=helpers.parse_events(log,cwd,repo)
after=helpers.snapshot(repo)
(out/'source-inputs.after.json').write_text(json.dumps(after,indent=2)+'\n')
item={'name':failed[0]['name'],'cwd':failed[0]['cwd'],'command':command,'exit_code':result.returncode,'duration_seconds':round(time.monotonic()-start,3),'log':log.name,'log_sha256':helpers.digest(log),**events}
finished=datetime.datetime.now(datetime.timezone.utc).isoformat()
passed=(result.returncode==0 and events['pass']==3 and events['fail']==0 and events['skip']==0 and not events['errors'] and not events['unfinished_ids'] and len(events['done'])==1 and events['done'][0]['success'] is True and before==after)
record={'source_commit':original['source_commit'],'source_tree':original['source_tree'],'started_at_utc':started,'finished_at_utc':finished,'source_inputs_unchanged':before==after,'accepted':passed,'run':item}
(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
if passed:
    (accepted/log.name).write_bytes(log.read_bytes())
    original['runs']=[item if r['name']==item['name'] else r for r in original['runs']]
    original['accepted']=True
    original['finished_at_utc']=finished
    original['composition']={'original_receipt':'attempt-2-compiler/receipt.json','retry_receipt':'retry-odt-open/receipt.json','explanation':'Retain 16 successful process runs and replace only the compiler-error ODT run with its successful retry. All executions use the same source commit and identical tracked inputs.'}
    (accepted/'receipt.json').write_text(json.dumps(original,indent=2)+'\n')
shutil.rmtree(tmp)
print(json.dumps({'accepted':passed,'pass':events['pass'],'errors':len(events['errors']),'unchanged':before==after}),flush=True)
raise SystemExit(0 if passed else 1)
