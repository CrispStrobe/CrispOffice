
import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;
const w=OfficeNamespaces.w;
WmlDocument fixture(String body,{String prefix='w'}) {
  final p=OpcPackage.openBytes((DocxDocumentBuilder()..paragraph('Seed')).build());
  p.getPart('/word/document.xml')!.writeText('<$prefix:document xmlns:$prefix="$w" xmlns:x="urn:foreign"${prefix=='q' ? ' xmlns:w="urn:foreign-word-prefix"' : ''}><$prefix:body><$prefix:p>$body</$prefix:p><$prefix:sectPr/></$prefix:body></$prefix:document>');
  return WordDeserializer().readBytes(p.save());
}
void verify(bool condition,String message) { if(!condition) throw StateError(message); }
void main() {
  for(final sample in <(String,String,bool,String)>[
    ('valid','<w:rPr><w:position w:val="2"/></w:rPr>',false,'w'),
    ('aliased','<q:rPr><q:position q:val="2"/></q:rPr>',false,'q'),
    ('foreign-empty','<x:rPr/>',true,'w'),
    ('foreign-root','<x:rPr><w:position w:val="2"/></x:rPr>',true,'w'),
    ('duplicate-native','<w:rPr><w:position w:val="2"/></w:rPr><w:rPr><w:position w:val="4"/></w:rPr>',true,'w'),
    ('native-then-foreign','<w:rPr><w:position w:val="2"/></w:rPr><x:rPr><w:position w:val="4"/></x:rPr>',true,'w'),
    ('foreign-wrapper','<x:opaque><w:rPr><w:position w:val="4"/></w:rPr></x:opaque>',true,'w'),
    ('foreign-metadata-within-native','<w:rPr><x:opaque><w:rPr><w:position w:val="4"/></w:rPr></x:opaque><w:position w:val="2"/></w:rPr>',false,'w'),
  ]) {
    final (name,props,refuse,prefix)=sample;
    final doc=fixture('<$prefix:r><$prefix:t>First</$prefix:t></$prefix:r><$prefix:r>$props<$prefix:t>Second</$prefix:t></$prefix:r>',prefix:prefix);
    final runs=doc.paragraphs.single.inlines.whereType<WmlRun>().toList();
    final before=runs.map((r)=>r.properties.positionHalfPoints).toList();
    var refused=false;
    String? error;
    try { native.applyStep(doc,{'op':'runFormat','paragraph':0,'start':2,'end':8,'position':3,'bold':true}); }
    on UnsupportedError catch(e) { refused=true; error=e.toString(); }
    verify(refused==refuse,'$name refusal=$refused expected=$refuse');
    if(refuse) {
      verify(doc.paragraphs.single.inlines.length==2,'$name split before failure');
      verify(jsonEncode(runs.map((r)=>r.properties.positionHalfPoints).toList())==jsonEncode(before),'$name mutated position');
      verify(runs.every((r)=>!r.properties.bold),'$name mutated bold');
    } else {
      final saved=WordSerializer().writeBytes(doc);
      final reopened=WordDeserializer().readBytes(saved);
      final result=reopened.paragraphs.single.inlines.whereType<WmlRun>().toList();
      verify(result.map((r)=>r.text).join()=='FirstSecond','$name changed text');
      verify(result.where((r)=>r.properties.bold).every((r)=>r.properties.positionHalfPoints==6),'$name lost native value');
      verify(result.where((r)=>r.properties.bold).map((r)=>r.text).join()=='rstSec','$name changed selected range');
    }
    print(jsonEncode({'probe':name,'refused':refused,'atomic':refuse,'error':error}));
  }
  final detached=WmlDocument.empty(text:'Detached');
  detached.paragraphs.single.inlines.whereType<WmlRun>().single.properties.sourcePropertiesXml='<x:rPr xmlns:x="urn:foreign" xmlns:w="$w"><w:position w:val="2"/></x:rPr>';
  var refusedDetached=false;
  try {native.applyStep(detached,{'op':'runFormat','paragraph':0,'position':3});} on UnsupportedError {refusedDetached=true;}
  verify(refusedDetached,'detached foreign rPr accepted');
  print(jsonEncode({'probe':'detached-foreign-root','refused':refusedDetached}));
  for(final entry in <(String,WmlLineSpacingRule,double,bool,double)>[
    ('auto',WmlLineSpacingRule.auto,1,false,75.84),
    ('atLeast',WmlLineSpacingRule.atLeast,10,false,75.84),
    ('atLeast-floor',WmlLineSpacingRule.atLeast,120,false,120),
    ('exact',WmlLineSpacingRule.exact,12,false,12),
    ('compat',WmlLineSpacingRule.auto,1,true,15.84),
  ]) {
    final (name,rule,spacing,compat,expected)=entry;
    WmlRun r(String text,int hp)=>WmlRun(text:text,properties:WmlRunProps(fontSizeHalfPoints:24,positionHalfPoints:hp));
    final d=WmlDocument(sourceNoSpaceRaiseLower:compat,sections:[WmlSection(blocks:[
      WmlParagraph(properties:WmlParagraphProps(lineSpacingRule:rule,lineSpacing:spacing,spacingAfter:0),inlines:[r('A',0),r('B',60),r('C',-60)]),
      WmlParagraph(properties:WmlParagraphProps(lineSpacing:1,spacingAfter:0),inlines:[r('Next',0)])
    ])]);
    final lines=WordLayoutEngine(font:null).layout(d,updateFields:false).pages.single.lines;
    final first=lines.first;
    verify((first.height-expected).abs()<1e-9,'$name height ${first.height} !=$expected');
    verify((lines[1].y-first.y-expected).abs()<1e-9,'$name next line overlap');
    verify((first.glyphs[1].y-first.glyphs[0].y+30).abs()<1e-9,'$name raise displacement');
    verify((first.glyphs[2].y-first.glyphs[0].y-30).abs()<1e-9,'$name lower displacement');
    print(jsonEncode({'probe':'layout-$name','height':first.height,'nextLineY':lines[1].y,'glyphY':first.glyphs.map((g)=>g.y).toList()}));
  }
}
