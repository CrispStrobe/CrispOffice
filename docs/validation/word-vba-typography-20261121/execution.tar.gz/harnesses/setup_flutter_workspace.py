from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import yaml

runtime = Path(__file__).resolve().parent
repo = runtime.parent / 'quds_office_suite'
workspace = runtime / 'workspace'
workspace.mkdir(exist_ok=True)
manifest = yaml.safe_load((repo / 'pubspec.yaml').read_text())
package_names = manifest['workspace'] + ['third_party/enough_mail']
for name in ['pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml']:
    shutil.copy2(repo / name, workspace / name)
skip = {'.dart_tool', 'build', 'pubspec.lock'}
for name in sorted(package_names, key=lambda value: value.count('/')):
    source = repo / name
    if not source.is_dir():
        source = runtime / name
    destination = workspace / name
    destination.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / 'pubspec.yaml', destination / 'pubspec.yaml')
    for child in source.iterdir():
        if child.name in skip or child.name == 'pubspec.yaml':
            continue
        relative = f'{name}/{child.name}'
        if any(item == relative or item.startswith(relative + '/') for item in package_names):
            continue
        target = destination / child.name
        if not target.exists() and not target.is_symlink():
            target.symlink_to(child, target_is_directory=child.is_dir())
print(workspace)
