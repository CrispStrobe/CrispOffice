from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import yaml

runtime = Path(__file__).resolve().parent
cache = runtime.parent / 'quds_dart_runtime/pub-cache'
archives = runtime / 'sdk-package-archives'
archives.mkdir(exist_ok=True)
hashes = cache / 'hosted-hashes/pub.dev'
hashes.mkdir(parents=True, exist_ok=True)
packages = yaml.safe_load((runtime / 'flutter/packages/flutter_tools/pubspec.lock').read_text())['packages']
missing = [(name, value) for name, value in packages.items()
           if value['source'] == 'hosted' and not
           (cache / 'hosted/pub.dev' / f"{name}-{value['version']}").is_dir()]


def download(item):
    name, value = item
    version = value['version']
    stem = f'{name}-{version}'
    archive = archives / (stem + '.tar.gz')
    url = f'https://pub.dev/api/archives/{stem}.tar.gz'
    subprocess.run(['curl', '-fsSL', '--connect-timeout', '10', '--max-time', '90', '--retry', '1', url, '-o', str(archive)], check=True)
    actual = hashlib.sha256(archive.read_bytes()).hexdigest()
    expected = value['description']['sha256']
    assert actual == expected, (name, actual, expected)
    destination = cache / 'hosted/pub.dev' / stem
    destination.mkdir()
    with tarfile.open(archive) as data:
        data.extractall(destination, filter='data')
    (hashes / (stem + '.sha256')).write_text(actual)
    return {'package': name, 'version': version, 'url': url, 'sha256': actual, 'bytes': archive.stat().st_size}


records = []
with ThreadPoolExecutor(max_workers=6) as pool:
    futures = [pool.submit(download, item) for item in missing]
    for task in as_completed(futures):
        records.append(task.result())
        if len(records) % 10 == 0:
            print(f'Verified {len(records)}/{len(missing)} SDK tool package archives', flush=True)
(runtime / 'sdk-package-archive-receipt.json').write_text(json.dumps(sorted(records, key=lambda item: item['package']), indent=2) + '\n')
print(f'Cached {len(records)} official SDK-pinned packages; all archive hashes verified', flush=True)
