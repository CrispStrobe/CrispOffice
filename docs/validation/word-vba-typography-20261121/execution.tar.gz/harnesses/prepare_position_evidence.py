#!/usr/bin/env python3
"""Assemble source-bound Word position evidence in scratch, never in the repo.

Re-run after the final Word/intake gates finish. Optional --follow-up paths add
the separately preserved format correction and source-equivalence records.
Generated JavaScript, SDKs, package caches and unrelated artifacts are excluded.
"""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile


ROOT = Path('/workspace/scratch/65a76194ed76')
REPO = ROOT / 'quds_office_suite'
OUT = ROOT / 'position-evidence-staging'
PAYLOAD = OUT / 'execution'
TREE = '479bfb1adc542c5f46be270e6d35c3f5c0be1b4d'
EXTENSIONS = {'.json', '.jsonl', '.log', '.txt', '.stderr', '.stdout',
              '.py', '.dart', '.diff', '.patch', '.sh', '.yaml', '.lock', '.bas', '.md'}
EXCLUDED_PARTS = {'__pycache__', 'build', 'pub-cache', 'dart-sdk', 'sdk-package-archives'}
SENSITIVE = re.compile(rb'(?:ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[A-Z0-9]{16}|Authorization:\s*Bearer\s+[A-Za-z0-9_-]{16,})')


def read_json(path):
    return json.loads(path.read_text())


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--follow-up', action='append', type=Path, default=[])
    parser.add_argument('--publication-integration', action='append', type=Path, default=[])
    parser.add_argument('--final', action='store_true', help='Require all completed acceptance gates and mark the source-bound record final.')
    args = parser.parse_args()
    PAYLOAD.mkdir(parents=True, exist_ok=True)
    entries = {}

    def write(relative, data, origin):
        if SENSITIVE.search(data):
            raise SystemExit(f'Credential-like content requires review: {relative}')
        target = PAYLOAD / relative
        if not target.resolve().is_relative_to(PAYLOAD):
            raise SystemExit('Unsafe archive destination')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        entries[str(relative)] = {'bytes': len(data), 'sha256': sha256(data), 'origin': origin}

    def copy(source, relative):
        if not source.resolve().is_relative_to(ROOT):
            raise SystemExit(f'Outside approved workspace: {source}')
        write(relative, source.read_bytes(), str(source.relative_to(ROOT)))

    def frozen_source(relative):
        return subprocess.check_output(['git', 'show', f'{TREE}:{relative}'], cwd=REPO)

    def copy_tree(source, prefix):
        if not source.is_dir():
            return
        for path in sorted(source.rglob('*')):
            relative = path.relative_to(source)
            if path.is_file() and not EXCLUDED_PARTS.intersection(relative.parts) and (path.suffix in EXTENSIONS or path.name == 'SHA256SUMS'):
                copy(path, Path(prefix) / relative)

    # Complete, source-frozen editor execution only; development readiness is omitted.
    editor_source = ROOT / 'quds_flutter_runtime/editor-qualification'
    editor = read_json(editor_source / 'receipt.json')
    assert editor['exit_code'] == 0 and not editor['source_files_changed_during_check']
    assert editor['tree_before'] == TREE == editor['tree_after']
    copy_tree(editor_source, 'editor')

    portable_source = ROOT / 'position-validation/portable'
    portable = read_json(portable_source / 'summary.json')
    assert portable['passed'] and not portable['sourceChanged']
    copy_tree(portable_source, 'portable')
    corpus = read_json(portable_source / 'corpus-vm.json')
    example = read_json(portable_source / 'example-vm.json')
    assert (portable_source / 'example-vm.json').read_bytes() == (portable_source / 'example-js.json').read_bytes()
    assert (portable_source / 'corpus-vm.json').read_bytes() == (portable_source / 'corpus-js.json').read_bytes()
    assert '3.13.7' in (portable_source / 'dart-version.txt').read_text()
    for name, path in [
        ('word_font_position.bas', 'packages/quds_office_engine/example/macros/word_font_position.bas'),
        ('word_font_position_v1.json', 'packages/quds_office_engine/test/fixtures/vba_conformance/word_font_position_v1.json'),
    ]:
        write('portable/inputs/' + name, frozen_source(path), f'git-tree:{TREE}:{path}')

    review_source = ROOT / 'intake-validation/position-review'
    review = read_json(review_source / 'probe-receipt.json')
    assert review['exit_code'] == 0 and review['before'] == review['after']
    assert 'quds_flutter_runtime/flutter/bin/cache/dart-sdk/bin/dart' in review['command'][0]
    review_events = [json.loads(line) for line in (review_source / 'probe.stdout.jsonl').read_text().splitlines() if line.strip()]
    review_source_matches = {name: sha256(frozen_source(name)) == digest
                             for name, digest in review['after'].items()}
    assert all(review_source_matches.values())
    copy_tree(review_source, 'independent-review')
    write('independent-review/frozen-source-binding.json', (json.dumps({
        'probe_count': len(review_events), 'dart_version': '3.13.7',
        'dart_executable_sha256': editor['runtime_files']['bin/cache/dart-sdk/bin/dart'],
        'source_tree': TREE, 'recorded_sources_match_frozen_tree': review_source_matches,
        'scope': 'The probe receipt hashes three relevant production files. The archive manifest separately binds the probe source and raw output; it is not a whole-engine source snapshot.',
    }, indent=2) + '\n').encode(), 'derived from probe receipt and frozen source')

    # Copy a running gate only after its completion summary and after-snapshot exist.
    statuses = {}
    for name, source in [
        ('word-tests', ROOT / 'position-validation/word-final/tests'),
        ('incoming-tests', ROOT / 'intake-validation/final-frozen'),
    ]:
        if not (source / 'summary.json').is_file() or not (source / 'source-after.json').is_file():
            statuses[name] = {'state': 'pending', 'source': str(source.relative_to(ROOT))}
            continue
        summary = read_json(source / 'summary.json')
        copy_tree(source, name)
        passed = (summary.get('exit_code') == 0 and summary.get('done', {}).get('success') is True
                  and summary.get('failures', 0) == 0 and not summary.get('errors')
                  and not summary.get('source_changed') and not summary.get('source_added'))
        statuses[name] = {'state': 'passed' if passed else 'failed', 'summary': summary}

    analysis_source = ROOT / 'position-validation/word-final/analysis'
    if (analysis_source / 'summary.json').is_file():
        analysis = read_json(analysis_source / 'summary.json')
        copy_tree(analysis_source, 'analysis-original')
        analyze_commands = [item for item in analysis['commands'] if item['label'].startswith('analyze-')]
        format_commands = [item for item in analysis['commands'] if item['label'] == 'format']
        statuses['strict-analysis'] = {'state': 'passed' if analyze_commands and all(item['exit_code'] == 0 for item in analyze_commands) and not analysis['source_changed'] else 'failed', 'targets': len(analyze_commands)}
        statuses['original-format-check'] = {'state': 'passed' if all(item['exit_code'] == 0 for item in format_commands) else 'failed-preserved', 'disposition': 'The exact one-file formatter-only correction is a separate follow-up; this original failure is retained.'}
    else:
        statuses['strict-analysis'] = {'state': 'pending'}
        statuses['original-format-check'] = {'state': 'pending'}

    follow_ups = []
    format_correction = None
    for index, source in enumerate(args.follow_up, 1):
        source = source.resolve()
        prefix = Path('follow-up') / f'{index:02d}-{source.name}'
        if source.is_dir():
            copy_tree(source, prefix)
            summary_path = source / 'summary.json'
            if summary_path.is_file():
                candidate = read_json(summary_path)
                if candidate.get('formatting_only') is True:
                    format_correction = candidate
        elif source.is_file() and source.suffix in EXTENSIONS:
            copy(source, prefix)
        else:
            raise SystemExit(f'Unsupported follow-up evidence: {source}')
        follow_ups.append(str(source.relative_to(ROOT)))
    if format_correction is not None:
        statuses['format-correction'] = {
            'state': 'passed' if format_correction.get('passed') is True
                     and format_correction.get('production_sources_byte_identical') is True else 'failed',
            'passing': format_correction.get('passing'),
            'removed_optional_trailing_comma': format_correction.get('removed_optional_trailing_comma'),
        }
        if statuses['format-correction']['state'] == 'passed':
            statuses['original-format-check']['resolved_by'] = 'format-correction'

    integrations = []
    for index, source in enumerate(args.publication_integration, 1):
        source = source.resolve()
        if not source.is_dir() or not source.is_relative_to(ROOT):
            raise SystemExit(f'Expected a publication integration directory in scratch: {source}')
        copy_tree(source, Path('publication-integration') / f'{index:02d}-{source.name}')
        record_path = source / 'receipt.json'
        if not record_path.is_file():
            record_path = source / 'summary.json'
        record = read_json(record_path) if record_path.is_file() else None
        integrations.append({'source': str(source.relative_to(ROOT)), 'receipt': record})

    # Preserve the demonstrated cache failures and focused correction separately
    # from the source-frozen publication acceptance gate.
    cache_regressions = {}
    for name in ['cache-red', 'cache-green']:
        source = ROOT / 'position-validation' / name
        if (source / 'receipt.json').is_file() and (source / 'source-after.json').is_file():
            copy_tree(source, Path('renderer-regression') / name)
            cache_regressions[name] = read_json(source / 'receipt.json')
    copy_tree(ROOT / 'position-validation/body-cache-fix', 'renderer-regression/fix-review')
    copy_tree(ROOT / 'position-validation/publication-frontier', 'reconciliation/publication-frontier')

    for source, relative in [
        (ROOT / 'run_position_portable.py', 'harnesses/run_position_portable.py'),
        (ROOT / 'prepare_position_evidence.py', 'harnesses/prepare_position_evidence.py'),
        (ROOT / 'finalize_word_position_record.py', 'harnesses/finalize_word_position_record.py'),
        (ROOT / 'position-validation/run_word_format_followup.py', 'harnesses/run_word_format_followup.py'),
        (ROOT / 'position-validation/run_publication_odt.py', 'harnesses/run_publication_odt.py'),
        (ROOT / 'position-validation/run_word_final.py', 'harnesses/run_word_final.py'),
        (ROOT / 'position-validation/run_word_analysis.py', 'harnesses/run_word_analysis.py'),
        (ROOT / 'intake-validation/run_frozen_intake.py', 'harnesses/run_frozen_intake.py'),
        (ROOT / 'quds_flutter_runtime/run_editor_checks.py', 'harnesses/run_editor_checks.py'),
        (ROOT / 'quds_flutter_runtime/run_editor_checks_frozen.py', 'harnesses/run_editor_checks_original.py'),
        (ROOT / 'quds_flutter_runtime/setup_workspace.py', 'harnesses/setup_flutter_workspace.py'),
        (ROOT / 'quds_flutter_runtime/cache_sdk_tools.py', 'harnesses/cache_sdk_tools.py'),
        (ROOT / 'quds_flutter_runtime/run-editor-tests.sh', 'harnesses/run-editor-tests.sh'),
        (ROOT / 'quds_flutter_runtime/env.sh', 'runtime/flutter-env.sh'),
        (ROOT / 'quds_flutter_runtime/archive-verification.json', 'runtime/flutter-archive-verification.json'),
        (ROOT / 'quds_flutter_runtime/sdk-package-archive-receipt.json', 'runtime/sdk-package-archive-receipt.json'),
        (ROOT / 'quds_flutter_runtime/canonical-package-roots.json', 'runtime/canonical-package-roots.json'),
        (ROOT / 'quds_flutter_runtime/workspace/.dart_tool/package_config.json', 'runtime/flutter-package-config.json'),
        (ROOT / 'quds_flutter_runtime/workspace/.dart_tool/package_graph.json', 'runtime/flutter-package-graph.json'),
        (REPO / '.dart_tool/package_config.json', 'runtime/engine-package-config.json'),
        (ROOT / 'quds_flutter_runtime/logs/pub-get-direct.log', 'runtime/workspace-enforced-resolution.log'),
        (ROOT / 'quds_flutter_runtime/logs/sdk-tools-pub-get-offline-corrected.log', 'runtime/sdk-enforced-resolution.log'),
        (ROOT / 'quds_dart_runtime/environment.json', 'runtime/dependency-resolution-dart-3.14.1.json'),
    ]:
        if source.is_file():
            copy(source, relative)
    write('runtime/repository-pubspec.lock', frozen_source('pubspec.lock'), f'git-tree:{TREE}:pubspec.lock')
    for name in ['remote-intake-before-final.json', 'remote-intake-final-refresh.json',
                 'remote-intake-accounted.json', 'frozen-publication.json',
                 'publication-intake-checkpoint.json', 'final-code-checkpoint.json']:
        source = ROOT / 'position-validation' / name
        if source.is_file():
            copy(source, Path('reconciliation') / name)

    checkpoint_path = ROOT / 'position-validation/final-code-checkpoint.json'
    final_checkpoint = read_json(checkpoint_path) if checkpoint_path.is_file() else None
    if args.final:
        assert final_checkpoint is not None, 'Missing final code checkpoint'
        assert all(statuses[name]['state'] == 'passed' for name in
                   ['word-tests', 'incoming-tests', 'strict-analysis', 'format-correction'])
        final_editor = next((item['receipt'] for item in integrations
                             if item['source'].endswith('/publication-editor')), None)
        final_odt = next((item['receipt'] for item in integrations
                          if item['source'].endswith('/publication-odt')), None)
        assert final_editor is not None and final_odt is not None, 'Missing publication integration gates'
        assert final_editor['exit_code'] == 0 and not final_editor['failed_tests']
        assert not final_editor['source_files_changed_during_check']
        assert final_editor['tree_before'] == final_editor['tree_after'] == final_checkpoint['tree']
        assert final_editor['head_before'] == final_editor['head_after'] == final_checkpoint['remote']
        assert final_editor['flutter']['frameworkVersion'] == '3.47.8'
        assert final_editor['flutter']['dartSdkVersion'].startswith('3.13.7')
        assert final_odt['engine_gate_passed'] is True and final_odt['failures'] == 0
        assert not final_odt['source_changed'] and not final_odt['source_added'] and not final_odt['source_removed']
        assert cache_regressions['cache-green']['exitCode'] == 0
        assert not cache_regressions['cache-green']['sourceChanged']
        correction = read_json(ROOT / 'position-validation/body-cache-fix/source-qualification.json')
        assert correction['passed'] is True and correction['source_stable'] is True

    qualification = {
        'kind': 'source-bound-local-qualification' if args.final else 'scratch-staging-draft',
        'source_tree': TREE,
        'source_tree_role': 'Initial broad Word/native, incoming and portable qualification',
        'final_code_checkpoint': final_checkpoint,
        'local_qualified_head': editor['head_before'],
        'published_identical_tree_head': '5ebd69bacd789c89e2ee6d06a9807ecf22cac764',
        'editor_tests': editor['completed_tests'], 'editor_source_files': editor['source_file_count'],
        'portable_corpus_cases': corpus['caseCount'], 'example_native_operations': example['operations'],
        'portable_vm_js_receipts_identical': True, 'independent_probes': len(review_events),
        'statuses': statuses, 'format_follow_up_sources': follow_ups,
        'publication_integrations': integrations,
        'renderer_regression_receipts': cache_regressions,
        'finalized': args.final,
        'notes': [
            'All final execution cohorts use pinned Dart 3.13.7 / Flutter 3.47.8 where applicable.',
            'Dart 3.14.1 was used for initial engine dependency resolution and development readiness only; its package-config generator field is retained honestly. Earlier development test logs are omitted.',
            'The original failed format check remains separate from the later formatter-only correction and affected-suite rerun.',
            'Source/test counts and VM/JavaScript repetitions are separate evidence, not a VBA parity percentage or an aggregate unique-test count.',
        ],
    }
    write('qualification-status.json', (json.dumps(qualification, indent=2) + '\n').encode(), 'derived staging status')

    def test_state(name):
        value = statuses[name]
        if value['state'] == 'pending':
            return '**Pending completion receipt**'
        summary = value['summary']
        return f"{value['state']}: {summary.get('passing', summary.get('visible_tests', '?'))} passed across {summary.get('suites_requested', '?')} files; {summary.get('failures', 0)} failures"

    format_result = ('**Follow-up receipt pending**' if format_correction is None else
                     f"{statuses['format-correction']['state']}: {format_correction.get('passing')} cases; strict analysis and format check passed; production sources byte-identical")

    draft = f'''# Word VBA native baseline positioning — qualification draft

This scratch draft is not the final publication record. Completion and format
correction records must be reviewed before it is copied into the repository.

## Implemented contract

`Font.Position` now emits a native `docx.runFormat` position write through the
existing paragraph, typed Font alias, nested `With`, named helper and independent
header/footer selectors. Positive points raise text, negative points lower it,
and an explicit zero overrides inherited positioning. Font size and authored
UTF-16 text are preserved. Position combines independently with existing
superscript/subscript behavior.

The VBA source property accepts exact whole points in -1584..1584. This envelope
is a Quds dialect restriction, not Microsoft's full range. Native JSON writes
accept exact half-points within the same envelope; DOCX stores signed half-point
`w:position` values. Sparse native ownership preserves unrelated and foreign
metadata, while ambiguous/duplicate/foreign ownership is refused atomically.
Automatic and minimum line spacing include positioned text; exact line spacing
retains its fixed box. Imported `w:compat/w:noSpaceRaiseLower` suppresses that
expansion. Native/PDF/editor display and copy/history/proofing fingerprints
retain position.

No readable Position property, Selection/arbitrary text range, document-aware
source execution, embedded VBA host, new ODT/RTF position interchange, or
installed Microsoft Word differential qualification is claimed. Empty text
still refuses run formatting rather than changing paragraph-mark formatting.

The source contract and references are in `docs/VBA_WORD_MACROS.md`, under
"Baseline position without resizing text". The committed example is
`packages/quds_office_engine/example/macros/word_font_position.bas`.

## Source identity and reconciliation

Frozen source tree: `{TREE}`.
Editor gate local commit: `{editor['head_before']}`. The same tree was published
at `5ebd69bacd789c89e2ee6d06a9807ecf22cac764`; the reconciliation records retain
the original local-to-remote commit mapping. Final merge/main identities and
the later formatter-only formatting correction must be completed by the
publication owner. GitHub Actions were not awaited.

## Executed local evidence

| Check | Recorded result |
| --- | --- |
| Pinned Flutter editor cohort, five files | {editor['completed_tests']} passed; {editor['source_file_count']} captured source/test/font files unchanged |
| Complete committed BAS example, VM and JavaScript | Byte-identical successful receipts; {example['operations']} operations, native recording/replay, rollback, policy refusals and inert-part preservation |
| Independent position corpus, VM and JavaScript | {corpus['caseCount']} cases; byte-identical complete receipts |
| Independent native ownership/spacing probes | {len(review_events)} probes, pinned Dart 3.13.7; recorded production hashes match the frozen tree |
| Word/native engine cohort, 31 files | {test_state('word-tests')} |
| Incoming ODT/Word branch cohort, 25 files | {test_state('incoming-tests')} |
| Strict engine/new-test/tool analysis | {statuses['strict-analysis']['state']}; see original command receipts |
| Initial format check | {statuses['original-format-check']['state']}; one test-file wrapping and optional trailing-comma difference preserved |
| Formatter correction and affected 33-case rerun | {format_result} |
| Later publication integrations | {len(integrations)} separately bound evidence directories; each retains its own head/tree and source inventory |
| Body-text renderer regression demonstration and focused correction | {len(cache_regressions)} separate receipts; failures before the fix and controls are preserved, never counted as acceptance passes |

All final execution uses the repository-pinned Flutter 3.47.8 and bundled Dart
3.13.7 where applicable. The standalone engine dependency graph was initially
resolved by Dart 3.14.1 against exactly matching repository lock identities;
its generator metadata and initial setup provenance remain separately labeled.
Earlier development runs are not final frozen-source qualification.

The five editor files cover position formatting/render grouping/history and
stale proofing, existing Unicode painting, small capitals, incoming ODT image
rendering and selection-path cache invalidation. Corpus fixture runs and
cross-host repetitions must not be added to unique test counts or interpreted
as a VBA parity percentage.

## Archive and refresh

`execution.tar.gz` contains raw execution logs, commands, source inventories,
runtime/dependency provenance and harness source. `archive-manifest.json`
records every archive payload file's byte count and SHA-256, plus the archive
digest. No generated JavaScript/maps, SDK binaries, downloaded package archives,
package caches, publish payloads, credentials or unrelated artifacts are included.

Rebuild this staging directory after the pending gates finish:

```bash
python3 /workspace/scratch/65a76194ed76/prepare_position_evidence.py
```

Append an explicit completed correction/equivalence evidence directory with
`--follow-up /workspace/scratch/65a76194ed76/path-to-follow-up`. Add a later
source-bound editor/renderer qualification directory with
`--publication-integration /workspace/scratch/65a76194ed76/path-to-integration`.
The initial tree's example, corpus and lock are read from that immutable Git
tree, not from a later checkout. Integration receipts never relabel the original
31 editor cases as having run against a newer source tree. The builder
leaves the source repository unchanged. This draft must be finalized before
publication; the original format failure remains part of the audit trail.
'''
    (OUT / 'README.draft.md').write_text(draft)
    (OUT / 'qualification-status.json').write_text(json.dumps(qualification, indent=2) + '\n')
    payload_manifest = {'source_tree': TREE, 'final_code_checkpoint': final_checkpoint, 'finalized': args.final, 'payload_file_count': len(entries), 'files': dict(sorted(entries.items())), 'excluded': ['generated JavaScript/maps/deps', 'SDK binaries', 'package cache', 'downloaded archives', 'credentials', 'unrelated files', 'incomplete running gate files', 'earlier development tests']}
    manifest_bytes = (json.dumps(payload_manifest, indent=2) + '\n').encode()
    (PAYLOAD / 'manifest.json').write_bytes(manifest_bytes)
    archive = OUT / 'execution.tar.gz'
    with archive.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as bundle:
        for relative in sorted([*entries.keys(), 'manifest.json']):
            path = PAYLOAD / relative
            info = bundle.gettarinfo(str(path), arcname=relative)
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            info.mode = 0o644
            with path.open('rb') as stream:
                bundle.addfile(info, stream)
    archive_bytes = archive.read_bytes()
    archive_manifest = {
        **payload_manifest,
        'built_utc': datetime.now(timezone.utc).isoformat(),
        'archive': {'name': archive.name, 'bytes': len(archive_bytes), 'sha256': sha256(archive_bytes)},
        'embedded_manifest_sha256': sha256(manifest_bytes),
        'archive_entries': len(entries) + 1,
    }
    (OUT / 'archive-manifest.json').write_text(json.dumps(archive_manifest, indent=2) + '\n')
    # Verify exact archive membership and bytes after compression.
    with tarfile.open(archive) as bundle:
        assert set(bundle.getnames()) == set(entries) | {'manifest.json'}
        for name, entry in entries.items():
            content = bundle.extractfile(name).read()
            assert len(content) == entry['bytes'] and sha256(content) == entry['sha256']
    print(json.dumps({'directory': str(OUT), 'archive_bytes': len(archive_bytes), 'archive_sha256': sha256(archive_bytes), 'payload_files': len(entries), 'statuses': {name: value['state'] for name, value in statuses.items()}, 'follow_up_sources': follow_ups, 'publication_integrations': len(integrations)}, indent=2))


if __name__ == '__main__':
    main()
