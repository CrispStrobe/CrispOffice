from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

runtime = Path(__file__).resolve().parent
repo = runtime.parent / 'quds_office_suite'
workspace = runtime / 'workspace'
output = runtime / 'editor-qualification'
output.mkdir(exist_ok=True)
selected = [
    'word_position_test.dart',
    'paint_run_text_unicode_test.dart',
    'word_small_caps_test.dart',
    'word_odt_image_load_test.dart',
    'word_selection_path_cache_test.dart',
]
packages = ['quds_office_engine', 'quds_office_editor', 'legacy_doc_parser', 'quds_reports']


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def snapshot():
    paths = {repo / name for name in ['.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml']}
    for package in packages:
        root = repo / 'packages' / package
        paths.add(root / 'pubspec.yaml')
        if (root / 'analysis_options.yaml').exists():
            paths.add(root / 'analysis_options.yaml')
        paths.update(p for p in (root / 'lib').rglob('*') if p.is_file())
    for directory in ['packages/quds_office_editor/fonts', 'packages/quds_office_editor/example/fonts']:
        paths.update(p for p in (repo / directory).rglob('*') if p.is_file())
    paths.update(repo / 'packages/quds_office_editor/test' / name for name in selected)
    return {str(path.relative_to(repo)): digest(path) for path in sorted(paths)}


environment = os.environ.copy()
environment.update({
    'FLUTTER_ROOT': str(runtime / 'flutter'),
    'PUB_CACHE': str(runtime.parent / 'quds_dart_runtime/pub-cache'),
    'TMPDIR': str(runtime / 'tmp'),
    'XDG_CONFIG_HOME': str(runtime / 'config'),
    'XDG_CACHE_HOME': str(runtime / 'cache'),
    'XDG_DATA_HOME': str(runtime / 'data'),
    'DART_SUPPRESS_ANALYTICS': 'true',
    'FLUTTER_SUPPRESS_ANALYTICS': 'true',
    'DASH__SUPPRESS_ANALYTICS': 'true',
    'CI': 'true',
})
environment['PATH'] = str(runtime / 'flutter/bin') + ':' + environment['PATH']
assert (workspace / 'pubspec.lock').read_bytes() == (repo / 'pubspec.lock').read_bytes()
before = snapshot()
head_before = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
tree_before = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=repo, text=True).strip()
(output / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
command = [str(runtime / 'flutter/bin/flutter'), '--no-version-check', '--packages=' + str(workspace / '.dart_tool/package_config.json'), 'test', '--no-pub', '--concurrency=1', '--reporter=json']
command.extend(str(repo / 'packages/quds_office_editor/test' / name) for name in selected)
started = datetime.now(timezone.utc).isoformat()
begin = time.monotonic()
with (output / 'tests.stdout.jsonl').open('wb') as stdout, (output / 'tests.stderr.log').open('wb') as stderr:
    result = subprocess.run(command, cwd=repo / 'packages/quds_office_editor', env=environment, stdout=stdout, stderr=stderr)
after = snapshot()
(output / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
changed = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
events = []
for line in (output / 'tests.stdout.jsonl').read_text().splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        pass
completed = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden') and not e.get('skipped')]
record = {
    'command': command, 'cwd': str(repo / 'packages/quds_office_editor'),
    'started_utc': started, 'exit_code': result.returncode, 'seconds': round(time.monotonic() - begin, 3),
    'head_after': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'head_before': head_before,
    'tree_before': tree_before,
    'tree_after': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=repo, text=True).strip(),
    'source_file_count': len(before), 'source_files_changed_during_check': changed,
    'completed_tests': len(completed), 'failed_tests': [e for e in completed if e.get('result') != 'success'],
    'done_events': [e for e in events if e.get('type') == 'done'],
    'flutter': json.loads(subprocess.check_output([str(runtime / 'flutter/bin/flutter'), '--no-version-check', '--version', '--machine'], env=environment, text=True)),
    'package_config_sha256': digest(workspace / '.dart_tool/package_config.json'),
    'editor_package_config_sha256': digest(repo / 'packages/quds_office_editor/.dart_tool/package_config.json'),
    'editor_package_graph_sha256': digest(repo / 'packages/quds_office_editor/.dart_tool/package_graph.json'),
    'root_package_config_sha256': digest(repo / '.dart_tool/package_config.json'),
    'root_lock_sha256': digest(repo / 'pubspec.lock'),
    'tests_stdout_sha256': digest(output / 'tests.stdout.jsonl'),
    'tests_stderr_sha256': digest(output / 'tests.stderr.log'),
    'source_before_sha256': digest(output / 'source-before.json'),
    'source_after_sha256': digest(output / 'source-after.json'),
    'runtime_files': {
        name: digest(runtime / 'flutter' / name)
        for name in [
            'bin/cache/dart-sdk/bin/dart',
            'bin/cache/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot',
            'bin/cache/artifacts/engine/linux-x64/flutter_tester',
            'bin/cache/flutter_tools.snapshot',
            'packages/flutter_tools/pubspec.yaml',
            'packages/flutter_tools/pubspec.lock',
        ]
    },
}
(output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if result.returncode == 0 and not changed else 1)
