#!/usr/bin/env bash
set -euo pipefail
source /workspace/scratch/65a76194ed76/quds_flutter_runtime/env.sh
cd /workspace/scratch/65a76194ed76/quds_office_suite/packages/quds_office_editor
exec "$FLUTTER_ROOT/bin/flutter" --no-version-check --packages="$QUDS_FLUTTER_WORKSPACE/.dart_tool/package_config.json" test --no-pub --concurrency=1 "$@"
