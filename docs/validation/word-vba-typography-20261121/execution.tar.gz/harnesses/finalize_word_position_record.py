#!/usr/bin/env python3
"""Finalize the repository qualification record from completed local evidence."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess

ROOT = Path('/workspace/scratch/65a76194ed76')
REPO = ROOT / 'quds_office_suite'
OUT = REPO / 'docs/validation/word-vba-typography-20261121'
STAGING = ROOT / 'position-evidence-staging'
CORE_TREE = '479bfb1adc542c5f46be270e6d35c3f5c0be1b4d'
POSITION_TEST = 'packages/quds_office_engine/test/office_vba_word_position_test.dart'
ODT_TEST = 'packages/quds_office_engine/test/odt_reader_styles_test.dart'
RENDERER = 'packages/quds_office_editor/lib/src/editor_word/render_word_canvas.dart'

def read(relative):
    return json.loads((ROOT / relative).read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()

def differences(manifest):
    result = []
    for name, old in manifest.items():
        path = REPO / name
        new = digest(path) if path.is_file() else None
        if old != new:
            result.append({'path': name, 'qualified_sha256': old, 'current_sha256': new})
    return result

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

word = read('position-validation/word-final/tests/summary.json')
incoming = read('intake-validation/final-frozen/summary.json')
formatting = read('position-validation/word-final/format-followup/summary.json')
odt = read('position-validation/publication-odt/summary.json')
editor = read('position-validation/publication-editor/receipt.json')
portable = read('position-validation/portable/summary.json')
checkpoint = read('position-validation/final-code-checkpoint.json')
frontier = read('position-validation/publication-frontier/captured-frontier-postmerge.json')
original_editor = read('quds_flutter_runtime/editor-qualification/receipt.json')

assert word['passing'] == 998 and word['frozen_gate_passed']
assert incoming['passing'] == 716 and incoming['frozen_gate_passed']
assert formatting['passed'] and formatting['passing'] == 33
assert formatting['production_sources_byte_identical']
assert odt['engine_gate_passed'] and odt['passing'] == 46
assert portable['passed'] and not portable['sourceChanged']
assert editor['exit_code'] == 0 and not editor['failed_tests']
assert not editor['source_files_changed_during_check']
assert editor['done_events'] and all(item['success'] for item in editor['done_events'])
assert editor['tree_before'] == editor['tree_after'] == checkpoint['tree']
assert git('rev-parse', 'HEAD^{tree}') == checkpoint['tree']

word_changes = differences(read('position-validation/word-final/tests/source-after.json'))
incoming_changes = differences(read('intake-validation/final-frozen/source-after.json'))
assert {item['path'] for item in word_changes} == {POSITION_TEST, ODT_TEST}
assert {item['path'] for item in incoming_changes} == {POSITION_TEST, ODT_TEST}
assert not differences(read('position-validation/publication-odt/source-after.json'))
assert not differences(read('position-validation/publication-editor/source-after.json'))
portable_changes = differences(read('position-validation/portable/sources-after.json'))
assert {item['path'] for item in portable_changes} == {RENDERER}
assert digest(REPO / POSITION_TEST) == read('position-validation/word-final/format-followup/source-after.json')[POSITION_TEST]

refs = []
for ref in frontier['refs']:
    contained = subprocess.run(['git', 'merge-base', '--is-ancestor', ref['sha'], 'HEAD'], cwd=REPO).returncode == 0
    refs.append(dict(ref, contained_in_final_code=contained))
assert all(item['contained_in_final_code'] for item in refs if item['kind'] in ('fork', 'upstream'))

OUT.mkdir(parents=True, exist_ok=True)
for name in ['execution.tar.gz', 'archive-manifest.json']:
    shutil.copyfile(STAGING / name, OUT / name)

source_binding = {
    'core_qualified_tree': CORE_TREE,
    'final_code_checkpoint': checkpoint,
    'final_editor_source_manifest_sha256': digest(ROOT / 'position-validation/publication-editor/source-after.json'),
    'final_editor_all_inputs_match_worktree': True,
    'engine_production_unchanged_since_core_gate': True,
    'word_gate_input_changes': word_changes,
    'incoming_gate_input_changes': incoming_changes,
    'portable_inventory_changes': portable_changes,
    'change_dispositions': {
        POSITION_TEST: 'Pinned formatter only: line wrapping and optional trailing comma; affected 33-case suite and strict analysis rerun successfully.',
        ODT_TEST: 'Incoming explanatory name/comments and equivalent FormatException matcher; all 46 cases rerun successfully.',
        RENDERER: 'Incoming page text cache plus reviewed mutable-ink/proofing correction; final editor cohort and retained-versus-fresh pixel tests cover the changed renderer.'
    },
    'record_creation_changes': 'Only this documentation/evidence directory is written after the final code checkpoint.'
}
write('source-binding.json', source_binding)
write('remote-intake.json', {
    'captured_at_utc': frontier['at_utc'],
    'checked_against_code_head': checkpoint['remote'],
    'fork_heads': 43, 'upstream_heads': 4, 'pull_heads': 339,
    'historical_non_ancestor_pull_heads': [item for item in refs if item['kind'] == 'pull' and not item['contained_in_final_code']],
    'branch_heads': [item for item in refs if item['kind'] != 'pull'],
    'note': 'All captured fork/upstream heads and all newly captured PR heads are incorporated. Fourteen unchanged historical PR refs are recorded rather than resurrected. No GitHub Actions were awaited.'
})

editor_suites = sum(value.endswith('_test.dart') for value in editor['command'])
validation = {
    'schema_version': 1,
    'qualified': True,
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'final_code_checkpoint': checkpoint,
    'runtime': {'flutter': '3.47.8', 'dart': '3.13.7'},
    'checks': {
        'word_engine': {'passed': word['passing'], 'suites': word['suites_requested'], 'failures': 0, 'skipped': 0, 'source_files': word['source_files_hashed']},
        'incoming_branches': {'passed': incoming['passing'], 'suites': incoming['suites_requested'], 'failures': 0, 'skipped': 0, 'source_files': incoming['source_files_hashed']},
        'final_editor': {'passed': editor['completed_tests'], 'suites': editor_suites, 'failures': 0, 'source_files': editor['source_file_count'], 'tree': editor['tree_before']},
        'earlier_editor': {'passed': original_editor['completed_tests'], 'suites': 5, 'tree': CORE_TREE, 'scope': 'Earlier evidence; the final editor cohort repeats these cases.'},
        'formatter_follow_up': {'passed': 33, 'formatting_passed': True, 'scope': 'Repeat of cases inside the broad Word gate; do not add to unique totals.'},
        'odt_style_follow_up': {'passed': 46, 'scope': 'Repeat of cases inside incoming gate after an equivalent matcher change.'},
        'portable': {'corpus_cases': 12, 'bas_operations': 5, 'vm_javascript_receipts_identical': True, 'receipt_hashes': portable['receiptHashes']},
        'independent_native_probes': {'passed': 14, 'scope': 'Additional ownership/spacing probes, separate from suite counts.'},
        'cache_regressions': {'before_fix_failed': 6, 'differing_pixels_per_failure': 688, 'focused_after_fix_passed': 9, 'overlay_failure_reproduced': False},
        'strict_analysis': 'Passed for engine library, new engine/editor tests, portable runner and changed renderer.',
        'formatting': 'Passed with pinned Dart; original one-file formatter failure and its successful correction are retained.'
    },
    'ci': {'github_actions_awaited': False, 'merge_basis': 'Executed local checks and source-bound receipts'},
    'limits': ['Bounded source-to-plan dialect, not a general VBA host.', 'No installed Microsoft Word differential run.', 'No new ODT/RTF position interchange.', 'noSpaceRaiseLower qualifies spacing suppression, not complete Word clipping parity.'],
    'archive_sha256': digest(OUT / 'execution.tar.gz'),
    'source_binding_sha256': digest(OUT / 'source-binding.json'),
    'remote_intake_sha256': digest(OUT / 'remote-intake.json')
}
write('validation.json', validation)

readme = f'''# Word VBA baseline positioning and integrated rendering qualification

## Delivered behavior

The `vba-word` adapter now supports `Font.Position` on explicitly selected
paragraph text, including typed `Font` aliases, nested `With`, `ByVal` helpers,
named helper arguments and independent header/footer paragraphs. Positive
points raise text, negative points lower it, and an explicit zero overrides an
inherited displacement. Authored text and font size remain intact.

Each assignment compiles to the ordinary `docx.runFormat` operation. Source
values must be exact whole points in **-1584..1584**. This envelope belongs to
the Quds dialect; it does not describe Microsoft's entire accepted range.
Native JSON separately accepts exact half-point increments within that
envelope. DOCX stores signed half-points in `w:position/@w:val`, with sparse
inheritance and explicit-zero ownership. Imported signed-integer values remain
representable independently of the narrower macro-writing envelope.

Automatic and minimum line spacing reserve the visible raised/lowered extents;
exact spacing keeps its fixed line box. Imported
`w:compat/w:noSpaceRaiseLower` suppresses expansion. Existing superscript and
subscript scaling/offsets remain independent. Position survives splitting,
copying, undo/redo, save/reopen, incremental and note layout, PDF extraction,
paint grouping, comparison and stale-operation fingerprints. Unsupported or
ambiguous native ownership refuses before mutation.

The [complete contract](../../VBA_WORD_MACROS.md#baseline-position-without-resizing-text)
and [native mapping](../../MACROS.md) describe the exact boundaries. The
[BAS example](../../../packages/quds_office_engine/example/macros/word_font_position.bas)
requires three existing body paragraphs and an independent primary header; its
five operations exercise positive, negative and zero positions and preserve an
unrelated bold assignment.

```vb
Sub Main()
    ActiveDocument.Paragraphs(1).Range.Font.Position = 3
    ActiveDocument.Paragraphs(2).Range.Font.Position = -2
    ActiveDocument.Paragraphs(3).Range.Font.Position = 0
End Sub
```

## Integration and retained history

Work was saved incrementally on `codex/word-vba-typography-20261121` using normal
merge parents and expected-head branch updates. The captured frontier contains
**43 fork heads and four upstream heads**, all ancestors of the final code
checkpoint. The refresh also fetched **339 PR heads**: 325 are ancestors, while
14 unchanged historical non-ancestor refs remain explicitly recorded. Newly
captured work is incorporated; historical refs were not treated as new work.

Intake includes the concurrent Mail/main changes, Zotero picture and uppercase
round trips, native note-style validation, converter qualification, and the
page text cache from PR339. Documentation conflicts retained both work streams
and their latest qualification limits. The original branch histories remain
available. [Remote accounting](remote-intake.json) records exact heads, and the
archive retains the fetch and semantic-review receipts.

The original core gates used tree `{CORE_TREE}`, published as
`5ebd69bacd789c89e2ee6d06a9807ecf22cac764`. The final code checkpoint is
[`{checkpoint['remote']}`](https://github.com/CrispStrobe/quds_office_suite/commit/{checkpoint['remote']}),
tree `{checkpoint['tree']}`. This record is a subsequent documentation-only
addition. GitHub Actions were not awaited.

## Rendering correction during final intake

Review of the incoming page-text cache found adaptive ink depended on mutable
selection and story state absent from the cache identity. Six retained-versus-
fresh pixel comparisons reproduced the defect: table-band selection, mutation
of one caret across cells, and entering/leaving header and footer editing.
Each failing comparison had **688 differing pixels**.

The corrected cache stores one picture per page with an immutable snapshot of
its ink inputs. It includes selected table/band, normalized spanning paragraph
selection, selection fill, header/footer mode and active-story membership when
colors adapt to the theme. It disposes replaced pictures. Collapsed and
same-paragraph caret changes preserve cache reuse. The six mismatches disappear
and all nine focused tests pass, including Position relayout and caret controls.

Code review also found overlay proofing could enter the static body picture.
Both overlay paths now honor the proofing flag, with body overlay findings in
the dynamic clipped pass. The bounded TOC fixtures passed before and after this
correction; no separately reproduced proofing failure is claimed. Raw red and
green evidence, reviewed patches, exact source snapshots and the final combined
renderer run are preserved in the archive.

## Executed local checks

All final execution used **Flutter 3.47.8 and bundled Dart 3.13.7**, matching the
repository pin. Dependencies retain the repository lockfile. Initial Dart
3.14.1 setup/development runs are not presented as the pinned qualification.

| Check | Result | Source binding |
| --- | --- | --- |
| Word/native/compiler/layout regressions | **998 passed**, 31 suites; zero failures/skips | 1,151 engine/test/tool/config inputs unchanged during execution |
| Incoming ODT/Zotero/Word regressions | **716 passed**, 25 suites; zero failures/skips | 981 inputs unchanged during execution |
| Final combined editor/rendering cohort | **{editor['completed_tests']} passed**, {editor_suites} suites; zero failures | {editor['source_file_count']} inputs unchanged at the final code tree |
| Formatter correction follow-up | **33 passed**, strict analysis and format checks passed | Only call wrapping and an optional trailing comma changed |
| Final ODT style matcher follow-up | **46 passed**, zero failures/skips | Equivalent assertion/name/comment update; engine production bytes unchanged |
| Independent ownership/spacing probes | **14 passed** | Pinned runtime and relevant production hashes retained |
| Committed BAS example on VM and JavaScript | **Identical successful receipts** | Five native operations, recording/replay, validation-only behavior, late rollback, three policy refusals and preserved inert parts |
| Versioned Position corpus on VM and JavaScript | **12 cases; identical receipts** | Independently authored expectations and positioned diagnostics |
| Strict analysis and formatting | **Passed** | Engine library, new tests, portable runner and changed renderer; original format failure retained with its successful resolution |

The final editor cohort repeats the earlier 31-case editor run. The formatter,
ODT matcher, focused cache, corpus and cross-runtime runs also repeat relevant
cases; their counts must not be summed into a unique-test total or VBA parity
percentage. [validation.json](validation.json) is the compact machine-readable
result.

## Final-source equivalence

After the broad frozen gates, engine production files remained byte-identical.
Two engine test files changed: the pinned formatter normalized one call, and an
incoming ODT commit clarified an equivalent exception assertion. Their complete
affected suites were rerun successfully. The portable runner, BAS, corpus and
engine inputs also stayed identical; its broad inventory additionally notices
the renderer change, covered by the final editor run.

[source-binding.json](source-binding.json) checks every captured input against
the final checkout and identifies those exact differences. Final editor inputs
match the final code checkpoint byte-for-byte. Changes after that checkpoint
are confined to this documentation/evidence record.

## Reproduction and evidence

The archive contains exact commands, runtime/config identities, JSONL test
events, per-case results, source inventories before/after, patches and harness
source. It excludes installed SDKs, package caches and generated JavaScript.
[archive-manifest.json](archive-manifest.json) enumerates payload sizes and
SHA-256 digests; [SHA256SUMS](SHA256SUMS) covers this published record.

Use the pinned Flutter installation and the repository's locked dependency
resolution. From `packages/quds_office_engine`, the new engine suites are:

```bash
dart test test/office_macro_word_position_test.dart \\
  test/office_vba_word_position_test.dart \\
  test/office_vba_word_position_conformance_test.dart \\
  test/office_vba_word_position_integration_test.dart \\
  test/word_position_test.dart
```

The complete 31-file and 25-file lists are in the archived command receipts.
The workflow in `.github/workflows/office-macros.yml` retains future native and
portable coverage. The portable harness supplies the actual committed BAS with
`WORD_POSITION_BAS_BASE64` and the versioned corpus with
`VBA_CONFORMANCE_BASE64`; VM and JavaScript receipts are compared byte-for-byte.

## Compatibility limits and primary references

This is the existing bounded source-to-plan dialect. It adds no live Position
reads, arbitrary Selection/subranges, document-dependent VBA evaluation or
embedded VBA execution. Embedded DOCM project bytes remain inert and preserved.
No new ODT/RTF Position interchange or installed Microsoft Word differential run
is claimed. Empty text keeps the existing run-format refusal. The imported
compatibility flag qualifies spacing suppression, not complete Word clipping
or font-metric parity.

Primary contracts: Microsoft [Font.Position](https://learn.microsoft.com/en-us/office/vba/api/word.font.position),
[OOXML Position](https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.wordprocessing.position),
and [NoSpaceRaiseLower](https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.wordprocessing.nospaceraiselower).
'''
(OUT / 'README.md').write_text(readme)
(OUT / 'SHA256SUMS').write_text(''.join(f'{digest(path)}  {path.name}\n' for path in sorted(OUT.iterdir()) if path.is_file() and path.name != 'SHA256SUMS'))
print(json.dumps({'record': str(OUT), 'code_head': checkpoint['remote'], 'tree': checkpoint['tree'], 'editor_tests': editor['completed_tests'], 'editor_suites': editor_suites, 'files': sorted(path.name for path in OUT.iterdir())}, indent=2))
