#!/usr/bin/env python3
from pathlib import Path
import argparse, datetime, hashlib, json, os, subprocess, time
ROOT=Path('/workspace/scratch/65a76194ed76/quds_office_suite')
DART=Path('/workspace/scratch/65a76194ed76/quds_flutter_runtime/flutter/bin/cache/dart-sdk/bin/dart')
RUNTIME=Path('/workspace/scratch/65a76194ed76/quds_dart_runtime')
RUNNER=RUNTIME/'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
FILES=['odt_reader_styles_test.dart']
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def source_status():
    return git('status','--porcelain=1','--untracked-files=all','--',
        'packages/quds_office_engine/lib','packages/quds_office_engine/test',
        'pubspec.yaml','pubspec.lock','packages/quds_office_engine/pubspec.yaml')
def snapshot():
    paths=set()
    for subtree in ['packages/quds_office_engine/lib','packages/quds_office_engine/test']:
        paths.update(p for p in (ROOT/subtree).rglob('*') if p.is_file())
    for rel in ['pubspec.yaml','pubspec.lock','.dart_tool/package_config.json',
                'packages/quds_office_engine/pubspec.yaml']:
        p=ROOT/rel
        if p.is_file():paths.add(p)
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--expected-head',required=True)
    parser.add_argument('--expected-tree',required=True)
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    head=git('rev-parse','HEAD')
    tree=git('rev-parse','HEAD^{tree}')
    relevant=['packages/quds_office_engine/lib','packages/quds_office_engine/test',
        'pubspec.yaml','pubspec.lock','packages/quds_office_engine/pubspec.yaml']
    delta=git('diff','--name-only',args.expected_head,head,'--',*relevant)
    if delta:
        raise SystemExit('Engine inputs changed from approved starting head: '+delta)
    dirty=source_status()
    if dirty:
        raise SystemExit('Engine source differs from frozen commit before start:\\n'+dirty)
    out=Path(args.output)
    out.mkdir(parents=True,exist_ok=False)
    env=os.environ.copy()
    env.update({'PUB_CACHE':str(RUNTIME/'pub-cache'),'TMPDIR':str(RUNTIME/'tmp'),
        'XDG_CONFIG_HOME':str(RUNTIME/'config'),'XDG_CACHE_HOME':str(RUNTIME/'cache'),
        'DART_SUPPRESS_ANALYTICS':'true','CI':'true',
        'PATH':str(DART.parent)+os.pathsep+os.environ.get('PATH','')})
    cwd=ROOT/'packages/quds_office_engine'
    for name in FILES:
        if not (cwd/'test'/name).is_file():raise SystemExit('Missing suite '+name)
    cmd=[str(DART),'--old_gen_heap_size=1536',
        '--packages='+str(ROOT/'.dart_tool/package_config.json'),str(RUNNER),
        '--compiler=source','--concurrency=2','--timeout=4x','--reporter=json',
        *['test/'+name for name in FILES]]
    start=time.monotonic()
    started=now()
    before=snapshot()
    write(out/'source-before.json',before)
    write(out/'command.json',{'command':cmd,'cwd':str(cwd),'head':head,'tree':tree,
        'expected_head':args.expected_head,'expected_tree':args.expected_tree,
        'scope':'Engine lib/tests and root package inputs; concurrent editor changes permitted',
        'started_utc':started,
        'test_files':FILES,'status_before':git('status','--short')})
    version=subprocess.check_output([str(DART),'--version'],env=env,text=True).strip()
    write(out/'toolchain.json',{'dart_version':version,'dart_path':str(DART),
        'test_runner':str(RUNNER),'test_runner_sha256':hashlib.sha256(RUNNER.read_bytes()).hexdigest(),
        'package_config':json.loads((ROOT/'.dart_tool/package_config.json').read_text()),
        'pubspec_lock_sha256':hashlib.sha256((ROOT/'pubspec.lock').read_bytes()).hexdigest()})
    print(json.dumps({'started_utc':started,'head':head,'tree':tree,'suite_count':len(FILES),'dart':version}),flush=True)
    cases={}
    suites={}
    errors=[]
    done=None
    last_report=time.monotonic()
    with (out/'events.jsonl').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
        process=subprocess.Popen(cmd,cwd=cwd,env=env,text=True,stdout=subprocess.PIPE,stderr=stderr,bufsize=1)
        for line in process.stdout:
            stdout.write(line)
            stdout.flush()
            try:event=json.loads(line)
            except json.JSONDecodeError:
                errors.append({'non_json_stdout':line.rstrip()})
                continue
            typ=event.get('type')
            if typ=='suite':
                suites[event['suite']['id']]=event['suite']
            elif typ=='testStart':
                cases[event['test']['id']]=dict(event['test'])
            elif typ=='testDone':
                case=cases.setdefault(event['testID'],{'id':event['testID'],'hidden':True})
                case.update({k:v for k,v in event.items() if k not in ('type','testID')})
            elif typ=='error':
                errors.append(event)
            elif typ=='done':
                done=event
            if time.monotonic()-last_report>=25:
                visible=[case for case in cases.values() if not case.get('hidden',True)]
                print(json.dumps({'elapsed_seconds':round(time.monotonic()-start,1),
                    'loaded_suites':len(suites),
                    'passed':sum(case.get('result')=='success' and not case.get('skipped',False) for case in visible),
                    'failed':sum(case.get('result') in ('failure','error') for case in visible)}),flush=True)
                last_report=time.monotonic()
        exit_code=process.wait()
    after=snapshot()
    write(out/'source-after.json',after)
    write(out/'cases.json',sorted(cases.values(),key=lambda case:case['id']))
    visible=[case for case in cases.values() if not case.get('hidden',True)]
    changed=sorted(p for p in before.keys()&after.keys() if before[p]!=after[p])
    added=sorted(after.keys()-before.keys())
    removed=sorted(before.keys()-after.keys())
    summary={'head':head,'head_after':git('rev-parse','HEAD'),
        'tree':tree,'tree_after':git('rev-parse','HEAD^{tree}'),
        'expected_head':args.expected_head,'expected_tree':args.expected_tree,
        'scope':'Engine lib/tests and root package inputs; concurrent editor changes permitted',
        'started_utc':started,'completed_utc':now(),
        'elapsed_seconds':round(time.monotonic()-start,3),'exit_code':exit_code,
        'suites_requested':len(FILES),'suites_loaded':len(suites),'source_files_hashed':len(before),
        'visible_tests':len(visible),
        'passing':sum(case.get('result')=='success' and not case.get('skipped',False) for case in visible),
        'failures':sum(case.get('result') in ('failure','error') for case in visible),
        'skipped':sum(case.get('skipped',False) for case in visible),
        'source_changed':changed,'source_added':added,'source_removed':removed,
        'done':done,'errors':errors,'status_after':git('status','--short'),
        'engine_source_status_after':source_status()}
    summary['engine_gate_passed']=(exit_code==0 and done is not None and done.get('success') is True
        and not errors and not changed and not added and not removed and len(visible)>0
        and not summary['engine_source_status_after'])
    write(out/'summary.json',summary)
    print(json.dumps(summary),flush=True)
    raise SystemExit(0 if summary['engine_gate_passed'] else 1)
if __name__=='__main__':main()
