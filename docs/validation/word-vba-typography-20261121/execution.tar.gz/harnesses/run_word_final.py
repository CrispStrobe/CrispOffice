#!/usr/bin/env python3
"""Run the frozen Word cohort with the pinned runtime and JSONL evidence."""
from pathlib import Path
import hashlib
import importlib.util

source = Path('/workspace/scratch/65a76194ed76/intake-validation/run_frozen_intake.py')
spec = importlib.util.spec_from_file_location('frozen_word_gate', source)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
gate.FILES = [
    'office_macro_word_position_test.dart',
    'office_vba_word_position_test.dart',
    'office_vba_word_position_conformance_test.dart',
    'office_vba_word_position_integration_test.dart',
    'word_position_test.dart',
    'office_vba_language_test.dart',
    'office_vba_word_language_test.dart',
    'office_vba_word_typography_test.dart',
    'office_vba_word_typography_integration_test.dart',
    'office_vba_word_proofing_test.dart',
    'office_vba_word_proofing_integration_test.dart',
    'office_vba_word_all_caps_test.dart',
    'office_vba_word_all_caps_integration_test.dart',
    'office_macro_word_all_caps_test.dart',
    'office_vba_word_language_controls_test.dart',
    'office_vba_word_language_controls_integration_test.dart',
    'office_macro_word_language_controls_test.dart',
    'office_macro_word_paragraph_style_test.dart',
    'office_vba_word_styles_test.dart',
    'office_vba_word_styles_integration_test.dart',
    'style_cascade_test.dart',
    'word_styles_layout_test.dart',
    'word_paragraph_mark_layout_test.dart',
    'word_all_caps_test.dart',
    'word_small_caps_test.dart',
    'word_proofing_inheritance_test.dart',
    'word_layout_test.dart',
    'word_incremental_layout_test.dart',
    'word_incremental_layout_prefix_test.dart',
    'word_incremental_layout_differential_test.dart',
    'word_incremental_break_translation_test.dart',
]
original_snapshot = gate.snapshot
def snapshot():
    result = original_snapshot()
    for path in sorted((gate.ROOT / 'packages/quds_office_engine/tool').rglob('*')):
        if path.is_file():
            result[str(path.relative_to(gate.ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return dict(sorted(result.items()))
gate.snapshot = snapshot
gate.main()
