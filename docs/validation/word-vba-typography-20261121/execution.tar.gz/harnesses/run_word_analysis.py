#!/usr/bin/env python3
"""Non-mutating formatting and strict analysis for the frozen Word feature."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/workspace/scratch/65a76194ed76/quds_office_suite')
OUT = Path('/workspace/scratch/65a76194ed76/position-validation/word-final/analysis')
RUNTIME = Path('/workspace/scratch/65a76194ed76/quds_dart_runtime')
DART = Path('/workspace/scratch/65a76194ed76/quds_flutter_runtime/flutter/bin/cache/dart-sdk/bin/dart')
EXPECTED_TREE = '479bfb1adc542c5f46be270e6d35c3f5c0be1b4d'
COMMITS = ['a646cf761f7eafe7915988a1d84f90ca6dbe5793',
           '3eba122e108098ea3cfae52ecad24039d4e3839c',
           'bbfbb8e0cfc4b62a06c20dd67412e54347e18252']
TARGETS = ['lib', 'test/office_macro_word_position_test.dart',
           'test/office_vba_word_position_test.dart',
           'test/office_vba_word_position_conformance_test.dart',
           'test/office_vba_word_position_integration_test.dart',
           'test/word_position_test.dart',
           'tool/macros/web_vba_word_position_smoke.dart']

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def snapshot(paths):
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(paths) if p.is_file()}

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

OUT.mkdir(parents=True, exist_ok=False)
before_head = git('rev-parse', 'HEAD')
before_tree = git('rev-parse', 'HEAD^{tree}')
if before_tree != EXPECTED_TREE:
    raise SystemExit('Frozen tree mismatch: ' + before_tree)
changed = set()
for commit in COMMITS:
    changed.update(path for path in git('diff-tree', '--no-commit-id', '--name-only', '-r', commit).splitlines()
                   if path.endswith('.dart') and (ROOT / path).is_file())
paths = {ROOT / path for path in changed}
paths.update((ROOT / 'packages/quds_office_engine/lib').rglob('*.dart'))
for target in TARGETS:
    p = ROOT / 'packages/quds_office_engine' / target
    if p.is_file():
        paths.add(p)
for rel in ['.dart_tool/package_config.json', 'pubspec.yaml', 'pubspec.lock',
            'analysis_options.yaml', 'packages/quds_office_engine/pubspec.yaml',
            'packages/quds_office_engine/analysis_options.yaml']:
    paths.add(ROOT / rel)
before = snapshot(paths)
write('source-before.json', before)
write('format-files.json', sorted(changed))
env = os.environ.copy()
env.update({'PUB_CACHE': str(RUNTIME / 'pub-cache'), 'TMPDIR': str(RUNTIME / 'tmp'),
            'XDG_CONFIG_HOME': str(RUNTIME / 'config'), 'XDG_CACHE_HOME': str(RUNTIME / 'cache'),
            'DART_SUPPRESS_ANALYTICS': 'true', 'CI': 'true',
            'PATH': str(DART.parent) + os.pathsep + env.get('PATH', '')})
version = subprocess.check_output([str(DART), '--version'], env=env, text=True).strip()
if 'Dart SDK version: 3.13.7 ' not in version:
    raise SystemExit('Wrong Dart version: ' + version)
write('toolchain.json', {'dart_version': version, 'dart_path': str(DART),
                         'head': before_head, 'tree': before_tree,
                         'dart_sha256': hashlib.sha256(DART.read_bytes()).hexdigest()})
results = []
def run(label, command, cwd):
    started = now()
    start = time.monotonic()
    print(json.dumps({'started': label, 'started_utc': started, 'command': command}), flush=True)
    with (OUT / (label + '.stdout.log')).open('w') as stdout, (OUT / (label + '.stderr.log')).open('w') as stderr:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
    record = {'label': label, 'command': command, 'cwd': str(cwd),
              'started_utc': started, 'completed_utc': now(),
              'elapsed_seconds': round(time.monotonic() - start, 3), 'exit_code': result.returncode}
    results.append(record)
    write('commands.json', results)
    print(json.dumps(record), flush=True)

run('format', [str(DART), 'format', '--output=none', '--set-exit-if-changed', *sorted(changed)], ROOT)
for index, target in enumerate(TARGETS):
    run('analyze-' + str(index), [str(DART), 'analyze', '--fatal-infos', target],
        ROOT / 'packages/quds_office_engine')
after = snapshot(paths)
write('source-after.json', after)
changed_sources = sorted(path for path in before if before.get(path) != after.get(path))
summary = {'head': before_head, 'head_after': git('rev-parse', 'HEAD'),
           'tree': before_tree, 'tree_after': git('rev-parse', 'HEAD^{tree}'),
           'dart_version': version, 'format_files': len(changed),
           'analysis_targets': TARGETS, 'commands': results,
           'source_files_hashed': len(before), 'source_changed': changed_sources,
           'status_after': git('status', '--short')}
summary['passed'] = all(record['exit_code'] == 0 for record in results) and not changed_sources and summary['tree_after'] == EXPECTED_TREE
write('summary.json', summary)
print(json.dumps(summary), flush=True)
raise SystemExit(0 if summary['passed'] else 1)
