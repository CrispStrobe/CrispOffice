import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

repo = Path('/workspace/scratch/65a76194ed76/quds_office_suite')
engine = repo / 'packages/quds_office_engine'
runtime = Path('/workspace/scratch/65a76194ed76/quds_dart_runtime')
dart = '/workspace/scratch/65a76194ed76/quds_flutter_runtime/flutter/bin/cache/dart-sdk/bin/dart'
out = Path('/workspace/scratch/65a76194ed76/position-validation/portable')
out.mkdir(parents=True, exist_ok=True)
env = dict(os.environ)
env.update(PUB_CACHE=str(runtime/'pub-cache'), TMPDIR=str(runtime/'tmp'),
           XDG_CONFIG_HOME=str(runtime/'config'), XDG_CACHE_HOME=str(runtime/'cache'),
           DART_SUPPRESS_ANALYTICS='true', CI='true')
env['PATH'] = str(Path(dart).parent) + os.pathsep + env['PATH']
packages = '--packages=' + str(repo/'.dart_tool/package_config.json')

def sources():
    paths = list((engine/'lib').rglob('*.dart'))
    paths += list((repo/'packages/quds_office_editor/lib').rglob('*.dart'))
    paths += list((engine/'tool/macros').glob('*.dart'))
    paths += [engine/'test/support/vba_conformance.dart',
              engine/'test/fixtures/vba_conformance/word_font_position_v1.json',
              engine/'example/macros/word_font_position.bas',
              repo/'pubspec.lock', repo/'pubspec.yaml', repo/'.fvmrc',
              repo/'.dart_tool/package_config.json']
    return {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(set(paths))}

before = sources()
(out/'sources-before.json').write_text(json.dumps(before, indent=2)+'\n')
commands = []
def run(name, args, stdout):
    start = time.time()
    with (out/stdout).open('wb') as target, (out/(name+'.stderr')).open('wb') as errors:
        p = subprocess.run(args, cwd=engine, env=env, stdout=target, stderr=errors, timeout=600)
    commands.append({'name': name, 'argv': args, 'cwd': str(engine),
                     'exitCode': p.returncode, 'seconds': round(time.time()-start,3),
                     'stdout': stdout, 'stderr': name+'.stderr'})
    (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if p.returncode:
        raise RuntimeError(name+' failed; inspect saved stdout/stderr')

run('dart-version', [dart, '--version'], 'dart-version.txt')
for label, source, define, script in [
    ('example', engine/'example/macros/word_font_position.bas',
     'WORD_POSITION_BAS_BASE64', 'tool/macros/web_vba_word_position_smoke.dart'),
    ('corpus', engine/'test/fixtures/vba_conformance/word_font_position_v1.json',
     'VBA_CONFORMANCE_BASE64', 'tool/macros/web_vba_conformance.dart')]:
    value = '-D'+define+'='+base64.b64encode(source.read_bytes()).decode()
    run(label+'-vm', [dart, packages, value, script], label+'-vm.json')
    js = str(out/(label+'.js'))
    run(label+'-compile-js', [dart, 'compile', 'js', '-O1', packages, value, script, '-o', js], label+'-compile.log')
    run(label+'-js', [shutil.which('node'), '-e', 'globalThis.self=globalThis; require(process.argv[1]);', js], label+'-js.json')
    if (out/(label+'-vm.json')).read_bytes() != (out/(label+'-js.json')).read_bytes():
        raise RuntimeError(label+' VM/JavaScript receipts differ')
after = sources()
(out/'sources-after.json').write_text(json.dumps(after,indent=2)+'\n')
changed = [p for p in before.keys()|after.keys() if before.get(p)!=after.get(p)]
summary = {'passed': not changed, 'sourceChanged': changed, 'sourceFileCount': len(before),
           'receiptHashes': {name: hashlib.sha256((out/name).read_bytes()).hexdigest()
                             for name in ['example-vm.json','example-js.json','corpus-vm.json','corpus-js.json']}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
if changed:
    raise SystemExit(1)
