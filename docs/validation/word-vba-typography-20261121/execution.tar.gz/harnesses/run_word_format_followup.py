#!/usr/bin/env python3
"""Apply only the approved formatting diff, then qualify that test file."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import re
import subprocess
import time

REPO = Path('/workspace/scratch/65a76194ed76/quds_office_suite')
BASE = Path('/workspace/scratch/65a76194ed76/position-validation/word-final')
OUT = BASE / 'format-followup'
DART = Path('/workspace/scratch/65a76194ed76/quds_flutter_runtime/flutter/bin/cache/dart-sdk/bin/dart')
RUNTIME = Path('/workspace/scratch/65a76194ed76/quds_dart_runtime')
RUNNER = RUNTIME / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
TARGET = 'packages/quds_office_engine/test/office_vba_word_position_test.dart'

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def snapshot():
    paths = set(json.loads((BASE / 'tests/source-before.json').read_text()))
    paths.update(str(path.relative_to(REPO)) for path in (REPO / 'packages/quds_office_editor/lib').rglob('*.dart'))
    paths.add('packages/quds_office_editor/test/word_position_test.dart')
    result = {}
    for rel in sorted(paths):
        path = REPO / rel
        if path.is_symlink():
            value = os.readlink(path).encode()
        elif path.is_file():
            value = path.read_bytes()
        else:
            raise RuntimeError('Missing tracked file: ' + rel)
        result[rel] = sha(value)
    return result

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

broad = json.loads((BASE / 'tests/summary.json').read_text())
if broad['frozen_gate_passed'] is not True:
    raise SystemExit('Broad frozen gate must pass before formatting follow-up.')
if git('rev-parse', 'HEAD^{tree}') != broad['tree']:
    raise SystemExit('Frozen committed source tree moved before formatting follow-up.')
if (OUT / 'applied.diff').exists():
    raise SystemExit('Follow-up already applied; preserve its evidence.')
OUT.mkdir(parents=True, exist_ok=True)
before_head = git('rev-parse', 'HEAD')
before_status = git('status', '--short')
before = snapshot()
write('source-before.json', before)
target = REPO / TARGET
original = target.read_text()
formatted = (BASE / 'analysis/formatted-office-vba-word-position.dart').read_text()
expected_diff = (BASE / 'analysis/format-required.diff').read_text()
actual_diff = ''.join(difflib.unified_diff(original.splitlines(keepends=True), formatted.splitlines(keepends=True),
                     fromfile=TARGET, tofile=TARGET + '.formatted'))
if actual_diff != expected_diff or not actual_diff:
    raise SystemExit('Approved exact formatter diff no longer matches current test source.')
def formatting_tokens(text):
    return re.sub(r'\s+', '', re.sub(r',(?=\s*\))', '', text))
if formatting_tokens(original) != formatting_tokens(formatted):
    raise SystemExit('Formatting candidate changes text beyond whitespace/optional trailing commas.')
(OUT / 'applied.diff').write_text(actual_diff)
target.write_text(formatted)
env = os.environ.copy()
env.update({'PUB_CACHE': str(RUNTIME / 'pub-cache'), 'TMPDIR': str(RUNTIME / 'tmp'),
            'XDG_CONFIG_HOME': str(RUNTIME / 'config'), 'XDG_CACHE_HOME': str(RUNTIME / 'cache'),
            'DART_SUPPRESS_ANALYTICS': 'true', 'CI': 'true',
            'PATH': str(DART.parent) + os.pathsep + env.get('PATH', '')})
version = subprocess.check_output([str(DART), '--version'], env=env, text=True).strip()
if 'Dart SDK version: 3.13.7 ' not in version:
    raise SystemExit('Wrong pinned runtime: ' + version)
commands = []
def run(label, command, cwd, stdout_name=None):
    start = time.monotonic()
    started = now()
    print(json.dumps({'started': label, 'started_utc': started}), flush=True)
    with (OUT / (stdout_name or label + '.stdout.log')).open('w') as stdout, (OUT / (label + '.stderr.log')).open('w') as stderr:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
    record = {'label': label, 'command': command, 'cwd': str(cwd),
              'started_utc': started, 'completed_utc': now(),
              'elapsed_seconds': round(time.monotonic() - start, 3), 'exit_code': result.returncode}
    commands.append(record)
    write('commands.json', commands)
    print(json.dumps({'completed': label, 'exit_code': result.returncode, 'elapsed_seconds': record['elapsed_seconds']}), flush=True)

engine = REPO / 'packages/quds_office_engine'
run('tests', [str(DART), '--old_gen_heap_size=1536', '--packages=' + str(REPO / '.dart_tool/package_config.json'),
              str(RUNNER), '--compiler=source', '--concurrency=1', '--timeout=4x', '--reporter=json',
              'test/office_vba_word_position_test.dart'], engine, 'events.jsonl')
run('analyze', [str(DART), 'analyze', '--fatal-infos', 'test/office_vba_word_position_test.dart'], engine)
format_files = json.loads((BASE / 'analysis/format-files.json').read_text())
run('format', [str(DART), 'format', '--output=none', '--set-exit-if-changed', *format_files], REPO)
cases = {}
done = None
errors = []
for line in (OUT / 'events.jsonl').read_text().splitlines():
    event = json.loads(line)
    kind = event.get('type')
    if kind == 'testStart':
        cases[event['test']['id']] = event['test']
    elif kind == 'testDone':
        cases.setdefault(event['testID'], {'id': event['testID']}).update(
            {key: value for key, value in event.items() if key not in ('type', 'testID')})
    elif kind == 'error':
        errors.append(event)
    elif kind == 'done':
        done = event
visible = [case for case in sorted(cases.values(), key=lambda item: item['id']) if not case.get('hidden', True)]
(OUT / 'visible-cases.jsonl').write_text(''.join(json.dumps(case, sort_keys=True) + '\n' for case in visible))
after = snapshot()
write('source-after.json', after)
changed = sorted(path for path in before.keys() & after.keys() if before[path] != after[path])
added = sorted(after.keys() - before.keys())
removed = sorted(before.keys() - after.keys())
summary = {'head_before': before_head, 'head_after': git('rev-parse', 'HEAD'),
           'committed_tree': git('rev-parse', 'HEAD^{tree}'), 'broad_gate_tree': broad['tree'],
           'status_before': before_status, 'status_after': git('status', '--short'),
           'dart_version': version, 'dart_path': str(DART), 'commands': commands,
           'case_count': len(visible), 'passing': sum(case.get('result') == 'success' and not case.get('skipped', False) for case in visible),
           'failures': sum(case.get('result') in ('error', 'failure') for case in visible),
           'skipped': sum(bool(case.get('skipped', False)) for case in visible),
           'done': done, 'errors': errors, 'source_files_hashed': len(before),
           'source_changed': changed, 'source_added': added, 'source_removed': removed,
           'formatting_only': True, 'whitespace_only': False,
           'removed_optional_trailing_comma': True,
           'production_sources_byte_identical': changed == [TARGET] and not added and not removed,
           'before_manifest_sha256': sha((OUT / 'source-before.json').read_bytes()),
           'after_manifest_sha256': sha((OUT / 'source-after.json').read_bytes()),
           'applied_diff_sha256': sha((OUT / 'applied.diff').read_bytes()),
           'events_sha256': sha((OUT / 'events.jsonl').read_bytes()),
           'cases_sha256': sha((OUT / 'visible-cases.jsonl').read_bytes())}
summary['git_diff_paths'] = git('diff', '--name-only').splitlines()
summary['passed'] = (all(command['exit_code'] == 0 for command in commands)
                     and len(visible) == 33 and summary['passing'] == 33
                     and not errors and done is not None and done.get('success') is True
                     and summary['production_sources_byte_identical']
                     and summary['git_diff_paths'] == [TARGET])
write('summary.json', summary)
print(json.dumps(summary), flush=True)
raise SystemExit(0 if summary['passed'] else 1)
