#!/usr/bin/env python3
"""Reconstruct and hash-check four historical source cohorts without tests.

Requires only Python 3, Git, three retained commits, and the two archived
top-level evidence directories. Never reads an isolated-engine or build cache.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile


QUALIFIED = 'fb502f612da6e87184e3025fdb379ba02fac1aab'
CONCURRENT = 'b9bfe664a4efe4128a47792a1ea2cce16c7dd2c8'
INTEGRATED = 'e19783792ef09744f0ec4b3403b44570dd7f6922'
ENGINE_PREFIX = 'packages/quds_office_engine/'
WRITER = 'lib/src/word/serial/odt_document_writer.dart'
GERMAN = 'lib/src/proofing/german_grammar.dart'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def need(condition, description):
    if not condition:
        raise ValueError(description)


def git(repo, *args):
    return subprocess.check_output(
        ['git', '--no-optional-locks', '-C', str(repo), *args],
        stderr=subprocess.PIPE,
    )


def git_file(repo, commit, path):
    return git(repo, 'show', f'{commit}:{ENGINE_PREFIX}{path}')


def library(repo, commit):
    archive = git(repo, 'archive', '--format=tar', commit, ENGINE_PREFIX + 'lib')
    result = {}
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:') as bundle:
        for member in bundle.getmembers():
            if member.isdir():
                continue
            need(member.isfile(), f'Nonregular library member: {member.name}')
            need(member.name.startswith(ENGINE_PREFIX), 'Unexpected archive prefix')
            path = member.name[len(ENGINE_PREFIX):]
            need(path.startswith('lib/') and '..' not in PurePosixPath(path).parts,
                 f'Unexpected library path: {path}')
            need(path not in result, f'Duplicate archive member: {path}')
            result[path] = bundle.extractfile(member).read()
    need(len(result) == 319, f'Expected 319 files at {commit}, got {len(result)}')
    return result


def file_map(files):
    return {path: sha(data) for path, data in sorted(files.items())}


def map_sha(mapping):
    return sha(json.dumps(mapping, sort_keys=True, separators=(',', ':')).encode())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--tab-evidence', required=True, type=Path)
    parser.add_argument('--column-evidence', required=True, type=Path)
    parser.add_argument('--audit', required=True, type=Path)
    parser.add_argument('--materialize', type=Path,
                        help='Optional new directory for the four lib/ + test/ source trees')
    args = parser.parse_args()
    repo = args.repo.resolve()
    evidence_dirs = [args.tab_evidence.resolve(), args.column_evidence.resolve()]
    audit_path = args.audit.resolve()
    for protected in [repo, *evidence_dirs]:
        need(not audit_path.is_relative_to(protected),
             'Audit output must be outside the repository and original evidence directories')
    if args.materialize:
        need(not args.materialize.exists(), 'Materialization directory already exists')

    refs = {}
    for commit in [QUALIFIED, CONCURRENT, INTEGRATED]:
        need(git(repo, 'rev-parse', '--verify', commit + '^{commit}').decode().strip() == commit,
             f'Commit not available: {commit}')
        refs[commit] = {
            'tree': git(repo, 'rev-parse', commit + '^{tree}').decode().strip(),
        }
    for commit in [QUALIFIED, CONCURRENT]:
        git(repo, 'merge-base', '--is-ancestor', commit, INTEGRATED)

    bases = {QUALIFIED: library(repo, QUALIFIED), INTEGRATED: library(repo, INTEGRATED)}
    german = git_file(repo, CONCURRENT, GERMAN)
    cases = []
    materialized = []
    input_hashes = {}
    cohort_maps = {}

    recipes = [
        ('tabs', args.tab_evidence, QUALIFIED,
         'odt_tab_style_fidelity_test.dart', 'run_tab_control.py',
         {'before': 'merged-before-tab-cache.dart', 'after': 'merged-after-tab-cache.dart'}),
        ('columns', args.column_evidence, INTEGRATED,
         'odt_columns_schema_fidelity_test.dart', 'run_column_control.py',
         {'before': 'writer-before-column-schema.dart', 'after': 'writer-after-column-schema.dart'}),
    ]
    for family, evidence, base_commit, probe_name, runner_name, snapshots in recipes:
        probe = (evidence / probe_name).read_bytes()
        need(probe == git_file(repo, INTEGRATED, 'test/' + probe_name),
             f'Archived {family} probe differs from integrated source')
        common = None
        for phase in ['before', 'after']:
            label = family + '-' + phase
            record_path = evidence / (phase + '.json')
            record_bytes = record_path.read_bytes()
            record = json.loads(record_bytes)
            need(record['source_sha256_before'] == record['source_sha256_after'],
                 f'{label}: recorded source changed during run')
            expected = record['source_sha256_before']
            need(len(expected) == 319, f'{label}: expected-map count differs')
            snapshot = (evidence / snapshots[phase]).read_bytes()
            need(sha(snapshot) == record['writer_sha256'] == expected[WRITER],
                 f'{label}: archived writer digest differs')
            need(sha(probe) == record['probe_sha256'], f'{label}: probe digest differs')

            immutable_inputs = {
                phase + '.json': record_bytes,
                phase + '.jsonl': (evidence / (phase + '.jsonl')).read_bytes(),
                phase + '.stderr': (evidence / (phase + '.stderr')).read_bytes(),
                probe_name: probe,
                snapshots[phase]: snapshot,
                'source-package-config.json': (evidence / 'source-package-config.json').read_bytes(),
                runner_name: (evidence / runner_name).read_bytes(),
            }
            for path, data in immutable_inputs.items():
                input_hashes[str(evidence / path)] = sha(data)
            need(sha(immutable_inputs[phase + '.jsonl']) == record['stdout_sha256'],
                 f'{label}: stdout digest differs')
            need(sha(immutable_inputs[phase + '.stderr']) == record['stderr_sha256'],
                 f'{label}: stderr digest differs')
            need(sha(immutable_inputs['source-package-config.json']) == record['source_package_config_sha256'],
                 f'{label}: source graph digest differs')
            need(sha(immutable_inputs[runner_name]) == record['runner_sha256'],
                 f'{label}: original runner digest differs')
            stable = {key: record[key] for key in [
                'probe_sha256', 'source_package_config_sha256',
                'isolated_package_config_sha256', 'dart_sha256', 'runner_sha256',
            ]}
            if common is None:
                common = stable
            else:
                need(stable == common, f'{family}: non-writer control inputs differ')

            reconstructed = dict(bases[base_commit])
            overrides = []
            if family == 'tabs':
                reconstructed[GERMAN] = german
                overrides.append({'path': GERMAN, 'source_commit': CONCURRENT,
                                  'sha256': sha(german)})
            reconstructed[WRITER] = snapshot
            overrides.append({'path': WRITER, 'archived_snapshot': snapshots[phase],
                              'sha256': sha(snapshot)})
            actual = file_map(reconstructed)
            missing = sorted(set(expected) - set(actual))
            unexpected = sorted(set(actual) - set(expected))
            mismatched = sorted(path for path in set(actual) & set(expected)
                                if actual[path] != expected[path])
            need(not missing and not unexpected and not mismatched,
                 f'{label}: map mismatch: missing={missing}, unexpected={unexpected}, hashes={mismatched}')
            cohort_maps[label] = actual
            unchanged = sum(actual[path] == sha(bases[base_commit][path]) for path in actual)
            case = {
                'cohort': label,
                'base_commit': base_commit,
                'overrides': overrides,
                'library_files': len(actual),
                'identical_to_base_files': unchanged,
                'full_source_map_sha256': map_sha(actual),
                'recorded_before_map_matches': actual == record['source_sha256_before'],
                'recorded_after_map_matches': actual == record['source_sha256_after'],
                'missing_paths': missing,
                'unexpected_paths': unexpected,
                'mismatched_hashes': mismatched,
                'probe': {'path': 'test/' + probe_name, 'sha256': sha(probe),
                          'matches_integrated_commit': True},
                'recorded_control_inputs': stable,
            }
            cases.append(case)
            materialized.append((label, reconstructed, 'test/' + probe_name, probe, case))

    for family in ['tabs', 'columns']:
        old = cohort_maps[family + '-before']
        new = cohort_maps[family + '-after']
        need([path for path in old if old[path] != new[path]] == [WRITER],
             f'{family}: reconstructed pair changes more than the writer')

    if args.materialize:
        args.materialize.mkdir(parents=True, exist_ok=False)
        for label, files, probe_path, probe, case in materialized:
            cohort = args.materialize / label
            for path, data in {**files, probe_path: probe}.items():
                destination = cohort / path
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
            (cohort / 'SOURCE.json').write_text(json.dumps(case, indent=2) + '\n')
            disk = {str(path.relative_to(cohort)): sha(path.read_bytes())
                    for path in (cohort / 'lib').rglob('*') if path.is_file()}
            need(disk == cohort_maps[label], f'{label}: materialized source differs')

    # Re-read every consumed evidence file to prove this audit leaves it intact.
    need(all(sha(Path(path).read_bytes()) == digest for path, digest in input_hashes.items()),
         'An evidence input changed during reconstruction')
    report = {
        'status': 'passed',
        'scope': 'Exact reconstruction of four recorded 319-library-file cohorts; no product tests executed.',
        'source_refs': refs,
        'references_are_ancestors_of_integrated_commit': True,
        'local_only_commit_required': False,
        'original_isolated_engine_or_cache_required': False,
        'cases': cases,
        'original_evidence_unchanged': True,
        'evidence_sha256': input_hashes,
        'script_sha256': sha(Path(__file__).read_bytes()),
        'materialized': str(args.materialize.resolve()) if args.materialize else None,
        'runtime_scope': 'Recorded runtime and graph identities are retained; this source audit does not requalify dependencies, execute Dart, or recreate transient test caches.',
    }
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    audit_path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': 'passed', 'cohorts': len(cases), 'library_files_each': 319,
                      'audit': str(audit_path), 'tests_executed': 0}))


if __name__ == '__main__':
    main()
