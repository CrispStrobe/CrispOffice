# Reconstruct the tab and column control sources

The four recorded control cohorts can be reconstructed from three retained Git
commits and the archived writer snapshots. The historical local merge commit
`e94d6b69` and the `isolated-engine`, build, and temporary directories are not
required. `reconstruct_controls.py` uses Python 3 and Git only; it never runs Dart,
tests, dependency resolution, or either original control runner.

## Source recipes

All paths below are relative to `packages/quds_office_engine/`.

| Cohort | Base library | Additional public-source overlay | Archived writer snapshot |
|---|---|---|---|
| Tabs before | `fb502f612da6e87184e3025fdb379ba02fac1aab` | `lib/src/proofing/german_grammar.dart` from `b9bfe664a4efe4128a47792a1ea2cce16c7dd2c8` | `merged-before-tab-cache.dart` |
| Tabs after | Same | Same | `merged-after-tab-cache.dart` |
| Columns before | `e19783792ef09744f0ec4b3403b44570dd7f6922` | None | `writer-before-column-schema.dart` |
| Columns after | Same | None | `writer-after-column-schema.dart` |

Each snapshot replaces `lib/src/word/serial/odt_document_writer.dart`. The script
checks the exact set of 319 library paths and every SHA-256 value against both
`source_sha256_before` and `source_sha256_after` in the corresponding archived
record. The entire column-after library already matches the integrated commit.
Both archived probe files also match their exact Git blobs in that commit.

## Verify without retaining reconstructed trees

Place the extracted evidence directories wherever convenient, and use a clone
containing the three full commit IDs above:

```bash
python3 reconstruct_controls.py \
  --repo /path/to/quds_office_suite \
  --tab-evidence /path/to/evidence-concurrent-writer \
  --column-evidence /path/to/evidence-concurrent-columns \
  --audit /path/to/new-audit.json
```

The included `audit.json` records a successful reconstruction of all four
cohorts: 319 files per cohort, no missing or unexpected paths, and no mismatched
hashes. Original evidence inputs were hashed before and after reconstruction and
were unchanged. Only the writer differs within each before/after pair.

Add `--materialize /path/to/new-directory` to retain four independent `lib/` and
`test/` source trees plus provenance manifests. The destination must not already
exist. Without this option, all source reconstruction occurs in memory.

## Evidence that must be retained

Keep these top-level files in **each** original evidence directory:

- `before.json`, `after.json`, the corresponding `.jsonl` logs, and `.stderr` files.
- Both writer snapshots named in the table.
- The archived probe: `odt_tab_style_fidelity_test.dart` or
  `odt_columns_schema_fidelity_test.dart`.
- `source-package-config.json` and the original `run_tab_control.py` or
  `run_column_control.py`.

Retain the existing patches, schema reference, and merge-retention records for
review context. Keep this directory's script, guide, and audit with that evidence.
No `isolated-engine` directory is read by the reconstruction script.

## Limits

This establishes exact source reconstruction and preserves the recorded
test, graph, runner, and Dart identities. It does not create a runnable dependency
graph or qualify a new execution. The archived runners and command records remain
the execution record. Repeating those tests elsewhere requires restoring their
dependencies and runtime and deliberately resolving the archived graph's original
absolute/relative package paths; any relocated graph should receive its own hash
and new logs. The original runners, logs, and source records remain unchanged.
