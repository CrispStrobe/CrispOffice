#!/usr/bin/env python3
"""Read-only audit of the narrow section-column schema control pair."""
import hashlib
import json
from pathlib import Path
from urllib.parse import unquote, urlparse

ROOT = Path('/workspace/scratch/7ce65890233c')
EVIDENCE = ROOT / 'evidence-concurrent-columns'
ENGINE = ROOT / 'quds_office_suite/packages/quds_office_engine'
WRITER = 'lib/src/word/serial/odt_document_writer.dart'
TEST = 'test/odt_columns_schema_fidelity_test.dart'
DART = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/flutter-sdk/bin/cache/dart-sdk/bin/dart')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit_run(label, expected_results):
    metadata = json.loads((EVIDENCE / f'{label}.json').read_text())
    raw = EVIDENCE / f'{label}.jsonl'
    events = [json.loads(line) for line in raw.read_text().splitlines() if line.strip()]
    starts = [event['test'] for event in events if event['type'] == 'testStart']
    ends = [event for event in events if event['type'] == 'testDone']
    assert len(starts) == len(ends) == 3
    assert len({test['id'] for test in starts}) == len(starts)
    assert len({end['testID'] for end in ends}) == len(ends)
    assert {test['id'] for test in starts} == {end['testID'] for end in ends}
    assert not any(test['metadata']['skip'] for test in starts)
    assert not any(end['skipped'] for end in ends)
    end_by_id = {end['testID']: end for end in ends}
    loading = [test for test in starts if test['name'].startswith('loading ')]
    assert len(loading) == 1 and end_by_id[loading[0]['id']]['result'] == 'success'
    actual = {}
    for test in starts:
        if test in loading:
            continue
        assert Path(unquote(urlparse(test['url']).path)).resolve() == (EVIDENCE / 'isolated-engine' / TEST).resolve()
        actual[test['name']] = end_by_id[test['id']]['result']
    assert actual == expected_results
    errors = [event for event in events if event['type'] == 'error']
    assert len(errors) == (1 if label == 'before' else 0)
    if errors:
        assert errors[0]['isFailure'] is True
        assert errors[0]['error'] == "Expected: null\n  Actual: '2'\n"
    done = [event for event in events if event['type'] == 'done']
    assert len(done) == 1 and done[0]['success'] == (label == 'after')
    assert metadata['exit_code'] == (1 if label == 'before' else 0)
    assert digest(raw) == metadata['stdout_sha256']
    assert digest(EVIDENCE / f'{label}.stderr') == metadata['stderr_sha256']
    assert metadata['source_sha256_before'] == metadata['source_sha256_after']
    assert len(metadata['source_sha256_after']) == 319
    assert metadata['writer_sha256'] == metadata['source_sha256_after'][WRITER]
    assert digest(EVIDENCE / f'writer-{label}-column-schema.dart') == metadata['writer_sha256']
    return metadata, {
        'substantive_results': actual,
        'loading_results': 1,
        'raw_start_and_end_ids_unique': True,
        'assertion_failures': len(errors),
        'skips': 0,
        'source_stable_during_run': True,
        'raw_log_sha256': digest(raw),
    }


names = [
    'section column counts and gaps use the ODF columns child',
    'a single column retains the ordinary body without a section wrapper',
]
before, before_review = audit_run('before', dict(zip(names, ['failure', 'success'])))
after, after_review = audit_run('after', dict(zip(names, ['success', 'success'])))
stable_keys = ['probe_sha256', 'isolated_package_config_sha256', 'source_package_config_sha256', 'dart_sha256', 'runner_sha256']
assert all(before[key] == after[key] for key in stable_keys)
assert before['source_sha256_after'].keys() == after['source_sha256_after'].keys()
changed = [key for key in before['source_sha256_after'] if before['source_sha256_after'][key] != after['source_sha256_after'][key]]
assert changed == [WRITER]
assert digest(ENGINE / TEST) == digest(EVIDENCE / Path(TEST).name) == after['probe_sha256']
assert digest(EVIDENCE / 'source-package-config.json') == after['source_package_config_sha256']
assert digest(EVIDENCE / 'isolated-engine/.dart_tool/package_config.json') == after['isolated_package_config_sha256']
assert digest(DART) == after['dart_sha256']
assert digest(EVIDENCE / 'run_column_control.py') == after['runner_sha256']
assert all(digest(ENGINE / path) == value for path, value in after['source_sha256_after'].items())

report = {
    'status': 'passed',
    'reviewer': 'odt_writer_review',
    'scope': 'Read-only review of section column schema correction and existing paired logs; no source edits or test reruns.',
    'schema': {
        'source': 'https://docs.oasis-open.org/office/OpenDocument/v1.3/os/part3-schema/OpenDocument-v1.3-os-part3-schema.html',
        'sections_independently_read': ['17.11', '17.12', '19.232', '19.233'],
        'finding': 'style:columns is a child of style:section-properties. Count and gap attributes belong on style:columns; an element without child formatting properties means equal-width columns.',
    },
    'code_review': {
        'blockers': [],
        'change': 'Moves existing serialized count and gap attributes onto the required child; keeps style key, name allocation, numeric representation, and section wrapper selection unchanged.',
        'tests': 'Three distinct (count,gap) settings check style isolation and direct namespace-correct columns placement; ordinary single-column paths remain unwrapped.',
        'incoming_string_assertions_retained': True,
        'full_schema_or_external_consumer_acceptance_claimed': False,
    },
    'before': before_review,
    'after': after_review,
    'identical_test_graph_and_runtime': {key: after[key] for key in stable_keys},
    'only_changed_library_source': changed,
    'all_319_positive_library_sources_match_current_checkout': True,
    'writer_sha256': after['writer_sha256'],
    'review_script_sha256': digest(Path(__file__)),
}
output = Path(__file__).with_suffix('.json')
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'output': str(output), 'writer_sha256': report['writer_sha256']}))
