# ODF extraction and ODS import follow-up

Baseline source: `7a9702c3b74e0e905c76fcf467d608bbb852d004` in Quds Office.

## Confirmed defects and changes

Stored ODT deletions and change comments, and previous ODS cell values, entered
current-text extraction and search. Both `text:tracked-changes` and
`table:tracked-changes` are now excluded by namespace identity in paragraph,
structured table, inline/frame and namespace-less fallback traversal. Current
inserted text remains visible. The XML package is not rewritten by extraction.

The ODS importer walked nested paragraphs twice: once while flattening their
parent and once as separately collected blocks. Anchored text boxes therefore
duplicated their content; notes and ruby pronunciations also entered cell text.
The importer now uses the shared ODF story decoder. Annotation roots are decoded
deliberately and independently, and the existing rejection of ambiguous comment
ownership remains. The existing 1,048,576 UTF-16-code-unit cell limit is preserved;
decoder allocation has a UTF-8 bound of three times that limit, the maximum byte
size of an admitted string. Paragraph separators count toward both limits.

The ODF revision-container interpretation follows ODF 1.3 Part 3, sections 5.5.2,
5.5.5, 5.5.7, 9.9.2 and 9.9.19:
https://docs.oasis-open.org/office/OpenDocument/v1.3/os/part3-schema/OpenDocument-v1.3-os-part3-schema.html

## Evidence

- `baseline.jsonl`: 9 assertion failures, 1 expansion error, 4 passing controls.
- `corrected.jsonl`: all 14 focused cases pass with the exact baseline probes.
- `regression.jsonl`: 201 substantive passes across 9 ODF/ODS files; no skips.
- `search-regression.jsonl`: 27 Office search passes; no skips.
- `final-focused.jsonl`: all 14 focused cases pass after test-only lint fixes.
- `final-tests-baseline.jsonl`: the exact final probes rerun against isolated
  baseline source again produce 9 assertion failures, 1 expansion error and 4
  passes. Both source and probes remain unchanged during this negative run.
- `analysis.json`: four clean scopes and three informational test-file lints.
- `analysis-corrected.json`: the corrected test file passes strict analysis.
- `baseline-setup-failure.*`: the original unavailable `/tmp` failure, retained.
- `summary.json`: machine-readable recount, exact source/probe hashes, and
  verification that all four incoming production files match the baseline SHA.
- `baseline-source/`: exact old production source used by the negative control.
- `baseline-tests/`: exact original probes, including the assertion failures.
- `*.lint-only.diff`: equivalent string-interpolation changes made to satisfy
  strict analysis. No fixture bytes, expected values or assertions were changed.

Every test run has command, working directory, UTC timestamps, source/probe,
dependency graph, lockfile, Dart binary and raw-log hashes in its metadata file.
The before/after hashes of the four production files owned by this investigation
are equal within every accepted run. These focused receipts do not claim a
complete repository freeze; the parent qualification binds the combined source.
These local
focused results do not claim full application, live LibreOffice/Word, native
model or Wasm acceptance. Repeated runs are separately attributed; their totals
must not be added together. The focused cases are included in the 201-pass run.

The four production files changed by this work are:

1. `packages/quds_office_engine/lib/src/odf/odf_text.dart`
2. `packages/quds_office_engine/lib/src/extract/office_text_extractor.dart`
3. `packages/quds_office_engine/lib/src/extract/office_search_text.dart`
4. `packages/quds_office_engine/lib/src/sheet/legacy/ods_sheet_reader.dart`

The new probe files are:

1. `packages/quds_office_engine/test/odf_revision_extraction_test.dart`
2. `packages/quds_office_engine/test/ods_text_story_import_test.dart`

## Reproduction

Use a qualified checkout with the workspace dependency graph already resolved.
`run-extraction.py` defaults to the captured source and runtime paths. Set
`QUDS_SOURCE_ROOT`, `QUDS_DART_BINARY`, `QUDS_PUB_CACHE` and optionally
`QUDS_EVIDENCE_DIR` when replaying elsewhere. The runner sets a writable `TMPDIR`
and refuses to overwrite a previously named evidence run.

```sh
python run-extraction.py new-focused-run
python run-extraction.py new-search-run test/office_search_fidelity_test.dart
```

To reproduce the original negative control, use an isolated checkout of the
baseline commit, copy `baseline-tests/*.dart` into the engine's `test/` directory,
resolve its dependency graph, and point `QUDS_SOURCE_ROOT` at that checkout.
Do not swap source files underneath an active qualification run.

The complete regression selection and all strict-analyzer commands are recorded
in the corresponding metadata. Raw JSON events, including hidden load events,
are retained; reported substantive totals exclude those load events.

`run-final-negative.py` records the exact-final-probe negative control against an
already prepared isolated baseline engine. Its optional `QUDS_BASELINE_ROOT`
points to a checkout containing the baseline engine under
`packages/quds_office_engine` and a resolved `.dart_tool/package_config.json`.
It verifies incoming implementation hashes before copying the current probes
into that isolated engine. It never replaces shared production source.
