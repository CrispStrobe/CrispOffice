"""Replay the final probes against an already prepared, isolated old engine."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

evidence = Path(__file__).parent
source = Path(os.environ.get('QUDS_SOURCE_ROOT', '/workspace/scratch/7ce65890233c/quds_office_suite'))
isolated = Path(os.environ.get('QUDS_BASELINE_ROOT', '/workspace/scratch/7ce65890233c/evidence-writer/bookmark-old-engine-001'))
engine = isolated / 'packages/quds_office_engine'
dart = Path(os.environ.get('QUDS_DART_BINARY', '/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/flutter-sdk/bin/cache/dart-sdk/bin/dart'))
cache = Path(os.environ.get('QUDS_PUB_CACHE', '/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/pub-cache'))
label = sys.argv[1] if len(sys.argv) > 1 else 'final-tests-baseline'
if any((evidence / (label + suffix)).exists() for suffix in ['.jsonl', '.stderr.log', '.metadata.json']):
    raise FileExistsError('Refusing to overwrite named evidence')
tests = ['test/odf_revision_extraction_test.dart', 'test/ods_text_story_import_test.dart']
baseline = json.loads((evidence / 'baseline.metadata.json').read_text())
bound = [name for name in baseline['source_sha256'] if '/lib/' in name]
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
before = {name: sha(isolated / name) for name in bound}
assert all(before[name] == baseline['source_sha256'][name] for name in bound)
for name in tests:
    target = engine / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source / 'packages/quds_office_engine' / name, target)
package_config = isolated / '.dart_tool/package_config.json'
command = [str(dart), '--packages=' + str(package_config), str(cache / 'hosted/pub.dev/test-1.31.1/bin/test.dart'), '--reporter=json', *tests]
env = os.environ.copy()
env['PUB_CACHE'] = str(cache)
env['TMPDIR'] = str(evidence / 'tmp')
metadata = {
    'baseline_head': baseline['head'],
    'cwd': str(engine),
    'command': command,
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_sha256': before,
    'tests_sha256': {name: sha(engine / name) for name in tests},
    'package_config_sha256': sha(package_config),
    'dart_sha256': sha(dart),
    'environment_overrides': {name: env[name] for name in ['PUB_CACHE', 'TMPDIR']},
}
with (evidence / f'{label}.jsonl').open('w') as out, (evidence / f'{label}.stderr.log').open('w') as err:
    result = subprocess.run(command, cwd=engine, env=env, stdout=out, stderr=err)
metadata['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
metadata['exit_code'] = result.returncode
metadata['source_sha256_after'] = {name: sha(isolated / name) for name in bound}
metadata['tests_sha256_after'] = {name: sha(engine / name) for name in tests}
metadata['source_unchanged_during_run'] = metadata['source_sha256_after'] == before
metadata['tests_unchanged_during_run'] = metadata['tests_sha256_after'] == metadata['tests_sha256']
metadata['log_sha256'] = sha(evidence / f'{label}.jsonl')
metadata['stderr_sha256'] = sha(evidence / f'{label}.stderr.log')
events = [json.loads(line) for line in (evidence / f'{label}.jsonl').read_text().splitlines() if line.startswith('{')]
names = {e['test']['id']: e['test']['name'] for e in events if e['type'] == 'testStart'}
results = [{**e, 'name': names.get(e['testID'])} for e in events if e['type'] == 'testDone' and not e.get('hidden')]
metadata['test_results'] = results
(evidence / f'{label}.metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps({'exit_code': result.returncode, 'source_unchanged': metadata['source_unchanged_during_run'], 'tests_unchanged': metadata['tests_unchanged_during_run'], 'results': results}, indent=2))
sys.exit(result.returncode)
