import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(os.environ.get('QUDS_SOURCE_ROOT', '/workspace/scratch/7ce65890233c/quds_office_suite'))
evidence = Path(os.environ.get('QUDS_EVIDENCE_DIR', str(Path(__file__).parent)))
dart = Path(os.environ.get('QUDS_DART_BINARY', '/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/flutter-sdk/bin/cache/dart-sdk/bin/dart'))
label = sys.argv[1]
if '/' in label or '\\' in label or label in ['', '.', '..']:
    raise ValueError('The evidence label must be a simple filename component')
evidence.mkdir(parents=True, exist_ok=True)
if any((evidence / f'{label}{suffix}').exists() for suffix in ['.jsonl', '.stderr.log', '.metadata.json', '.results.json']):
    raise FileExistsError(f'Refusing to overwrite existing evidence for {label}')
(evidence / 'tmp').mkdir(exist_ok=True)
tests = sys.argv[2:] or ['test/odf_revision_extraction_test.dart', 'test/ods_text_story_import_test.dart']
bound = [
    'packages/quds_office_engine/lib/src/odf/odf_text.dart',
    'packages/quds_office_engine/lib/src/extract/office_text_extractor.dart',
    'packages/quds_office_engine/lib/src/extract/office_search_text.dart',
    'packages/quds_office_engine/lib/src/sheet/legacy/ods_sheet_reader.dart',
    *['packages/quds_office_engine/' + path for path in tests],
    '.dart_tool/package_config.json',
    'pubspec.lock',
]
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
metadata = {
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'source_sha256': {name: sha(root / name) for name in bound},
    'dart': str(dart),
    'dart_sha256': sha(dart),
    'dart_version': subprocess.check_output([str(dart), '--version'], text=True).strip(),
    'cwd': str(root / 'packages/quds_office_engine'),
    'command': [str(dart), 'test', '--reporter=json', *tests],
}
env = os.environ.copy()
env['PUB_CACHE'] = os.environ.get('QUDS_PUB_CACHE', '/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/pub-cache')
env['TMPDIR'] = str(evidence / 'tmp')
metadata['environment_overrides'] = {name: env[name] for name in ['PUB_CACHE', 'TMPDIR']}
with (evidence / f'{label}.jsonl').open('w') as out, (evidence / f'{label}.stderr.log').open('w') as err:
    result = subprocess.run(metadata['command'], cwd=metadata['cwd'], env=env, stdout=out, stderr=err)
metadata['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
metadata['exit_code'] = result.returncode
metadata['source_sha256_after'] = {name: sha(root / name) for name in bound}
metadata['source_unchanged_during_run'] = metadata['source_sha256'] == metadata['source_sha256_after']
metadata['log_sha256'] = sha(evidence / f'{label}.jsonl')
metadata['stderr_sha256'] = sha(evidence / f'{label}.stderr.log')
(evidence / f'{label}.metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
events = [json.loads(line) for line in (evidence / f'{label}.jsonl').read_text().splitlines() if line.startswith('{')]
names = {event['test']['id']: event['test']['name'] for event in events if event['type'] == 'testStart'}
results = [{**event, 'name': names.get(event.get('testID'))} for event in events if event['type'] in ['testDone', 'error', 'done']]
(evidence / f'{label}.results.json').write_text(json.dumps(results, indent=2) + '\n')
substantive = [event for event in results if event['type'] == 'testDone' and not event.get('hidden')]
print(json.dumps({'label': label, 'exit_code': result.returncode, 'source_unchanged_during_run': metadata['source_unchanged_during_run'], 'substantive_passes': sum(event['result'] == 'success' and not event.get('skipped') for event in substantive), 'skips': sum(bool(event.get('skipped')) for event in substantive), 'failures': [event for event in results if event['type'] == 'error']}, indent=2))
sys.exit(result.returncode)
