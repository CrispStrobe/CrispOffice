#!/usr/bin/env python3
"""Record a source-bound run of the standalone-story ODT regression file."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/7ce65890233c')
REPO = BASE / 'quds_office_suite'
OUT = BASE / 'evidence-writer'
RUNTIME = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime')
DART = RUNTIME / 'flutter-sdk/bin/cache/dart-sdk/bin/dart'
FILES = [
    'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart',
    'packages/quds_office_engine/test/odt_story_visual_fidelity_test.dart',
    'packages/quds_office_engine/test/fixtures/fidelity/story-media.docx',
    'pubspec.lock',
    '.dart_tool/package_config.json',
]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

name = sys.argv[1]
log = OUT / f'{name}.jsonl'
stderr = OUT / f'{name}.stderr'
receipt = OUT / f'{name}.json'
assert not any(path.exists() for path in (log, stderr, receipt))
command = [str(DART), 'test', '--reporter=json', 'test/odt_story_visual_fidelity_test.dart']
env = os.environ.copy()
env.update(
    PUB_CACHE=str(RUNTIME / 'pub-cache'),
    FLUTTER_ROOT=str(RUNTIME / 'flutter-sdk'),
    CI='true',
    DART_SUPPRESS_ANALYTICS='true',
    FLUTTER_SUPPRESS_ANALYTICS='true',
)
record = {
    'command': command,
    'cwd': str(REPO / 'packages/quds_office_engine'),
    'head': subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip(),
    'source_sha256_before': {name: sha(REPO / name) for name in FILES},
    'runtime_sha256': sha(DART),
    'runner_sha256': sha(Path(__file__)),
    'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
}
start = time.monotonic()
with log.open('w') as output, stderr.open('w') as errors:
    result = subprocess.run(command, cwd=record['cwd'], env=env, stdout=output, stderr=errors)
record.update(
    exit_code=result.returncode,
    seconds=round(time.monotonic() - start, 3),
    completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    source_sha256_after={name: sha(REPO / name) for name in FILES},
    stdout_sha256=sha(log),
    stderr_sha256=sha(stderr),
)
events = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
record['test_results'] = [
    {'name': starts[e['testID']]['name'], 'result': e['result'], 'hidden': e['hidden'], 'skipped': e['skipped']}
    for e in events if e.get('type') == 'testDone'
]
record['errors'] = [e for e in events if e.get('type') == 'error']
receipt.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'run': name, 'exit_code': result.returncode, 'test_results': record['test_results'], 'errors': record['errors']}, indent=2))
sys.exit(result.returncode)
