#!/usr/bin/env python3
"""Record the writer's neighboring regression and static-analysis scopes."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

BASE = Path('/workspace/scratch/7ce65890233c')
REPO = BASE / 'quds_office_suite'
OUT = BASE / 'evidence-writer'
RUNTIME = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime')
DART = RUNTIME / 'flutter-sdk/bin/cache/dart-sdk/bin/dart'
CWD = REPO / 'packages/quds_office_engine'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

env = os.environ.copy()
env.update(PUB_CACHE=str(RUNTIME / 'pub-cache'), TMPDIR=str(OUT / 'tmp'), CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true')
tests = sorted(str(path.relative_to(CWD)) for path in (CWD / 'test').glob('odt_*_test.dart'))
tests.append('test/story_media_fidelity_test.dart')
targets = ['lib/src/word/serial/odt_document_writer.dart', 'test/odt_story_visual_fidelity_test.dart', 'test/odt_bookmark_range_fidelity_test.dart']
commands = [
    ('final-adjacent-suites', [str(DART), 'test', '--reporter=json', *tests]),
    ('final-strict-analysis', [str(DART), 'analyze', '--fatal-infos', '--fatal-warnings', *targets]),
    ('final-format', [str(DART), 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed', *targets]),
]
for name, command in commands:
    log = OUT / f'{name}.log'
    assert not log.exists()
    inputs = {str(path.relative_to(REPO)): sha(path) for path in [CWD / targets[0], *(CWD / path for path in tests)]}
    record = {
        'command': command,
        'cwd': str(CWD),
        'head': subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip(),
        'source_sha256_before': inputs,
        'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'dart_sha256': sha(DART),
        'runner_sha256': sha(Path(__file__)),
    }
    start = time.monotonic()
    print('START', name, flush=True)
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=CWD, env=env, stdout=stream, stderr=subprocess.STDOUT)
    record.update(exit_code=result.returncode, seconds=round(time.monotonic() - start, 3), log_sha256=sha(log), source_sha256_after={path: sha(REPO / path) for path in inputs})
    assert record['source_sha256_after'] == inputs
    if name == 'final-adjacent-suites':
        events = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
        starts = {event['test']['id']: event['test'] for event in events if event.get('type') == 'testStart'}
        record['test_results'] = [
            {'name': starts[event['testID']]['name'], 'result': event['result'], 'hidden': event['hidden'], 'skipped': event['skipped']}
            for event in events if event.get('type') == 'testDone'
        ]
        visible = [event for event in record['test_results'] if not event['hidden']]
        print(json.dumps({'run': name, 'exit_code': result.returncode, 'passed': sum(event['result'] == 'success' and not event['skipped'] for event in visible), 'failed': sum(event['result'] != 'success' for event in visible), 'skipped': sum(event['skipped'] for event in visible), 'selected_test_files': len(tests)}), flush=True)
    else:
        print(log.read_text(), flush=True)
    (OUT / f'{name}.json').write_text(json.dumps(record, indent=2) + '\n')
    if result.returncode:
        raise SystemExit(result.returncode)
