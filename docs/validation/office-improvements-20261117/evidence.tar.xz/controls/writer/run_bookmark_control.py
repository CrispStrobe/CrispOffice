#!/usr/bin/env python3
"""Run final bookmark tests against an isolated engine at a frozen Git ref."""
from pathlib import Path
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time
from urllib.parse import unquote, urlparse

BASE = Path('/workspace/scratch/7ce65890233c')
REPO = BASE / 'quds_office_suite'
OUT = BASE / 'evidence-writer'
RUN = sys.argv[1]
CONTROL = OUT / f'bookmark-old-engine-{RUN}'
SOURCE = '7a9702c3b74e0e905c76fcf467d608bbb852d004'
RUNTIME = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime')
DART = RUNTIME / 'flutter-sdk/bin/cache/dart-sdk/bin/dart'
REL = 'packages/quds_office_engine'
PROBE = 'test/odt_bookmark_range_fidelity_test.dart'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert not CONTROL.exists()
CONTROL.mkdir()
archive = subprocess.check_output([
    'git', '-C', str(REPO), 'archive', SOURCE, f'{REL}/lib', f'{REL}/pubspec.yaml',
])
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    tar.extractall(CONTROL, filter='data')
cwd = CONTROL / REL
(cwd / 'test').mkdir()
shutil.copyfile(REPO / REL / PROBE, cwd / PROBE)
shutil.copyfile(REPO / REL / PROBE, OUT / f'odt_bookmark_range_fidelity_test.{RUN}.dart')
source_config = REPO / '.dart_tool/package_config.json'
config = json.loads(source_config.read_text())
test_runner = None
for package in config['packages']:
    uri = urlparse(package['rootUri'])
    path = Path(unquote(uri.path)) if uri.scheme == 'file' else (source_config.parent / package['rootUri']).resolve()
    if package['name'] == 'quds_office_engine':
        path = cwd
    elif package['name'] == 'test':
        test_runner = path / 'bin/test.dart'
    package['rootUri'] = path.as_uri() + '/'
assert test_runner is not None
(CONTROL / '.dart_tool').mkdir()
config_path = CONTROL / '.dart_tool/package_config.json'
config_path.write_text(json.dumps(config, indent=2) + '\n')
command = [str(DART), f'--packages={config_path}', str(test_runner), '--reporter=json', PROBE]
env = os.environ.copy()
env.update(PUB_CACHE=str(RUNTIME / 'pub-cache'), TMPDIR=str(OUT / 'tmp'), CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true')
log = OUT / f'bookmark-old-source-{RUN}.jsonl'
stderr = OUT / f'bookmark-old-source-{RUN}.stderr'
assert not log.exists()
record = {
    'command': command,
    'cwd': str(cwd),
    'source_ref': SOURCE,
    'git_archive_sha256': hashlib.sha256(archive).hexdigest(),
    'isolated_engine_lib_sha256': {str(p.relative_to(cwd)): sha(p) for p in sorted((cwd / 'lib').rglob('*')) if p.is_file()},
    'probe_sha256': sha(cwd / PROBE),
    'source_package_config_sha256': sha(source_config),
    'isolated_package_config_sha256': sha(config_path),
    'dart_sha256': sha(DART),
    'runner_sha256': sha(Path(__file__)),
    'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
}
start = time.monotonic()
with log.open('w') as output, stderr.open('w') as errors:
    result = subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=errors)
record.update(exit_code=result.returncode, seconds=round(time.monotonic()-start, 3), stdout_sha256=sha(log), stderr_sha256=sha(stderr))
record['isolated_engine_lib_sha256_after'] = {str(p.relative_to(cwd)): sha(p) for p in sorted((cwd / 'lib').rglob('*')) if p.is_file()}
assert record['isolated_engine_lib_sha256_after'] == record['isolated_engine_lib_sha256']
events = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
record['test_results'] = [
    {'name': starts[e['testID']]['name'], 'result': e['result'], 'hidden': e['hidden'], 'skipped': e['skipped']}
    for e in events if e.get('type') == 'testDone'
]
record['errors'] = [e for e in events if e.get('type') == 'error']
(OUT / f'bookmark-old-source-{RUN}.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['exit_code', 'test_results', 'errors']}, indent=2))
raise SystemExit(result.returncode)
