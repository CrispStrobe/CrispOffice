#!/usr/bin/env python3
"""Run an isolated before/after control for the merged ODT column-schema defect."""
from pathlib import Path
from urllib.parse import unquote, urljoin, urlparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/7ce65890233c')
REPO = BASE / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
OUT = BASE / 'evidence-concurrent-columns'
ISOLATED = OUT / 'isolated-engine'
RUNTIME = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime')
DART = RUNTIME / 'flutter-sdk/bin/cache/dart-sdk/bin/dart'
WRITER = 'lib/src/word/serial/odt_document_writer.dart'
PROBE = 'test/odt_columns_schema_fidelity_test.dart'
RUN = sys.argv[1]
assert RUN in ('before', 'after')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source_map():
    return {str(path.relative_to(ISOLATED)): sha(path) for path in sorted((ISOLATED / 'lib').rglob('*')) if path.is_file()}

if RUN == 'before':
    assert not ISOLATED.exists()
    ISOLATED.mkdir()
    shutil.copytree(ENGINE / 'lib', ISOLATED / 'lib')
    shutil.copyfile(ENGINE / 'pubspec.yaml', ISOLATED / 'pubspec.yaml')
    (ISOLATED / 'test').mkdir()
    shutil.copyfile(ENGINE / PROBE, ISOLATED / PROBE)
    config_path = REPO / '.dart_tool/package_config.json'
    config = json.loads(config_path.read_text())
    for package in config['packages']:
        path = Path(unquote(urlparse(urljoin(config_path.as_uri(), package['rootUri'])).path)).resolve()
        if package['name'] == 'quds_office_engine':
            path = ISOLATED
        package['rootUri'] = path.as_uri() + '/'
    (ISOLATED / '.dart_tool').mkdir()
    (ISOLATED / '.dart_tool/package_config.json').write_text(json.dumps(config, indent=2) + '\n')
    (OUT / 'source-package-config.json').write_bytes(config_path.read_bytes())
else:
    before = json.loads((OUT / 'before.json').read_text())
    require_original = {path: value for path, value in before['source_sha256_before'].items() if path != WRITER}
    assert {path: value for path, value in source_map().items() if path != WRITER} == require_original
    assert sha(ENGINE / PROBE) == sha(ISOLATED / PROBE) == before['probe_sha256']
    shutil.copyfile(ENGINE / WRITER, ISOLATED / WRITER)

config_path = ISOLATED / '.dart_tool/package_config.json'
config = json.loads(config_path.read_text())
test_root = Path(unquote(urlparse(next(package['rootUri'] for package in config['packages'] if package['name'] == 'test')).path))
command = [str(DART), f'--packages={config_path}', str(test_root / 'bin/test.dart'), '--reporter=json', PROBE]
env = os.environ.copy()
(OUT / 'tmp').mkdir(exist_ok=True)
env.update(PUB_CACHE=str(RUNTIME / 'pub-cache'), TMPDIR=str(OUT / 'tmp'), CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true')
log, errors = OUT / f'{RUN}.jsonl', OUT / f'{RUN}.stderr'
assert not log.exists()
record = {
    'command': command, 'cwd': str(ISOLATED),
    'qualified_input': 'fb502f612da6e87184e3025fdb379ba02fac1aab',
    'concurrent_input': 'b9bfe664a4efe4128a47792a1ea2cce16c7dd2c8',
    'captured_main': 'edd023c3505942cd2433bfa6c815a7d009432a3c',
    'source_sha256_before': source_map(),
    'writer_sha256': sha(ISOLATED / WRITER), 'probe_sha256': sha(ISOLATED / PROBE),
    'isolated_package_config_sha256': sha(config_path),
    'source_package_config_sha256': sha(OUT / 'source-package-config.json'),
    'dart_sha256': sha(DART), 'runner_sha256': sha(Path(__file__)),
    'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    'scope': 'A structural column-schema regression and single-column control on the isolated merged source; optional AOT/model integration is outside this control.',
}
start = time.monotonic()
with log.open('w') as output, errors.open('w') as stderr:
    result = subprocess.run(command, cwd=ISOLATED, env=env, stdout=output, stderr=stderr)
record.update(exit_code=result.returncode, seconds=round(time.monotonic() - start, 3), source_sha256_after=source_map(), stdout_sha256=sha(log), stderr_sha256=sha(errors))
assert record['source_sha256_before'] == record['source_sha256_after']
events = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
starts = {event['test']['id']: event['test'] for event in events if event.get('type') == 'testStart'}
record['test_results'] = [
    {'name': starts[event['testID']]['name'], 'result': event['result'], 'hidden': event['hidden'], 'skipped': event['skipped']}
    for event in events if event.get('type') == 'testDone'
]
record['errors'] = [event for event in events if event.get('type') == 'error']
(OUT / f'{RUN}.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('exit_code', 'test_results', 'errors')}, indent=2))
raise SystemExit(result.returncode)
