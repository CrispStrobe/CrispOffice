# Office export and visible-text improvements — 17 November 2026

This follow-up fixes confirmed fidelity defects in the qualified Office continuation.
It builds on `7a9702c3b74e0e905c76fcf467d608bbb852d004` and leaves the earlier
[continuation and qualification evidence](../office-resume-20261117/README.md) intact.

**Accepted canonical source:**
[`fb502f612da6e87184e3025fdb379ba02fac1aab`](https://github.com/CrispStrobe/quds_office_suite/commit/fb502f612da6e87184e3025fdb379ba02fac1aab).
Its source tree is `36fc90b8c478e1c6938808c4adbe1630fcd86549`.
The final source-specific run passed **564 engine tests across 33 files and 42
Flutter editor tests across six files: 606 tests, zero failures and zero skips**.

## Confirmed behavior changes

| Problem | Correction and regression evidence |
| --- | --- |
| Deleted paragraphs, old spreadsheet values and change comments entered current extraction/search. | Exclude namespace-qualified text and spreadsheet revision stores, including the history-only fallback. Preserve current inserted text, foreign lookalikes and raw package XML. |
| ODS cells duplicated anchored frame paragraphs and exposed note/ruby annotation payload. | Use the shared ODF story decoder: each paragraph contributes its own inline text, then its anchored text-box stories once. Preserve comment ownership, authored whitespace and XLSX save/reopen. |
| Standalone default header/footer pictures disappeared on ODT export. | Emit the modeled header/footer visual lists through the existing story writer and media registry, including image-only stories and textual visual fallbacks. A real DOCX story-media fixture exercises import followed by export. |
| Equivalent uppercase/lowercase run colors could force a continuous section onto another master page. | Normalize foreground and highlight colors before constructing the style-cache key, matching emitted XML. Different colors and changed picture geometry remain distinguishable. |
| Native DOCX bookmark ends were dropped because they have an ID without a name. | Pair ends with starts by canonical numeric ID within the same logical story. Overlapping ranges and ranges crossing paragraphs retain their endpoints; headers, footers, notes, comments, frames and covered cells keep independent maps. Source boundary objects are unchanged. |

The canonical implementation change is limited to five engine files. Four new
test files add **23 cases**. Their final old-source controls produce **18 failures
(17 matcher failures and one hidden-whitespace expansion error) and five clean
control passes**; all 23 pass on the corrected source. The tests use identical
final bytes between their accepted negative controls and positive runs.

The ODF revision distinction follows [ODF 1.3 Part 3, sections 5.5 and 9.9](https://docs.oasis-open.org/office/OpenDocument/v1.3/os/part3-schema/OpenDocument-v1.3-os-part3-schema.html).
Revision containers hold stored content and metadata. Current insertions are
in the live document between change markers, so excluding the containers does
not remove inserted text.

The ODS importer retains its existing 1,048,576 UTF-16-code-unit text limit,
including paragraph separators. The shared decoder is separately bounded in
UTF-8 bytes; an exact-limit non-ASCII case and an over-limit case verify that
the change preserves that contract.

## Accepted qualification

| Scope | Result |
| --- | --- |
| Engine ODT/ODF/ODS/ODP, search, isolate open/save, bookmarks, sections and story media | 564 passed; 33 selected files |
| Editor bookmark editing/copy/history and note editing/numbering | 42 passed; six selected files |
| Entire engine strict analysis | Passed with fatal informational diagnostics |
| All nine changed Dart files, language version 3.12 | Formatting passed |
| Whitespace gate | Passed |

The new controlled cases are included in the 606; they are not added again.
The preceding 3,280-test continuation qualification remains historical evidence
for its own source. This follow-up does not claim to have repeated that entire
selection or the unrelated German proofing/Zotero qualification.

The executed [runner](run_validation.py), [receipt](qualification.json),
[independent review](independent-review.json), [archive](evidence.tar.xz) and
[member index](evidence-index.json) bind the source commit, commands, test routing
and raw events. The reviewer independently recounted starts and completions,
excluded loading events, checked suite identities and source URLs, and compared
the saved maps to the frozen Git blobs and local inputs.

Before/after maps are identical for 2,776 materialized source entries in the
recorded scopes, 5,365 dependency/manifest entries, 514 SDK/runtime entries and
19 workspace entries. The maps explicitly state their scope; they are not a
claim that unrelated sparse paths were executed. SDK library and platform files,
locked manifests, actual test realpaths and hashes are included. The recorded
runtime is Flutter 3.47.8 / Dart 3.13.7.

## CrispCloud integration

Companion [PR #238](https://github.com/CrispStrobe/CrispCloud/pull/238) pins this
exact source at host
[`63ca9f46a7c08bd9f1aa64f9aa7cc6ce2a17e66c`](https://github.com/CrispStrobe/CrispCloud/commit/63ca9f46a7c08bd9f1aa64f9aa7cc6ce2a17e66c).
The guarded sync writes the five engine files and four new canonical tests,
with no deletions. Its manifest contains **2,607 managed files: 750 canonical
files and the unchanged 1,857-file standalone parser**.

The host adds matching visible-story behavior, namespace-based ODT preview
parsing, separate note paragraph boundaries and bounded explicit cell whitespace.
An independently authored DOCX passes through the production importer, writer
and preview service, with independent XML assertions for bookmarks, styles,
lists, tables, notes, annotation ownership and unchanged model/source data.

Its separate final run passed **107 Dart/Flutter tests and 28 Python controls**,
with no failures or skips. The host preservation audit retains all 50 canonical
and 46 host Zotero paths, 20 audited customizations, six original notices and
the same 12 inherited mode differences. See the
[host report](https://github.com/CrispStrobe/CrispCloud/blob/codex/office-qualified-resume-20261117/docs/validation/office-improvements-20261117/README.md).

## Evidence and reproduction

The archive contains the final raw logs/maps, independent audit and exact runner;
writer and extraction regression controls; failed setup/probe attempts; exact
source and test snapshots; and locked setup inputs. Its complete member index is
verified by rereading each member and comparing its recorded size and SHA-256.
Temporary compiler caches and reproducible old-source working trees are excluded.

The first writer setup attempt lacked a writable temporary directory. Early
visual probes used missing-element access before explicit cardinality assertions,
and the first bookmark probe omitted a required test constructor argument.
Those attempts are preserved, followed by genuine failing controls using the
final test bytes. Three extraction-test string-interpolation lint changes also
retain originals, their patch and final-byte negative/positive reruns. Assertions
were not relaxed to convert product failures into success.

An earlier combined local run used a commit with the same tree before the remote
commit identity and runner input-binding review were finalized. It is retained
as a preflight; the accepted numbers above come only from the later exact-source
run at `fb502f61` with the reviewed runner. Counts are never combined.

Restore the pinned SDK/cache and the archived locked package graph, checking its
hashes. Use a clean checkout at the accepted source, preserve its manifests, and
resolve the archived lock offline with `--enforce-lockfile`. Then run:

```sh
python3 run_validation.py --kind canonical \
  --repo /path/to/quds --harness /path/to/quds \
  --sdk /path/to/flutter-sdk --cache /path/to/pub-cache \
  --expected-head fb502f612da6e87184e3025fdb379ba02fac1aab \
  --baseline 7a9702c3b74e0e905c76fcf467d608bbb852d004 \
  --output /path/to/new-evidence-directory
```

The runner refuses an existing output directory and uncommitted program inputs.
The archived setup/reviewer scripts and source snapshots support reproducing
controls or recounting logs without rerunning product tests.

## Limits and publication

This is local engine/editor/service qualification. It does not establish a full
application or export-dialog acceptance run, live Word/LibreOffice/Zotero
interoperability, real native/model quality or Wasm acceptance. The header/footer
repair covers default modeled stories; first/even-page and opaque preserved story
variants were not expanded.

Publication adds documentation/evidence only after the accepted source. The
source-equivalence receipt verifies every non-documentation Git blob and mode.
Branch updates require the observed prior head and do not force concurrent work.
Commit messages retain `[skip ci]`. No GitHub Actions, workflow, check-run or
CI-status endpoint was queried or awaited.
