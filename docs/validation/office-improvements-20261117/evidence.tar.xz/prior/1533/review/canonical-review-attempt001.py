#!/usr/bin/env python3
"""Independently audit saved canonical qualification; never execute product tests."""
from __future__ import annotations

import argparse
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urljoin, urlparse


EXPECTED_SOURCE = 'e19783792ef09744f0ec4b3403b44570dd7f6922'
REVIEWED_RUNNER = '169a4074740523bd3325e18a089fb2bff99476588df987c41aaafa6829747659'
ORIGINAL_RUNNER = '0f09023a8166f28aa43d9008c2ec22a310d3bee834c48127908c08356364d0ad'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def git(repo, *arguments):
    return subprocess.check_output(['git', '-C', str(repo), *arguments])


def optional_file_hash(path):
    return digest(path.read_bytes()) if path.is_file() else None


def resolve_event_path(value, cwd):
    parsed = urlparse(value)
    check(not parsed.scheme or parsed.scheme == 'file', 'Unexpected event URI: ' + value)
    path = Path(unquote(parsed.path)) if parsed.scheme else Path(value)
    return (path if path.is_absolute() else cwd / path).resolve(strict=True)


def frozen_tree(repo, commit):
    result = {}
    for record in git(repo, 'ls-tree', '-r', '-z', commit).split(b'\0'):
        if not record:
            continue
        metadata, name = record.split(b'\t', 1)
        mode, kind, blob = metadata.decode().split()
        if kind == 'blob':
            result[name.decode()] = {'mode': mode, 'git_blob': blob}
    return result


def recount(command, evidence, repo, expected_files, frozen_inputs, platform):
    name = command['name']
    cwd = Path(command['cwd']).resolve(strict=True)
    expected = {(cwd / value).resolve(strict=True) for value in expected_files}
    check(set(command['selected_files']) == set(expected_files), name + ': selected paths differ')
    check(len(command['selected_files']) == len(expected_files), name + ': duplicate selection')
    argument_files = [value for value in command['command'] if value.endswith('_test.dart')]
    check(Counter(argument_files) == Counter(expected_files), name + ': command routing differs')
    routes = command['test_routing']
    check({route['selected'] for route in routes} == set(expected_files), name + ': missing routing receipt')
    check(len(routes) == len(expected_files), name + ': duplicate routing receipt')
    for route in routes:
        actual = (cwd / route['selected']).resolve(strict=True)
        relative = str(actual.relative_to(repo))
        check(actual in expected and route['resolved'] == str(actual), name + ': wrong realpath')
        check(route['source_path'] == relative, name + ': wrong source path')
        check(route['sha256'] == frozen_inputs[relative]['sha256'] == digest(actual.read_bytes()),
              name + ': routed source hash differs')

    suites, starts, endings, errors, completions = {}, {}, {}, [], []
    non_json_lines = 0
    for line in (evidence / (name + '.stdout.log')).read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            non_json_lines += 1
            continue
        event_type = event.get('type')
        if event_type == 'suite':
            suite = event['suite']
            check(suite['id'] not in suites, name + ': duplicate suite ID')
            check(suite['platform'] == platform, name + ': wrong platform')
            suites[suite['id']] = suite
        elif event_type == 'testStart':
            test = event['test']
            check(test['id'] not in starts, name + ': duplicate start ID')
            starts[test['id']] = test
        elif event_type == 'testDone':
            check(event['testID'] not in endings, name + ': duplicate completion ID')
            endings[event['testID']] = event
        elif event_type == 'error':
            errors.append(event)
        elif event_type == 'done':
            completions.append(event)

    check(len(completions) == 1 and completions[0].get('success') is True,
          name + ': incomplete or unsuccessful runner')
    check(not errors, name + ': raw error event')
    check(starts.keys() == endings.keys(), name + ': start/completion mismatch')
    resolved_suites = {key: resolve_event_path(suite['path'], cwd) for key, suite in suites.items()}
    check(set(resolved_suites.values()) == expected and len(suites) == len(expected),
          name + ': actual suite paths differ')

    counts = Counter()
    excluded = Counter()
    suite_counts = Counter()
    identities = []
    source_urls = set()
    for identifier, end in endings.items():
        start = starts[identifier]
        test_name = start['name']
        if end.get('hidden') or test_name.startswith('loading ') or test_name.endswith(('(setUpAll)', '(tearDownAll)')):
            excluded['loading' if test_name.startswith('loading ') else 'hidden_or_lifecycle'] += 1
            continue
        check(start['suiteID'] in resolved_suites, name + ': unknown suite reference')
        suite_path = resolved_suites[start['suiteID']]
        suite_relative = str(suite_path.relative_to(repo))
        check(start.get('url'), name + ': substantive test has no source URL')
        source = resolve_event_path(start['url'], cwd)
        source_relative = str(source.relative_to(repo))
        check(source_relative in frozen_inputs, name + ': unbound test source URL')
        check(digest(source.read_bytes()) == frozen_inputs[source_relative]['sha256'],
              name + ': source URL content changed')
        source_urls.add(source_relative)
        outcome = 'skipped' if end.get('skipped') else end.get('result')
        counts[outcome] += 1
        suite_counts[suite_relative] += 1
        identities.append((suite_relative, test_name, source_relative, start.get('line'), start.get('column')))

    check(counts.get('success', 0) > 0 and set(counts) == {'success'}, name + ': failed/skipped/empty cohort')
    check(len(set(identities)) == len(identities), name + ': duplicate substantive case identity')
    reported = command['tests']
    check(reported == {'complete': True, 'passed': counts['success'], 'failed': 0, 'skipped': 0},
          name + ': receipt disagrees with independent recount')
    derived = read_json(evidence / (name + '-events.json'))
    check(derived['passed'] == counts['success'] and derived['failed'] == derived['skipped'] == 0
          and derived['complete'] is True and len(derived['records']) == len(identities),
          name + ': derived event artifact disagrees with raw events')
    return ({
        'passed': counts['success'], 'failed': 0, 'skipped': 0,
        'test_files': len(expected), 'platform': platform,
        'raw_start_events': len(starts), 'raw_completion_events': len(endings),
        'excluded_events': dict(excluded), 'non_json_output_lines': non_json_lines,
        'per_file_passes': dict(sorted(suite_counts.items())),
        'source_urls_verified': sorted(source_urls),
        'case_identity_sha256': digest(json.dumps(sorted(identities), ensure_ascii=False).encode()),
        'exact_suite_realpaths_and_source_hashes_verified': True,
    }, identities)


def audit(args, report):
    repo, evidence, runner = args.repo.resolve(), args.evidence.resolve(), args.runner.resolve()
    receipt = read_json(evidence / 'receipt.json')
    check(receipt['status'] == 'passed', 'Qualification receipt is not terminal/passed')
    check(receipt['source_commit'] == EXPECTED_SOURCE, 'Unexpected qualified source')
    check(receipt['kind'] == 'canonical', 'Wrong qualification kind')
    check(digest(runner.read_bytes()) == REVIEWED_RUNNER, 'Runner differs from independently reviewed bytes')
    check(all(receipt.get(key) is True for key in ('inputs_unchanged', 'source_head_unchanged',
          'analysis_config_restored', 'analysis_config_unchanged_during_run')), 'Failed preservation gate')
    before, after = [read_json(evidence / ('inputs-' + label + '.json')) for label in ('before', 'after')]
    check(before == after, 'Before/after input maps differ')
    check(before['runner_sha256'] == REVIEWED_RUNNER, 'Recorded runner hash differs')
    tree = frozen_tree(repo, EXPECTED_SOURCE)
    source_tree = git(repo, 'rev-parse', EXPECTED_SOURCE + '^{tree}').decode().strip()
    check(receipt['source_tree'] == source_tree, 'Frozen tree attribution differs')
    prefixes = ('lib/', 'test/', 'tool/', 'packages/quds_office_engine/lib/',
                'packages/quds_office_engine/test/', 'packages/quds_office_engine/third_party/',
                'packages/quds_office_editor/lib/', 'packages/quds_office_editor/test/',
                'packages/quds_office_editor/example/lib/', 'packages/quds_office_editor/example/test/',
                'packages/quds_office_editor/example/assets/', 'packages/quds_office_editor/example/fonts/',
                'packages/quds_office_editor/fonts/', 'packages/quds_proofing_harper/lib/',
                'packages/quds_proofing_aot/lib/', 'packages/quds_proofing_aot/test/',
                'packages/quds_proofing_aot/tool/', 'tools/proofing/german_model/',
                'packages/quds_reports/lib/', 'packages/legacy_doc_parser/')
    names = {name for name in tree if (name.startswith(prefixes) or Path(name).name in
             ('pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml')) and (repo / name).exists()}
    check(names == set(before['source']), 'Materialized source inventory differs')
    for name in sorted(names):
        local = repo / name
        data = os.readlink(local).encode() if local.is_symlink() else local.read_bytes()
        mode = '120000' if local.is_symlink() else ('100755' if local.stat().st_mode & 0o111 else '100644')
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        check(tree[name] == {'mode': mode, 'git_blob': blob}, 'Live input differs from frozen Git blob/mode: ' + name)
        check(before['source'][name] == {'mode': mode, 'git_blob': blob, 'sha256': digest(data)},
              'Source map differs from frozen/live bytes: ' + name)

    config = repo / '.dart_tool/package_config.json'
    graph = read_json(config)
    check(digest(config.read_bytes()) == before['graph_sha256'], 'Package graph content changed')
    check(digest((repo / 'pubspec.lock').read_bytes()) == before['lock_sha256'], 'Locked graph changed')
    dependencies = {}
    for package in graph['packages']:
        package_root = Path(unquote(urlparse(urljoin(config.as_uri(), package['rootUri'])).path)).resolve()
        for filename in ('pubspec.yaml', 'pubspec.lock', 'pubspec_overrides.yaml', 'analysis_options.yaml'):
            path = package_root / filename
            dependencies[str(path)] = optional_file_hash(path)
        if (package_root / 'lib').resolve().is_relative_to(repo):
            continue
        for directory in ('lib', 'bin', 'assets'):
            for path in (package_root / directory).rglob('*'):
                if path.is_file():
                    dependencies[str(path)] = digest(path.read_bytes())
    check(dependencies == before['dependencies'], 'Dependency inventory/hash differs')

    workspace_paths = {repo / name for name in ('pubspec.yaml', 'pubspec.lock', 'pubspec_overrides.yaml',
                       'analysis_options.yaml', '.dart_tool/package_config.json', '.dart_tool/package_graph.json')}
    for pattern in ('packages/*/pubspec*.yaml', 'packages/*/example/pubspec*.yaml',
                    'apps/*/pubspec*.yaml', 'packages/*/analysis_options.yaml'):
        workspace_paths.update(repo.glob(pattern))
    check({str(path): optional_file_hash(path) for path in workspace_paths} == before['workspace'],
          'Workspace manifest/config inventory differs')

    commands = {command['name']: command for command in receipt['commands']}
    expected_commands = {'engine-tests', 'editor-tests', 'aot-vm-tests', 'aot-node-tests', 'studio-tests',
                         'candidate-python-controls', 'engine-analysis', 'aot-analysis',
                         'editor-proofing-analysis', 'studio-analysis', 'changed-dart-format', 'whitespace'}
    check(len(commands) == len(receipt['commands']) and set(commands) == expected_commands,
          'Qualification command inventory differs')
    sdk = Path(commands['engine-tests']['command'][0]).resolve().parents[4]
    sdk_files = {sdk / name for name in (
        'bin/cache/dart-sdk/bin/dart', 'bin/cache/dart-sdk/bin/dartaotruntime',
        'bin/cache/flutter_tools.snapshot', 'bin/cache/flutter.version.json',
        'bin/cache/artifacts/engine/linux-x64/flutter_tester',
        'bin/cache/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot',
        'bin/cache/dart-sdk/bin/snapshots/analysis_server_aot.dart.snapshot',
        'bin/cache/dart-sdk/bin/snapshots/dart2js_aot.dart.snapshot',
        'bin/cache/dart-sdk/bin/snapshots/dartdev_aot.dart.snapshot')}
    for directory in ('bin/cache/dart-sdk/lib', 'bin/cache/artifacts/engine/common/flutter_patched_sdk',
                      'bin/cache/artifacts/engine/common/flutter_patched_sdk_product'):
        sdk_files.update(path for path in (sdk / directory).rglob('*') if path.is_file())
    icu = sdk / 'bin/cache/artifacts/engine/linux-x64/icudtl.dat'
    if icu.is_file():
        sdk_files.add(icu)
    runtime = {str(path.relative_to(sdk)): digest(path.read_bytes()) for path in sdk_files}
    for label in ('node', 'python'):
        metadata = receipt[label + '_runtime']
        executable = Path(metadata['path']).resolve(strict=True)
        runtime[label + '/executable'] = digest(executable.read_bytes())
        check(runtime[label + '/executable'] == metadata['sha256'], label + ' executable changed')
        version = subprocess.check_output([str(executable), '--version'], text=True).strip()
        check(version == metadata['version'], label + ' version differs')
    check(runtime == before['runtime'], 'Runtime inventory/hash differs')

    engine_prefix = 'packages/quds_office_engine/'
    engine_files = []
    for name in tree:
        if not name.startswith(engine_prefix):
            continue
        relative = name[len(engine_prefix):]
        path = Path(relative)
        if path.parent == Path('test') and path.name.endswith('_test.dart') and (
            path.name.startswith(('odt_', 'odf_', 'ods_', 'odp_', 'word_bookmark_', 'word_section_')) or
            path.name in ('office_search_fidelity_test.dart', 'office_isolate_open_test.dart',
                          'office_isolate_save_test.dart', 'story_media_fidelity_test.dart')):
            engine_files.append(relative)
        if path.parent == Path('test/proofing') and path.name.endswith('_test.dart'):
            engine_files.append(relative)
    editor_files = ['test/' + name + '_test.dart' for name in (
        'word_bookmark_fidelity', 'word_bookmark_copy', 'word_bookmark_history',
        'word_generated_bookmark_paste', 'word_note_numbering', 'word_notes_editing',
        'word_german_grammar_integration', 'word_manual_proofing', 'word_proofing_session',
        'word_proofing_correction', 'word_proofing_dialog')]
    aot_prefix = 'packages/quds_proofing_aot/'
    aot_files = sorted(name[len(aot_prefix):] for name in tree if name.startswith(aot_prefix)
                       and Path(name[len(aot_prefix):]).parent == Path('test') and name.endswith('_test.dart'))
    studio_files = ['test/studio_aot_test.dart', 'test/widget_test.dart']
    cohorts = {
        'engine-tests': ('packages/quds_office_engine', sorted(engine_files), 'vm'),
        'editor-tests': ('packages/quds_office_editor', editor_files, 'vm'),
        'aot-vm-tests': ('packages/quds_proofing_aot', aot_files, 'vm'),
        'aot-node-tests': ('packages/quds_proofing_aot', aot_files, 'node'),
        'studio-tests': ('packages/quds_office_editor/example', studio_files, 'vm'),
    }
    summaries, identities = {}, {}
    for name, (directory, files, platform) in cohorts.items():
        check(Path(commands[name]['cwd']).resolve() == repo / directory, name + ': wrong package cwd')
        summaries[name], identities[name] = recount(commands[name], evidence, repo, files, before['source'], platform)
    check(Counter(identities['aot-node-tests']) == Counter(identities['aot-vm-tests']),
          'Node and VM substantive case identities differ')
    check(commands['aot-node-tests'].get('repeat_of') == 'aot-vm-tests', 'Missing repeat attribution')
    unique = [identity for name, group in identities.items() if name != 'aot-node-tests' for identity in group]
    check(len(unique) == len(set(unique)), 'Duplicate cases across the unique cohorts')
    summaries['aot-node-tests']['repeat_of'] = 'aot-vm-tests'
    check('--dart-define=QUDS_AOT_ENDPOINT=http://127.0.0.1:17018/' in commands['studio-tests']['command'],
          'Studio endpoint setting differs')

    control = read_json(evidence / 'candidate-python-controls-result.json')
    python_module = repo / 'tools/proofing/german_model/test_candidate_admission.py'
    module_ast = ast.parse(python_module.read_bytes())
    declared = sorted('test_candidate_admission.' + cls.name + '.' + method.name
                      for cls in module_ast.body if isinstance(cls, ast.ClassDef)
                      for method in cls.body if isinstance(method, ast.FunctionDef) and method.name.startswith('test_'))
    check(len(declared) == 5 and sorted(control['case_ids']) == declared, 'Python case identity differs')
    check(control['passed'] and control['tests_run'] == control['expected_count'] == 5 and
          control['failures'] == control['errors'] == control['skips'] == 0, 'Python controls incomplete')
    check(control['source'] == str(python_module) and control['sha256'] == control['sha256_after'] ==
          before['source'][str(python_module.relative_to(repo))]['sha256'], 'Python source binding differs')
    python_log = (evidence / 'candidate-python-controls.stderr.log').read_text()
    completed_python_ids = re.findall(r'^test_\w+ \(([^)]+)\) \.\.\. ok$', python_log, re.MULTILINE)
    check(sorted(completed_python_ids) == declared and re.search(r'^Ran 5 tests in ', python_log, re.MULTILINE)
          and python_log.rstrip().endswith('OK'), 'Python raw log differs from structured result')
    check(commands['candidate-python-controls']['python_controls'] == control, 'Python receipt differs')
    check(Path(commands['candidate-python-controls']['command'][0]).resolve() ==
          Path(receipt['python_runtime']['path']), 'Python command executable differs')

    changed = git(repo, 'diff', '--name-only', receipt['baseline'], EXPECTED_SOURCE).decode().splitlines()
    changed_dart = sorted(path for path in changed if path.startswith('packages/') and path.endswith('.dart'))
    formatter = commands['changed-dart-format']['command']
    check(sorted(value for value in formatter if value.endswith('.dart')) == changed_dart,
          'Formatting target inventory differs')
    check('--language-version=3.12' in formatter and '--set-exit-if-changed' in formatter, 'Formatting gate weakened')
    for name, command in commands.items():
        check(command.get('passed') is True and command['exit_code'] == 0, name + ': command failed')
        for stream in ('stdout', 'stderr'):
            check(digest((evidence / (name + '.' + stream + '.log')).read_bytes()) == command[stream + '_sha256'],
                  name + ': raw log hash differs')
        if name.endswith('-analysis'):
            check('--fatal-infos' in command['command'] and
                  'No issues found!' in (evidence / (name + '.stdout.log')).read_text(), name + ': strict analyzer gate differs')
    check(commands['engine-analysis']['command'][-1] == 'packages/quds_office_engine', 'Engine analysis scope differs')
    check(commands['aot-analysis']['command'][-1] == 'packages/quds_proofing_aot', 'AOT analysis scope differs')
    check(commands['whitespace']['command'] == ['git', 'diff', '--check', receipt['baseline'], 'HEAD'], 'Whitespace gate differs')

    observed_head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    committed_since = git(repo, 'diff', '--name-only', EXPECTED_SOURCE, observed_head).decode().splitlines()
    dirty = git(repo, 'status', '--porcelain', '--untracked-files=all').decode().splitlines()
    check(all(path.startswith('docs/') for path in committed_since), 'Product commit changed after qualification')
    check(all(line[3:].startswith('docs/') for line in dirty), 'Non-documentation worktree modification')
    root = runner.parent
    check(digest((root / 'run_improvement_validation.py').read_bytes()) == ORIGINAL_RUNNER, 'Historical runner modified')
    historical = read_json(root / 'final-canonical/receipt.json')
    check(historical['source_commit'] == 'fb502f612da6e87184e3025fdb379ba02fac1aab', 'Historical source attribution changed')
    artifacts = {str(path.relative_to(evidence)): digest(path.read_bytes()) for path in evidence.iterdir() if path.is_file()}
    report.update({
        'status': 'passed', 'source_commit': EXPECTED_SOURCE, 'source_tree': source_tree,
        'observed_head': observed_head, 'only_documentation_changes_since_source': True,
        'cohorts': summaries, 'unique_dart_flutter_passes': len(unique),
        'unique_dart_flutter_test_files': len({case[0] for case in unique}),
        'node_repeat_passes': len(identities['aot-node-tests']), 'python_controls': control,
        'input_maps': {name: {'entries': len(before[name]), 'before_after_equal': True,
                            'live_inventory_and_hashes_verified': True}
                       for name in ('source', 'dependencies', 'runtime', 'workspace')},
        'source_git_blobs_and_modes_verified': True, 'graph_sha256': before['graph_sha256'],
        'lock_sha256': before['lock_sha256'], 'runtime_metadata': {
            'node': receipt['node_runtime'], 'python': receipt['python_runtime'],
            'flutter': read_json(sdk / 'bin/cache/flutter.version.json')},
        'command_gates_verified': list(commands), 'changed_dart_format_targets': changed_dart,
        'qualification_runner_sha256': REVIEWED_RUNNER,
        'historical_runner_sha256': ORIGINAL_RUNNER,
        'historical_606_source': historical['source_commit'],
        'historical_counts_added': False, 'node_repeat_added_to_unique_count': False,
        'raw_logs_recounted_independently': True, 'runner_summary_used_to_compute_counts': False,
        'evidence_sha256': artifacts, 'findings': [],
    })


def main():
    base = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=base / 'quds_office_suite')
    parser.add_argument('--evidence', type=Path, default=base / 'integrated-canonical')
    parser.add_argument('--runner', type=Path, default=base / 'run_integrated_improvement_validation.py')
    parser.add_argument('--output', type=Path, default=Path(__file__).with_suffix('.json'))
    args = parser.parse_args()
    check(not args.output.exists(), 'Preserve the prior review; choose a fresh output path')
    report = {
        'status': 'failed', 'reviewed_utc': datetime.now(timezone.utc).isoformat(),
        'method': 'Independent raw-event recount and read-only Git, file, dependency graph, runtime and log verification.',
        'scope': 'Frozen local Office/proofing/AOT/Studio unit/widget qualification. No full application/export-dialog, live interoperability, native/model or Wasm acceptance.',
        'product_tests_executed': False, 'product_code_modified': False,
        'review_script_sha256': digest(Path(__file__).read_bytes()),
    }
    try:
        audit(args, report)
    except BaseException as error:
        report['findings'] = [repr(error)]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        stream.write(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: report.get(key) for key in ('status', 'source_commit', 'unique_dart_flutter_passes',
          'node_repeat_passes', 'findings')}))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
