#!/usr/bin/env python3
"""Independently audit frozen canonical Office evidence without running tests.

The event recount deliberately ignores the runner's parsed events files and
test-count summaries. Git objects, live file bytes, real paths and recorded
before/after maps are verified separately. No source is written.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote, urljoin, urlparse
import argparse
import hashlib
import json
import os
import subprocess
import sys

EXPECTED_SOURCE = 'fb502f612da6e87184e3025fdb379ba02fac1aab'
EXPECTED_TREE = '36fc90b8c478e1c6938808c4adbe1630fcd86549'
BASELINE = '7a9702c3b74e0e905c76fcf467d608bbb852d004'
EXPECTED_WRITER = {
    'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart': '0d00989aef423d95222153b7e3c580c6c9ad19c3673f8d055dcab97e80a6d472',
    'packages/quds_office_engine/test/odt_story_visual_fidelity_test.dart': 'e79f4f43075941b345e7956c60afa3ca64c1bf25e2fcf1ba06999ba6310d65ea',
    'packages/quds_office_engine/test/odt_bookmark_range_fidelity_test.dart': 'db4561321db44fdd0f0793995157fed2e1c9d7d190f1cafdbdd0d431bcdeaec9',
}
ENGINE_NAMES = '''
odf_annotation_extraction odf_covered_cell_extraction odf_export_text_fidelity
odf_frame_extraction odf_revision_extraction odf_text_box_extraction
odp_presentation_writer odp_table_fidelity odp_transform_fidelity
ods_sheet_reader ods_sheet_writer ods_text_story_import
odt_bookmark_range_fidelity odt_comment_fidelity odt_document_writer
odt_header_footer_fidelity odt_list_fidelity odt_note_fidelity
odt_paragraph_decoration odt_paragraph_properties odt_section_continuation
odt_section_fidelity odt_section_integration odt_story_visual_fidelity
odt_structure_fidelity odt_table_merge office_isolate_open office_isolate_save
office_search_fidelity story_media_fidelity word_bookmark_copy
word_bookmark_fidelity word_section_clone_fidelity
'''.split()
EDITOR_NAMES = '''
word_bookmark_fidelity word_bookmark_copy word_bookmark_history
word_generated_bookmark_paste word_note_numbering word_notes_editing
'''.split()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_hash(path):
    return digest(path.read_bytes()) if path.is_file() else None


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def tree_entries(repo):
    result = {}
    for entry in git(repo, 'ls-tree', '-r', '-z', EXPECTED_SOURCE).split(b'\0'):
        if not entry:
            continue
        meta, raw_path = entry.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        require(kind == 'blob', f'Unexpected tracked object: {raw_path!r}')
        result[raw_path.decode()] = {'mode': mode, 'git_blob': oid}
    return result


def resolve_url(value, cwd):
    parsed = urlparse(value)
    if parsed.scheme == 'file':
        path = Path(unquote(parsed.path))
    else:
        require(not parsed.scheme, f'Unsupported path URI: {value}')
        path = Path(value)
    return (path if path.is_absolute() else cwd / path).resolve(strict=True)


def review_events(repo, evidence, row, names, expected_count, source):
    cwd = Path(row['cwd'])
    relative = [f'test/{name}_test.dart' for name in names]
    expected = {(cwd / path).resolve(strict=True) for path in relative}
    require(len(expected) == len(names), 'Duplicate planned suite')
    require(set(row['selected_files']) == set(relative), 'Declared suite selection differs from independent plan')
    command_selection = [arg for arg in row['command'] if arg.endswith('_test.dart')]
    require(len(command_selection) == len(names) and set(command_selection) == set(relative), 'Executed command selection differs')
    require(not any(arg.startswith(('--name', '--plain-name', '--tags', '--exclude-tags')) for arg in row['command']), 'Unexpected case filter')
    routed = {entry['selected']: entry for entry in row['test_routing']}
    require(len(routed) == len(names), 'Duplicate or missing routing receipt')
    for relative_path in relative:
        actual = (cwd / relative_path).resolve(strict=True)
        require(actual.is_relative_to(repo), f'Test escapes source repository: {actual}')
        entry = routed[relative_path]
        source_path = str(actual.relative_to(repo))
        require(entry['resolved'] == str(actual), 'Realpath routing mismatch')
        require(entry['source_path'] == source_path, 'Source-path routing mismatch')
        require(file_hash(actual) == source[source_path]['sha256'] == entry['sha256'], 'Test hash binding mismatch')

    log = evidence / f"{row['name']}.stdout.log"
    raw_lines = log.read_text().splitlines()
    require(raw_lines, 'Empty raw log')
    events = [json.loads(line) for line in raw_lines]
    allowed = {'start', 'suite', 'testStart', 'testDone', 'allSuites', 'group', 'done'}
    require(all(event.get('type') in allowed for event in events), 'Error, unknown or unparsed raw event')
    require(events[0]['type'] == 'start', 'Missing initial protocol event')
    require(events[-1]['type'] == 'done' and events[-1].get('success') is True, 'Missing final successful done event')
    counts = Counter(event['type'] for event in events)
    require(counts['start'] == counts['done'] == counts['allSuites'] == 1, 'Duplicate protocol completion or suite declaration')
    require(next(event['count'] for event in events if event['type'] == 'allSuites') == len(names), 'allSuites count differs')
    suites, starts, ends, loads, cases = {}, {}, {}, {}, []
    source_bindings = []
    seen_names = set()
    for event in events:
        kind = event['type']
        if kind == 'suite':
            suite = event['suite']
            require(suite['id'] not in suites, 'Duplicate raw suite ID')
            require(suite['platform'] == 'vm', 'Unexpected test platform')
            suites[suite['id']] = resolve_url(suite['path'], cwd)
        elif kind == 'group':
            require(event['group']['metadata'].get('skip') is False, 'Skipped group')
        elif kind == 'testStart':
            test = event['test']
            require(test['id'] not in starts, 'Duplicate started test ID')
            require(test['suiteID'] in suites, 'Test refers to undeclared suite')
            require(test['metadata'].get('skip') is False, 'Skipped test metadata')
            starts[test['id']] = test
        elif kind == 'testDone':
            test_id = event['testID']
            require(test_id in starts and test_id not in ends, 'Unstarted or duplicate terminal ID')
            require(event['result'] == 'success' and event.get('skipped') is False, 'Failure, error or skipped terminal event')
            ends[test_id] = event
            test = starts[test_id]
            suite_path = suites[test['suiteID']]
            if test['name'].startswith('loading '):
                require(event['hidden'] is True and test.get('url') is None, 'Unexpected loading-event classification')
                require(test['suiteID'] not in loads, 'Duplicate loading event for a suite')
                loads[test['suiteID']] = test_id
                continue
            require(event['hidden'] is False, 'Hidden substantive terminal event')
            require(not test['name'].endswith(('(setUpAll)', '(tearDownAll)')), 'Unexpected setup/teardown event; explicit review required')
            authored_url = test.get('root_url') or test.get('url')
            require(authored_url and authored_url.startswith('file:'), 'Missing concrete authored test source URL')
            resolved_test = resolve_url(authored_url, cwd)
            require(resolved_test == suite_path, 'Test source URL/root_url resolves outside its suite')
            pair = (str(suite_path), test['name'])
            require(pair not in seen_names, 'Repeated substantive test name within one suite')
            seen_names.add(pair)
            cases.append({'id': test_id, 'suite': str(suite_path.relative_to(repo)), 'name': test['name']})
            source_bindings.append(str(resolved_test.relative_to(repo)))
    require(set(starts) == set(ends), 'Not every started test completed exactly once')
    require(len(suites) == len(names) and set(suites.values()) == expected, 'Raw suite set differs from independent exact plan')
    require(set(loads) == set(suites), 'Not every suite loaded successfully exactly once')
    require(len(cases) == expected_count, f'Raw substantive count is {len(cases)}, expected {expected_count}')
    per_suite = Counter(case['suite'] for case in cases)
    require(len(per_suite) == len(names), 'One selected suite has no substantive cases')
    return {
        'status': 'passed', 'raw_log_sha256': file_hash(log),
        'raw_event_counts': dict(counts), 'unique_start_end_pairs': len(starts),
        'loading_events_excluded': len(loads), 'substantive_passes': len(cases),
        'failures': 0, 'skips': 0, 'errors': 0,
        'exact_suite_count': len(suites), 'per_suite_passes': dict(sorted(per_suite.items())),
        'all_authored_test_urls_match_real_suite_paths': True,
        'cases': cases,
    }


def main(args):
    repo, evidence, sdk = args.repo.resolve(), args.evidence.resolve(), args.sdk.resolve()
    receipt = json.loads((evidence / 'receipt.json').read_text())
    before = json.loads((evidence / 'inputs-before.json').read_text())
    after = json.loads((evidence / 'inputs-after.json').read_text())
    require(git(repo, 'rev-parse', 'HEAD').decode().strip() == EXPECTED_SOURCE, 'Current source commit differs')
    require(git(repo, 'rev-parse', 'HEAD^{tree}').decode().strip() == EXPECTED_TREE, 'Current source tree differs')
    require(git(repo, 'status', '--porcelain', '--untracked-files=all') == b'', 'Source worktree is not clean')
    require(receipt['source_commit'] == EXPECTED_SOURCE and receipt['source_tree'] == EXPECTED_TREE, 'Receipt source binding differs')
    require(receipt['baseline'] == BASELINE and receipt['kind'] == 'canonical', 'Wrong qualification kind or baseline')
    require(before == after, 'Captured source/dependency/runtime/workspace maps changed')
    frozen = tree_entries(repo)
    prefixes = (
        'lib/', 'test/', 'tool/', 'packages/quds_office_engine/lib/',
        'packages/quds_office_engine/test/', 'packages/quds_office_engine/third_party/',
        'packages/quds_office_editor/lib/', 'packages/quds_office_editor/test/',
        'packages/quds_office_editor/fonts/', 'packages/quds_reports/lib/',
        'packages/legacy_doc_parser/',
    )
    expected_source_paths = {
        path for path in frozen
        if (repo / path).exists()
        and (path.startswith(prefixes) or Path(path).name in {'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'})
    }
    require(set(before['source']) == expected_source_paths, 'Captured materialized source scope is incomplete or has extra entries')
    for path, record in before['source'].items():
        actual = repo / path
        content = os.readlink(actual).encode() if actual.is_symlink() else actual.read_bytes()
        mode = '120000' if actual.is_symlink() else ('100755' if actual.stat().st_mode & 0o111 else '100644')
        blob = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
        require({'mode': mode, 'git_blob': blob} == frozen[path], f'Git mode/blob differs: {path}')
        require(record == {'mode': mode, 'git_blob': blob, 'sha256': digest(content)}, f'Captured source hash differs: {path}')
    require(all(file_hash(repo / path) == expected for path, expected in EXPECTED_WRITER.items()), 'Final writer/test bytes differ from reviewed patches')

    # Verify every captured absolute path independently, including explicit
    # absence sentinels. Then reconstruct the dependency path set from the
    # resolved package graph, rather than accepting a stable subset blindly.
    for section in ('dependencies', 'workspace'):
        for path, expected in before[section].items():
            require(file_hash(Path(path)) == expected, f'Live {section} input differs: {path}')
    for path, expected in before['runtime'].items():
        require(file_hash(sdk / path) == expected, f'Live runtime input differs: {path}')
    config_path = repo / '.dart_tool/package_config.json'
    require(file_hash(config_path) == before['graph_sha256'], 'Package graph was not restored')
    require(file_hash(repo / 'pubspec.lock') == before['lock_sha256'], 'Locked dependencies changed')
    require(file_hash(args.runner) == before['runner_sha256'], 'Executed runner bytes changed')
    graph = json.loads(config_path.read_text())
    dependency_paths = set()
    for package in graph['packages']:
        root = Path(unquote(urlparse(urljoin(config_path.as_uri(), package['rootUri'])).path)).resolve(strict=True)
        dependency_paths.update(str(root / name) for name in ('pubspec.yaml', 'pubspec.lock', 'pubspec_overrides.yaml', 'analysis_options.yaml'))
        if (root / 'lib').resolve().is_relative_to(repo):
            continue
        for child in ('lib', 'bin', 'assets'):
            dependency_paths.update(str(path) for path in (root / child).rglob('*') if path.is_file())
    require(set(before['dependencies']) == dependency_paths, 'Captured dependency scope differs from resolved graph')
    runtime_files = {
        sdk / path for path in (
            'bin/cache/dart-sdk/bin/dart', 'bin/cache/dart-sdk/bin/dartaotruntime',
            'bin/cache/flutter_tools.snapshot', 'bin/cache/flutter.version.json',
            'bin/cache/artifacts/engine/linux-x64/flutter_tester',
            'bin/cache/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot',
            'bin/cache/dart-sdk/bin/snapshots/analysis_server_aot.dart.snapshot',
        )
    }
    for child in ('bin/cache/dart-sdk/lib', 'bin/cache/artifacts/engine/common/flutter_patched_sdk', 'bin/cache/artifacts/engine/common/flutter_patched_sdk_product'):
        runtime_files.update(path for path in (sdk / child).rglob('*') if path.is_file())
    icu = sdk / 'bin/cache/artifacts/engine/linux-x64/icudtl.dat'
    if icu.is_file():
        runtime_files.add(icu)
    require(set(before['runtime']) == {str(path.relative_to(sdk)) for path in runtime_files}, 'Captured runtime scope is incomplete')

    rows = {row['name']: row for row in receipt['commands']}
    expected_gates = {'engine-tests', 'editor-tests', 'engine-analysis', 'changed-dart-format', 'whitespace'}
    require(len(rows) == len(receipt['commands']) and set(rows) == expected_gates, 'Missing or duplicate qualification gate')
    for name, row in rows.items():
        require(row['exit_code'] == 0, f'Gate process failed: {name}')
        for stream in ('stdout', 'stderr'):
            require(file_hash(evidence / f'{name}.{stream}.log') == row[f'{stream}_sha256'], f'Raw gate log hash mismatch: {name} {stream}')
        require((evidence / f'{name}.stderr.log').read_bytes() == b'', f'Unexpected stderr: {name}')
    require('No issues found!' in (evidence / 'engine-analysis.stdout.log').read_text(), 'Analyzer did not report clean result')
    require('--fatal-infos' in rows['engine-analysis']['command'], 'Analyzer fatal-info gate missing')
    require(rows['engine-analysis']['command'][-1] == 'packages/quds_office_engine', 'Analyzer scope mismatch')
    changed = git(repo, 'diff', '--name-only', BASELINE, EXPECTED_SOURCE).decode().splitlines()
    require(len(changed) == 9 and all(path.endswith('.dart') for path in changed), 'Unexpected final implementation scope')
    formatting = rows['changed-dart-format']['command']
    require(set(arg for arg in formatting if arg.endswith('.dart')) == set(changed), 'Formatter misses changed Dart paths')
    require('--set-exit-if-changed' in formatting and '--output=none' in formatting and '--language-version=3.12' in formatting, 'Formatter gate flags differ')
    require('Formatted 9 files (0 changed)' in (evidence / 'changed-dart-format.stdout.log').read_text(), 'Formatter changed source')
    require((evidence / 'whitespace.stdout.log').read_bytes() == b'', 'Whitespace gate emitted problems')
    require(rows['whitespace']['command'] == ['git', 'diff', '--check', BASELINE, 'HEAD'], 'Whitespace command scope mismatch')

    engine_tree_names = {
        Path(path).name.removesuffix('_test.dart')
        for path in frozen if path.startswith('packages/quds_office_engine/test/')
        and len(Path(path).parts) == 4 and path.endswith('_test.dart')
        and (Path(path).name.startswith(('odt_', 'odf_', 'ods_', 'odp_', 'word_bookmark_', 'word_section_'))
             or Path(path).name in {'office_search_fidelity_test.dart', 'office_isolate_open_test.dart', 'office_isolate_save_test.dart', 'story_media_fidelity_test.dart'})
    }
    require(engine_tree_names == set(ENGINE_NAMES), 'Independent engine suite list misses frozen family member')
    engine_result = review_events(repo, evidence, rows['engine-tests'], ENGINE_NAMES, 564, before['source'])
    editor_result = review_events(repo, evidence, rows['editor-tests'], EDITOR_NAMES, 42, before['source'])
    allowed_scope = 'Local source-specific Office tests and strict gates; no application/dialog, live interoperability, model or Wasm acceptance.'
    require(receipt['scope'] == allowed_scope, 'Qualification scope wording differs')
    return {
        'status': 'passed', 'reviewed_utc': datetime.now(timezone.utc).isoformat(),
        'source_commit': EXPECTED_SOURCE, 'source_tree': EXPECTED_TREE,
        'source_worktree_clean': True, 'tests_rerun': False,
        'raw_logs_recounted_independently': True,
        'runner_summary_counts_used_for_recount': False,
        'engine': engine_result, 'editor': editor_result,
        'combined_substantive_passes': 606, 'combined_unique_test_files': 39,
        'inputs': {
            'recorded_before_after_equal': True, 'live_inputs_match_captured_maps': True,
            'source_paths_verified_against_git_modes_blobs_and_bytes': len(before['source']),
            'dependency_paths_including_absence_sentinels': len(before['dependencies']),
            'dependency_absence_sentinels': sum(value is None for value in before['dependencies'].values()),
            'runtime_inputs': len(before['runtime']), 'workspace_inputs': len(before['workspace']),
            'resolved_packages': len(graph['packages']), 'package_graph_restored': True,
            'captured_scope_completeness_checked': True,
            'writer_and_regression_hashes': EXPECTED_WRITER,
        },
        'gates_verified': sorted(expected_gates), 'changed_dart_paths': changed,
        'scope': allowed_scope,
        'attribution': 'Only this frozen 564-engine/42-editor cohort is counted. Earlier 3280-test qualification and separate controls/host runs are not added or reattributed.',
        'artifact_sha256': {
            path.name: file_hash(path) for path in sorted(evidence.iterdir()) if path.is_file()
        },
        'review_script_sha256': file_hash(Path(__file__)),
        'qualification_runner_sha256': file_hash(args.runner),
    }


if __name__ == '__main__':
    base = Path('/workspace/scratch/7ce65890233c')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=base / 'quds_office_suite')
    parser.add_argument('--evidence', type=Path, default=base / 'final-canonical')
    parser.add_argument('--sdk', type=Path, default=Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/flutter-sdk'))
    parser.add_argument('--runner', type=Path, default=base / 'run_improvement_validation.py')
    parser.add_argument('--output', type=Path, default=base / 'final-independent-review/canonical-review.json')
    args = parser.parse_args()
    try:
        result = main(args)
    except Exception as error:
        result = {'status': 'failed', 'error': repr(error), 'review_script_sha256': file_hash(Path(__file__))}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('engine', 'editor', 'artifact_sha256')}, indent=2))
    sys.exit(0 if result['status'] == 'passed' else 1)
