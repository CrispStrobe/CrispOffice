#!/usr/bin/env python3
from datetime import datetime, timezone
from pathlib import Path
import base64, hashlib, json, os, shutil, subprocess, sys, time

from capture_source import capture

ROOT = Path('/workspace/scratch/bca670ac89b2')
REPO = ROOT / 'quds_office_suite'
OUT = ROOT / 'all-caps-validation'
FREEZE = '0fe00b18fef6b79a435817c99714f987329d5f3c'
BASE = '01517de8886ef7bd24947894be5dc823d0328869'
EXPECTED_MANIFEST = '9b7185c99dbc2bd7cb77243d46565c34082327ebecd39a6fff42913efd66ae4e'
DART = ROOT / 'runtime-flutter/flutter/bin/cache/dart-sdk/bin/dart'
NODE = Path(shutil.which('node'))
ENGINE = REPO / 'packages/quds_office_engine'
EXPECTED = json.loads((OUT / 'frozen-source.json').read_text())

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write_json(path, value):
    Path(path).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

def capture_bound(folder, phase):
    actual = capture()
    path = folder / ('source-' + phase + '.json')
    path.write_text(json.dumps(actual, sort_keys=True, separators=(',', ':')) + '\n')
    differences = sorted(key for key in set(actual) | set(EXPECTED) if actual.get(key) != EXPECTED.get(key))
    result = {'files': len(actual), 'manifest_sha256': digest(path), 'matches_freeze': not differences, 'different_paths': differences}
    if differences or result['manifest_sha256'] != EXPECTED_MANIFEST:
        raise RuntimeError('Source differs from frozen manifest: ' + str(differences[:20]))
    return result

def run(folder, name, argv, cwd, timeout=900):
    argv = [str(arg) for arg in argv]
    started = datetime.now(timezone.utc).isoformat()
    stamp = time.monotonic()
    print('START ' + name, flush=True)
    with (folder / (name + '.stdout')).open('wb') as stdout, (folder / (name + '.stderr')).open('wb') as stderr:
        try:
            proc = subprocess.run(argv, cwd=cwd, stdout=stdout, stderr=stderr, env=os.environ, timeout=timeout)
            code = proc.returncode
            timed_out = False
        except subprocess.TimeoutExpired:
            code = None
            timed_out = True
    result = {'name': name, 'argv': argv, 'cwd': str(cwd), 'started_utc': started, 'duration_seconds': round(time.monotonic() - stamp, 3), 'exit_code': code, 'timed_out': timed_out, 'stdout_sha256': digest(folder / (name + '.stdout')), 'stderr_sha256': digest(folder / (name + '.stderr'))}
    write_json(folder / (name + '.command.json'), result)
    print('END ' + name + ' exit=' + str(code), flush=True)
    return result

assert digest(OUT / 'frozen-source.json') == EXPECTED_MANIFEST
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == FREEZE

runtime_inputs = [
    DART,
    DART.parent / 'dartaotruntime',
    DART.parent / 'snapshots/dart2js_aot.dart.snapshot',
    DART.parent / 'snapshots/analysis_server_aot.dart.snapshot',
    DART.parent / 'snapshots/dartdev_aot.dart.snapshot',
    NODE,
    REPO / '.dart_tool/package_config.json',
    ROOT / 'runtime/provenance.json',
    ROOT / 'runtime-flutter/pub-cache-receipt.json',
    Path(__file__),
    ROOT / 'capture_source.py',
]
provenance = {'qualified_source': FREEZE, 'initial_main': BASE, 'expected_manifest_sha256': EXPECTED_MANIFEST, 'runtime_files': {str(p): {'bytes': p.stat().st_size, 'sha256': digest(p)} for p in runtime_inputs}, 'environment': {key: os.environ.get(key) for key in ('PUB_CACHE', 'FLUTTER_ROOT', 'TMPDIR', 'CI', 'DART_SUPPRESS_ANALYTICS')}, 'dart_version': subprocess.check_output([str(DART), '--version'], text=True, stderr=subprocess.STDOUT).strip(), 'node_version': subprocess.check_output([str(NODE), '--version'], text=True).strip()}

checks = OUT / 'checks'
checks.mkdir(exist_ok=True)
check_summary = {'qualified_source': FREEZE, 'passed': False, 'commands': []}
try:
    check_summary['source_before'] = capture_bound(checks, 'before')
    changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, FREEZE, '--', '*.dart'], cwd=REPO, text=True).splitlines()
    (checks / 'changed-dart-paths.txt').write_text('\n'.join(changed) + '\n')
    check_summary['dart_paths'] = changed
    check_summary['dart_path_count'] = len(changed)
    check_summary['commands'].append(run(checks, 'analyze', [DART, 'analyze', '--fatal-infos', *changed], REPO))
    check_summary['commands'].append(run(checks, 'format', [DART, 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed', *changed], REPO))
    check_summary['source_after'] = capture_bound(checks, 'after')
    check_summary['passed'] = all(command['exit_code'] == 0 for command in check_summary['commands'])
except BaseException as error:
    check_summary['error'] = repr(error)
finally:
    write_json(checks / 'summary.json', check_summary)
    write_json(checks / 'provenance.json', provenance)

portable = OUT / 'portable'
portable.mkdir(exist_ok=True)
portable_summary = {'qualified_source': FREEZE, 'passed': False, 'commands': [], 'comparison_scope': 'Complete raw JSON receipts, including selected native part hashes. DOCM ZIP byte identity is not asserted.'}
try:
    portable_summary['source_before'] = capture_bound(portable, 'before')
    example = ENGINE / 'example/macros/word_all_caps.bas'
    encoded = base64.b64encode(example.read_bytes()).decode('ascii')
    portable_summary['example'] = {'path': str(example.relative_to(REPO)), 'bytes': example.stat().st_size, 'sha256': digest(example)}
    define = '-DWORD_ALL_CAPS_BAS_BASE64=' + encoded
    script = 'tool/macros/web_vba_word_all_caps_smoke.dart'
    vm = run(portable, 'vm', [DART, define, script], ENGINE)
    portable_summary['commands'].append(vm)
    compile_js = run(portable, 'compile-js', [DART, 'compile', 'js', '-O2', define, '-o', portable / 'word-all-caps.js', script], ENGINE)
    portable_summary['commands'].append(compile_js)
    if compile_js['exit_code'] == 0:
        source = ROOT / 'runtime/pub-cache/hosted/pub.dev/node_preamble-2.0.2/lib/preamble.dart'
        preamble = source.read_text().split('final _normal = r"""', 1)[1].split('""";', 1)[0].encode()
        (portable / 'node_preamble.js').write_bytes(preamble)
        (portable / 'word-all-caps.node.cjs').write_bytes(preamble + (portable / 'word-all-caps.js').read_bytes())
        portable_summary['node_preamble'] = {'package': 'node_preamble', 'version': '2.0.2', 'source_sha256': digest(source), 'extracted_preamble_sha256': digest(portable / 'node_preamble.js'), 'unchanged_normal_preamble': True}
        node = run(portable, 'node', [NODE, portable / 'word-all-caps.node.cjs'], ENGINE)
        portable_summary['commands'].append(node)
        portable_summary['raw_receipts_byte_identical'] = (portable / 'vm.stdout').read_bytes() == (portable / 'node.stdout').read_bytes()
        if vm['exit_code'] == node['exit_code'] == 0:
            receipt = json.loads((portable / 'vm.stdout').read_text())
            portable_summary['receipt'] = receipt
            portable_summary['receipt_sha256'] = digest(portable / 'vm.stdout')
    portable_summary['source_after'] = capture_bound(portable, 'after')
    portable_summary['runtime_files_unchanged'] = all(digest(path) == details['sha256'] for path, details in provenance['runtime_files'].items())
    portable_summary['passed'] = len(portable_summary['commands']) == 3 and all(command['exit_code'] == 0 for command in portable_summary['commands']) and portable_summary.get('raw_receipts_byte_identical') is True and portable_summary['runtime_files_unchanged']
except BaseException as error:
    portable_summary['error'] = repr(error)
finally:
    write_json(portable / 'summary.json', portable_summary)
    write_json(portable / 'provenance.json', provenance)

print(json.dumps({'checks_passed': check_summary['passed'], 'portable_passed': portable_summary['passed'], 'checks_error': check_summary.get('error'), 'portable_error': portable_summary.get('error')}), flush=True)
sys.exit(0 if check_summary['passed'] and portable_summary['passed'] else 1)
