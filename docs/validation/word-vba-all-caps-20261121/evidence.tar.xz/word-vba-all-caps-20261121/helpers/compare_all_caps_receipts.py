from decimal import Decimal
from pathlib import Path
import hashlib, json

ROOT = Path('/workspace/scratch/bca670ac89b2/all-caps-validation/portable')

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result

def reject_constant(value):
    raise ValueError('Non-JSON numeric value: ' + value)

def load_decimal(data):
    return json.loads(data, parse_int=Decimal, parse_float=Decimal, parse_constant=reject_constant, object_pairs_hook=unique_object)

def canonical(value):
    if value is None:
        return 'null'
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValueError('Non-finite number')
        return '0' if value == 0 else format(value.normalize(), 'f')
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, list):
        return '[' + ','.join(canonical(item) for item in value) + ']'
    if isinstance(value, dict):
        return '{' + ','.join(json.dumps(key, ensure_ascii=False) + ':' + canonical(value[key]) for key in sorted(value)) + '}'
    raise TypeError(type(value))

vm_raw = (ROOT / 'vm.stdout').read_bytes()
node_raw = (ROOT / 'node.stdout').read_bytes()
vm = load_decimal(vm_raw)
node = load_decimal(node_raw)
vm_canonical = (canonical(vm) + '\n').encode()
node_canonical = (canonical(node) + '\n').encode()
(ROOT / 'vm.canonical.json').write_bytes(vm_canonical)
(ROOT / 'node.canonical.json').write_bytes(node_canonical)
ordinary_vm = json.loads(vm_raw)
ordinary_node = json.loads(node_raw)
differences = []
for index, (left, right) in enumerate(zip(ordinary_vm['display'], ordinary_node['display'], strict=True)):
    if type(left['scale']) is not type(right['scale']):
        assert type(left['scale']) is float and type(right['scale']) is int
        assert left['scale'] == 1.0 and right['scale'] == 1
        differences.append({'path': '$.display[' + str(index) + '].scale', 'vm_json_number': '1.0', 'node_json_number': '1', 'exact_decimal_values_equal': True})
sole_difference = len(differences) == 10 and vm_raw.replace(b'"scale":1.0', b'"scale":1') == node_raw
raw_summary = json.loads((ROOT / 'summary.json').read_text())
summary = {
    'qualified_source': raw_summary['qualified_source'],
    'raw_receipts_byte_identical': vm_raw == node_raw,
    'canonical_json_number_equivalence': vm_canonical == node_canonical,
    'comparison': 'Strict duplicate-free JSON; JSON numbers parsed as exact Decimal values; booleans remain distinct; object keys sorted; numeric lexical spelling canonicalized only.',
    'sole_raw_difference_is_numeric_spelling': sole_difference,
    'differing_paths': differences,
    'processes': [{key: command[key] for key in ('name', 'exit_code', 'timed_out', 'duration_seconds')} for command in raw_summary['commands']],
    'all_processes_exit_zero': all(command['exit_code'] == 0 and not command['timed_out'] for command in raw_summary['commands']),
    'source_before': raw_summary['source_before'],
    'source_after': raw_summary['source_after'],
    'runtime_files_unchanged': raw_summary['runtime_files_unchanged'],
    'vm_stdout_sha256': hashlib.sha256(vm_raw).hexdigest(),
    'node_stdout_sha256': hashlib.sha256(node_raw).hexdigest(),
    'canonical_receipt_sha256': hashlib.sha256(vm_canonical).hexdigest(),
    'native_part_hashes_identical': ordinary_vm['nativePartSha256'] == ordinary_node['nativePartSha256'],
    'native_part_sha256': ordinary_vm['nativePartSha256'],
    'operations': ordinary_vm['operations'],
    'recorded_steps': ordinary_vm['recordedSteps'],
    'whole_zip_byte_identity_asserted': False,
    'raw_comparison_failure_retained': 'summary.json',
    'comparison_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
summary['accepted'] = summary['all_processes_exit_zero'] and summary['canonical_json_number_equivalence'] and sole_difference and summary['native_part_hashes_identical'] and summary['source_before']['matches_freeze'] and summary['source_after']['matches_freeze'] and summary['runtime_files_unchanged']
(ROOT / 'semantic-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ('accepted', 'raw_receipts_byte_identical', 'canonical_json_number_equivalence', 'sole_raw_difference_is_numeric_spelling', 'native_part_hashes_identical', 'canonical_receipt_sha256')}))
