import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/bca670ac89b2/all-caps-validation')
FROZEN = '0fe00b18fef6b79a435817c99714f987329d5f3c'
MCP = 'test/office_macro_mcp_test.dart'

def read(path):
    return json.loads((ROOT/path).read_text())

def require(condition, message):
    if not condition:
        raise ValueError(message)

engine = read('engine/summary.json')
replay = read('mcp-replay/summary.json')
editor = read('editor-final/summary.json')
checks = read('checks/summary.json')
portable = read('portable/semantic-summary.json')
manifest_hash = hashlib.sha256((ROOT/'frozen-source.json').read_bytes()).hexdigest()
requested = set((ROOT/'engine-suites.txt').read_text().splitlines())
require(set(engine['per_file']) == requested, 'Initial engine run did not execute every requested file')
require(engine['process_exit'] == 1 and engine['failed'] == 3 and engine['skipped'] == 0, 'Unexpected primary engine disposition')
require(engine['final_event']['success'] is False and not engine['parse_errors'], 'Primary stream is incomplete or malformed')
require(replay['accepted'] and set(replay['per_file']) == {MCP}, 'MCP replay not accepted or changed scope')

tests = {}
suites = {}
errors = []
for line in (ROOT/'engine/stdout.jsonl').read_text().splitlines():
    event = json.loads(line)
    if event.get('type') == 'testStart':
        tests[event['test']['id']] = event['test']
    elif event.get('type') == 'suite':
        suites[event['suite']['id']] = event['suite']
    elif event.get('type') == 'error':
        errors.append(event)
require(len(errors) == 3, 'Unexpected engine error count')
initial_timeouts = []
for error in errors:
    test = tests[error['testID']]
    require(suites[test['suiteID']]['path'] == MCP, 'Error outside replayed MCP file')
    require(error['error'].startswith('TimeoutException after 0:00:30.000000:'), 'Non-startup-timeout error in primary run')
    initial_timeouts.append(test['name'])

per_file = dict(engine['per_file'])
require(per_file[MCP] == {'passed': 12, 'failed': 3, 'skipped': 0}, 'Primary MCP file counts differ')
require(replay['per_file'][MCP] == {'passed': 15, 'failed': 0, 'skipped': 0}, 'Replayed MCP file counts differ')
per_file[MCP] = replay['per_file'][MCP]
require(all(not row['failed'] and not row['skipped'] for row in per_file.values()), 'Unresolved engine case')
for gate in [engine, replay, editor]:
    require(gate['source_unchanged'], 'Source changed during gate')
    require(gate['source_before_sha256'] == gate['source_after_sha256'] == manifest_hash, 'Gate differs from frozen source')
require(editor['accepted'] and editor['files'] == 17, 'Editor gate not accepted')
require(checks['passed'] and checks['qualified_source'] == FROZEN and checks['dart_path_count'] == 23, 'Checks incomplete')
require(portable['accepted'] and portable['source_before']['matches_freeze'] and portable['source_after']['matches_freeze'], 'Portability not accepted')
require(portable['native_part_hashes_identical'] and portable['canonical_json_number_equivalence'], 'Native or semantic portability mismatch')

engine_passed = sum(row['passed'] for row in per_file.values())
new_engine_files = [
    'office_vba_word_all_caps_test.dart', 'office_macro_word_all_caps_test.dart',
    'office_vba_word_all_caps_integration_test.dart', 'word_all_caps_test.dart',
    'zotero_all_caps_test.dart',
]
new_engine = {name: per_file['test/'+name]['passed'] for name in new_engine_files}
summary = {
    'accepted': True, 'qualified_source': FROZEN,
    'source_manifest_sha256': manifest_hash, 'source_inputs': engine['source_files'],
    'engine': {'passed': engine_passed, 'files': len(per_file), 'failed': 0, 'skipped': 0,
               'counting': 'Each requested file counted once; complete accepted MCP replay replaces its initial result.',
               'primary_run': {'process_exit': engine['process_exit'], 'passed': engine['passed'], 'failed': engine['failed']},
               'replay': {'path': MCP, 'passed': 15, 'process_exit': 0, 'timeout_seconds': 120},
               'initial_30_second_timeouts': initial_timeouts, 'per_file': per_file},
    'editor': {key: editor[key] for key in ('passed','files','failed','skipped','process_exit')},
    'new_engine_cases': new_engine, 'new_engine_cases_total': sum(new_engine.values()),
    'new_editor_cases': 7,
    'changed_dart_files': 23, 'strict_analysis_and_format': 'passed',
    'portability': {'accepted': True, 'raw_bytes_equal': False, 'canonical_receipts_equal': True,
                    'native_parts_equal': True, 'difference': 'Ten display.scale JSON numbers are spelled 1.0 on VM and 1 on JavaScript.'},
    'earlier_editor_run': 'Development-only: old parser rejected Flutter control arrays before retaining nested exit; replaced by full identical editor-final run.',
    'github_actions_queried_or_awaited': False,
}
(ROOT/'acceptance.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({key:value for key,value in summary.items() if key != 'engine'}))
print(json.dumps({'engine_passed': engine_passed, 'engine_files': len(per_file)}))
