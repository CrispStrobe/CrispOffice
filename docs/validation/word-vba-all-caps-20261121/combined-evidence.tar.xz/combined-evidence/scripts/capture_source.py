import hashlib
import json
from pathlib import Path
import subprocess
import sys

REPO = Path('/workspace/scratch/bca670ac89b2/quds_office_suite')

def capture():
    paths = subprocess.check_output(['git', '-C', str(REPO), 'ls-files', '-z']).decode().split('\0')
    result = {}
    for rel in paths:
        if not rel or rel.startswith('docs/'):
            continue
        p = REPO / rel
        selected = p.suffix in ('.dart', '.bas', '.yaml', '.lock') or rel == '.fvmrc'
        selected |= '/test/' in rel or '/testdata/' in rel or '/fixtures/' in rel
        selected |= '/fonts/' in rel and p.suffix.lower() in ('.ttf', '.otf')
        if not selected:
            continue
        data = p.read_bytes()
        result[rel] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    return result

if __name__ == '__main__':
    value = capture()
    text = json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n'
    Path(sys.argv[1]).write_text(text)
    print(json.dumps({'files': len(value), 'bytes': sum(x['bytes'] for x in value.values()),
                      'manifest_sha256': hashlib.sha256(text.encode()).hexdigest()}))
