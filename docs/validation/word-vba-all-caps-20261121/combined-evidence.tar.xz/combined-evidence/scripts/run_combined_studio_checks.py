from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, subprocess, time

from capture_source import capture

ROOT = Path('/workspace/scratch/bca670ac89b2')
REPO = ROOT / 'quds_office_suite'
OUT = ROOT / 'all-caps-combined-validation'
OUT.mkdir(exist_ok=True)
COMBINED = 'a52013158c28fbcf3e69a999deffb6cc2eea23cc'
FROZEN = '0fe00b18fef6b79a435817c99714f987329d5f3c'
PRESERVED = 'c74ba469'
EXPECTED_HASH = '64bf85be8dbc6db823032fe40c38a2c841e6b76881b4779cdb5a7fddbfbdc48a'
PATHS = [
    'packages/quds_office_editor/example/lib/studio_about.dart',
    'packages/quds_office_editor/example/lib/studio_strings.dart',
    'packages/quds_office_editor/example/test/studio_about_test.dart',
]
EXPECTED = json.loads((ROOT / 'combined-source.json').read_text())

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')

def source_capture(name):
    actual = capture()
    text = json.dumps(actual, sort_keys=True, separators=(',', ':')) + '\n'
    (OUT / name).write_text(text)
    if actual != EXPECTED or hashlib.sha256(text.encode()).hexdigest() != EXPECTED_HASH:
        raise RuntimeError('Combined source manifest mismatch')
    return {'files': len(actual), 'matches_combined': True, 'sha256': EXPECTED_HASH}

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def tree(commit):
    result = {}
    for line in git('ls-tree', '-r', '-z', commit).split(b'\0'):
        if not line:
            continue
        header, path = line.split(b'\t', 1)
        mode, kind, object_id = header.decode().split()
        result[path.decode()] = {'mode': mode, 'type': kind, 'object': object_id}
    return result

if os.environ.get('COMBINED_PREPARE_ONLY') == '1':
    assert sha(ROOT / 'combined-source.json') == EXPECTED_HASH
    assert git('rev-parse', 'HEAD').decode().strip() == COMBINED
    assert git('status', '--porcelain') == b''
    current = source_capture('source-preflight.json')
    frozen_manifest = json.loads((ROOT / 'all-caps-validation/frozen-source.json').read_text())
    changed = sorted(key for key in set(frozen_manifest) | set(EXPECTED) if frozen_manifest.get(key) != EXPECTED.get(key))
    assert changed == sorted(PATHS), changed
    frozen_tree, combined_tree = tree(FROZEN), tree(COMBINED)
    unchanged = sorted(set(EXPECTED) - set(changed))
    assert all(frozen_tree.get(path) == combined_tree.get(path) for path in unchanged)
    blob_mismatches = []
    for path in EXPECTED:
        data = os.readlink(REPO / path).encode() if combined_tree[path]['mode'] == '120000' else (REPO / path).read_bytes()
        oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if oid != combined_tree[path]['object']:
            blob_mismatches.append(path)
    assert not blob_mismatches, blob_mismatches
    intake_paths = git('diff', '--name-only', PRESERVED, COMBINED).decode().splitlines()
    assert sorted(intake_paths) == sorted(PATHS + ['docs/release/app-store-submission.md']), intake_paths
    write_json(OUT / 'source-reconciliation.json', {
        'frozen_source': FROZEN, 'preserved_evidence_commit': git('rev-parse', PRESERVED).decode().strip(),
        'combined_source': COMBINED, 'combined_tree': git('rev-parse', COMBINED + '^{tree}').decode().strip(),
        'combined_source_manifest': current, 'frozen_manifest_sha256': sha(ROOT / 'all-caps-validation/frozen-source.json'),
        'changed_selected_paths': changed, 'unchanged_selected_paths': len(unchanged),
        'all_unchanged_git_modes_and_blob_ids_equal': True, 'all_combined_worktree_blob_hashes_match_git_tree': True,
        'full_intake_changed_paths': intake_paths,
        'changed_source_objects': {path: {'frozen': frozen_tree[path], 'combined': combined_tree[path]} for path in changed},
        'worktree_clean_before_checks': True,
    })
    spec = {'name': 'combined-main-studio-about', 'output': str(OUT / 'studio-about'),
            'command': ['flutter', 'test', '--no-pub', '--machine', '--concurrency=1', '--timeout=120s', 'test/studio_about_test.dart'],
            'cwd': str(REPO / 'packages/quds_office_editor/example'), 'timeout_seconds': 900}
    write_json(OUT / 'studio-about-spec.json', spec)
    (OUT / 'changed-dart-paths.txt').write_text('\n'.join(PATHS) + '\n')
    print(json.dumps({'prepared': True, 'changed_source_paths': changed, 'unchanged_inputs': len(unchanged), 'combined_manifest_sha256': EXPECTED_HASH}))
    raise SystemExit(0)

checks = OUT / 'checks'
checks.mkdir(exist_ok=True)
summary = {'qualified_source': COMBINED, 'paths': PATHS, 'passed': False, 'commands': []}
try:
    summary['source_before'] = source_capture('checks-source-before.json')
    for name, command in (
        ('analyze', ['dart', 'analyze', '--fatal-infos', *PATHS]),
        ('format', ['dart', 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed', *PATHS]),
    ):
        started = datetime.now(timezone.utc).isoformat(); stamp = time.monotonic()
        print('START ' + name, flush=True)
        with (checks / (name + '.stdout')).open('wb') as stdout, (checks / (name + '.stderr')).open('wb') as stderr:
            try:
                result = subprocess.run(command, cwd=REPO, stdout=stdout, stderr=stderr, timeout=900)
                code, timeout = result.returncode, False
            except subprocess.TimeoutExpired:
                code, timeout = None, True
        receipt = {'argv': command, 'cwd': str(REPO), 'started_utc': started, 'duration_seconds': round(time.monotonic() - stamp, 3), 'exit_code': code, 'timed_out': timeout, 'stdout_sha256': sha(checks / (name + '.stdout')), 'stderr_sha256': sha(checks / (name + '.stderr'))}
        write_json(checks / (name + '.command.json'), receipt)
        summary['commands'].append(receipt)
        print('END ' + name + ' exit=' + str(code), flush=True)
    summary['source_after'] = source_capture('checks-source-after.json')
    summary['passed'] = all(command['exit_code'] == 0 for command in summary['commands'])
except BaseException as error:
    summary['error'] = repr(error)
finally:
    write_json(checks / 'summary.json', summary)
print(json.dumps({'checks_passed': summary['passed'], 'error': summary.get('error')}), flush=True)
raise SystemExit(0 if summary['passed'] else 1)
