import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

from capture_source import capture

spec = json.loads(Path(sys.argv[1]).read_text())
out = Path(spec['output'])
out.mkdir(parents=True, exist_ok=True)
before = capture()
before_text = json.dumps(before, sort_keys=True, separators=(',', ':')) + '\n'
(out/'source-before.json').write_text(before_text)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
t0 = time.monotonic()
with (out/'stdout.jsonl').open('w') as stdout, (out/'stderr.log').open('w') as stderr:
    process = subprocess.Popen(spec['command'], cwd=spec['cwd'], stdout=stdout, stderr=stderr)
    try:
        code = process.wait(timeout=spec.get('timeout_seconds', 1800))
    except subprocess.TimeoutExpired:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        code = 124
after = capture()
after_text = json.dumps(after, sort_keys=True, separators=(',', ':')) + '\n'
(out/'source-after.json').write_text(after_text)
(out/'execution.json').write_text(json.dumps({
    'command': spec['command'], 'cwd': spec['cwd'], 'process_exit': code,
    'started_utc': started,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'elapsed_seconds': round(time.monotonic()-t0, 3),
}, indent=2)+'\n')
tests = {}
results = {}
suites = {}
errors = []
done = None
parse_errors = []
control_events = []
for line_no, line in enumerate((out/'stdout.jsonl').read_text().splitlines(), 1):
    if not line.strip():
        continue
    try:
        event = json.loads(line)
    except json.JSONDecodeError:
        parse_errors.append({'line': line_no, 'text': line[:250]})
        continue
    if isinstance(event, list):
        # Flutter --machine wraps launch notifications in an array. These are
        # separate from the package:test JSON protocol and carry no test result.
        if all(isinstance(item, dict) and item.get('event') in ('test.startedProcess', 'test.finishedProcess') and isinstance(item.get('params'), dict) for item in event):
            control_events.extend(event)
        else:
            parse_errors.append({'line': line_no, 'text': line[:250], 'reason': 'Unknown control event array'})
        continue
    if not isinstance(event, dict):
        parse_errors.append({'line': line_no, 'text': line[:250], 'reason': 'Unknown JSON event value'})
        continue
    kind = event.get('type')
    if kind == 'testStart':
        tests[event['test']['id']] = event['test']
    elif kind == 'testDone':
        results[event['testID']] = event
    elif kind == 'suite':
        suites[event['suite']['id']] = event['suite']
    elif kind == 'error':
        errors.append(event)
    elif kind == 'done':
        done = event
visible = [e for e in results.values() if not e.get('hidden', False)]
passed = sum(e.get('result') == 'success' and not e.get('skipped') for e in visible)
failed = sum(e.get('result') != 'success' for e in visible)
skipped = sum(bool(e.get('skipped')) for e in visible)
by_file = {}
for test_id, event in results.items():
    if event.get('hidden', False):
        continue
    test = tests[test_id]
    suite = suites.get(test.get('suiteID'), {})
    key = suite.get('path', str(test.get('suiteID')))
    entry = by_file.setdefault(key, {'passed': 0, 'failed': 0, 'skipped': 0})
    if event.get('skipped'):
        entry['skipped'] += 1
    elif event.get('result') == 'success':
        entry['passed'] += 1
    else:
        entry['failed'] += 1
summary = {
    'name': spec['name'], 'started_utc': started,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'elapsed_seconds': round(time.monotonic()-t0, 3),
    'command': spec['command'], 'cwd': spec['cwd'], 'process_exit': code,
    'passed': passed, 'failed': failed, 'skipped': skipped,
    'error_events': errors, 'parse_errors': parse_errors, 'control_events': control_events, 'final_event': done,
    'files': len(by_file), 'per_file': by_file,
    'source_files': len(before), 'source_unchanged': before == after,
    'source_before_sha256': hashlib.sha256(before_text.encode()).hexdigest(),
    'source_after_sha256': hashlib.sha256(after_text.encode()).hexdigest(),
    'stdout_sha256': hashlib.sha256((out/'stdout.jsonl').read_bytes()).hexdigest(),
    'stderr_sha256': hashlib.sha256((out/'stderr.log').read_bytes()).hexdigest(),
    'github_actions_queried_or_awaited': False,
}
summary['accepted'] = code == 0 and not failed and not skipped and not errors and not parse_errors and done is not None and done.get('success') is True and before == after
(out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('per_file','error_events','parse_errors','command')}))
sys.exit(0 if summary['accepted'] else 1)
