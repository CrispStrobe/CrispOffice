import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path('/workspace/scratch/bca670ac89b2')
repo = root / 'quds_office_suite'
destination = root / 'all-caps-combined-validation'
destination.mkdir(exist_ok=True)
frozen = '0fe00b18fef6b79a435817c99714f987329d5f3c'
evidence = 'c74ba46996a50d5041e9ceab02ccb4f1812dd281'
incoming = '3f6b9a2b9209693aa32bbad402bb7d093cf8b4db'
combined = 'a52013158c28fbcf3e69a999deffb6cc2eea23cc'

def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args]).decode().strip()

assert git('rev-parse', 'HEAD') == combined
assert not git('status', '--porcelain=v1')
parents = git('show', '-s', '--format=%P', combined).split()
assert parents == [evidence, incoming]
tree = git('rev-parse', combined + '^{tree}')
assert git('merge-tree', '--write-tree', evidence, incoming) == tree

old_bytes = (root / 'all-caps-validation/frozen-source.json').read_bytes()
new_bytes = (root / 'combined-source.json').read_bytes()
old = json.loads(old_bytes)
new = json.loads(new_bytes)
expected = {
    'packages/quds_office_editor/example/lib/studio_about.dart',
    'packages/quds_office_editor/example/lib/studio_strings.dart',
    'packages/quds_office_editor/example/test/studio_about_test.dart',
}
delta = {path: {'before': old.get(path), 'after': new.get(path)}
         for path in sorted(set(old) | set(new)) if old.get(path) != new.get(path)}
assert set(delta) == expected
assert set(old) == set(new)
incoming_paths = git('diff', '--name-only', evidence, combined).splitlines()
assert set(incoming_paths) == expected | {'docs/release/app-store-submission.md'}
assert all(path.startswith('docs/') or path in expected
           for path in git('diff', '--name-only', frozen, combined).splitlines())
for commit in [frozen, evidence, incoming]:
    subprocess.run(['git', '-C', str(repo), 'merge-base', '--is-ancestor', commit, combined], check=True)

receipt = {
    'purpose': 'Preserve and inspect post-cutoff completed main before AllCaps publication.',
    'all_caps_qualified_source': frozen,
    'all_caps_evidence_checkpoint': evidence,
    'incoming_main': incoming,
    'incoming_merged_prs': [312, 313],
    'combined_source_commit': combined,
    'combined_tree': tree,
    'merge_parents': parents,
    'recomputed_conflict_free_merge_tree_matches': True,
    'incoming_paths': incoming_paths,
    'qualified_input_paths_added_or_removed': [],
    'selected_input_count': len(new),
    'selected_input_bytes': sum(item['bytes'] for item in new.values()),
    'unchanged_selected_inputs': len(old) - len(delta),
    'original_selected_input_manifest_sha256': hashlib.sha256(old_bytes).hexdigest(),
    'combined_selected_input_manifest_sha256': hashlib.sha256(new_bytes).hexdigest(),
    'changed_selected_inputs': delta,
    'all_other_changes_since_qualified_source_are_documentation': True,
    'application_validation': 'Recorded separately by the combined-source Studio gate and static checks.',
    'github_ci_actions_queried_or_awaited': False,
}
(destination / 'merge-and-source-binding.json').write_text(json.dumps(receipt, indent=2) + '\n')
shutil.copy2(root / 'all-caps-validation/post-cutoff-main-audit.json', destination / 'post-cutoff-main-audit.json')
shutil.copy2(root / 'all-caps-validation/frozen-source.json', destination / 'original-frozen-source.json')
shutil.copy2(root / 'combined-source.json', destination / 'combined-source.json')
print(json.dumps({key: receipt[key] for key in (
    'combined_source_commit', 'combined_tree', 'incoming_paths', 'unchanged_selected_inputs',
    'combined_selected_input_manifest_sha256')}, indent=2))
