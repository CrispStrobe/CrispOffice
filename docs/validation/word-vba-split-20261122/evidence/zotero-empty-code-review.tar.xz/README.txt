Zotero empty-code formatting review and regression evidence

Incoming source: 8f2e943bf5aa1dd157e72f7ec47d0f7c2ccd5dd4
Previously qualified source: 2d19bb8daf76d8305e47f136c92060b5cd5da019
Merged baseline: 0e0994d7d3d4d07872322167f23ba0c0687377e8
The initial baseline run recorded49c16aa5; its tree equals0e0994d7.

baseline-events.jsonl is an intentional failing reproduction:8 cases,6 fail,
2 preservation controls pass. fixed-events.jsonl is the accepted focused run:
9 cases, all pass, with an additional adjacent-empty-citation regression.
Do not count the repeated executions as distinct additional accepted cases.
Both stdout streams are raw Dart JSON test events; stderr is empty.

The source correction is fix.patch. Source hashes and exact commands are
recorded separately. Only the two files named in the review were edited.
Root separately owns broader engine/editor acceptance. This receipt makes no
claim of installed Word/LibreOffice/Zotero-plugin execution.
