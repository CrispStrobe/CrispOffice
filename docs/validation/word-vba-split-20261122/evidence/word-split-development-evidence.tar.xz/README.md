# Word Split development and pinned acceptance evidence

This archive preserves original attempts and successful executions. It does not
replace the separately archived broad final engine gate.

## Selected acceptance

The pinned Flutter 3.47.8 / Dart 3.13.7 execution contains 373 distinct substantive
test identities: 364 compiler cases, eight native integration cases, and one CLI
case. Raw start/finish events match the case ledger exactly; errors, failures,
skips, missing finishes and stderr are all zero. Loaders and lifecycle hooks are
excluded. All 473 captured inputs match before/after manifests and the checkout
at packaging time. The transitive table fixture was not captured by this narrow
input manifest; its current bytes match acceptance HEAD 373b7fe9. This limitation
is explicit in verification/independent-verification.json. The broad final gate
captures it separately.

## Development and historical records

- development/compiler contains the later 364-case Dart 3.14.1 development run
  and 174 compiler-corpus cases across three adapters with identical VM/JS bytes.
- development/native contains nine passing development cases, the actual BAS
  executed for DOCX and DOCM on VM and JavaScript, commands and independent review.
  Native parsed receipts are equal. Raw JSON differs only at 58 integral double
  values (for example 4.0 versus 4); the original outputs remain unchanged.
- earlier-attempts/compiler includes a failed expanded run (316 passed / 12
  failed), a failed 328-case JSON run (319 passed / nine failed), and the
  superseded successful 328-case run. These retain their original filenames;
  names such as "final" do not mean they are accepted final-source results.
- earlier-attempts/native/first-tests.log retains a loading type error and a
  wrong expected Null diagnostic, both corrected in the later development run.

Development, portable, and pinned executions overlap. The unique acceptance
count is 373; their totals must not be added together. Runtime setup proof counts
inside provenance records are also not credited to this increment.

## Reproduction and integrity

Exact original commands and runtime/lock provenance are retained. Absolute paths
identify the original workspace and need adjustment for another checkout. SDK
and package binaries, generated JS/maps/deps, and Microsoft PDF/text copies are
excluded. Sources, fixtures and examples are in the repository; this is evidence,
not a source or SDK distribution. The historical scripts are preserved verbatim.

MEMBERS.json hashes every payload member except itself. The external manifest
hashes every member, including MEMBERS.json, plus the compressed archive. Tar
entries are sorted, regular files with uid/gid/mtime zero and mode 0644. Rebuild
the byte-identical archive from an extracted directory with:

    python3 verification/repack_archive.py EXTRACTED_DIRECTORY OUTPUT.tar.xz

The repacker checks each member before writing and uses Python's XZ compressor
at preset 6. The original package was independently reopened and rehashed, and
its deterministic construction was repeated to confirm the same bytes.
