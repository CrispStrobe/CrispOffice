import hashlib,json,os,shutil,subprocess,time
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path('/workspace/scratch/7c69340222d3/quds_office_suite')
ENGINE=ROOT/'packages/quds_office_engine'
OUT=Path('/workspace/scratch/7c69340222d3/pinned-split-acceptance')
TESTS=['test/office_vba_split_test.dart','test/office_vba_word_split_integration_test.dart','test/office_vba_word_split_cli_test.dart']
EXACT=[
 '.fvmrc','pubspec.yaml','pubspec.lock','.dart_tool/package_config.json',
 '.dart_tool/package_graph.json',
 'packages/quds_office_engine/analysis_options.yaml',
 'packages/quds_office_engine/test/fixtures/vba_conformance/split_v1.json',
 'packages/quds_office_engine/example/macros/word_split_report.bas',
 'packages/quds_office_engine/tool/macros/web_vba_split_conformance.dart',
 'packages/quds_office_engine/tool/macros/web_vba_word_split_smoke.dart',
 'packages/quds_office_engine/tool/macros/office_macro.dart',
]
EXACT += ['packages/quds_office_engine/'+p for p in TESTS]

def paths():
 result={ROOT/p for p in EXACT if (ROOT/p).is_file()}
 for directory in [ENGINE/'lib',ENGINE/'test/support',ROOT/'packages/legacy_doc_parser/lib']:
  result.update(directory.rglob('*.dart'))
 for directory in [ROOT/'packages',ROOT/'apps']:
  result.update(directory.rglob('pubspec.yaml'))
  result.update(directory.rglob('pubspec.lock'))
 return sorted(result)

def snapshot():
 return {str(p.relative_to(ROOT)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in paths()}

def capture(args):
 p=subprocess.run(args,cwd=ENGINE,text=True,capture_output=True)
 return {'command':args,'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}

def write(name,data):
 (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

before=snapshot()
write('inputs-before.json',before)
metadata={
 'startedAt':datetime.now(timezone.utc).isoformat(),
 'command':['dart','test','--concurrency=2','--reporter=json',*TESTS],
 'cwd':str(ENGINE),
 'environmentSetup':'source /workspace/scratch/7c69340222d3/.flutter-runtime/env.sh',
 'dartCommand':shutil.which('dart'),
 'dartVersion':capture(['dart','--version']),
 'head':capture(['git','rev-parse','HEAD']),
 'configuredFlutter':json.loads((ROOT/'.fvmrc').read_text()),
 'environment':{key:os.environ.get(key) for key in ['FLUTTER_ROOT','PUB_CACHE','TMPDIR']},
 'inputCount':len(before),
 'scope':'Only the three new Split suites on the repository-pinned Dart runtime; no GitHub Actions queried or awaited.'
}
write('metadata-before.json',metadata)
print(json.dumps({'phase':'start','dartVersion':metadata['dartVersion'],'inputCount':len(before)}),flush=True)
start=time.time()
with (OUT/'events.jsonl').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
 p=subprocess.run(metadata['command'],cwd=ENGINE,stdout=stdout,stderr=stderr)
metadata['exitCode']=p.returncode
metadata['seconds']=round(time.time()-start,3)
metadata['finishedAt']=datetime.now(timezone.utc).isoformat()
after=snapshot()
write('inputs-after.json',after)
changes=[]
for path in sorted(before.keys() | after.keys()):
 if before.get(path)!=after.get(path): changes.append({'path':path,'before':before.get(path),'after':after.get(path)})
metadata['inputsUnchanged']=not changes
write('input-changes.json',changes)
rows=[]
nonEvents=[]
for line in (OUT/'events.jsonl').read_text().splitlines():
 try:
  row=json.loads(line)
  if isinstance(row,dict) and 'type' in row:rows.append(row)
  else:nonEvents.append(line)
 except ValueError:nonEvents.append(line)
suites={row['suite']['id']:row['suite'] for row in rows if row['type']=='suite'}
starts={row['test']['id']:row['test'] for row in rows if row['type']=='testStart'}
dones={row['testID']:row for row in rows if row['type']=='testDone'}
errors=[row for row in rows if row['type']=='error']
ledger=[]
for ident,done in dones.items():
 if done.get('hidden',False):continue
 test=starts[ident]
 suite=suites[test['suiteID']]
 ledger.append({'id':ident,'suite':suite['path'],'platform':suite.get('platform'),'name':test['name'],'result':done.get('result'),'skipped':done.get('skipped',False),'hidden':done.get('hidden',False)})
ledger.sort(key=lambda item:(item['suite'],item['name']))
counts={}
for entry in ledger:counts[entry['suite']]=counts.get(entry['suite'],0)+1
finish=[row for row in rows if row['type']=='done']
metadata.update({'cases':len(ledger),'suiteCounts':counts,'errors':len(errors),'failures':sum(x['result']!='success' for x in ledger),'skips':sum(x['skipped'] for x in ledger),'missingFinishes':sorted(starts.keys()-dones.keys()),'reporterDone':finish[-1] if finish else None,'nonEventLines':nonEvents})
metadata['accepted']=(p.returncode==0 and not changes and bool(finish) and finish[-1].get('success') is True and not errors and not metadata['failures'] and not metadata['skips'] and not metadata['missingFinishes'])
write('case-ledger.json',ledger)
write('errors.json',errors)
write('acceptance.json',metadata)
print(json.dumps({key:metadata[key] for key in ['exitCode','seconds','inputCount','inputsUnchanged','cases','suiteCounts','errors','failures','skips','accepted']}),flush=True)
assert metadata['accepted'],'Pinned Split acceptance did not pass; inspect retained evidence.'
