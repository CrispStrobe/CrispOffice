import hashlib,io,json,lzma,sys,tarfile
from pathlib import Path
root=Path(sys.argv[1]).resolve();target=Path(sys.argv[2])
manifest=json.loads((root/'MEMBERS.json').read_text())
payload={}
for name,expected in manifest['members'].items():
    path=(root/name).resolve()
    if not path.is_relative_to(root):raise ValueError('Unsafe member path')
    data=path.read_bytes()
    if len(data)!=expected['bytes'] or hashlib.sha256(data).hexdigest()!=expected['sha256']:raise ValueError(name+' failed integrity')
    payload[name]=data
payload['MEMBERS.json']=(root/'MEMBERS.json').read_bytes()
raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode='w',format=tarfile.PAX_FORMAT) as archive:
    for name,data in sorted(payload.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.uid=0;info.gid=0
        info.uname='';info.gname='';info.mtime=0;info.mode=0o644
        archive.addfile(info,io.BytesIO(data))
output=lzma.compress(raw.getvalue(),format=lzma.FORMAT_XZ,preset=6)
target.write_bytes(output)
print(json.dumps({'bytes':len(output),'sha256':hashlib.sha256(output).hexdigest(),'members':len(payload)}))
