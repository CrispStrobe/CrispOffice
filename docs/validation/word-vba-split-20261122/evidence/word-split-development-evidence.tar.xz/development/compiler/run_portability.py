import base64,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/scratch/7c69340222d3/quds_office_suite')
engine=root/'packages/quds_office_engine'
out=Path('/workspace/scratch/7c69340222d3/split-research')
runtime=Path('/workspace/scratch/7c69340222d3/.runtime')
dart=runtime/'dart-sdk/bin/dart'
config=runtime/'engine-package-config.json'
fixture=engine/'test/fixtures/vba_conformance/split_v1.json'
runner=engine/'tool/macros/web_vba_split_conformance.dart'
inputs=[fixture,runner,engine/'lib/src/automation/office_vba_language.dart',engine/'test/support/vba_conformance.dart']
def hashes(): return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
before=hashes()
encoded=base64.b64encode(fixture.read_bytes()).decode('ascii')
define='-DVBA_CONFORMANCE_BASE64='+encoded
records=[]
commands=[('vm',[str(dart),'--packages='+str(config),define,str(runner)]),('js-compile',[str(dart),'compile','js','--packages='+str(config),define,'-O2','-o',str(out/'split-conformance.js'),str(runner)]),('node',['node',str(out/'split-conformance.js')])]
for name,args in commands:
 start=time.time()
 with (out/('split-'+name+'.stdout')).open('wb') as stdout, (out/('split-'+name+'.stderr')).open('wb') as stderr:
  p=subprocess.run(args,cwd=engine,stdout=stdout,stderr=stderr)
 record={'phase':name,'exitCode':p.returncode,'seconds':round(time.time()-start,3),'command':[('<base64-fixture-definition>' if a==define else a) for a in args]}
 records.append(record)
 print(json.dumps(record),flush=True)
 if p.returncode:break
else:
 vm=(out/'split-vm.stdout').read_bytes();js=(out/'split-node.stdout').read_bytes()
 assert vm==js,'VM and JavaScript receipts differ'
 receipt=json.loads(vm)
 records.append({'byteIdentical':True,'sha256':hashlib.sha256(vm).hexdigest(),'caseCount':receipt['caseCount'],'adapterCount':receipt['adapterCount']})
after=hashes()
report={'inputsBefore':before,'inputsAfter':after,'unchanged':before==after,'runs':records}
(out/'split-portability.json').write_text(json.dumps(report,indent=2)+'\n')
assert before==after,'Qualified inputs changed during portability checks'
assert all(r.get('exitCode',0)==0 for r in records),'Portability phase failed'
print(json.dumps(records[-1]),flush=True)
