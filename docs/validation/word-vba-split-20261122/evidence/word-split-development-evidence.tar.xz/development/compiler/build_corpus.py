import json
from pathlib import Path
ROOT=Path('/workspace/scratch/7c69340222d3/quds_office_suite/packages/quds_office_engine')
SINK='ActiveDocument.Tables(1).Cell(1, 1).Range.Text'
REFS=[
 'https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/split-function',
 'https://learn.microsoft.com/en-us/openspecs/microsoft_general_purpose_programming_languages/ms-vbal/d9c2417c-2d36-45b1-b3d7-1876064e6085',
]
CASES=[]
def add(case_id, body, outputs, *, kind='spec-derived', before='', helpers='', note=None):
    code=(before+'Sub Main()\n'+body.strip()+'\nEnd Sub\n'+helpers).replace('@OUT@',SINK)
    CASES.append(dict(id=case_id, feature='Split source String arrays', source=code,
      expected={'steps':[{'tool':'docx.tableCellRangeText','arguments':{'table':0,'row':0,'column':0,'text':s}} for s in outputs]},
      provenance={'kind':kind,'references':REFS,'note':note or (
        'Independently authored source-array result from the published Split contract; output uses the Quds native Word sink. No Office host was executed.' if kind=='spec-derived' else
        'Explicit bounded Quds array ownership, UTF-16, coercion or empty-descriptor contract; this case is not a claim of installed Office-host observation.')}))
def split(case_id, args, parts, *, before='', prelude='', kind='spec-derived'):
    body='Dim parts() As String, i As Long\n'+prelude+'\nparts = Split('+args+')\n@OUT@ = CStr(LBound(parts)) & ":" & CStr(UBound(parts))\nFor i = LBound(parts) To UBound(parts)\n    @OUT@ = CStr(i) & "=" & parts(i)\nNext i'
    outputs=['0:'+str(len(parts)-1)]+[str(i)+'='+p for i,p in enumerate(parts)]
    add(case_id,body,outputs,before=before,kind=kind)
split('default-space','"alpha beta gamma"',['alpha','beta','gamma'])
split('default-is-only-ascii-space','"alpha" & vbTab & "beta gamma"',['alpha\tbeta','gamma'])
split('multicharacter-delimiter','"alpha::beta::gamma", "::"',['alpha','beta','gamma'])
split('delimiter-not-found','"alpha|beta", ","',['alpha|beta'])
split('delimiter-longer-than-input','"abc", "abcdef"',['abc'])
split('leading-adjacent-trailing','"|a||b|", "|"',['','a','','b',''])
split('nonoverlapping-delimiters','"aaaaa", "aa"',['','','a'])
split('binary-case-sensitive','"xAxax", "a"',['xAx','x'])
split('empty-delimiter','"a|b", ""',['a|b'])
split('nonascii-delimiter','"eins§zwei§drei", "§"',['eins','zwei','drei'])
split('surrogate-pair-delimiter','"A😀B😀", "😀"',['A','B',''],kind='dialect-contract')
split('combining-sequence-delimiter','"café|cafe" & ChrW$(769) & "|fin", "e" & ChrW$(769)',['café|caf','|fin'],kind='dialect-contract')
split('crlf-delimiter','"one" & vbCrLf & "two", vbCrLf',['one','two'])
split('nul-code-unit-delimiter','"a" & vbNullChar & "b", vbNullChar',['a','b'],kind='dialect-contract')
split('explicit-all-limit','"a|b|c", "|", -1',['a','b','c'])
split('one-keeps-whole-input','"a|b|c", "|", 1',['a|b|c'])
split('two-keeps-unsplit-remainder','"a|b|c", "|", 2',['a','b|c'])
split('limit-larger-than-parts','"a|b", "|", 99',['a','b'])
split('max-signed32-limit','"a|b", "|", 2147483647',['a','b'],kind='dialect-contract')
split('limit-counts-leading-empty-slot','"|a|b", "|", 2',['','a|b'])
split('limit-preserves-trailing-empty-slot','"a|", "|", 2',['a',''])
split('binary-comparison-explicit','"aAa", "A", -1, vbBinaryCompare',['a','a'])
split('zero-limit-is-allocated-empty','"a|b", "|", 0',[],kind='dialect-contract')
split('empty-source-has-no-elements','""',[],kind='dialect-contract')
split('empty-source-empty-delimiter','"", ""',[],kind='dialect-contract')
split('empty-source-positive-limit','"", "|", 1',[],kind='dialect-contract')
split('empty-source-state','Empty, "|"',[],kind='dialect-contract')
split('empty-delimiter-state','"a|b", Empty',['a|b'],kind='dialect-contract')
split('variant-string-arguments','text, separator, count, mode',['a','b|c'],prelude='Dim text As Variant, separator As Variant, count As Variant, mode As Variant\ntext = "a|b|c"\nseparator = "|"\ncount = 2\nmode = 0',kind='dialect-contract')
split('explicit-string-conversion','CStr(42), "-"',['42'],kind='dialect-contract')
split('option-base-one-does-not-change-result','"a|b", "|"',['a','b'],before='Option Explicit\nOption Base 1\n')
split('option-base-zero','"a|b", "|"',['a','b'],before='Option Base 0\n')
split('constant-arguments','DataText, Separator, 2',['a','b|c'],before='Const DataText As String = "a|b|c"\nConst Separator As String = "|"\n')
split('replaces-negative-lower-bound','"a|b", "|"',['a','b'],prelude='ReDim parts(-2 To -1)\nparts(-2) = "discard"\nparts(-1) = "discard too"',kind='dialect-contract')
split('reads-old-element-before-replacement','parts(1), "|"',['c','d'],prelude='parts = Split("a|b,c|d", ",")',kind='dialect-contract')
split('reads-old-join-before-replacement','Join(parts, ":"), ":"',['a','b'],prelude='parts = Split("a|b", "|")',kind='dialect-contract')
add('let-and-case-insensitive', '''
Dim parts() As String
Let PARTS = sPlIt("red|green", "|")
@OUT@ = Join(parts, "/")
''',['red/green'])
add('foreach-ascending-and-scalar-isolation','''
Dim parts() As String, item As Variant
parts = Split("a|b|c", "|")
For Each item In parts
    @OUT@ = item
    item = "local"
Next item
@OUT@ = Join(parts, ",")
''',['a','b','c','a,b,c'],kind='dialect-contract')
add('empty-foreach-and-join','''
Dim parts() As String, item As Variant
parts = Split("a|b", "|", 0)
item = "unchanged"
For Each item In parts
    item = "wrong"
Next item
@OUT@ = CStr(LBound(parts)) & ":" & CStr(UBound(parts)) & ":" & item & ":" & Join(parts, "|")
''',['0:-1:unchanged:'],kind='dialect-contract')
add('preserve-after-empty-split','''
Dim parts() As String
parts = Split("")
ReDim Preserve parts(1)
parts(1) = "after"
@OUT@ = CStr(LBound(parts)) & ":" & CStr(UBound(parts)) & ":" & Join(parts, "|")
''',['0:1:|after'],kind='dialect-contract')
add('erase-and-reallocate','''
Dim parts() As String
parts = Split("one|two", "|")
Erase parts
ReDim parts(-1 To 0)
parts(-1) = "new"
@OUT@ = CStr(LBound(parts)) & ":" & CStr(UBound(parts)) & ":" & Join(parts, "|")
''',['-1:0:new|'],kind='dialect-contract')
add('helper-local-descriptor-isolation','''
Dim parts() As String
parts = Split("caller|retained", "|")
@OUT@ = BuildText("helper:local")
@OUT@ = Join(parts, "/")
''',['helper/local','caller/retained'],kind='dialect-contract',helpers='''
Function BuildText(ByVal text As String) As String
    Dim parts() As String
    parts = Split(text, ":")
    BuildText = Join(parts, "/")
End Function
''')
add('argument-evaluation-order-once','''
Dim parts() As String
parts = Split(SourceText(), SeparatorText(), LimitValue(), ComparisonValue())
@OUT@ = Join(parts, "/")
''',['source','delimiter','limit','compare','a/b|c'],kind='dialect-contract',helpers='''
Function SourceText() As String
    @OUT@ = "source"
    SourceText = "a|b|c"
End Function
Function SeparatorText() As String
    @OUT@ = "delimiter"
    SeparatorText = "|"
End Function
Function LimitValue() As Long
    @OUT@ = "limit"
    LimitValue = 2
End Function
Function ComparisonValue() As Long
    @OUT@ = "compare"
    ComparisonValue = 0
End Function
''')
add('utf16-unit-delimiter','''
Dim parts() As String
parts = Split("A😀B", ChrW$(-10179))
@OUT@ = parts(0) & ":" & CStr(AscW(parts(1))) & ":" & Right$(parts(1), 1)
''',['A:-8704:B'],kind='dialect-contract')
add('utf16-slices-can-be-recombined','''
Dim parts() As String
parts = Split("A😀B", ChrW$(-10179))
@OUT@ = parts(0) & ChrW$(-10179) & parts(1)
''',['A😀B'],kind='dialect-contract')
add('independent-source-arrays','''
Dim parts() As String, other() As String
parts = Split("a|b", "|")
other = Split(Join(parts, ":"), ":")
parts(0) = "changed"
@OUT@ = Join(other, "/")
@OUT@ = Join(parts, "/")
''',['a/b','changed/b'],kind='dialect-contract')
def reject(case_id, body, code, anchor, *, occurrence=0):
    source='Sub Main()\n'+body+'\nEnd Sub\n'
    lines=source.splitlines()
    matches=[(i+1,line.index(anchor)+1) for i,line in enumerate(lines) if anchor in line]
    line,column=matches[occurrence]
    CASES.append(dict(id=case_id,feature='Split strict source refusals',source=source,
      expected={'diagnostic':{'code':code,'line':line,'column':column}},
      provenance={'kind':'dialect-contract','references':REFS,
        'note':'Independently authored bounded-dialect refusal and token location. This is not an Office-host diagnostic observation.'}))
reject('arity-no-source','Dim parts() As String\nparts = Split()', 'vba_type_error', 'Split')
reject('arity-too-many','Dim parts() As String\nparts = Split("a", "|", -1, 0, 0)', 'vba_type_error', 'Split')
reject('fixed-array-target','Dim parts(1) As String\nparts = Split("a", "|")', 'vba_unsupported', 'parts =')
reject('variant-array-target','Dim parts() As Variant\nparts = Split("a", "|")', 'vba_unsupported', 'parts =')
reject('set-target','Dim parts() As String\nSet parts = Split("a", "|")', 'vba_unsupported', 'parts =')
reject('named-source-argument','Dim parts() As String\nparts = Split(Expression:="a")', 'vba_unsupported', 'Expression')
reject('omitted-delimiter-argument','Dim parts() As String\nparts = Split("a", , 2)', 'vba_unsupported', ', 2')
reject('numeric-source','Dim parts() As String\nparts = Split(42, "|")', 'vba_type_error', '42')
reject('null-source','Dim parts() As String\nparts = Split(Null, "|")', 'vba_invalid_use_of_null', 'Null')
reject('negative-limit','Dim parts() As String\nparts = Split("", "|", -2)', 'vba_type_error', '-2')
reject('text-comparison','Dim parts() As String\nparts = Split("", "|", 0, vbTextCompare)', 'vba_unsupported', 'vbTextCompare')
reject('null-limit','Dim parts() As String\nparts = Split("a", "|", Null)', 'vba_invalid_use_of_null', 'Null')
path=ROOT/'test/fixtures/vba_conformance/split_v1.json'
path.write_text(json.dumps({'schemaVersion':1,'suite':'vba-split','dialect':'vba-word','cases':CASES},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'cases':len(CASES),'path':str(path)}))
