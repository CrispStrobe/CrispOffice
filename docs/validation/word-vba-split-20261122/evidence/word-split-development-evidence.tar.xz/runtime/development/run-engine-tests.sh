#!/usr/bin/env bash
set -euo pipefail
source /workspace/scratch/7c69340222d3/.runtime/env.sh
cd "$QUDS_VALIDATION_ROOT/packages/quds_office_engine"
exec "$QUDS_DART_ROOT/bin/dart" --old_gen_heap_size=768 --packages="/workspace/scratch/7c69340222d3/.runtime/engine-package-config.json" /workspace/scratch/7c69340222d3/.runtime/test-runner/test-runner.dill --compiler source --concurrency=1 --timeout=4x "$@"
