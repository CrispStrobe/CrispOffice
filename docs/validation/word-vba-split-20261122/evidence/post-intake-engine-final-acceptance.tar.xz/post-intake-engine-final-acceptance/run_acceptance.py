#!/usr/bin/env python3
"""Prepare or run pinned post-intake Word/Zotero acceptance without hosted CI.

Preparation is the default and starts no Dart process. Use --run only after the
source freeze and capacity signal. All child command output, case events, exact
arguments, dependency checks, and before/after source hashes are retained even
when a gate fails. No dependency resolution or repository mutation is requested.
"""
from __future__ import annotations

import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
from urllib.parse import unquote, urljoin, urlparse

DEFAULT_ROOT = Path('/workspace/scratch/7c69340222d3/concurrent-office-intake')
RUNTIME = Path('/workspace/scratch/7c69340222d3/.flutter-runtime')
PATTERNS = ('word_zotero*_test.dart', 'odt_zotero*_test.dart', 'odf_zotero*_test.dart')
EXTRA_SUITES = (
    'word_field_span_test.dart', 'odt_reader_styles_test.dart',
    'odt_outline_compatibility_test.dart',
    'office_vba_word_split_integration_test.dart',
    'office_vba_word_split_cli_test.dart',
    'word_step_atomicity_test.dart', 'word_structure_steps_test.dart',
    'word_structure_integrity_test.dart', 'table_grid_steps_test.dart',
    'word_table_grid_addressing_test.dart',
    'word_revision_validation_test.dart', 'word_revision_story_test.dart',
    'word_revision_scaling_test.dart', 'word_extended_revision_test.dart',
    'office_macro_word_revision_guard_test.dart',
    'odt_complex_field_fidelity_test.dart',
)
ANALYSIS = (
    'lib/src/word/model/word_field_spans.dart',
    'lib/src/word/model/wml_run_edit.dart',
    'lib/src/word/model/word_revision.dart',
    'lib/src/word/properties/wml_properties.dart',
    'lib/src/word/serial/word_style_cascade.dart',
    'lib/src/word/model/word_zotero.dart',
    'lib/src/word/serial/odt_reader_styles.dart',
    'lib/src/word/serial/word_deserializer.dart',
    'test/support/zotero_converter_fixtures.dart',
    'test/word_zotero_boundary_formatting_test.dart',
    'test/word_zotero_field_recovery_test.dart',
    'test/office_vba_word_split_integration_test.dart',
    'test/office_vba_word_split_cli_test.dart',
    'tool/macros/web_vba_word_split_smoke.dart',
)


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(path):
    path = Path(path)
    return {'sha256': sha(path), 'bytes': path.stat().st_size}


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root, text=True)


def select_suites(engine):
    result = sorted({
        str(path.relative_to(engine))
        for pattern in PATTERNS for path in (engine / 'test').glob(pattern)
    } | {'test/' + name for name in EXTRA_SUITES})
    missing = [name for name in result if not (engine / name).is_file()]
    if missing:
        raise RuntimeError(f'Missing selected suites: {missing}')
    return result


def source_snapshot(root):
    names = set(git(root, 'ls-files', '-z', '--cached', '--others', '--exclude-standard').split('\0'))
    prefixes = (
        'packages/quds_office_engine/lib/', 'packages/quds_office_engine/test/',
        'packages/quds_office_engine/tool/', 'packages/quds_office_engine/example/macros/',
        'packages/legacy_doc_parser/',
    )
    exact = {
        '.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
        '.dart_tool/package_config.json', '.dart_tool/package_graph.json',
        'packages/quds_office_engine/analysis_options.yaml',
        'packages/quds_office_engine/dart_test.yaml',
    }
    selected = {
        name for name in names if name and (
            name.startswith(prefixes) or name in exact or
            Path(name).name in {'pubspec.yaml', 'pubspec.lock', 'pubspec_overrides.yaml'}
        ) and (root / name).is_file()
    }
    selected.update(name for name in exact if (root / name).is_file())
    return {name: record(root / name) for name in sorted(selected)}


def lock_entries(path):
    # Pub's generated lockfile uses these fixed indentation levels. The audit
    # only reads scalar source/version/hash fields; it does not rewrite YAML.
    result = {}
    current = None
    for line in Path(path).read_text().splitlines():
        match = re.fullmatch(r'  ([A-Za-z0-9_]+):', line)
        if match:
            current = match.group(1)
            result[current] = {}
        elif line and not line.startswith(' '):
            current = None
        elif current:
            match = re.fullmatch(r'    (source|version):\s*(.*?)\s*', line)
            if match:
                result[current][match.group(1)] = match.group(2).strip('\"\'')
            match = re.fullmatch(r'      (sha256|resolved-ref):\s*(.*?)\s*', line)
            if match:
                result[current][match.group(1)] = match.group(2).strip('\"\'')
    return result


def dependency_audit(root):
    config_path = root / '.dart_tool/package_config.json'
    config = json.loads(config_path.read_text())
    locked = lock_entries(root / 'pubspec.lock')
    configured = {}
    rows = []
    failures = []
    for package in config['packages']:
        name = package['name']
        configured[name] = package
        uri = urljoin(config_path.as_uri(), package['rootUri'])
        parsed = urlparse(uri)
        if parsed.scheme != 'file':
            failures.append(f'{name}: non-file package root {uri}')
            continue
        package_root = Path(unquote(parsed.path)).resolve()
        manifest = package_root / 'pubspec.yaml'
        entry = locked.get(name)
        if not manifest.is_file():
            failures.append(f'{name}: missing pubspec {manifest}')
            continue
        version = re.search(r'^version:\s*[\"\']?([^\s\"\'#]+)', manifest.read_text(), re.M)
        actual = version.group(1) if version else None
        row = {
            'name': name, 'root': str(package_root),
            'manifest': str(manifest), 'manifest_sha256': sha(manifest),
            'language_version': package.get('languageVersion'),
            'resolved_version': actual, 'locked': entry,
            'workspace_package': package_root == root or root in package_root.parents,
        }
        if entry and entry.get('source') != 'sdk' and actual != entry.get('version'):
            failures.append(f'{name}: resolved version {actual} differs from lock {entry.get("version")}')
        if entry is None and not row['workspace_package']:
            failures.append(f'{name}: external configured package missing from lock')
        rows.append(row)
    missing = sorted(set(locked) - set(configured))
    failures.extend(f'{name}: lock package missing from configuration' for name in missing)
    if config.get('generatorVersion') != '3.13.7':
        failures.append(f'package configuration generated by {config.get("generatorVersion")}, expected 3.13.7')
    return {
        'lock_sha256': sha(root / 'pubspec.lock'),
        'package_config_sha256': sha(config_path),
        'generator': config.get('generator'),
        'generator_version': config.get('generatorVersion'),
        'packages': rows, 'failures': failures, 'accepted': not failures,
    }


def parse_test_log(path, suites, output):
    events, non_events, malformed = [], [], []
    for number, line in enumerate(path.read_text(errors='replace').splitlines(), 1):
        try:
            value = json.loads(line)
            if isinstance(value, dict) and 'type' in value:
                events.append(value)
            else:
                non_events.append({'line': number, 'text': line})
        except ValueError:
            non_events.append({'line': number, 'text': line})
            if line.startswith('{'):
                malformed.append(number)
    suite_map = {e['suite']['id']: e['suite'] for e in events if e['type'] == 'suite'}
    starts = {e['test']['id']: e for e in events if e['type'] == 'testStart'}
    done = {e['testID']: e for e in events if e['type'] == 'testDone'}
    errors = [e for e in events if e['type'] == 'error']
    terminal = [e for e in events if e['type'] == 'done']
    all_cases = []
    for ident, event in done.items():
        start = starts.get(ident)
        if start is None:
            continue
        test = start['test']
        suite = suite_map.get(test['suiteID'], {})
        all_cases.append({
            'id': ident, 'suite': suite.get('path'), 'platform': suite.get('platform'),
            'name': test['name'], 'url': test.get('url'),
            'line': test.get('line'), 'column': test.get('column'),
            'started_ms': start.get('time'), 'finished_ms': event.get('time'),
            'result': event.get('result'), 'skipped': event.get('skipped', False),
            'hidden': event.get('hidden', False),
        })
    all_cases.sort(key=lambda row: (row['suite'] or '', row['name'], row['id']))
    cases = [row for row in all_cases if not row['hidden']]
    visible_suites = {row['path'] for row in suite_map.values()}
    summary = {
        'selected_suites': len(suites), 'observed_suites': len(visible_suites),
        'cases': len(cases),
        'passed': sum(row['result'] == 'success' and not row['skipped'] for row in cases),
        'failed': sum(row['result'] != 'success' for row in all_cases),
        'skipped': sum(row['skipped'] for row in all_cases),
        'error_events': len(errors), 'suite_counts': dict(Counter(row['suite'] for row in cases)),
        'missing_finishes': sorted(set(starts) - set(done)),
        'finishes_without_start': sorted(set(done) - set(starts)),
        'missing_suites': sorted(set(suites) - visible_suites),
        'unexpected_suites': sorted(visible_suites - set(suites)),
        'terminal': terminal[-1] if terminal else None,
        'malformed_event_lines': malformed,
    }
    summary['accepted'] = (
        summary['cases'] > 0 and bool(terminal) and terminal[-1].get('success') is True
        and not any(summary[key] for key in (
            'failed', 'skipped', 'error_events', 'missing_finishes',
            'finishes_without_start', 'missing_suites', 'unexpected_suites',
            'malformed_event_lines',
        ))
    )
    write(output / 'case-ledger.json', cases)
    write(output / 'all-test-ledger.json', all_cases)
    write(output / 'test-errors.json', errors)
    write(output / 'non-event-lines.json', non_events)
    write(output / 'test-summary.json', summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=DEFAULT_ROOT)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--dart', default=str(RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'))
    parser.add_argument('--node', default='node')
    parser.add_argument('--run', action='store_true', help='Execute only after source freeze and capacity signal.')
    parser.add_argument('--expected-commit')
    parser.add_argument('--tests-timeout', type=int, default=2400)
    args = parser.parse_args()
    root = args.root.resolve()
    engine = root / 'packages/quds_office_engine'
    suites = select_suites(engine)
    analysis = sorted(set(ANALYSIS))
    missing_analysis = [name for name in analysis if not (engine / name).is_file()]
    if missing_analysis:
        raise RuntimeError(f'Missing analysis files: {missing_analysis}')
    selection_dir = Path(__file__).resolve().parent
    write(selection_dir / 'suite-selection.json', suites)
    write(selection_dir / 'analysis-selection.json', analysis)
    if not args.run:
        write(selection_dir / 'prepared.json', {
            'prepared_at': utc(), 'source_head': git(root, 'rev-parse', 'HEAD').strip(),
            'root': str(root), 'suite_count': len(suites), 'analysis_files': len(analysis),
            'patterns': PATTERNS, 'concurrency': 1,
            'environment_setup': f'source {RUNTIME / "env.sh"}',
            'runtime': {'flutter': '3.47.8', 'dart': '3.13.7'},
            'tests_started': False, 'analysis_started': False,
        })
        print(json.dumps({'prepared': True, 'tests_started': False, 'suites': len(suites), 'analysis_files': len(analysis), 'directory': str(selection_dir)}))
        return
    if args.output is None:
        parser.error('--output is required with --run')
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    shutil.copy2(Path(__file__).resolve(), output / 'run_acceptance.py')
    write(output / 'suite-selection.json', suites)
    write(output / 'analysis-selection.json', analysis)
    commands = []
    start_time = time.monotonic()
    source_before = source_snapshot(root)
    dependencies_before = dependency_audit(root)
    write(output / 'inputs-before.json', source_before)
    write(output / 'dependencies-before.json', dependencies_before)
    source_head = git(root, 'rev-parse', 'HEAD').strip()
    dart = shutil.which(args.dart) if not os.path.isabs(args.dart) else args.dart
    node = shutil.which(args.node) if not os.path.isabs(args.node) else args.node
    metadata = {
        'started_at': utc(), 'root': str(root), 'cwd': str(engine),
        'source_commit': source_head, 'runner_sha256': sha(__file__),
        'configured_flutter': json.loads((root / '.fvmrc').read_text()),
        'dart_command': dart, 'node_command': node,
        'environment': {key: os.environ.get(key) for key in (
            'FLUTTER_ROOT', 'PUB_CACHE', 'TMPDIR', 'CI', 'DART_SUPPRESS_ANALYTICS',
        )},
        'source_input_count': len(source_before), 'concurrency': 1,
        'scope': 'Post-intake Word/Zotero regression and actual Word Split VM/JavaScript smoke; no GitHub Actions.',
    }
    write(output / 'invocation.json', metadata)
    (output / 'source-status-before.txt').write_text(git(root, 'status', '--porcelain=v1'))
    (output / 'source-diff-before.patch').write_text(git(root, 'diff', '--', 'packages/quds_office_engine', 'packages/legacy_doc_parser'))
    test_summary = None
    failure = None

    def run(name, command, timeout=600):
        stdout = output / (name + ('.jsonl' if name == 'tests' else '.stdout'))
        stderr = output / (name + '.stderr')
        entry = {'name': name, 'command': command, 'cwd': str(engine), 'started_at': utc(), 'timeout_seconds': timeout}
        commands.append(entry)
        write(output / 'commands.json', commands)
        print(json.dumps({'phase': 'start', 'name': name, 'time': entry['started_at']}), flush=True)
        command_start = time.monotonic()
        with stdout.open('wb') as out, stderr.open('wb') as err:
            process = subprocess.Popen(command, cwd=engine, stdout=out, stderr=err, start_new_session=True)
            try:
                entry['exit_code'] = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                entry['timed_out'] = True
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                entry['exit_code'] = process.returncode
        entry.update({
            'finished_at': utc(), 'seconds': round(time.monotonic() - command_start, 3),
            'stdout': stdout.name, 'stderr': stderr.name,
            'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr),
        })
        write(output / 'commands.json', commands)
        print(json.dumps({'phase': 'finish', 'name': name, 'exit_code': entry['exit_code'], 'seconds': entry['seconds']}), flush=True)
        if name == 'tests':
            nonlocal test_summary
            test_summary = parse_test_log(stdout, suites, output)
        if entry['exit_code'] != 0 or entry.get('timed_out'):
            raise RuntimeError(f'{name} did not succeed; inspect retained streams')
        return stdout

    try:
        if args.expected_commit and source_head != args.expected_commit:
            raise RuntimeError(f'Expected frozen commit {args.expected_commit}, found {source_head}')
        if not dependencies_before['accepted']:
            raise RuntimeError(f'Dependency lock audit failed: {dependencies_before["failures"]}')
        if metadata['configured_flutter'].get('flutter') != '3.47.8':
            raise RuntimeError('Repository Flutter pin changed')
        if not dart or not node:
            raise RuntimeError('Dart and Node must already be installed')
        runtime_version = run('dart-version', [dart, '--version'], 30).read_text().strip()
        metadata['dart_version'] = runtime_version
        if not runtime_version.startswith('Dart SDK version: 3.13.7 '):
            raise RuntimeError(f'Expected pinned Dart 3.13.7, got {runtime_version}')
        expected_dart = (RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart').resolve()
        if Path(dart).resolve() != expected_dart:
            raise RuntimeError(f'Dart executable is not the pinned Flutter runtime: {dart}')
        metadata['dart_binary_sha256'] = sha(expected_dart)
        flutter_version_file = RUNTIME / 'flutter/bin/cache/flutter.version.json'
        metadata['flutter_version_metadata'] = json.loads(flutter_version_file.read_text())
        if metadata['flutter_version_metadata'].get('frameworkVersion') != '3.47.8' or metadata['flutter_version_metadata'].get('dartSdkVersion') != '3.13.7':
            raise RuntimeError('Installed Flutter runtime does not match the repository pin')
        metadata['node_version'] = run('node-version', [node, '--version'], 30).read_text().strip()
        write(output / 'invocation.json', metadata)
        run('analysis', [dart, 'analyze', '--fatal-infos', *analysis])
        run('format', [dart, 'format', '--output=none', '--set-exit-if-changed', *analysis], 120)
        run('whitespace', ['git', '-C', str(root), 'diff', '--check', '--', 'packages/quds_office_engine', 'packages/legacy_doc_parser'], 30)
        run('tests', [dart, 'test', '--concurrency=1', '--reporter=json', *suites], args.tests_timeout)
        if not test_summary or not test_summary['accepted']:
            raise RuntimeError('Complete test ledger did not meet the acceptance gate')
        source = engine / 'example/macros/word_split_report.bas'
        driver = 'tool/macros/web_vba_word_split_smoke.dart'
        define = '-DWORD_SPLIT_BAS_BASE64=' + base64.b64encode(source.read_bytes()).decode()
        vm = run('word-report-vm', [dart, define, driver], 180)
        javascript = output / 'word-report.js'
        run('word-report-compile', [dart, 'compile', 'js', '-O1', define, driver, '-o', str(javascript)], 300)
        js = run('word-report-node', [node, '-e', 'globalThis.self = globalThis; require(process.argv[1]);', str(javascript)], 120)
        comparison = {
            'source': str(source.relative_to(root)), 'source_sha256': sha(source),
            'driver': driver, 'driver_sha256': sha(engine / driver),
            'equal_parsed_receipts': json.loads(vm.read_text()) == json.loads(js.read_text()),
            'byte_equal': vm.read_bytes() == js.read_bytes(),
            'vm_sha256': sha(vm), 'js_sha256': sha(js),
        }
        write(output / 'word-report-comparison.json', comparison)
        if not comparison['equal_parsed_receipts']:
            raise RuntimeError('Actual Word Split VM/JavaScript receipts differ')
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)}
        write(output / 'failure.json', failure)
    finally:
        source_after = source_snapshot(root)
        dependencies_after = dependency_audit(root)
        write(output / 'inputs-after.json', source_after)
        write(output / 'dependencies-after.json', dependencies_after)
        source_changes = [name for name in sorted(set(source_before) | set(source_after)) if source_before.get(name) != source_after.get(name)]
        stability = {
            'before_count': len(source_before), 'after_count': len(source_after),
            'source_unchanged': not source_changes, 'changed_paths': source_changes,
            'dependency_resolution_unchanged': dependencies_before == dependencies_after,
            'dependencies_accepted': dependencies_after['accepted'],
        }
        write(output / 'input-stability.json', stability)
        acceptance = {
            'accepted': failure is None and not source_changes and dependencies_before == dependencies_after,
            'source_commit': source_head, 'ending_commit': git(root, 'rev-parse', 'HEAD').strip(),
            'finished_at': utc(), 'seconds': round(time.monotonic() - start_time, 3),
            'input_stability': stability, 'tests': test_summary, 'failure': failure,
        }
        write(output / 'acceptance.json', acceptance)
        write(output / 'artifacts.json', {
            str(path.relative_to(output)): record(path)
            for path in sorted(output.rglob('*')) if path.is_file() and path.name != 'artifacts.json'
        })
        print(json.dumps(acceptance), flush=True)
    if not acceptance['accepted']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
