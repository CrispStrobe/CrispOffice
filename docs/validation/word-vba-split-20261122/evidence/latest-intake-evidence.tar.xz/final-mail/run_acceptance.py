#!/usr/bin/env python3
"""Bind merged Mail/Zotero acceptance to the isolated source tree and lock."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
from urllib.parse import unquote, urljoin, urlparse

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent / 'concurrent-office-intake'
MAIL = REPO / 'packages/quds_office_editor/example'
EDITOR = REPO / 'packages/quds_office_editor'
RUNTIME = ROOT.parent.parent / '.flutter-runtime'
MAIL_TESTS = sorted(MAIL.glob('test/studio_mail_account_navigation*_test.dart'))
EDITOR_TESTS = [EDITOR / 'test' / name for name in [
    'word_zotero_converter_controller_test.dart',
    'word_zotero_field_context_controller_test.dart',
    'word_zotero_recovery_controller_test.dart',
    'word_zotero_rich_controller_test.dart',
    'word_zotero_adjacent_citations_controller_test.dart',
    'word_zotero_multiparagraph_controller_test.dart',
    'word_zotero_bibliography_controller_test.dart',
    'word_zotero_transfer_controller_test.dart',
    'word_zotero_paragraph_format_controller_test.dart',
    'word_zotero_field_at_caret_test.dart',
    'word_zotero_unlink_recovery_test.dart',
    'word_zotero_note_target_test.dart',
]]
MAIL_PRODUCTION = [MAIL / 'lib' / (name + '.dart') for name in [
    'studio_mail_account_navigation', 'studio_mail_account_navigation_strings',
    'studio_mail_cloud', 'studio_mail_ews', 'studio_mail_native',
    'studio_mail_local_accounts',
]]
MAIL_PRODUCTION += [REPO / 'packages/quds_mail_store/lib/src/local_accounts.dart']
assert len(MAIL_TESTS) == 6 and all(p.is_file() for p in EDITOR_TESTS)


def sha(path):
    d = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            d.update(block)
    return d.hexdigest()


def input_paths():
    files = set(MAIL_TESTS + EDITOR_TESTS + MAIL_PRODUCTION)
    package_file = REPO / '.dart_tool/package_config.json'
    config = json.loads(package_file.read_text())
    files.add(package_file)
    for name in ['pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.fvmrc']:
        files.add(REPO / name)
    for item in config['packages']:
        uri = urljoin(package_file.as_uri(), item['rootUri'])
        package_root = Path(unquote(urlparse(uri).path)).resolve()
        if item['name'] == 'quds_office_editor':
            assert package_root == EDITOR.resolve(), 'Wrong checkout package configuration'
        for name in ['pubspec.yaml', 'analysis_options.yaml']:
            if (package_root / name).is_file():
                files.add(package_root / name)
        for sub in [item.get('packageUri', 'lib/'), 'hook']:
            directory = package_root / sub
            if directory.is_dir():
                files.update(p for p in directory.rglob('*') if p.is_file())
    for base, dirs in [
        (MAIL, ['test', 'assets', 'fonts']),
        (EDITOR, ['test', 'assets', 'fonts']),
        (REPO / 'packages/quds_office_engine', ['test/fixtures/zotero']),
    ]:
        for sub in dirs:
            files.update(p for p in (base / sub).rglob('*') if p.is_file())
        for name in ['test/flutter_test_config.dart', 'test/dart_test.yaml', 'dart_test.yaml']:
            if (base / name).is_file():
                files.add(base / name)
    for sub in ['bin/cache/dart-sdk/bin/dart',
                'bin/cache/artifacts/engine/linux-x64/flutter_tester',
                'bin/cache/flutter_tools.snapshot']:
        files.add(RUNTIME / 'flutter' / sub)
    files.add(REPO / '.dart_tool/hooks_runner/shared/sqlite3/build/download-0a658527/libsqlite3.so')
    return sorted({p.resolve() for p in files})


def snapshot():
    return {str(p): {'sha256': sha(p), 'bytes': p.stat().st_size}
            for p in input_paths()}


def now():
    return datetime.now(timezone.utc).isoformat()


before = snapshot()
(ROOT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
record = {
    'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    'source_root': str(REPO), 'started_at_utc': now(),
    'input_count': len(before), 'runs': [], 'status': 'running',
    'dependency_lock_sha256': sha(REPO / 'pubspec.lock'),
    'flutter_version': '3.47.8', 'dart_version': '3.13.7',
}


def save():
    (ROOT / 'acceptance.json').write_text(json.dumps(record, indent=2) + '\n')


def run(name, command, cwd):
    out, err = ROOT / (name + '.stdout.jsonl'), ROOT / (name + '.stderr.log')
    started = now()
    print('START ' + name, flush=True)
    with out.open('wb') as stdout, err.open('wb') as stderr:
        result = subprocess.run(command, cwd=cwd, stdout=stdout, stderr=stderr,
                                timeout=1800, env=os.environ.copy())
    record['runs'].append({
        'name': name, 'command': command, 'cwd': str(cwd),
        'started_at_utc': started, 'finished_at_utc': now(),
        'exit_code': result.returncode, 'stdout': str(out), 'stderr': str(err),
        'stdout_sha256': sha(out), 'stderr_sha256': sha(err),
    })
    save()
    print('END ' + name + ' exit=' + str(result.returncode), flush=True)
    return result.returncode


save()
try:
    exits = []
    exits.append(run('navigation-tests', [str(RUNTIME / 'bin/flutter'), 'test',
        '--no-pub', '--concurrency=1', '--reporter=json',
        *[str(p.relative_to(MAIL)) for p in MAIL_TESTS]], MAIL))
    exits.append(run('navigation-analysis', [str(RUNTIME / 'bin/dart'), 'analyze',
        '--fatal-infos', *[str(p) for p in MAIL_PRODUCTION + MAIL_TESTS]], MAIL))
    record['status'] = 'passed' if all(code == 0 for code in exits) else 'failed'
except BaseException as error:
    record['status'] = 'interrupted'
    record['runner_error'] = repr(error)
    raise
finally:
    after = snapshot()
    (ROOT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
    record['input_changes'] = {
        p: {'before': before.get(p), 'after': after.get(p)}
        for p in before.keys() | after.keys() if before.get(p) != after.get(p)
    }
    record['finished_at_utc'] = now()
    save()
    print(json.dumps({'status': record['status'], 'input_count': len(before),
                      'input_changes': len(record['input_changes'])}), flush=True)
