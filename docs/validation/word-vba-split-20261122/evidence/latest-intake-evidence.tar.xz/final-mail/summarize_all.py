#!/usr/bin/env python3
"""Produce case-level receipts from both native test streams."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def parse(name):
    events = []
    non_json = []
    source = ROOT / (name + '.stdout.jsonl')
    for n, line in enumerate(source.read_text().splitlines(), 1):
        try:
            event = json.loads(line)
            assert isinstance(event, dict)
            events.append(event)
        except (ValueError, AssertionError):
            if line.strip():
                non_json.append({'line': n, 'text': line})
    suites = {e['suite']['id']: e['suite'] for e in events if e.get('type') == 'suite'}
    tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    cases = []
    suite_loading_failures = []
    by_suite = {}
    for e in events:
        if e.get('type') != 'testDone' or e.get('hidden'):
            continue
        test = tests[e['testID']]
        if test['name'].startswith('loading '):
            if e['result'] != 'success':
                suite_loading_failures.append({'name': test['name'], 'result': e['result']})
            continue
        case = {'suite': suites[test['suiteID']]['path'], 'name': test['name'],
                'result': e['result'], 'skipped': e.get('skipped', False)}
        cases.append(case)
        counter = by_suite.setdefault(case['suite'], Counter())
        counter['skipped' if case['skipped'] else case['result']] += 1
    result = {'suite_loading_failures': suite_loading_failures,
              'case_count': len(cases),
              'distinct_case_count': len({(c['suite'], c['name']) for c in cases}),
              'suite_count': len(suites),
              'passed': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
              'failed': sum(c['result'] != 'success' and not c['skipped'] for c in cases),
              'skipped': sum(c['skipped'] for c in cases),
              'by_suite': by_suite,
              'errors': [e for e in events if e.get('type') == 'error'],
              'terminal_events': [e for e in events if e.get('type') == 'done'],
              'non_json_lines': non_json,
              'stdout_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'stderr_bytes': (ROOT / (name + '.stderr.log')).stat().st_size,
              'debug_warning_messages': sum(e.get('type') == 'print' and
                  'WARNING (drift):' in e.get('message', '') for e in events)}
    (ROOT / (name + '.cases.json')).write_text(json.dumps(cases, indent=2) + '\n')
    return result


record = json.loads((ROOT / 'acceptance.json').read_text())
results = {name: parse(name) for name in ['navigation-tests']}
summary = {'source_commit': record['source_commit'], 'status': record['status'],
           'results': results,
           'input_count': record['input_count'],
           'input_change_count': len(record['input_changes']),
           'passed': sum(x['passed'] for x in results.values()),
           'failed': sum(x['failed'] for x in results.values()),
           'skipped': sum(x['skipped'] for x in results.values()),
           'error_event_count': sum(len(x['errors']) for x in results.values())}
summary['store_continuity'] = json.loads((ROOT.parent / 'store-continuity.json').read_text())
summary['qualified'] = (summary['status'] == 'passed' and
                        summary['input_change_count'] == 0 and
                        summary['passed'] > 0 and summary['failed'] == 0 and
                        summary['skipped'] == 0 and summary['error_event_count'] == 0 and
                        all(len(x['terminal_events']) == 1 and
                            x['terminal_events'][0].get('success') is True
                            for x in results.values()))
(ROOT / 'qualification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
