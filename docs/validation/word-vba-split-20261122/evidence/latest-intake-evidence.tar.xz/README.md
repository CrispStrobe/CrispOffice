# Qualified Mail and Zotero editor intake

Qualified source: `c971ad0e1515db8deed59b7d8360960c64e13059`.
The combined case ledger contains **552 distinct passing cases**, with no failed
or skipped cases in the qualified results. No GitHub Actions result was queried
or awaited. The initial failed local attempt is retained separately.

| Scope | Suites | Cases | Execution source | How it applies to the qualified source |
| --- | ---: | ---: | --- | --- |
| Mail account navigation | 6 | 209 | `c971ad0e` | Fresh successful execution and strict analysis; all 8,980 before/after inputs identical. |
| Zotero editor integration | 12 | 296 | `cbb7ae3b` | All editor production, tests, fixtures, dependencies, and runtime inputs unchanged. The only two changed entries in the 8,980-input comparison are Mail test fixture repairs. |
| Native SQLite account store | 2 | 47 | `3e3a8fb0` | 6,381 relevant source, dependency, manifest, test, and runtime inputs rechecked unchanged; identical genuine SQLite release binary. |

This receipt applies only to these recorded source boundaries. Later engine or
deserializer changes require a new affected-scope qualification or explicit input
continuity; these results do not automatically qualify later production edits.

## Final Mail results

| Suite | Passed |
| --- | ---: |
| Account chooser dialog | 13 |
| Native owner release | 4 |
| Native navigation | 37 |
| EWS, Gmail, and Graph provider navigation | 100 |
| Account router | 5 |
| Account identity and canonical route validation | 50 |

The final test stream has 209 distinct substantive cases, zero errors/skips, one
successful terminal event, and empty stderr. Strict analysis of seven production
and store files plus all six navigation test files reports no issues. The new
Zotero converter controller test also passes strict analysis.

The twelve editor suites cover converter cycles; field context; damaged-field
recovery; rich results; adjacent citations; multiparagraph operations;
bibliographies; transfer; paragraph formatting; field lookup at the caret;
unlink recovery; and note targeting. Their exact suite paths and all case names
are in `qualified-cases.json` and `zotero-editor-tests.cases.json`.

## Preserved initial failures and repairs

At `cbb7ae3b`, the first Mail attempt passed 107 cases, failed two cases, and could
not load the provider suite. The failed cases were caused by a fixture assertion
casting `find.byTooltip`'s `RawTooltip` to `IconButton`; the provider suite had an
automatically merged duplicate `openGate` field. The bounded repair removed the
duplicate and matched `IconButton` by its tooltip property. No production code
changed for these repairs. The final six-suite rerun and strict analysis passed.

The initial editor run passed all 296 cases. Its entire 8,980-input snapshot was
unchanged during execution, so it was retained rather than repeated after two
unrelated Mail fixture edits. `editor-continuity.json` records the exact two
changed paths and their old/new hashes.

`merge-resolution.md` describes the earlier semantic conflict resolution. It
preserves explicit release recovery, observer and durable-receipt draining,
selected-account guards, late-owner serialization, and guarded catalog refresh.

## Runtime and reproduction

Execution uses the official Flutter **3.47.8**, Dart **3.13.7**, and the unchanged
repository lockfile. The isolated worktree ran
`dart pub get --offline --enforce-lockfile`; all 23 pubspec/lock manifests kept
their original hashes. Its package configuration maps to the isolated source
tree, not the other checkout running the broad Word engine gate.

SQLite is the actual native library selected by the unmodified `sqlite3 3.9.1`
package hook, version **3.54.1**, SHA-256
`0a65852703763619a7a34633b4959b3b86c4103804a4dfe4e8b27b5de1c0647b`.
Only that previously verified binary was copied into the new worktree's hook
download cache; no generated hook output or source code was substituted.

To reproduce with this prepared workspace:

```bash
source /workspace/scratch/7c69340222d3/.flutter-runtime/env.sh
cd /workspace/scratch/7c69340222d3/concurrent-office-intake/packages/quds_office_editor/example
flutter test --no-pub --concurrency=1 --reporter=json test/studio_mail_account_navigation*_test.dart
```

The complete exact commands, working directories, timings, exit codes, source
commit, output hashes, and selected editor paths are in `acceptance.json` and
`final-mail/acceptance.json`. The two runner scripts recreate the snapshots and
checks in their respective directories; copy an evidence directory before
rerunning so the original raw records remain intact.

## Evidence map

- `qualification-final.json`: combined, source-bounded 552-case result.
- `qualified-cases.json`: one entry per substantive qualified case, with source.
- `final-mail/`: successful rerun, strict analysis, raw streams, case ledger,
  command receipts, and before/after input hashes.
- Root `navigation-*`: initial failed Mail attempt and its strict analysis.
- Root `zotero-editor-*`: successful twelve-suite editor stream and case ledger.
- `inputs-before.json` and `inputs-after.json`: complete initial input snapshots.
- `editor-continuity.json`: editor qualification across the two Mail repairs.
- `store-continuity*.json`: mapped prior store dependencies and unchanged hashes.
- `workspace-*` and `sqlite-runtime.json`: exact-lock setup and native runtime.
- Archive `prior-mail-store/`: original 47-case store execution and source hashes.
- Archive `runtime/`: official SDK/archive provenance and environment scripts.

The earlier store stream contains one build-hook prefix before its first JSON
event and 17 Drift debug notices about multiple database instances across the
tests. It has no test errors or failures. These original messages are retained;
they are not counted as substantive test cases.
