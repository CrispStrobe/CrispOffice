#!/usr/bin/env python3
"""Bind local Mail navigation checks to source and dependency inputs."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
from urllib.parse import unquote, urljoin, urlparse

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'quds_office_suite'
PKG = REPO / 'packages/quds_office_editor/example'
RUNTIME = ROOT.parent / '.flutter-runtime'
ROOT.mkdir(parents=True, exist_ok=True)
TESTS = sorted(PKG.glob('test/studio_mail_account_navigation*_test.dart'))
PRODUCTION = [PKG / 'lib' / (name + '.dart') for name in [
    'studio_mail_account_navigation', 'studio_mail_account_navigation_strings',
    'studio_mail_cloud', 'studio_mail_ews', 'studio_mail_native']]
STORE = REPO / 'packages/quds_mail_store'
STORE_TESTS = [STORE / 'test/local_accounts_expected_record_test.dart', STORE / 'test/local_accounts_test.dart']
PRODUCTION += [PKG / 'lib/studio_mail_local_accounts.dart', STORE / 'lib/src/local_accounts.dart']
assert len(TESTS) == 5 and all(p.is_file() for p in STORE_TESTS)


def sha(path):
    d = hashlib.sha256()
    with path.open('rb') as stream:
        for b in iter(lambda: stream.read(1024 * 1024), b''):
            d.update(b)
    return d.hexdigest()


def input_paths():
    files = set(TESTS + STORE_TESTS + PRODUCTION)
    package_file = REPO / '.dart_tool/package_config.json'
    config = json.loads(package_file.read_text())
    files.add(package_file)
    for name in ['pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.fvmrc']:
        files.add(REPO / name)
    for item in config['packages']:
        uri = urljoin(package_file.as_uri(), item['rootUri'])
        root = Path(unquote(urlparse(uri).path))
        for name in ['pubspec.yaml', 'analysis_options.yaml']:
            if (root / name).is_file():
                files.add(root / name)
        lib = root / item.get('packageUri', 'lib/')
        if lib.is_dir():
            files.update(p for p in lib.rglob('*') if p.is_file())
    for dirname in ['test/support', 'assets', 'fonts']:
        files.update(p for p in (PKG / dirname).rglob('*') if p.is_file())
    for name in ['test/flutter_test_config.dart', 'test/dart_test.yaml', 'dart_test.yaml']:
        if (PKG / name).is_file():
            files.add(PKG / name)
    for sub in ['bin/cache/dart-sdk/bin/dart',
                'bin/cache/artifacts/engine/linux-x64/flutter_tester',
                'bin/cache/flutter_tools.snapshot']:
        files.add(RUNTIME / 'flutter' / sub)
    return sorted({p.resolve() for p in files})


def snapshot(paths):
    return {str(p): {'sha256': sha(p), 'bytes': p.stat().st_size}
            for p in paths}


paths = input_paths()
before = snapshot(paths)
(ROOT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
record = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
          'started_at_utc': datetime.now(timezone.utc).isoformat(),
          'input_count': len(before), 'runs': [], 'status': 'running'}


def save():
    (ROOT / 'acceptance.json').write_text(json.dumps(record, indent=2) + '\n')


def run(name, command, cwd=PKG):
    started = datetime.now(timezone.utc).isoformat()
    out = ROOT / (name + '.stdout.jsonl')
    err = ROOT / (name + '.stderr.log')
    print('START ' + name, flush=True)
    with out.open('wb') as stdout, err.open('wb') as stderr:
        result = subprocess.run(command, cwd=cwd, stdout=stdout, stderr=stderr,
                                timeout=600, env=os.environ.copy())
    receipt = {'name': name, 'command': command, 'cwd': str(cwd),
               'started_at_utc': started,
               'finished_at_utc': datetime.now(timezone.utc).isoformat(),
               'exit_code': result.returncode, 'stdout': str(out),
               'stderr': str(err), 'stdout_sha256': sha(out), 'stderr_sha256': sha(err)}
    record['runs'].append(receipt)
    save()
    print('END ' + name + ' exit=' + str(result.returncode), flush=True)
    return result.returncode


save()
try:
    test_exit = run('navigation-tests', [str(RUNTIME / 'bin/flutter'), 'test',
                    '--no-pub', '--concurrency=1', '--reporter=json',
                    *[str(p.relative_to(PKG)) for p in TESTS]])
    store_exit = run('store-tests', [str(RUNTIME / 'bin/dart'), 'test',
                    '--concurrency=1', '--reporter=json',
                    *[str(p.relative_to(STORE)) for p in STORE_TESTS]], cwd=STORE)
    analysis_exit = run('navigation-analysis', [str(RUNTIME / 'bin/dart'), 'analyze',
                        '--fatal-infos', *[str(p) for p in PRODUCTION]])
    record['status'] = 'passed' if test_exit == 0 and store_exit == 0 and analysis_exit == 0 else 'failed'
finally:
    after = snapshot(paths)
    (ROOT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
    changes = {p: {'before': before.get(p), 'after': after.get(p)}
               for p in before.keys() | after.keys() if before.get(p) != after.get(p)}
    record['input_changes'] = changes
    record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps({'status': record['status'], 'input_count': len(before),
                      'input_changes': len(changes)}), flush=True)
