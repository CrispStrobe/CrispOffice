from pathlib import Path
import subprocess,json,hashlib,datetime,time
base=Path('/workspace/scratch/7c69340222d3')
repo=base/'concurrent-office-intake'
engine=repo/'packages/quds_office_engine'
out=base/'zotero-main-reconciliation-qualification'
relative=[
 'lib/src/word/model/word_zotero.dart',
 'lib/src/word/model/word_field_spans.dart',
 'lib/src/word/model/wml_run_edit.dart',
 'lib/src/word/model/word_revision.dart',
 'lib/src/word/model/word_zotero_citing.dart',
 'lib/src/word/properties/wml_properties.dart',
 'lib/src/word/serial/word_deserializer.dart',
 'lib/src/word/serial/word_style_cascade.dart',
 'lib/src/word/serial/word_serializer.dart',
 'test/word_zotero_boundary_formatting_test.dart',
 'test/support/zotero_converter_fixtures.dart',
 'pubspec.yaml',
]
paths=[engine/p for p in relative]+[repo/'pubspec.yaml',repo/'pubspec.lock']
paths+=sorted(p for p in (engine/'test/fixtures/zotero/converter').rglob('*') if p.is_file())
def snapshot():
 return {str(p.relative_to(repo)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths}
before=snapshot()
(out/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
cmd=['dart','test','--concurrency=1','--reporter=json','test/word_zotero_boundary_formatting_test.dart']
metadata={'command':cmd,'cwd':str(engine),'environment':'source /workspace/scratch/7c69340222d3/.flutter-runtime/env.sh','runtime':subprocess.check_output(['dart','--version'],text=True,stderr=subprocess.STDOUT).strip(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'incomingMainHead':'4cc604810fb2f41ac7ba04cbed65cb76300bff59','incomingZoteroHead':'5bf13601caac2c08fe97de25fe853c9d642f0cb1','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputScope':'Explicit reviewed Word source files, boundary suite, shared golden helper, complete converter fixture subtree, package/root manifests and lock. Broader engine/editor acceptance is separately owned by root.'}
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
start=time.monotonic()
with (out/'events.jsonl').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 result=subprocess.run(cmd,cwd=engine,stdout=stdout,stderr=stderr)
after=snapshot()
(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
changes=[p for p in before if before[p]!=after.get(p)]
starts={};cases=[];errors=[];done=[]
for line in (out/'events.jsonl').read_text().splitlines():
 e=json.loads(line)
 if e['type']=='testStart':starts[e['test']['id']]=e['test']
 elif e['type']=='testDone' and not e['hidden']:
  cases.append({'name':starts[e['testID']]['name'],'result':e['result'],'skipped':e['skipped']})
 elif e['type']=='error':errors.append(e)
 elif e['type']=='done':done.append(e)
summary={'exitCode':result.returncode,'seconds':time.monotonic()-start,'uniqueCases':len(cases),'passed':sum(c['result']=='success' for c in cases),'failed':sum(c['result']!='success' for c in cases),'skipped':sum(c['skipped'] for c in cases),'errors':len(errors),'reporterSuccess':done[-1]['success'] if done else None,'capturedInputs':len(before),'inputChanges':changes,'stderrBytes':(out/'stderr.log').stat().st_size,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'case-ledger.json').write_text(json.dumps(cases,indent=2)+'\n')
(out/'errors.json').write_text(json.dumps(errors,indent=2)+'\n')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
raise SystemExit(result.returncode or bool(changes))
