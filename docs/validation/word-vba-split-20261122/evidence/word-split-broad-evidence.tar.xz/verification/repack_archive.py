from pathlib import Path
import hashlib,io,json,lzma,sys,tarfile
root=Path(sys.argv[1]);target=Path(sys.argv[2])
manifest=json.loads((root/'MEMBERS.json').read_text())
members={}
for entry in manifest['members']:
 data=(root/entry['path']).read_bytes()
 assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
 members[entry['path']]=data
members['MEMBERS.json']=(root/'MEMBERS.json').read_bytes()
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w',format=tarfile.PAX_FORMAT) as tar:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=0;info.gid=0
  tar.addfile(info,io.BytesIO(data))
data=lzma.compress(buffer.getvalue(),format=lzma.FORMAT_XZ,preset=6)
target.write_bytes(data)
print(json.dumps({'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'members':len(members)}))
