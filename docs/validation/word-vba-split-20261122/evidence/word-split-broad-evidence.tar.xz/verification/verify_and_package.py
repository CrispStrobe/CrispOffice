from pathlib import Path
import base64
import collections
import datetime
import hashlib
import io
import json
import lzma
import re
import subprocess
import tarfile

BASE = Path('/workspace/scratch/7c69340222d3')
GATE = BASE / 'word-split-final-gate'
REPO = BASE / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
RUNTIME = BASE / '.runtime'
ARCHIVE = BASE / 'word-split-broad-evidence.tar.xz'
MANIFEST = BASE / 'word-split-broad-evidence.manifest.json'
VERIFICATION = BASE / 'word-split-broad-evidence.verification.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def data_json(value):
    return (json.dumps(value, ensure_ascii=True, indent=2) + '\n').encode()


def read_json(path):
    return json.loads(path.read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


invocation = read_json(GATE / 'invocation.json')
resume = read_json(GATE / 'resume-invocation.json')
commands = read_json(GATE / 'commands.json')
selection = read_json(GATE / 'suite-selection.json')
inputs = read_json(GATE / 'inputs-before.json')
assert len(inputs) == 3068
assert inputs == read_json(GATE / 'inputs-after-initial.json')
assert inputs == read_json(GATE / 'inputs-after.json')
current_changes = [p for p, digest in inputs.items() if sha((REPO / p).read_bytes()) != digest]
assert not current_changes, current_changes
prefixes = (
    'packages/quds_office_engine/lib/',
    'packages/quds_office_engine/test/',
    'packages/quds_office_engine/tool/macros/',
    'packages/quds_office_engine/example/macros/',
    'packages/legacy_doc_parser/',
)
manifest_paths = {
    '.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
    'packages/quds_office_engine/pubspec.yaml',
    'packages/quds_office_engine/analysis_options.yaml',
}
tracked = git('ls-files', '-z').decode().split('\0')
expected_inputs = sorted(p for p in tracked if p and (p.startswith(prefixes) or p in manifest_paths) and (REPO / p).is_file())
assert expected_inputs == sorted(inputs)
changed_paths = git('diff', '--name-only', invocation['source_commit'], resume['source_commit']).decode().splitlines()
assert not set(changed_paths).intersection(inputs)

starts = {}
finishes = {}
suites = {}
terminals = []
errors = []
event_counts = collections.Counter()
raw_lines = (GATE / 'tests.stdout').read_text().splitlines()
for line in raw_lines:
    event = json.loads(line)
    kind = event['type']
    event_counts[kind] += 1
    if kind == 'suite':
        key = event['suite']['id']
        assert key not in suites
        suites[key] = event['suite']
    elif kind == 'testStart':
        key = event['test']['id']
        assert key not in starts
        starts[key] = event['test']
    elif kind == 'testDone':
        key = event['testID']
        assert key not in finishes
        finishes[key] = event
    elif kind == 'error':
        errors.append(event)
    elif kind == 'done':
        terminals.append(event)
assert set(starts) == set(finishes)
assert event_counts['start'] == 1
assert len(terminals) == 1 and terminals[0]['success'] is True
assert not errors
assert all(e['result'] == 'success' and not e['skipped'] for e in finishes.values())
cases = [dict(starts[key], result=e['result'], skipped=e['skipped']) for key, e in finishes.items() if not e['hidden']]
assert len(cases) == 9310
assert cases == read_json(GATE / 'cases.json')
assert data_json(cases) == (GATE / 'cases.json').read_bytes()
assert len(selection) == len(suites) == 179
assert sorted(s['path'] for s in suites.values()) == selection
assert len(commands) == 10
assert [c['name'] for c in commands].count('tests') == 1
assert commands[0]['name'] == 'tests'
assert commands[0]['command'][1:-2] == selection
assert commands[0]['command'][-2:] == ['--concurrency=2', '--reporter=json']
assert all(c['exit_code'] == 0 for c in commands)
for command in commands:
    for stream in ('stdout', 'stderr'):
        path = GATE / (command['name'] + '.' + stream)
        assert sha(path.read_bytes()) == command[stream + '_sha256']
        if stream == 'stderr':
            assert path.stat().st_size == 0
assert len({c['name'] for c in commands}) == len(commands)
assert all(left['finished'] <= right['started'] for left, right in zip(commands, commands[1:]))
by_name = {c['name']: c for c in commands}
analysis_files = by_name['analysis']['command'][3:]
assert len(analysis_files) == len(set(analysis_files)) == 9
assert by_name['analysis']['command'][1:3] == ['analyze', '--fatal-infos']
assert by_name['format']['command'][1:4] == ['format', '--output=none', '--set-exit-if-changed']
assert by_name['format']['command'][4:] == analysis_files
assert by_name['whitespace']['command'] == ['git', 'diff', '--check']
assert 'No issues found!' in (GATE / 'analysis.stdout').read_text()
assert 'Formatted 9 files (0 changed)' in (GATE / 'format.stdout').read_text()
assert (GATE / 'whitespace.stdout').stat().st_size == 0

# Some parameterized tests have the same display name. They are distinct
# registrations with different source parameters, never repeated subprocesses.
name_groups = collections.defaultdict(list)
for case in cases:
    suite = suites[case['suiteID']]
    name_groups[(suite['path'], suite['platform'], case['name'])].append(case)
duplicate_groups = []
source_excerpts = {}
for (path, platform, name), group in name_groups.items():
    if len(group) == 1:
        continue
    duplicate_groups.append({'suite': path, 'platform': platform, 'name': name,
                             'testIds': [c['id'] for c in group],
                             'sourceLine': group[0]['line']})
    key = (path, group[0]['line'])
    if key not in source_excerpts:
        lines = (ENGINE / path).read_text().splitlines()
        start = max(1, key[1] - 37)
        end = min(len(lines), key[1] + 14)
        source_excerpts[key] = {'path': path, 'sourceSha256': sha((ENGINE / path).read_bytes()),
                               'firstLine': start, 'lastLine': end,
                               'text': '\n'.join(lines[start - 1:end])}
assert len(name_groups) == 9289 and len(duplicate_groups) == 14
surrogates = [case for case in cases if any(0xD800 <= ord(ch) <= 0xDFFF for ch in case['name'])]
assert surrogates

runner = REPO / 'docs/validation/word-vba-split-20261122/run_checks.py'
assert sha((GATE / 'original-runner.py').read_bytes()) == invocation['runner_sha256']
assert sha(runner.read_bytes()) == resume['runner_sha256']
recovery = read_json(GATE / 'report-recovery.json')
assert recovery['original_runner_sha256'] == invocation['runner_sha256']
assert recovery['recovered_runner_sha256'] == resume['runner_sha256']
assert recovery['tests_will_be_reexecuted'] is False
assert resume['arguments']['resume_tests_report'] is True
initial_failure = (GATE / 'initial-driver.log').read_text()
assert 'Finished tests: 0' in initial_failure
assert 'UnicodeEncodeError' in initial_failure and 'surrogates not allowed' in initial_failure
assert 'ensure_ascii=False' in (GATE / 'original-runner.py').read_text()
assert 'ensure_ascii=True' in runner.read_text()
assert sha((REPO / '.dart_tool/package_config.json').read_bytes()) == invocation['package_config_sha256'] == resume['package_config_sha256']

portable = {}
for name, source, define in (
    ('split-corpus', 'test/fixtures/vba_conformance/split_v1.json', 'VBA_CONFORMANCE_BASE64'),
    ('word-report', 'example/macros/word_split_report.bas', 'WORD_SPLIT_BAS_BASE64'),
):
    source_bytes = (ENGINE / source).read_bytes()
    receipt = read_json(GATE / (name + '-comparison.json'))
    vm_bytes = (GATE / (name + '-vm.stdout')).read_bytes()
    js_bytes = (GATE / (name + '-node.stdout')).read_bytes()
    vm = json.loads(vm_bytes)
    js = json.loads(js_bytes)
    assert vm == js
    assert sha(source_bytes) == receipt['source_sha256']
    assert sha(vm_bytes) == receipt['vm_sha256']
    assert sha(js_bytes) == receipt['js_sha256']
    assert (vm_bytes == js_bytes) == receipt['byte_equal']
    assert receipt['equal_parsed_receipts'] is True
    for mode in ('vm', 'compile'):
        flags = [arg for arg in by_name[name + '-' + mode]['command'] if arg.startswith('-D' + define + '=')]
        assert len(flags) == 1
        assert base64.b64decode(flags[0].split('=', 1)[1], validate=True) == source_bytes
    portable[name] = receipt
    if name == 'split-corpus':
        assert vm_bytes == js_bytes and vm['caseCount'] == 174 and vm['adapterCount'] == 3
    else:
        assert set(vm) == {'docx', 'docm'}
        assert vm_bytes != js_bytes
        normalize_numbers = lambda data: re.sub(rb'(-?\d+)\.0(?=[,}\]])', rb'\1', data)
        assert normalize_numbers(vm_bytes) == js_bytes
        differences = []
        def compare_representation(left, right, path='$'):
            if isinstance(left, dict):
                assert set(left) == set(right)
                for key in left:
                    compare_representation(left[key], right[key], path + '.' + key)
            elif isinstance(left, list):
                assert len(left) == len(right)
                for index, (a, b) in enumerate(zip(left, right)):
                    compare_representation(a, b, path + '[' + str(index) + ']')
            elif type(left) is not type(right):
                assert isinstance(left, float) and isinstance(right, int)
                assert left.is_integer() and left == right
                differences.append(path)
            else:
                assert left == right
        compare_representation(vm, js)
        assert len(differences) == 58
        portable[name]['representationDifferences'] = differences

accepted = read_json(GATE / 'accepted.json')
assert accepted == {'accepted': True, 'inputs': 3068, 'tests': {
    'selected_suites': 179, 'cases': 9310, 'passed': 9310, 'failed': 0,
    'skipped': 0, 'error_events': 0, 'terminal_success': True}}
assert accepted['tests'] == read_json(GATE / 'test-summary.json')
runtime_provenance = read_json(RUNTIME / 'runtime-provenance.json')
assert runtime_provenance['dart_version'] == '3.14.1'
assert runtime_provenance['repository_lock_sha256'] == sha((REPO / 'pubspec.lock').read_bytes())
assert runtime_provenance['resolved_lock_sha256'] == sha((RUNTIME / 'engine-validation/pubspec.lock').read_bytes())
assert runtime_provenance['dependency_changes'] == {}
helper = 'packages/quds_office_engine/tool/macros/web_vba_word_table_cells_smoke.dart'
assert helper in inputs

verification = {
    'schemaVersion': 1,
    'accepted': True,
    'registeredCases': 9310,
    'selectedSuites': 179,
    'passed': 9310,
    'failed': 0,
    'skipped': 0,
    'errorEvents': 0,
    'missingOrDuplicateStartFinishIds': False,
    'hiddenLifecycleRecordsExcluded': len(starts) - len(cases),
    'hiddenLifecycleProblems': 0,
    'rawReporterStarts': event_counts['start'],
    'rawSuccessfulTerminalEvents': len(terminals),
    'caseLedgerEqualsIndependentReconstruction': True,
    'caseLedgerByteReconstructionEqual': True,
    'escapedSurrogateNamedCases': len(surrogates),
    'counting': {
        'distinctSuitePlatformNameTuples': len(name_groups),
        'duplicateDisplayNameGroups': len(duplicate_groups),
        'additionalRegistrationsSharingDisplayNames': len(cases) - len(name_groups),
        'sourceReview': 'All 14 duplicate-name groups were independently read. They use distinct parameter variants: group-shape contents, duplicate element/attribute shapes, tab markup/numeric limits, allocation states, surrogate-producing expressions and mutation policies.',
        'duplicateRuntimeExecutionsAddedToCount': 0,
        'additionalPortabilityOrRuntimeProofCaseCredit': 0,
    },
    'sourceContinuity': {
        'capturedInputs': len(inputs),
        'selectionMatchesTrackedSourcePrefixesAndManifests': True,
        'beforeEqualsAfterInitialEqualsAfterRecoveredEqualsCurrent': True,
        'changedInputs': [],
        'initialSourceCommit': invocation['source_commit'],
        'reportRecoverySourceCommit': resume['source_commit'],
        'commitDeltaTouchesCapturedInputs': False,
        'commitDeltaPaths': changed_paths,
        'previouslyOmittedPinnedFixtureIsCapturedHere': helper,
        'capturedFixtureSha256': inputs[helper],
        'comparisonCheckout': str(REPO),
        'laterConcurrentIntakeSourceClaimedIdentical': False,
    },
    'reportRecovery': {
        'initialTestSubprocessExitCode': 0,
        'initialDriverCompletedSuccessfully': False,
        'initialDriverFailure': 'UnicodeEncodeError while writing cases.json with ensure_ascii=False; a passing testcase name intentionally contains an isolated UTF-16 surrogate.',
        'testsReexecutedForRecovery': False,
        'testCommandRecords': 1,
        'originalTestStreamsVerifiedAgainstRetainedDigests': True,
        'sourceAndSuiteSelectionGuardsVerified': True,
        'originalRunnerSha256': invocation['runner_sha256'],
        'recoveredRunnerSha256': resume['runner_sha256'],
        'recoveredJsonEncoding': 'ensure_ascii=True',
        'remainingPostTestCommands': len(commands) - 1,
        'remainingPostTestCommandFailures': 0,
    },
    'staticChecks': {'analyzedFiles': analysis_files, 'fatalInfos': True, 'analysisExitCode': 0, 'formatFiles': 9, 'formatChangedFiles': 0, 'whitespaceExitCode': 0},
    'runtime': {
        'dart': '3.14.1', 'node': invocation['node_version'],
        'environment': runtime_provenance['isolation'],
        'hostedVersionsUnchanged': runtime_provenance['hosted_versions_unchanged'],
        'rootPackageConfigSha256': invocation['package_config_sha256'],
        'testRunnerPackageConfigSha256': sha((RUNTIME / 'engine-package-config.json').read_bytes()),
        'rootAndTestRunnerConfigurationsRetainedSeparately': True,
    },
    'portability': {
        'splitCorpus': {'caseReceipts': 174, 'adapters': 3, **portable['split-corpus']},
        'nativeWordReport': {'formats': ['docx', 'docm'], **portable['word-report'], 'numericRepresentationDifferences': 58, 'onlyRawDifferenceIsIntegralDecimalSuffix': True},
    },
    'allCommandOutputDigestsVerified': len(commands) * 2,
    'allCommandStderrBytes': 0,
    'testsExecutedDuringIndependentVerification': False,
    'repositoryOrGitEditsMade': False,
    'ciQueried': False,
    'scope': 'Original broad Word/VBA selected-engine gate at captured source373b7fe9, with report recovery at7a0d1f30. Later reconciled Mail/Zotero engine/editor gates are separate. This is not a whole-workspace or installed Microsoft Office acceptance claim.',
}

members = {}
source_files = {}
def include(name, path):
    data = path.read_bytes()
    members[name] = data
    source_files[str(path)] = sha(data)

excluded = []
for path in sorted(GATE.iterdir()):
    if not path.is_file():
        continue
    if path.name.endswith(('.js', '.js.map', '.js.deps')):
        excluded.append(path.name)
        continue
    include('gate/' + path.name, path)
include('runner/run_checks.py', runner)
for name in ('runtime-provenance.json', 'sdk-provenance.json', 'locked-closure.json', 'original-lock.json', 'engine-package-config.json', 'env.sh', 'run-engine-tests.sh'):
    include('runtime/' + name, RUNTIME / name)
include('runtime/root-package-config.json', REPO / '.dart_tool/package_config.json')
for name in ('pubspec.yaml', 'pubspec.lock', 'packages/quds_office_engine/pubspec.yaml', 'packages/legacy_doc_parser/pubspec.yaml', '.dart_tool/package_config.json', '.dart_tool/package_graph.json'):
    include('runtime/isolated-workspace/' + name, RUNTIME / 'engine-validation' / name)
for name in ('compile-test-runner.log', 'pub-get-verified.log', 'pub-get-reduced.log'):
    include('runtime/logs/' + name, RUNTIME / 'logs' / name)
verification['excludedGeneratedGateFiles'] = excluded
verification['excludedRuntimeBinaries'] = ['Dart SDK archive and binaries', 'compiled test-runner.dill', 'hosted package cache binaries']
members['verification/independent-verification.json'] = data_json(verification)
members['verification/duplicate-display-name-review.json'] = data_json({'groups': duplicate_groups, 'sourceExcerpts': list(source_excerpts.values()), 'conclusion': verification['counting']['sourceReview']})
members['verification/surrogate-name-cases.json'] = data_json([{'id': c['id'], 'suite': suites[c['suiteID']]['path'], 'name': c['name'], 'result': c['result']} for c in surrogates])
members['verification/verify_and_package.py'] = Path(__file__).read_bytes()
members['verification/repack_archive.py'] = b'''from pathlib import Path
import hashlib,io,json,lzma,sys,tarfile
root=Path(sys.argv[1]);target=Path(sys.argv[2])
manifest=json.loads((root/'MEMBERS.json').read_text())
members={}
for entry in manifest['members']:
 data=(root/entry['path']).read_bytes()
 assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
 members[entry['path']]=data
members['MEMBERS.json']=(root/'MEMBERS.json').read_bytes()
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w',format=tarfile.PAX_FORMAT) as tar:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=0;info.gid=0
  tar.addfile(info,io.BytesIO(data))
data=lzma.compress(buffer.getvalue(),format=lzma.FORMAT_XZ,preset=6)
target.write_bytes(data)
print(json.dumps({'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'members':len(members)}))
'''
members['README.txt'] = '''Broad Word/VBA gate: original source acceptance and report recovery

The raw test process completed successfully: 9,310 registered test cases
passed across 179 suites. No failures, errors or skips occurred. Its retained
stdout has one runner start and one successful terminal event. The 257 hidden
loading/lifecycle records are excluded from the case count and also passed.
Some parameterized registrations share display names. There are 9,289 distinct
suite/platform/name tuples; all 14 duplicate-name groups use independently
reviewed, distinct source parameters. Repeated runs are not credited as new
cases, and portability/runtime proof repetitions are not added to 9,310.

The initial Python DRIVER DID FAIL after the successful test subprocess. It
tried to serialize an intentional isolated UTF-16 surrogate in a passing test
name as unescaped UTF-8. initial-driver.log and original-runner.py retain the
failure. This was a report-writing failure, not a failed test and not a wholly
successful initial driver invocation.

The corrected runner uses escaped JSON. Its guarded --resume-tests-report
path verifies exactly unchanged captured inputs, raw test stdout/stderr
hashes, one successful test command and unchanged suite selection before
rebuilding the case ledger. It did not rerun tests. The recovered ledger was
independently reconstructed byte-for-byte, including the surrogate names.
The remaining nine commands then passed: strict nine-file analysis,
format/whitespace checks, and the compiler/native VM/JavaScript comparisons.

All 3,068 captured tracked inputs match before the original run, after its
report failure, after recovery, and the original checkout at independent
verification. The original source commit is373b7fe9; recovery is7a0d1f30.
Their changed paths do not touch the captured engine/legacy/manifests scope.
The later concurrent Mail/Zotero intake is a separate source snapshot and gate;
this archive does not claim those later changed files were identical here.

The runtime is recorded Dart3.14.1 with exact repository-lock hosted versions,
in a reduced two-package engine validation workspace. Both root and wrapper
package configurations are retained. SDK/package binaries, compiled runner
kernel, generated JavaScript, maps and dependency products are excluded.
Retained runtime metadata/manifests, wrapper, compile log and qualification
runner describe reproduction with the matching checkout and SDK. The isolated
runtime's separate80-case proof is provenance only, not added test coverage.

The Split corpus has174 VM/JavaScript receipts across3 adapters, byte-identical.
The native Word BAS receipts cover DOCX and DOCM and are equal as parsed JSON;
their only raw differences are58 integral-number spellings such as4.0 versus4.
No output normalization was used to execute either driver. Independent
verification reports the representation difference rather than byte equality.

The archive includes all retained gate raw logs, commands, ledgers, manifests,
invocations, initial failure and recovery records. It is not a whole-workspace
or installed Microsoft Word/LibreOffice acceptance claim. No hosted CI queue
was queried, and no tests were rerun for independent packaging.

MEMBERS.json hashes every payload except itself. The outside manifest hashes
all members, including MEMBERS.json, plus the compressed archive. Extract and
run python3 verification/repack_archive.py EXTRACTED_DIR OUTPUT.tar.xz to
verify the payload and reproduce the normalized archive byte-for-byte.
'''.encode()

member_manifest = {'schemaVersion': 1, 'members': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())]}
members['MEMBERS.json'] = data_json(member_manifest)
def build_archive():
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data); info.mode = 0o644; info.mtime = 0; info.uid = 0; info.gid = 0
            tar.addfile(info, io.BytesIO(data))
    return lzma.compress(buffer.getvalue(), format=lzma.FORMAT_XZ, preset=6)
archive_bytes = build_archive()
assert archive_bytes == build_archive()
ARCHIVE.write_bytes(archive_bytes)
with tarfile.open(ARCHIVE, 'r:xz') as tar:
    assert len(tar.getmembers()) == len(members)
    for member in tar:
        assert tar.extractfile(member).read() == members[member.name]
for path, digest in source_files.items():
    assert sha(Path(path).read_bytes()) == digest
outer = {'schemaVersion': 1, 'archive': {'path': ARCHIVE.name, 'bytes': len(archive_bytes), 'sha256': sha(archive_bytes)}, 'members': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())]}
MANIFEST.write_bytes(data_json(outer))
concise = {key: verification[key] for key in ('schemaVersion', 'accepted', 'registeredCases', 'selectedSuites', 'passed', 'failed', 'skipped', 'errorEvents', 'hiddenLifecycleRecordsExcluded', 'caseLedgerByteReconstructionEqual', 'escapedSurrogateNamedCases', 'counting', 'reportRecovery', 'runtime', 'scope')}
concise.update({'capturedInputs': 3068, 'allCapturedInputsUnchanged': True, 'staticChecksPass': True, 'strictAnalyzedFormattedFiles': 9, 'allCommandOutputDigestsVerified': 20, 'compilerCorpusReceipts': 174, 'compilerAdapters': 3, 'compilerVmJsByteEqual': True, 'wordReportParsedVmJsEqual': True, 'wordReportByteEqual': False, 'wordReportIntegralNumberSpellingDifferences': 58, 'memberCount': len(members), 'archive': outer['archive'], 'outerManifest': {'path': MANIFEST.name, 'bytes': MANIFEST.stat().st_size, 'sha256': sha(MANIFEST.read_bytes())}, 'everyMemberReopenedAndVerified': True, 'deterministicRebuildByteIdentical': True, 'sourceEvidenceUnchangedDuringPackaging': True, 'newTestsRun': False, 'repositoryOrGitEdits': False, 'ciQueried': False})
VERIFICATION.write_bytes(data_json(concise))
for path in (ARCHIVE, MANIFEST, VERIFICATION):
    print(json.dumps({'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}))
print(json.dumps({'members': len(members), 'registeredCases': len(cases), 'surrogateNamedCases': len(surrogates), 'sourceInputs': len(inputs), 'excludedGeneratedFiles': len(excluded)}))
