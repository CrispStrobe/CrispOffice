Broad Word/VBA gate: original source acceptance and report recovery

The raw test process completed successfully: 9,310 registered test cases
passed across 179 suites. No failures, errors or skips occurred. Its retained
stdout has one runner start and one successful terminal event. The 257 hidden
loading/lifecycle records are excluded from the case count and also passed.
Some parameterized registrations share display names. There are 9,289 distinct
suite/platform/name tuples; all 14 duplicate-name groups use independently
reviewed, distinct source parameters. Repeated runs are not credited as new
cases, and portability/runtime proof repetitions are not added to 9,310.

The initial Python DRIVER DID FAIL after the successful test subprocess. It
tried to serialize an intentional isolated UTF-16 surrogate in a passing test
name as unescaped UTF-8. initial-driver.log and original-runner.py retain the
failure. This was a report-writing failure, not a failed test and not a wholly
successful initial driver invocation.

The corrected runner uses escaped JSON. Its guarded --resume-tests-report
path verifies exactly unchanged captured inputs, raw test stdout/stderr
hashes, one successful test command and unchanged suite selection before
rebuilding the case ledger. It did not rerun tests. The recovered ledger was
independently reconstructed byte-for-byte, including the surrogate names.
The remaining nine commands then passed: strict nine-file analysis,
format/whitespace checks, and the compiler/native VM/JavaScript comparisons.

All 3,068 captured tracked inputs match before the original run, after its
report failure, after recovery, and the original checkout at independent
verification. The original source commit is373b7fe9; recovery is7a0d1f30.
Their changed paths do not touch the captured engine/legacy/manifests scope.
The later concurrent Mail/Zotero intake is a separate source snapshot and gate;
this archive does not claim those later changed files were identical here.

The runtime is recorded Dart3.14.1 with exact repository-lock hosted versions,
in a reduced two-package engine validation workspace. Both root and wrapper
package configurations are retained. SDK/package binaries, compiled runner
kernel, generated JavaScript, maps and dependency products are excluded.
Retained runtime metadata/manifests, wrapper, compile log and qualification
runner describe reproduction with the matching checkout and SDK. The isolated
runtime's separate80-case proof is provenance only, not added test coverage.

The Split corpus has174 VM/JavaScript receipts across3 adapters, byte-identical.
The native Word BAS receipts cover DOCX and DOCM and are equal as parsed JSON;
their only raw differences are58 integral-number spellings such as4.0 versus4.
No output normalization was used to execute either driver. Independent
verification reports the representation difference rather than byte equality.

The archive includes all retained gate raw logs, commands, ledgers, manifests,
invocations, initial failure and recovery records. It is not a whole-workspace
or installed Microsoft Word/LibreOffice acceptance claim. No hosted CI queue
was queried, and no tests were rerun for independent packaging.

MEMBERS.json hashes every payload except itself. The outside manifest hashes
all members, including MEMBERS.json, plus the compressed archive. Extract and
run python3 verification/repack_archive.py EXTRACTED_DIR OUTPUT.tar.xz to
verify the payload and reproduce the normalized archive byte-for-byte.
