# Final merged Mail and Zotero editor qualification

Qualified commit: `8bbe17bc7d82964b67385aa796b7f43248c65149`.
Qualified tree: `f1b36d91a8fb6bc843bcbc9c448a911f47147566`.

**563 distinct cases are qualified, with zero failures or skips.** Of these,
516 were freshly executed on this commit; the 47 native SQLite store cases have
unchanged source/dependency inputs verified before and after the fresh run.

| Scope | Suites | Passed | Evidence |
| --- | ---: | ---: | --- |
| Mail account navigation | 6 | 220 | Fresh run, including all eleven late-main regressions. |
| Zotero editor integration | 12 | 296 | Fresh run against the final engine parsing and revision fixes. |
| Native SQLite account store | 2 | 47 | Prior passed execution; all 6,381 scoped inputs remain unchanged. |

The fresh run captured 8,980 production, package dependency, selected test,
fixture, configuration, and runtime inputs. Their before/after hashes are
identical. Both test groups have one successful terminal event, no suite loading
failures or error events, and empty stderr. Strict analysis reports no issues for
the seven Mail/store production files, all six navigation suites, and the new
Zotero converter controller test.

## Actual changes since the preceding qualification

The preceding qualified commit was `c971ad0e`. Nine captured inputs changed
between that commit and this run: six engine production files and three Mail
test files. Those changes are recorded separately from the zero changes observed
during this run. The engine files are:

- `word_deserializer.dart`
- `word_style_cascade.dart`
- `wml_properties.dart`
- `wml_run_edit.dart`
- `word_revision.dart`
- `word_zotero.dart`

The changed Mail fixtures are the native, provider, and account-validation test
suites. Mail production files, the dependency lock, the runtime, and the scoped
store inputs remain unchanged. `previous-qualification-input-delta.json`
contains every old/new input hash; `package-changes-since-qualified-source.patch`
contains the exact package diff; `changes-since-qualified-source.txt` includes the
complete Git name/status diff, including documentation and engine tests.

The twelve editor suites were rerun because their read/write operations exercise
the changed engine behavior. The six Mail suites were rerun to qualify the
late-main merge and eleven additional regressions. No unrelated test expansion
was performed after these gates passed.

## Mail coverage and merge contract

| Mail suite | Passed |
| --- | ---: |
| Chooser dialog | 13 |
| Native owner release | 4 |
| Native navigation | 40 |
| EWS, Gmail, and Graph provider navigation | 106 |
| Account router | 5 |
| Identity and canonical route validation | 52 |

`late-main-resolution.md` explains the overlapping atomic refresh fixes. The
merged implementation keeps the qualified final guarded refresh, all post-await
identity checks, and explicit owner recovery. The new regressions verify fresh
catalog registration, failed removed/revised selected refreshes, legacy custom
directories, and expiration while validation is pending. The fixtures distinguish
attempted refreshes from successful writes; stale CAS completion commits nothing.

The editor suites cover converter cycles, field context, damaged-field recovery,
rich results, adjacent citations, multiparagraph operations, bibliographies,
transfer, paragraph formatting, field lookup, unlink recovery, and note targets.
Every exact suite path and case name appears in `qualified-cases.json`.

## Runtime and reproduction

The run used official Flutter 3.47.8 / Dart 3.13.7 with the original exact lock
and no Pub resolution during testing. Dependency lock SHA-256:
`2231cacd6ab548da8f0d94020201a29f07f54a20c1682c0e8ae0079967b720eb`.

The genuine native SQLite library remains version 3.54.1, from the unmodified
`sqlite3 3.9.1` package hook, SHA-256
`0a65852703763619a7a34633b4959b3b86c4103804a4dfe4e8b27b5de1c0647b`.
SDK archive provenance, exact-lock setup, and native runtime records are retained
in the archive under `prior-intake/`.

Both fresh test groups ran with `--no-pub --concurrency=1 --reporter=json`.
`acceptance.json` records the exact commands, working directories, source tree,
timings, exit codes, and raw output hashes. To reproduce using this prepared
workspace, copy the evidence directory first so existing raw results remain
intact, then source `/workspace/scratch/7c69340222d3/.flutter-runtime/env.sh` and
run the copied `run_acceptance.py` script.

No GitHub Actions results were queried or awaited.

## Evidence contents

- `qualification-final.json`: combined 563-case source-bounded result.
- `qualified-cases.json`: distinct qualified cases with execution source.
- `qualification.json`: fresh 516-case run and unchanged store receipt.
- `navigation-*` and `zotero-editor-*`: fresh raw streams and case ledgers.
- `*-analysis.*`: strict analysis output and stderr.
- `inputs-before.json` / `inputs-after.json`: full fresh input snapshots.
- `store-continuity*.json`: 6,381 exact scoped inputs checked before and after.
- Input-delta JSON and package patch: changes across qualification commits.
- `prior-intake/` in the archive: the complete preceding evidence package,
  including the initial failed Mail fixture attempt, its successful repair,
  previous editor results, original store raw results, source snapshots, and SDK
  provenance. Prior failures are retained and do not count as current passes.
- `archive-members.json`: per-member digests for the combined archive.

The archived store stream preserves its build-hook prefix and 17 Drift debug
notices about database instances in separate tests. It has no failed cases or
test errors. Loader/setup records are not counted as substantive test cases.
