#!/usr/bin/env python3
"""Summarize the raw Flutter JSON stream without counting loader/setup events."""
from collections import Counter
import ctypes
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'quds_office_suite'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


events = []
non_json = []
for i, line in enumerate((ROOT / 'navigation-tests.stdout.jsonl').read_text().splitlines(), 1):
    try:
        event = json.loads(line)
        assert isinstance(event, dict)
        events.append(event)
    except (ValueError, AssertionError):
        if line.strip():
            non_json.append({'line': i, 'text': line})
suites = {e['suite']['id']: e['suite'] for e in events if e.get('type') == 'suite'}
tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
by_suite = {}
cases = []
for e in events:
    if e.get('type') != 'testDone' or e.get('hidden'):
        continue
    test = tests[e['testID']]
    suite = suites[test['suiteID']]
    case = {'suite': suite['path'], 'name': test['name'],
            'result': e['result'], 'skipped': e.get('skipped', False)}
    cases.append(case)
    c = by_suite.setdefault(suite['path'], Counter())
    if case['skipped']:
        c['skipped'] += 1
    else:
        c[case['result']] += 1
errors = [e for e in events if e.get('type') == 'error']
done = [e for e in events if e.get('type') == 'done']
summary = {'suite_count': len(suites),
           'case_count': len(cases),
           'distinct_case_count': len({(c['suite'], c['name']) for c in cases}),
           'passed': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
           'failed': sum(c['result'] != 'success' and not c['skipped'] for c in cases),
           'skipped': sum(c['skipped'] for c in cases),
           'error_event_count': len(errors),
           'terminal_events': done,
           'by_suite': by_suite,
           'non_json_lines': non_json,
           'errors': errors,
           'stderr_bytes': (ROOT / 'navigation-tests.stderr.log').stat().st_size}
(ROOT / 'cases.json').write_text(json.dumps(cases, indent=2) + '\n')
(ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')

sqlite = REPO / '.dart_tool/hooks_runner/shared/sqlite3/build/download-0a658527/libsqlite3.so'
expected = '0a65852703763619a7a34633b4959b3b86c4103804a4dfe4e8b27b5de1c0647b'
actual = sha(sqlite)
assert actual == expected
library = ctypes.CDLL(str(sqlite))
library.sqlite3_libversion.restype = ctypes.c_char_p
native = {'library': str(sqlite), 'sha256': actual,
          'locked_package_expected_sha256': expected,
          'version': library.sqlite3_libversion().decode(),
          'origin': 'Default unmodified sqlite3 3.9.1 Pub package build hook; downloaded release asset, checksum validated by hook and independently.',
          'no_library_substitution': True}
(ROOT / 'sqlite-runtime.json').write_text(json.dumps(native, indent=2) + '\n')
shutil.copyfile(REPO / '.dart_tool/hooks_runner/sqlite3/6b4ebf10e7/output.json',
                ROOT / 'sqlite-hook-output.json')
print(json.dumps(summary, indent=2))
