#!/usr/bin/env python3
"""Stream and verify the official pinned Flutter runtime for local tests."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tarfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
URL = 'https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.47.8-stable.tar.xz'
SHA256 = 'baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2'
ROOT.mkdir(parents=True, exist_ok=True)


class DigestReader:
    def __init__(self, stream):
        self.stream = stream
        self.digest = hashlib.sha256()
        self.total = 0

    def read(self, n=-1):
        data = self.stream.read(n)
        self.digest.update(data)
        self.total += len(data)
        return data


def selected(name):
    parts = PurePosixPath(name).parts
    if not parts or parts[0] != 'flutter':
        return False
    if len(parts) == 1:
        return True
    if parts[1] == '.git':
        return True
    if parts[1] == 'bin':
        if '/'.join(parts[1:]).startswith('bin/cache/artifacts/engine/'):
            platform = parts[5] if len(parts) > 5 else ''
            if platform.startswith(('android', 'ios', 'darwin', 'windows',
                                    'linux-arm64', 'linux-x64-profile',
                                    'linux-x64-release')):
                return False
        return True
    if parts[1] == 'packages':
        return not (len(parts) > 3 and parts[3] in {
            'test', 'test_private', 'test_fixes', 'example', 'examples',
            'benchmark', 'benchmarks'})
    return len(parts) == 2 and parts[1] in {
        'LICENSE', 'AUTHORS', 'README.md', 'version', '.metadata',
        'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
        'flutter_console.bat'}


expanded = 0
files = []
last = time.monotonic()
print('Streaming official Flutter 3.47.8 archive', flush=True)
with urllib.request.urlopen(URL, timeout=60) as response:
    reader = DigestReader(response)
    with tarfile.open(fileobj=reader, mode='r|xz') as bundle:
        for member in bundle:
            if selected(member.name):
                expanded += member.size
                if expanded > 4 * 1024**3 or shutil.disk_usage(ROOT).free < 512 * 1024**2:
                    raise RuntimeError('SDK extraction exceeded disk budget')
                bundle.extract(member, ROOT, filter='data')
                if member.isfile():
                    files.append({'path': member.name, 'bytes': member.size})
            if time.monotonic() - last > 20:
                print(json.dumps({'downloaded_bytes': reader.total,
                                  'expanded_bytes': expanded}), flush=True)
                last = time.monotonic()
    while reader.read(8 * 1024 * 1024):
        pass
    actual = reader.digest.hexdigest()
    if actual != SHA256:
        raise RuntimeError('Official SDK checksum mismatch: ' + actual)
record = {'url': URL, 'sha256': actual, 'bytes': reader.total,
          'published_checksum_verified': True, 'extracted_bytes': expanded,
          'framework_revision': '737ba8f885dc774b53b442759999a312c9461e4e',
          'version': '3.47.8', 'dart_version': '3.13.7',
          'selection': 'Full Dart SDK, Linux debug engine, framework and tools; unused mobile/desktop engines and framework tests omitted.'}
(ROOT / 'sdk-provenance.json').write_text(json.dumps(record, indent=2) + '\n')
(ROOT / 'sdk-members.json').write_text(json.dumps(files, indent=2) + '\n')
print(json.dumps(record), flush=True)
