#!/usr/bin/env python3
"""Restore exact Pub archives and resolve the unmodified full workspace."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile
import urllib.parse
import urllib.request
import yaml

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'quds_office_suite'
SDK = ROOT / 'flutter'
CACHE = ROOT.parent / '.runtime/pub-cache'
for p in [ROOT / x for x in ['logs', 'bin', 'tmp', 'config', 'cache', 'data']]:
    p.mkdir(parents=True, exist_ok=True)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


lock_before = sha(REPO / 'pubspec.lock')
record = {'started_at_utc': datetime.now(timezone.utc).isoformat(),
          'status': 'running', 'workspace': str(REPO), 'runs': [],
          'lockfile_before': lock_before}


def save():
    (ROOT / 'runtime-provenance.json').write_text(json.dumps(record, indent=2) + '\n')


env = dict(os.environ,
           PUB_CACHE=str(CACHE), FLUTTER_ROOT=str(SDK), CI='true',
           DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true',
           DASH__SUPPRESS_ANALYTICS='true',
           XDG_CONFIG_HOME=str(ROOT / 'config'),
           XDG_CACHE_HOME=str(ROOT / 'cache'),
           XDG_DATA_HOME=str(ROOT / 'data'), TMPDIR=str(ROOT / 'tmp'))


def run(name, argv, cwd):
    print('START ' + name, flush=True)
    log = ROOT / 'logs' / (name + '.log')
    started = datetime.now(timezone.utc).isoformat()
    with log.open('wb') as stream:
        result = subprocess.run([str(x) for x in argv], cwd=cwd, env=env,
                                stdout=stream, stderr=subprocess.STDOUT,
                                timeout=300)
    record['runs'].append({'name': name, 'command': [str(x) for x in argv],
                          'cwd': str(cwd), 'exit_code': result.returncode,
                          'started_at_utc': started,
                          'finished_at_utc': datetime.now(timezone.utc).isoformat(),
                          'log': str(log), 'log_sha256': sha(log)})
    save()
    print('END ' + name + ' exit=' + str(result.returncode), flush=True)
    if result.returncode:
        raise RuntimeError(name + ': ' + log.read_text(errors='replace')[-8000:])
    return log


try:
    save()
    archive = json.loads((ROOT / 'sdk-provenance.json').read_text())
    assert archive['published_checksum_verified']
    record['sdk'] = archive
    workspace = yaml.safe_load((REPO / 'pubspec.yaml').read_text())['workspace']
    missing = [x for x in workspace if not (REPO / x / 'pubspec.yaml').is_file()]
    if missing:
        raise RuntimeError('Missing workspace packages: ' + ', '.join(missing))
    packages = {}
    for lock in [SDK / 'packages/flutter_tools/pubspec.lock', REPO / 'pubspec.lock']:
        for name, item in yaml.safe_load(lock.read_text())['packages'].items():
            if item['source'] != 'hosted':
                continue
            info = item['description']
            if info['url'] != 'https://pub.dev':
                raise RuntimeError('Unexpected package host')
            key = name + '-' + item['version']
            value = {'name': name, 'version': item['version'], 'sha256': info['sha256']}
            if key in packages and packages[key] != value:
                raise RuntimeError('Conflicting package hashes: ' + key)
            packages[key] = value
    for p in [CACHE / '_temp', CACHE / 'hosted/pub.dev', CACHE / 'hosted-hashes/pub.dev']:
        p.mkdir(parents=True, exist_ok=True)

    def fetch(pair):
        key, item = pair
        target = CACHE / 'hosted/pub.dev' / key
        mark = CACHE / 'hosted-hashes/pub.dev' / (key + '.sha256')
        if (target / 'pubspec.yaml').is_file() and mark.is_file() and mark.read_text().strip() == item['sha256']:
            return dict(item, cache_hit=True)
        url = 'https://pub.dev/api/archives/' + urllib.parse.quote(key, safe='-._+') + '.tar.gz'
        with urllib.request.urlopen(url, timeout=60) as response:
            data = response.read()
        actual = hashlib.sha256(data).hexdigest()
        if actual != item['sha256']:
            raise RuntimeError('Package hash mismatch: ' + key)
        target.mkdir(exist_ok=True)
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as bundle:
            bundle.extractall(target, filter='data')
        mark.write_text(actual)
        return dict(item, url=url, bytes=len(data), verified=True)

    print('Restoring ' + str(len(packages)) + ' locked Pub packages', flush=True)
    with ThreadPoolExecutor(max_workers=12) as pool:
        receipts = list(pool.map(fetch, sorted(packages.items())))
    (ROOT / 'pub-cache-receipt.json').write_text(json.dumps(receipts, indent=2) + '\n')
    record['hosted_archives'] = len(receipts)
    dart = SDK / 'bin/cache/dart-sdk/bin/dart'
    tester = SDK / 'bin/cache/artifacts/engine/linux-x64/flutter_tester'
    expected = {str(dart): '01e869e4af277734b02ab8898b870c6b00c9bec61bbcf9c923cd14de7ed85fbb',
                str(tester): '800f4ca182df7dd2fb46a42dea5d76277b9dbc5e8cd2915e02bcbc978681b45f'}
    for path, digest in expected.items():
        if sha(path) != digest:
            raise RuntimeError('Executable hash mismatch: ' + path)
    record['executables_sha256'] = expected
    run('flutter-tools-pub-get', [dart, 'pub', 'get', '--offline', '--enforce-lockfile'], SDK / 'packages/flutter_tools')
    flutter = ROOT / 'bin/flutter'
    flutter.write_text('#!/bin/sh\nexec ' + shlex.quote(str(dart)) + ' ' +
                       shlex.quote(str(SDK / 'bin/cache/flutter_tools.snapshot')) +
                       ' --no-version-check "$@"\n')
    flutter.chmod(0o755)
    dart_wrapper = ROOT / 'bin/dart'
    dart_wrapper.write_text('#!/bin/sh\nexec ' + shlex.quote(str(dart)) + ' "$@"\n')
    dart_wrapper.chmod(0o755)
    env['PATH'] = str(ROOT / 'bin') + ':' + env.get('PATH', '')
    keys = ['PUB_CACHE', 'FLUTTER_ROOT', 'CI', 'DART_SUPPRESS_ANALYTICS',
            'FLUTTER_SUPPRESS_ANALYTICS', 'DASH__SUPPRESS_ANALYTICS',
            'XDG_CONFIG_HOME', 'XDG_CACHE_HOME', 'XDG_DATA_HOME', 'TMPDIR']
    (ROOT / 'env.sh').write_text(''.join('export ' + k + '=' + shlex.quote(env[k]) + '\n' for k in keys) +
                               'export PATH=' + shlex.quote(str(ROOT / 'bin')) + ':"$PATH"\n')
    run('workspace-pub-get', [dart, 'pub', 'get', '--offline', '--enforce-lockfile'], REPO)
    version = run('flutter-version', [flutter, '--version', '--machine'], REPO)
    record['version'] = json.loads(version.read_text())
    if record['version']['frameworkRevision'] != '737ba8f885dc774b53b442759999a312c9461e4e' or record['version']['dartSdkVersion'] != '3.13.7':
        raise RuntimeError('Unexpected SDK identity')
    record['lockfile_after'] = sha(REPO / 'pubspec.lock')
    assert record['lockfile_after'] == lock_before, 'Tracked lock changed'
    record['package_count'] = len(json.loads((REPO / '.dart_tool/package_config.json').read_text())['packages'])
    record['environment_script'] = str(ROOT / 'env.sh')
    record['status'] = 'ready'
except BaseException as error:
    record['status'] = 'failed'
    record['error'] = repr(error)
    raise
finally:
    record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps({'status': record['status'], 'error': record.get('error')}), flush=True)
