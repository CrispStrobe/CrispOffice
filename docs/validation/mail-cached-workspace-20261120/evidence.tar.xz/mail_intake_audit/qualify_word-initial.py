#!/usr/bin/env python3
"""Independent local qualification of incoming Word outline/list-level source."""
from __future__ import annotations

import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from urllib.parse import urljoin, unquote, urlsplit

ROOT = Path('/workspace/scratch/6e376c6dad91/quds_office_suite')
ENGINE = ROOT / 'packages/quds_office_engine'
RUNTIME = ROOT.parent / 'runtime'
BASE = 'bb5320a50f288d95844a6d60cfd72eab13a9befc'
INCOMING = '3c87debcd4d50cac88981ec39255c3c6890fe8fa'
sys.path.insert(0, str(ROOT / 'tools/mail'))
from check_store import execute, test_summary

TESTS = [
    'office_macro_word_list_levels_test.dart',
    'office_vba_word_list_levels_test.dart',
    'office_vba_word_list_levels_integration_test.dart',
    'office_macro_word_list_format_test.dart',
    'office_vba_word_lists_test.dart',
    'office_vba_word_lists_integration_test.dart',
    'office_macro_word_tab_stops_test.dart',
    'office_vba_word_tabstops_test.dart',
    'office_vba_word_tabstops_integration_test.dart',
    'style_cascade_test.dart',
    'numbering_collision_test.dart',
    'word_styles_layout_test.dart',
    'word_style_introduction_test.dart',
    'word_referenced_styles_and_breaks_test.dart',
    'word_list_numbering_snapshot_test.dart',
    'list_restart_fidelity_test.dart',
    'word_package_preservation_test.dart',
    'word_compatibility_fidelity_test.dart',
    'odt_list_fidelity_test.dart',
]

def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inputs() -> dict[str, dict[str, str]]:
    names = git('ls-files', '-z', '--', 'packages/quds_office_engine',
                'packages/legacy_doc_parser', 'pubspec.yaml', 'pubspec.lock',
                '.fvmrc', '.cursorrules', 'CONTRIBUTING.md', 'analysis_options.yaml',
                'tools/mail/check_store.py').split('\0')
    result = {}
    for name in names:
        if not name or not (ROOT / name).is_file():
            continue
        entry = git('ls-files', '-s', '--', name).split()
        result[name] = {'sha256': sha(ROOT / name), 'git_blob': entry[1], 'mode': entry[0]}
    return result

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--phase', choices=('tests', 'portable-static', 'all'), default='all')
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    dart = RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'
    config = ROOT / '.dart_tool/package_config.json'
    packages = json.loads(config.read_text())['packages']
    test_package = next(item for item in packages if item['name'] == 'test')
    test_uri = urlsplit(urljoin(config.as_uri(), test_package['rootUri']))
    assert test_uri.scheme == 'file' and not test_uri.netloc
    test_entry = Path(unquote(test_uri.path)) / 'bin/test.dart'
    assert test_entry.is_file()
    changed = [path for path in git('diff', '--name-only', BASE, INCOMING).splitlines()
               if path.endswith('.dart')]
    bas = ENGINE / 'example/macros/word_list_levels.bas'
    define = '-DWORD_LIST_LEVELS_BAS_BASE64=' + base64.b64encode(bas.read_bytes()).decode()
    driver = 'tool/macros/web_vba_word_list_levels_smoke.dart'
    commands = []
    if args.phase in ('tests', 'all'):
        commands.append(('word-regression', [str(dart), '--packages=' + str(config), str(test_entry),
                        '--compiler=kernel', '--timeout=120s', '--concurrency=2', '--reporter=json',
                        *['test/' + path for path in TESTS]], ENGINE, True))
    if args.phase in ('portable-static', 'all'):
        commands += [
            ('word-analysis', [str(dart), 'analyze', '--fatal-infos', 'lib/src/automation',
                               'lib/src/word/serial/word_style_cascade.dart',
                               *[str(ROOT / p) for p in changed if '/test/' in p or '/tool/' in p]], ENGINE, False),
            ('word-format', [str(dart), 'format', '--output=none', '--set-exit-if-changed',
                            *[str(ROOT / path) for path in changed]], ROOT, False),
            ('word-levels-vm', [str(dart), '--packages=' + str(config), define, driver], ENGINE, False),
            ('word-levels-js-compile', [str(dart), 'compile', 'js', '--packages=' + str(config), define,
                                      driver, '-o', str(output / 'word-list-levels.js')], ENGINE, False),
            ('word-levels-node', ['node', str(output / 'word-list-levels.js')], ENGINE, False),
        ]
    receipt = dict(status='RUNNING', phase=args.phase, started_at=datetime.now(timezone.utc).isoformat(),
                   source_commit=git('rev-parse', 'HEAD'), source_tree=git('rev-parse', 'HEAD^{tree}'),
                   incoming_source=INCOMING, selected_test_files=TESTS,
                   source_before=inputs(), github_actions='NOT QUERIED OR AWAITED', checks=[],
                   runtime={'dart': str(dart), 'dart_sha256': sha(dart),
                            'dart_version': subprocess.check_output([str(dart), '--version'], text=True).strip(),
                            'node_version': subprocess.check_output(['node', '--version'], text=True).strip(),
                            'package_config': str(config), 'package_config_sha256': sha(config),
                            'test_entry': str(test_entry), 'test_entry_sha256': sha(test_entry),
                            'bas_sha256': sha(bas), 'runner_sha256': sha(Path(__file__))})
    receipt_file = output / 'receipt.json'
    def save():
        receipt_file.write_text(json.dumps(receipt, indent=2) + '\n')
    save()
    accepted = True
    try:
        for name, command, cwd, tests in commands:
            print(name, flush=True)
            log = output / (name + ('.jsonl' if tests else '.stdout'))
            stderr = output / (name + '.stderr')
            check = dict(name=name, command=command, cwd=str(cwd), status='RUNNING',
                         timeout_seconds=900, log=log.name, stderr=stderr.name)
            receipt['checks'].append(check)
            save()
            with log.open('wb') as stdout_stream, stderr.open('wb') as error_stream:
                check['exit_code'] = execute(command, cwd=cwd, env=dict(os.environ),
                                             stdout=stdout_stream, stderr=error_stream, timeout=900)
            okay = check['exit_code'] == 0
            if tests:
                summary = test_summary(log)
                (output / (name + '-cases.json')).write_text(json.dumps(summary, indent=2) + '\n')
                check['summary'] = {key:value for key,value in summary.items() if key != 'cases'}
                okay = okay and bool(summary['valid'])
            check['log_sha256'] = sha(log)
            check['stderr_sha256'] = sha(stderr)
            check['status'] = 'PASS' if okay else 'FAIL'
            accepted = accepted and okay
            save()
        if args.phase in ('portable-static', 'all'):
            vm = (output / 'word-levels-vm.stdout').read_bytes()
            node = (output / 'word-levels-node.stdout').read_bytes()
            receipt['portable_raw_equal'] = vm == node
            try:
                receipt['portable_json_equal'] = json.loads(vm) == json.loads(node)
            except (ValueError, UnicodeError):
                receipt['portable_json_equal'] = False
            accepted = accepted and receipt['portable_raw_equal'] and receipt['portable_json_equal']
        receipt['status'] = 'PASS' if accepted else 'FAIL'
    except (Exception, KeyboardInterrupt) as error:
        receipt['status'] = 'FAIL'
        receipt['error'] = f'{type(error).__name__}: {error}'
    finally:
        receipt['source_after'] = inputs()
        receipt['source_unchanged'] = receipt['source_before'] == receipt['source_after']
        receipt['runtime_configuration_unchanged'] = sha(config) == receipt['runtime']['package_config_sha256']
        if not receipt['source_unchanged'] or not receipt['runtime_configuration_unchanged']:
            receipt['status'] = 'FAIL'
        receipt['finished_at'] = datetime.now(timezone.utc).isoformat()
        save()
    print(receipt['status'], flush=True)
    return 0 if receipt['status'] == 'PASS' else 1

if __name__ == '__main__':
    raise SystemExit(main())
