#!/usr/bin/env python3
"""Qualify the independent native-host scenarios with exact source receipts."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time


ROOT = Path('/workspace/scratch/6e376c6dad91')
REPO = ROOT / 'quds_office_suite'
EXAMPLE = REPO / 'packages/quds_office_editor/example'
FLUTTER = ROOT / 'runtime/flutter/bin/flutter'
DART = ROOT / 'runtime/flutter/bin/cache/dart-sdk/bin/dart'
TEST = 'test/studio_mail_cached_host_test.dart'


def inputs():
    files = set()
    for package in ('core', 'mime', 'transport', 'store', 'ui'):
        files.update((REPO / f'packages/quds_mail_{package}/lib').rglob('*'))
    files.update((EXAMPLE / 'lib').glob('studio_mail*.dart'))
    files.update((EXAMPLE / 'test/support').rglob('*'))
    files.update([
        EXAMPLE / TEST, EXAMPLE / 'lib/studio_strings.dart',
        REPO / 'pubspec.yaml', REPO / 'pubspec.lock',
        REPO / '.dart_tool/package_config.json', EXAMPLE / 'pubspec.yaml',
    ])
    return {
        str(path.relative_to(REPO)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(files) if path.is_file()
    }


def run(label, args, output):
    started = time.time()
    with (output / f'{label}.stdout').open('w') as stdout:
        with (output / f'{label}.stderr').open('w') as stderr:
            result = subprocess.run(
                args, cwd=EXAMPLE, stdout=stdout, stderr=stderr, check=False,
            )
    return {
        'command': args, 'cwd': str(EXAMPLE), 'exit_code': result.returncode,
        'seconds': round(time.time() - started, 3),
        'stdout': f'{label}.stdout', 'stderr': f'{label}.stderr',
    }


def count_report(path):
    tests = {}
    results = {}
    errors = []
    for line in path.read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get('type') == 'testStart':
            tests[event['test']['id']] = event['test']
        elif event.get('type') == 'testDone':
            results[event['testID']] = event
        elif event.get('type') == 'error':
            errors.append(event)
    cases = []
    for test_id, event in results.items():
        name = tests.get(test_id, {}).get('name', '')
        if event.get('hidden') or name.startswith('loading '):
            continue
        cases.append({
            'name': name, 'result': event['result'],
            'skipped': event.get('skipped', False),
        })
    return {
        'passed': sum(x['result'] == 'success' and not x['skipped'] for x in cases),
        'failed': sum(x['result'] != 'success' for x in cases),
        'skipped': sum(x['skipped'] for x in cases),
        'errors': len(errors), 'cases': cases,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', required=True)
    parser.add_argument('--name')
    parser.add_argument('--expected', type=int, default=28)
    args = parser.parse_args()
    output = ROOT / 'mail_intake_audit' / args.label
    output.mkdir(exist_ok=False)
    before = inputs()
    (output / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
    command = [str(FLUTTER), 'test', '--no-pub', '--concurrency=1', '--reporter=json']
    if args.name:
        command += ['--name', args.name]
    command.append(TEST)
    checks = {'tests': run('tests', command, output)}
    checks['analysis'] = run('analysis', [str(DART), 'analyze', '--fatal-infos', TEST], output)
    checks['format'] = run('format', [str(DART), 'format', '--output=none',
                                   '--set-exit-if-changed', TEST], output)
    after = inputs()
    (output / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    counts = count_report(output / 'tests.stdout')
    summary = {
        'scope': 'native-host cache integration; injected typed providers, actual file-backed SQLite',
        'checks': checks, 'counts': counts, 'expected_cases': args.expected,
        'source_files': len(before), 'source_unchanged': before == after,
        'changed_paths': sorted(path for path in before.keys() | after.keys()
                                if before.get(path) != after.get(path)),
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
        'success': all(check['exit_code'] == 0 for check in checks.values())
                   and before == after and counts['passed'] == args.expected
                   and not counts['errors']
                   and not counts['failed'] and not counts['skipped'],
    }
    (output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({key: value for key, value in summary.items()
                      if key not in ('checks', 'counts')}, indent=2), flush=True)
    print(json.dumps({key: value for key, value in counts.items() if key != 'cases'}), flush=True)
    raise SystemExit(0 if summary['success'] else 1)


if __name__ == '__main__':
    main()
