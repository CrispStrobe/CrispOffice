"""Read-only Git-object verification of the incoming Word evidence checkpoint."""
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

REPO = Path('/workspace/scratch/6e376c6dad91/quds_office_suite')
OUTPUT = Path('/workspace/scratch/6e376c6dad91/mail_intake_audit/word_checkpoint_delta_review.json')
OLD = '3c87debcd4d50cac88981ec39255c3c6890fe8fa'
NEW = '273d78f54d2d4448c25791060eb41ae65e3d3674'
PREFIX = 'docs/validation/word-vba-list-levels-20261120/'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def tree(commit):
    result = {}
    for record in git('ls-tree', '-r', '-z', commit).split(b'\0'):
        if not record:
            continue
        metadata, path = record.split(b'\t', 1)
        mode, kind, blob = metadata.decode().split()
        result[path.decode()] = {'mode': mode, 'type': kind, 'blob': blob}
    return result


def main():
    current = git('rev-parse', 'HEAD').decode().strip()
    old_tree, new_tree, current_tree = map(tree, [OLD, NEW, current])
    changed = {
        path for path in old_tree.keys() | new_tree.keys()
        if old_tree.get(path) != new_tree.get(path)
    }
    expected_changed = {
        PREFIX + 'README.md', PREFIX + 'word-gates-checkpoint.json',
        PREFIX + 'word-gates-checkpoint.tar.xz',
    }
    assert changed == expected_changed, changed
    assert subprocess.run(['git', 'merge-base', '--is-ancestor', OLD, NEW], cwd=REPO).returncode == 0
    manifest_bytes = git('show', NEW + ':' + PREFIX + 'word-gates-checkpoint.json')
    manifest = json.loads(manifest_bytes)
    archive = git('show', NEW + ':' + PREFIX + manifest['archive']['file'])
    assert manifest['archive']['identity'] == {'bytes': len(archive), 'sha256': sha(archive)}
    expected = {m['path']: m for m in manifest['archive']['members']}
    assert len(expected) == len(manifest['archive']['members']) == 83
    members = {}
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r|xz') as stream:
        for item in stream:
            assert item.isfile() and item.name not in members and item.size < 64 * 1024 * 1024
            assert not item.name.startswith('/') and '..' not in Path(item.name).parts
            data = stream.extractfile(item).read()
            record = expected[item.name]
            assert len(data) == item.size == record['bytes']
            assert sha(data) == record['sha256'] and f'{item.mode:04o}' == record['mode']
            members[item.name] = data
    assert members.keys() == expected.keys() and len(members) == manifest['archive']['member_count']

    def read(path):
        data = members[path]
        return json.loads(gzip.decompress(data) if path.endswith('.gz') else data)

    stage_names = ['word-office-final', 'list-level-final-checks', 'list-level-portable-final']
    stages = {}
    source = None
    for stage in stage_names:
        before = read(f'runtime/{stage}/inputs-before.json.gz')
        after = read(f'runtime/{stage}/inputs-after.json.gz')
        assert before['entries'] == after['entries']
        assert before['runtime_inputs'] == after['runtime_inputs']
        assert before['head_matches_worktree'] and after['head_matches_worktree']
        for record in [before, after]:
            assert record['source_commit'] == OLD
            assert record['source_tree'] == git('rev-parse', OLD + '^{tree}').decode().strip()
        source = source or before['entries']
        assert source == before['entries'] and len(source) == 1123
        stages[stage] = {
            'source_entries': len(source),
            'source_before_after_equal': True,
            'runtime_before_after_equal': True,
            'recorded_runtime_inputs': len(before['runtime_inputs']),
        }

    batch = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=REPO,
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    verified = {}
    try:
        for path, record in source.items():
            assert old_tree[path] == new_tree[path] == current_tree[path] == record['head'], path
            assert record['worktree_blob'] == record['head']['blob']
            assert record['worktree_mode'] == record['head']['mode']
            blob = record['head']['blob']
            if blob not in verified:
                batch.stdin.write((blob + '\n').encode())
                batch.stdin.flush()
                actual_blob, kind, size = batch.stdout.readline().decode().split()
                assert actual_blob == blob and kind == 'blob'
                data = batch.stdout.read(int(size))
                assert batch.stdout.read(1) == b'\n'
                verified[blob] = {'bytes': len(data), 'sha256': sha(data)}
            assert verified[blob] == {'bytes': record['bytes'], 'sha256': record['sha256']}, path
    finally:
        batch.stdin.close()
        batch.wait()
    assert batch.returncode == 0

    regression = read('runtime/word-office-final/summary.json')
    cases = read('runtime/word-office-final/cases.json.gz')
    events = [json.loads(line) for line in members['runtime/word-office-final/stdout.jsonl'].splitlines()]
    starts = {e['test']['id']: e['test'] for e in events if e['type'] == 'testStart'}
    finishes = [e for e in events if e['type'] == 'testDone' and not e.get('hidden')]
    by_id = {e['testID']: e for e in finishes}
    assert len(cases) == len(finishes) == len(by_id) == 2569
    assert len({(c['file'], c['name'], c['occurrence']) for c in cases}) == len(cases)
    assert not any(e['type'] == 'error' for e in events)
    terminal = [e for e in events if e['type'] == 'done']
    assert len(terminal) == 1 and terminal[0]['success'] is True and events[-1] == terminal[0]
    for case in cases:
        finish = by_id[case['test_id']]
        assert finish['result'] == case['result'] == 'success'
        assert not finish['skipped'] and not case['skipped']
        assert starts[case['test_id']]['name'] == case['file'] + ' ' + case['name']
    per_file = dict(Counter(c['file'] for c in cases))
    assert len(per_file) == regression['file_count'] == manifest['regression']['modules'] == 70
    assert per_file == regression['per_file_cases'] == regression['declared_per_file_cases']
    assert regression['passing_cases'] == manifest['regression']['passing_cases'] == 2569
    assert regression['failed_cases'] == regression['skipped_cases'] == 0
    assert regression['accepted'] and regression['complete'] and not regression['problems']

    for stage in stage_names:
        summary = read(f'runtime/{stage}/summary.json')
        for name, identity in summary.get('hashes', {}).items():
            data = members[f'runtime/{stage}/{name}']
            if isinstance(identity, str):
                assert sha(data) == identity
            else:
                assert {'bytes': len(data), 'sha256': sha(data)} == identity
    checks = read('runtime/list-level-final-checks/summary.json')
    assert checks['qualified'] and checks['analysis_clean'] and checks['formatting_clean']
    assert checks['formatted_file_count'] == manifest['formatted_files'] == 9
    portable = read('runtime/list-level-portable-final/summary.json')
    vm = members['runtime/list-level-portable-final/vm.stdout']
    node = members['runtime/list-level-portable-final/node.stdout']
    canonical = members['runtime/list-level-portable-final/result.json']
    assert vm == node and len(vm) == portable['raw_output_bytes'] == manifest['raw_output_bytes'] == 1553
    assert sha(vm) == portable['raw_output_sha256']
    assert sha(canonical) == portable['canonical_sha256'] == manifest['canonical_sha256']
    assert json.loads(vm) == json.loads(canonical)
    assert portable['qualified'] and portable['commands_succeeded']
    assert all(command['exit_code'] == 0 for command in portable['commands'])
    review = read('runtime/list-level-review/evidence-review.json')
    assert review['accepted'] and not review['problems']

    report = {
        'status': 'PASS', 'reviewed_utc': datetime.now(timezone.utc).isoformat(),
        'method': 'Independent read-only Git-object and archive/event parsing; no archive scripts executed, no checkout or source edits, no test reruns.',
        'base': OLD, 'incoming': NEW, 'current_feature_head_at_review': current,
        'changed_paths': sorted(changed), 'source_neutral_delta': True,
        'archive': {'bytes': len(archive), 'sha256': sha(archive), 'members': len(members),
                    'all_paths_modes_sizes_hashes_match': True, 'uncompressed_bytes': sum(map(len, members.values()))},
        'manifest_sha256': sha(manifest_bytes),
        'word_source_inputs': {'count': len(source), 'all_match_base_incoming_current_git_objects': True,
                               'all_bytes_sha256_modes_match': True},
        'captured_before_after_inputs': stages,
        'raw_regression': {'cases': len(cases), 'modules': len(per_file), 'failures': 0, 'skips': 0,
                           'terminal_success': True, 'all_case_ids_names_and_per_file_counts_match': True},
        'portable': {'vm_node_bytes_equal': True, 'bytes': len(vm), 'sha256': sha(vm),
                     'canonical_sha256': sha(canonical), 'result_objects_equal': True},
        'analysis_and_format_records_consistent': True,
        'retained_scope_limits': [regression['isolation_difference'], manifest['scope'],
                                  'Archived runtime file identities were checked for internal consistency; the other workspace runtime was not accessed or rerun.'],
        'no_additional_store_or_word_run_required_by_this_delta': True,
        'script_sha256': sha(Path(__file__).read_bytes()),
    }
    OUTPUT.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
