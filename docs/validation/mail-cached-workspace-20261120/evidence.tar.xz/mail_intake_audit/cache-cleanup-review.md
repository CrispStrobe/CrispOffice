# Independent cache cleanup and revision-counter review

## Outcome

One confirmed recovery defect was found, reproduced against the frozen source,
and corrected by the store author. The focused post-correction probe passes.
No additional confirmed defect remains in the reviewed cleanup and global
mailbox-view revision paths.

This was a source review plus a narrow native SQLite reproduction, not another
run of the full store suite. The store author's final regression receipts remain
the authority for that broader execution coverage.

## Confirmed defect and correction

`clearMailboxCache` originally called the same body eviction helper as ordinary
cache eviction. That helper transferred and decoded the retained header envelope
to rebuild header search. Its metadata budget checks could reject valid content
written under a formerly larger limit, preventing the recovery action itself.

The reproduction uses an actual native SQLite file:

1. Save a visited folder and cached body whose valid subject contains 4,096
   characters, under the default 2,097,152-unit metadata limit.
2. Close and reopen with `maxMetadataCodeUnits: 64` and `maxAccountBytes: 1`.
3. Call `clearMailboxCache` with its ordinary default bounds.
4. Observe `quotaExceeded`; a subsequent normal-limit reopen still contains both
   the view and body because the transaction rolled back.

The author changed the explicit cleanup path to evict without admitting or
decoding old header envelopes. It removes the disposable cache search/index
state; authoritative headers retained by sync memberships or pending operations
remain available for later explicit reindexing or synchronization. Ordinary
`evictCache` retains its existing header-search behavior.

The corrected probe repeats the same setup and now observes a successful clear,
with neither the cached view nor body present after normal-limit reopen.

Evidence is retained in:

- `cleanup_lowered_metadata_probe.dart` and
  `cleanup-lowered-metadata-probe.stdout/.stderr` — original confirmed defect.
- `cleanup_lowered_metadata_fixed_probe.dart` and
  `cleanup-lowered-metadata-fixed-probe.stdout/.stderr` — same inputs with the
  corrected outcome asserted.

The focused probes are diagnostic evidence, not additional unique cases in the
store author's regression count.

## Reviewed invariants

### Atomic rollback

Cleanup runs through `_write`, which wraps the entire operation in `_commit` and
one Drift transaction. The `beforeCommit` fault remains inside that transaction;
domain notifications occur only after commit. Folder views and their cascaded
members, cached body rows, cache-owned blob references, disposable search state,
unreferenced headers, and unused blobs therefore commit or roll back together.
The existing failure regression also closes and reopens the file before checking
that the original view revision, body bytes and search result survived.

### Recovery without a new quota admission

The corrected cleanup path does not call `_quota`, load body/attachment payloads,
decode old envelopes, or rebuild their search text. It can therefore remove
automatic cache content after the account or metadata budget has been lowered.
It still validates the account scope, explicit batch bound and bounded ID types
and lengths; malformed storage can produce an explicit storage failure.

### Preservation and scope

Every selection and mutation is account-scoped after profile validation.
Cleanup does not modify drafts, Outbox entries/attempts, account credentials,
pending-operation records, folder definitions, sync cursors, authoritative
memberships or tombstones. Header deletion excludes sync memberships, remaining
browse memberships, retained cached bodies/cache refs, and queued/applying/
reconcile operations.

The editor-pin predicate protects a cached body if any of its cache-owned blob
hashes has a same-account pin. Removing cache refs cannot remove a blob still
referenced by a draft, Outbox entry or pin because blob collection requires the
absence of every reference. Other accounts are excluded by the predicates.
Successful cleanup intentionally removes the evicted cache's search/index state;
it does not promise to preserve that disposable index.

### Bounded progress and completion

Each successful call removes at most `limit` views, `limit` unpinned bodies and
`limit` expendable headers. Surviving browse memberships protect their headers
until the corresponding view batch is removed. `hasMore` checks the same
eligible categories after all deletions. Pinned bodies are counted separately
and do not keep `hasMore` true indefinitely. Repeating cleanup after eligible
work is gone is idempotent.

These are bounded row-category and metadata-transfer guarantees. SQL scans,
foreign-key cascades, FTS maintenance and blob collection are not a promise of a
fixed wall-clock duration or a fixed number of physical SQLite page writes.

### Clear/recreate stale CAS

The new `store_profile.mailbox_view_revision` counter survives cleanup. Each
successful save checks the current folder revision against the supplied CAS,
validates the global counter, then advances the counter and writes the new view
within the same transaction. Failed writes roll back the increment. Recreating a
cleared folder receives a later revision even after restart and at an identical
timestamp; a prior non-null folder revision cannot become valid again.

The schema bounds the counter and view revisions to exact safe integer values
through 9,007,199,254,740,991. Exhaustion fails explicitly before writing.
Creation and upgrades from released schema versions 1–4 add the counter and new
view tables in the migration transaction. Released schema definitions remain
unchanged. A null expected revision continues to mean that the folder currently
has no retained view, as documented by the API.

## Limits

This review did not repeat the broad native/browser regression suites or add a
new process-kill campaign. It does not establish browser-storage behavior,
installed-platform operation, live-provider interoperability, recovery from every
possible externally corrupted database, or successful writes when the physical
filesystem cannot support a SQLite transaction. The repository's exclusive-owner
contract remains part of the concurrency assumptions.

The exact reviewed source fingerprints and probe commands are recorded in
`cache-cleanup-review-receipt.json`.
