"""Independently audit the final incoming Word evidence from Git objects only."""
from collections import Counter
from datetime import datetime, timezone
import gzip
import io
import json
from pathlib import Path
import subprocess
import tarfile

from verify_word_checkpoint_delta import REPO, git, sha, tree

BASE = '273d78f54d2d4448c25791060eb41ae65e3d3674'
FROZEN = '3c87debcd4d50cac88981ec39255c3c6890fe8fa'
BRANCH = 'fff4a4afda2beecdd20ae0bd1f3c31622e8c0b37'
MAIN = '3ee4e3622c9a2198d384ed1cb296ab092a8838d0'
FEATURE = '3730a4b9bc431e9ae313255d408b6fc266a9280e'
MERGE_TREE = 'f7eada34fdbc35e4c6083c9d8d50fc1943cee6b6'
PREFIX = 'docs/validation/word-vba-list-levels-20261120/'
OUTPUT = Path(__file__).with_name('word_final_delta_review.json')


def main():
    current = git('rev-parse', 'HEAD').decode().strip()
    trees = {ref: tree(ref) for ref in [BASE, FROZEN, BRANCH, MAIN, FEATURE, MERGE_TREE, current]}
    changed = {
        path for path in trees[BASE].keys() | trees[MAIN].keys()
        if trees[BASE].get(path) != trees[MAIN].get(path)
    }
    assert len(changed) == 23 and all(path.startswith(PREFIX) for path in changed)
    assert trees[BRANCH] == trees[MAIN], 'Merged main is not the published Word tree'
    merge_delta = {
        path for path in trees[FEATURE].keys() | trees[MERGE_TREE].keys()
        if trees[FEATURE].get(path) != trees[MERGE_TREE].get(path)
    }
    assert merge_delta == changed, 'Expected Mail merge modifies more than Word evidence'
    for parent in [BASE, FROZEN, BRANCH]:
        assert subprocess.run(['git', 'merge-base', '--is-ancestor', parent, MAIN], cwd=REPO).returncode == 0

    files = {
        path[len(PREFIX):]: git('cat-file', 'blob', identity['blob'])
        for path, identity in trees[MAIN].items() if path.startswith(PREFIX)
    }
    file_index = json.loads(files['evidence-files.json'])
    assert set(files) == set(file_index['files']) | {file_index['excluded_self']}
    assert all('/' not in name and not name.startswith('.') for name in files)
    for name, record in file_index['files'].items():
        assert record == {'bytes': len(files[name]), 'sha256': sha(files[name])}, name
    archives = json.loads(files['archive-members.json'])['archives']
    members = {}
    archive_results = {}
    for name, index in archives.items():
        data = files[name]
        assert index['identity'] == {'bytes': len(data), 'sha256': sha(data)}
        expected = {entry['path']: entry for entry in index['members']}
        assert len(expected) == len(index['members']) == index['member_count']
        actual = {}
        with tarfile.open(fileobj=io.BytesIO(data), mode='r|xz') as stream:
            for member in stream:
                assert member.isfile() and member.name not in actual and member.size < 64 * 1024 * 1024
                assert not member.name.startswith('/') and '..' not in Path(member.name).parts
                content = stream.extractfile(member).read()
                record = expected[member.name]
                assert len(content) == member.size == record['bytes']
                assert sha(content) == record['sha256'] and f'{member.mode:04o}' == record['mode']
                if member.name in members:
                    assert members[member.name] == content
                actual[member.name] = members[member.name] = content
        assert actual.keys() == expected.keys()
        archive_results[name] = {
            'bytes': len(data), 'sha256': sha(data), 'members': len(actual),
            'all_paths_modes_sizes_hashes_match': True,
        }

    packaging = json.loads(files['packaging.json'])
    assert len(members) == packaging['selected_input_count'] == 226
    assert sum(map(len, members.values())) == packaging['selected_input_bytes']
    for report, archived in packaging['copied_reports'].items():
        assert files[report] == members[archived], report

    def read(path):
        content = members[path]
        return json.loads(gzip.decompress(content) if path.endswith('.gz') else content)

    inputs = read('runtime/word-office-final/inputs-before.json.gz')['entries']
    assert len(inputs) == 1123
    stages = {}
    for stage in ['word-office-final', 'list-level-final-checks', 'list-level-portable-final']:
        before = read(f'runtime/{stage}/inputs-before.json.gz')
        after = read(f'runtime/{stage}/inputs-after.json.gz')
        assert before['entries'] == after['entries'] == inputs
        assert before['runtime_inputs'] == after['runtime_inputs']
        assert before['source_commit'] == after['source_commit'] == FROZEN
        assert before['source_tree'] == after['source_tree'] == git('rev-parse', FROZEN + '^{tree}').decode().strip()
        stages[stage] = {'source_entries': len(inputs), 'source_before_after_equal': True,
                         'runtime_before_after_equal': True, 'recorded_runtime_inputs': len(before['runtime_inputs'])}

    consistency = json.loads(gzip.decompress(files['source-consistency.json.gz']))
    assert set(consistency['published_inputs']) == set(inputs)
    batch = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=REPO,
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    verified = {}
    try:
        for path, record in inputs.items():
            assert all(trees[ref][path] == record['head'] for ref in trees), path
            assert record['worktree_blob'] == record['head']['blob']
            assert record['worktree_mode'] == record['head']['mode']
            blob = record['head']['blob']
            if blob not in verified:
                batch.stdin.write((blob + '\n').encode())
                batch.stdin.flush()
                actual, kind, size = batch.stdout.readline().decode().split()
                assert actual == blob and kind == 'blob'
                content = batch.stdout.read(int(size))
                assert batch.stdout.read(1) == b'\n'
                verified[blob] = {'bytes': len(content), 'sha256': sha(content)}
            identity = {'bytes': record['bytes'], 'sha256': record['sha256']}
            assert verified[blob] == identity, path
            assert consistency['published_inputs'][path] == record['head'] | identity, path
    finally:
        batch.stdin.close()
        batch.wait()
    assert batch.returncode == 0

    regression = json.loads(files['regression.json'])
    cases = read('runtime/word-office-final/cases.json.gz')
    events = [json.loads(line) for line in members['runtime/word-office-final/stdout.jsonl'].splitlines()]
    starts = {e['test']['id']: e['test'] for e in events if e['type'] == 'testStart'}
    finishes = [e for e in events if e['type'] == 'testDone' and not e.get('hidden')]
    by_id = {e['testID']: e for e in finishes}
    assert len(cases) == len(finishes) == len(by_id) == 2569
    assert len({(c['file'], c['name'], c['occurrence']) for c in cases}) == len(cases)
    assert not any(e['type'] == 'error' for e in events)
    terminal = [e for e in events if e['type'] == 'done']
    assert len(terminal) == 1 and terminal[0]['success'] is True and events[-1] == terminal[0]
    for case in cases:
        finish = by_id[case['test_id']]
        assert finish['result'] == case['result'] == 'success'
        assert not finish['skipped'] and not case['skipped']
        assert starts[case['test_id']]['name'] == case['file'] + ' ' + case['name']
    counts = dict(Counter(case['file'] for case in cases))
    assert counts == regression['per_file_cases'] == regression['declared_per_file_cases']
    assert len(counts) == regression['file_count'] == 70
    assert regression['accepted'] and regression['complete'] and not regression['problems']
    for stage in stages:
        summary = read(f'runtime/{stage}/summary.json')
        for name, identity in summary.get('hashes', {}).items():
            content = members[f'runtime/{stage}/{name}']
            assert sha(content) == (identity if isinstance(identity, str) else identity['sha256'])
            if isinstance(identity, dict):
                assert len(content) == identity['bytes']
    portable = json.loads(files['portable.json'])
    vm = members['runtime/list-level-portable-final/vm.stdout']
    node = members['runtime/list-level-portable-final/node.stdout']
    canonical = files['portable-result.json']
    assert vm == node and len(vm) == portable['raw_output_bytes'] == 1553
    assert sha(vm) == portable['raw_output_sha256']
    assert sha(canonical) == portable['canonical_sha256'] and json.loads(vm) == json.loads(canonical)
    qualification = json.loads(files['qualification.json'])
    for name, identity in qualification['evidence_summaries'].items():
        assert identity == {'bytes': len(files[name]), 'sha256': sha(files[name])}
    assert qualification['qualified_word_engine_source'] and qualification['source_commit'] == FROZEN
    assert qualification['regression']['passing_cases'] == len(cases)
    scope = json.loads(files['publication-scope-review.json'])
    assert scope['scope_review_accepted'] and not scope['problems']
    assert scope['all_initial_heads_included'] and not scope['all_final_heads_included']
    assert len(scope['deferred_ref_entries']) == 2 and not scope['unclassified_uncovered_ref_entries']
    assert qualification['reconciliation']['deferred_ref_entries'] == scope['deferred_ref_entries']
    assert qualification['reconciliation']['raw_audit_exit_code'] == 1
    for entry in scope['deferred_ref_entries']:
        assert subprocess.run(['git', 'merge-base', '--is-ancestor', entry['sha'], FEATURE], cwd=REPO).returncode == 0
    environment = json.loads(files['environment.json'])

    result = {
        'status': 'PASS', 'reviewed_utc': datetime.now(timezone.utc).isoformat(),
        'method': 'Independent Git-object, archive, manifest and raw-event parsing only; no archive code execution, checkout, source edits or test reruns.',
        'base': BASE, 'published_word_branch': BRANCH, 'incoming_main': MAIN,
        'feature_before_integration': FEATURE, 'expected_integration_tree': MERGE_TREE,
        'observed_feature_head': current, 'changed_paths': sorted(changed),
        'source_neutral_delta': True, 'incoming_main_tree_equals_word_branch': True,
        'integration_tree_changes_only_the_same_23_word_evidence_files': True,
        'directory_manifest': {'indexed_files': len(file_index['files']),
                               'all_direct_regular_files_indexed_except_self': True,
                               'all_bytes_and_sha256_match': True},
        'archives': archive_results,
        'final_archive_members': len(members), 'final_archive_member_bytes': sum(map(len, members.values())),
        'copied_reports_match_archived_originals': True,
        'qualified_source': {'count': len(inputs), 'all_git_modes_blobs_bytes_sha256_match': True,
                             'compared_git_objects': list(trees)},
        'recorded_before_after_manifests': stages,
        'raw_regression': {'passed': len(cases), 'modules': len(counts), 'failures': 0, 'skips': 0,
                           'case_ids_names_occurrences_and_counts_match': True, 'terminal_success': True},
        'portable': {'vm_node_identical': True, 'bytes': len(vm), 'sha256': sha(vm),
                     'canonical_sha256': sha(canonical), 'result_objects_equal': True},
        'author_runtime_record': environment,
        'historical_scope': {'explicitly_deferred_refs': scope['deferred_ref_entries'],
                             'raw_audit_exit_code_preserved': 1, 'unclassified_refs': [],
                             'all_deferred_mail_heads_are_feature_ancestors': True},
        'limits': qualification['limits'] + [
            'Other-workspace binaries were not accessed or rerun. Runtime identities are archived records.',
            'The archived source-consistency snapshot targets273d78f5; this review freshly compares the published branch, merged main and proposed integration tree.'
        ],
        'no_store_or_word_rerun_required_by_this_documentation_delta': True,
        'script_sha256': sha(Path(__file__).read_bytes()),
        'helper_sha256': sha(Path(__file__).with_name('verify_word_checkpoint_delta.py').read_bytes()),
    }
    OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in {'author_runtime_record', 'changed_paths'}}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
