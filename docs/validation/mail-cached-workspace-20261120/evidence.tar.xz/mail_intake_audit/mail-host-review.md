# Independent native mailbox host review

Scope: connected IMAP, EWS, Gmail and Microsoft Graph hosts; the optional
`StudioMailMailboxRecords` and `StudioMailMailboxStoreOwner` interfaces;
ownership, identity rebinding, failure handling, and offline reopen through the
actual SQLite draft repository. This review does not claim live-provider,
installed-platform, or browser-storage interoperability.

## Findings and corrections

1. **Independent failure scopes.** A successful body write must not clear a
   previous failed folder snapshot, and a successful snapshot must not clear a
   failed body write. The root implementation now retains separate view and body
   warnings. An integration scenario exercises both directions and requires each
   warning to clear only after success in its own scope.
2. **Injected owner account.** Checking a draft catalog's account does not prove
   that an optional mailbox-store owner exposes that same account. The store
   reviewer found this mismatch and the root corrected both hosts before draft
   loading or owner adoption. Integration tests give the host an otherwise valid
   real catalog with a foreign cache owner; no draft load or cache write is
   permitted, the candidate closes, and the online reader remains available.
3. **Fetched-message local identity.** EWS and cloud verified the fetched body
   before reader adoption. Native loading originally checked its remote identity
   but left a conflicting non-null local ID for the later cache check. The root
   corrected the native host before reader construction and the native loader
   against its frozen browsed record. Integration tests retain an original
   verified reader, then inject wrong remote and wrong local identities, require
   rejection before reader or cache adoption, and reopen the original bytes from
   disk.

## Integration scenarios

The current `studio_mail_cached_host_test.dart` contains eight scenarios for each
of IMAP, EWS, Gmail and Microsoft Graph, plus one additional offline local-draft
scenario: 33 cases using a real file-backed `SqliteStudioMailDraftStore`.

- Connect, save visited headers, explicitly open a body, disconnect and close,
  reopen offline, and compare exact raw MIME and attachment bytes. Unknown flags
  stay unknown, the partial snapshot is labeled, unopened bodies stay unavailable,
  and offline actions cause no provider construction or OAuth authorization.
- Reject wrong remote identities and conflicting non-null provider local IDs
  before reader or cache adoption, then reopen the prior verified bytes.
- Fail a replacement body transaction at `beforeCommit`; preserve the live
  provider reader and show the failure, while reopening the prior durable body.
- Hold a body transaction at `beforeCommit`, disconnect, then release it; the
  invalidated connection lease prevents a stale body commit and closing waits
  for the transaction.
- Fail the initial folder snapshot while an uncertain draft already exists;
  preserve the uncertainty and draft, leave connected headers and body reading
  usable, and expose the cache warning.
- Exercise independent view/body save warnings and clear each only with a
  subsequent successful save of its own scope.
- Reject a foreign optional mailbox owner before any draft load or cache write.
- Fill a real 32 KiB account with cached MIME, edit an existing uncertain draft,
  and observe an actual `quotaExceeded` save failure. Clear cache through the
  composer's confirmation, retry the save in place, and preserve the same live
  Word controller, To/Cc/Bcc/subject/body, attachment bytes and uncertainty,
  without provider or authorization activity.

The additional offline case closes the connected account and reopens its local
draft catalog before performing the same real-quota recovery. It checks that the
local composer cannot send and that recovery does not reconnect. A new case in
`studio_mail_local_drafts_test.dart` separately injects a valid local catalog with
a foreign optional mailbox owner and requires rejection/close before any draft
load or cache clear.

The IMAP scenarios use the production `NativeStudioMailMessageLoader` with an
injected typed provider. EWS and cloud use their production hosts with injected
typed providers. A forwarding draft owner observes close and load calls but
does not replace persistence, queue serialization, fault injection, account
validation, or storage leases.

## Qualification record

`cached-host-complete-development-6/summary.json` records **28 passing cases**, no
failures, skips or errors, plus successful strict analysis and formatting. Its
149 scoped source fingerprints were identical before and after execution at
HEAD `2d3799af2d9b32e115fee4ba2f8326795fc6b29f`. The complete Studio qualification
was subsequently repeated against the final store and UI source, as recorded
below.

After in-place recovery was added, the six new cases passed together in
`composer-host-recovery-development-3.jsonl`, and both edited files passed strict
analysis and formatting. Their focused command, case names and final source
fingerprints are recorded in `composer-host-recovery-summary.json`. This is a
focused six-case run; it does not claim that the current 33-case host file or the
entire local-draft file was rerun independently at that intermediate step. The
root's final complete Studio gate covers both complete files.

The final complete gate subsequently passed in `mail-cached-studio-accepted`:
1,149 cases across 57 files, including all 33 cached-host cases and all 13 local
draft cases. The independent raw-event/Git-blob verification in
`independent-final-count.json` confirms those counts and the final source binding
at commit `2c0c9bed091eb6bfa5a2aed153f48fc79569a433`.

Earlier development JSON logs are retained, including fixture construction
failures, Navigator reuse, the refresh polling frame race, and the transient
cleanup-interface compile gap during parallel implementation. Those earlier
failed aggregates are not accepted passing runs. The focused warning/identity
run passed all eight selected cases before the full 28-case run; it is
overlapping diagnostic evidence and does not add eight unique cases.

Recovery development also retained an initial attachment-API compile error and
a Word-editor cursor `pumpAndSettle` timeout. Corrected assertions use the public
immutable content API; explicit frame pumping allows the live editor to retain
its cursor without waiting for all animations to stop.
