# Independent qualification-seal review

Reviewed `docs/validation/mail-cached-workspace-20261120/seal_qualification.py`
for accepted-run selection, input binding, raw-event recounting and declared
scope. Repository production code and tests were not changed for this review.

## Confirmed correction

The initial sealer rejected legitimate null entries in native runtime manifests.
`direct_launcher` deliberately records three absent package-local native asset
maps because introducing one would shadow the verified workspace mapping. The
sealer originally required every manifest value to be a non-null file hash.

The root corrected this: a null entry must still be absent **and not a symlink**;
non-null entries must hash to their recorded value. Before/after runtime equality
remains required. The corrected code now agrees with the launcher's semantics.
This was a seal-logic defect; it was not a test or runtime failure.

## Acceptance review

- Complete accepted runs must report `PASS`; each accepted check must separately
  report `PASS` and exit zero. Their raw output and stderr hashes are verified.
- The initial Word aggregate is deliberately handled through its explicit
  `word-regression` selection. Its 679-case regression check passed; the aggregate
  had rejected the unrelated plain-Node empty output. The corrected complete
  portable/static Word run is accepted separately. This does not accept the
  original failed aggregate as a whole.
- The final Studio selection is `mail-cached-studio-accepted`. The preceding
  `mail-cached-studio-final-recovery` fixture failures and other interrupted or
  development runs contribute no accepted cases.
- The sealer recounts the selected JSON logs with the existing strict parser.
  That parser requires one start and successful terminal, complete test IDs,
  valid LF-framed JSON, no duplicate completions, no errors and no skipped or
  failed cases, including excluded loader/lifecycle cases. Hidden/load cases do
  not inflate substantive pass counts.

No additional confirmed defect was found in these acceptance rules. The complete
accepted Studio receipt closed successfully, and the final independent check
passed against commit `2c0c9bed091eb6bfa5a2aed153f48fc79569a433`.

## Input binding review

Accepted source manifests must be identical before and after their run. Each
source hash must still match the current file, and overlapping manifests cannot
disagree. Runtime/configuration inputs are checked against their before/after
records and current bytes, including the negative native-mapping assertions.

The sealer also rejects tracked uncommitted changes among the qualified inputs.
An independent check found that the current union's 5,648 paths are all committed
regular files; there are no qualified untracked files or symlink inputs. The
final independent check additionally compares the actual content of every
qualified file to its Git blob at a captured immutable HEAD, rather than relying
only on working-tree cleanliness.

These checks bind the declared source and runtime scopes. They are not a claim
that every file elsewhere in the repository or every external installed tool is
part of those manifests.

## Independent recount

`independent_final_count.py` is a separate read-only verifier. It does not import
the sealer or `test_summary`, execute test suites, or modify repository files.
It parses raw test events independently, validates completion and failures,
checks required named check sets, compares suite files with each run's own source
manifest, and verifies complete final Studio and Word file sets. It also checks
the final Word VM/Node output bytes and parsed JSON directly and reads the Python
control-run footer.

The final accepted cohorts independently recount as follows:

| Cohort | Cases | Test files |
|---|---:|---:|
| Mail core VM | 67 | 7 |
| Mail core Node | 67 | 7 |
| Native mail store | 714 | 30 |
| Store portability Node | 46 | 3 |
| Shared mail UI | 96 | 8 |
| MIME and transport | 486 | 26 |
| Complete Studio mail/saved-mail/credentials | 1,149 | 57 |
| Incoming Word regression | 679 | 19 |

Word has 677 unique file/name labels and 679 actual test declarations/executions.
The two duplicate labels each represent distinct existing tab-stop fixtures,
as documented in the earlier raw recount; they are not repeated suite runs.
VM and Node executions intentionally remain separate, and no combined unique
total is formed by adding overlapping platform cohorts.

The Python control log independently confirms 48 tests. The Word example reports
13 operations, and VM/Node outputs are identical as bytes and parsed JSON, with
SHA-256 `afb450d1cfd4dba6ee2b0fc8b1ca0dc639b410dd70a16c3eff1bb17fbe08bea8`.

`independent-final-count.json` is the final passing report. All 5,648 qualified
files match the Git blobs in tree `f7eada34fdbc35e4c6083c9d8d50fc1943cee6b6`, and
the normalized source-fingerprint map has SHA-256
`6da3ddc3d2803b38e5e6cb00c8d951cfbf9cf4f1e189184a153b6679ea11520f`.
`independent-completed-recount.json` remains the earlier partial-scope recount.

The accepted Studio number comes from a new complete 57-file run. It does not
combine the previous 1,143 passes/six fixture failures with a selected rerun.
