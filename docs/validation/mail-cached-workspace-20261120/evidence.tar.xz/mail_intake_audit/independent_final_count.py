#!/usr/bin/env python3
"""Read final receipts and raw events independently; do not run tests or edit sources."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = Path('/workspace/scratch/6e376c6dad91')
REPO = BASE / 'quds_office_suite'
RUNS = [
    ('mail-cached-store-final-recovery', None),
    ('mail-cached-shared-final-recovery', None),
    ('mail-cached-studio-accepted', None),
    ('mail_intake_audit/word-qualification', {'word-regression'}),
    ('mail_intake_audit/word-portable-final', None),
]
EXPECTED_CHECKS = {
    'mail-cached-store-final-recovery': {
        'runtime', 'runner-regressions', 'locked-resolution', 'core-analysis',
        'store-analysis', 'format', 'core-vm', 'core-node', 'store-vm',
        'portable-node', 'browser-entry', 'browser-worker', 'whitespace',
    },
    'mail-cached-shared-final-recovery': {'shared-mail-ui', 'mime-transport'},
    'mail-cached-studio-accepted': {
        'studio-mail', 'studio-analysis', 'changed-format', 'whitespace',
    },
    'mail_intake_audit/word-qualification': {'word-regression'},
    'mail_intake_audit/word-portable-final': {
        'word-analysis', 'word-format', 'word-levels-vm',
        'word-levels-js-compile', 'word-levels-node',
    },
}
EXPECTED_COUNTS = {
    'core-vm': 67, 'core-node': 67, 'store-vm': 714, 'portable-node': 46,
    'shared-mail-ui': 96, 'mime-transport': 486, 'studio-mail': 1149,
    'word-regression': 679,
}


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def events(path: Path, cwd: Path) -> dict:
    suites, cases, done = {}, {}, {}
    starts, terminals, errors = [], [], []
    for number, line in enumerate(path.read_bytes().decode('utf-8').split('\n'), 1):
        text = line.strip()
        while text.startswith(('Running build hooks...', 'Running link hooks...')):
            prefix = next(p for p in ('Running build hooks...', 'Running link hooks...')
                          if text.startswith(p))
            text = text[len(prefix):].lstrip()
        if not text:
            continue
        item = json.loads(text)
        need(isinstance(item, dict) and isinstance(item.get('type'), str),
             f'{path.name}:{number}: invalid event')
        need(not terminals, f'{path.name}: event after final result')
        kind = item['type']
        if kind == 'start':
            starts.append(item)
        else:
            need(len(starts) == 1, f'{path.name}: missing or duplicate start')
        if kind == 'suite':
            suite = item['suite']
            need(suite['id'] not in suites, f'{path.name}: duplicate suite')
            source = Path(suite['path'])
            source = source if source.is_absolute() else cwd / source
            suites[suite['id']] = str(source.resolve().relative_to(REPO))
        elif kind == 'testStart':
            case = item['test']
            need(case['id'] not in cases, f'{path.name}: duplicate test identifier')
            cases[case['id']] = case
        elif kind == 'testDone':
            identifier = item['testID']
            need(identifier in cases and identifier not in done,
                 f'{path.name}: unmatched or duplicate completion')
            need(item['result'] == 'success' and item['skipped'] is False,
                 f'{path.name}: failed/skipped case {cases[identifier]["name"]}')
            need(type(item['hidden']) is bool, f'{path.name}: invalid visibility')
            done[identifier] = item
        elif kind == 'error':
            errors.append(item)
        elif kind == 'done':
            terminals.append(item)
    need(len(starts) == len(terminals) == 1 and terminals[0]['success'] is True,
         f'{path.name}: absent or unsuccessful terminal')
    need(set(cases) == set(done) and not errors, f'{path.name}: incomplete/error cases')
    accepted = []
    for identifier, case in cases.items():
        need(case['suiteID'] in suites, f'{path.name}: unknown suite')
        source = suites[case['suiteID']]
        loader = case['name'] == 'loading ' + str(REPO / source)
        if done[identifier]['hidden'] or loader:
            continue
        accepted.append({'file': source, 'name': case['name']})
    need(bool(accepted), f'{path.name}: no substantive cases')
    labels = Counter((case['file'], case['name']) for case in accepted)
    return {
        'passed': len(accepted), 'files': sorted(set(suites.values())),
        'file_counts': dict(sorted(Counter(case['file'] for case in accepted).items())),
        'unique_case_labels': len(labels),
        'duplicate_case_labels': [{'file': f, 'name': n, 'executions': count}
                                 for (f, n), count in labels.items() if count > 1],
        'cases': accepted,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    tree = {}
    for record in subprocess.check_output(['git', 'ls-tree', '-rz', head], cwd=REPO).split(b'\0'):
        if record:
            meta, name = record.split(b'\t', 1)
            mode, kind, oid = meta.decode().split()
            tree[name.decode()] = (mode, kind, oid)
    sources, checks = {}, []
    for folder, selection in RUNS:
        directory = BASE / folder
        receipt = json.loads((directory / 'receipt.json').read_text())
        if selection is None:
            need(receipt['status'] == 'PASS', folder + ' is not complete/PASS')
        need(receipt['source_unchanged'] and receipt['source_before'] == receipt['source_after'],
             folder + ' source changed')
        for relative, entry in receipt['source_before'].items():
            expected = entry if isinstance(entry, str) else entry['sha256']
            need(relative in tree and tree[relative][0] in {'100644', '100755'},
                 'Qualified source is not a committed regular file: ' + relative)
            content = (REPO / relative).read_bytes()
            need(hashlib.sha256(content).hexdigest() == expected, 'Source differs: ' + relative)
            blob = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
            need(blob == tree[relative][2], 'Qualified content differs from Git tree: ' + relative)
            need(relative not in sources or sources[relative] == expected,
                 'Conflicting source manifest: ' + relative)
            sources[relative] = expected
        for before, after in [('runtime_before', 'runtime_after'),
                              ('direct_launcher_inputs_before', 'direct_launcher_inputs_after')]:
            if before not in receipt:
                continue
            need(receipt[before] == receipt[after], folder + ' runtime changed')
            for name, expected in receipt[before].items():
                path = Path(name)
                need((not path.exists() and not path.is_symlink()) if expected is None
                     else digest(path) == expected, 'Runtime differs: ' + name)
        if 'runtime' in receipt:
            runtime = receipt['runtime']
            need(receipt['runtime_configuration_unchanged'], folder + ' Word runtime changed')
            for key in ['dart', 'package_config', 'test_entry']:
                need(digest(Path(runtime[key])) == runtime[key + '_sha256'],
                     'Word runtime differs: ' + key)
        selected = [c for c in receipt['checks'] if selection is None or c['name'] in selection]
        names = [c['name'] for c in selected]
        need(len(set(names)) == len(names) and set(names) == EXPECTED_CHECKS[folder],
             'Required check set differs: ' + folder)
        for check in selected:
            need(check['status'] == 'PASS' and check['exit_code'] == 0,
                 folder + ': check not PASS: ' + check['name'])
            log = directory / check['log']
            need(digest(log) == check['log_sha256'], 'Raw log differs: ' + str(log))
            if 'stderr' in check:
                need(digest(directory / check['stderr']) == check['stderr_sha256'],
                     'Stderr differs: ' + check['name'])
            recorded = check.get('tests', check.get('summary'))
            if recorded is None:
                continue
            counted = events(log, Path(check['cwd']))
            need(counted['passed'] == recorded['passed'] and recorded['valid'] is True,
                 'Recorded count differs: ' + check['name'])
            if check['name'] in EXPECTED_COUNTS:
                need(counted['passed'] == EXPECTED_COUNTS[check['name']],
                     'Expected cohort count differs: ' + check['name'])
            need(set(counted['files']) <= set(receipt['source_before']),
                 'Suite source absent from its run manifest')
            if check['name'] == 'studio-mail':
                base = REPO / 'packages/quds_office_editor/example'
                expected = {str(p.relative_to(REPO)) for p in (base / 'test').glob('*_test.dart')
                            if p.name.startswith(('studio_mail', 'studio_saved_mail', 'studio_credential'))}
                need(set(counted['files']) == expected, 'Complete Studio file set differs')
                need(not any(a in {'--name', '--plain-name'} for a in check['command']),
                     'Unexpected Studio test filter')
            if check['name'] == 'word-regression':
                expected = {str((Path(check['cwd']) / 'test' / p).resolve().relative_to(REPO))
                            for p in receipt['selected_test_files']}
                need(set(counted['files']) == expected, 'Complete Word file set differs')
            checks.append({'run': folder, 'check': check['name'], **counted})
    portable = BASE / 'mail_intake_audit/word-portable-final'
    vm = (portable / 'word-levels-vm.stdout').read_bytes()
    node = (portable / 'word-levels-node.stdout').read_bytes()
    need(vm == node and json.loads(vm) == json.loads(node), 'Word VM/Node content differs')
    need(json.loads(vm)['example']['operations'] == 13, 'Word operation count differs')
    controls = (BASE / 'mail-cached-store-final-recovery/runner-regressions.log').read_text()
    footer = re.search(r'Ran (\d+) tests in [^\n]+\n\nOK\s*\Z', controls)
    need(footer is not None and int(footer[1]) == 48, 'Python control footer differs')
    need(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == head,
         'HEAD changed during independent check')
    result = {
        'status': 'PASS', 'verified_at_utc': datetime.now(timezone.utc).isoformat(),
        'verified_commit': head, 'source_inputs': len(sources),
        'verified_tree': subprocess.check_output(
            ['git', 'rev-parse', head + '^{tree}'], cwd=REPO, text=True).strip(),
        'source_fingerprints_sha256': hashlib.sha256(
            json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        'all_qualified_files_match_git_blobs': True, 'python_control_cases': 48,
        'word_vm_node_bytes_equal': True, 'word_example_operations': 13,
        'word_output_sha256': hashlib.sha256(vm).hexdigest(),
        'checks': checks, 'github_actions': 'NOT QUERIED OR AWAITED',
        'counting_note': 'Counts are case executions by cohort/platform; overlapping VM/Node cases are not added into a unique combined total.',
    }
    if args.output:
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'checks'}))
    for check in checks:
        print(json.dumps({'check': check['check'], 'passed': check['passed'],
                          'files': len(check['files']), 'unique_case_labels': check['unique_case_labels']}))


if __name__ == '__main__':
    main()
