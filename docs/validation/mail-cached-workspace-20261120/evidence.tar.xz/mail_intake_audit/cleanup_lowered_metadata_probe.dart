import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:drift/native.dart';
import 'package:quds_mail_core/quds_mail_core.dart';
import 'package:quds_mail_store/quds_mail_store.dart';

T value<T>(MailResult<T> result) => switch (result) {
  MailSuccess<T>(:final value) => value,
  MailFailure<T>(:final problem) => throw StateError(problem.code.name),
};

Future<void> main() async {
  final directory = await Directory.systemTemp.createTemp('cleanup-review-');
  final file = File('${directory.path}/mail.sqlite');
  final profile = MailProfileId('cleanup-review', hostId: 'test-office');
  final account = MailAccountId('account', profile: profile);
  final mailbox = MailMailbox(
    id: MailMailboxId('inbox', account: account),
    displayName: 'Inbox',
  );
  final header = MailHeaderRecord(
    id: MailMessageId('message'),
    remote: MailImapIdentity(mailbox: mailbox.id, uidValidity: 1, uid: 1),
    envelope: MailEnvelope(subject: 'x' * 4096),
  );
  Future<SqliteMailRepository> open(MailStoreLimits limits) async => value(
    await SqliteMailRepository.open(
      executor: NativeDatabase(file),
      profile: profile,
      limits: limits,
    ),
  );
  var store = await open(const MailStoreLimits());
  try {
    value(await store.createAccount(MailStoreAccount(
      id: account,
      provider: MailProviderKind.imap,
      displayName: 'Account',
    )));
    value(await store.saveMailboxView(
      mailbox,
      [header],
      expectedRevision: null,
      hasMore: false,
      lease: MailAccountSession(account).begin(),
    ));
    value(await store.cacheMessage(account, header.id, MailMessage(
      raw: MailBytes(Uint8List.fromList([1, 2, 3])),
      envelope: header.envelope,
      body: const MailBody(plainText: 'Cached body'),
      localId: header.id,
      remoteIdentity: header.remote,
    )));
    await store.close();
    store = await open(const MailStoreLimits(
      maxAccountBytes: 1,
      maxMetadataCodeUnits: 64,
    ));
    final cleanup = await store.clearMailboxCache(account);
    final failure = switch (cleanup) {
      MailFailure<MailCacheCleanupReport>(:final problem) => problem.code.name,
      MailSuccess<MailCacheCleanupReport>() => null,
    };
    await store.close();
    store = await open(const MailStoreLimits());
    final retainedView = value(await store.loadMailboxView(mailbox.id));
    final retainedBody = value(await store.loadCachedMessage(account, header.id));
    final evidence = {
      'stored_subject_units': header.envelope.subject.length,
      'original_metadata_limit': const MailStoreLimits().maxMetadataCodeUnits,
      'reopened_metadata_limit': 64,
      'reopened_account_byte_limit': 1,
      'cleanup_failure': failure,
      'view_retained_after_reopen': retainedView != null,
      'body_retained_after_reopen': retainedBody != null,
      'confirmed': failure == 'quotaExceeded' && retainedView != null && retainedBody != null,
    };
    stdout.writeln(jsonEncode(evidence));
    if (evidence['confirmed'] != true) throw StateError('Reproduction changed.');
  } finally {
    await store.close();
    await directory.delete(recursive: true);
  }
}
