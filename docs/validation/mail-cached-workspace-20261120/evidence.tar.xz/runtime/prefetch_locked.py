from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import sys
import tarfile
import time
import urllib.request
import yaml

root = Path(__file__).resolve().parent
archive_dir = root / 'downloads' / 'pub'
cache = root / 'pub-cache'
archive_dir.mkdir(parents=True, exist_ok=True)
hosted = cache / 'hosted' / 'pub.dev'
hashes = cache / 'hosted-hashes' / 'pub.dev'
hosted.mkdir(parents=True, exist_ok=True)
hashes.mkdir(parents=True, exist_ok=True)
packages = {}
for filename in sys.argv[1:]:
    data = yaml.safe_load(Path(filename).read_text())
    for name, item in data['packages'].items():
        if item['source'] != 'hosted':
            continue
        description = item['description']
        if description['url'] != 'https://pub.dev':
            raise ValueError('Unexpected package source: ' + name)
        version = item['version']
        value = (name, version, description['sha256'])
        key = name + '-' + version
        if key in packages and packages[key] != value:
            raise ValueError('Conflicting package hashes')
        packages[key] = value

def fetch(value):
    name, version, expected = value
    key = name + '-' + version
    path = archive_dir / (key + '.tar.gz')
    url = 'https://pub.dev/api/archives/' + key + '.tar.gz'
    if not path.exists():
        last = None
        for attempt in range(3):
            try:
                with urllib.request.urlopen(url, timeout=45) as response:
                    path.write_bytes(response.read())
                last = None
                break
            except Exception as error:
                last = error
        if last is not None:
            raise last
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise ValueError('Archive hash mismatch: ' + key)
    target = hosted / key
    if not target.exists():
        target.mkdir()
        with tarfile.open(path) as archive:
            archive.extractall(target, filter='data')
    (hashes / (key + '.sha256')).write_text(expected)
    return {'name': name, 'version': version, 'url': url,
            'archive': str(path), 'sha256': actual,
            'bytes': path.stat().st_size, 'verified': True}

with ThreadPoolExecutor(max_workers=12) as executor:
    receipts = list(executor.map(fetch, packages.values()))
output = root / 'pub-cache-receipt.json'
output.write_text(json.dumps({'count': len(receipts), 'archives': receipts}, indent=2) + '\n')
print('Verified locked hosted archives:', len(receipts), flush=True)
