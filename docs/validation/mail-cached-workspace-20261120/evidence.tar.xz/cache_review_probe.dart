import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:quds_mail_core/quds_mail_core.dart';
import 'package:quds_mail_store/quds_mail_store.dart';
import 'package:sqlite3/sqlite3.dart' as sqlite;

T value<T>(MailResult<T> result) {
  if (result case MailSuccess<T>(:final value)) return value;
  throw StateError('Expected success: ${(result as MailFailure<T>).problem.code}');
}

String resultName<T>(MailResult<T> result) => switch (result) {
  MailSuccess<T>() => 'success',
  MailFailure<T>(:final problem) => problem.code.name,
};

final class Probe extends QueryInterceptor {
  int maximumTransferredText = 0;
  @override
  Future<List<Map<String, Object?>>> runSelect(
    QueryExecutor executor,
    String statement,
    List<Object?> args,
  ) async {
    final result = await super.runSelect(executor, statement, args);
    for (final row in result) {
      for (final value in row.values) {
        if (value is String && value.length > maximumTransferredText) {
          maximumTransferredText = value.length;
        }
      }
    }
    return result;
  }
}

Future<void> main() async {
  final folder = await Directory.systemTemp.createTemp('cache-review-');
  final file = File('${folder.path}/mail.sqlite');
  final profile = MailProfileId('review', hostId: 'review');
  final account = MailAccountId('account', profile: profile);
  final mailbox = MailMailbox(
    id: MailMailboxId('inbox', account: account), displayName: 'Inbox',
  );
  final header = MailHeaderRecord(
    id: MailMessageId('one'),
    remote: MailImapIdentity(mailbox: mailbox.id, uidValidity: 1, uid: 1),
    envelope: MailEnvelope(subject: 'One'),
  );
  final session = MailAccountSession(account);
  final probe = Probe();
  var store = value(await SqliteMailRepository.open(
    executor: NativeDatabase(file).interceptWith(probe), profile: profile,
    limits: const MailStoreLimits(maxAccountBytes: 16384),
  ));
  try {
    value(await store.createAccount(MailStoreAccount(id: account,
      provider: MailProviderKind.imap, displayName: 'Review')));
    value(await store.saveMailboxView(mailbox,[header],expectedRevision:null,
      hasMore:false,lease:session.begin()));
    final cacheResult = await store.cacheMessage(account,header.id,MailMessage(
      raw: MailBytes(Uint8List.fromList(List<int>.filled(8000, 65))), envelope:header.envelope,
      body: MailBody(plainText:'b' * 1000), localId:header.id,remoteIdentity:header.remote,
    ));
    final draft=MailDraft(id:'draft',account:account,revision:0,
      envelope:MailEnvelope(subject:'Unfinished'),body:MailBody(plainText:'c' * 5000));
    final before = await store.saveDraft(draft,expectedRevision:null);
    final evicted=await store.evictCache(account);
    final after = await store.saveDraft(draft,expectedRevision:null);
    print(jsonEncode({'probe':'cache blocks draft', 'cache':resultName(cacheResult),
      'draft_before_eviction':resultName(before),'evicted':evicted is MailSuccess<int> ? evicted.value : null,
      'draft_after_eviction':resultName(after)}));
    // Restore one normal cached body, then replace its metadata outside the
    // closed repository to exercise the reopened-storage corruption boundary.
    value(await store.cacheMessage(account,header.id,MailMessage(raw:MailBytes(Uint8List.fromList([1,2,3])),
      envelope:header.envelope,body:const MailBody(plainText:'body'),localId:header.id,
      remoteIdentity:header.remote)));
    await store.close();
    final db=sqlite.sqlite3.open(file.path);
    db.execute('UPDATE cached_messages SET data=?',['x' * (1024*1024)]);
    db.close();
    store=value(await SqliteMailRepository.open(
      executor:NativeDatabase(file).interceptWith(probe),profile:profile,
      limits:const MailStoreLimits(maxMetadataCodeUnits:4096),
    ));
    probe.maximumTransferredText=0;
    final saved=await store.saveMailboxView(mailbox,[header],expectedRevision:1,
      hasMore:false,lease:session.begin());
    print(jsonEncode({'probe':'cached metadata preflight','result':resultName(saved),
      'maximum_transferred_text':probe.maximumTransferredText,'configured_metadata_limit':4096}));
  } finally {
    await store.close();
    await folder.delete(recursive:true);
  }
}
