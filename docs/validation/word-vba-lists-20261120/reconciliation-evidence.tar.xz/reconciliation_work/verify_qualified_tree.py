"""Verify the complete qualified source path/mode/blob set at a Git commit."""
import datetime
import gzip
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
REPO = ROOT / 'quds_office_suite'
TARGET = sys.argv[1]
MANIFEST = pathlib.Path(sys.argv[2])
OUT = pathlib.Path(sys.argv[3]) if len(sys.argv) > 3 else None

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

before = json.loads(gzip.decompress(MANIFEST.read_bytes()))
scopes = before['selection']['directories'] + before['selection']['configuration_files']
commit = git('rev-parse', TARGET + '^{commit}').decode().strip()
actual = {}
for record in git('ls-tree', '-rz', commit, '--', *scopes).split(b'\0'):
    if not record:
        continue
    metadata, path = record.split(b'\t', 1)
    mode, kind, blob = metadata.decode().split()
    actual[path.decode()] = dict(mode=mode, type=kind, blob=blob)
expected = {path: entry['head'] for path, entry in before['entries'].items()}
changes = sorted(path for path in set(actual) | set(expected) if actual.get(path) != expected.get(path))
report = dict(recorded_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              source_commit=before['source_commit'], source_tree=before['source_tree'],
              target_commit=commit, target_tree=git('rev-parse', commit + '^{tree}').decode().strip(),
              source_manifest_sha256=hashlib.sha256(MANIFEST.read_bytes()).hexdigest(),
              input_count=len(expected), target_input_count=len(actual),
              complete_path_sets_equal=set(actual) == set(expected),
              modes_types_and_git_objects_equal=actual == expected,
              changed_paths=changes,
              canonical_qualified_input_manifest_sha256=hashlib.sha256(
                  json.dumps(expected, sort_keys=True, separators=(',', ':')).encode()).hexdigest())
if OUT is not None:
    OUT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
if changes:
    raise SystemExit(1)
