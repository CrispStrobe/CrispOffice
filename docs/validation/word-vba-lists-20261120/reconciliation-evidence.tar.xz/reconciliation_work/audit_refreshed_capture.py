#!/usr/bin/env python3
"""Read-only proof of exact captured heads at an intake target."""
import collections
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
REPO = ROOT.parent / 'quds_office_suite'
TARGET = sys.argv[1]
CAPTURE = pathlib.Path(sys.argv[2]).resolve()
OUT = pathlib.Path(sys.argv[3]).resolve()
PRIOR = REPO / 'docs/validation/word-vba-tabstops-20261120/final-intake.json'

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()

def ancestor(sha):
    result = subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', sha, TARGET], capture_output=True, text=True)
    if result.returncode not in (0, 1):
        raise RuntimeError(result.stderr)
    return result.returncode == 0

def entries(sha, paths):
    return git('ls-tree', '-r', sha, '--', *paths).splitlines()

capture = json.loads(CAPTURE.read_text())
prior = json.loads(PRIOR.read_text())
proofs = []
for source in prior['historical_equivalence_proofs']:
    old = source['historical_head']
    accepted = source['accepted_ancestor']
    base = source['comparison_base']
    paths = git('diff', '--name-only', base, old).splitlines()
    old_tree = git('rev-parse', old + '^{tree}')
    accepted_tree = git('rev-parse', accepted + '^{tree}')
    same_paths = sorted(paths) == sorted(source['changed_paths'])
    accepted_is_ancestor = ancestor(accepted)
    identical_changed_entries = entries(old, paths) == entries(accepted, paths)
    full_tree_equal = old_tree == accepted_tree
    verified = same_paths and accepted_is_ancestor and identical_changed_entries
    if source['whole_tree_equal']:
        verified = verified and full_tree_equal
    proofs.append(dict(historical_head=old, accepted_ancestor=accepted,
        comparison_base=base, changed_paths=paths, changed_path_count=len(paths),
        matches_previous_path_inventory=same_paths,
        accepted_is_ancestor=accepted_is_ancestor,
        changed_modes_types_objects_exact=identical_changed_entries,
        historical_tree=old_tree, accepted_tree=accepted_tree,
        whole_tree_equal=full_tree_equal, verified=verified))

equivalents = {p['historical_head']: p for p in proofs if p['verified']}
assessed = {}
for kind in ['branches', 'pull_requests', 'upstream']:
    result = []
    for item in capture[kind]:
        row = dict(item)
        sha = row['sha']
        if sha == TARGET:
            row['status'] = 'exact_target'
        elif ancestor(sha):
            row['status'] = 'ancestor'
        elif sha in equivalents:
            row['status'] = 'historically_superseded_equivalent'
            row['accepted_ancestor'] = equivalents[sha]['accepted_ancestor']
        else:
            row['status'] = 'uncovered'
        result.append(row)
    assessed[kind] = result

uncovered = [r for rows in assessed.values() for r in rows if r['status'] == 'uncovered']
report = dict(schema='quds-word-vba-source-intake/v1',
    audited_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    repository=capture['repository'], target_commit=git('rev-parse', TARGET),
    target_tree=git('rev-parse', TARGET + '^{tree}'),
    target_parents=git('show', '-s', '--format=%P', TARGET).split(),
    captured_inventory_at_utc=capture['captured_at_utc'],
    captured_main=capture['captured_main'],
    historical_equivalence_proofs=proofs,
    summary={kind: dict(collections.Counter(r['status'] for r in rows)) for kind, rows in assessed.items()},
    uncovered_ref_entries=uncovered,
    all_historical_proofs_verified=all(p['verified'] for p in proofs),
    prior_reconciliation_sha256=hashlib.sha256(PRIOR.read_bytes()).hexdigest(),
    capture_sha256=hashlib.sha256(CAPTURE.read_bytes()).hexdigest(),
    github_actions_used=False,
    qualification_claim='Source/history inclusion only. Incoming Mail, editor, provider and other runtimes are not independently qualified by this audit.',
    **assessed)
out = OUT
out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['target_commit', 'target_tree', 'summary', 'uncovered_ref_entries', 'all_historical_proofs_verified']}, indent=2))
if uncovered or not report['all_historical_proofs_verified']:
    sys.exit(1)
