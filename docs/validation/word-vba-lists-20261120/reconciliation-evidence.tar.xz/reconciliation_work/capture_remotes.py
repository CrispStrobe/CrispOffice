"""Capture advertised source refs; never query workflow or status endpoints."""
import datetime
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
REPO = ROOT / 'quds_office_suite'
OUT = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'reconciliation_work/final-capture.json'
UPSTREAM = 'https://github.com/MohammedAsaadAsaad/quds_office_suite.git'

def run(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True)

def refs(remote, *patterns):
    return [dict(ref=ref, sha=sha) for sha, ref in
            (line.split() for line in run('ls-remote', remote, *patterns).splitlines())]

run('fetch', '--no-tags', 'origin', '+refs/heads/*:refs/remotes/origin/*', '+refs/pull/*/head:refs/remotes/origin-pr/*')
run('fetch', '--no-tags', UPSTREAM, '+refs/heads/*:refs/remotes/upstream/*')
fork = refs('origin', 'refs/heads/*', 'refs/pull/*/head')
branches = [r for r in fork if r['ref'].startswith('refs/heads/')]
prs = [dict(r, number=int(r['ref'].split('/')[2])) for r in fork if r['ref'].startswith('refs/pull/')]
upstream = refs(UPSTREAM, 'refs/heads/*')
capture = dict(schema='quds-word-vba-refreshed-remote-capture/v1',
               captured_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               repository='CrispStrobe/quds_office_suite', branches=branches,
               pull_requests=prs, upstream=upstream,
               captured_main=next(r['sha'] for r in branches if r['ref'] == 'refs/heads/main'),
               github_actions_used=False,
               source_commands=['git ls-remote origin refs/heads/* refs/pull/*/head',
                                'git ls-remote ' + UPSTREAM + ' refs/heads/*'])
OUT.write_text(json.dumps(capture, indent=2) + '\n')
print(json.dumps(dict(path=str(OUT), main=capture['captured_main'],
                      branches=len(branches), pull_requests=len(prs), upstream=len(upstream))))
