import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;
const w=OfficeNamespaces.w;
String p(String value)=>'<w:p>$value</w:p>';
String t(String value)=>'<w:r><w:t>$value</w:t></w:r>';
String f(String type)=>'<w:r><w:fldChar w:fldCharType="$type"/></w:r>';
String i(String value)=>'<w:r><w:instrText xml:space="preserve">$value</w:instrText></w:r>';
void main(){
 final cases=<String,String>{
  'middle result':p(f('begin')+i(' LISTNUM LegalDefault ')+f('separate')+t('First'))+p(t('Middle'))+p(t('Last')+f('end')),
  'split cross paragraph':p(f('begin')+i(' LIST'))+p(i('NUM LegalDefault ')+f('separate')+t('Middle'))+p(t('Last')+f('end')),
  'whole unrelated':p(f('begin')+i(' LISTNUM LegalDefault ')+f('separate')+t('First')+f('end'))+p(t('Middle'))+p(t('Last')),
 };
 for(final e in cases.entries){
 final pkg=OpcPackage.create(OpcPackageKind.word);
 pkg.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="$w"><w:body>${e.value}<w:sectPr/></w:body></w:document>');
 final doc=WordDeserializer().readBytes(pkg.save());
 final state=[for(final p in doc.paragraphs){'instruction':p.properties.fieldInstruction,'begin':p.properties.fieldBegin,'separate':p.properties.fieldSeparate,'end':p.properties.fieldEnd,'inlines':[for(final r in p.inlines)r is WmlFieldBoundary ? '${r.kind.name}:${r.text}' : r is WmlRun ? '${r.text}:${r.fieldInstruction}' : r.runtimeType.toString()]}];
 String result;
 try{native.applyStep(doc,{'op':'removeNumbers','paragraph':1});result='accepted';}catch(e){result=e.toString();}
 print(jsonEncode({'case':e.key,'model':state,'result':result}));
 }
}
