import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;
const w=OfficeNamespaces.w;
void main(){
 for(final op in ['listDefault','removeNumbers']){
 final pkg=OpcPackage.create(OpcPackageKind.word);
 pkg.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="$w"><w:body><w:p><w:pPr><w:numPr><w:ilvl w:val="0"/><w:numId w:val="71"/></w:numPr></w:pPr><w:r><w:t>Original</w:t></w:r></w:p><w:sectPr/></w:body></w:document>');
 final numbering='<w:numbering xmlns:w="$w"><w:abstractNum w:abstractNumId="42"><w:multiLevelType w:val="singleLevel"/><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1."/><w:pPr><w:ind w:left="1440" w:hanging="360"/></w:pPr></w:lvl></w:abstractNum><w:num w:numId="71"><w:abstractNumId w:val="42"/></w:num></w:numbering>';
 final part=pkg.getPart('/word/numbering.xml');
 if(part==null){pkg.createPart('/word/numbering.xml',OfficeContentTypes.wordNumbering,utf8.encode(numbering));}else{part.writeText(numbering);}
 if(pkg.relationshipsFor('/word/document.xml').firstByType(RelationshipTypes.numbering)==null){pkg.relationshipsFor('/word/document.xml').add(type:RelationshipTypes.numbering,target:'numbering.xml');}
 var doc=WordDeserializer().readBytes(pkg.save());
 Map<String,Object?> state()=>{'id':doc.paragraphs.single.properties.numId,'indent':doc.paragraphs.single.properties.indent.left,'hanging':doc.paragraphs.single.properties.indent.hanging,'imported':doc.paragraphs.single.properties.importedValues?['ind'],'source':doc.paragraphs.single.properties.sourcePropertiesXml};
 final before=state();
 native.applyStep(doc,{'op':op,'paragraph':0,if(op=='listDefault')'numbered':true});
 final mutated=state();
 var bytes=WordSerializer().writeBytes(doc);
 doc=WordDeserializer().readBytes(bytes);
 print(jsonEncode({'op':op,'before':before,'mutated':mutated,'reopened':state()}));
 }
}
