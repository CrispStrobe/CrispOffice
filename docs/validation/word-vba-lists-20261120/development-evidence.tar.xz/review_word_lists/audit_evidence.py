#!/usr/bin/env python3
"""Independent read-only audit of already completed local qualification."""
import argparse
import collections
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT=Path('/workspace/scratch/c7ec4681d1f4')
REPO=ROOT/'quds_office_suite'

def read(path):
    return json.loads(gzip.decompress(path.read_bytes()) if path.suffix=='.gz' else path.read_bytes())
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git','-C',str(REPO),*args])
def entries(ref,*scopes):
    result={}
    for row in git('ls-tree','-rz',ref,'--',*scopes).split(b'\0'):
        if not row: continue
        metadata,path=row.split(b'\t',1)
        mode,kind,blob=metadata.decode().split()
        result[path.decode()]={'mode':mode,'type':kind,'blob':blob}
    return result

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--gate',type=Path,required=True)
    parser.add_argument('--portable',type=Path,required=True)
    parser.add_argument('--commit',required=True)
    parser.add_argument('--tree',required=True)
    parser.add_argument('--supplement',type=Path,default=ROOT/'review_word_lists/portable-static-review.json')
    parser.add_argument('--excluded-portable',type=Path,action='append',default=[])
    parser.add_argument('--out',type=Path,default=ROOT/'review_word_lists/evidence-review.json')
    args=parser.parse_args()
    FROZEN=args.commit
    TREE=args.tree
    gate=args.gate
    plan=read(gate/'plan.json')
    summary=read(gate/'summary.json')
    before=read(gate/'inputs-before.json.gz')
    after=read(gate/'inputs-after.json.gz')
    recorded_cases=read(gate/'cases.json.gz')
    checks={}
    def check(label,condition):
        checks[label]=bool(condition)
    supplement=read(args.supplement)
    source_review=read(ROOT/'review_word_lists/source-review.json')
    check('supplemental_portable_static_review_accepted',supplement['accepted'] is True and not supplement['failed_checks'] and all(supplement['checks'].values()) and supplement['source_commit']==FROZEN and supplement['source_tree']==TREE)
    check('source_review_current_bound_and_resolved',source_review['source_commit']==FROZEN and source_review['source_tree']==TREE and source_review['superseded'] is False and not source_review['unresolved_concrete_issues'])
    check('supplemental_artifacts_unchanged',sha((Path(supplement['portable']['directory'])/'receipt.json').read_bytes())==supplement['portable']['receipt_sha256'] and sha((Path(supplement['static']['directory'])/'summary.json').read_bytes())==supplement['static']['summary_sha256'] and sha((Path(supplement['static']['directory'])/'inputs-before.json.gz').read_bytes())==supplement['static']['inputs_before_sha256'] and sha((Path(supplement['static']['directory'])/'inputs-after.json.gz').read_bytes())==supplement['static']['inputs_after_sha256'])
    check('frozen_tree_identity',git('rev-parse',FROZEN+'^{tree}').decode().strip()==TREE)
    check('gate_bound_to_frozen_source',before['source_commit']==FROZEN and before['source_tree']==TREE and summary['source_commit']==FROZEN and summary['source_tree']==TREE)
    raw=(gate/'stdout.jsonl').read_bytes()
    event_lines=raw.decode().splitlines()
    check('raw_reporter_nonempty_and_line_terminated',bool(event_lines) and raw.endswith(b'\n'))
    events=[json.loads(line) for line in event_lines if line.strip()]
    started={};completed={};groups={};suites={};duplicates=[];errors=[]
    for event in events:
        typ=event.get('type')
        if typ=='testStart':
            record=event['test'];target=started;key=record['id']
        elif typ=='testDone':
            record=event;target=completed;key=record['testID']
        elif typ=='group':
            record=event['group'];target=groups;key=record['id']
        elif typ=='suite':
            record=event['suite'];target=suites;key=record['id']
        else:
            if typ=='error': errors.append(event)
            continue
        if key in target: duplicates.append([typ,key])
        target[key]=record
    check('unique_reporter_ids',not duplicates)
    check('all_started_tests_completed',set(started)==set(completed))
    check('single_vm_suite',len(suites)==1 and all(v['platform']=='vm' for v in suites.values()))
    done_events=[e for e in events if e.get('type')=='done']
    check('exactly_one_successful_final_done',len(done_events)==1 and events[-1] is done_events[0] and done_events[0].get('success') is True)
    check('no_reporter_errors',not errors)
    names=plan['files']
    check('unique_selected_files',len(names)==len(set(names))==plan['file_count'])
    per_file={name:0 for name in names};declared={};occurrences=collections.Counter();cases=[];bad_groups=[]
    for group in groups.values():
        if group['name'] in per_file:
            if group['name'] in declared: bad_groups.append(group['name'])
            declared[group['name']]=group['testCount']
    hidden=0;failed=0;skipped=0
    for key,event in completed.items():
        start=started[key]
        failed += event['result']!='success'
        skipped += bool(event.get('skipped') or start.get('metadata',{}).get('skip'))
        if event.get('hidden'):
            hidden+=1
            continue
        matches=[groups[g]['name'] for g in start['groupIDs'] if g in groups and groups[g]['name'] in per_file]
        if len(matches)!=1:
            bad_groups.append(start['name']);continue
        name=matches[0]
        prefix=name+' '
        if not start['name'].startswith(prefix): bad_groups.append(start['name'])
        original=start['name'][len(prefix):]
        occurrences[name,original]+=1
        per_file[name]+=1
        cases.append({'file':name,'name':original,'occurrence':occurrences[name,original],'test_id':key,'result':event['result'],'skipped':event.get('skipped',False)})
    roots=[g for g in groups.values() if g['parentID'] is None]
    check('no_failed_or_skipped_completions',failed==0 and skipped==0)
    check('exact_declared_file_groups',not bad_groups and set(declared)==set(names))
    check('all_declared_cases_executed_once',per_file==declared and all(v>0 for v in per_file.values()))
    check('root_count_equals_completed_cases',len(roots)==1 and roots[0]['testCount']==len(cases))
    check('case_manifest_matches_raw_reporter',cases==recorded_cases)
    check('summary_matches_independent_raw_counts',summary['file_count']==len(names) and summary['passing_cases']==len(cases) and summary['failed_cases']==failed and summary['skipped_cases']==skipped and summary['hidden_completions']==hidden and summary['per_file_cases']==per_file)
    check('summary_accepts_completed_zero_exit_run',summary['accepted'] is True and summary['complete'] is True and summary['exit_code']==0 and not summary['problems'])
    check('gate_raw_stderr_empty',(gate/'stderr.log').read_bytes()==b'')
    check('summary_artifact_hashes_match',all((gate/name).is_file() and sha((gate/name).read_bytes())==digest for name,digest in summary['hashes'].items()))
    harness=(gate/'word_office_gate_test.dart').read_bytes()
    check('harness_hash_matches',sha(harness)==plan['harness_sha256'])
    imports=re.findall(r"import 'file://[^']*/test/([^/']+)' as suite(\d+);",harness.decode())
    calls=re.findall(r"group\('([^']+)', suite(\d+)\.main\);",harness.decode())
    expected=[(name,str(i)) for i,name in enumerate(names)]
    check('harness_imports_and_calls_exact_file_set',imports==expected and calls==expected)
    all_tests=entries(FROZEN,'packages/quds_office_engine/test')
    all_vba={Path(p).name for p in all_tests if Path(p).parent.as_posix()=='packages/quds_office_engine/test' and Path(p).name.startswith('office_vba_') and Path(p).name.endswith('_test.dart')}
    check('all_office_vba_files_selected',all_vba=={n for n in names if n.startswith('office_vba_')})
    prior=json.loads(git('show',FROZEN+':docs/validation/word-vba-tabstops-20261120/regression.json'))
    old_names={n for g in prior['groups'] for n in g['files']}
    check('selected_files_are_full_prior_gate_plus_new_vba_and_native',set(names)==old_names|all_vba|{'office_macro_word_list_format_test.dart'})
    old_test_entries=entries(prior['source_commit'],'packages/quds_office_engine/test')
    prior_counts={}
    for name,count in prior['per_file_cases'].items():
        path='packages/quds_office_engine/test/'+name
        if old_test_entries.get(path)==all_tests.get(path): prior_counts[name]={'previous':count,'observed':per_file[name]}
    check('unchanged_prior_test_counts_preserved',all(v['previous']==v['observed'] for v in prior_counts.values()))
    scopes=before['selection']['directories']+before['selection']['configuration_files']
    frozen_entries=entries(FROZEN,*scopes)
    check('complete_input_path_set_matches_frozen_tree',set(before['entries'])==set(frozen_entries)==set(after['entries']))
    check('before_after_source_and_runtime_inputs_identical',before['entries']==after['entries'] and before['runtime_inputs']==after['runtime_inputs'])
    bad_inputs=[]
    for path,info in before['entries'].items():
        actual=frozen_entries.get(path)
        expected={'mode':info['worktree_mode'],'type':'blob','blob':info['worktree_blob']}
        data=git('show',FROZEN+':'+path)
        if info['head']!=actual or expected!=actual or sha(data)!=info['sha256'] or len(data)!=info['bytes']:
            bad_inputs.append(path)
    check('all_input_blob_mode_length_sha256_bindings_match',not bad_inputs)
    check('recorded_worktree_matches_head',before['head_matches_worktree'] is True and after['head_matches_worktree'] is True)
    check('selected_module_hashes_match_bound_inputs',len(plan['reviewed_modules'])==len(names) and {m['file'] for m in plan['reviewed_modules']}==set(names) and all(before['entries']['packages/quds_office_engine/test/'+m['file']]['sha256']==m['sha256'] for m in plan['reviewed_modules']))
    check('runtime_input_hashes_match',all(Path(p).is_file() and Path(p).stat().st_size==v['bytes'] and sha(Path(p).read_bytes())==v['sha256'] for p,v in before['runtime_inputs'].items()))
    stopped=[]
    for index,old in enumerate([ROOT/'runtime/word-office-gate-final',ROOT/'runtime/word-office-gate-final-v2'],start=1):
        superseded=read(old/'superseded.json')
        partial=[json.loads(line) for line in (old/'stdout.jsonl').read_text().splitlines() if line.strip()]
        partial_completed=sum(e.get('type')=='testDone' and not e.get('hidden') for e in partial)
        check(f'stopped_attempt_{index}_explicitly_unqualified',superseded['superseded'] is True and superseded['complete'] is False and superseded['accepted'] is False and superseded['exit_code']==130 and superseded['partial_visible_completed']==partial_completed)
        check(f'stopped_attempt_{index}_hashes_match',all((old/n).is_file() and sha((old/n).read_bytes())==h for n,h in superseded['hashes'].items()))
        stopped.append({'directory':str(old),'source_commit':superseded['source_commit'],'partial_visible_completed':partial_completed,'exit_code':superseded['exit_code'],'included_in_final_total':False,'superseded_receipt_sha256':sha((old/'superseded.json').read_bytes())})
    excluded_portable=[]
    for path in args.excluded_portable:
        old_receipt=read(path/'receipt.json')
        excluded_portable.append({'directory':str(path),'receipt_sha256':sha((path/'receipt.json').read_bytes()),'attempt_exit_codes':{a['name']:a['exit_code'] for a in old_receipt['attempts']},'source_commit_at_start':old_receipt.get('source_commit_at_start'),'included_in_final_qualification':False})
    portable=args.portable
    receipt=read(portable/'receipt.json')
    binding=read(portable/'input-binding.json')
    vm=(portable/'vm.stdout').read_bytes();js=(portable/'js.stdout').read_bytes()
    pv=json.loads(vm);pj=json.loads(js)
    canonical=json.dumps(pv,sort_keys=True,separators=(',',':')).encode()
    check('portable_three_commands_completed_successfully',[a['name'] for a in receipt['attempts']]==['vm','js-compile','js'] and all(a['exit_code']==0 for a in receipt['attempts']))
    check('portable_raw_and_canonical_equal',vm==js and pv==pj and receipt['raw_equal'] is True and receipt['canonical_equal'] is True and sha(canonical)==receipt['canonical_sha256'])
    check('portable_canonical_artifact_matches',read(portable/'canonical-result.json')==pv)
    check('portable_expected_semantic_guards',pv['example']['operations']==8 and pv['example']['revision']==1 and pv['example']['additionalReopens']==2 and pv['lateFailureRollback'] is True and pv['opaqueBoundaryGuards']=={'cases':4,'allModeRollback':True,'paragraphModeRefusals':2,'paragraphModePreservations':2,'additionalReopens':2} and pv['fieldAndPolicyGuards']['allNumberRefusalRollback'] is True and pv['fieldAndPolicyGuards']['paragraphModePreservesField'] is True and pv['fieldAndPolicyGuards']['policyRefusals']==2 and pv['refusedSources']==8)
    portable_tree=entries(FROZEN,*receipt['input_scopes'])
    check('portable_complete_input_path_set',set(binding)==set(portable_tree) and len(binding)==receipt['input_count'])
    bad_portable=[]
    for path,info in binding.items():
        data=git('show',FROZEN+':'+path)
        mode='100755' if int(info['mode'],8)&0o111 else '100644'
        if sha(data)!=info['sha256'] or mode!=portable_tree[path]['mode']: bad_portable.append(path)
    check('portable_input_hashes_match_frozen_source',not bad_portable and receipt['source_inputs_unchanged_during_run'] is True)
    bas='packages/quds_office_engine/example/macros/word_lists.bas'
    driver='packages/quds_office_engine/tool/macros/web_vba_word_lists_smoke.dart'
    check('portable_exact_bas_and_driver_hashes',receipt['source_sha256']==sha(git('show',FROZEN+':'+bas)) and receipt['source_bytes']==len(git('show',FROZEN+':'+bas)) and receipt['driver_sha256']==sha(git('show',FROZEN+':'+driver)))
    check('portable_execution_stderr_empty',all((portable/(name+'.stderr')).read_bytes()==b'' for name in ['vm','js']))
    report={'schema':'quds-word-vba-independent-evidence-review/v1','reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':FROZEN,'source_tree':TREE,'accepted':all(checks.values()),'checks':checks,'failed_checks':[k for k,v in checks.items() if not v],
      'gate':{'directory':str(gate),'passing_cases':len(cases),'file_count':len(names),'files':names,'per_file_cases':per_file,'declared_root_cases':roots[0]['testCount'] if len(roots)==1 else None,'hidden_completions':hidden,'failed':failed,'skipped':skipped,'input_entries':len(before['entries']),'office_vba_files':len(all_vba),'unchanged_prior_test_files':len(prior_counts),'source_commit_after':after['source_commit'],'source_tree_after':after['source_tree'],'stdout_sha256':sha(raw),'summary_sha256':sha((gate/'summary.json').read_bytes())},
      'stopped_attempts':stopped,'excluded_portable_attempts':excluded_portable,
      'portable':{'directory':str(portable),'source_commit_at_start':receipt['source_commit_at_start'],'input_entries':len(binding),'raw_stdout_bytes':len(vm),'raw_sha256':sha(vm),'canonical_sha256':sha(canonical),'semantic_result':pv,'receipt_sha256':sha((portable/'receipt.json').read_bytes())},
      'supplemental_review':{'path':str(args.supplement),'sha256':sha(args.supplement.read_bytes()),'accepted':supplement['accepted'],'static_input_entries':supplement['static']['input_count'],'formatted_files':supplement['static']['formatted_files']},
      'source_review':{'path':str(ROOT/'review_word_lists/source-review.json'),'sha256':sha((ROOT/'review_word_lists/source-review.json').read_bytes()),'confirmed_findings_fixed':len(source_review['confirmed_findings']),'unresolved_concrete_issues':source_review['unresolved_concrete_issues']},
      'issues':{'duplicate_reporter_ids':duplicates,'reporter_errors':errors,'bad_case_groups':bad_groups,'source_binding_mismatches':bad_inputs,'portable_binding_mismatches':bad_portable},
      'limits':['This independently parses existing execution evidence; no additional tests were run.','Final totals use only the explicitly selected completed final reporter stream; both stopped gates and earlier portable/development attempts are excluded.','The gate imports original test modules into one serial VM isolate. It does not recreate separate-file isolate boundaries; that isolation difference is disclosed by the gate plan.','Source identity covers complete recorded input scopes, including path additions/deletions, Git modes/types/blob IDs and content hashes. It is not runtime coverage of every file in those scopes.','No runtime qualification is claimed for incoming Mail/Flutter/provider changes outside the selected Word/Office gate.','No GitHub Actions, workflow runs or status checks were queried or awaited.']}
    args.out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'accepted':report['accepted'],'failed_checks':report['failed_checks'],'passing_cases':len(cases),'files':len(names),'inputs':len(before['entries']),'saved':str(args.out)}))
    return 0 if report['accepted'] else 1

if __name__=='__main__': raise SystemExit(main())
