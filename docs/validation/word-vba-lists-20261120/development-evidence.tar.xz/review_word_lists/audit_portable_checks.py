#!/usr/bin/env python3
"""Independently audit already completed portable/static evidence; no tests."""
import base64
import datetime
import hashlib
import json
from pathlib import Path

from audit_evidence import ROOT, REPO, entries, git, read, sha

COMMIT = '57456c602856a8ec56095352e9c1b9b17476ea69'
TREE = 'ef086f4b2fe1d5a4db86f53e2da7bf210289dba7'
PORTABLE = ROOT / 'runtime/word-lists-portable-final-v2'
STATIC = ROOT / 'runtime/final-checks-v2'


def main():
    checks = {}
    def check(label, value):
        checks[label] = bool(value)

    check('frozen_tree_identity', git('rev-parse', COMMIT+'^{tree}').decode().strip() == TREE)
    source_review = read(ROOT/'review_word_lists/source-review.json')
    check('current_source_review_bound_and_resolved', source_review['source_commit'] == COMMIT and source_review['source_tree'] == TREE and not source_review['superseded'] and not source_review['unresolved_concrete_issues'])
    receipt = read(PORTABLE/'receipt.json')
    binding = read(PORTABLE/'input-binding.json')
    vm = (PORTABLE/'vm.stdout').read_bytes()
    js = (PORTABLE/'js.stdout').read_bytes()
    value = json.loads(vm)
    canonical = json.dumps(value, sort_keys=True, separators=(',', ':')).encode()
    attempts = receipt['attempts']
    check('portable_three_commands_successful', [a['name'] for a in attempts] == ['vm', 'js-compile', 'js'] and all(a['exit_code'] == 0 for a in attempts))
    check('portable_bound_to_frozen_commit', receipt['source_commit_at_start'] == COMMIT)
    check('portable_raw_and_canonical_equal', vm == js and value == json.loads(js) and receipt['raw_equal'] is True and receipt['canonical_equal'] is True and sha(canonical) == receipt['canonical_sha256'])
    check('portable_canonical_file_exact', (PORTABLE/'canonical-result.json').read_bytes() == canonical+b'\n')
    check('portable_stderr_empty', all((PORTABLE/(a['name']+'.stderr')).read_bytes() == b'' for a in attempts))
    expected_opaque = {'cases': 4, 'allModeRollback': True, 'paragraphModeRefusals': 2, 'paragraphModePreservations': 2, 'additionalReopens': 2}
    check('portable_semantic_results', value['example']['operations'] == 8 and value['example']['revision'] == 1 and value['example']['additionalReopens'] == 2 and value['lateFailureRollback'] is True and value['opaqueBoundaryGuards'] == expected_opaque and value['fieldAndPolicyGuards'] == {'allNumberRefusalRollback': True, 'paragraphModePreservesField': True, 'policyRefusals': 2} and value['refusedSources'] == 8 and value['toggleAndChangeKind'] == {'kinds': ['decimal', 'none', 'bullet', 'decimal', 'none'], 'revision': 5})
    native = entries(COMMIT, *receipt['input_scopes'])
    check('portable_complete_path_set', set(binding) == set(native) and len(binding) == receipt['input_count'])
    bad_portable = []
    for path, info in binding.items():
        data = git('show', COMMIT+':'+path)
        mode = '100755' if int(info['mode'], 8) & 0o111 else '100644'
        if sha(data) != info['sha256'] or native[path]['mode'] != mode:
            bad_portable.append(path)
    check('portable_input_hashes_modes_match_frozen_tree', not bad_portable)
    check('portable_runner_observed_unchanged_inputs', receipt['source_inputs_unchanged_during_run'] is True)
    bas_path = 'packages/quds_office_engine/example/macros/word_lists.bas'
    driver_path = 'packages/quds_office_engine/tool/macros/web_vba_word_lists_smoke.dart'
    bas = git('show', COMMIT+':'+bas_path)
    driver = git('show', COMMIT+':'+driver_path)
    check('portable_source_driver_hashes', sha(bas) == receipt['source_sha256'] and len(bas) == receipt['source_bytes'] and sha(driver) == receipt['driver_sha256'])
    define = '-DWORD_LISTS_BAS_BASE64='
    decoded_sources = [[base64.b64decode(arg[len(define):]) for arg in a['command'] if arg.startswith(define)] for a in attempts[:2]]
    check('actual_bas_bytes_in_both_executed_commands', decoded_sources == [[bas], [bas]])
    compiled = str(PORTABLE/'word-lists-smoke.js')
    check('js_executed_same_output_path_as_compiler', compiled in attempts[1]['command'] and attempts[2]['command'][-1] == compiled and (PORTABLE/'word-lists-smoke.js').is_file())
    wrapper = read(PORTABLE/'wrapper-invocation.json')
    wrapper_source = ROOT/wrapper['wrapper_relative_path']
    check('portable_wrapper_retrospective_hash_matches', wrapper_source.stat().st_size == wrapper['wrapper_bytes'] and sha(wrapper_source.read_bytes()) == wrapper['wrapper_sha256_at_recording'])
    check('portable_wrapper_record_names_actual_output_and_success', str(PORTABLE) in wrapper['shell_command'] and wrapper['cwd'] == str(ROOT) and wrapper['observed_wrapper_exit_code'] == 0 and wrapper['executed_child_commands_receipt'] == 'receipt.json')

    before = read(STATIC/'inputs-before.json.gz')
    after = read(STATIC/'inputs-after.json.gz')
    summary = read(STATIC/'summary.json')
    check('static_before_after_source_binding', all(d['source_commit'] == COMMIT and d['source_tree'] == TREE and d['head_matches_worktree'] is True for d in [before, after, summary]))
    check('static_before_after_inputs_identical', before['entries'] == after['entries'] and before['selection'] == after['selection'] and summary['inputs_unchanged'] is True)
    native_static = entries(COMMIT, *(before['selection']['directories']+before['selection']['configuration_files']))
    check('static_complete_input_path_set', set(before['entries']) == set(after['entries']) == set(native_static) and len(native_static) == summary['input_count'])
    bad_static = []
    for path, info in before['entries'].items():
        data = git('show', COMMIT+':'+path)
        expected = {'mode': info['worktree_mode'], 'type': 'blob', 'blob': info['worktree_blob']}
        if info['head'] != native_static[path] or expected != native_static[path] or sha(data) != info['sha256'] or len(data) != info['bytes']:
            bad_static.append(path)
    check('static_input_blob_mode_length_hashes_match', not bad_static)
    check('static_summary_artifact_hashes', all((STATIC/name).is_file() and sha((STATIC/name).read_bytes()) == digest for name, digest in summary['hashes'].items()))
    analysis = read(STATIC/'analysis.json')
    formatting = read(STATIC/'format.json')
    check('static_exact_two_checks_completed', summary['completed_checks'] == ['analysis', 'format'])
    check('static_commands_bound_and_successful', all(r['source_commit'] == COMMIT and r['source_tree'] == TREE and r['cwd'] == str(REPO) and r['exit_code'] == 0 for r in [analysis, formatting]))
    check('static_raw_output_hashes', all(sha((STATIC/(name+'.stdout')).read_bytes()) == record['stdout_sha256'] and sha((STATIC/(name+'.stderr')).read_bytes()) == record['stderr_sha256'] for name, record in [('analysis', analysis), ('format', formatting)]))
    check('static_stderr_empty', all((STATIC/(name+'.stderr')).read_bytes() == b'' for name in ['analysis', 'format']))
    check('whole_engine_fatal_info_analysis_clean', analysis['command'][1:] == ['analyze', '--fatal-infos', 'packages/quds_office_engine'] and (STATIC/'analysis.stdout').read_text() == 'Analyzing quds_office_engine...\nNo issues found!\n')
    reviewed_dart = sorted(item['path'] for item in source_review['files'] if item['path'].endswith('.dart'))
    check('format_exact_seven_reviewed_dart_files', formatting['file_count'] == 7 and formatting['files'] == reviewed_dart and formatting['command'][1:4] == ['format', '--output=none', '--set-exit-if-changed'] and formatting['command'][4:] == reviewed_dart)
    check('format_raw_zero_changes', (STATIC/'format.stdout').read_text().startswith('Formatted 7 files (0 changed) in '))
    check('portable_scopes_consistent_with_static_bindings', all(path in before['entries'] and before['entries'][path]['sha256'] == info['sha256'] for path, info in binding.items()))
    report = {
        'schema': 'quds-word-vba-independent-portable-static-review/v1',
        'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': COMMIT, 'source_tree': TREE,
        'accepted': all(checks.values()), 'checks': checks,
        'failed_checks': [name for name, ok in checks.items() if not ok],
        'portable': {'directory': str(PORTABLE), 'input_count': len(binding), 'raw_stdout_bytes': len(vm), 'raw_sha256': sha(vm), 'canonical_sha256': sha(canonical), 'receipt_sha256': sha((PORTABLE/'receipt.json').read_bytes()), 'semantic_result': value},
        'portable_wrapper': {'invocation_record_sha256': sha((PORTABLE/'wrapper-invocation.json').read_bytes()), 'source_path': str(wrapper_source), 'source_sha256_at_recording': wrapper['wrapper_sha256_at_recording'], 'provenance': wrapper['provenance']},
        'static': {'directory': str(STATIC), 'input_count': len(before['entries']), 'formatted_files': formatting['files'], 'summary_sha256': sha((STATIC/'summary.json').read_bytes()), 'inputs_before_sha256': sha((STATIC/'inputs-before.json.gz').read_bytes()), 'inputs_after_sha256': sha((STATIC/'inputs-after.json.gz').read_bytes())},
        'mismatches': {'portable': bad_portable, 'static': bad_static},
        'limits': [
            'This audits existing raw outputs and manifests; no additional product tests were run.',
            'The portable runner stores its first fingerprint and an end-of-run exact-equality result, rather than a second full portable manifest. The recorded first fingerprint is independently bound here to the frozen source, and the separately recorded static before/after manifests agree for their shared inputs.',
            'The portable wrapper invocation record and source hash were recorded retrospectively by the executing root agent. This review verifies that recorded current hash and the child-command evidence; it does not treat the wrapper record as a pre-execution hash capture.',
            'This report does not qualify the still-running full regression gate. Its separate completed raw reporter stream must be audited before final regression totals are accepted.',
            'The earlier failed final portable attempt and older successful development attempt are excluded from final qualification.'
        ]
    }
    path = ROOT/'review_word_lists/portable-static-review.json'
    path.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({'accepted': report['accepted'], 'failed_checks': report['failed_checks'], 'portable_inputs': len(binding), 'static_inputs': len(before['entries']), 'saved': str(path)}))
    return 0 if report['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
