import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;
const w=OfficeNamespaces.w;
void main(){
 for(final wrapper in ['customXml','smartTag']){
 for(final opaqueEnd in [false,true]){
 final pkg=OpcPackage.create(OpcPackageKind.word);
 pkg.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="$w"><w:body><w:$wrapper w:uri="urn:example" w:element="wrapped"><w:p><w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> LISTNUM LegalDefault </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>Start</w:t></w:r></w:p></w:$wrapper><w:p><w:r><w:t>Selected result</w:t></w:r>${opaqueEnd ? '' : '<w:r><w:fldChar w:fldCharType="end"/></w:r>'}</w:p>${opaqueEnd ? '<w:$wrapper w:uri="urn:example" w:element="wrapped"><w:p><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p></w:$wrapper>' : ''}<w:sectPr/></w:body></w:document>');
 var doc=WordDeserializer().readBytes(pkg.save());
 final target=doc.paragraphs.toList().indexWhere((p)=>p.text=='Selected result');
 final before={'blocks':[for(final b in doc.sections.single.blocks)b.runtimeType.toString()],'paragraphs':[for(final p in doc.paragraphs){'text':p.text,'fields':[for(final i in p.inlines)if(i is WmlFieldBoundary)'${i.kind.name}:${i.text}']}],'target':target};
 String result;
 try{native.applyStep(doc,{'op':'removeNumbers','paragraph':target});result='accepted';}catch(e){result=e.toString();}
 final output=WordSerializer().writeBytes(doc);
 final after=OpcPackage.openBytes(output).getPart('/word/document.xml')!.readText();
 print(jsonEncode({'wrapper':wrapper,'opaqueEnd':opaqueEnd,'before':before,'result':result,'retainsLISTNUM':after.contains('LISTNUM')}));
 }
 }
}
