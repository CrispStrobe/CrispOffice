import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;
const w=OfficeNamespaces.w;
void main(){
 for(final prefix in ['w','q','']){
 final n=prefix.isEmpty?'':'$prefix:';
 final a=prefix.isEmpty?'w:':n;
 final xmlns=prefix.isEmpty?'xmlns="$w" xmlns:w="$w"':'xmlns:$prefix="$w"';
 final start='<$n' 'customXml ${a}uri="urn:example" ${a}element="wrapped"><${n}p><${n}r><${n}fldChar ${a}fldCharType="begin"/></${n}r><${n}r><${n}instrText xml:space="preserve"> LISTNUM LegalDefault </${n}instrText></${n}r><${n}r><${n}fldChar ${a}fldCharType="separate"/></${n}r><${n}r><${n}t>Start</${n}t></${n}r></${n}p></${n}customXml>';
 final end='<${n}customXml ${a}uri="urn:example" ${a}element="wrapped"><${n}p><${n}r><${n}fldChar ${a}fldCharType="end"/></${n}r></${n}p></${n}customXml>';
 final pkg=OpcPackage.create(OpcPackageKind.word);
 pkg.getPart('/word/document.xml')!.writeText('<${n}document $xmlns><${n}body>$start<${n}p><${n}r><${n}t>Selected result</${n}t></${n}r></${n}p>$end<${n}sectPr/></${n}body></${n}document>');
 final doc=WordDeserializer().readBytes(pkg.save());
 final selected=doc.paragraphs.toList().indexWhere((p)=>p.text=='Selected result');
 final blocks=[for(final block in WordTree.descendants(doc.sections.expand((s)=>s.blocks)))if(block is WmlOpaqueBlock)block.xml];
 String result;
 try{native.applyStep(doc,{'op':'removeNumbers','paragraph':selected});result='accepted';}catch(e){result=e.toString();}
 print(jsonEncode({'prefix':prefix,'selected':selected,'opaqueXml':blocks,'result':result}));
 }
}
