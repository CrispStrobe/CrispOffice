import base64,datetime,hashlib,json,os,pathlib,shutil,subprocess,time
ROOT=pathlib.Path('/workspace/scratch/c7ec4681d1f4')
REPO=ROOT/'quds_office_suite'
ENGINE=REPO/'packages/quds_office_engine'
OUT=ROOT/'runtime/development/word-lists-portable'
OUT.mkdir(exist_ok=True)
DART=str(ROOT/'runtime/dart-sdk/bin/dart')
PKG='--packages='+str(REPO/'.dart_tool/package_config.json')
BAS=ENGINE/'example/macros/word_lists.bas'
DRIVER=ENGINE/'tool/macros/web_vba_word_lists_smoke.dart'
SCOPES=['packages/quds_office_engine/lib','packages/quds_office_engine/test','packages/quds_office_engine/tool','packages/quds_office_engine/example','packages/legacy_doc_parser/lib','packages/legacy_doc_parser/pubspec.yaml','packages/quds_office_engine/pubspec.yaml','pubspec.yaml','pubspec.lock','analysis_options.yaml']
def fingerprint():
    files=[]
    for scope in SCOPES:
        p=REPO/scope
        files.extend(q for q in (p.rglob('*') if p.is_dir() else [p]) if q.is_file())
    return {str(p.relative_to(REPO)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':oct(p.stat().st_mode & 0o777)} for p in sorted(set(files))}
start=fingerprint()
(OUT/'input-binding.json').write_text(json.dumps(start,indent=2)+'\n')
source=BAS.read_bytes()
define='-DWORD_LISTS_BAS_BASE64='+base64.b64encode(source).decode()
js=OUT/'word-lists-smoke.js'
commands=[('vm',[DART,'--old_gen_heap_size=512',PKG,define,str(DRIVER)]),('js-compile',[DART,'compile','js','-O1',PKG,define,'-o',str(js),str(DRIVER)]),('js',[shutil.which('node'),'-e','globalThis.self = globalThis; require(process.argv[1]);',str(js)])]
receipt={'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit_at_start':subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip(),'source_sha256':hashlib.sha256(source).hexdigest(),'source_bytes':len(source),'driver_sha256':hashlib.sha256(DRIVER.read_bytes()).hexdigest(),'input_scopes':SCOPES,'input_count':len(start),'attempts':[]}
for name,command in commands:
    before=time.monotonic()
    with (OUT/(name+'.stdout')).open('wb') as stdout,(OUT/(name+'.stderr')).open('wb') as stderr:
        result=subprocess.run(command,cwd=ENGINE,stdout=stdout,stderr=stderr)
    receipt['attempts'].append({'name':name,'command':command,'exit_code':result.returncode,'seconds':round(time.monotonic()-before,3)})
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'name':name,'exit_code':result.returncode,'seconds':receipt['attempts'][-1]['seconds']}),flush=True)
    if result.returncode:
        print((OUT/(name+'.stderr')).read_text())
        raise SystemExit(result.returncode)
a=(OUT/'vm.stdout').read_bytes();b=(OUT/'js.stdout').read_bytes()
canonical_a=json.dumps(json.loads(a),sort_keys=True,separators=(',',':')).encode()
canonical_b=json.dumps(json.loads(b),sort_keys=True,separators=(',',':')).encode()
receipt.update(raw_equal=a==b,canonical_equal=canonical_a==canonical_b,canonical_sha256=hashlib.sha256(canonical_a).hexdigest(),source_inputs_unchanged_during_run=start==fingerprint())
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(OUT/'canonical-result.json').write_bytes(canonical_a+b'\n')
print(json.dumps({k:receipt[k] for k in ['raw_equal','canonical_equal','canonical_sha256','source_inputs_unchanged_during_run']}),flush=True)
assert receipt['raw_equal'] and receipt['canonical_equal']
