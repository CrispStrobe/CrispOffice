    // @dart=3.12

    import 'dart:isolate';

    import 'package:test_core/src/bootstrap/vm.dart';

    import 'file:///workspace/scratch/c7ec4681d1f4/runtime/word-office-gate-final/word_office_gate_test.dart' as test;

    // This variable is read at runtime through the VM service and is unsafe to
    // remove.
    const packageConfigLocation = 'file:///workspace/scratch/c7ec4681d1f4/quds_office_suite/.dart_tool/package_config.json';

    void main(_, SendPort sendPort) {
      internalBootstrapVmTest(() => test.main, sendPort);
    }
  