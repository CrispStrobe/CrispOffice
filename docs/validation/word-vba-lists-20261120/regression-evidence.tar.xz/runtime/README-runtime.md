# Pure Dart validation runtime

Dart 3.14.1 is in `dart-sdk/`. The SDK archive SHA-256 and all 56 hosted package versions are recorded in `environment.json`; every hosted version matches the repository lockfile.

Dependency resolution used copied engine/parser manifests under `engine-validation/packages/`, with the copied workspace declarations removed and exact hosted version overrides. No tracked repository manifest was changed. The ignored repository root `.dart_tool/package_config.json` remaps the two local package roots to the actual repository checkout, so tests and analysis consume current source directly. The copied package graph is installed alongside it.

From `/workspace/scratch/c7ec4681d1f4`:

```sh
source runtime/env.sh
runtime/run-engine-tests.sh --reporter=json test/office_vba_word_tabstops_test.dart
dart analyze --fatal-infos quds_office_suite/packages/quds_office_engine
dart format --output=none --set-exit-if-changed path/to/changed.dart
dart compile js --packages=quds_office_suite/.dart_tool/package_config.json path/to/driver.dart -o runtime/driver.js
node runtime/driver.js
```

The test wrapper sets the original engine directory as cwd and invokes a precompiled test runner kernel with `--compiler source --concurrency=1 --timeout=4x --fail-fast`. It avoids implicit Flutter workspace dependency resolution while preserving source package identities.

Setup was checked with one existing TabStops compiler case (passed) and strict analysis of the unchanged StepInput source (no issues). See `setup-receipt.json` and raw setup logs. These setup checks do not qualify feature edits in progress.
