import datetime
import importlib.util
import json
import pathlib
import subprocess
import time

ROOT = pathlib.Path('/workspace/scratch/c7ec4681d1f4')
REPO = ROOT / 'quds_office_suite'
OUT = ROOT / 'runtime/final-checks-v2'
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('gate', ROOT / 'runtime/word_office_gate.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
before = gate.source_manifest()
assert before['head_matches_worktree']
gate.save(OUT / 'inputs-before.json.gz', before)
dart = str(ROOT / 'runtime/dart-sdk/bin/dart')
files = [name for name in subprocess.check_output(
    ['git', 'diff', '--name-only', '79e11935e16ea1d2fa576ead0712c83f22e15c28', 'HEAD', '--', 'packages/quds_office_engine'],
    cwd=REPO, text=True,
).splitlines() if name.endswith('.dart')]
commands = [
    ('analysis', [dart, 'analyze', '--fatal-infos', 'packages/quds_office_engine']),
    ('format', [dart, 'format', '--output=none', '--set-exit-if-changed', *files]),
]
for name, command in commands:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    began = time.monotonic()
    with (OUT / (name + '.stdout')).open('wb') as stdout, (OUT / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(command, cwd=REPO, stdout=stdout, stderr=stderr)
    receipt = dict(source_commit=before['source_commit'], source_tree=before['source_tree'],
                   command=command, cwd=str(REPO), started_at_utc=started,
                   seconds=round(time.monotonic() - began, 3), exit_code=result.returncode,
                   stdout_sha256=gate.digest((OUT / (name + '.stdout')).read_bytes()),
                   stderr_sha256=gate.digest((OUT / (name + '.stderr')).read_bytes()))
    if name == 'format':
        receipt.update(files=files, file_count=len(files))
    gate.save(OUT / (name + '.json'), receipt)
    print(json.dumps({'check': name, 'exit_code': result.returncode, 'seconds': receipt['seconds']}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
after = gate.source_manifest()
gate.save(OUT / 'inputs-after.json.gz', after)
assert before == after
summary = dict(source_commit=before['source_commit'], source_tree=before['source_tree'],
               head_matches_worktree=True, inputs_unchanged=True, input_count=len(before['entries']),
               completed_checks=['analysis', 'format'],
               hashes={p.name: gate.digest(p.read_bytes()) for p in sorted(OUT.iterdir()) if p.is_file()})
gate.save(OUT / 'summary.json', summary)
print(json.dumps({'complete': True, 'inputs_unchanged': True, 'file_count': len(files)}), flush=True)
