#!/usr/bin/env python3
"""Prepare/run the Word/Office source gate; never changes repository source."""
from __future__ import annotations

import argparse
import collections
import datetime as dt
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
RUNTIME = ROOT / "runtime"
REPO = ROOT / "quds_office_suite"
ENGINE = REPO / "packages/quds_office_engine"
PRIOR = REPO / "docs/validation/word-vba-tabstops-20261120/regression.json"
PREFIXES = [
    "packages/quds_office_engine/lib",
    "packages/quds_office_engine/test",
    "packages/quds_office_engine/tool",
    "packages/quds_office_engine/example",
    "packages/legacy_doc_parser/lib",
]
CONFIGS = [
    "pubspec.yaml", "pubspec.lock", "analysis_options.yaml",
    "packages/quds_office_engine/pubspec.yaml",
    "packages/quds_office_engine/analysis_options.yaml",
    "packages/legacy_doc_parser/pubspec.yaml",
    "packages/legacy_doc_parser/analysis_options.yaml",
]


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=REPO, text=True).strip()


def save(path: Path, value: object) -> None:
    data = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix == ".gz":
        with gzip.open(path, "wb") as out:
            out.write(data)
    else:
        path.write_bytes(data)


def selected_files() -> tuple[list[str], dict[str, object]]:
    prior = json.loads(PRIOR.read_text())
    names = {name for group in prior["groups"] for name in group["files"]}
    names.update(p.name for p in (ENGINE / "test").glob("office_vba_*_test.dart"))
    names.add("office_macro_word_list_format_test.dart")
    return sorted(names), prior


def source_manifest() -> dict[str, object]:
    names = {p for p in CONFIGS if (REPO / p).is_file()}
    for prefix in PREFIXES:
        names.update(str(p.relative_to(REPO)) for p in (REPO / prefix).rglob("*") if p.is_file())
    raw_tree = subprocess.check_output(
        ["git", "ls-tree", "-rz", "HEAD", "--", *PREFIXES, *CONFIGS], cwd=REPO,
    )
    tree = {}
    for record in raw_tree.split(b"\0"):
        if not record:
            continue
        metadata, path = record.split(b"\t", 1)
        mode, kind, blob = metadata.decode().split()
        tree[path.decode()] = {"mode": mode, "type": kind, "blob": blob}
    assert set(tree) <= names, "Tracked input missing from the worktree"
    entries = {}
    for name in sorted(names):
        path = REPO / name
        assert not path.is_symlink(), f"Input symlink requires separate target identity: {name}"
        data = path.read_bytes()
        blob = hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
        mode = "100755" if path.stat().st_mode & 0o111 else "100644"
        entries[name] = {"bytes": len(data), "sha256": digest(data),
                         "worktree_mode": mode, "worktree_blob": blob,
                         "head": tree.get(name)}
    matches_head = all(
        entry["head"] == {"mode": entry["worktree_mode"], "type": "blob", "blob": entry["worktree_blob"]}
        for entry in entries.values()
    )
    return {"source_commit": git("rev-parse", "HEAD"), "source_tree": git("rev-parse", "HEAD^{tree}"),
            "selection": {"directories": PREFIXES, "configuration_files": CONFIGS},
            "head_matches_worktree": matches_head, "entries": entries}


def runtime_manifest(harness: Path) -> dict[str, object]:
    paths = [Path(__file__), harness, RUNTIME / "env.sh", RUNTIME / "run-engine-tests.sh",
             RUNTIME / "test-runner/test-runner.dill", RUNTIME / "environment.json",
             REPO / ".dart_tool/package_config.json", REPO / ".dart_tool/package_graph.json",
             RUNTIME / "engine-validation/packages/quds_office_engine/pubspec.yaml",
             RUNTIME / "engine-validation/packages/quds_office_engine/pubspec.lock",
             RUNTIME / "engine-validation/packages/legacy_doc_parser/pubspec.yaml"]
    return {str(p): {"bytes": p.stat().st_size, "sha256": digest(p.read_bytes())} for p in paths}


def prepare(out: Path) -> dict[str, object]:
    out.mkdir(parents=True, exist_ok=True)
    names, prior = selected_files()
    reviewed = []
    for name in names:
        path = ENGINE / "test" / name
        source = path.read_text()
        assert re.search(r"^void main\(\)\s*\{", source, re.M), f"Nonstandard main: {name}"
        assert not re.search(r"^@(TestOn|Timeout|Tags|Skip|OnPlatform)\b", source, re.M), name
        reviewed.append({"file": name, "sha256": digest(path.read_bytes()),
                         "synchronous_main": True, "library_test_metadata": False})
    for config in [REPO / "dart_test.yaml", ENGINE / "dart_test.yaml"]:
        assert not config.exists(), f"Test configuration requires review: {config}"
    imports = ["import 'package:test/test.dart';", ""]
    imports.extend(f"import '{(ENGINE / 'test' / name).as_uri()}' as suite{i};" for i, name in enumerate(names))
    body = ["", "void main() {"]
    body.extend(f"  group('{name}', suite{i}.main);" for i, name in enumerate(names))
    harness = out / "word_office_gate_test.dart"
    harness.write_text("\n".join(imports + body + ["}", ""]))
    plan = {
        "files": names,
        "harness": str(harness), "harness_sha256": digest(harness.read_bytes()),
        "file_count": len(names), "previous_file_count": prior["file_count"],
        "previous_source_commit": prior["source_commit"],
        "previous_per_file_cases": prior["per_file_cases"],
        "reviewed_modules": reviewed,
        "execution": "One VM suite, original test modules imported as separate Dart libraries and registered under a filename group; original engine cwd; serial cases.",
        "preserved": ["Original test module source and private library globals", "Per-file setup/teardown scopes", "Nested groups and per-test timeouts", "Fixture paths and CLI subprocess source paths"],
        "isolation_difference": "Modules share one VM isolate and process-wide caches. This does not claim the original separate-file isolate boundary. No selected test mutates shared engine configuration; native ListFormat cases use fresh documents.",
        "metadata_review": "No library-level test metadata or dart_test.yaml; all module main functions are synchronous. Registration retains every original test, adding only its filename prefix.",
    }
    save(out / "plan.json", plan)
    return plan


def validate_events(events: list[dict[str, object]], names: list[str]) -> dict[str, object]:
    problems = []
    starts, dones, groups, suites = {}, {}, {}, {}
    errors = []
    for event in events:
        kind = event.get("type")
        if kind == "testStart":
            test = event["test"]
            if test["id"] in starts:
                problems.append(f"Duplicate testStart {test['id']}")
            starts[test["id"]] = test
        elif kind == "testDone":
            if event["testID"] in dones:
                problems.append(f"Duplicate testDone {event['testID']}")
            dones[event["testID"]] = event
        elif kind == "group":
            group = event["group"]
            if group["id"] in groups:
                problems.append(f"Duplicate group {group['id']}")
            groups[group["id"]] = group
        elif kind == "suite":
            suite = event["suite"]
            suites[suite["id"]] = suite
        elif kind == "error":
            errors.append(event)
    if set(starts) != set(dones):
        problems.append("Test start/completion IDs do not match")
    if len(suites) != 1 or any(s["platform"] != "vm" for s in suites.values()):
        problems.append("Expected exactly one VM suite")
    if not events or events[-1].get("type") != "done" or events[-1].get("success") is not True:
        problems.append("Missing successful final done event")
    if errors:
        problems.append(f"{len(errors)} reporter errors")
    per_file = {name: 0 for name in names}
    declared = {}
    for group in groups.values():
        if group["name"] in per_file:
            if group["name"] in declared:
                problems.append(f"Duplicate filename group: {group['name']}")
            declared[group["name"]] = group["testCount"]
    case_occurrences = collections.Counter()
    cases = []
    hidden = skipped = failed = 0
    for test_id, result in dones.items():
        test = starts.get(test_id)
        if result["result"] != "success":
            failed += 1
        if result.get("skipped") or (test or {}).get("metadata", {}).get("skip"):
            skipped += 1
        if result.get("hidden"):
            hidden += 1
            continue
        if test is None:
            continue
        file_groups = [groups[g]["name"] for g in test["groupIDs"] if g in groups and groups[g]["name"] in per_file]
        if len(file_groups) != 1:
            problems.append(f"Case has no unique filename group: {test['name']}")
            continue
        name = file_groups[0]
        prefix = name + " "
        if not test["name"].startswith(prefix):
            problems.append(f"Filename prefix missing: {test['name']}")
        original_name = test["name"][len(prefix):]
        case_occurrences[name, original_name] += 1
        cases.append({"file": name, "name": original_name, "occurrence": case_occurrences[name, original_name],
                      "test_id": test_id, "result": result["result"], "skipped": result.get("skipped", False)})
        per_file[name] += 1
    if set(declared) != set(names):
        problems.append("Declared filename groups do not match complete selected file set")
    for name, count in per_file.items():
        if count < 1 or count != declared.get(name):
            problems.append(f"{name}: completed {count}, declared {declared.get(name)}")
    roots = [g for g in groups.values() if g["parentID"] is None]
    if len(roots) != 1 or roots[0]["testCount"] != sum(per_file.values()):
        problems.append("Root suite count differs from completed file totals")
    if failed or skipped:
        problems.append(f"Failed={failed}; skipped={skipped}")
    return {"accepted": not problems, "problems": problems, "passing_cases": len(cases) - sum(c["result"] != "success" or c["skipped"] for c in cases),
            "failed_cases": failed, "skipped_cases": skipped, "hidden_completions": hidden,
            "per_file_cases": per_file, "declared_per_file_cases": declared,
            "case_identity": ["file", "name", "occurrence"], "cases": cases, "errors": errors}


def run(out: Path) -> int:
    assert not (out / "stdout.jsonl").exists(), "Use a new output directory; prior evidence is retained"
    plan = prepare(out)
    before = source_manifest()
    for module in plan["reviewed_modules"]:
        path = "packages/quds_office_engine/test/" + module["file"]
        assert before["entries"][path]["sha256"] == module["sha256"], f"Test source changed during preparation: {path}"
    before["runtime_inputs"] = runtime_manifest(Path(plan["harness"]))
    save(out / "inputs-before.json.gz", before)
    command = [str(RUNTIME / "run-engine-tests.sh"), "--reporter=json", plan["harness"]]
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    save(out / "command.json", {"argv": command, "cwd": str(ENGINE), "started_utc": started,
                                "runner_sha256": digest((RUNTIME / "run-engine-tests.sh").read_bytes()),
                                "collector_sha256": digest(Path(__file__).read_bytes())})
    began = time.monotonic()
    with (out / "stdout.jsonl").open("wb") as stdout, (out / "stderr.log").open("wb") as stderr:
        result = subprocess.run(command, cwd=ENGINE, stdout=stdout, stderr=stderr)
    after = source_manifest()
    after["runtime_inputs"] = runtime_manifest(Path(plan["harness"]))
    save(out / "inputs-after.json.gz", after)
    try:
        events = [json.loads(line) for line in (out / "stdout.jsonl").read_text().splitlines() if line.strip()]
        summary = validate_events(events, plan["files"])
    except (ValueError, KeyError, TypeError) as error:
        summary = {"accepted": False, "problems": [f"Malformed reporter log: {error}"]}
    problems = summary["problems"]
    unchanged = before["entries"] == after["entries"] and before["runtime_inputs"] == after["runtime_inputs"]
    if not unchanged:
        problems.append("Source input content, identities, or complete path set changed during execution")
    if result.returncode:
        problems.append(f"Test runner exit code {result.returncode}")
    old_tree = git("ls-tree", "-r", plan["previous_source_commit"], "--", "packages/quds_office_engine/test")
    prior_blobs = {line.split("\t", 1)[1]: line.split()[2] for line in old_tree.splitlines()}
    checks = {}
    for name, expected in plan["previous_per_file_cases"].items():
        path = "packages/quds_office_engine/test/" + name
        if before["entries"][path]["worktree_blob"] == prior_blobs.get(path):
            actual = summary.get("per_file_cases", {}).get(name)
            checks[name] = {"previous": expected, "current": actual, "matches": expected == actual}
            if expected != actual:
                problems.append(f"Unchanged test file case count changed: {name}")
    cases = summary.pop("cases", [])
    save(out / "cases.json.gz", cases)
    summary.update({"accepted": not problems, "complete": not problems, "file_count": len(plan["files"]),
                    "source_commit": before["source_commit"], "source_tree": before["source_tree"],
                    "head_matches_worktree": before["head_matches_worktree"],
                    "started_utc": started, "finished_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                    "seconds": round(time.monotonic() - began, 3), "exit_code": result.returncode,
                    "inputs_unchanged": unchanged, "input_entries": len(before["entries"]),
                    "same_source_test_count_checks": checks,
                    "execution": plan["execution"], "isolation_difference": plan["isolation_difference"],
                    "hashes": {p.name: digest(p.read_bytes()) for p in sorted(out.iterdir()) if p.is_file()}})
    save(out / "summary.json", summary)
    print(json.dumps({k: summary.get(k) for k in ["complete", "file_count", "passing_cases", "failed_cases", "skipped_cases", "input_entries", "inputs_unchanged", "seconds", "problems"]}), flush=True)
    return 0 if summary["complete"] else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["prepare", "run"])
    parser.add_argument("--out", type=Path, default=RUNTIME / "word-office-gate")
    args = parser.parse_args()
    out = args.out.resolve()
    if args.action == "prepare":
        plan = prepare(out)
        print(json.dumps({"file_count": plan["file_count"], "harness": plan["harness"], "started": False}))
        return 0
    return run(out)


if __name__ == "__main__":
    raise SystemExit(main())
