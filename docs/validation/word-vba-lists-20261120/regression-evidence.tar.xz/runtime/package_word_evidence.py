"""Package completed, source-bound local qualification in the repository."""
import datetime
import gzip
import hashlib
import io
import json
import pathlib
import shutil
import subprocess
import tarfile

ROOT = pathlib.Path('/workspace/scratch/c7ec4681d1f4')
REPO = ROOT / 'quds_office_suite'
DEST = REPO / 'docs/validation/word-vba-lists-20261120'
GATE = ROOT / 'runtime/word-office-gate-final-v3'
PORTABLE = ROOT / 'runtime/word-lists-portable-final-v2'
STATIC = ROOT / 'runtime/final-checks-v2'
REVIEW = ROOT / 'review_word_lists'
RECON = ROOT / 'reconciliation_work'

def read(path):
    return json.loads(path.read_text())

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write(name, value):
    (DEST / name).write_text(json.dumps(value, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

gate = read(GATE / 'summary.json')
portable = read(PORTABLE / 'receipt.json')
static = read(STATIC / 'summary.json')
review = read(REVIEW / 'evidence-review.json')
source_review = read(REVIEW / 'source-review.json')
intake = read(RECON / 'final-intake.json')
capture = read(RECON / 'final-capture.json')
mail_continuation = read(RECON / 'incoming-mail-continuation-review.json')
assert gate['accepted'] and gate['complete'] and gate['inputs_unchanged']
assert gate['head_matches_worktree'] and gate['failed_cases'] == gate['skipped_cases'] == 0
assert gate['passing_cases'] == 2292 and gate['file_count'] == 62 and gate['input_entries'] == 1118
assert portable['raw_equal'] and portable['canonical_equal'] and portable['source_inputs_unchanged_during_run']
assert all(a['exit_code'] == 0 for a in portable['attempts'])
assert static['inputs_unchanged'] and static['head_matches_worktree']
assert review['accepted'] and not source_review['unresolved_concrete_issues'] and not source_review['superseded']
assert not intake['uncovered_ref_entries'] and intake['all_historical_proofs_verified']
assert intake['capture_sha256'] == digest((RECON / 'final-capture.json').read_bytes())
assert intake['target_commit'] == git('rev-parse', 'HEAD').decode().strip()
assert mail_continuation['integration_complete'] and mail_continuation['qualified_inputs_equal']

before = json.loads(gzip.decompress((GATE / 'inputs-before.json.gz').read_bytes()))
scopes = before['selection']['directories'] + before['selection']['configuration_files']
entries = {}
for record in git('ls-tree', '-rz', 'HEAD', '--', *scopes).split(b'\0'):
    if not record:
        continue
    metadata, path = record.split(b'\t', 1)
    mode, kind, blob = metadata.decode().split()
    entries[path.decode()] = dict(mode=mode, type=kind, blob=blob)
expected = {p: e['head'] for p, e in before['entries'].items()}
assert entries == expected
input_digest = digest(json.dumps(entries, sort_keys=True, separators=(',', ':')).encode())

DEST.mkdir(exist_ok=True)
regression = dict(gate, groups=[dict(name='Complete Word and Office regression selection', files=sorted(gate['per_file_cases']))])
write('regression.json', regression)
write('portable.json', portable)
write('portable-result.json', read(PORTABLE / 'canonical-result.json'))
for name in ['analysis.json', 'format.json']:
    shutil.copyfile(STATIC / name, DEST / name)
for name in ['source-review.json', 'portable-static-review.json', 'evidence-review.json']:
    shutil.copyfile(REVIEW / name, DEST / name)
for name in ['final-capture.json', 'final-intake.json', 'incoming-mail-review.json',
             'incoming-mail-continuation-review.json']:
    shutil.copyfile(RECON / name, DEST / name)
shutil.copyfile(ROOT / 'runtime/environment.json', DEST / 'environment.json')
write('qualified-inputs.json', dict(
    source_commit=gate['source_commit'], source_tree=gate['source_tree'],
    compared_commit=git('rev-parse', 'HEAD').decode().strip(),
    input_count=len(entries), complete_path_sets_equal=True, modes_types_and_git_objects_equal=True,
    canonical_input_manifest_sha256=input_digest,
    manifest_definition='UTF-8 JSON sorted by path and key, compact separators; values are Git mode/type/blob objects.',
    source_manifest='regression-evidence.tar.xz:runtime/word-office-gate-final-v3/inputs-before.json.gz',
    guarantee='All qualified input paths, modes, types and Git blob identities are retained. Publication and remote-main verification repeat this comparison after evidence-only or disjoint incoming changes.',
))

archive_members = {}

def archive(name, paths, exclude_names=()):
    files = {}
    for item in paths:
        assert item.exists(), item
        candidates = item.rglob('*') if item.is_dir() else [item]
        for path in candidates:
            if path.is_file() and path.name not in exclude_names:
                files[str(path.relative_to(ROOT))] = path
    records = []
    with tarfile.open(DEST / name, 'w:xz', preset=6) as tar:
        for member, path in sorted(files.items()):
            data = path.read_bytes()
            info = tarfile.TarInfo(member)
            info.size = len(data)
            info.mode = 0o755 if path.stat().st_mode & 0o111 else 0o644
            info.mtime = 0
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            tar.addfile(info, io.BytesIO(data))
            records.append(dict(path=member, bytes=len(data), sha256=digest(data)))
    archive_members[name] = records

runtime_files = [ROOT / 'runtime' / name for name in [
    'word_office_gate.py', 'run-engine-tests.sh', 'env.sh', 'environment.json',
    'README-runtime.md', 'setup-receipt.json', 'setup-smoke.jsonl', 'setup-smoke.stderr',
    'setup-analysis.stdout', 'setup-analysis.stderr', 'reproduce_runtime.py',
    'runtime-build-command.json', 'run-final-analysis-format.py', 'package_word_evidence.py',
    'engine-validation/packages/quds_office_engine/pubspec.yaml',
    'engine-validation/packages/quds_office_engine/pubspec.lock',
    'engine-validation/packages/legacy_doc_parser/pubspec.yaml',
]]
archive('regression-evidence.tar.xz', [GATE, STATIC, *runtime_files,
    REPO / '.dart_tool/package_config.json', REPO / '.dart_tool/package_graph.json'])
archive('portable-evidence.tar.xz', [PORTABLE, ROOT / 'runtime/development/run-word-lists-portable.py'])
development = [ROOT / 'runtime' / name for name in [
    'word-office-gate-final', 'word-office-gate-final-v2', 'word-lists-portable-final',
    'development/word-lists-portable', 'development/compiler-tests.jsonl',
    'development/compiler-tests.stderr', 'development/word-lists-integration-final.jsonl',
    'development/word-lists-integration-final.stderr',
]]
development += [p for p in RECON.iterdir() if p.name.startswith(('native-', 'portable-list-'))]
development += [p for p in REVIEW.iterdir() if p.is_file() and p.name not in [
    'source-review.json', 'evidence-review.json', 'portable-static-review.json']]
archive('development-evidence.tar.xz', development,
        exclude_names=['word-lists-smoke.js', 'word-lists-smoke.js.map', 'word-lists-smoke.js.deps'])
archive('reconciliation-evidence.tar.xz', [RECON / name for name in [
    'capture_remotes.py', 'audit_refreshed_capture.py', 'verify_qualified_tree.py', 'initial-capture.json',
    'initial-intake.json', 'integration-review.json', 'final-capture.json',
    'final-intake.json', 'incoming-mail-review.json', 'incoming-mail-continuation-review.json']])
write('archive-members.json', archive_members)

counts = {kind: len(capture[kind]) for kind in ['branches', 'pull_requests', 'upstream']}
new_counts = {name: gate['per_file_cases'][name] for name in [
    'office_vba_word_lists_test.dart', 'office_macro_word_list_format_test.dart',
    'office_vba_word_lists_integration_test.dart']}
assert sum(new_counts.values()) == 178
write('qualification.json', dict(
    recorded_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_commit=gate['source_commit'], source_tree=gate['source_tree'],
    accepted=True, github_actions_used=False,
    regression=dict(passing_cases=gate['passing_cases'], files=gate['file_count'], failed=0,
                    skipped=0, input_count=gate['input_entries'], inputs_unchanged=True,
                    new_cases=new_counts, unchanged_previous_cases=2114),
    portable=dict(raw_equal=True, raw_bytes=len((PORTABLE / 'vm.stdout').read_bytes()),
                  canonical_equal=True, canonical_sha256=portable['canonical_sha256'],
                  source_sha256=portable['source_sha256'], input_count=portable['input_count']),
    analysis='Whole engine, --fatal-infos, exit 0, no issues found',
    format=dict(changed_dart_files=7, changes=0, exit_code=0),
    independent_source_review='No unresolved concrete issue; two field-span findings corrected',
    independent_evidence_review='Accepted; raw reporter and byte/hash identities recomputed',
    captured_inventory=counts, uncovered_captured_heads=0,
    qualification_input_manifest_sha256=input_digest,
    excluded_attempts=['Stopped full gate v1: 162 partial cases, exit 130',
                       'Stopped full gate v2: 600 partial cases, exit 130',
                       'Failed first final portable run and older development checks'],
    scope_limit=gate['isolation_difference'],
))

readme = f'''# Word VBA paragraph list formatting — local qualification

## Qualified result

The completed qualification is bound to source commit
`{gate['source_commit']}` and tree `{gate['source_tree']}`.
The working branch is `codex/word-vba-compat-20261120-next`. GitHub Actions,
workflow runs and status checks were neither queried nor awaited.

| Check | Result |
| --- | --- |
| Word/Office regression selection | **2,292 passing cases across 62 original test modules; zero failures, skips or reporter errors** |
| New ListFormat cases, included above | 95 compiler + 61 native + 22 integration = **178** |
| Existing unchanged regression modules | All 59 modules retain their previous per-file counts, totaling 2,114 cases |
| Source binding | Complete set of **1,118** inputs, with exact modes, Git blobs and SHA-256; unchanged during execution |
| Strict analysis | Entire engine, `--fatal-infos`, exit 0, no issues |
| Formatting | All seven changed Dart files, zero changes |
| Actual BAS on VM and compiled JavaScript | All commands exit 0; raw 1,176-byte outputs and canonical results are identical |
| Independent review | Source review and raw-evidence audit accepted; no unresolved concrete finding |

See [qualification.json](qualification.json), [regression.json](regression.json),
[portable.json](portable.json), [analysis.json](analysis.json), and
[format.json](format.json). Counts include each original test case once; focused
reruns, setup smoke tests and interrupted/development attempts are not added.

## Behavior and coverage

The [Word contract](../../VBA_WORD_MACROS.md#paragraph-list-formatting) defines
typed `Paragraph.Range.ListFormat` selectors, aliases, required `ByVal` helpers,
nested `With`, named optional arguments and statement/`Call` forms for
`ApplyBulletDefault`, `ApplyNumberDefault` and `RemoveNumbers`.

Native operations inspect the input document at execution time for matching-kind
toggles. They allocate collision-safe default definitions, preserve imported
numbering, write persistent suppression when clearing, retain indentation on
removal, and preserve unrelated content. Source guards reject ambiguous numbering and requests
that cannot preserve field semantics before mutation or detached publication.

The actual [word_lists.bas](../../../packages/quds_office_engine/example/macros/word_lists.bas)
executes eight native steps as one revision and survives two additional reopens.
The portable driver also checks changing list kinds, late rollback, policy
refusal, selected LISTNUM refusal, four opaque-boundary cases, and eight rejected
source forms. The opaque cases separately assert two paragraph-mode refusals
with original bytes intact and two fully opaque field-preservation results with
every native field token retained. The canonical result SHA-256 is
`{portable['canonical_sha256']}`; see [portable-result.json](portable-result.json).

Independent review exposed two concrete field-span problems during development:
all-number removal overlooked boundaries hidden in opaque containers, and an
existing serializer rule could discard a modeled closing boundary whose opening
was opaque. The first is guarded by opaque field scanning. All new list methods
also use the serializer's own unbalanced-boundary predicate before mutation,
across body, header/footer, note and comment stories. The serializer itself is
unchanged. Full marker-sequence checks replace the earlier instruction-only
preservation assertion. See [source-review.json](source-review.json).

## Execution and evidence limits

The gate imports the 62 original test modules as separate Dart libraries into
one generated suite, grouping each under its filename. It preserves the original
module source, private library globals, setup/teardown scopes, nested groups,
per-test timeouts, fixture cwd and actual CLI subprocesses. All 44 `office_vba_*`
modules are selected together with 18 native/style/fidelity/preservation/ODT
modules. No selected file has library-level test metadata or a `dart_test.yaml`.

**The modules share one VM isolate and process-wide caches. This does not claim
the original separate-file isolate boundary.** The raw collector checks complete
start/done pairs, unique identities, every declared filename group, matching
per-file and root totals, final success, zero skips/errors, and unchanged source
and runtime input manifests. The independent reviewer recomputes these checks.

Dart 3.14.1 and 56 hosted dependency versions exactly matching the repository
lockfile were used. Only copied dependency manifests had workspace declarations
removed; package roots point to original checkout source. No tracked manifest
or dependency lock was modified for setup. [environment.json](environment.json)
records SDK and package identities. The reproduction helper is reconstructed
from executed setup steps and syntax-checked, not rerun as an additional gate.

The first two full-gate attempts were interrupted after 162 and 600 partial cases
when later checks found source changes were needed. Both exited 130. The first
final portable attempt failed the field-token assertion described above. These
attempts and earlier development checks remain in the development archive and
are explicitly **excluded** from the qualified totals.

## Remote source reconciliation

The initial intake preserved main `5c48058bedc42dd8cbf3fb9d6f1fb492b2ac1eb8` and
the subsequent Zotero test-label continuation at
`79e11935e16ea1d2fa576ead0712c83f22e15c28`.
The initial capture had 19 fork heads, 257 existing PR heads and four upstream
heads. The final capture at `{capture['captured_at_utc']}` accounts for
**{counts['branches']} fork heads, {counts['pull_requests']} existing PR heads and
{counts['upstream']} upstream heads, with zero uncovered heads**.

Fourteen historical equivalence proofs were recomputed: thirteen full-tree
identities and one exact 37-changed-path ODT continuation equivalence, each with
an accepted ancestor. New Mail account intake at `9c4fbb2b` and implementation at
`63ff7f238c6c2871082cc4dc557552a04aecde68` were merged with their histories.
At integration checkpoint `57456c60`, all 17 incoming implementation paths
matched source `63ff7f23` exactly and overlapped none of the Word qualification
inputs. The later Mail continuation at
`{mail_continuation['integrated_commit']}` also preserves the Word checkpoint
and all 1,118 qualified inputs. Its {mail_continuation['continuation']['path_count']}
changed paths are recorded separately. These checks prove inclusion; the Word
gate does not qualify Mail store/provider/Flutter runtimes.

See [final-capture.json](final-capture.json), [final-intake.json](final-intake.json),
[incoming-mail-review.json](incoming-mail-review.json),
[incoming-mail-continuation-review.json](incoming-mail-continuation-review.json)
and the initial records.
[qualified-inputs.json](qualified-inputs.json) records the complete qualified
path/mode/blob comparison. It is repeated against the final publication and
remote main so later evidence or disjoint reconciliation changes cannot silently
replace tested engine inputs.

## Evidence files

| Archive | Contents |
| --- | --- |
| [regression-evidence.tar.xz](regression-evidence.tar.xz) | Completed reporter stream, case identities, source/runtime before/after manifests, generated harness, collector, analysis/format logs, exact setup/build records and reproduction helper |
| [portable-evidence.tar.xz](portable-evidence.tar.xz) | Used portable runner, retrospective wrapper-invocation receipt, exact child/BAS payload commands, input binding, VM/compiler/JavaScript logs, generated JavaScript, and canonical result |
| [development-evidence.tar.xz](development-evidence.tar.xz) | Explicitly superseded attempts, failing probes, focused development logs and independent review probes |
| [reconciliation-evidence.tar.xz](reconciliation-evidence.tar.xz) | Initial/final remote captures, inclusion/equivalence audits and exact audit scripts |

[archive-members.json](archive-members.json) gives byte counts and SHA-256 for
every archived file; [evidence-files.json](evidence-files.json) hashes the delivered
evidence files. The SDK, package cache and runner binary are omitted; their
versions/hashes and the exact kernel build command are recorded. Archives retain
original workspace-relative paths and commands. The gate helper expects a root
containing `quds_office_suite/` and `runtime/`; the setup helper supports creating
that layout in a fresh environment. Extraction alone does not install runtimes.

## Compatibility boundary

This remains a bounded VBA source adapter. New defaults use Quds geometry
(18-point left, 9-point hanging); clearing retains indentation. Only omitted/
Word8 default behavior is supported. Live collection/property reads, arbitrary
Word ranges, customized galleries/templates, outline application, indent/outdent,
COM and embedded VBA execution remain outside this increment. Existing supported
table-style inheritance layers are reused. Ambiguous or lossy field/numbering
sources may be refused conservatively across the document.
'''
(DEST / 'README.md').write_text(readme)
write('evidence-files.json', {p.name: dict(bytes=p.stat().st_size, sha256=digest(p.read_bytes()))
                            for p in sorted(DEST.iterdir()) if p.is_file() and p.name != 'evidence-files.json'})
print(json.dumps(dict(destination=str(DEST), files=len(list(DEST.iterdir())),
                      archives={name: (DEST / name).stat().st_size for name in archive_members}), indent=2))
