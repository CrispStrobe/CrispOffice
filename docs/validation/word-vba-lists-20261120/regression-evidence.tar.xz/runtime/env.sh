export QUDS_VALIDATION_ROOT=/workspace/scratch/c7ec4681d1f4/quds_office_suite
export QUDS_DART_ROOT=/workspace/scratch/c7ec4681d1f4/runtime/dart-sdk
export PUB_CACHE=/workspace/scratch/c7ec4681d1f4/runtime/pub-cache
export TMPDIR=/workspace/scratch/c7ec4681d1f4/runtime/tmp
export XDG_CONFIG_HOME=/workspace/scratch/c7ec4681d1f4/runtime/config
export XDG_CACHE_HOME=/workspace/scratch/c7ec4681d1f4/runtime/cache
export DART_SUPPRESS_ANALYTICS=true
export PATH="$QUDS_DART_ROOT/bin:$PATH"
