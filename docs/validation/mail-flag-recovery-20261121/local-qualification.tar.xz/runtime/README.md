# Local Quds validation runtime

This runtime uses the official Flutter 3.47.8 Linux SDK archive, verified against
the SHA-256 already recorded in Quds validation evidence. Flutter reports tag
`737ba8f885dc774b53b442759999a312c9461e4e` and Dart 3.13.7.

Before each local validation command:

```sh
. /workspace/scratch/7bc8916fff75/runtime/env.sh
```

The environment selects this SDK, an isolated Pub cache, suppresses analytics
for the process, and supplies a real writable `TMPDIR`. The sandbox has no usable
`/tmp`; omitting that variable stops Flutter before assertions.

`dart pub get --offline --enforce-lockfile` completed for both the workspace and
Flutter tools. All 202 unique hosted package archives in the two lockfiles were
SHA-256 verified before extraction. The Quds lockfile remains byte-identical to
the checked-out committed version. No product manifest or SDK source patch was
used.

Ordinary commands work:

```sh
cd /workspace/scratch/7bc8916fff75/quds_office_suite/packages/quds_mail_core
dart test test/bulk_flags_journal_test.dart --reporter expanded

cd /workspace/scratch/7bc8916fff75/quds_office_suite/packages/quds_office_editor/example
flutter test --no-pub test/studio_mail_flag_journal_test.dart --reporter expanded
```

The first `dart test` invocation compiles its launcher and may be slow before
printing the first event. The direct lock-resolved runner also works and avoids
that precompilation:

```sh
dart --packages=/workspace/scratch/7bc8916fff75/quds_office_suite/.dart_tool/package_config.json \
  /workspace/scratch/7bc8916fff75/runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart \
  test/flag_journal_test.dart --reporter expanded
```

For direct store tests, root `.dart_tool/native_assets.yaml` contains the actual
Flutter-generated mapping from the normal SQLite build hook. It points to the
same real hook-downloaded SQLite library used by successful Flutter tests, not a
stub or substituted implementation.

See `setup-receipt.json`, `sdk-receipt.json`, `pub-cache-receipt.json`, and `logs/`
for readiness results. The existing core journal (16), SQLite journal (26), and
Studio adapter journal (15) smoke cases passed. The second core invocation is a
repeat of the same cases. These are setup checks during concurrent development,
not qualification of later source edits.
