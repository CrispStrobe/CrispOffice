export FLUTTER_ROOT=/workspace/scratch/7bc8916fff75/runtime/flutter
export PUB_CACHE=/workspace/scratch/7bc8916fff75/runtime/pub-cache
export PATH="$FLUTTER_ROOT/bin:$FLUTTER_ROOT/bin/cache/dart-sdk/bin:$PATH"
export DASH__SUPPRESS_ANALYTICS=true
export FLUTTER_SUPPRESS_ANALYTICS=true
export CI=true
export TMPDIR=/workspace/scratch/7bc8916fff75/runtime/tmp
