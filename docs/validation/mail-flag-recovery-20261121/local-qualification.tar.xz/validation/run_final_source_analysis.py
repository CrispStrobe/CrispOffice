#!/usr/bin/env python3
"""Check formatting and fatal-info analysis for the exact final Dart diff."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/workspace/scratch/7bc8916fff75/quds_office_suite')
RUNTIME = ROOT.parent / 'runtime'
OUT = ROOT.parent / 'validation/final-source-analysis'
SDK = RUNTIME / 'flutter/bin/cache/dart-sdk'
DART = SDK / 'bin/dart'
BASE = 'bf761552d22dcd1eb8cbb0ab00ddab6507e1d572'
OUT.mkdir(parents=True, exist_ok=True)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def revision():
    commit, tree = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=ROOT, text=True).splitlines()
    return {'commit': commit, 'tree': tree}


def inputs():
    paths = {ROOT / name for name in [
        '.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
        '.dart_tool/package_config.json',
    ]}
    for base in [ROOT / 'packages', ROOT / 'apps', ROOT / 'third_party/enough_mail']:
        paths.update(base.rglob('*.dart'))
        paths.update(base.rglob('pubspec.yaml'))
        paths.update(base.rglob('analysis_options.yaml'))
    result = {}
    for path in sorted(paths):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if path != ROOT / '.dart_tool/package_config.json' and any(
                part in ['build', '.dart_tool', '__pycache__'] for part in relative.parts):
            continue
        result[str(relative)] = digest(path)
    return result


def runtime_inputs():
    paths = [DART, SDK / 'bin/snapshots/dartdev_aot.dart.snapshot',
             SDK / 'bin/snapshots/analysis_server_aot.dart.snapshot']
    return {str(path): digest(path) for path in paths}


ENV = dict(os.environ)
ENV.update({
    'FLUTTER_ROOT': str(RUNTIME / 'flutter'),
    'PUB_CACHE': str(RUNTIME / 'pub-cache'),
    'TMPDIR': str(RUNTIME / 'tmp'),
    'DASH__SUPPRESS_ANALYTICS': 'true',
    'FLUTTER_SUPPRESS_ANALYTICS': 'true',
    'CI': 'true',
    'PATH': str(SDK / 'bin') + ':' + ENV['PATH'],
})


def run(name, command):
    started = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    stdout = OUT / (name + '.log')
    stderr = OUT / (name + '.stderr')
    with stdout.open('w') as output, stderr.open('w') as errors:
        result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=output, stderr=errors, timeout=600)
    receipt = {'name': name, 'command': command, 'cwd': str(ROOT),
               'started_at_utc': started, 'elapsed_seconds': time.monotonic() - start,
               'exit_code': result.returncode, 'stdout': stdout.name, 'stderr': stderr.name,
               'stdout_sha256': digest(stdout), 'stderr_sha256': digest(stderr),
               'accepted': result.returncode == 0}
    if name == 'format':
        match = re.search(r'Formatted (\d+) files \((\d+) changed\)', stdout.read_text())
        receipt['checked_files'] = int(match[1]) if match else None
        receipt['changed_files'] = int(match[2]) if match else None
        receipt['accepted'] &= bool(match and int(match[1]) == len(targets) and int(match[2]) == 0)
    (OUT / (name + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
    return receipt


starting_source = revision()
targets = subprocess.check_output(
    ['git', 'diff', '--name-only', '-z', BASE + '..HEAD', '--', '*.dart'], cwd=ROOT).decode().split('\0')
targets = [path for path in targets if path]
assert len(targets) == 53, len(targets)
assert all((ROOT / path).is_file() for path in targets)
(OUT / 'selected-files.json').write_text(json.dumps(targets, indent=2) + '\n')
before = inputs()
runtime_before = runtime_inputs()
(OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
(OUT / 'runtime-before.json').write_text(json.dumps(runtime_before, indent=2) + '\n')
checks = [run('format', [str(DART), 'format', '--output=none', '--set-exit-if-changed', *targets])]
checks.append(run('analysis', [str(DART), 'analyze', '--fatal-infos', *targets]))
after = inputs()
runtime_after = runtime_inputs()
ending_source = revision()
(OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
(OUT / 'runtime-after.json').write_text(json.dumps(runtime_after, indent=2) + '\n')
changed = sorted(path for path in set(before) | set(after) if before.get(path) != after.get(path))
runtime_changed = sorted(path for path in set(runtime_before) | set(runtime_after) if runtime_before.get(path) != runtime_after.get(path))
receipt = {'baseline': BASE, 'source_before': starting_source, 'source_after': ending_source,
           'selected_files': targets, 'checks': checks, 'source_input_count': len(before),
           'changed_inputs': changed, 'changed_runtime_inputs': runtime_changed,
           'github_actions': 'Not queried or awaited.',
           'accepted': all(check['accepted'] for check in checks) and not changed and not runtime_changed}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(0 if receipt['accepted'] else 1)
