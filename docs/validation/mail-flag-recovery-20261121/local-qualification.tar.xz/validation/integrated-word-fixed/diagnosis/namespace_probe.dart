import 'dart:convert';
import 'dart:io';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;
const w = OfficeNamespaces.w;
const x = 'urn:page-setup-test';
const output = '/workspace/scratch/7bc8916fff75/validation/integrated-word-fixed/diagnosis';
XmlElement firstSection(String xml) {
 final body=XmlDocument.parse(xml).root!.firstChild('body',namespaceUri:w)!;
 for (final child in body.childElements) {
  if(child.namespaceUri==w && child.localName=='sectPr') return child;
  final section=child.firstChild('pPr',namespaceUri:w)?.firstChild('sectPr',namespaceUri:w);
  if(section!=null) return section;
 }
 throw StateError('Missing first section');
}
Future<void> main() async {
 var document=WordDeserializer().readBytes(File('test/fixtures/fidelity/word-compatibility.docx').readAsBytesSync());
 final first=document.sections.first;
 first.pageSize=WmlPageSize.letter();
 first.margins=first.margins.copyWith(left:90);
 first.columnCount=3;
 first.columnSpace=24;
 first.columnSep=false;
 first.lineNumbers=false;
 first.differentFirstPage=false;
 final cycles=<Map<String,Object?>>[];
 for(var cycle=1;cycle<=3;cycle++) {
  final bytes=await OfficeIsolateSave.word(document);
  final xml=OpcPackage.openBytes(bytes).getPart('/word/document.xml')!.readText();
  File('$output/modeled-edit-$cycle.xml').writeAsStringSync(xml);
  final size=firstSection(xml).firstChild('pgSz',namespaceUri:w)!;
  document=WordDeserializer().readBytes(bytes);
  cycles.add({'cycle':cycle,'unqualified_width':size.getAttribute('w'),'qualified_width':size.getAttribute('w',namespaceUri:w),'reopened_width_points':document.sections.first.pageSize.width,'width_attributes':[for(final a in size.attributes) if(a.localName=='w') {'qname':a.qualifiedName,'namespace':a.namespaceUri,'value':a.value}]});
 }
 final package=OpcPackage.openBytes((DocxDocumentBuilder()..paragraph('Original text')).build());
 package.getPart('/word/document.xml')!.writeText('<w:document xmlns:w="$w" xmlns:x="$x"><w:body><w:p><w:r><w:t>Original text</w:t></w:r></w:p><w:sectPr><w:pgSz w:w="12240" w:h="15840" w:orient="portrait" w:code="9" x:w="foreign-width" x:code="foreign-paper"/><pgMar xmlns="$w" xmlns:w="$x" w:token="keep"/><w:cols w:num="2" w:space="720"/><w:pgNumType w:start="7"/><x:metadata x:val="keep"/></w:sectPr></w:body></w:document>');
 final repeated=WordDeserializer().read(package);
 void apply()=>native.applyStep(repeated,{'op':'pageSetup','section':0,'property':'left','points':48});
 apply();
 final one=repeated.sections.single.sourceProperties!.xml;
 File('$output/repeated-write-1.xml').writeAsStringSync(one);
 for(var i=0;i<50;i++) apply();
 final many=repeated.sections.single.sourceProperties!.xml;
 File('$output/repeated-write-51.xml').writeAsStringSync(many);
 final serialized=WordSerializer().writeBytes(repeated);
 File('$output/repeated-write-document.xml').writeAsStringSync(OpcPackage.openBytes(serialized).getPart('/word/document.xml')!.readText());
 final report={'modeled_edit_cycles':cycles,'repeated_writes':{'source_equal':one==many,'declarations_after_1':RegExp('xmlns:qudsWord0=').allMatches(one).length,'declarations_after_51':RegExp('xmlns:qudsWord0=').allMatches(many).length}};
 File('$output/runtime-observations.json').writeAsStringSync('${const JsonEncoder.withIndent('  ').convert(report)}\n');
 print(jsonEncode(report));
}
