from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

import run_qualification as qualification

OUTPUT = Path(__file__).resolve().parent / 'diagnosis'
WORD = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'


def main():
    before = qualification.fingerprint()
    (OUTPUT/'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
    command = ['dart', '--packages=' + str(qualification.REPO/'.dart_tool/package_config.json'), str(OUTPUT/'namespace_probe.dart')]
    record = {
        'source_reference': qualification.SOURCE_REFERENCE,
        'started_utc': datetime.now(timezone.utc).isoformat(),
        'command': command,
        'cwd': str(qualification.WORK),
        'probe_sha256': qualification.sha(OUTPUT/'namespace_probe.dart'),
        'before_aggregate_sha256': before['aggregate_sha256'],
    }
    start = time.monotonic()
    with (OUTPUT/'probe.stdout.log').open('w') as stdout, (OUTPUT/'probe.stderr.log').open('w') as stderr:
        result = subprocess.run(command, cwd=qualification.WORK, stdout=stdout, stderr=stderr)
    record.update(exit_code=result.returncode, elapsed_seconds=round(time.monotonic()-start, 3))
    if result.returncode == 0:
        observations = json.loads((OUTPUT/'runtime-observations.json').read_text())
        record['runtime_observations'] = observations
        record['strict_parser'] = 'Python xml.etree.ElementTree (Expat)'
        strict = []
        for path in sorted(OUTPUT.glob('*.xml')):
            item = {'file': path.name, 'sha256': qualification.sha(path)}
            try:
                root = ET.fromstring(path.read_bytes())
                size = root.find('.//{' + WORD + '}pgSz')
                margins = root.find('.//{' + WORD + '}pgMar')
                item.update(valid_xml=True, native_width=size.attrib.get('{' + WORD + '}w'))
                if path.name.startswith('repeated-'):
                    item['native_left_margin'] = margins.attrib.get('{' + WORD + '}left')
                    item['foreign_token'] = margins.attrib.get('{urn:page-setup-test}token')
            except ET.ParseError as error:
                item.update(valid_xml=False, error=str(error))
            strict.append(item)
        record['strict_xml_results'] = strict
        record['strict_diagnostic_success'] = (
            len(strict) == 6 and all(item.get('valid_xml') and item.get('native_width') == '12240' for item in strict)
            and all(item.get('native_left_margin') == '960' and item.get('foreign_token') == 'keep' for item in strict if item['file'].startswith('repeated-'))
            and all(cycle['qualified_width'] == '12240' and cycle['reopened_width_points'] == 612 for cycle in observations['modeled_edit_cycles'])
            and observations['repeated_writes'] == {'source_equal': True, 'declarations_after_1': 1, 'declarations_after_51': 1}
        )
    after = qualification.fingerprint()
    (OUTPUT/'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    record['after_aggregate_sha256'] = after['aggregate_sha256']
    record['changes'] = {
        category: [path for path in sorted(before[category].keys() | after[category].keys()) if before[category].get(path) != after[category].get(path)]
        for category in ['source_sha256', 'config_sha256', 'runtime_sha256']
    }
    record['strict_success'] = result.returncode == 0 and record.get('strict_diagnostic_success', False) and not any(record['changes'].values())
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (OUTPUT/'diagnosis.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))
    return 0 if record['strict_success'] else 1


if __name__ == '__main__':
    sys.exit(main())
