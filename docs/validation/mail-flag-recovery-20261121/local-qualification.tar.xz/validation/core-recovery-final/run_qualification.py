#!/usr/bin/env python3
"""Source-bound full portable core qualification; writes only validation evidence."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from urllib.parse import unquote, urljoin, urlparse

REPO = Path('/workspace/scratch/7bc8916fff75/quds_office_suite')
OUTPUT = Path(__file__).resolve().parent
RUNTIME = Path('/workspace/scratch/7bc8916fff75/runtime')
SDK = RUNTIME / 'flutter/bin/cache/dart-sdk'
TEST_DIRECTORY = 'packages/quds_mail_core/test'


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    if not path.is_file():
        return None
    value = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def files_under(path):
    if not path.is_dir():
        return []
    found = subprocess.run(
        ['rg', '--files', '-uu', str(path)],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if found.returncode not in (0, 1):
        found.check_returncode()
    return [Path(line) for line in found.stdout.splitlines()]


def fingerprint():
    config_path = REPO / '.dart_tool/package_config.json'
    package_config = json.loads(config_path.read_text())
    graph = {
        p['name']: p
        for p in json.loads((REPO / '.dart_tool/package_graph.json').read_text())['packages']
    }
    needed = set()
    pending = ['quds_mail_core', 'test']
    while pending:
        name = pending.pop()
        if name in needed:
            continue
        needed.add(name)
        pending.extend(graph[name].get('dependencies', []))
    sources = set()
    dependencies = {}
    configs = {
        REPO / relative
        for relative in [
            'pubspec.yaml', 'pubspec.lock', 'pubspec_overrides.yaml',
            'dart_test.yaml', 'analysis_options.yaml',
            '.dart_tool/package_config.json', '.dart_tool/package_graph.json',
            '.dart_tool/native_assets.yaml',
            'packages/quds_mail_core/dart_test.yaml',
            'packages/quds_mail_core/pubspec_overrides.yaml',
        ]
    }
    for package in package_config['packages']:
        if package['name'] not in needed:
            continue
        root = Path(unquote(urlparse(urljoin(config_path.as_uri(), package['rootUri'])).path))
        dependencies[package['name']] = {
            'version': graph[package['name']].get('version'),
            'root': str(root),
            'languageVersion': package.get('languageVersion'),
        }
        configs.add(root / 'pubspec.yaml')
        for directory in ['lib', 'bin', 'hook']:
            sources.update(files_under(root / directory))
    sources.update(files_under(REPO / 'packages/quds_mail_core/test'))
    runtime = {
        RUNTIME / 'env.sh',
        RUNTIME / 'flutter/bin/dart',
        SDK / 'version', SDK / 'revision',
        SDK / 'bin/dart', SDK / 'bin/dartvm', SDK / 'bin/dartaotruntime',
        Path(shutil.which('node')).resolve(),
        REPO / '.dart_tool/lib/libsqlite3.so',
        REPO / '.dart_tool/pub/bin/test/test.dart-3.13.7.snapshot',
    }
    runtime.update(files_under(SDK / 'bin/snapshots'))
    runtime.update(files_under(SDK / 'lib'))
    result = {
        'source_sha256': {str(path): sha(path) for path in sorted(sources)},
        'config_sha256': {str(path): sha(path) for path in sorted(configs)},
        'runtime_sha256': {str(path): sha(path) for path in sorted(runtime)},
        'resolved_dependencies': dependencies,
    }
    result['aggregate_sha256'] = hashlib.sha256(
        json.dumps(result, sort_keys=True, separators=(',', ':')).encode()
    ).hexdigest()
    return result


def test_counts(path):
    suites = {}
    tests = {}
    done = {}
    runner_done = None
    for line in path.read_text().splitlines():
        event = json.loads(line)
        kind = event['type']
        if kind == 'suite':
            suites[event['suite']['id']] = event['suite']
        elif kind == 'testStart':
            tests[event['test']['id']] = event['test']
        elif kind == 'testDone':
            done[event['testID']] = event
        elif kind == 'done':
            runner_done = event
    by_suite = {}
    for sid, suite in suites.items():
        rows = [
            (tests[tid], event)
            for tid, event in done.items()
            if tests.get(tid, {}).get('suiteID') == sid and not event.get('hidden')
        ]
        by_suite[suite['path']] = {
            'total': len(rows),
            'passed': sum(e['result'] == 'success' and not e.get('skipped') for _, e in rows),
            'skipped': sum(bool(e.get('skipped')) for _, e in rows),
            'failed': sum(e['result'] != 'success' and not e.get('skipped') for _, e in rows),
            'failures': [t['name'] for t, e in rows if e['result'] != 'success'],
        }
    return {
        'suites': by_suite,
        'total': sum(s['total'] for s in by_suite.values()),
        'passed': sum(s['passed'] for s in by_suite.values()),
        'skipped': sum(s['skipped'] for s in by_suite.values()),
        'failed': sum(s['failed'] for s in by_suite.values()),
        'runner_done': runner_done,
    }


def main():
    platform = sys.argv[1]
    files = [TEST_DIRECTORY]
    inventory = sorted(str(path.relative_to(REPO)) for path in files_under(REPO / TEST_DIRECTORY) if path.name.endswith('_test.dart'))
    command = ['dart', 'test', *files, '--platform', platform, '--reporter', 'expanded',
               '--file-reporter', 'json:' + str(OUTPUT / f'{platform}.jsonl')]
    metadata_path = OUTPUT / f'{platform}.run.json'
    before = fingerprint()
    (OUTPUT / f'{platform}.before.sha256.json').write_text(json.dumps(before, indent=2) + '\n')
    record = {
        'started_utc': now(),
        'command': command,
        'cwd': str(REPO),
        'test_inventory': inventory,
        'environment': {key: os.environ.get(key) for key in [
            'FLUTTER_ROOT', 'PUB_CACHE', 'TMPDIR', 'CI',
            'DASH__SUPPRESS_ANALYTICS', 'FLUTTER_SUPPRESS_ANALYTICS',
        ]},
        'dart_path': shutil.which('dart'),
        'node_path': shutil.which('node'),
        'versions': {
            'dart': subprocess.check_output(['dart', '--version'], text=True, stderr=subprocess.STDOUT).strip(),
            'node': subprocess.check_output(['node', '--version'], text=True).strip(),
        },
        'runner_sha256': sha(Path(__file__).resolve()),
        'before_aggregate_sha256': before['aggregate_sha256'],
    }
    metadata_path.write_text(json.dumps(record, indent=2) + '\n')
    start = time.monotonic()
    with (OUTPUT / f'{platform}.stdout.log').open('w') as stdout, (OUTPUT / f'{platform}.stderr.log').open('w') as stderr:
        result = subprocess.run(command, cwd=REPO, stdout=stdout, stderr=stderr)
    record.update(exit_code=result.returncode, elapsed_seconds=round(time.monotonic()-start, 3), finished_utc=now())
    after = fingerprint()
    (OUTPUT / f'{platform}.after.sha256.json').write_text(json.dumps(after, indent=2) + '\n')
    record['after_aggregate_sha256'] = after['aggregate_sha256']
    record['changes'] = {
        category: [
            path for path in sorted(before[category].keys() | after[category].keys())
            if before[category].get(path) != after[category].get(path)
        ]
        for category in ['source_sha256', 'config_sha256', 'runtime_sha256']
    }
    if (OUTPUT / f'{platform}.jsonl').exists():
        record['counts'] = test_counts(OUTPUT / f'{platform}.jsonl')
    record['strict_success'] = (result.returncode == 0 and record.get('counts', {}).get('runner_done', {}).get('success') is True and record['counts']['failed'] == 0 and record['counts']['skipped'] == 0 and not any(record['changes'].values()))
    metadata_path.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))
    return 0 if record['strict_success'] else 1


if __name__ == '__main__':
    sys.exit(main())
