import hashlib,json,subprocess,sys,time
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
root=Path('/workspace/scratch/7bc8916fff75')
repo=root/'quds_office_suite'
dst=root/'validation/integrated-zotero-final'
job=sys.argv[1]
specs={
 'engine':('packages/quds_office_engine',['/workspace/scratch/7bc8916fff75/runtime/flutter/bin/cache/dart-sdk/bin/dart','test','test/word_zotero_multiparagraph_test.dart','test/word_zotero_research_target_test.dart','test/word_zotero_add_note_test.dart','--reporter','json']),
 'editor':('packages/quds_office_editor',['flutter','test','--no-pub','--machine','test/word_zotero_multiparagraph_controller_test.dart','test/word_zotero_add_note_controller_test.dart'])
}
folder,cmd=specs[job]
started=datetime.now(timezone.utc).isoformat()
watch=time.monotonic()
raw=dst/(job+'.jsonl')
with raw.open('w') as out:
 result=subprocess.run(cmd,cwd=repo/folder,stdout=out,stderr=subprocess.STDOUT)
elapsed=time.monotonic()-watch
names={};suite_paths={};done=[];errors=[];complete=None;nonjson=[]
for line in raw.read_text().splitlines():
 try: item=json.loads(line)
 except (ValueError,TypeError):
  if line.strip(): nonjson.append(line)
  continue
 if not isinstance(item,dict): continue
 kind=item.get('type')
 if kind=='suite':
  suite=item.get('suite',{});suite_paths[suite.get('id')]=suite.get('path')
 elif kind=='testStart': names[item['test']['id']]=item['test']
 elif kind=='testDone' and not item.get('hidden',False):
  t=names.get(item.get('testID'),{})
  done.append({'id':item.get('testID'),'name':t.get('name'),'suite':suite_paths.get(t.get('suiteID')),'result':item.get('result'),'skipped':item.get('skipped',False)})
 elif kind=='error': errors.append(item)
 elif kind=='done': complete=item
counts=Counter('skipped' if t['skipped'] else t['result'] for t in done)
manifest=json.loads((dst/'source-manifest.json').read_text())
changed=[]
for item in manifest['delta_files']+manifest['focused_existing_tests']:
 data=(repo/item['path']).read_bytes()
 actual=hashlib.sha256(data).hexdigest()
 if actual!=item['sha256']: changed.append({'path':item['path'],'before':item['sha256'],'after':actual})
summary={'job':job,'command':cmd,'cwd':str(repo/folder),'started_at_utc':started,'completed_at_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':round(elapsed,3),'exit_code':result.returncode,'runner_done_event':complete,'visible_test_count':len(done),'counts':dict(counts),'errors':errors,'source_changes_during_run':changed,'raw_log':raw.name,'raw_log_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'source_manifest_sha256':hashlib.sha256((dst/'source-manifest.json').read_bytes()).hexdigest(),'cases':done,'non_json_lines':nonjson}
(dst/(job+'-result.json')).write_text(json.dumps(summary,indent=2)+'\n')
log=['Command: '+json.dumps(cmd),'CWD: '+str(repo/folder),'Started: '+started,'']
log.extend(t['result'].upper()+(' SKIPPED' if t['skipped'] else '')+' '+str(t['name']) for t in done)
log.extend(['','Exit code: '+str(result.returncode),'Counts: '+json.dumps(dict(counts)),'Source changes: '+json.dumps(changed)])
if errors: log.extend(['','Errors:',json.dumps(errors,indent=2)])
if nonjson: log.extend(['','Runner output:',*nonjson])
(dst/(job+'.log')).write_text('\n'.join(log)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['cases','non_json_lines']},indent=2),flush=True)
sys.exit(result.returncode if result.returncode else (1 if changed or errors or not complete or not complete.get('success') else 0))
