#!/usr/bin/env python3
"""Qualify the complete native store inventory and changed public/Studio code."""
from __future__ import annotations

import concurrent.futures
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/7bc8916fff75/quds_office_suite')
RUNTIME = ROOT.parent / 'runtime'
OUT = ROOT.parent / 'validation/store-analysis-final'
STUDIO = ROOT / 'packages/quds_office_editor/example'
STORE = ROOT / 'packages/quds_mail_store'
DART = RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / 'tools/mail'))
from check_store import test_summary

STUDIO_FILES = [
    'studio_mail_bulk_status.dart', 'studio_mail_ews.dart',
    'studio_mail_flag_journal.dart', 'studio_mail_flag_reconciliation.dart',
    'studio_mail_journal_dialog.dart', 'studio_mail_journal_strings.dart',
    'studio_mail_message_loader.dart', 'studio_mail_native.dart',
]


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def inputs():
    paths = {ROOT / name for name in [
        '.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
        '.dart_tool/package_config.json', 'tools/mail/check_store.py',
        'tools/mail/check_reader.py',
    ]}
    bases = list((ROOT / 'packages').iterdir()) + list((ROOT / 'apps').iterdir())
    bases += [STUDIO, ROOT / 'packages/quds_mail_ui/example', ROOT / 'third_party/enough_mail']
    for base in bases:
        paths.add(base / 'pubspec.yaml')
        paths.update((base / 'lib').rglob('*.dart'))
    for name in ['quds_mail_core', 'quds_mail_store', 'quds_mail_transport']:
        package = ROOT / 'packages' / name
        for folder in ['test', 'tool']:
            paths.update(path for path in (package / folder).rglob('*') if path.is_file())
    return {str(path.relative_to(ROOT)): digest(path) for path in sorted(paths)
            if path.is_file() and not any(part in ['build', '.dart_tool', '__pycache__'] for part in path.relative_to(ROOT).parts)
            or path == ROOT / '.dart_tool/package_config.json'}


def runtime_inputs():
    paths = [DART,
        RUNTIME / 'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',
        RUNTIME / 'flutter/bin/cache/dart-sdk/bin/snapshots/dartdev_aot.dart.snapshot',
        ROOT / '.dart_tool/hooks_runner/shared/sqlite3/build/download-0a658527/libsqlite3.so',
    ]
    return {str(path): digest(path) for path in paths if path.is_file()}


ENV = dict(os.environ)
ENV.update({
    'FLUTTER_ROOT': str(RUNTIME / 'flutter'),
    'PUB_CACHE': str(RUNTIME / 'pub-cache'),
    'TMPDIR': str(RUNTIME / 'tmp'),
    'DASH__SUPPRESS_ANALYTICS': 'true',
    'FLUTTER_SUPPRESS_ANALYTICS': 'true',
    'CI': 'true',
    'PATH': str(RUNTIME / 'flutter/bin') + ':' + str(DART.parent) + ':' + ENV['PATH'],
})


def run(name, command, cwd, tests=False):
    started = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    stdout = OUT / (name + ('.jsonl' if tests else '.log'))
    stderr = OUT / (name + '.stderr')
    with stdout.open('w') as output, stderr.open('w') as errors:
        result = subprocess.run(command, cwd=cwd, env=ENV, stdout=output, stderr=errors, timeout=600)
    receipt = {'name': name, 'command': command, 'cwd': str(cwd),
               'started_at_utc': started, 'elapsed_seconds': time.monotonic() - start,
               'exit_code': result.returncode, 'stdout': stdout.name, 'stderr': stderr.name,
               'stdout_sha256': digest(stdout), 'stderr_sha256': digest(stderr)}
    if tests:
        summary = test_summary(stdout)
        (OUT / (name + '-cases.json')).write_text(json.dumps(summary, indent=2) + '\n')
        receipt['tests'] = {key: value for key, value in summary.items() if key != 'cases'}
    receipt['accepted'] = result.returncode == 0 and (not tests or receipt['tests']['valid'])
    (OUT / (name + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
    return receipt


before = inputs()
runtime_before = runtime_inputs()
(OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
(OUT / 'runtime-before.json').write_text(json.dumps(runtime_before, indent=2) + '\n')
native = sorted(str(path.relative_to(STORE)) for path in (STORE / 'test').glob('*_test.dart')
                if path.name != 'browser_problem_test.dart')
analysis_paths = ['packages/' + name for name in ['quds_mail_core', 'quds_mail_store', 'quds_mail_transport']]
analysis_paths += ['packages/quds_office_editor/example/lib/' + name for name in STUDIO_FILES]
jobs = [
    ('targeted-analysis', [str(DART), 'analyze', '--fatal-infos', *analysis_paths], ROOT, False),
    ('full-store-vm', [str(DART), 'test', '--compiler=kernel', '--platform', 'vm', '--reporter', 'json', '--concurrency=2', *native], STORE, True),
]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(run, *job) for job in jobs]
    checks = [future.result() for future in futures]
checks.append(run('store-node-only', [str(DART), 'test', '--platform', 'node', '--reporter', 'json', 'test/browser_problem_test.dart'], STORE, True))
after = inputs()
runtime_after = runtime_inputs()
(OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
(OUT / 'runtime-after.json').write_text(json.dumps(runtime_after, indent=2) + '\n')
changed = sorted(path for path in set(before) | set(after) if before.get(path) != after.get(path))
runtime_changed = sorted(path for path in set(runtime_before) | set(runtime_after) if runtime_before.get(path) != runtime_after.get(path))
receipt = {'checks': checks, 'source_input_count': len(before), 'changed_inputs': changed,
           'changed_runtime_inputs': runtime_changed, 'native_suite_files': native,
           'node_only_suite_files': ['test/browser_problem_test.dart'],
           'scope': 'Complete 33-file store test inventory: 32 native files and the Node-only browser problem classification file. Node tests do not qualify browser storage.',
           'github_actions': 'Not queried or awaited.',
           'accepted': all(check['accepted'] for check in checks) and not changed and not runtime_changed}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(0 if receipt['accepted'] else 1)
