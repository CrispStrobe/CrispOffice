#!/usr/bin/env python3
"""Qualify the captured combined Mail/Office source without hosted CI."""
from __future__ import annotations

import concurrent.futures
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/7bc8916fff75/quds_office_suite')
RUNTIME = ROOT.parent / 'runtime'
OUT = ROOT.parent / 'validation/integrated-mail-final'
STUDIO = ROOT / 'packages/quds_office_editor/example'
UI = ROOT / 'packages/quds_mail_ui'
FLUTTER = RUNTIME / 'flutter/bin/flutter'
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / 'tools/mail'))
from check_store import test_summary

STUDIO_TESTS = [
    'test/studio_mail_flag_journal_test.dart',
    'test/studio_mail_journal_dialog_test.dart',
    'test/studio_mail_bulk_visual_test.dart',
    'test/studio_mail_bulk_provider_test.dart',
    'test/studio_mail_flag_reconciliation_test.dart',
    'test/studio_mail_flag_recovery_dialog_test.dart',
    'test/studio_mail_journal_host_test.dart',
    'test/studio_mail_message_loader_test.dart',
    'test/studio_mail_remote_images_incoming_test.dart',
]
UI_TESTS = [
    'test/bulk_api_aliases_test.dart',
    'test/remote_images_test.dart',
    'test/reader_image_updates_test.dart',
]


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def source_commit():
    commit, tree = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=ROOT, text=True).splitlines()
    return {'commit': commit, 'tree': tree}


def inputs():
    paths = {ROOT / name for name in [
        '.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
        '.dart_tool/package_config.json', 'tools/mail/check_store.py',
        'tools/mail/check_reader.py',
    ]}
    bases = list((ROOT / 'packages').iterdir()) + list((ROOT / 'apps').iterdir())
    bases += [STUDIO, ROOT / 'packages/quds_mail_ui/example', ROOT / 'third_party/enough_mail']
    for base in bases:
        paths.add(base / 'pubspec.yaml')
        paths.update((base / 'lib').rglob('*.dart'))
    for base in [STUDIO, UI]:
        paths.update(path for path in (base / 'test').rglob('*') if path.is_file())
    paths.update((ROOT / 'packages/quds_office_editor/fonts').glob('*'))
    paths.update((STUDIO / 'fonts').glob('*'))
    result = {}
    for path in sorted(paths):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if path != ROOT / '.dart_tool/package_config.json' and any(
                part in ['build', '.dart_tool', '__pycache__'] for part in relative.parts):
            continue
        result[str(relative)] = digest(path)
    return result


def runtime_inputs():
    paths = [
        RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart',
        RUNTIME / 'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',
        RUNTIME / 'flutter/bin/cache/flutter_tools.snapshot',
        RUNTIME / 'flutter/packages/flutter_tools/pubspec.lock',
        ROOT / '.dart_tool/hooks_runner/shared/sqlite3/build/download-0a658527/libsqlite3.so',
    ]
    return {str(path): digest(path) for path in paths}


ENV = dict(os.environ)
ENV.update({
    'FLUTTER_ROOT': str(RUNTIME / 'flutter'),
    'PUB_CACHE': str(RUNTIME / 'pub-cache'),
    'TMPDIR': str(RUNTIME / 'tmp'),
    'DASH__SUPPRESS_ANALYTICS': 'true',
    'FLUTTER_SUPPRESS_ANALYTICS': 'true',
    'CI': 'true',
    'PATH': str(RUNTIME / 'flutter/bin') + ':' + str(RUNTIME / 'flutter/bin/cache/dart-sdk/bin') + ':' + ENV['PATH'],
})


def run(name, command, cwd):
    started = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    stdout = OUT / (name + '.jsonl')
    stderr = OUT / (name + '.stderr')
    with stdout.open('w') as output, stderr.open('w') as errors:
        result = subprocess.run(command, cwd=cwd, env=ENV, stdout=output, stderr=errors, timeout=600)
    summary = test_summary(stdout)
    (OUT / (name + '-cases.json')).write_text(json.dumps(summary, indent=2) + '\n')
    receipt = {'name': name, 'command': command, 'cwd': str(cwd),
               'started_at_utc': started, 'elapsed_seconds': time.monotonic() - start,
               'exit_code': result.returncode, 'stdout': stdout.name, 'stderr': stderr.name,
               'stdout_sha256': digest(stdout), 'stderr_sha256': digest(stderr),
               'tests': {key: value for key, value in summary.items() if key != 'cases'},
               'accepted': result.returncode == 0 and summary['valid']}
    (OUT / (name + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
    return receipt


starting_source = source_commit()
before = inputs()
runtime_before = runtime_inputs()
(OUT / 'source-before.json').write_text(json.dumps(starting_source, indent=2) + '\n')
(OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
(OUT / 'runtime-before.json').write_text(json.dumps(runtime_before, indent=2) + '\n')
jobs = [
    ('studio-integrated', [str(FLUTTER), 'test', '--no-pub', '--reporter', 'json', '--concurrency=2',
     '--dart-define=MAIL_RECOVERY_SCREENSHOT_DIR=' + str(OUT / 'visuals'), *STUDIO_TESTS], STUDIO),
    ('mail-ui-integrated', [str(FLUTTER), 'test', '--no-pub', '--reporter', 'json', '--concurrency=2', *UI_TESTS], UI),
]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(run, *job) for job in jobs]
    checks = [future.result() for future in futures]
after = inputs()
runtime_after = runtime_inputs()
ending_source = source_commit()
(OUT / 'source-after.json').write_text(json.dumps(ending_source, indent=2) + '\n')
(OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
(OUT / 'runtime-after.json').write_text(json.dumps(runtime_after, indent=2) + '\n')
changed = sorted(path for path in set(before) | set(after) if before.get(path) != after.get(path))
runtime_changed = sorted(path for path in set(runtime_before) | set(runtime_after) if runtime_before.get(path) != runtime_after.get(path))
visuals = {path.name: digest(path) for path in sorted((OUT / 'visuals').glob('*.png'))}
receipt = {'source_before': starting_source, 'source_after': ending_source,
           'checks': checks, 'source_input_count': len(before), 'changed_inputs': changed,
           'changed_runtime_inputs': runtime_changed, 'visuals': visuals,
           'scope': 'Nine Studio and three shared Mail UI suites on the current integrated Office/Mail source. Synthetic provider tests, real native SQLite and Flutter tester; no live accounts.',
           'github_actions': 'Not queried or awaited.',
           'accepted': all(check['accepted'] for check in checks) and not changed and not runtime_changed and len(visuals) == 6}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(0 if receipt['accepted'] else 1)
