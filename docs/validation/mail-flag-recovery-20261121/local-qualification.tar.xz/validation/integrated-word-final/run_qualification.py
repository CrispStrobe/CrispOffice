#!/usr/bin/env python3
"""Source-bound integrated Word page-setup qualification; writes only validation evidence."""
from datetime import datetime, timezone
import hashlib
import base64
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from urllib.parse import unquote, urljoin, urlparse

REPO = Path('/workspace/scratch/7bc8916fff75/quds_office_suite')
OUTPUT = Path(__file__).resolve().parent
RUNTIME = Path('/workspace/scratch/7bc8916fff75/runtime')
SDK = RUNTIME / 'flutter/bin/cache/dart-sdk'
WORK = REPO / 'packages/quds_office_engine'
SOURCE_REFERENCE = 'ac2b65cdbdea6d5ca3464c6a1fc826cfccc9e1dc'
TEST_FILES = ['test/office_macro_word_page_setup_test.dart', 'test/office_vba_word_page_setup_test.dart', 'test/office_vba_word_page_setup_integration_test.dart', 'test/word_compatibility_fidelity_test.dart', 'test/word_section_clone_fidelity_test.dart']


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    if not path.is_file():
        return None
    value = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def files_under(path):
    if not path.is_dir():
        return []
    found = subprocess.run(
        ['rg', '--files', '-uu', str(path)],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if found.returncode not in (0, 1):
        found.check_returncode()
    return [Path(line) for line in found.stdout.splitlines()]


def fingerprint():
    config_path = REPO / '.dart_tool/package_config.json'
    package_config = json.loads(config_path.read_text())
    graph = {
        p['name']: p
        for p in json.loads((REPO / '.dart_tool/package_graph.json').read_text())['packages']
    }
    needed = set()
    pending = ['quds_office_engine', 'test']
    while pending:
        name = pending.pop()
        if name in needed:
            continue
        needed.add(name)
        pending.extend(graph[name].get('dependencies', []))
    sources = set()
    dependencies = {}
    configs = {
        REPO / relative
        for relative in [
            'pubspec.yaml', 'pubspec.lock', 'pubspec_overrides.yaml',
            'dart_test.yaml', 'analysis_options.yaml',
            '.dart_tool/package_config.json', '.dart_tool/package_graph.json',
            '.dart_tool/native_assets.yaml',
            'packages/quds_office_engine/dart_test.yaml',
            'packages/quds_office_engine/pubspec_overrides.yaml',
        ]
    }
    for package in package_config['packages']:
        if package['name'] not in needed:
            continue
        root = Path(unquote(urlparse(urljoin(config_path.as_uri(), package['rootUri'])).path))
        dependencies[package['name']] = {
            'version': graph[package['name']].get('version'),
            'root': str(root),
            'languageVersion': package.get('languageVersion'),
        }
        configs.add(root / 'pubspec.yaml')
        for directory in ['lib', 'bin', 'hook']:
            sources.update(files_under(root / directory))
    sources.update(WORK / name for name in TEST_FILES)
    sources.update(files_under(WORK / 'test/support'))
    sources.update(files_under(WORK / 'tool/macros'))
    sources.add(WORK / 'example/macros/word_page_setup.bas')
    sources.add(WORK / 'test/fixtures/fidelity/word-compatibility.docx')
    runtime = {
        RUNTIME / 'env.sh',
        RUNTIME / 'flutter/bin/dart',
        SDK / 'version', SDK / 'revision',
        SDK / 'bin/dart', SDK / 'bin/dartvm', SDK / 'bin/dartaotruntime',
        Path(shutil.which('node')).resolve(),
        REPO / '.dart_tool/lib/libsqlite3.so',
        REPO / '.dart_tool/pub/bin/test/test.dart-3.13.7.snapshot',
    }
    runtime.update(files_under(SDK / 'bin/snapshots'))
    runtime.update(files_under(SDK / 'lib'))
    result = {
        'source_sha256': {str(path): sha(path) for path in sorted(sources)},
        'config_sha256': {str(path): sha(path) for path in sorted(configs)},
        'runtime_sha256': {str(path): sha(path) for path in sorted(runtime)},
        'resolved_dependencies': dependencies,
    }
    result['aggregate_sha256'] = hashlib.sha256(
        json.dumps(result, sort_keys=True, separators=(',', ':')).encode()
    ).hexdigest()
    return result


def test_counts(path):
    suites = {}
    tests = {}
    done = {}
    runner_done = None
    for line in path.read_text().splitlines():
        event = json.loads(line)
        kind = event['type']
        if kind == 'suite':
            suites[event['suite']['id']] = event['suite']
        elif kind == 'testStart':
            tests[event['test']['id']] = event['test']
        elif kind == 'testDone':
            done[event['testID']] = event
        elif kind == 'done':
            runner_done = event
    by_suite = {}
    for sid, suite in suites.items():
        rows = [
            (tests[tid], event)
            for tid, event in done.items()
            if tests.get(tid, {}).get('suiteID') == sid and not event.get('hidden')
        ]
        by_suite[suite['path']] = {
            'total': len(rows),
            'passed': sum(e['result'] == 'success' and not e.get('skipped') for _, e in rows),
            'skipped': sum(bool(e.get('skipped')) for _, e in rows),
            'failed': sum(e['result'] != 'success' and not e.get('skipped') for _, e in rows),
            'failures': [t['name'] for t, e in rows if e['result'] != 'success'],
        }
    return {
        'suites': by_suite,
        'total': sum(s['total'] for s in by_suite.values()),
        'passed': sum(s['passed'] for s in by_suite.values()),
        'skipped': sum(s['skipped'] for s in by_suite.values()),
        'failed': sum(s['failed'] for s in by_suite.values()),
        'runner_done': runner_done,
    }


def run_step(name, command, record):
    start = time.monotonic()
    with (OUTPUT / f'{name}.stdout.log').open('w') as stdout, (OUTPUT / f'{name}.stderr.log').open('w') as stderr:
        result = subprocess.run(command, cwd=WORK, stdout=stdout, stderr=stderr)
    record['steps'].append({'name': name, 'command': command, 'exit_code': result.returncode, 'elapsed_seconds': round(time.monotonic()-start, 3), 'stdout': f'{name}.stdout.log', 'stderr': f'{name}.stderr.log'})
    return result.returncode


def main():
    label = sys.argv[1]
    metadata = OUTPUT / f'{label}.run.json'
    before = fingerprint()
    (OUTPUT / f'{label}.before.sha256.json').write_text(json.dumps(before, indent=2) + chr(10))
    record = {
        'started_utc': now(),
        'source_reference': SOURCE_REFERENCE,
        'cwd': str(WORK),
        'test_inventory': TEST_FILES if label == 'tests' else [],
        'environment': {key: os.environ.get(key) for key in ['FLUTTER_ROOT','PUB_CACHE','TMPDIR','CI','DASH__SUPPRESS_ANALYTICS','FLUTTER_SUPPRESS_ANALYTICS']},
        'dart_path': shutil.which('dart'),
        'node_path': shutil.which('node'),
        'versions': {
            'dart': subprocess.check_output(['dart','--version'], text=True, stderr=subprocess.STDOUT).strip(),
            'node': subprocess.check_output(['node','--version'], text=True).strip(),
        },
        'runner_sha256': sha(Path(__file__).resolve()),
        'before_aggregate_sha256': before['aggregate_sha256'],
        'steps': [],
    }
    metadata.write_text(json.dumps(record, indent=2) + chr(10))
    if label == 'tests':
        command = ['dart','test',*TEST_FILES,'--platform','vm','--reporter','expanded','--file-reporter','json:'+str(OUTPUT/'tests.jsonl')]
        run_step('tests', command, record)
        if (OUTPUT/'tests.jsonl').exists():
            record['counts'] = test_counts(OUTPUT/'tests.jsonl')
        successful = (record['steps'][-1]['exit_code'] == 0 and record.get('counts',{}).get('runner_done',{}).get('success') is True and record['counts']['failed'] == 0 and record['counts']['skipped'] == 0 and set(record['counts']['suites']) == set(TEST_FILES))
    elif label == 'smoke':
        example = WORK / 'example/macros/word_page_setup.bas'
        encoded = base64.b64encode(example.read_bytes()).decode('ascii')
        javascript = OUTPUT/'web_vba_word_page_setup_smoke.js'
        record['example_sha256'] = sha(example)
        command = ['dart','compile','js','-O1','-DWORD_PAGE_SETUP_BAS_BASE64='+encoded,'tool/macros/web_vba_word_page_setup_smoke.dart','-o',str(javascript)]
        result = run_step('compile-js', command, record)
        successful = False
        if result == 0:
            record['compiled_javascript_sha256'] = sha(javascript)
            result = run_step('node-smoke', ['node','-e','globalThis.self = globalThis; require(process.argv[1]);',str(javascript)], record)
            if result == 0:
                report = json.loads((OUTPUT/'node-smoke.stdout.log').read_text())
                record['smoke_report'] = report
                expected = {
                    'example': {'operations':10,'firstRunRevision':1,'repeatedRevision':2,'additionalReopens':2,'opaquePayloadsPreserved':True},
                    'rollback': {'failedStep':1,'validateAndRunRollback':True},
                    'recording': {'recordedSteps':2,'failedCallExcluded':True,'replayRevision':1},
                }
                successful = all(report.get(group,{}).get(key) == value for group, fields in expected.items() for key,value in fields.items())
                record['smoke_contract_valid'] = successful
    else:
        raise ValueError(label)
    after = fingerprint()
    (OUTPUT / f'{label}.after.sha256.json').write_text(json.dumps(after, indent=2) + chr(10))
    record['after_aggregate_sha256'] = after['aggregate_sha256']
    record['changes'] = {category: [path for path in sorted(before[category].keys() | after[category].keys()) if before[category].get(path) != after[category].get(path)] for category in ['source_sha256','config_sha256','runtime_sha256']}
    record['strict_success'] = successful and not any(record['changes'].values())
    record['finished_utc'] = now()
    metadata.write_text(json.dumps(record, indent=2) + chr(10))
    printed = {key: value for key,value in record.items() if key != 'steps'}
    printed['steps'] = [{key:value for key,value in step.items() if key != 'command'} for step in record['steps']]
    print(json.dumps(printed, indent=2))
    return 0 if record['strict_success'] else 1


if __name__ == '__main__':
    sys.exit(main())
