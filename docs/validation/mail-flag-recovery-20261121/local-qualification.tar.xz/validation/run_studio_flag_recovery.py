#!/usr/bin/env python3
"""Run the focused native recovery cohort and bind it to its source inputs."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/7bc8916fff75/quds_office_suite')
RUNTIME = ROOT.parent / 'runtime'
OUT = ROOT.parent / 'validation/studio-recovery-final'
STUDIO = ROOT / 'packages/quds_office_editor/example'
TESTS = [
    'test/studio_mail_flag_reconciliation_test.dart',
    'test/studio_mail_flag_recovery_dialog_test.dart',
]
OUT.mkdir(parents=True, exist_ok=True)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def inputs():
    paths = {ROOT / name for name in [
        '.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
        '.dart_tool/package_config.json',
    ]}
    bases = list((ROOT / 'packages').iterdir()) + list((ROOT / 'apps').iterdir())
    bases += [STUDIO, ROOT / 'packages/quds_mail_ui/example', ROOT / 'third_party/enough_mail']
    for base in bases:
        paths.add(base / 'pubspec.yaml')
        paths.update((base / 'lib').rglob('*.dart'))
    paths.update(STUDIO / path for path in TESTS)
    paths.add(STUDIO / 'test/support/mail_flag_journal.dart')
    paths.update((ROOT / 'packages/quds_office_editor/fonts').glob('*'))
    paths.update((STUDIO / 'fonts').glob('*'))
    return {str(path.relative_to(ROOT)): digest(path) for path in sorted(paths) if path.is_file()}


def runtime_inputs():
    paths = [
        RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart',
        RUNTIME / 'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',
        RUNTIME / 'flutter/bin/cache/flutter_tools.snapshot',
        RUNTIME / 'flutter/packages/flutter_tools/pubspec.lock',
        ROOT / '.dart_tool/hooks_runner/shared/sqlite3/build/download-0a658527/libsqlite3.so',
    ]
    return {str(path): digest(path) for path in paths}


before = inputs()
runtime_before = runtime_inputs()
(OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
(OUT / 'runtime-before.json').write_text(json.dumps(runtime_before, indent=2) + '\n')
env = dict(os.environ)
env.update({
    'FLUTTER_ROOT': str(RUNTIME / 'flutter'),
    'PUB_CACHE': str(RUNTIME / 'pub-cache'),
    'TMPDIR': str(RUNTIME / 'tmp'),
    'DASH__SUPPRESS_ANALYTICS': 'true',
    'FLUTTER_SUPPRESS_ANALYTICS': 'true',
    'CI': 'true',
    'PATH': str(RUNTIME / 'flutter/bin') + ':' + str(RUNTIME / 'flutter/bin/cache/dart-sdk/bin') + ':' + env['PATH'],
})
command = [str(RUNTIME / 'flutter/bin/flutter'), 'test', '--no-pub', '--reporter', 'json',
           '--dart-define=MAIL_RECOVERY_SCREENSHOT_DIR=' + str(OUT / 'visuals'), *TESTS]
started = datetime.now(timezone.utc).isoformat()
with (OUT / 'stdout.jsonl').open('w') as stdout, (OUT / 'stderr.log').open('w') as stderr:
    result = subprocess.run(command, cwd=STUDIO, env=env, stdout=stdout, stderr=stderr, timeout=300)
after = inputs()
runtime_after = runtime_inputs()
(OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
(OUT / 'runtime-after.json').write_text(json.dumps(runtime_after, indent=2) + '\n')
events = [json.loads(line) for line in (OUT / 'stdout.jsonl').read_text().splitlines() if line.strip()]
cases = {}
failures = []
for event in events:
    if event['type'] == 'testStart':
        item = event['test']
        cases[item['id']] = {'name': item['name'], 'suite_id': item['suiteID']}
    elif event['type'] == 'testDone':
        cases[event['testID']].update(result=event['result'], hidden=event['hidden'], skipped=event['skipped'])
    elif event['type'] == 'error':
        failures.append(event)
substantive = [case for case in cases.values() if not case.get('hidden') and not case['name'].startswith('loading ')]
terminal = [event for event in events if event['type'] == 'done']
changed = sorted(path for path in set(before) | set(after) if before.get(path) != after.get(path))
runtime_changed = sorted(path for path in set(runtime_before) | set(runtime_after) if runtime_before.get(path) != runtime_after.get(path))
receipt = {
    'started_at_utc': started,
    'finished_at_utc': datetime.now(timezone.utc).isoformat(),
    'command': command,
    'cwd': str(STUDIO),
    'exit_code': result.returncode,
    'source_input_count': len(before),
    'changed_inputs': changed,
    'changed_runtime_inputs': runtime_changed,
    'passed': sum(case.get('result') == 'success' and not case.get('skipped') for case in substantive),
    'skipped': sum(bool(case.get('skipped')) for case in substantive),
    'failed': sum(case.get('result') in ['failure', 'error'] for case in cases.values()),
    'errors': len(failures),
    'terminal_events': terminal,
    'visuals': {path.name: digest(path) for path in sorted((OUT / 'visuals').glob('*.png'))},
}
receipt['accepted'] = (result.returncode == 0 and not changed and not runtime_changed
                       and receipt['passed'] == 38 and receipt['skipped'] == 0
                       and receipt['failed'] == 0 and receipt['errors'] == 0
                       and len(terminal) == 1 and terminal[0]['success'] is True)
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
(OUT / 'cases.json').write_text(json.dumps(substantive, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(0 if receipt['accepted'] else 1)
