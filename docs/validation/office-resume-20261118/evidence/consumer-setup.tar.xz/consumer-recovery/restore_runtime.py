#!/usr/bin/env python3
"""Restore exact consumer tooling from versioned evidence and available binaries."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shlex
import shutil
import subprocess
import tarfile


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo, output = args.repo.resolve(), args.output.resolve()
    output.mkdir(exist_ok=True, parents=True)
    for name in ('tmp', 'config', 'logs'):
        (output / name).mkdir(exist_ok=True)
    source = repo / 'docs/validation/office-reconciled-20261117/recovered'
    archive = source / 'consumer-intermediate-1d8325d4.tar.xz'
    index_path = source / 'consumer-intermediate-1d8325d4.tar.index.json'
    index = json.loads(index_path.read_text())
    archive_bytes = archive.read_bytes()
    assert sha(archive_bytes) == index['sha256'] == '49b519e8ef949a3dd6ff6cf1befa7f0264b90dab23da932aaa93879afc2e2951'
    assert len(archive_bytes) == index['bytes']
    indexed = {row['path']: row for row in index['members']}
    target = output / 'retained-reference'
    target.mkdir(exist_ok=True)
    restored = []
    with tarfile.open(archive) as tar:
        names = set()
        for member in tar:
            assert member.isfile(), f'Unexpected nonfile archive member: {member.name}'
            relative = PurePosixPath(member.name)
            assert not relative.is_absolute() and '..' not in relative.parts
            assert member.name not in names
            names.add(member.name)
            data = tar.extractfile(member).read()
            expected = indexed[member.name]
            assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
            path = target / member.name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            assert sha(path.read_bytes()) == expected['sha256']
            restored.append(expected)
        assert names == set(indexed)
    assert len(restored) == index['member_count'] == 710
    for name, expected in {
        'schemas/OpenDocument-v1.3-schema.rng': '40bad03efdbb02825230d357da0aa6ac679934c5bf56c6281752c0c24d58e4e6',
        'schemas/OpenDocument-v1.3-manifest-schema.rng': '8aee71f03484be112af972d622cc9031280c007b0a454ae8815e8e333c9bdd17',
        'tools/jing-20241231.jar': 'ea5e9026244d977e607d8b52212d6871498ece51939f9c49d0e7a77aad91133a',
    }.items():
        assert sha((target / name).read_bytes()) == expected
    env = dict(os.environ, TMPDIR=str(output / 'tmp'), XDG_CONFIG_HOME=str(output / 'config'))
    versions = {}
    tool_files = {}
    for tool, option in [('soffice', '--version'), ('pdftotext', '-v'), ('pdfinfo', '-v'), ('pdftoppm', '-v'), ('java', '-version')]:
        path = Path(shutil.which(tool)).resolve()
        proc = subprocess.run([tool, option], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
        (output / 'logs' / f'{tool}-version.stdout').write_bytes(proc.stdout)
        (output / 'logs' / f'{tool}-version.stderr').write_bytes(proc.stderr)
        assert proc.returncode == 0, f'{tool} failed: {proc.stderr.decode(errors="replace")}'
        versions[tool] = (proc.stdout + proc.stderr).decode().strip()
        tool_files[tool] = {'resolved_path': str(path), 'sha256': sha(path.read_bytes())}
    assert versions['soffice'] == 'LibreOfficeDev 26.8.0.0.alpha0 2c87e51eeaa2b413ff4ae097b2705eea1995d8e5'
    assert versions['pdftotext'].startswith('pdftotext version 25.03.0')
    assert versions['java'].startswith('openjdk version "21.')
    old = json.loads(gzip.decompress((target / 'qualification-1d8325d4-current7/inputs.json.gz').read_bytes()))['runtime']
    native_roots = ('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/',
                    '/opt/codex/runtimes/codex-primary-runtime/dependencies/native/poppler/')
    exact_tools = {entry['resolved_path'] for entry in tool_files.values()}
    comparisons = []
    for path, expected in old.items():
        if not path.startswith(native_roots) and path not in exact_tools:
            continue
        file = Path(path)
        actual = sha(file.read_bytes()) if file.is_file() else None
        comparisons.append({'path': path, 'expected': expected, 'actual': actual, 'matches': actual == expected})
    assert comparisons and all(row['matches'] for row in comparisons), 'Installed consumer differs from retained runtime'
    from lxml import etree
    assert tuple(etree.LXML_VERSION) == (6, 1, 1, 0)
    assert tuple(etree.LIBXML_VERSION) == (2, 14, 6)
    settings = {
        'OFFICE_CONSUMER_ROOT': str(output),
        'OFFICE_CONSUMER_REFERENCE': str(target),
        'ODF_SCHEMAS': str(target / 'schemas'),
        'JING_JAR': str(target / 'tools/jing-20241231.jar'),
        'OFFICE_PYTHON': shutil.which('python3'),
        'TMPDIR': str(output / 'tmp'),
        'XDG_CONFIG_HOME': str(output / 'config'),
    }
    (output / 'env.sh').write_text('\n'.join(f'export {k}={shlex.quote(v)}' for k, v in settings.items()) + '\n')
    report = {
        'completed_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_archive': str(archive), 'archive_sha256': index['sha256'],
        'source_index_sha256': sha(index_path.read_bytes()),
        'restored_member_count': len(restored), 'all_members_verified': True,
        'versions': versions, 'tool_files': tool_files,
        'lxml_version': list(etree.LXML_VERSION), 'libxml_version': list(etree.LIBXML_VERSION),
        'retained_runtime_comparisons': comparisons,
        'retained_runtime_comparison_count': len(comparisons),
        'all_selected_runtime_files_match': True,
        'downloaded': False, 'system_installation': False,
        'scope': 'Exact archived schema/Jing/harness recovery and comparison of available consumer binaries with retained runtime inputs; no product qualification claimed.'
    }
    (output / 'recovery.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'recovered_members': len(restored), 'matching_runtime_files': len(comparisons), 'versions': versions}))


if __name__ == '__main__':
    main()
