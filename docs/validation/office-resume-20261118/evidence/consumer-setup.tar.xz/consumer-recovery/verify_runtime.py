#!/usr/bin/env python3
"""Smoke-check recovered tools on fixed historical controls, not current product."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    reference = root / 'retained-reference'
    output = root / 'smoke'
    output.mkdir(exist_ok=False)
    env = dict(os.environ, TMPDIR=str(root / 'tmp'), XDG_CONFIG_HOME=str(root / 'config'))
    commands = []

    def run(label, command, expected=0):
        proc = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=45)
        (output / (label + '.stdout')).write_bytes(proc.stdout)
        (output / (label + '.stderr')).write_bytes(proc.stderr)
        commands.append({'label': label, 'command': command, 'exit_code': proc.returncode,
                         'expected_exit_code': expected})
        assert proc.returncode == expected, commands[-1]
        return proc

    jar = reference / 'tools/jing-20241231.jar'
    schema = reference / 'schemas/OpenDocument-v1.3-schema.rng'
    controls = []
    for name, expected in [('unchanged-styled-page-count', 0), ('linked-styled-page-count', 0),
                           ('invalid-field-child-span', 1), ('invalid-field-attribute', 1)]:
        path = reference / 'schema-controls' / (name + '.xml')
        run(name, ['java', '-jar', str(jar), '-i', str(schema), str(path)], expected)
        controls.append({'name': name, 'expected_valid': expected == 0,
                         'input_sha256': digest(path), 'observed_exit_code': expected})
    native_input = reference / 'schema-oracle/toc-fields.odt'
    profile = root / 'smoke-profile'
    run('historical-render', ['soffice', '--headless', '-env:UserInstallation=' + profile.as_uri(),
                             '--convert-to', 'pdf', '--outdir', str(output), str(native_input)])
    pdf = output / 'toc-fields.pdf'
    assert pdf.is_file() and pdf.stat().st_size > 0
    run('historical-extraction', ['pdftotext', '-bbox-layout', str(pdf), str(output / 'toc-fields.bbox.xhtml')])
    report = {'completed_at_utc': datetime.now(timezone.utc).isoformat(), 'passed': True,
              'commands': commands, 'controls': controls,
              'historical_render_input_sha256': digest(native_input),
              'historical_render_pdf_sha256': digest(pdf),
              'jing_sha256': digest(jar), 'schema_sha256': digest(schema),
              'scope': 'Tool smoke check on unchanged historical inputs; no current product/source qualification.'}
    (output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'passed': True, 'schema_controls': len(controls), 'historical_render': True}))


if __name__ == '__main__':
    main()
