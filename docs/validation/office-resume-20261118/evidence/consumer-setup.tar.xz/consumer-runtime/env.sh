export OFFICE_CONSUMER_ROOT=/workspace/scratch/5fe2474d40d1/office_qualification/consumer-runtime
export OFFICE_CONSUMER_REFERENCE=/workspace/scratch/5fe2474d40d1/office_qualification/consumer-runtime/retained-reference
export ODF_SCHEMAS=/workspace/scratch/5fe2474d40d1/office_qualification/consumer-runtime/retained-reference/schemas
export JING_JAR=/workspace/scratch/5fe2474d40d1/office_qualification/consumer-runtime/retained-reference/tools/jing-20241231.jar
export OFFICE_PYTHON=/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3
export TMPDIR=/workspace/scratch/5fe2474d40d1/office_qualification/consumer-runtime/tmp
export XDG_CONFIG_HOME=/workspace/scratch/5fe2474d40d1/office_qualification/consumer-runtime/config
