#!/usr/bin/env python3
"""Independently hash installed bytes against the compile inventory and permitted overlay."""
from datetime import datetime, timezone
import ast
import gzip
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'quds_office_suite'
FIXTURE = REPO / 'docs/validation/thesaurus-20261118/continuation/local/fixtures'
OUTPUT = ROOT / 'native-final-qualification'
BUILD = OUTPUT / 'browser-build'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_record(path, data):
    return {'path': path, 'bytes': len(data), 'sha256': sha(data)}


receipt_raw = (OUTPUT / 'receipt.json').read_bytes()
receipt = json.loads(receipt_raw)
assert receipt['status'] == 'native_passed_web_compiled_browser_not_run'
assert receipt['source_unchanged_during_tests'] is True
assert receipt['source_unchanged_during_build'] is True
bound = receipt['browser_build_binding']['compiled_files']
inventory_raw = (OUTPUT / bound['path']).read_bytes()
assert sha(inventory_raw) == bound['sha256']
compiled = json.loads(gzip.decompress(inventory_raw))
assert len(compiled) == receipt['compiled_browser_files']
assert sum(e['bytes'] for e in compiled) == receipt['compiled_browser_bytes']
expected = {e['path']: e for e in compiled}
assert len(expected) == len(compiled)

# Read only the two literal overlays from the exact bound fixture source.
# The independent scanner below does not use the installer's file_records.
installer_raw = (FIXTURE / 'install_offline.py').read_bytes()
module = ast.parse(installer_raw)
literals = {}
for statement in module.body:
    if isinstance(statement, ast.Assign) and len(statement.targets) == 1:
        target = statement.targets[0]
        if isinstance(target, ast.Name) and target.id in {'INDEX', 'INSTALL_SCRIPT'}:
            literals[target.id] = ast.literal_eval(statement.value)
assert set(literals) == {'INDEX', 'INSTALL_SCRIPT'}
expected['index.html'] = file_record('index.html', literals['INDEX'].encode())
assert 'offline-install.js' not in expected
expected['offline-install.js'] = file_record('offline-install.js', literals['INSTALL_SCRIPT'].encode())

source_meta = receipt['browser_build_binding']['source_inputs']
source_raw = (OUTPUT / source_meta['path']).read_bytes()
assert sha(source_raw) == source_meta['sha256']
source = json.loads(gzip.decompress(source_raw))
assert source['__fixture__/install_offline.py']['sha256'] == sha(installer_raw)

manifest_raw = (BUILD / 'offline-files.json').read_bytes()
manifest = json.loads(manifest_raw)
ordered_expected = [expected[name] for name in sorted(expected)]
assert manifest == ordered_expected, 'Installed inventory differs from original compile plus literal overlay'
generated = {'offline-files.json', 'offline-test-worker.js'}
observed = []
for path in sorted(BUILD.rglob('*')):
    assert not path.is_symlink(), 'Installed build contains a symlink'
    if path.is_file() and path.relative_to(BUILD).as_posix() not in generated:
        observed.append(file_record(path.relative_to(BUILD).as_posix(), path.read_bytes()))
assert observed == ordered_expected, 'Installed bytes differ from qualified compile/overlay'

# The canonical validator also checks the full generated worker text and the
# original successful build command, log bindings and all current fixture files.
sys.path.insert(0, str(FIXTURE))
from install_offline import validate_installation
records, identity, provenance = validate_installation(BUILD, OUTPUT / 'receipt.json')
assert records == observed
assert identity == sha(json.dumps(observed, sort_keys=True).encode())
unchanged = sum(e['path'] not in {'index.html'} for e in compiled)
report = dict(
    status='passed', recorded_at_utc=datetime.now(timezone.utc).isoformat(),
    scope='compiled-file integrity and test-only offline installation; browser not executed',
    source_commit=receipt['base_commit'], compile_receipt_sha256=sha(receipt_raw),
    compiled_files=len(compiled), compiled_bytes=sum(e['bytes'] for e in compiled),
    original_compiled_files_unchanged=unchanged,
    permitted_overlay_files=['index.html', 'offline-install.js'],
    installed_inventory_files=len(observed), installed_inventory_bytes=sum(e['bytes'] for e in observed),
    generated_files={name: file_record(name, (BUILD / name).read_bytes()) for name in sorted(generated)},
    cache_identity=identity, canonical_validation_passed=True, compile_provenance=provenance,
    verifier_sha256=sha(Path(__file__).read_bytes()), fixture_installer_sha256=sha(installer_raw),
    browser_execution='not_run')
(OUTPUT / 'installed-file-inventory.json.gz').write_bytes(
    gzip.compress(json.dumps(observed, indent=2).encode() + b'\n', mtime=0))
(OUTPUT / 'installed-byte-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in (
    'status', 'source_commit', 'compiled_files', 'compiled_bytes',
    'original_compiled_files_unchanged', 'installed_inventory_files',
    'installed_inventory_bytes', 'cache_identity', 'browser_execution')}, indent=2))
