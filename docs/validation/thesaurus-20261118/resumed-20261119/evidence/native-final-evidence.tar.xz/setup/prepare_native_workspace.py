#!/usr/bin/env python3
"""Prepare a separate source-linked workspace without touching source/runtime inputs."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'quds_office_suite'
RUNTIME = ROOT / 'runtime'
TASK = ROOT / 'native-validation-task'
WORKSPACE = TASK / 'zotero-validation'
TOOLCHAIN = TASK / 'zotero-toolchain'
FIXTURE = SOURCE / 'docs/validation/thesaurus-20261118/continuation/local/fixtures'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def link(path, target):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.is_symlink():
        assert path.resolve() == target.resolve(), 'Unexpected existing path: ' + str(path)
        return
    path.symlink_to(target, target_is_directory=target.is_dir())


spec = importlib.util.spec_from_file_location('workspace_binding', FIXTURE / 'workspace_binding.py')
binding = importlib.util.module_from_spec(spec)
spec.loader.exec_module(binding)
assert not TASK.exists(), 'Use a fresh native validation task root'
TASK.mkdir()
link(TASK / 'quds_office_suite', SOURCE)
WORKSPACE.mkdir()
for name in ('bin', 'tmp', 'config', 'cache', 'data', 'logs', 'setup', 'flutter-sdk/bin'):
    (TOOLCHAIN / name).mkdir(parents=True, exist_ok=True)

members = binding.workspace_members(SOURCE)
for member in members:
    (WORKSPACE / member).mkdir(parents=True, exist_ok=True)
manifests = ['pubspec.yaml', *[member + '/pubspec.yaml' for member in members]]
for relative in manifests:
    shutil.copy2(SOURCE / relative, WORKSPACE / relative)
shutil.copy2(SOURCE / 'pubspec.lock', WORKSPACE / 'pubspec.lock')
for member in members:
    for child in (SOURCE / member).iterdir():
        if child.name in binding.GENERATED:
            continue
        relative = child.relative_to(SOURCE).as_posix()
        if any(name == relative or name.startswith(relative + '/') for name in members):
            continue
        link(WORKSPACE / relative, child)
for relative in ('analysis_options.yaml', '.fvmrc', 'lib'):
    if (SOURCE / relative).exists():
        link(WORKSPACE / relative, SOURCE / relative)
for relative in binding.locked_path_dependencies(SOURCE).values():
    link(WORKSPACE / relative, SOURCE / relative)

# The runner expects these compatibility paths. Both wrappers still execute the
# already verified, unchanged official SDK with its real FLUTTER_ROOT.
for name in ('dart', 'flutter'):
    link(TOOLCHAIN / 'bin' / name, RUNTIME / 'bin' / name)
    link(TOOLCHAIN / 'flutter-sdk/bin' / name, RUNTIME / 'bin' / name)
link(TOOLCHAIN / 'flutter-sdk/bin/cache', RUNTIME / 'flutter/bin/cache')
for name in ('packages', 'engine'):
    link(TOOLCHAIN / 'flutter-sdk' / name, RUNTIME / 'flutter' / name)
link(TOOLCHAIN / 'pub-cache', RUNTIME / 'pub-cache')

settings = dict(
    PUB_CACHE=str(RUNTIME / 'pub-cache'), FLUTTER_ROOT=str(RUNTIME / 'flutter'),
    TMPDIR=str(TOOLCHAIN / 'tmp'), XDG_CONFIG_HOME=str(TOOLCHAIN / 'config'),
    XDG_CACHE_HOME=str(TOOLCHAIN / 'cache'), XDG_DATA_HOME=str(TOOLCHAIN / 'data'),
    CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true',
    DASH__SUPPRESS_ANALYTICS='true', PYTHONDONTWRITEBYTECODE='1')
env = dict(os.environ, **settings)
env['PATH'] = str(TOOLCHAIN / 'bin') + os.pathsep + env.get('PATH', '')
(TOOLCHAIN / 'env.sh').write_text(
    '\n'.join('export ' + key + '=' + shlex.quote(value) for key, value in settings.items())
    + '\nexport PATH=' + shlex.quote(str(TOOLCHAIN / 'bin')) + ':"$PATH"\n')

runtime_receipt = json.loads((RUNTIME / 'runtime.json').read_text())
bound = [RUNTIME / name for name in ('runtime.json', 'sdk-receipt.json',
         'pub-cache-receipt.json', 'env.sh', 'bin/dart', 'bin/flutter')]
bound += [Path(name) for name in runtime_receipt['executables_sha256']]
bound += [RUNTIME / 'flutter/bin/cache/flutter_tools.snapshot',
          RUNTIME / 'flutter/packages/flutter_tools/.dart_tool/package_config.json',
          SOURCE / '.dart_tool/package_config.json', SOURCE / 'pubspec.lock']
before = {str(path): sha(path) for path in bound}
record = dict(started_at_utc=datetime.now(timezone.utc).isoformat(), status='preparing',
              source=str(SOURCE), task_root=str(TASK), workspace=str(WORKSPACE),
              source_head_at_setup=subprocess.check_output(
                  ['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip(),
              runtime=str(RUNTIME), runtime_receipt_sha256=sha(RUNTIME / 'runtime.json'),
              product_tests_run=0, web_builds_run=0, github_actions='NOT USED')
receipt = TOOLCHAIN / 'setup/workspace-ready.json'
try:
    command = [str(RUNTIME / 'bin/dart'), 'pub', 'get', '--offline', '--enforce-lockfile']
    log = TOOLCHAIN / 'logs/workspace-pub-get.log'
    with log.open('wb') as stream:
        result = subprocess.run(command, cwd=WORKSPACE, env=env,
                                stdout=stream, stderr=subprocess.STDOUT, timeout=240)
    record['resolution'] = dict(command=command, cwd=str(WORKSPACE),
                               exit_code=result.returncode, log=str(log), log_sha256=sha(log))
    assert result.returncode == 0, log.read_text(errors='replace')
    assert (WORKSPACE / 'pubspec.lock').read_bytes() == (SOURCE / 'pubspec.lock').read_bytes()
    snapshot = binding.snapshot_sources(SOURCE, WORKSPACE)
    record['workspace_binding'] = snapshot['__workspace_binding__']
    record['snapshot_entry_count'] = len(snapshot)
    record['workspace_package_count'] = len(json.loads(
        (WORKSPACE / '.dart_tool/package_config.json').read_text())['packages'])
    record['manifests_sha256'] = {relative: sha(SOURCE / relative) for relative in manifests}
    record['lock_sha256'] = sha(SOURCE / 'pubspec.lock')
    record['bound_inputs_before'] = before
    record['bound_inputs_after'] = {str(path): sha(path) for path in bound}
    assert record['bound_inputs_after'] == before, 'Existing source/runtime bound input changed'
    record['status'] = 'ready_for_final_source_freeze'
except BaseException as error:
    record.update(status='failed', error=repr(error))
    raise
finally:
    record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    receipt.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: record.get(key) for key in (
        'status', 'error', 'workspace_package_count', 'snapshot_entry_count',
        'source_head_at_setup', 'lock_sha256')}, indent=2), flush=True)
