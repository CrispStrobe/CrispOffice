#!/usr/bin/env python3
"""Run the unchanged native/build harness with supplementary runtime bindings."""
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'quds_office_suite'
TASK = ROOT / 'native-validation-task'
WORKSPACE = TASK / 'zotero-validation'
TOOLCHAIN = TASK / 'zotero-toolchain'
RUNTIME = ROOT / 'runtime'
OUTPUT = ROOT / 'native-final-qualification'
FIXTURE = REPO / 'docs/validation/thesaurus-20261118/continuation/local/fixtures'
EXPECTED_HEAD = '39843ed4874c7b56572c7aa8195716e5892aeca2'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def write(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2) + '\n')


assert git('rev-parse', 'HEAD') == EXPECTED_HEAD
assert not OUTPUT.exists(), 'Preserve existing qualification evidence'
OUTPUT.mkdir()
source_head = git('rev-parse', 'HEAD')
runtime = json.loads((RUNTIME / 'runtime.json').read_text())
sdk = json.loads((RUNTIME / 'sdk-receipt.json').read_text())
assert runtime['status'] == 'ready' and sdk['archive']['verified'] is True
assert sha(RUNTIME / 'sdk-receipt.json') == runtime['sdk_receipt_sha256']
assert sha(REPO / 'pubspec.lock') == runtime['lock_sha256_after']
assert sha(RUNTIME / 'pub-cache-receipt.json') == runtime['pub_cache_receipt_sha256']
for path, expected in runtime['executables_sha256'].items():
    assert sha(path) == expected, path

spec = importlib.util.spec_from_file_location('workspace_binding', FIXTURE / 'workspace_binding.py')
binding = importlib.util.module_from_spec(spec)
spec.loader.exec_module(binding)
source = binding.snapshot_sources(REPO, WORKSPACE)
write('final-source-setup.json', dict(
    source_commit=source_head, source_tree=git('rev-parse', 'HEAD^{tree}'),
    recorded_at_utc=datetime.now(timezone.utc).isoformat(),
    original_workspace_setup= str(TOOLCHAIN / 'setup/workspace-ready.json'),
    original_workspace_setup_sha256=sha(TOOLCHAIN / 'setup/workspace-ready.json'),
    effective_workspace_binding=source['__workspace_binding__'],
    source_entries=len(source), source_lock_sha256=sha(REPO / 'pubspec.lock'),
    workspace_lock_sha256=sha(WORKSPACE / 'pubspec.lock'),
    runtime_receipt_sha256=sha(RUNTIME / 'runtime.json'),
    harness_sha256=sha(FIXTURE / 'run_final_validation.py')))

# Reuse the independently enumerated external input paths, then hash their
# actual current contents again. This list covers dependency/framework files,
# Dart snapshots/libraries, wrappers and setup receipts, not generated caches.
baseline_path = ROOT / 'combined-qualification/environment-before.json'
paths = set(json.loads(baseline_path.read_text()))
paths.update(str(p) for p in (TOOLCHAIN / 'env.sh',
    WORKSPACE / '.dart_tool/package_config.json', WORKSPACE / 'pubspec.lock',
    TOOLCHAIN / 'setup/workspace-ready.json', Path(__file__).resolve()))


def snapshot_runtime():
    return {path: sha(path) for path in sorted(paths)}


def compressed(name, data):
    value = json.dumps(data, indent=2).encode() + b'\n'
    (OUTPUT / name).write_bytes(gzip.compress(value, mtime=0))


before = snapshot_runtime()
compressed('runtime-inputs-before.json.gz', before)
record = dict(status='running', source_commit=source_head,
              started_at_utc=datetime.now(timezone.utc).isoformat(),
              input_path_list=str(baseline_path), input_path_list_sha256=sha(baseline_path),
              runtime_input_count=len(before), runtime=runtime['runtime'],
              sdk_archive=sdk['archive'], github_actions='NOT USED')
write('supplemental-runtime-receipt.json', record)
command = [sys.executable, '-B', str(FIXTURE / 'run_final_validation.py'),
           '--root', str(TASK), '--output', str(OUTPUT)]
record['command'] = command
try:
    with (OUTPUT / 'driver.stdout').open('wb') as out, (OUTPUT / 'driver.stderr').open('wb') as err:
        result = subprocess.run(command, cwd=ROOT, env=os.environ.copy(), stdout=out, stderr=err)
    record['exit_code'] = result.returncode
    final = json.loads((OUTPUT / 'receipt.json').read_text())
    record['harness_status'] = final['status']
    record['native_passed'] = final.get('test_audit', {}).get('passed')
    record['status'] = 'passed' if result.returncode == 0 and final['status'] == \
        'native_passed_web_compiled_browser_not_run' else 'failed'
except BaseException as error:
    record.update(status='failed', error=repr(error))
    raise
finally:
    after = snapshot_runtime()
    compressed('runtime-inputs-after.json.gz', after)
    record['runtime_inputs_unchanged'] = before == after
    if before != after:
        record['status'] = 'failed'
        record['changed_runtime_inputs'] = [p for p in before if before[p] != after[p]]
    record['source_head_after'] = git('rev-parse', 'HEAD')
    record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    record['evidence_hashes'] = {name: sha(OUTPUT / name) for name in (
        'final-source-setup.json', 'runtime-inputs-before.json.gz',
        'runtime-inputs-after.json.gz', 'driver.stdout', 'driver.stderr', 'receipt.json')
        if (OUTPUT / name).exists()}
    write('supplemental-runtime-receipt.json', record)
    print(json.dumps({k: record.get(k) for k in (
        'status', 'harness_status', 'native_passed', 'runtime_inputs_unchanged', 'error')}, indent=2), flush=True)
sys.exit(0 if record['status'] == 'passed' else 1)
