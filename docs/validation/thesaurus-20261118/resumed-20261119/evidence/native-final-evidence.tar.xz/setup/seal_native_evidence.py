#!/usr/bin/env python3
"""Seal native/build/install evidence, explicitly excluding generated application bytes."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'native-final-qualification'
REPO = ROOT / 'quds_office_suite'
TASK = ROOT / 'native-validation-task'
TOOLCHAIN = TASK / 'zotero-toolchain'
SETUP = OUT / 'setup'
SETUP.mkdir(exist_ok=False)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n')


sources = {
    'prepare_native_workspace.py': ROOT / 'prepare_native_workspace.py',
    'run_native_qualification.py': ROOT / 'run_native_qualification.py',
    'verify_native_installation.py': ROOT / 'verify_native_installation.py',
    'seal_native_evidence.py': Path(__file__).resolve(),
    'env.sh': TOOLCHAIN / 'env.sh',
    'workspace-ready.json': TOOLCHAIN / 'setup/workspace-ready.json',
    'workspace-pub-get.log': TOOLCHAIN / 'logs/workspace-pub-get.log',
    'outer-runner.stdout': ROOT / 'native-final-qualification.runner.log',
    'runtime.json': ROOT / 'runtime/runtime.json',
    'sdk-receipt.json': ROOT / 'runtime/sdk-receipt.json',
    'pub-cache-receipt.json': ROOT / 'runtime/pub-cache-receipt.json',
    'environment-preflight.json': ROOT / 'runtime/environment-preflight.json',
}
for name, source in sources.items():
    shutil.copyfile(source, SETUP / name)

receipt = json.loads((OUT / 'receipt.json').read_text())
runtime = json.loads((OUT / 'supplemental-runtime-receipt.json').read_text())
installed = json.loads((OUT / 'installed-byte-verification.json').read_text())
packet = json.loads((OUT / 'linguistic/linguistic-review.json').read_text())
native = json.loads((OUT / 'native-pack-report.json').read_text())
assert receipt['status'] == 'native_passed_web_compiled_browser_not_run'
assert runtime['status'] == 'passed' and runtime['runtime_inputs_unchanged']
assert installed['status'] == 'passed'
assert packet['review_status'] == 'not_reviewed'
assert packet['queries'] == native['queries']
assert packet['report']['sha256'] == sha(OUT / 'native-pack-report.json')
assert all(packet[key] is None for key in (
    'reviewer', 'reviewed_at', 'language_expertise', 'release_recommendation'))
assert packet['additional_cases'] == []
assert len(packet['decisions']) == len(packet['queries'])
assert all(row['decision'] is None and row['notes'] is None and
           row['sense_ids'] == [] and row['term_ids'] == [] for row in packet['decisions'])
ids = {sense['id'] for query in packet['queries'] for sense in query['senses']}
assert set(packet['source_records']) == ids
notices = []
pack_root = REPO / 'packages/quds_office_editor/assets/thesaurus'
for locale, pack in packet['packs'].items():
    manifest_path = pack_root / locale / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    assert pack['identity'] == manifest['packId'] + ':' + sha(manifest_path)
    for notice in pack['notices']:
        original = pack_root / locale / notice['path']
        exported = OUT / 'linguistic' / notice['export_path']
        metadata = manifest['files'][notice['path']]
        assert exported.read_bytes() == original.read_bytes()
        assert exported.stat().st_size == notice['bytes'] == metadata['size']
        assert sha(exported) == notice['sha256'] == metadata['sha256']
        notices.append(dict(locale=locale, path=notice['path'],
                            bytes=notice['bytes'], sha256=notice['sha256']))
assert len(notices) == 10
write('linguistic-export-receipt.json', dict(
    status='source_verified_not_reviewed', source_commit=receipt['base_commit'],
    queries=len(packet['queries']), distinct_source_records=len(ids), notices=notices,
    report_sha256=sha(OUT / 'native-pack-report.json'),
    packet_json_sha256=sha(OUT / 'linguistic/linguistic-review.json'),
    packet_markdown_sha256=sha(OUT / 'linguistic/linguistic-review.md'),
    exporter_sha256=sha(REPO / 'tools/thesaurus/export_review_packet.py'),
    source_helper_sha256=sha(REPO / 'tools/thesaurus/build_packs.py'),
    human_review_completed=False,
    export_command=['python3', '-B', str(REPO / 'tools/thesaurus/export_review_packet.py'),
                    '--report', str(OUT / 'native-pack-report.json'),
                    '--output', str(OUT / 'linguistic')],
    integrity_checks='Export performed manifest/shard validation; exact packet/report, IDs, blank decisions and all original notice bytes rechecked at sealing.'))

write('bundle-summary.json', dict(
    status='native_passed_web_compiled_installation_verified_browser_not_run',
    source_commit=receipt['base_commit'], source_tree=json.loads(
        (OUT / 'final-source-setup.json').read_text())['source_tree'],
    native_cases=receipt['test_audit']['passed'], native_suites=receipt['test_audit']['suite_count'],
    case_count_scope='Native command; cases overlap the separate combined affected-suite replay.',
    source_unchanged_during_tests=receipt['source_unchanged_during_tests'],
    source_unchanged_during_build=receipt['source_unchanged_during_build'],
    captured_runtime_inputs=runtime['runtime_input_count'],
    captured_runtime_inputs_unchanged=runtime['runtime_inputs_unchanged'],
    compiled_files=installed['compiled_files'], compiled_bytes=installed['compiled_bytes'],
    installed_inventory_files=installed['installed_inventory_files'],
    installed_inventory_bytes=installed['installed_inventory_bytes'],
    cache_identity=installed['cache_identity'],
    linguistic_review_status=packet['review_status'],
    browser_execution='not_run', installed_native_desktop='not_run', human_review='not_completed',
    compiled_build_local_path=str(OUT / 'browser-build'),
    compiled_bytes_archived=False,
    archive_exclusion='browser-build/ is retained locally and omitted from the compact evidence archive; original compiled and installed inventories, receipts and logs are included.',
    compiler_warnings=['Deprecated --pwa-strategy option',
                       'Wider editor references packages/cupertino_icons/CupertinoIcons without a bundled font'],
    recorded_at_utc=datetime.now(timezone.utc).isoformat()))

bundle = ROOT / 'native-final-bundle'
bundle.mkdir(exist_ok=False)
archive = bundle / 'native-final-evidence.tar.xz'
paths = [p for p in sorted(OUT.rglob('*')) if p.is_file()
         and p.relative_to(OUT).parts[0] != 'browser-build']
entries = []
with tarfile.open(archive, 'w:xz') as target:
    for path in paths:
        assert not path.is_symlink()
        relative = path.relative_to(OUT).as_posix()
        entries.append(dict(path=relative, bytes=path.stat().st_size, sha256=sha(path)))
        target.add(path, arcname=relative, recursive=False)
with tarfile.open(archive) as source:
    members = source.getmembers()
    assert len(members) == len(entries)
    assert [m.name for m in members] == [e['path'] for e in entries]
    for member, entry in zip(members, entries):
        value = source.extractfile(member).read()
        assert len(value) == entry['bytes']
        assert hashlib.sha256(value).hexdigest() == entry['sha256']
index = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive),
             source_commit=receipt['base_commit'], member_count=len(entries),
             readback_verified=True, excluded_directories=['browser-build'], files=entries)
(bundle / 'native-final-evidence-index.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({key: value for key, value in index.items() if key != 'files'}, indent=2))
