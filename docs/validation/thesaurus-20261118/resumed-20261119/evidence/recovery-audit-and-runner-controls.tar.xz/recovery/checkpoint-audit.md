# Independent audit of the recovered checkpoint

Audited checkpoint: `7e4adc08fce78fb95524f304962f9c1804e18691`.
This audit replays saved event records and checks their source inventories. It
does not execute application tests or verify a currently running browser.

## Evidence recovered

All nine archives under `docs/validation/thesaurus-20261118/reconciled/evidence`
match their committed SHA-256 and byte-count records. Their 215 files were
extracted without links or path traversal. Every member of the eight archives
with per-file indexes matches that index. The native release archive has a
76-member archive-level index rather than a separate digest for every member;
its complete archive digest matches.

An independent event counter, rather than the application runner's parser,
reconstructs these results:

| Saved cohort | Substantive passes | Qualification scope |
| --- | ---: | --- |
| Mail core/store/MIME | 152 distinct; 250 runtime executions | VM and Node cases; repeated platforms do not increase distinct case counts |
| Final native thesaurus fixture | 208 in 14 suites | Headless native tests at the final Notes fix |
| Focused Notes pane fix | 28 in 2 suites | Both selected pane suites; included again in the planned union |
| Earlier Notes test repair | 33 | Historical bounded test repair; not a final combined run |

The accepted raw logs contain no failures, skips, unfinished cases, duplicate
completions, error events, or detected overflow/missed-tap diagnostics. Lifecycle
and loading events were excluded from substantive pass counts. The saved Python
control records report 34 final Mail parser methods, 36 workspace/browser
harness methods, and 7 exporter methods. Repeated earlier control runs are not
added to these totals.

The final native inventory and focused Notes inventory each contain 4,991
ordinary source records. Every recorded SHA-256 matches the corresponding Git
blob at the recovered checkpoint. The Notes fixture was originally tested as a
working-tree patch against `a6c165d3`; those exact tested bytes are present at
the later committed checkpoint. Mail's application records also match. Only
the parser/control files changed after the original Mail execution, and their
final replay/control receipts are saved separately.

The native evidence includes successful release-compilation receipts and
inventories for 1,155 compiled files, plus preparation/verification receipts for
1,156 installed files. The generated build files themselves are not stored in
the compact archive. This audit verifies the saved evidence, not a fresh copy
of those generated files.

## Work that was not saved as a completed run

There is no saved receipt or raw log set for a successful complete 129-suite
union. Its committed plan contains 42 engine, 73 editor, 10 Studio and 4 Mail UI
suites. The earlier handoff's reported 714 engine passes and a later interrupted
full rerun are not recoverable from this checkpoint's combined-run evidence.
They must not be used as current accepted combined results.

The documented replay command is:

```sh
python3 docs/validation/thesaurus-20261118/reconciled/run_targeted.py \
  --runtime /absolute/verified-runtime \
  --output /absolute/new-combined-evidence \
  --concurrency 4
```

The incoming reconciliation may change selected tests and source inventories;
the new run must bind its own committed source and current runtime. Existing
native/Mail results remain explicitly historical source-bound evidence.

Actual offline-browser execution, installed Studio/real OS-IME checks and
independent human English/German linguistic review remain unqualified. The
saved packet contains 15 observed queries, 109 meaning records and ten notice
files; its human judgments are blank.

## Targeted runner fixes

The continuation's runner changes are limited to four concrete failure modes
and bounded execution configuration:

- Malformed suite/test records now produce inspectable rejection instead of
  raising during supplementary suite accounting.
- Flutter overflow and missed-tap diagnostics reject otherwise successful
  stdout or stderr results.
- Preflight errors write an atomic failed receipt to a new output directory;
  prior evidence is never overwritten.
- Timeout/interruption cleanup terminates the entire spawned process group,
  including descendants that ignore SIGTERM.
- Positive `--concurrency` (default 4) and `--timeout` arguments are recorded in
  the receipt; application groups still execute sequentially.

The adjacent `test_run_targeted.py` has 14 passing controls, including a real
SIGTERM-ignoring child process. Exact commands, source hashes, stdout/stderr
and the result are saved under `targeted-runner-controls/`. These controls do
not add application passes. The source, dependency, runtime and plan binding
requirements remain in effect.

Machine-readable details are in `checkpoint-audit.json` and
`archive-audit.json`. The independent reproduction script is
`audit_checkpoint.py`.
