#!/usr/bin/env python3
"""Independent inspection of the saved 7e4adc08 checkpoint; no test execution."""
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'quds_office_suite'
COMMIT = '7e4adc08fce78fb95524f304962f9c1804e18691'


def read(path):
    path = Path(path)
    return json.loads(gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes())


def events(path):
    records = []
    for number, line in enumerate(Path(path).read_text().splitlines(), 1):
        line = line.strip()
        for _ in range(10):
            prefix = next((p for p in ('Running build hooks...', 'Running link hooks...') if line.startswith(p)), None)
            if not prefix:
                break
            line = line[len(prefix):].lstrip()
        if line:
            records.append((number, json.loads(line)))
    return records


def inspect_events(path):
    stream = events(path)
    starts = [e['test'] for _, e in stream if e.get('type') == 'testStart']
    tests = {e['id']: e for e in starts}
    suites = {e['suite']['id']: e['suite']['path'] for _, e in stream if e.get('type') == 'suite'}
    done = [e for _, e in stream if e.get('type') == 'testDone']
    counts = Counter(e['testID'] for e in done)
    substantive = []
    for e in done:
        t = tests.get(e['testID'], {})
        if e.get('hidden') or t.get('name', '').startswith('loading ') or re.search(r'(?:^| )\((?:setUpAll|tearDownAll)\)$', t.get('name', '')):
            continue
        substantive.append((suites.get(t.get('suiteID')), t.get('name'), e['result'], e.get('skipped')))
    diagnostics = [(n, e) for n, e in stream if e.get('type') == 'print' and re.search(r'A Render\w+ overflowed|would not hit test on the specified widget|does not receive pointer events', e.get('message', ''))]
    return {
        'path': str(Path(path).relative_to(ROOT)),
        'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest(),
        'passed': sum(v[2] == 'success' and not v[3] for v in substantive),
        'failed_including_lifecycle': sum(e.get('result') != 'success' for e in done),
        'skipped_including_lifecycle': sum(bool(e.get('skipped')) for e in done),
        'suite_count': len(suites),
        'duplicate_starts': len(starts) - len(tests),
        'duplicate_done': sum(v - 1 for v in counts.values()),
        'incomplete': len(set(tests) - set(counts)),
        'orphan_done': len(set(counts) - set(tests)),
        'error_events': sum(e.get('type') == 'error' for _, e in stream),
        'terminals': [e for _, e in stream if e.get('type') == 'done'],
        'layout_or_tap_diagnostics': diagnostics,
        'cases': [{'file': (p.split('/quds_office_suite/')[-1] if p else p), 'name': n} for p, n, _, _ in substantive],
    }


def compare_sources(snapshot):
    records = {p: v['sha256'] if isinstance(v, dict) else v for p, v in snapshot.items() if not p.startswith('__')}
    git = subprocess.Popen(['git', '-C', str(REPO), 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    mismatches = []
    try:
        for path, expected in records.items():
            git.stdin.write((COMMIT + ':' + path + '\n').encode())
            git.stdin.flush()
            header = git.stdout.readline().decode().rstrip()
            if header.endswith(' missing'):
                mismatches.append({'path': path, 'reason': 'missing_at_checkpoint'})
                continue
            sha, kind, size = header.split()
            data = git.stdout.read(int(size))
            assert git.stdout.read(1) == b'\n'
            actual = hashlib.sha256(data).hexdigest()
            if actual != expected:
                mismatches.append({'path': path, 'recorded_sha256': expected, 'checkpoint_sha256': actual})
    finally:
        git.stdin.close()
        git.wait()
    return {'checked': len(records), 'mismatches': mismatches}


mail = read(ROOT / 'mail/summary.json')
mail_logs = [inspect_events(ROOT / 'mail' / cohort['raw_log']) for cohort in mail['cohorts']]
mail_identities = {(c['file'], c['name']) for result in mail_logs for c in result['cases']}
native_root = ROOT / 'thesaurus-release/thesaurus-release-validation/run-3'
native = inspect_events(native_root / 'logs/native-acceptance.stdout')
notes = inspect_events(ROOT / 'notes-review-fix/test.stdout')
notes_repair = inspect_events(ROOT / 'notes-repair/final-tests.jsonl')
source_checks = {
    'native_final': compare_sources(read(native_root / 'source-inputs.json.gz')),
    'notes_fix': compare_sources(read(ROOT / 'notes-review-fix/source-before.json.gz')),
    'mail_store': compare_sources(read(ROOT / 'mail/store-attempt-2-offline/receipt.json')['source_before']),
    'mail_mime': compare_sources(read(ROOT / 'mail/mime-attempt-1/receipt.json')['source_before']),
}
report = {
    'checkpoint': COMMIT,
    'activity': 'Independent replay of saved JSON events and comparison with checkpoint Git blobs; no fresh application tests.',
    'archives': read(ROOT / 'archive-audit.json'),
    'mail_distinct_cases': len(mail_identities),
    'mail_runtime_case_executions': sum(r['passed'] for r in mail_logs),
    'mail_cohorts': mail_logs,
    'native_final': native,
    'notes_fix': notes,
    'notes_repair_earlier_source': notes_repair,
    'source_checks': source_checks,
    'combined_129_suite_results_saved': False,
}
(ROOT / 'checkpoint-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({
    'mail_distinct': report['mail_distinct_cases'],
    'mail_executions': report['mail_runtime_case_executions'],
    'native_passed': native['passed'],
    'notes_passed': notes['passed'],
    'earlier_notes_repair_passed': notes_repair['passed'],
    'source_comparisons': source_checks,
}, indent=2))
