# Notes controller regression fixture repair

## Outcome

The final isolated Notes controller suite passed **33 substantive cases**, with zero failures, skips, unfinished cases, or error events; process exit was zero and the reporter ended with success. The complete source manifests before and after the run match. This is targeted qualification, not a whole-repository result.

The run used the provided `runtime/env.sh` and pinned Flutter/Dart wrapper:

```sh
flutter test --no-pub --concurrency=1 --reporter=json test/word_notes_proofing_controller_test.dart
```

Working directory: `packages/quds_office_editor`. Repository HEAD was `0ea205e0ee35bb43635960a0edafd42dc4c16e8d`, with the exact repaired test source preserved as `final-test.dart.txt` and bound by the manifests. No application library was changed by this repair. The sole tracked edit is `packages/quds_office_editor/test/word_notes_proofing_controller_test.dart`.

## Fixture defects corrected

1. The `_bodyAt` helper assigned nullable values to nonnullable `CaretEngine` anchors. A collapsed selection uses the current paragraph and offset, so an absent optional anchor now means `anchor ?? offset`, in paragraph zero.
2. Two mixed ordinary/manual tests used overlapping findings. `mergeOfficeProofingReports` intentionally suppresses an overlapping secondary/manual proposal. The fixture now uses distinct typos in the same paragraph (`Feler` and `Gramatik`), preserving ordinary-first order, both correction paths, alias identity, and the assertion that no provider rerun occurs across the history commit.
3. The IME test created a body revision with `WordRevisions.record`, which enables tracking. Its old expected plain replacement contradicted tracked deletion/insertion. It now asserts the retained deletion and insertion spans and both undo steps, while preserving the original body revision. The active-composition refusal assertions are unchanged.

Only the assigned test was formatted. The recovered original test had extensive formatting drift; the larger textual diff includes that formatter output.

## Preserved attempts

- `original-combined-*`: untouched copies of the earlier combined narrow run. The Notes controller suite failed to compile with two nullable-anchor diagnostics and completed zero substantive cases. Other suites in that combined attempt do not count as an isolated Notes rerun. The combined run exited one and ended unsuccessfully.
- `fixed-*`, `helper-only-*`, and `source-before/after.json`: helper-only repair. Compilation succeeded; 30 cases passed and three fixture assertions failed. Those failures exposed the overlapping-provider and tracking assumptions above. Exit one; terminal success false; source manifests unchanged.
- `final-*`: the final fixture repair and successful isolated suite, with all 33 cases passing. Prior/repeated cases are not added to this total.

No GitHub Actions execution, status, wait, rerun, or dispatch was used. The author of this repair did not commit or push; publication is owned by the parent task.
