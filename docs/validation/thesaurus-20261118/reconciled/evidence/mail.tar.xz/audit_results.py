#!/usr/bin/env python3
"""Reconstruct distinct Mail cases from raw Dart reporter events."""
from datetime import datetime, timezone
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
from urllib.parse import unquote, urlparse

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--evidence-root', type=Path, default=Path(__file__).resolve().parent)
args = parser.parse_args()
ROOT = args.evidence_root.resolve()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


cohorts = []
unique = {}
for directory in ['store-attempt-2-offline', 'mime-attempt-1']:
    receipt_path = ROOT / directory / 'receipt.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'PASS'
    assert receipt['source_unchanged'] is True
    for check in receipt['checks']:
        assert check['status'] == 'PASS' and check['exit_code'] == 0
        assert sha(ROOT / directory / check['log']) == check['log_sha256']
        if not check.get('tests'):
            continue
        path = ROOT / directory / check['log']
        suites = {}
        cases = {}
        starts = 0
        terminals = []
        errors = []
        for number, line in enumerate(path.read_text().splitlines(), 1):
            start = line.find('{')
            if start < 0:
                continue
            event = json.loads(line[start:])
            kind = event['type']
            assert not terminals, f'{path}:{number}: event after terminal'
            if kind == 'start':
                starts += 1
            elif kind == 'suite':
                suite = event['suite']
                assert suite['id'] not in suites
                suites[suite['id']] = suite
            elif kind == 'testStart':
                test = event['test']
                assert test['id'] not in cases
                cases[test['id']] = dict(test)
            elif kind == 'testDone':
                test = cases[event['testID']]
                assert 'completion' not in test
                test['completion'] = event
            elif kind == 'error':
                errors.append(event)
            elif kind == 'done':
                terminals.append(event)
        assert starts == 1 and len(terminals) == 1 and terminals[0]['success'] is True
        assert not errors
        accepted = []
        excluded = []
        for test in cases.values():
            done = test['completion']
            assert done['result'] == 'success' and done['skipped'] is False
            lifecycle = re.search(r'\((?:setUpAll|tearDownAll)\)$', test['name']) is not None
            if done['hidden'] or test['name'].startswith('loading ') or lifecycle:
                excluded.append(test['name'])
                continue
            suite = suites[test['suiteID']]
            source = Path(unquote(urlparse(test['url']).path)) if test.get('url', '').startswith('file:') else Path(check['cwd']) / suite['path']
            # Raw reporter URLs preserve the historical machine path. The
            # package suffix gives the stable repository-relative identity.
            parts = source.parts
            assert 'packages' in parts
            relative = str(Path(*parts[parts.index('packages'):]))
            key = relative + '::' + test['name']
            assert key not in {x['key'] for x in accepted}, 'Duplicate case identity within cohort'
            entry = {'key': key, 'file': relative, 'name': test['name'], 'platform': suite['platform']}
            accepted.append(entry)
            unique.setdefault(key, {'file': relative, 'name': test['name'], 'platforms': [], 'cohorts': []})
            if suite['platform'] not in unique[key]['platforms']:
                unique[key]['platforms'].append(suite['platform'])
            unique[key]['cohorts'].append(check['name'])
        assert len(accepted) == check['tests']['passed'], 'Runner count differs from independent reconstruction'
        cohorts.append({'name': check['name'], 'receipt': str(receipt_path.relative_to(ROOT)), 'receipt_sha256': sha(receipt_path), 'raw_log': str(path.relative_to(ROOT)), 'raw_log_sha256': sha(path), 'exit_code': check['exit_code'], 'passed': len(accepted), 'excluded_loading_lifecycle_events': len(excluded), 'cases': accepted})

process = json.loads((ROOT / 'store-attempt-2-offline/process-receipt.json').read_text())
assert process['process_exit_code'] == 0
mime_process = json.loads((ROOT / 'mime-attempt-1/process-receipt.json').read_text())
assert mime_process['invocation_exit_code'] == 0
controls = (ROOT / 'store-attempt-2-offline/runner-regressions.log').read_text()
assert re.search(r'\nOK\s*$', controls)
control_count = int(re.search(r'Ran (\d+) tests', controls)[1])
control_runs = [{'path': 'store-attempt-2-offline/runner-regressions.log', 'methods': control_count}]
final_controls_path = ROOT / 'final-parser-reconciliation/controls-receipt.json'
if final_controls_path.is_file():
    final_controls = json.loads(final_controls_path.read_text())
    final_log = ROOT / 'final-parser-reconciliation/controls.log'
    assert final_controls['exit_code'] == 0 and final_controls['source_unchanged'] is True
    assert sha(final_log) == final_controls['stdout_stderr_sha256']
    assert re.search(r'\nOK\s*$', final_log.read_text())
    original_names = set(re.findall(r'^(test_[A-Za-z0-9_]+) \(', controls, re.M))
    final_names = set(final_controls['method_names'])
    assert len(original_names) == control_count and original_names <= final_names
    assert len(final_names) == final_controls['distinct_methods']
    control_count = len(final_names)
    replay = json.loads((ROOT / 'final-parser-reconciliation/raw-replay.json').read_text())
    assert replay['status'] == 'PASS' and replay['distinct_dart_cases'] == len(unique)
    assert all(x['product_and_dependency_inputs_unchanged'] for x in replay['source_comparisons'])
    assert all(x['case_set_unchanged'] and x['summary']['valid'] and x['original_process_exit_code'] == 0 for x in replay['replayed_cohorts'])
    control_runs.append({'path': 'final-parser-reconciliation/controls.log', 'methods': control_count})
packages = {}
for item in unique.values():
    package = item['file'].split('/')[1]
    packages[package] = packages.get(package, 0) + 1
result = {'status': 'PASS', 'recorded_utc': datetime.now(timezone.utc).isoformat(), 'distinct_dart_cases': len(unique), 'runtime_case_executions': sum(x['passed'] for x in cohorts), 'distinct_python_controls': control_count, 'python_control_runs': control_runs, 'distinct_cases_and_controls': len(unique) + control_count, 'packages': packages, 'cohorts': cohorts, 'distinct_cases': [unique[k] for k in sorted(unique)], 'discarded_attempts': [{'path': 'store-attempt-1', 'status': 'INTERRUPTED', 'accepted_cases': 0, 'reason': 'External invocation interrupted with exit130; partial attempt is not included.'}], 'browser_runtime': 'NOT RUN: Node and compilation do not qualify browser storage.'}
(ROOT / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k not in {'cohorts','distinct_cases'}}, indent=2))
