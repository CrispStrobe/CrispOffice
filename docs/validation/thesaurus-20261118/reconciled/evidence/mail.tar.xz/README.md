# Mail local qualification — 18 November 2026

The full store gate and supplemental MIME gate passed with process exit code 0.
No GitHub Actions check was used. Actual browser persistence and reader rendering
remain unqualified; Node execution and JavaScript compilation do not close them.

## Final parser reconciliation

After the newer Mail continuation was merged, the runner retained the stricter
build/link-hook prefix handling, rejection of scalar/array or unstructured
records, all-failure/all-skip and excluded-event counters, and the offline flag.
All **34 distinct controls** pass. They include every one of the earlier 23;
the earlier controls are not added again.

The final parser revalidated all six accepted Dart streams with identical case
sets and counts. The recorded Mail application and dependency inputs remain
byte-identical; only the expected runner files changed. See
`final-parser-reconciliation/controls-receipt.json` and `raw-replay.json`.
This final accounting is **152 distinct Dart cases + 34 controls = 186**.
The original execution cohorts below remain unchanged.

## Original accepted results

| Cohort | Passed runtime executions | Distinct-case treatment |
| --- | ---: | --- |
| Mail core VM | 30 | 30 core cases |
| Mail core Node | 30 | Same 30 core cases |
| Mail store VM | 87 | 87 store cases |
| Portable store Node | 39 | 36 repeated cases plus 3 browser-error policy cases |
| Mail MIME VM | 32 | 32 MIME cases |
| Mail MIME Node | 32 | Same 32 MIME cases |
| Runner Python controls | 23 | 23 controls, counted once |

This is **152 distinct Dart cases** across 250 runtime case executions, plus
**23 distinct Python controls**: **175 distinct cases and controls**. Loading and
lifecycle events, repeated runtimes, and the interrupted attempt are excluded.
`summary.json` preserves every distinct case identity and cohort membership.

Strict fatal-info analysis and formatting passed for Mail core, store and MIME.
The store browser entry and worker compiled. MIME's portable entry compiled and
produced byte-identical native/Node projection output. The store suite exercised
real SQLite files, migrations, ownership, transaction rollback and process-kill
recovery. The actual default SQLite hook binary matches the package-pinned hash;
`native-asset-receipt.json` records it. No system SQLite override was used.

## Source and commands

The accepted store run is `store-attempt-2-offline/`. Its 53-entry source inventory
was identical before and after all commands. The accepted MIME run is
`mime-attempt-1/`; its 306-entry source inventory was also unchanged. The final
application sources still match both inventories. MIME finished before the
store runner's command-line-only `--offline` option was added; that one runner
file differs from MIME's inventory, while its event-accounting function is
unchanged. Every command, exit code, raw-log hash and source hash is retained.

The formatter repaired one indentation-only line in
`packages/quds_mail_store/test/native_platform_test.dart`; the original check,
repair output, byte hashes and diff are under `preflight/`. No other Mail
application code was changed during this qualification.

The store runner gained an opt-in `--offline` flag that affects only `pub get`;
`--enforce-lockfile` and every validation check remain mandatory. The accepted
run records both flags in its actual command log. The workspace lock stayed at
`35d1ef372908f4ab278973355ec6a957cd3240bea115d615056c5b9e398df974`.

The frozen source hashes are authoritative when the starting commit precedes
uncommitted parser/formatting preparation. Starting commits are recorded below:

- Store: `0ea205e0ee35bb43635960a0edafd42dc4c16e8d`.
- MIME: `0ea205e0ee35bb43635960a0edafd42dc4c16e8d`.

## Preserved interrupted attempt

`store-attempt-1/` is not accepted qualification. Its online resolution took
longer than necessary given the already verified offline cache. At the time an
external interrupt reached the invocation, resolution had completed and the
runner had advanced to core Node. The outer invocation exited 130. The original
partial runner receipt remains in its last observed RUNNING state; the companion
`interruption.json` closes this attempt as INTERRUPTED, with no invented child
exit code and no accepted cases. No failed or partial evidence was overwritten.

## Replay the result audit

```sh
python3 audit_results.py --evidence-root /path/to/this/directory
```

The audit independently reconstructs case identities from raw Dart events,
requires complete successful lifecycle/test pairs, checks terminal outcomes and
process exits, verifies raw-log hashes, and rejects inflated cross-runtime counts.
It writes `summary.json`. It does not execute application tests.
