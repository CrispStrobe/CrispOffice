#!/usr/bin/env python3
"""Save source-bound local MIME checks with raw output and exit-status truth."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'quds_office_suite'
OUT = ROOT / 'mime-attempt-1'
OUT.mkdir(exist_ok=False)
MIME = REPO / 'packages/quds_mail_mime'
sys.path.insert(0, str(REPO / 'tools/mail'))
from check_store import test_summary


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory():
    files = [REPO / x for x in ['.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', 'tools/mail/check_store.py']]
    for relative in ['packages/quds_mail_core', 'packages/quds_mail_mime', 'third_party/enough_mail']:
        for path in (REPO / relative).rglob('*'):
            if path.is_file() and not any(x in {'.dart_tool', 'build', '.git', '__pycache__', 'ephemeral'} for x in path.parts):
                files.append(path)
    return {str(path.relative_to(REPO)): sha(path) for path in sorted(set(files))}


receipt = {'status': 'RUNNING', 'started_utc': datetime.now(timezone.utc).isoformat(), 'starting_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(), 'runtime_receipt_sha256': sha(ROOT.parent / 'runtime/runtime.json'), 'source_before': inventory(), 'checks': [], 'github_actions': 'NOT USED'}


def save():
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')


def run(name, command, tests=False, cwd=MIME):
    path = OUT / (name + ('.jsonl' if tests else '.log'))
    item = {'name': name, 'command': command, 'cwd': str(cwd), 'status': 'RUNNING', 'exit_code': None, 'log': path.name}
    receipt['checks'].append(item)
    save()
    print(name, flush=True)
    with path.open('wb') as log:
        process = subprocess.run(command, cwd=cwd, env=os.environ, stdout=log, stderr=subprocess.STDOUT, timeout=300)
    item.update(exit_code=process.returncode, log_sha256=sha(path))
    valid = process.returncode == 0
    if tests:
        summary = test_summary(path)
        case_path = OUT / (name + '-cases.json')
        case_path.write_text(json.dumps(summary, indent=2) + '\n')
        item['tests'] = {k: v for k, v in summary.items() if k != 'cases'}
        item['case_list'] = case_path.name
        valid = valid and summary['valid']
    item['status'] = 'PASS' if valid else 'FAIL'
    save()
    return valid


try:
    save()
    ok = run('mime-analysis', ['dart', 'analyze', '--fatal-infos'])
    ok &= run('mime-format', ['dart', 'format', '--output=none', '--set-exit-if-changed', 'lib', 'test'])
    ok &= run('mime-vm', ['dart', 'test', '--platform', 'vm', '--reporter', 'json', '--concurrency=1'], tests=True)
    ok &= run('mime-node', ['dart', 'test', '--platform', 'node', '--reporter', 'json', '--concurrency=1'], tests=True)
    js = OUT / 'mime-portable.js'
    compiled = run('mime-js-compile', ['dart', 'compile', 'js', 'test/compile/portable_import.dart', '-o', str(js)])
    ok &= compiled
    native = run('mime-vm-projection', ['dart', 'test/compile/portable_import.dart'])
    node = run('mime-node-projection', ['node', str(js)]) if compiled else False
    equal = native and node and (OUT / 'mime-vm-projection.log').read_bytes() == (OUT / 'mime-node-projection.log').read_bytes()
    receipt['projection_equal'] = equal
    ok &= equal
    receipt['source_after'] = inventory()
    receipt['source_unchanged'] = receipt['source_before'] == receipt['source_after']
    ok &= receipt['source_unchanged']
    receipt['status'] = 'PASS' if ok else 'FAIL'
except BaseException as error:
    receipt['status'] = 'FAIL'
    receipt['error'] = repr(error)
    raise
finally:
    receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(receipt['status'], flush=True)
sys.exit(0 if receipt['status'] == 'PASS' else 1)
