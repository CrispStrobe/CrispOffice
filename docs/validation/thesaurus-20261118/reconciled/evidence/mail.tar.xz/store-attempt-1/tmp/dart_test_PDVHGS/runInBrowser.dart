        // @dart=3.12
        import "package:test/src/bootstrap/node.dart";

        import "file:///workspace/scratch/f3cf174091b0/quds_office_suite/packages/quds_mail_core/test/outbox_test.dart" as test;

        void main() {
          internalBootstrapNodeTest(() => test.main);
        }
      