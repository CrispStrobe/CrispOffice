#!/usr/bin/env python3
"""Download only archives whose hashes are pinned in supplied lockfiles."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import io
import json
import shutil
import sys
import tarfile
import urllib.parse
import urllib.request
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parent
CACHE = ROOT / 'pub-cache'
packages = {}
locks = []
previous_path = ROOT / 'pub-cache-receipt.json'
previous = json.loads(previous_path.read_text()) if previous_path.exists() else None
verified_previous = {x['name'] + '-' + x['version']: x for x in previous['archives']} if previous else {}
previous_hash = hashlib.sha256(previous_path.read_bytes()).hexdigest() if previous else None
if previous:
    (ROOT / ('pub-cache-receipt-' + previous_hash[:12] + '.json')).write_bytes(previous_path.read_bytes())
for arg in sys.argv[1:]:
    lock = Path(arg).resolve()
    data = lock.read_bytes()
    locks.append({'path': str(lock), 'sha256': hashlib.sha256(data).hexdigest()})
    for name, item in yaml.safe_load(data)['packages'].items():
        if item['source'] != 'hosted':
            continue
        info = item['description']
        if info['url'] != 'https://pub.dev':
            raise RuntimeError('Unexpected package host')
        key = name + '-' + item['version']
        entry = {'name': name, 'version': item['version'], 'sha256': info['sha256']}
        if key in packages and packages[key] != entry:
            raise RuntimeError('Conflicting package hashes')
        packages[key] = entry
for path in (CACHE / '_temp', CACHE / 'hosted/pub.dev', CACHE / 'hosted-hashes/pub.dev'):
    path.mkdir(parents=True, exist_ok=True)


def fetch(pair):
    key, item = pair
    target = CACHE / 'hosted/pub.dev' / key
    marker = CACHE / 'hosted-hashes/pub.dev' / (key + '.sha256')
    url = 'https://pub.dev/api/archives/' + urllib.parse.quote(key, safe='-._+') + '.tar.gz'
    old = verified_previous.get(key)
    if old and old['sha256'] == item['sha256'] and old.get('verified') and target.is_dir() and marker.is_file() and marker.read_text().strip() == item['sha256']:
        print('Reuse verified ' + key, flush=True)
        return old
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=120) as response:
                data = response.read()
            break
        except Exception:
            if attempt == 2:
                raise
    actual = hashlib.sha256(data).hexdigest()
    if actual != item['sha256']:
        raise RuntimeError('Package hash mismatch: ' + key)
    if target.exists():
        if not marker.exists() or marker.read_text().strip() != actual:
            raise RuntimeError('Existing cache identity mismatch: ' + key)
    else:
        partial = CACHE / '_temp' / key
        if partial.exists():
            shutil.rmtree(partial)
        partial.mkdir()
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as bundle:
            bundle.extractall(partial, filter='data')
        partial.rename(target)
        marker.write_text(actual)
    print('Verified ' + key, flush=True)
    return dict(item, url=url, bytes=len(data), verified=True)


with ThreadPoolExecutor(max_workers=12) as pool:
    receipts = list(pool.map(fetch, sorted(packages.items())))
(ROOT / 'pub-cache-receipt.json').write_text(json.dumps({'locks': locks, 'archives': receipts, 'previous_receipt_sha256': previous_hash}, indent=2) + '\n')
print('Verified hosted archives: ' + str(len(receipts)), flush=True)
