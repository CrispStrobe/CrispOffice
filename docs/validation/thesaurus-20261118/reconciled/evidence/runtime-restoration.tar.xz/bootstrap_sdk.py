#!/usr/bin/env python3
"""Restore an exact official Flutter runtime without changing the repository."""
from datetime import datetime, timezone
import hashlib
import json
import shutil
import tarfile
import time
import urllib.request
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / 'releases_linux.json'
EXPECTED = 'baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2'
metadata = json.loads(MANIFEST.read_text())
release = next(x for x in metadata['releases'] if x['version'] == '3.47.8' and x['channel'] == 'stable' and x.get('dart_sdk_arch') == 'x64')
assert release['sha256'] == EXPECTED
URL = metadata['base_url'] + '/' + release['archive']
record = {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'running', 'release': release, 'manifest_url': 'https://storage.googleapis.com/flutter_infra_release/releases/releases_linux.json', 'manifest_sha256': hashlib.sha256(MANIFEST.read_bytes()).hexdigest()}


def save():
    (ROOT / 'sdk-receipt.json').write_text(json.dumps(record, indent=2) + '\n')


class DigestReader:
    def __init__(self, source):
        self.source = source
        self.hash = hashlib.sha256()
        self.total = 0

    def read(self, size=-1):
        chunk = self.source.read(size)
        self.hash.update(chunk)
        self.total += len(chunk)
        return chunk


def selected(name):
    parts = PurePosixPath(name).parts
    if not parts or parts[0] != 'flutter':
        return False
    if len(parts) == 1:
        return True
    if parts[1] in {'.git', 'bin'}:
        return True
    if parts[1] == 'packages':
        return not (len(parts) > 3 and parts[3] in {'test', 'test_private', 'test_fixes', 'example', 'examples', 'benchmark', 'benchmarks'})
    return len(parts) == 2 and parts[1] in {'LICENSE', 'AUTHORS', 'README.md', 'version', '.metadata', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', 'flutter_console.bat'}


try:
    assert not (ROOT / 'flutter').exists(), 'Use a fresh runtime directory'
    save()
    expanded = 0
    files = []
    last = time.monotonic()
    print('Downloading official Flutter 3.47.8; SDK execution remains disabled until complete archive verification.', flush=True)
    with urllib.request.urlopen(URL, timeout=120) as response:
        reader = DigestReader(response)
        with tarfile.open(fileobj=reader, mode='r|xz') as archive:
            for member in archive:
                if selected(member.name):
                    expanded += member.size
                    if expanded > 10 * 1024**3 or shutil.disk_usage(ROOT).free < 1024**3:
                        raise RuntimeError('SDK extraction exceeded budget')
                    archive.extract(member, ROOT, filter='data')
                    if member.isfile():
                        files.append({'path': member.name, 'bytes': member.size})
                if time.monotonic() - last > 20:
                    print(json.dumps({'downloaded_bytes': reader.total, 'expanded_bytes': expanded}), flush=True)
                    last = time.monotonic()
        while reader.read(8 * 1024 * 1024):
            pass
    actual = reader.hash.hexdigest()
    if actual != EXPECTED:
        raise RuntimeError('Official archive hash mismatch: ' + actual)
    record['archive'] = {'url': URL, 'sha256': actual, 'bytes': reader.total, 'verified': True, 'extracted_bytes': expanded}
    (ROOT / 'sdk-archive-members.json').write_text(json.dumps(files, indent=2) + '\n')
    record['status'] = 'verified'
    (ROOT / 'sdk-verified').touch()
except BaseException as error:
    record['status'] = 'failed'
    record['error'] = repr(error)
    raise
finally:
    record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps({'status': record['status'], 'error': record.get('error')}), flush=True)
