#!/usr/bin/env python3
"""Bind the restored SDK and cache to the current workspace without changing its lock."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'quds_office_suite'
SDK = ROOT / 'flutter'
CACHE = ROOT / 'pub-cache'
LOGS = ROOT / 'logs'
assert (ROOT / 'sdk-verified').is_file(), 'Official archive must be fully verified first'
for path in (ROOT / 'bin', ROOT / 'tmp', ROOT / 'config', ROOT / 'cache', ROOT / 'data', LOGS):
    path.mkdir(parents=True, exist_ok=True)


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


dart = SDK / 'bin/cache/dart-sdk/bin/dart'
tester = SDK / 'bin/cache/artifacts/engine/linux-x64/flutter_tester'
expected = {str(dart): '01e869e4af277734b02ab8898b870c6b00c9bec61bbcf9c923cd14de7ed85fbb', str(tester): '800f4ca182df7dd2fb46a42dea5d76277b9dbc5e8cd2915e02bcbc978681b45f'}
for path, digest in expected.items():
    assert sha(Path(path)) == digest, 'Executable differs from verified prior provenance: ' + path
settings = dict(PUB_CACHE=str(CACHE), FLUTTER_ROOT=str(SDK), CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true', DASH__SUPPRESS_ANALYTICS='true', XDG_CONFIG_HOME=str(ROOT / 'config'), XDG_CACHE_HOME=str(ROOT / 'cache'), XDG_DATA_HOME=str(ROOT / 'data'), TMPDIR=str(ROOT / 'tmp'))
env = dict(os.environ, **settings)
env['PATH'] = str(ROOT / 'bin') + ':' + env.get('PATH', '')
flutter = ROOT / 'bin/flutter'
flutter.write_text('#!/bin/sh\nexec ' + shlex.quote(str(dart)) + ' ' + shlex.quote(str(SDK / 'bin/cache/flutter_tools.snapshot')) + ' --no-version-check "$@"\n')
flutter.chmod(0o755)
dart_wrapper = ROOT / 'bin/dart'
dart_wrapper.write_text('#!/bin/sh\nexec ' + shlex.quote(str(dart)) + ' "$@"\n')
dart_wrapper.chmod(0o755)
(ROOT / 'env.sh').write_text('\n'.join('export ' + key + '=' + shlex.quote(value) for key, value in settings.items()) + '\nexport PATH=' + shlex.quote(str(ROOT / 'bin')) + ':"$PATH"\n')
record = {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'running', 'sdk_receipt_sha256': sha(ROOT / 'sdk-receipt.json'), 'executables_sha256': expected, 'runs': [], 'lock_sha256_before': sha(REPO / 'pubspec.lock')}


def save():
    (ROOT / 'runtime.json').write_text(json.dumps(record, indent=2) + '\n')


def run(name, command, cwd):
    path = LOGS / (name + '.log')
    print('START ' + name, flush=True)
    with path.open('wb') as log:
        result = subprocess.run([str(x) for x in command], cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=300)
    record['runs'].append({'name': name, 'command': [str(x) for x in command], 'cwd': str(cwd), 'exit_code': result.returncode, 'log': str(path), 'log_sha256': sha(path)})
    save()
    if result.returncode:
        raise RuntimeError(name + ': ' + path.read_text(errors='replace')[-10000:])
    print('END ' + name + ' exit=0', flush=True)
    return path


try:
    save()
    run('flutter-tools-pub-get', [dart, 'pub', 'get', '--offline', '--enforce-lockfile'], SDK / 'packages/flutter_tools')
    run('workspace-pub-get', [dart, 'pub', 'get', '--offline', '--enforce-lockfile'], REPO)
    record['lock_sha256_after'] = sha(REPO / 'pubspec.lock')
    assert record['lock_sha256_after'] == record['lock_sha256_before'], 'Workspace lock changed during enforcement'
    version = run('flutter-version', [flutter, '--version', '--machine'], REPO)
    record['runtime'] = json.loads(version.read_text())
    assert record['runtime']['frameworkRevision'] == '737ba8f885dc774b53b442759999a312c9461e4e'
    assert record['runtime']['dartSdkVersion'] == '3.13.7'
    record['workspace_package_count'] = len(json.loads((REPO / '.dart_tool/package_config.json').read_text())['packages'])
    record['sdk_tools_lock_sha256'] = sha(SDK / 'packages/flutter_tools/pubspec.lock')
    record['pub_cache_receipt_sha256'] = sha(ROOT / 'pub-cache-receipt.json')
    record['environment_script'] = str(ROOT / 'env.sh')
    record['status'] = 'ready'
except BaseException as error:
    record['status'] = 'failed'
    record['error'] = repr(error)
    raise
finally:
    record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps({'status': record['status'], 'error': record.get('error')}), flush=True)
