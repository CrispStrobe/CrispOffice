#!/usr/bin/env python3
"""Restore official SDK engine fonts required by Flutter's offline web bundler."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
URL = 'https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.47.8-stable.tar.xz'
EXPECTED = 'baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2'
PREFIX = 'flutter/engine/src/flutter/txt/third_party/fonts/'
record = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(), 'archive_url': URL, 'expected_archive_sha256': EXPECTED, 'reason': 'The offline web bundler requires SDK engine fonts omitted by the initial selective extraction.', 'files': []}


def save():
    (ROOT / 'sdk-font-repair-receipt.json').write_text(json.dumps(record, indent=2) + '\n')


class DigestReader:
    def __init__(self, stream):
        self.stream = stream
        self.hash = hashlib.sha256()
        self.total = 0

    def read(self, size=-1):
        value = self.stream.read(size)
        self.hash.update(value)
        self.total += len(value)
        return value


try:
    save()
    last = time.monotonic()
    with urllib.request.urlopen(URL, timeout=120) as stream:
        reader = DigestReader(stream)
        with tarfile.open(fileobj=reader, mode='r|xz') as archive:
            for member in archive:
                if member.name.startswith(PREFIX) and member.isfile():
                    path = ROOT / member.name
                    assert not path.exists(), 'Refusing to overwrite an existing SDK file: ' + member.name
                    archive.extract(member, ROOT, filter='data')
                    record['files'].append({'path': member.name, 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
                if time.monotonic() - last > 20:
                    print(json.dumps({'downloaded_bytes': reader.total, 'restored_fonts': len(record['files'])}), flush=True)
                    last = time.monotonic()
        while reader.read(8 * 1024 * 1024):
            pass
    record['archive_bytes'] = reader.total
    record['archive_sha256'] = reader.hash.hexdigest()
    assert record['archive_sha256'] == EXPECTED, 'Official archive checksum mismatch'
    assert (ROOT / PREFIX / 'Roboto-Regular.ttf').is_file(), 'Required Roboto font was not restored'
    record['status'] = 'verified'
except BaseException as error:
    record['status'] = 'failed'
    record['error'] = repr(error)
    raise
finally:
    record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps(record, indent=2), flush=True)
