# Fresh thesaurus native and release-fixture qualification

The final attempt on `3847d5f4237fe0069ba0a8399ddbf4dc13d7194b` passed all
**208 substantive native cases across 14 suites**, compiled the release web
fixture, and verified its prepared offline installation. Native, compiler and
installer processes all exited zero. No GitHub Actions status was used.

## Results and binding

| Item | Result |
| --- | --- |
| Native cases | 208 passed, zero failed/skipped, every started case completed once |
| Native diagnostics | No layout overflow, missed-tap, reporter parse or error diagnostics |
| Effective source inventory | 5,006 entries, including 261 locked enough_mail vendor files |
| Source stability | Exact inventory unchanged during native tests and release compilation |
| Compiled fixture | 1,155 files / 87,446,594 bytes |
| Prepared offline inventory | 1,156 files / 87,447,185 bytes |
| Installed byte validation | PASS against successful compile receipt and allowed entry-point overlay |
| Native real-pack panel | 15 queries, 109 distinct meaning records and ten source notices |
| Native render inspection | Three readable headless Flutter renders, including 390px at 1.5x text |

The prepared inventory includes the replacement index and added local installer
script; its generated inventory and worker files are outside that cached-file
count. Every original compiled byte was checked before preparation. Subsequent
validation permits exactly the documented index/bootstrap overlay and checks all
remaining compiled assets. This validates the files prepared for a browser; it
does not establish that any browser cache was installed or exercised.

`run-3/receipt.json` binds exact fixture and helper sources, resolved workspace
roots, the compiled-file inventory and original compilation logs. The live
workspace alias resolves directly to the checkout; the command alias invokes the
verified Flutter 3.47.8 / Dart 3.13.7 runtime. No repository manifests were relaxed.
`environment-aliases-final.json` records the aliases and runtime font supplement.

## Evidence

- `run-3/logs/` — original native/compile stdout and stderr.
- `run-3/native-test-audit.json` — per-case results, suite identities, complete
  lifecycle accounting and diagnostic checks.
- `run-3/source-inputs.json.gz` and `browser-build-files.json.gz` — source and
  compiled-byte inventories linked to the receipt.
- `run-3/native-pack-report.json` — observed lexical records, notices and bounded
  native timing/memory observations.
- `run-3/visuals/` and `visual-inspection-final.json` — three native fixture renders and
  the assistant's UI inspection scope; no linguistic judgments were made.
- `run-3/installation.stdout`, `installation-process.json` and
  `installed-integrity.json` — preparation output, process exit and independent
  installed-byte revalidation.
- `run-3/compiled-index.html` — original index retained before the permitted
  installer overlay.
- `run-3/offline-installation/` — extracted installer, worker and inventory files
  for evidence inspection; this extract is not the full application build.

## Preserved earlier attempts and runtime repair

`run-2/` retains the complete successful qualification for
`a6c165d397587bf0606e40ecdfcbcec565e8896c`. A later product fix made the editor
host retain a stable Flex parent while Review opens, preserving active note
editing state. Final source `3847d5f4` was therefore rerun and rebuilt as
`run-3/`. Only run-3 supplies the final counts. Its three render PNGs are
byte-identical to the already inspected run-2 images; the comparison is recorded
in `visual-inspection-final.json`.


`run-1/` remains a failed historical attempt. Its native command observed 208
passing cases, but compilation failed because the initial selective SDK restore
omitted `engine/src/flutter/txt/third_party/fonts/Roboto-Regular.ttf`. Its source
also predates the final incoming integration and locked path-dependency binding.
It contributes no additional cases to the final accepted total.

The repair restored seven official SDK font files (5,721,016 bytes). The complete
1,581,444,364-byte Flutter archive was downloaded again and matched SHA-256
`baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2`.
Existing SDK executables were unchanged. The additive repair script, raw log and
per-file hashes are retained under `runtime/`.

The successful compile retains two warnings: the broader editor references a
CupertinoIcons font absent from this fixture's manifest, and the pinned SDK marks
`--pwa-strategy` as deprecated. The actual thesaurus fixture renders use its
verified Material icon font. Neither warning is suppressed or treated as browser
acceptance.

## Open release gates

Actual browser execution was not attempted. A fresh socket preflight records
`AF_UNIX` creation failing with `PermissionError`, errno 1; no Chromium process was
launched. Browser rendering, CSP behavior, offline lifecycle and performance
remain unverified. Headless renders do not qualify an installed native Studio
application or real OS/IME interaction. The fresh query panel is automated source
fidelity evidence; independent human English/German review remains open.

The final auditor must deduplicate these native case identities against the
broader Office cohorts; the 208 are not automatically additional cases.
