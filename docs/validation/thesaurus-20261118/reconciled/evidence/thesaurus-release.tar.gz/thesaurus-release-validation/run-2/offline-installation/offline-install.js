
window.qudsOfflineInstallation = {ready: false};
(async () => {
  try {
    const workerUrl = new URL('/offline-test-worker.js', location.href).href;
    let registration = await navigator.serviceWorker.getRegistration('/');
    if (!registration || registration.active?.scriptURL !== workerUrl) {
      registration = await navigator.serviceWorker.register(workerUrl,
        {scope: '/', updateViaCache: 'none'});
    }
    await navigator.serviceWorker.ready;
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Offline worker control timed out')), 120000);
      const check = () => {
        if (navigator.serviceWorker.controller?.scriptURL === workerUrl) {
          clearTimeout(timeout);
          navigator.serviceWorker.removeEventListener('controllerchange', check);
          resolve();
        }
      };
      navigator.serviceWorker.addEventListener('controllerchange', check);
      check();
    });
    const status = await new Promise((resolve, reject) => {
      const channel = new MessageChannel();
      const timeout = setTimeout(() => reject(new Error('Offline worker receipt timed out')), 120000);
      channel.port1.onmessage = event => {
        clearTimeout(timeout);
        channel.port1.close();
        resolve(event.data);
      };
      navigator.serviceWorker.controller.postMessage({type: 'quds-offline-status'}, [channel.port2]);
    });
    if (!status.ready || !status.inventoryVerified || !status.contentVerified ||
        status.verifiedFileCount !== status.expectedFileCount) {
      throw new Error(status.error || 'Offline cache integrity verification failed');
    }
    window.qudsOfflineInstallation = {...status, ready: true, workerUrl};
  } catch (error) {
    window.qudsOfflineInstallation = {ready: false, error: String(error)};
  }
})();
