# Prepared offline fixture files

These files were generated from and verified against the successful compile receipt.
The full asset inventory is in `offline-files.json`; every asset remained byte-verified
in the local build. This directory is an evidence extract, not a complete deployable
build or evidence that a browser installed its cache.
