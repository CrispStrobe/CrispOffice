#!/usr/bin/env python3
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import hashlib,io,json,os,re,shutil,subprocess,tarfile,time,urllib.request
ROOT=Path('/workspace/scratch/50c979e0f188')
RUNTIME=ROOT/'runtime'
SOURCE=ROOT/'quds_office_suite'
RUNTIME.mkdir(exist_ok=True)
for p in ['setup','logs','tmp','config','cache','data']:(RUNTIME/p).mkdir(exist_ok=True)
ARCHIVE_URL='https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.47.8-stable.tar.xz'
EXPECTED='baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2'
START=time.monotonic()
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
with tarfile.open(SOURCE/'docs/validation/thesaurus-20261118/resume/runtime/setup.tar.gz') as t:
 records=json.load(t.extractfile('setup/prefetch-162.json'))['packages']
 (RUNTIME/'setup/prefetch-162.json').write_text(json.dumps({'packages':records},indent=2)+'\n')
 (RUNTIME/'setup/workspace-pubspec.lock').write_bytes(t.extractfile('setup/workspace-pubspec.lock').read())

def sdk():
 with urllib.request.urlopen('https://storage.googleapis.com/flutter_infra_release/releases/releases_linux.json',timeout=45) as r: releases=json.load(r)
 pinned=[r for r in releases['releases'] if r['version']=='3.47.8' and r['channel']=='stable']
 assert len(pinned)==1,pinned
 assert pinned[0]['sha256']==EXPECTED,pinned[0]
 (RUNTIME/'setup/official-release-current.json').write_text(json.dumps(pinned[0],indent=2)+'\n')
 archive=RUNTIME/'flutter_linux_3.47.8-stable.tar.xz'
 if not archive.exists():
  partial=RUNTIME/'flutter.partial'
  with urllib.request.urlopen(ARCHIVE_URL,timeout=120) as r,partial.open('wb') as out:
   shutil.copyfileobj(r,out,8*1024*1024)
  partial.rename(archive)
 actual=sha(archive)
 assert actual==EXPECTED,(actual,EXPECTED)
 print(json.dumps({'sdk_download_verified':True,'bytes':archive.stat().st_size}),flush=True)
 dest=RUNTIME/'flutter-sdk'
 if not dest.exists():
  with tarfile.open(archive,'r:xz') as t:t.extractall(RUNTIME,filter='data')
  (RUNTIME/'flutter').rename(dest)
 receipt={'url':ARCHIVE_URL,'archive_sha256':actual,'archive_bytes':archive.stat().st_size,'sdk_root':str(dest),'elapsed_seconds':time.monotonic()-START,'telemetry_consent_changed':False}
 (RUNTIME/'flutter-recovery.json').write_text(json.dumps(receipt,indent=2)+'\n')
 return receipt

def package(record):
 name,version,expected=(record[k] for k in ['name','version','sha256'])
 assert re.fullmatch(r'[A-Za-z0-9_]+',name) and re.fullmatch(r'[A-Za-z0-9.+-]+',version)
 filename=f'{name}-{version}'
 url=f'https://pub.dev/api/archives/{filename}.tar.gz'
 assert record.get('url',url)==url
 hosted=RUNTIME/'pub-cache/hosted/pub.dev'; hashes=RUNTIME/'pub-cache/hosted-hashes/pub.dev'
 hosted.mkdir(parents=True,exist_ok=True);hashes.mkdir(parents=True,exist_ok=True)
 destination=hosted/filename;digest_path=hashes/(filename+'.sha256')
 if destination.exists():
  assert digest_path.read_text().strip()==expected
  return dict(name=name,version=version,sha256=expected,status='verified-cache')
 started=time.monotonic()
 with urllib.request.urlopen(url,timeout=90) as r:data=r.read()
 actual=hashlib.sha256(data).hexdigest();assert actual==expected,(filename,actual,expected)
 temporary=hosted/('.'+filename+'.restore')
 if temporary.exists():shutil.rmtree(temporary)
 temporary.mkdir()
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:t.extractall(temporary,filter='data')
 temporary.rename(destination);digest_path.write_text(actual)
 return dict(name=name,version=version,sha256=expected,actual_sha256=actual,url=url,bytes=len(data),seconds=time.monotonic()-started,status='verified-download')

with ThreadPoolExecutor(max_workers=9) as pool:
 sdk_job=pool.submit(sdk)
 jobs=[pool.submit(package,r) for r in records]
 results=[]
 for job in as_completed(jobs):
  result=job.result();results.append(result)
  print(json.dumps(result),flush=True)
 (RUNTIME/'setup/prefetch-current.json').write_text(json.dumps({'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'packages':sorted(results,key=lambda r:(r['name'],r['version'])),'seconds':time.monotonic()-START},indent=2)+'\n')
 sdk_result=sdk_job.result()
print(json.dumps({'status':'downloaded_and_verified','packages':len(results),'sdk':sdk_result}),flush=True)
