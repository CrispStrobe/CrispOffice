#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,shutil,subprocess,yaml
parser=argparse.ArgumentParser(description="Resolve an exact, separate source-linked validation workspace.")
parser.parse_args()
ROOT=Path('/workspace/scratch/50c979e0f188')
RUNTIME=ROOT/'runtime'
SOURCE=ROOT/'quds_office_suite'
WORKSPACE=RUNTIME/'validation'
SDK=RUNTIME/'flutter-sdk'
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
members=yaml.safe_load((SOURCE/'pubspec.yaml').read_text())['workspace']
WORKSPACE.mkdir(exist_ok=True)
for member in members:(WORKSPACE/member).mkdir(parents=True,exist_ok=True)
manifests=['pubspec.yaml']+[p+'/pubspec.yaml' for p in members]
for path in manifests:shutil.copy2(SOURCE/path,WORKSPACE/path)
skip={'.git','.dart_tool','build','pubspec.yaml','pubspec.lock','pubspec_overrides.yaml'}
links={}
for member in members:
 for child in (SOURCE/member).iterdir():
  target=WORKSPACE/member/child.name
  if child.name in skip:continue
  if target.is_symlink():assert target.resolve()==child.resolve(),target
  elif not target.exists():target.symlink_to(child,target_is_directory=child.is_dir())
  links[str(target.relative_to(WORKSPACE))]=str(child)
for name in ['analysis_options.yaml','third_party']:
 source=SOURCE/name;target=WORKSPACE/name
 if source.exists() and not target.exists():target.symlink_to(source,target_is_directory=source.is_dir())
lock=SOURCE/'pubspec.lock'
if not lock.exists():lock=RUNTIME/'setup/workspace-pubspec.lock'
shutil.copy2(lock,WORKSPACE/'pubspec.lock')
env=dict(os.environ,FLUTTER_ROOT=str(SDK),PUB_CACHE=str(RUNTIME/'pub-cache'),TMPDIR=str(RUNTIME/'tmp'),XDG_CONFIG_HOME=str(RUNTIME/'config'),XDG_CACHE_HOME=str(RUNTIME/'cache'),XDG_DATA_HOME=str(RUNTIME/'data'),CI='true',DART_SUPPRESS_ANALYTICS='true',DASH__SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true')
env['PATH']=str(SDK/'bin')+':'+env['PATH']
(RUNTIME/'env.sh').write_text('\n'.join('export '+k+'='+str(env[k]) for k in ['FLUTTER_ROOT','PUB_CACHE','TMPDIR','XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','CI','DART_SUPPRESS_ANALYTICS','DASH__SUPPRESS_ANALYTICS','FLUTTER_SUPPRESS_ANALYTICS'])+'\nexport PATH='+str(SDK/'bin')+':"$PATH"\n')
dart=SDK/'bin/cache/dart-sdk/bin/dart'
commands=[]
def run(cmd,cwd,name):
 with (RUNTIME/'logs'/name).open('wb') as out:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=300)
 commands.append(dict(command=cmd,cwd=str(cwd),exit_code=p.returncode,log=name))
 if p.returncode:raise RuntimeError('Failed '+name+'; see '+str(RUNTIME/'logs'/name))
locks=[WORKSPACE/'pubspec.lock',SDK/'packages/flutter_tools/pubspec.lock'];before={str(p):sha(p) for p in locks}
run([str(dart),'pub','get','--offline','--enforce-lockfile'],WORKSPACE,'workspace-pub-get.log')
run([str(dart),'pub','get','--offline','--enforce-lockfile'],SDK/'packages/flutter_tools','flutter-tools-pub-get.log')
assert before=={str(p):sha(p) for p in locks}
link=SOURCE/'.dart_tool'
if link.is_symlink():assert link.resolve()==WORKSPACE/'.dart_tool'
elif link.exists():raise RuntimeError('Source package config already exists')
else:link.symlink_to(WORKSPACE/'.dart_tool',target_is_directory=True)
run([str(SDK/'bin/flutter'),'--version','--machine'],WORKSPACE,'flutter-version.json')
run([str(dart),'--version'],WORKSPACE,'dart-version.log')
tracked=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=SDK,text=True);assert not tracked,tracked
config=json.loads((WORKSPACE/'.dart_tool/package_config.json').read_text())
receipt=dict(status='ready',recorded_at_utc=datetime.now(timezone.utc).isoformat(),source_head_at_setup=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),source=str(SOURCE),workspace=str(WORKSPACE),sdk=str(SDK),environment_script=str(RUNTIME/'env.sh'),runtime=json.loads((RUNTIME/'logs/flutter-version.json').read_text()),archive=json.loads((RUNTIME/'flutter-recovery.json').read_text()),executable_sha256={k:sha(v) for k,v in {'dart':dart,'flutter_tester':SDK/'bin/cache/artifacts/engine/linux-x64/flutter_tester'}.items()},framework_tracked_changes=[],workspace_package_count=len(config['packages']),workspace_lock_sha256=sha(locks[0]),flutter_tools_lock_sha256=sha(locks[1]),workspace_manifest_sha256={p:sha(SOURCE/p) for p in manifests},workspace_manifest_matches={p:sha(SOURCE/p)==sha(WORKSPACE/p) for p in manifests},commands=commands,product_tests_run=0,no_ci_actions_used=True)
(RUNTIME/'runtime-ready.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['status','source_head_at_setup','workspace_package_count','runtime','executable_sha256']},indent=2))
