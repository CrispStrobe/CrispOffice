#!/usr/bin/env python3
"""Run source-bound incoming integration cohorts without dependency resolution."""
from pathlib import Path
from datetime import datetime,timezone
from urllib.parse import unquote,urljoin,urlparse
import gzip,hashlib,importlib.util,json,os,subprocess,time
ROOT=Path('/workspace/scratch/50c979e0f188')
REPO=ROOT/'quds_office_suite'
RUNTIME=ROOT/'runtime'
WORKSPACE=RUNTIME/'validation'
OUT=ROOT/'integration-validation'
SDK=RUNTIME/'flutter-sdk'
FLUTTER=str(SDK/'bin/flutter');DART=str(SDK/'bin/cache/dart-sdk/bin/dart')
CONFIG=WORKSPACE/'.dart_tool/package_config.json'
AUDIT=REPO/'docs/validation/zotero-citation-workflow-20261118/editor/run_editor_zotero.py'
TARGETS=[
 'packages/quds_mail_ui/test/support/runtime_network_guard_web.dart',
 'packages/quds_office_editor/example/lib/studio_chrome.dart',
 'packages/quds_office_editor/example/lib/suite_workspace.dart',
 'packages/quds_office_editor/example/test/studio_comment_draft_proofing_test.dart',
 'packages/quds_mail_ui/lib/src/reader/message_view.dart',
]
COHORTS=[
 ('studio','quds_office_editor/example','flutter',[
  'test/studio_comment_draft_proofing_test.dart','test/studio_compact_navigation_test.dart',
  'test/studio_comment_keyboard_review_test.dart','test/studio_zotero_shortcuts_test.dart']),
 ('mail-ui','quds_mail_ui','flutter',None),
 ('mail-core','quds_mail_core','dart',None),
 ('mail-mime','quds_mail_mime','dart',None),
 ('engine','quds_office_engine','dart',['test/office_thesaurus_test.dart','test/word_zotero_note_insertion_test.dart']),
]
def utc():return datetime.now(timezone.utc).isoformat()
def sha(path):return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO,text=True).strip()
def record(path):return {'bytes':path.stat().st_size,'sha256':sha(path)}
def write_json(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
TRACKED=git('ls-files','-z').split('\0')
SELECTED={'.fvmrc','pubspec.yaml','pubspec.lock','analysis_options.yaml'}
for name in TRACKED:
 p=Path(name); parts=p.parts
 if parts and parts[0] in ('packages','apps','third_party') and (p.suffix in ('.dart','.yaml','.json','.gz','.png','.ttf','.otf','.bin','.js','.html','.css','.wasm') or p.name in ('CMakeLists.txt',)):
  if not any(x in ('doc','docs','verification','notices') for x in parts[2:]): SELECTED.add(name)
def snapshot():
 files={name:record(REPO/name) for name in sorted(SELECTED)}
 files.update({'__workspace_lock__':record(WORKSPACE/'pubspec.lock'),'__package_config__':record(CONFIG),'__runtime_ready__':record(RUNTIME/'runtime-ready.json'),'__dart__':record(Path(DART)),'__flutter_tester__':record(SDK/'bin/cache/artifacts/engine/linux-x64/flutter_tester'),'__audit_source__':record(AUDIT),'__runner__':record(Path(__file__))})
 return files
def save_snapshot(name,data):
 with gzip.open(OUT/name,'wt') as f:json.dump(data,f,indent=2,sort_keys=True)
 return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':')).encode()).hexdigest()
ENV=dict(os.environ,FLUTTER_ROOT=str(SDK),PUB_CACHE=str(RUNTIME/'pub-cache'),TMPDIR=str(RUNTIME/'tmp'),XDG_CONFIG_HOME=str(RUNTIME/'config'),XDG_CACHE_HOME=str(RUNTIME/'cache'),XDG_DATA_HOME=str(RUNTIME/'data'),CI='true',DART_SUPPRESS_ANALYTICS='true',DASH__SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true')
ENV['PATH']=str(SDK/'bin')+':'+ENV['PATH']
packages=json.loads(CONFIG.read_text())['packages'];test_pkg=next(x for x in packages if x['name']=='test')
test_uri=urlparse(urljoin(CONFIG.as_uri(),test_pkg['rootUri']));assert test_uri.scheme=='file'
TEST_RUNNER=Path(unquote(test_uri.path))/'bin/test.dart'
spec=importlib.util.spec_from_file_location('event_audit',AUDIT);audit_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit_module)
summary={'status':'running','started_at_utc':utc(),'source_sha':git('rev-parse','HEAD'),'github_actions_used':False,'browser_executed':False,'runs':[],'analysis_targets':TARGETS}
if (OUT/'summary.json').exists():raise RuntimeError('Refusing to overwrite existing summary')
BEFORE=snapshot();summary['input_digest']=save_snapshot('source-before.json.gz',BEFORE);summary['source_files']=len(BEFORE)
def flush():write_json(OUT/'summary.json',summary)
def command(name,cmd,cwd):
 directory=OUT/name;directory.mkdir()
 stdout=directory/'stdout.jsonl';stderr=directory/'stderr.log'
 start=time.monotonic();print('START '+name,flush=True)
 with stdout.open('wb') as out,stderr.open('wb') as err:p=subprocess.run(cmd,cwd=cwd,env=ENV,stdout=out,stderr=err,timeout=900)
 item={'name':name,'command':cmd,'cwd':str(cwd),'exit_code':p.returncode,'seconds':time.monotonic()-start,'stdout':str(stdout.relative_to(OUT)),'stderr':str(stderr.relative_to(OUT)),'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr)}
 summary['runs'].append(item);flush();print('END '+name+' '+json.dumps({'exit_code':p.returncode,'seconds':item['seconds']}),flush=True)
 return item,stdout
try:
 flush()
 item,stdout=command('analysis',[FLUTTER,'analyze','--no-pub','--fatal-infos',*TARGETS],REPO)
 if item['exit_code']!=0:raise RuntimeError('Strict analysis failed; inspect analysis logs')
 for name,package,kind,selected in COHORTS:
  cwd=WORKSPACE/'packages'/package
  selected=selected or [str(p.relative_to(cwd)) for p in sorted((cwd/'test').rglob('*_test.dart'))]
  assert selected and len(set(selected))==len(selected)
  for p in selected:assert (cwd/p).is_file(),p
  cmd=[FLUTTER,'test','--no-pub'] if kind=='flutter' else [DART,'--disable-dart-dev','--packages='+str(CONFIG),str(TEST_RUNNER)]
  item,stdout=command(name,[*cmd,'--concurrency=1','--reporter','json',*selected],cwd)
  audit=audit_module.audit_events(stdout);write_json(OUT/name/'test-audit.json',audit)
  expected={str((cwd/p).resolve()) for p in selected};actual={str((cwd/s['path']).resolve()) for s in audit['suites']}
  guards={'exit_success':item['exit_code']==0,'all_selected_suites_executed':actual==expected and len(audit['suites'])==len(selected),'nonempty_cases':audit['passed']>0,'no_failed_or_skipped_cases':audit['failed']==0 and audit['skipped']==0,'every_started_test_finished_once':audit['every_started_test_finished_once'],'final_event_success':len(audit['final_events'])==1 and audit['final_events'][0].get('success') is True,'clean_event_stream':not any(audit[k] for k in ('error_events','parse_errors','excluded_failures','layout_or_tap_diagnostics'))}
  item.update(test_audit={k:audit[k] for k in ('passed','failed','skipped','suite_count')},guards=guards,selected_tests=selected)
  after=snapshot();item['source_unchanged']=after==BEFORE
  item['changed_inputs']=[p for p in BEFORE.keys()|after.keys() if BEFORE.get(p)!=after.get(p)]
  write_json(OUT/name/'receipt.json',item);flush()
  if not all(guards.values()) or not item['source_unchanged']:raise RuntimeError('Cohort failed: '+name)
 summary['status']='passed'
except BaseException as e:
 summary['status']='failed';summary['error']=repr(e)
finally:
 AFTER=snapshot();summary['output_digest']=save_snapshot('source-after.json.gz',AFTER);summary['source_unchanged']=AFTER==BEFORE
 summary['changed_inputs']=[p for p in BEFORE.keys()|AFTER.keys() if BEFORE.get(p)!=AFTER.get(p)]
 if not summary['source_unchanged']:summary['status']='failed'
 summary['source_sha_after']=git('rev-parse','HEAD');summary['finished_at_utc']=utc();summary['passed_cases']=sum(x.get('test_audit',{}).get('passed',0) for x in summary['runs']);flush()
 print(json.dumps({k:summary[k] for k in ['status','passed_cases','source_unchanged']}),flush=True)
if summary['status']!='passed':raise SystemExit(1)
