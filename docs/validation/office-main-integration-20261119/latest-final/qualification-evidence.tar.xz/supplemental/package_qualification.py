#!/usr/bin/env python3
"""Save exact qualification evidence, excluding reproducible generated JS."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile

p = argparse.ArgumentParser()
p.add_argument('--source', required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--input', action='append', required=True, help='archive-name=directory')
a = p.parse_args()
a.output.parent.mkdir(parents=True, exist_ok=True)
members = []
excluded = []
with tarfile.open(a.output, 'w:xz', preset=6) as archive:
    for item in a.input:
        name, directory = item.split('=', 1)
        root = Path(directory)
        for path in sorted(root.rglob('*')):
            if not path.is_file():
                continue
            relative = path.relative_to(root)
            if path.is_symlink():
                raise RuntimeError('Unexpected evidence symlink: ' + str(path))
            data = path.read_bytes()
            record = {'path': name + '/' + relative.as_posix(), 'bytes': len(data),
                      'sha256': hashlib.sha256(data).hexdigest()}
            if path.name.endswith(('.js', '.js.map', '.js.deps')) or '.tmp' in relative.parts:
                excluded.append(record)
                continue
            info = tarfile.TarInfo(record['path'])
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
            members.append(record)
data = a.output.read_bytes()
index = {'source_commit': a.source, 'archive_sha256': hashlib.sha256(data).hexdigest(),
         'archive_bytes': len(data), 'members': members,
         'generated_outputs_preserved_as_hashes_only': excluded}
index_path = a.output.with_suffix('').with_suffix('.index.json')
index_path.write_text(json.dumps(index, indent=2) + '\n')
with tarfile.open(a.output, 'r:xz') as archive:
    assert archive.getnames() == [item['path'] for item in members]
    for item in members:
        actual = archive.extractfile(item['path']).read()
        assert len(actual) == item['bytes'] and hashlib.sha256(actual).hexdigest() == item['sha256']
print(json.dumps({'archive': str(a.output), 'bytes': len(data), 'members': len(members),
                  'sha256': index['archive_sha256'], 'generated_outputs': len(excluded)}))
