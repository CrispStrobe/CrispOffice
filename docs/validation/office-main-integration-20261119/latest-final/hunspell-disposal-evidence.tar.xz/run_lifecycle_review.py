#!/usr/bin/env python3
"""Replay one before/after native lifecycle suite without resolving packages."""
import argparse
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--variant', choices=('incoming', 'after'), required=True)
parser.add_argument('--backend', choices=('fixture', 'real'), required=True)
parser.add_argument('--label', required=True)
args = parser.parse_args()
if '/' in args.label or '\\' in args.label:
    raise SystemExit('The label must be a file basename.')
if (ROOT / (args.label + '-receipt.json')).exists():
    raise SystemExit('Choose a fresh label to preserve the existing receipt.')
spec = importlib.util.spec_from_file_location('review', ROOT / 'run_local_review.py')
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)
review.PACKAGE = ROOT / args.variant / 'packages/quds_proofing_hunspell'
review.CONFIG = review.PACKAGE / '.dart_tool/package_config.json'
library = ROOT / 'native-build' / ('libquds_hunspell_lifecycle_' + args.backend + '.so')
review.ENVIRONMENT['QUDS_HUNSPELL_LIFECYCLE_LIBRARY'] = str(library)
review.run(args.label, [review.DART, '--disable-dart-dev',
                       '--packages=' + str(review.CONFIG), review.TEST,
                       '--compiler=kernel', '--reporter=json', '--concurrency=1',
                       'test/hunspell_native_lifecycle_test.dart'],
           review.PACKAGE,
           [library, review.PACKAGE / 'test/hunspell_native_lifecycle_test.dart',
            review.PACKAGE / 'test/support/lifecycle_library.cpp'])
