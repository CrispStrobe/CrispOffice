#!/usr/bin/env python3
"""Rebuild retained native review artifacts from committed bundled sources.

No network access, package resolution, or tracked checkout changes. Run only
after any qualification using these output libraries has finished. Commands
retain this workspace's absolute paths; rebase them explicitly after moving
the evidence and preserve the original receipts.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'incoming/packages/quds_proofing_hunspell'
manifest = json.loads((PACKAGE / 'licenses/manifest.json').read_text())
archive = PACKAGE / 'licenses' / manifest['source_bundle']['file']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest['source_bundle']['sha256']
source = ROOT / 'native-source'
source.mkdir(exist_ok=True)
with tarfile.open(archive) as stream:
    members = stream.getmembers()
    assert all(item.isfile() and not item.name.startswith('/')
               and '..' not in Path(item.name).parts for item in members)
    stream.extractall(source, members=members, filter='data')
source /= 'hunspell-1.7.2'
for name, digest in manifest['component']['compiled_files'].items():
    assert hashlib.sha256((source / 'src/hunspell' / name).read_bytes()).hexdigest() == digest
for name, digest in manifest['notices'].items():
    assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest
for name in (
    'native-build/build-command.json',
    'instrumented-build-command.json',
    'lifecycle-fixture-build-command.json',
    'lifecycle-instrumented-build-command.json',
):
    recipe = json.loads((ROOT / name).read_text())
    subprocess.run(recipe['command'], cwd=ROOT, check=True)
    output = Path(recipe['command'][-1])
    print(json.dumps({'output': str(output), 'bytes': output.stat().st_size,
                      'sha256': hashlib.sha256(output.read_bytes()).hexdigest()}))
