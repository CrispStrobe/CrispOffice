import 'dart:convert';
import 'dart:ffi';
import 'dart:io';

import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_proofing_hunspell/quds_proofing_hunspell.dart';

Future<void> main(List<String> arguments) async {
  final library = arguments[0];
  final directory = arguments[1];
  final counting = arguments.length > 2 && arguments[2] == 'count';
  final live = counting
      ? DynamicLibrary.open(library)
          .lookupFunction<Size Function(), int Function()>(
            'quds_hunspell_debug_live_handles',
          )
      : null;
  final observed = <Map<String, Object?>>[];
  var failed = false;
  for (var iteration = 0; iteration < 2; iteration++) {
    final provider = HunspellProofingProvider(
      bundle: ayaspellArabic,
      dictionary: HunspellDictionaryFiles(
        affPath: '$directory/ar.aff',
        dicPath: '$directory/ar.dic',
      ),
      nativeLibraryPath: library,
    );
    final result = await provider.check(
      OfficeProofingRequest(
        documentId: 'fixture',
        blockId: 'one',
        revision: iteration,
        text: 'كتب كتت',
        language: 'ar',
        startOffset: 12,
      ),
    );
    final liveBeforeDispose = live?.call();
    final valid = result.status == OfficeProofingStatus.success &&
        result.findings.length == 1 &&
        result.findings.single.originalText == 'كتت' &&
        result.findings.single.start == 16 &&
        result.findings.single.end == 19 &&
        result.findings.single.replacements.contains('كتب');
    await provider.dispose();
    // Observe after the worker has had time to process its termination.
    await Future<void>.delayed(const Duration(milliseconds: 100));
    final liveAfterDispose = live?.call();
    observed.add({
      'iteration': iteration,
      'status': result.status.name,
      'findings': [
        for (final finding in result.findings)
          {
            'word': finding.originalText,
            'start': finding.start,
            'end': finding.end,
            'replacements': finding.replacements,
          },
      ],
      'native_fixture_valid': valid,
      if (counting) 'live_before_dispose': liveBeforeDispose,
      if (counting) 'live_after_dispose': liveAfterDispose,
    });
    failed |= !valid || (counting && liveAfterDispose != 0);
  }
  stdout.writeln(jsonEncode({
    'library': library,
    'fixture_is_ayaspell': false,
    'iterations': observed,
    'passed': !failed,
  }));
  if (failed) exitCode = 1;
}
