# Hunspell review and native disposal regression evidence

Reviewed incoming commit `b655b8a37fddc874bd42a453c371eed6253e82d8` from immutable Git objects. The new package is a workspace member; no editor registration, download UI, or app-target library/worker packaging is added by that change.

## Concrete repair

The incoming native transport killed its isolate on disposal but never closed the isolate's final native dictionary handle. A counter-only instrumented build of the actual adapter retained one handle after the first provider disposal and two after the second. The normal library independently passed a small Arabic spelling/suggestion/UTF-16-offset probe.

`native-disposal.patch` changes only the Dart native transport and adds a six-case lifecycle regression suite with a small native counter fixture. Normal disposal now sends a serialized close command and waits for its acknowledgement. Pending callers settle immediately; waiting for close is bounded to one second. Each handle has a NativeFinalizer owner, detached when closed explicitly. Forced fallback termination uses `Isolate.beforeNextEvent`: the current event can complete native allocation and register ownership before exit. The pinned SDK documents this scheduling behavior in `lib/isolate/isolate.dart` and native ownership semantics in `lib/ffi/native_finalizer.dart`.

These are asynchronous native calls: the change does not claim to interrupt arbitrary C++ execution. It bounds caller settlement and retains ownership until the current native operation can finish. Forced-exit release was observed on this Linux runtime; other installed platforms remain separate acceptance work.

## Observed validation

| Check | Passed | Failed | Skipped |
| --- | ---: | ---: | ---: |
| Existing provider scenarios, VM | 10 | 0 | 0 |
| Same provider scenarios, Node | 10 | 0 | 0 |
| Existing missing-native-library case | 1 | 0 | 0 |
| Incoming transport + new lifecycle tests + actual instrumented adapter | 1 | 5 | 0 |
| Patched transport + identical tests + actual instrumented adapter | 6 | 0 | 0 |
| Patched transport + identical tests + small counter ABI fixture | 6 | 0 | 0 |

The six lifecycle scenarios cover normal/repeated disposal, replacement of an already-open dictionary, cancellation during isolate startup, forced exit during a stalled check, forced exit while native open returns, and provider timeout. The RED/GREEN tests have identical bytes. `test-count-review.json` reconstructs exact starts, completions, names, results and terminal events from raw JSON. Each accepted receipt confirms its bound package/source/configuration/launcher inputs remained unchanged. Repeated VM/Node or real/fixture executions are not additional distinct scenarios.

Strict analysis with fatal infos/warnings and formatting pass for all 15 patched-package Dart paths. The committed web entrypoint compiled to JavaScript; this is compile-only evidence. The real Linux native bridge probe uses a clearly labeled three-word synthetic dictionary, not AyaSpell.

## Native build provenance

The committed source archive was checked against `licenses/manifest.json`, then every one of its 28 library source/header records and five notice records was hash verified. GCC 14.2 compiled the exact committed production adapter and library sources with the native CMake target's C++14/Release/PIC/hidden-visibility/static-Hunspell settings. CMake is unavailable here, so this is a direct equivalent compiler invocation, not a claim that `tool/build.py --native` ran. No source download occurred.

The production shared library is 887,136 bytes, SHA-256 `345e2fab9961e2309d984e527690e3034f3e5095551b3e33fbd01faf2c7ad739`. Build commands, logs, source pins and generated-output hashes are retained. Compiled libraries and generated JavaScript are local replayable outputs and are not included in the compact archive.

The actual-adapter lifecycle library adds only atomic counters and bounded delays around successful open, close and spelling calls. Its source and exact command are retained in `lifecycle_instrumented_adapter.cpp` and `lifecycle-instrumented-build-command.json`. The separate small counter-only fixture exercises the C ABI ownership contract without a downloaded dictionary; it is not linguistic acceptance.

## Replay

After any other qualification using these libraries finishes, run from this evidence directory:

```sh
python3 replay_build.py
python3 run_lifecycle_review.py --variant incoming --backend real --label replay-real-red
python3 run_lifecycle_review.py --variant after --backend real --label replay-real-green
python3 run_lifecycle_review.py --variant after --backend fixture --label replay-fixture-green
```

The replay preserves the original receipts by requiring fresh labels. Expected suite exits are 1 for RED and 0 for GREEN; the outer Python runner always writes the full child exit and hash receipt. `run_local_review.py` retains the original provider/missing-library/initial-native commands. Exact JS compilation and static-check commands are in their receipts. All commands use the restored Dart 3.13.7 SDK and cached dependencies. No Pub resolution, network access, GitHub Actions, publication or tracked checkout change is required.

The recipes retain original absolute workspace paths. After relocating the archive, rebase those paths and the two effective package configurations explicitly, retain the originals, and record fresh derived hashes. The original bundled Hunspell sources remain unchanged.

## Acceptance boundaries

The six existing real AyaSpell/installer cases were not run because the pinned dictionary is absent. The separately gated live download was not attempted. Emscripten/Wasm build, actual browser Worker/CSP/offline behavior, installed host UI and packaging, other OS/device runs, and linguistic review remain unverified by this packet. The parent's new frozen-checkout qualification is a separate result; these isolated review receipts do not replace it.
