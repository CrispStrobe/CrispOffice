#!/usr/bin/env python3
"""Run isolated checks; never resolves dependencies or uses the network."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'incoming/packages/quds_proofing_hunspell'
RUNTIME = ROOT.parent / 'toolchains'
DART = RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'
CONFIG = PACKAGE / '.dart_tool/package_config.json'
TEST = RUNTIME / 'pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
ENVIRONMENT = {
    'TMPDIR': str(ROOT / 'tmp'),
    'PUB_CACHE': str(RUNTIME / 'pub-cache'),
    'DART_SUPPRESS_ANALYTICS': 'true',
    'FLUTTER_SUPPRESS_ANALYTICS': 'true',
}
Path(ENVIRONMENT['TMPDIR']).mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(name, command, cwd, additional_inputs=()):
    paths = [DART, TEST, CONFIG, ROOT / 'native_probe.dart', *additional_inputs]
    paths.extend(PACKAGE / f['path'].split('packages/quds_proofing_hunspell/', 1)[1]
                 for f in json.loads((ROOT / 'source-manifest.json').read_text())['files'])
    before = {str(path): sha(path) for path in paths}
    receipt = {
        'name': name,
        'command': list(map(str, command)),
        'cwd': str(cwd),
        'environment_overrides': ENVIRONMENT,
        'before': before,
        'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    log = ROOT / (name + '.log')
    with log.open('wb') as output:
        result = subprocess.run(receipt['command'], cwd=cwd,
                                env=dict(os.environ, **ENVIRONMENT),
                                stdout=output, stderr=subprocess.STDOUT,
                                timeout=120)
    after = {str(path): sha(path) for path in paths}
    receipt.update(exit_code=result.returncode, after=after,
                   inputs_unchanged=before == after, log_sha256=sha(log),
                   finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (ROOT / (name + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'name': name, 'exit_code': result.returncode,
                      'inputs_unchanged': before == after}), flush=True)


if __name__ == '__main__':
    prefix = [DART, '--disable-dart-dev', '--packages=' + str(CONFIG)]
    for name, target, extra in (
        ('provider-tests', 'test/hunspell_provider_test.dart', []),
        ('missing-library-test', 'test/hunspell_native_test.dart',
         ['--plain-name', 'missing native library is unavailable without isolate errors']),
    ):
        run(name, [*prefix, TEST, '--compiler=kernel', '--reporter=json',
                   '--concurrency=1', target, *extra], PACKAGE)
    for name, library, extra in (
        ('real-linux-fixture', 'libquds_proofing_hunspell.so', []),
        ('disposal-counter-red', 'libquds_hunspell_instrumented.so', ['count']),
    ):
        library_path = ROOT / 'native-build' / library
        run(name, [*prefix, ROOT / 'native_probe.dart', library_path,
                   ROOT / 'fixture', *extra], ROOT,
            [library_path, ROOT / 'fixture/ar.aff', ROOT / 'fixture/ar.dic'])
