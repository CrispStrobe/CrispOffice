# Arabic semantic-mark regression evidence

Source: `f7117a493055008a72e6e16713dd67a4f7c2ad39`. The original provider erased combining madda and hamza from lexical lookup, then kept those marks beside a newly precomposed hamza in replacement suggestions. The exact probe logs include input/replacement code units.

`semantic-marks.patch` changes only the lexical ignored-mark set and adds five focused regression cases. U+0653-U+0655 remain part of word identity; optional vowel marks and tatweel still participate in the existing loose matching. The source text and its UTF-16 offsets are never normalized. Closed lexical rules conservatively leave these decomposed forms alone. Punctuation still recognizes all original marks. No dependencies or word lists change.

Both variants use identical augmented tests. Before: 74 started/completed, 70 passed, 4 failed. After: 74 passed, 0 failed, 0 skipped. All original 69 cases pass in both variants; four new cases expose the defect and the additional punctuation case preserves existing behavior. The standalone probe separately exits 1 before and 0 after. Source/launcher/configuration bindings remain unchanged during each run.

The before/after directories contain exact isolated proofing sources, tests, pubspec and effective package configurations. Receipt commands retain the original paths and pinned Dart/package:test entrypoints. When replaying in another directory, rebase the engine rootUri and scratch paths explicitly and record fresh hashes. No hosted dependency or application source is substituted.

The initial test-runner environment attempt failed before executing cases because the default /tmp directory was absent. Its logs remain under environment-attempt-*; the accepted red/green runs set TMPDIR to this task's scratch directory. Editor/application integration and the full final gate belong to their separate root receipts.

## Replay in this workspace

The following replay uses each recorded command, working directory and environment, checks its recorded input hashes before execution, and keeps the original logs intact. Run it from this evidence directory after the separate final qualification finishes. The expected failing RED runs are deliberate; their exit code is checked against the recorded result.

```bash
python3 - <<'PY_REPLAY'
import hashlib, json, os, pathlib, subprocess
for name in ('before-probe', 'after-probe', 'before-tests', 'after-tests'):
    receipt = json.loads(pathlib.Path(name + '-receipt.json').read_text())
    for path, digest in receipt['before'].items():
        assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest() == digest, path
    environment = dict(os.environ, **receipt['environment_overrides'])
    pathlib.Path(environment['TMPDIR']).mkdir(parents=True, exist_ok=True)
    with pathlib.Path('replay-' + name + '.log').open('wb') as output:
        result = subprocess.run(receipt['command'], cwd=receipt['cwd'], env=environment,
                                stdout=output, stderr=subprocess.STDOUT, timeout=120)
    assert result.returncode == receipt['exit_code'], (name, result.returncode)
    for path, digest in receipt['after'].items():
        assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest() == digest, path
    print(name, 'expected exit', result.returncode)
PY_REPLAY
```

For replay after relocating the archive or restoring the SDK elsewhere, first rebase the explicit receipt paths and the isolated engine `rootUri` in each effective package configuration; retain the originals and record the newly derived hashes. This is a local kernel test replay and does not require GitHub Actions or network access.
