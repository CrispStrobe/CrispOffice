import 'dart:convert';
import 'dart:io';
import 'package:quds_office_engine/src/proofing/arabic_writing_rules.dart';
import 'package:quds_office_engine/src/proofing/office_proofing.dart';
Future<void> main() async {
  final provider = ArabicWritingRulesProvider();
  var failed = false;
  for (final text in ['ا\u0653نا', 'ا\u0654ن', 'ا\u0655لى']) {
    final result = await provider.check(OfficeProofingRequest(documentId:'probe', blockId:'p', revision:0, text:text, language:'ar'));
    print(jsonEncode({'input':text,'code_units':text.codeUnits,'findings':[for(final f in result.findings) {'rule':f.ruleId,'original':f.originalText,'start':f.start,'end':f.end,'replacements':f.replacements,'replacement_code_units':[for(final s in f.replacements)s.codeUnits]}]}));
    failed = failed || result.findings.isNotEmpty;
  }
  await provider.dispose();
  exitCode = failed ? 1 : 0;
}
