import os,sys,subprocess,json,hashlib,pathlib,time
base=pathlib.Path(__file__).resolve().parent
runtime=base.parent/'runtime-recovery/toolchains'
prefix=pathlib.Path('packages/quds_office_editor/example')
stage=sys.argv[1]
cwd=base/('before' if stage=='red' else 'after')/prefix
env=dict(os.environ)
env.update(PUB_CACHE=str(runtime/'pub-cache'),FLUTTER_ROOT=str(runtime/'flutter'),CI='true',DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true',DASH__SUPPRESS_ANALYTICS='true',XDG_CONFIG_HOME=str(base/'config'),XDG_CACHE_HOME=str(base/'cache'),XDG_DATA_HOME=str(base/'data'),TMPDIR=str(base/'tmp'),PATH=str(runtime/'bin')+os.pathsep+env.get('PATH',''))
paths=['lib/studio_mail.dart','lib/studio_strings.dart','test/studio_mail_test.dart','pubspec.yaml','analysis_options.yaml','.dart_tool/package_config.json','.dart_tool/package_graph.json']
def snapshot():return {x:hashlib.sha256((cwd/x).read_bytes()).hexdigest()for x in paths}
if stage=='format':cmd=[str(runtime/'bin/dart'),'format','--output=none','--set-exit-if-changed',*paths[:3]]
elif stage=='analysis':cmd=[str(runtime/'bin/dart'),'analyze','--fatal-infos','--fatal-warnings',*paths[:3]]
else:cmd=[str(runtime/'bin/flutter'),'test','--no-pub','--concurrency=1','--reporter=json','test/studio_mail_test.dart']
before=snapshot();start=time.time();p=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);elapsed=time.time()-start
log=base/(stage+'.log');log.write_bytes(p.stdout)
after=snapshot();events=[];nonjson=[]
for line in p.stdout.decode(errors='replace').splitlines():
 try:
  obj=json.loads(line)
  if isinstance(obj,dict) and 'type'in obj:events.append(obj)
  else:nonjson.append(line)
 except json.JSONDecodeError:nonjson.append(line)
starts={e['test']['id']:e['test'] for e in events if e['type']=='testStart'}
completions=[e for e in events if e['type']=='testDone'and not e.get('hidden')and not starts.get(e['testID'],{}).get('name','').startswith('loading ')]
rows=[{'name':starts[e['testID']]['name'],'result':e['result'],'skipped':e['skipped']}for e in completions]
receipt={'stage':stage,'scope':'Isolated focused regression preparation, not final integrated qualification. Existing pinned runtime and Mail dependency sources reused; shared checkout/runtime inputs not modified.','command':cmd,'cwd':str(cwd),'exit_code':p.returncode,'elapsed_seconds':elapsed,'source_before':before,'source_after':after,'source_unchanged':before==after,'log':str(log),'log_sha256':hashlib.sha256(p.stdout).hexdigest(),'cases':rows,'case_counts':{k:sum(e['result']==k for e in rows)for k in ['success','failure','error']},'terminal':[e for e in events if e['type']=='done'],'non_json_lines':nonjson,'errors':[e for e in events if e['type']=='error']}
(base/(stage+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k]for k in ['stage','exit_code','elapsed_seconds','source_unchanged','case_counts','terminal','non_json_lines','errors']},indent=2))
sys.exit(p.returncode)
