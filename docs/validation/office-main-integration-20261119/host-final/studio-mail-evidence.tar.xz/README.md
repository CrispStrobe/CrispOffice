# Studio Mail async ownership review

This narrow patch is based on incoming source `be641457c8c7d1acc25091b31c87c73eaa3c9c2a`. It changes only Studio Mail, one localized error string in StudioStrings, and a new nine-case widget suite. Shared Mail/core/store/MIME/TLS implementations remain unchanged.

## Defect and correction

The incoming dialog awaited the file picker and optional file read, then used setState without verifying that its route still existed. It also allowed picker/read exceptions to escape. The patch checks mounted after selection and after the fallback read; a dismissed dialog performs no subsequent read or controller replacement. Failures while open preserve the current message and show an English/German/Arabic error message. Failures after dismissal are ignored. Existing controller replacement and deferred disposal behavior is retained.

## Focused evidence

The same nine named cases ran against the exact incoming dialog and the repaired dialog in isolated packages using existing pinned dependencies and `flutter test --no-pub`. The baseline completed with three passing and six failing cases. The repaired source completed with all nine passing, no skips and no errors. Final strict analysis with fatal infos/warnings and formatting with no changes also passed for all three selected paths. Every final receipt contains source hashes before/after and its raw-log hash.

The controls cover selected bytes and retained compact mode; delayed path fallback; cancellation; dismissal before picker completion without starting a read; dismissal before file-read completion; picker/read failures while visible with localized feedback; and picker/read failures after dismissal. All picker/file delays are controlled fakes. This evidence does not establish real OS picker behavior, browser acceptance or actual disk permissions.

This isolated preparation is not the final integrated source qualification. Run `test/studio_mail_test.dart` from the Studio example in the final frozen host plan, with strict checks on `lib/studio_mail.dart`, `lib/studio_strings.dart` and that test file.

## Preserved diagnostics

The zero-case red/green environment-1 logs record an initially absent isolated package_graph.json. The two green-fixture diagnostics record test-harness corrections: a Completer created outside Flutter's fake-async zone, then an error-text finder that matched both the visible dialog and background scaffold. They are preserved separately and do not contribute to final counts. Final product evidence is red/green plus analysis/format receipts only. No GitHub Actions were queried or awaited, and no shared checkout/dependency resolution was changed during this review.

## Inputs and replay

`studio-mail-lifecycle.patch` and `patch-manifest.json` describe the three final source paths and hashes. `before` holds the incoming two production files plus the identical final regression suite; `after` holds the repair. Each isolated tree includes a minimal pubspec, pinned package-config/graph materialization and analysis options. Their absolute paths describe this workspace and must be regenerated for another workspace. `run_review.py` records commands and logs. The source-level patch is the portable deliverable; the final repository gate provides the authoritative integrated replay.
