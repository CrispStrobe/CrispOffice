#!/usr/bin/env python3
"""Bounded, read-only ancestry and prior evidence continuity audit.

Replays the already committed 409-reference audit, including its original
fourteen historical equivalence proofs. It does not refresh any remote ref,
execute application tests, resolve dependencies, or modify the repository.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

BASE = 'ec8bd8edf0452f7b8dd8b15b3f9b62f1bb224fa4'
PHASE = 'docs/validation/office-main-integration-20261119/arabic-final/'
KNOWN = [
    ('main after PR176', 'f059065fa622da8cee7824d66d29a2aff414d529'),
    ('PR177 captured head', 'c268ce3bceb05f92b7868e90ba8ce7b9a5bbbe1e'),
    ('PR178 captured head', '0b8f8f7f78fbf4e2e26671ecf9a0d858c38ca75c'),
    ('main after PR180', 'f7117a493055008a72e6e16713dd67a4f7c2ad39'),
    ('latest supplied main cutoff', 'b655b8a37fddc874bd42a453c371eed6253e82d8'),
]
EARLIER = [
    ('earlier main before PR174', '690e6ac8a1f7d8f5c8d4bea69d989a6728f3b27e'),
    ('original captured PR174 head', 'df62b58975bab1f650879fc88f850550a3df5c13'),
    ('captured PR175 Notes head', 'c320f28347f1cd292b848be2cf72998d41f8a6ac'),
    ('Notes integration merge', 'f38959f04cf58298ac56b142228d825e9d0deb82'),
    ('published PR174 head', '59e0a7c232e7380021a8bda4477999205da0f8ae'),
    ('main PR174 merge', 'd41000336c84b6ebfe6b35f7f8335140b5d46038'),
    ('main PR173 merge', '55e262ef269634a0d618c0b5102dc9be5430a5f3'),
    ('Arabic qualified source', 'e41679f85c511bc8cf42447d3d1af0931884dee2'),
    ('prior evidence publication', BASE),
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--head', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    output = args.output.resolve()
    if output.is_relative_to(repo):
        raise SystemExit('Write this read-only audit outside the repository.')

    def git(*params):
        return subprocess.check_output(['git', '-C', str(repo), *params])

    def text(*params):
        return git(*params).decode().strip()

    def sha(data):
        return hashlib.sha256(data).hexdigest()

    def ancestor(older, newer):
        result = subprocess.run(
            ['git', '-C', str(repo), 'merge-base', '--is-ancestor', older, newer],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        if result.returncode not in (0, 1):
            raise RuntimeError(result.stderr.decode())
        return result.returncode == 0

    def observation():
        return {
            'head': text('rev-parse', 'HEAD'),
            'refs_sha256': sha(git('for-each-ref', '--format=%(refname) %(objectname)')),
            'index_sha256': sha(git('ls-files', '--stage', '-z')),
        }

    before = observation()
    head = text('rev-parse', args.head + '^{commit}')
    prior_bytes = git('show', BASE + ':' + PHASE + 'arabic_ancestry_review.json')
    prior = json.loads(prior_bytes)
    assert prior['passed'] and prior['total_capture_rows'] == 409
    assert prior['all_14_historical_equivalences_reverified']
    selected = {
        'arabic_saved_ref_ancestry_audit.py': prior['script_sha256'],
        'arabic_saved_fork_refs.txt': next(p['sha256'] for p in prior['inputs'] if not p['upstream']),
        'arabic_saved_upstream_refs.txt': next(p['sha256'] for p in prior['inputs'] if p['upstream']),
    }
    source_records = []
    with tempfile.TemporaryDirectory(prefix='latest-ancestry-', dir=output.parent) as temporary:
        directory = Path(temporary)
        for name, digest in selected.items():
            data = git('show', BASE + ':' + PHASE + name)
            assert sha(data) == digest, name
            (directory / name).write_bytes(data)
            source_records.append({'commit': BASE, 'path': PHASE + name,
                                   'bytes': len(data), 'sha256': digest})
        fresh_path = directory / 'fresh.json'
        command = [sys.executable, str(directory / 'arabic_saved_ref_ancestry_audit.py'),
                   '--repo', str(repo), '--head', head,
                   '--refs', str(directory / 'arabic_saved_fork_refs.txt'),
                   '--upstream-refs', str(directory / 'arabic_saved_upstream_refs.txt'),
                   '--output', str(fresh_path)]
        subprocess.run(command, check=True, capture_output=True)
        fresh = json.loads(fresh_path.read_text())
    identity = lambda row: (row['namespace'], row['kind'], row['ref'], row['object_sha'])
    same_inventory = {identity(row) for row in fresh['refs']} == {
        identity(row) for row in prior['refs']
    }
    assert same_inventory and fresh['passed']

    def describe(label, commit):
        assert text('rev-parse', commit + '^{commit}') == commit
        return {'label': label, 'commit': commit,
                'tree': text('rev-parse', commit + '^{tree}'),
                'parents': text('show', '-s', '--format=%P', commit).split(),
                'subject': text('show', '-s', '--format=%s', commit),
                'ancestor_of_frozen_source': ancestor(commit, head)}

    known = [describe(label, commit) for label, commit in KNOWN]
    earlier = [describe(label, commit) for label, commit in EARLIER]
    earlier_by_label = {row['label']: row for row in earlier}
    notes = earlier_by_label['captured PR175 Notes head']['commit']
    notes_merge = earlier_by_label['Notes integration merge']['commit']
    published = earlier_by_label['published PR174 head']['commit']
    pr174 = earlier_by_label['main PR174 merge']['commit']
    notes_chain = {
        'captured_pr175_head_is_notes_merge_second_parent':
            earlier_by_label['Notes integration merge']['parents'][1] == notes,
        'notes_merge_is_ancestor_of_published_pr174_head': ancestor(notes_merge, published),
        'published_pr174_head_is_main_merge_second_parent':
            earlier_by_label['main PR174 merge']['parents'][1] == published,
        'pr174_main_merge_is_ancestor_of_latest_source': ancestor(pr174, head),
        'scope': 'Git inclusion chain only. No separate PR175 GitHub merge event or current PR state is inferred.',
    }

    def entries(commit):
        result = {}
        for row in git('ls-tree', '-rz', commit, '--', 'docs/validation').split(b'\0'):
            if not row:
                continue
            metadata, name = row.split(b'\t', 1)
            mode, kind, oid = metadata.decode().split()
            result[name.decode()] = {'mode': mode, 'kind': kind, 'blob': oid}
        return result

    old_tree, new_tree = entries(BASE), entries(head)
    reader = subprocess.Popen(['git', '-C', str(repo), 'cat-file', '--batch'],
                              stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    digests = {}

    def blob_digest(oid):
        if oid not in digests:
            reader.stdin.write((oid + '\n').encode())
            reader.stdin.flush()
            observed, kind, size = reader.stdout.readline().decode().split()
            data = reader.stdout.read(int(size))
            assert observed == oid and kind == 'blob' and reader.stdout.read(1) == b'\n'
            digests[oid] = {'bytes': len(data), 'sha256': sha(data)}
        return digests[oid]

    raw, changed_markdown = [], []
    for path, entry in sorted(old_tree.items()):
        current = new_tree.get(path)
        identical = entry == current
        if path.lower().endswith(('.md', '.markdown')):
            if not identical:
                changed_markdown.append({'path': path, 'before': entry, 'after': current})
            continue
        old_digest = blob_digest(entry['blob'])
        new_digest = blob_digest(current['blob']) if current else None
        raw.append({'path': path, 'before': entry, 'after': current,
                    'before_content': old_digest, 'after_content': new_digest,
                    'unchanged': identical and old_digest == new_digest})
    reader.stdin.close()
    assert reader.wait() == 0
    added = sorted(new_tree.keys() - old_tree.keys())
    raw_passed = all(row['unchanged'] for row in raw)
    after = observation()
    passed = (fresh['passed'] and same_inventory and raw_passed
              and all(row['ancestor_of_frozen_source'] for row in known + earlier)
              and all(value for key, value in notes_chain.items() if key != 'scope'))
    report = {
        'schema': 1,
        'checked_at_utc': datetime.now(timezone.utc).isoformat(),
        'frozen_source': head,
        'frozen_tree': text('rev-parse', head + '^{tree}'),
        'script_sha256': sha(Path(__file__).read_bytes()),
        'prior_evidence_commit': BASE,
        'saved_audit_reuse': {
            'prior_report': PHASE + 'arabic_ancestry_review.json',
            'prior_report_sha256': sha(prior_bytes),
            'prior_qualified_source': prior['integrated_head'],
            'input_records': source_records,
            'exact_same_409_reference_identities': same_inventory,
            'scope': 'Previously captured immutable local observations; not a new remote advertisement.',
        },
        'captured_reference_audit': fresh,
        'known_head_addendum': {
            'count': len(known), 'heads': known,
            'scope': 'Five supplied commit observations, separate from the saved 409 references. Reference count is not inflated to 414.',
        },
        'earlier_main_and_integration_commits': earlier,
        'pr175_inclusion_through_pr174': notes_chain,
        'raw_artifact_continuity': {
            'baseline': BASE, 'scope': 'Every pre-existing non-Markdown path under docs/validation/.',
            'prior_validation_paths': len(old_tree),
            'prior_raw_artifact_paths': len(raw),
            'unchanged_raw_artifact_paths': sum(row['unchanged'] for row in raw),
            'changed_raw_artifact_paths': [row['path'] for row in raw if not row['unchanged']],
            'all_prior_raw_artifacts_preserved': raw_passed,
            'changed_existing_markdown': changed_markdown,
            'added_validation_paths': added,
            'raw_artifacts': raw,
            'method': 'Git mode/blob comparison and independently computed SHA-256 of every before/after raw artifact. Archive members are not re-extracted here; prior successful member audits remain tied to their original source.',
        },
        'working_copy_observation': {'before': before, 'after': after, 'unchanged': before == after},
        'qualification_scope': 'Ancestry, historical source equivalence and evidence-byte preservation only. No current application, browser, native platform, linguistic, or runtime acceptance is inferred.',
        'remote_queries': 0, 'github_actions_queries': 0,
        'repository_mutations': 0, 'application_tests_executed': False,
        'passed': passed,
    }
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({
        'head': head, 'counts': fresh['counts'],
        'classification': fresh['classification'],
        'historical_proofs_pass': fresh['all_14_historical_equivalences_reverified'],
        'known_heads': len(known),
        'raw_artifacts': len(raw), 'raw_artifacts_unchanged': raw_passed,
        'changed_markdown': [row['path'] for row in changed_markdown],
        'added_validation_paths': len(added),
        'working_copy_unchanged': before == after, 'passed': passed,
    }, indent=2))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
