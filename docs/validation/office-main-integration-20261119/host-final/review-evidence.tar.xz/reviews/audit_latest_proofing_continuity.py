#!/usr/bin/env python3
"""Read-only frozen Git and archived evidence continuity audit; executes no tests."""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import posixpath
import re
import subprocess
import tarfile
from urllib.parse import unquote, urlparse

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--head', required=True)
p.add_argument('--output', type=Path, required=True)
args = p.parse_args()
BASE = 'e41679f85c511bc8cf42447d3d1af0931884dee2'
PUBLICATION = 'ec8bd8edf0452f7b8dd8b15b3f9b62f1bb224fa4'
PREFIX = 'docs/validation/office-main-integration-20261119/arabic-final/'
LATEST = 'docs/validation/office-main-integration-20261119/latest-final/'
ORIGINAL = '39843ed4874c7b56572c7aa8195716e5892aeca2'
GROUP_NAMES = ['office-proofing-engine-vm', 'english-proofing-contracts-vm',
               'office-proofing-editor', 'studio-proofing-registration']
EXPECTED_CASES = [213, 29, 320, 18]

def git(*argv):
    return subprocess.check_output(['git', '-C', str(args.repo), *argv])

def sha(data):
    return hashlib.sha256(data).hexdigest()

head = git('rev-parse', args.head+'^{commit}').decode().strip()
def tree(ref):
    rows = {}
    for row in git('ls-tree', '-rz', ref).split(b'\0'):
        if row:
            meta, path = row.split(b'\t', 1)
            rows[path.decode()] = meta.decode().split()
    return rows

trees = {ref: tree(ref) for ref in {BASE, PUBLICATION, head, ORIGINAL}}
batch = subprocess.Popen(['git', '-C', str(args.repo), 'cat-file', '--batch'],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE)
blobs = {}
def read(ref, path):
    oid = trees[ref][path][2]
    if oid not in blobs:
        batch.stdin.write((oid+'\n').encode()); batch.stdin.flush()
        actual, kind, size = batch.stdout.readline().decode().split()
        blobs[oid] = batch.stdout.read(int(size))
        assert batch.stdout.read(1) == b'\n' and kind == 'blob' and actual == oid
    return blobs[oid]

packed = read(PUBLICATION, PREFIX+'qualification-evidence.tar.xz')
index = json.loads(read(PUBLICATION, PREFIX+'qualification-evidence.index.json'))
assert index['source_commit'] == BASE
assert len(packed) == index['archive_bytes'] and sha(packed) == index['archive_sha256']
with tarfile.open(fileobj=io.BytesIO(packed), mode='r:xz') as archive:
    members = archive.getmembers()
    assert all(m.isfile() and not m.name.startswith('/') and '..' not in PurePosixPath(m.name).parts for m in members)
    assert len(members) == len({m.name for m in members})
    archived = {m.name: archive.extractfile(m).read() for m in members}
indexed = {m['path']: m for m in index['members']}
assert set(archived) == set(indexed)
for name, data in archived.items():
    assert len(data) == indexed[name]['bytes'] and sha(data) == indexed[name]['sha256'], name
receipt_bytes = read(PUBLICATION, PREFIX+'verification.json')
assert receipt_bytes == archived['focused/verification.json']
receipt = json.loads(receipt_bytes)
plan_bytes = read(PUBLICATION, PREFIX+'plan.json')
plan = json.loads(plan_bytes)
assert receipt['source_commit'] == BASE and receipt['success']
assert sha(plan_bytes) == receipt['plan_sha256']
assert read(BASE, PREFIX+'plan.json') == plan_bytes
assert archived['focused/source-before.json'] == archived['focused/source-after.json']
assert archived['focused/environment-before.json'] == archived['focused/environment-after.json']
old_source = json.loads(archived['focused/source-before.json'])
old_environment = json.loads(archived['focused/environment-before.json'])
for name in ('source-before.json', 'source-after.json', 'environment-before.json', 'environment-after.json'):
    assert sha(archived['focused/'+name]) == receipt['manifest_sha256'][name]
for path, entry in old_source.items():
    assert trees[BASE][path][0] == entry['mode']
    assert trees[BASE][path][2] == entry['git_blob']
    assert sha(read(BASE, path)) == entry['sha256'], path
changed = {p for p in trees[BASE].keys() | trees[head].keys() if trees[BASE].get(p) != trees[head].get(p)}

# The previous actual package configuration is reconstructable without guessing:
# removing only the new Hunspell entry from the current raw bytes gives its
# exact archived SHA-256. This establishes every pre-existing package mapping.
config_path = args.repo/'.dart_tool/package_config.json'
config_bytes = config_path.read_bytes()
config_text = config_bytes.decode()
new_entry = re.search(r'    \{\n      "name": "quds_proofing_hunspell",.*?    \},\n', config_text, re.S)
assert new_entry is not None
old_config_bytes = (config_text[:new_entry.start()]+config_text[new_entry.end():]).encode()
assert sha(old_config_bytes) == old_environment['workspace/package_config.json']
configs = {BASE: json.loads(old_config_bytes), head: json.loads(config_bytes)}

def package_map(config):
    result = {}
    for entry in config['packages']:
        uri = entry['rootUri']
        parsed = urlparse(uri)
        if parsed.scheme == 'file': root = Path(unquote(parsed.path)).resolve()
        else:
            assert not parsed.scheme, uri
            root = (config_path.parent/unquote(uri)).resolve()
        lib = root/entry.get('packageUri', 'lib/')
        try:
            local_root = root.relative_to(args.repo)
            local_lib = lib.relative_to(args.repo)
            result[entry['name']] = ('git', str(local_lib), str(local_root))
        except ValueError:
            result[entry['name']] = ('external', str(lib), str(root))
    return result

maps = {ref: package_map(config) for ref, config in configs.items()}
runtime_root = Path(unquote(urlparse(configs[head]['flutterRoot']).path)).parent
external_records = {}
external_bytes = {}
def read_external(path):
    if path not in external_bytes:
        data = Path(path).read_bytes()
        try: key = 'runtime/'+str(Path(path).relative_to(runtime_root))
        except ValueError: key = 'additional/'+path
        expected = old_environment.get(key)
        digest = sha(data)
        external_records[path] = {'environment_key': key, 'bytes': len(data), 'sha256': digest,
                                  'archived_sha256': expected, 'unchanged': expected == digest}
        assert expected == digest, ('external input not bound to old environment', path, key)
        external_bytes[path] = data
    return external_bytes[path]

directive_pattern = re.compile(r'''^\s*(?:import|export|part)\s+(["'].*?);''', re.M|re.S)
quoted = re.compile(r'''["']([^"']+)["']''')
dependency_cache = {}
def dependencies(ref, item):
    key = ref, item
    if key in dependency_cache: return dependency_cache[key]
    kind, path = item
    data = read(ref, path) if kind == 'git' else read_external(path)
    links, sdk, packages, missing = set(), set(), set(), set()
    for directive in directive_pattern.findall(data.decode()):
        for uri in quoted.findall(directive):
            if uri.startswith('dart:'):
                sdk.add(uri); continue
            if uri.startswith('package:'):
                name, relative = uri[8:].split('/', 1)
                packages.add(name)
                if name not in maps[ref]:
                    missing.add(f'{kind}:{path} -> {uri}'); continue
                target_kind, lib, _ = maps[ref][name]
                target = (target_kind, posixpath.normpath(posixpath.join(lib, relative)))
            elif ':' in uri:
                missing.add(f'{kind}:{path} -> {uri}'); continue
            else:
                target = (kind, posixpath.normpath(posixpath.join(posixpath.dirname(path), uri)))
            target_exists = (target[1] in trees[ref]) if target[0] == 'git' else Path(target[1]).is_file()
            if target_exists: links.add(target)
            else: missing.add(f'{kind}:{path} -> {target[0]}:{target[1]}')
    dependency_cache[key] = links, sdk, packages, missing
    return dependency_cache[key]

def closure(ref, start):
    seen, sdk, packages, missing = set(), set(), set(), set()
    pending = [('git', start)]
    while pending:
        item = pending.pop()
        if item in seen: continue
        seen.add(item)
        linked, dart, names, absent = dependencies(ref, item)
        pending.extend(linked-seen); sdk.update(dart); packages.update(names); missing.update(absent)
    return seen, sdk, packages, missing

suite_checks = []
groups = []
union_old, union_new = set(), set()
for group_name, expected in zip(GROUP_NAMES, EXPECTED_CASES):
    group = next(g for g in plan['groups'] if g['name'] == group_name)
    run = next(g for g in receipt['runs'] if g['name'] == group_name)
    assert run['passed'] == expected and run['accepted'] and run['exit_code'] == 0
    group_records = []
    group_old, group_new = set(), set()
    for test in group['tests']:
        start = group['cwd']+'/'+test
        a, sdk_a, names_a, missing_a = closure(BASE, start)
        b, sdk_b, names_b, missing_b = closure(head, start)
        union_old.update(a); union_new.update(b); group_old.update(a); group_new.update(b)
        affected = sorted(path for kind,path in a|b if kind == 'git' and path in changed)
        package_names = sorted(names_a|names_b)
        local_manifests = sorted({maps[ref][name][2]+'/pubspec.yaml'
                                  for ref,names in [(BASE,names_a),(head,names_b)]
                                  for name in names if maps[ref][name][0] == 'git'})
        local_manifests.append(group['cwd']+'/pubspec.yaml')
        local_manifests = sorted(set(local_manifests))
        count = run['per_suite'][str(args.repo/start)]['passed']
        record = {'path': start, 'group': group_name, 'historical_passed_cases': count,
                  'suite_file_unchanged': start not in changed,
                  'qualified_tracked_closure_files': sum(k=='git' for k,p in a),
                  'current_tracked_closure_files': sum(k=='git' for k,p in b),
                  'qualified_external_closure_files': sum(k=='external' for k,p in a),
                  'current_external_closure_files': sum(k=='external' for k,p in b),
                  'closure_added': sorted(':'.join(x) for x in b-a),
                  'closure_removed': sorted(':'.join(x) for x in a-b),
                  'changed_tracked_closure_paths': affected,
                  'workspace_manifest_paths': local_manifests,
                  'changed_workspace_manifests': [p for p in local_manifests if p in changed],
                  'imported_packages': package_names, 'sdk_uris': sorted(sdk_a|sdk_b),
                  'unresolved_directives': sorted(missing_a|missing_b)}
        record['byte_bound_static_source_and_dependency_closure'] = not (
            affected or a!=b or record['changed_workspace_manifests'] or missing_a or missing_b)
        group_records.append(record); suite_checks.append(record)
    groups.append({'name': group_name, 'historical_passed_executions': expected,
                   'suite_count': len(group_records),
                   'suite_files_unchanged': sum(x['suite_file_unchanged'] for x in group_records),
                   'byte_bound_suites': sum(x['byte_bound_static_source_and_dependency_closure'] for x in group_records),
                   'byte_bound_historical_cases': sum(x['historical_passed_cases'] for x in group_records if x['byte_bound_static_source_and_dependency_closure']),
                   'qualified_tracked_union_files': sum(k=='git' for k,p in group_old),
                   'current_tracked_union_files': sum(k=='git' for k,p in group_new),
                   'external_union_files': sum(k=='external' for k,p in group_old|group_new),
                   'changed_tracked_closure_paths': sorted({p for x in group_records for p in x['changed_tracked_closure_paths']}),
                   'new_hunspell_overlap': sorted(p for k,p in group_old|group_new if k=='git' and p.startswith('packages/quds_proofing_hunspell/'))})

notes_paths = ['packages/quds_office_editor/CHANGELOG.md',
 'packages/quds_office_editor/lib/src/embed/office_editors.dart',
 'packages/quds_office_editor/test/word_notes_proofing_controller_test.dart',
 'packages/quds_office_editor/test/word_notes_proofing_pane_test.dart',
 'packages/quds_office_editor/test/word_zotero_notes_pane_test.dart']
notes = [{'path': path, 'original_blob': trees[ORIGINAL][path][2],
          'qualified_blob': trees[BASE][path][2], 'current_blob': trees[head][path][2],
          'identical_to_original_and_e416': trees[ORIGINAL][path] == trees[BASE][path] == trees[head][path]}
         for path in notes_paths]
arabic_paths = ['packages/quds_office_engine/lib/src/proofing/arabic_writing_rules.dart',
 'packages/quds_office_engine/test/proofing/arabic_writing_rules_test.dart',
 'packages/quds_office_editor/lib/src/proofing/word_proofing.dart',
 'packages/quds_office_editor/example/lib/suite_workspace.dart',
 'packages/quds_office_editor/test/word_arabic_writing_integration_test.dart']
arabic = [{'path':path, 'qualified_blob':trees[BASE][path][2], 'current_blob':trees[head][path][2],
           'unchanged':path not in changed,
           'registration_lines':[{'line':i, 'text':line.strip()}
                                 for i,line in enumerate(read(head,path).decode().splitlines(),1)
                                 if 'ArabicWritingRulesProvider' in line]}
          for path in arabic_paths]
host_prefixes = ['packages/quds_office_editor/lib/', 'packages/quds_office_editor/example/lib/',
                 'packages/quds_office_engine/lib/', 'apps/']
hunspell_host_hits = []
for path in trees[head]:
    if path.endswith('.dart') and any(path.startswith(prefix) for prefix in host_prefixes):
        for i,line in enumerate(read(head,path).decode().splitlines(),1):
            if re.search(r'HunspellProvider|HunspellProofingProvider|quds_proofing_hunspell',line):
                hunspell_host_hits.append({'path':path,'line':i,'text':line})

prefix_checks = []
for prefix in ['packages/quds_office_engine/', 'packages/quds_office_editor/', 'packages/quds_proofing_harper/']:
    old = {p for p in trees[BASE] if p.startswith(prefix)}
    new = {p for p in trees[head] if p.startswith(prefix)}
    prefix_checks.append({'prefix':prefix, 'old_files':len(old), 'current_files':len(new),
                          'old_files_changed_or_removed':sorted(old&changed),
                          'added_files':sorted(new-old),
                          'changed_or_added_dart_files':sorted(p for p in (old|new)&changed if p.endswith('.dart'))})

docs = []
for path in ['docs/PROOFING.md','docs/roadmaps/arabic-proofing.md','packages/quds_proofing_hunspell/README.md']:
    rows = read(head,path).decode().splitlines()
    relevant = [{'line':i,'text':line} for i,line in enumerate(rows,1)
                if re.search(r'adapter|host registration|host wiring|download workflow|packaging.*open|planned',line,re.I)]
    stale = [{'line':i,'text':line} for i,line in enumerate(rows,1)
             if re.search(r'(?:adapter|Hunspell engine).{0,45}(?:remain|remains|still) planned',line,re.I)]
    docs.append({'path':path,'git_blob':trees[head][path][2],
                 'relevant_lines':relevant,'stale_adapter_planned_matches':stale})

main_plan = json.loads(read(head,LATEST+'plan.json'))
node_plan = json.loads(read(head,LATEST+'node-plan.json'))
plan_checks = []
all_keys = []
for name, q in [('main',main_plan),('node',node_plan)]:
    keys = [(g.get('platform','vm'), g['cwd']+'/'+test) for g in q['groups'] for test in g['tests']]
    all_keys.extend(keys)
    plan_checks.append({'name':name,'suite_entries':len(keys),
                        'duplicate_platform_path_keys':[list(k) for k,n in Counter(keys).items() if n>1],
                        'missing_test_paths':[path for platform,path in keys if path not in trees[head]],
                        'analysis_paths':len(q.get('analysis',[])), 'format_paths':len(q.get('format',[])),
                        'analysis_format_identical':q.get('analysis',[])==q.get('format',[]),
                        'duplicate_analysis_paths':[x for x,n in Counter(q.get('analysis',[])).items() if n>1],
                        'missing_analysis_paths':[path for path in q.get('analysis',[]) if path not in trees[head]],
                        'missing_extra_inputs':[path for path in q['extra_inputs'] if path not in trees[head]],
                        'sha256':sha(read(head,LATEST+('plan.json' if name=='main' else 'node-plan.json')))})
selected_current_paths = {path for platform,path in all_keys}

locked_same = trees[BASE]['pubspec.lock'] == trees[head]['pubspec.lock']
assert locked_same and sha(read(BASE,'pubspec.lock')) == receipt['workspace_lock_sha256']
for record in external_records.values(): assert record['unchanged']
external_stable = all(sha(Path(path).read_bytes())==row['sha256'] for path,row in external_records.items())
assert config_path.read_bytes() == config_bytes and external_stable
batch.stdin.close(); assert batch.wait()==0

report = {
 'schema':1, 'audited_at_utc':datetime.now(timezone.utc).isoformat(),
 'qualified_source':BASE, 'qualified_tree':git('rev-parse',BASE+'^{tree}').decode().strip(),
 'evidence_publication':PUBLICATION, 'current_frozen_source':head,
 'current_frozen_tree':git('rev-parse',head+'^{tree}').decode().strip(),
 'archive_integrity':{'path':PREFIX+'qualification-evidence.tar.xz','sha256':sha(packed),
                     'bytes':len(packed),'members':len(archived),'all_member_hashes_sizes_verified':True,
                     'source_before_after_identical':True,'environment_before_after_identical':True,
                     'source_records_verified_against_qualified_git':len(old_source),
                     'receipt_source_and_plan_hash_verified':True,'raw_event_recount_performed':False},
 'groups':groups, 'suites':suite_checks,
 'scope':{'prior_groups_total_suites':len(suite_checks), 'prior_groups_total_executions':sum(EXPECTED_CASES),
          'byte_bound_suites':sum(x['byte_bound_static_source_and_dependency_closure'] for x in suite_checks),
          'byte_bound_historical_cases':sum(x['historical_passed_cases'] for x in suite_checks if x['byte_bound_static_source_and_dependency_closure']),
          'changed_closure_suites':sum(not x['byte_bound_static_source_and_dependency_closure'] for x in suite_checks),
          'qualified_tracked_union_files':sum(k=='git' for k,p in union_old),
          'current_tracked_union_files':sum(k=='git' for k,p in union_new),
          'external_closure_files_verified':len(external_records),
          'unresolved_directives':sorted({p for x in suite_checks for p in x['unresolved_directives']}),
          'prior_suites_selected_for_fresh_current_execution':[x['path'] for x in suite_checks if x['path'] in selected_current_paths]},
 'package_resolution':{'qualified_package_config_sha256':sha(old_config_bytes),
                       'current_package_config_sha256':sha(config_bytes),
                       'prior_config_exactly_reconstructed_by_removing_only_new_hunspell_entry':True,
                       'new_entry':json.loads('{"packages":['+new_entry.group(0).strip().removesuffix(',')+']}')['packages'][0],
                       'qualified_packages':len(configs[BASE]['packages']), 'current_packages':len(configs[head]['packages']),
                       'all_preexisting_mappings_and_language_versions_identical':True,
                       'root_lock_bytes_unchanged':True, 'root_lock_sha256':sha(read(BASE,'pubspec.lock')),
                       'root_workspace_manifest_unchanged':False,
                       'current_config_and_external_bytes_stable_during_audit':True,
                       'full_runtime_or_generated_outputs_equality_claimed':False},
 'external_dependency_source_files':external_records,
 'tracked_closure_inputs':[{'path':path,'qualified_blob':trees[BASE].get(path,[None,None,None])[2],
                            'current_blob':trees[head].get(path,[None,None,None])[2],
                            'unchanged':path not in changed}
                           for kind,path in sorted(union_old|union_new) if kind=='git'],
 'bound_source_inventory':{'identical_prior_records':sum(path not in changed for path in old_source),
                           'changed_prior_records':[path for path in old_source if path in changed]},
 'protected_notes':notes, 'arabic_source_and_registrations':arabic,
 'hunspell_default_host_registration_search':{'prefixes':host_prefixes,'matches':hunspell_host_hits,
                                              'not_default_registered':not hunspell_host_hits},
 'proofing_package_inventories':prefix_checks, 'documentation_scope':docs,
 'fresh_plan_review':{'plans':plan_checks,
                      'combined_duplicate_platform_path_keys':[list(k) for k,n in Counter(all_keys).items() if n>1],
                      'extra_inputs_identical':main_plan['extra_inputs']==node_plan['extra_inputs'],
                      'extra_input_count':len(main_plan['extra_inputs']),
                      'node_omits_redundant_static_checks':not node_plan['analysis'] and not node_plan['format'],
                      'actual_ayaspell_backend_installer_suite_selected':'packages/quds_proofing_hunspell/test/hunspell_native_test.dart' in selected_current_paths,
                      'forecast_counts_not_validated_as_test_results':True},
 'method':'Immutable Git mode/blob identities and archived hashes; Dart import/export/part traversal includes every conditional branch and recursively follows current workspace and hosted/Flutter sources. Exact prior package-configuration bytes are recovered by deleting only the new, unreferenced Hunspell entry and checked against the archived digest. Every visited external dependency source file is rehashed against the prior environment manifest and rechecked for stability. Dart SDK implementation, compiled runtimes, dynamic loading, assets/native packaging, and generated outputs are outside the static closure claim.',
 'qualification_wording':'The four prior proofing groups remain historical test executions at e41679f8. Static source/dependency continuity is reported per suite; unchanged closures retain source-bound evidence but are not fresh executions at the current source. Changed closures must not be represented as byte-bound to their prior pass. New Hunspell, Mail UID, native packaging, and current selected tests require their own current-source receipts. Overlapping historical and fresh counts must not be added.',
 'application_tests_executed':False, 'repository_mutations':0, 'remote_refreshes':0, 'github_actions_queried_or_awaited':False,
}
args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'output':str(args.output),'source':head,'groups':groups,'scope':report['scope'],
                  'protected_notes_unchanged':all(x['identical_to_original_and_e416'] for x in notes),
                  'arabic_source_unchanged':all(x['unchanged'] for x in arabic),
                  'hunspell_default_host_hits':hunspell_host_hits,
                  'package_resolution':report['package_resolution'],
                  'stale_adapter_planned_matches':[x for d in docs for x in d['stale_adapter_planned_matches']]},indent=2))
