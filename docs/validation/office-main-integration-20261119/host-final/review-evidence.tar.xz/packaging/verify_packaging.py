#!/usr/bin/env python3
"""Offline controls for the incoming packaging helpers, using synthetic outputs."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'incoming/packages/quds_proofing_hunspell'
SOURCE = PACKAGE / 'tool/build.py'
module = types.ModuleType('incoming_hunspell_build')
module.__file__ = str(SOURCE)
exec(compile(SOURCE.read_text(), str(SOURCE), 'exec'), module.__dict__)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class PackagingControls(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='packaging-', dir=ROOT)
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.output = self.root / 'build'
        self.output.mkdir()

    def receipt(self, files):
        for name, data in files.items():
            target = self.output / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        receipt = {'files': {name: digest(self.output / name) for name in files}}
        (self.output / 'build-receipt.json').write_text(json.dumps(receipt))

    def test_native_copies_only_selected_receipt_files(self):
        self.receipt({'native/fixture.so': b'native-control', 'web/module.mjs': b'web-control'})
        (self.output / 'native/stale.so').write_bytes(b'not-in-receipt')
        destination = self.root / 'host'
        result = module.install(self.output, 'native', destination, licenses=False)
        self.assertEqual(result['files'], ['native/fixture.so'])
        self.assertEqual({p.name for p in destination.iterdir()}, {'fixture.so'})
        self.assertEqual((destination / 'fixture.so').read_bytes(), b'native-control')

    def test_tampered_output_is_rejected_before_destination_mutation(self):
        self.receipt({'native/fixture.so': b'native-control'})
        (self.output / 'native/fixture.so').write_bytes(b'changed')
        destination = self.root / 'host'
        with self.assertRaisesRegex(SystemExit, 'changed build artifact'):
            module.install(self.output, 'native', destination, licenses=False)
        self.assertFalse(destination.exists())

    def test_web_installs_exact_notices_sources_and_receipt(self):
        payloads = {'web/hunspell_worker.mjs': b'worker-control',
                    'web/quds_proofing_hunspell.mjs': b'module-control',
                    'web/quds_proofing_hunspell.wasm': b'wasm-control'}
        self.receipt(payloads)
        destination = self.root / 'web-host'
        module.install(self.output, 'web', destination, licenses=True)
        for name, data in payloads.items():
            self.assertEqual((destination / Path(name).name).read_bytes(), data)
        notices = destination / 'licenses/hunspell'
        expected = {'COPYING.MPL', 'license.hunspell', 'license.myspell',
                    'manifest.json', 'hunspell-1.7.2-library-sources.tar.gz',
                    'LICENSE.adapter', 'build-receipt.json'}
        self.assertEqual({p.name for p in notices.iterdir()}, expected)
        for name in ('COPYING.MPL', 'license.hunspell', 'license.myspell'):
            self.assertEqual(digest(notices / name), digest(PACKAGE / 'licenses/upstream' / name))
        for name in ('manifest.json', 'hunspell-1.7.2-library-sources.tar.gz'):
            self.assertEqual(digest(notices / name), digest(PACKAGE / 'licenses' / name))
        self.assertEqual(digest(notices / 'LICENSE.adapter'), digest(PACKAGE / 'LICENSE'))
        self.assertEqual(digest(notices / 'build-receipt.json'), digest(self.output / 'build-receipt.json'))

    def test_missing_kind_and_self_install_fail_without_changes(self):
        self.receipt({'native/fixture.so': b'native-control'})
        destination = self.root / 'host'
        with self.assertRaisesRegex(SystemExit, 'no web outputs'):
            module.install(self.output, 'web', destination, licenses=False)
        self.assertFalse(destination.exists())
        before = (self.output / 'native/fixture.so').read_bytes()
        with self.assertRaisesRegex(SystemExit, 'separate from the build output'):
            module.install(self.output, 'native', self.output / 'native', licenses=False)
        self.assertEqual((self.output / 'native/fixture.so').read_bytes(), before)


if __name__ == '__main__':
    inputs = [PACKAGE / f['path'].split('packages/quds_proofing_hunspell/', 1)[1]
              for f in json.loads((ROOT / 'build-inputs.json').read_text())['files']]
    before = {str(path): digest(path) for path in inputs}
    stream = io.StringIO()
    with patch.object(module.urllib.request, 'urlopen', side_effect=AssertionError('Network forbidden')) as network:
        with patch.object(module, 'run', side_effect=AssertionError('Compiler execution not part of these controls')) as compiler:
            result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
                unittest.defaultTestLoader.loadTestsFromTestCase(PackagingControls))
    log = ROOT / 'packaging-controls.log'
    log.write_text(stream.getvalue())
    after = {str(path): digest(path) for path in inputs}
    receipt = {'source_commit': 'be641457c8c7d1acc25091b31c87c73eaa3c9c2a',
               'checked_at_utc': datetime.now(timezone.utc).isoformat(),
               'tests': result.testsRun, 'failures': len(result.failures),
               'errors': len(result.errors), 'skipped': len(result.skipped),
               'before': before, 'after': after, 'inputs_unchanged': before == after,
               'network_calls': network.call_count, 'compiler_calls': compiler.call_count,
               'script_sha256': digest(Path(__file__)), 'log_sha256': digest(log),
               'scope': 'Synthetic build artifacts test install selection, tamper rejection and source/notice copying; no platform build or installed app acceptance.',
               'passed': result.wasSuccessful() and before == after}
    (ROOT / 'packaging-controls-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ('tests', 'failures', 'errors', 'skipped',
                                                   'inputs_unchanged', 'network_calls',
                                                   'compiler_calls', 'passed')}))
    raise SystemExit(0 if receipt['passed'] else 1)
