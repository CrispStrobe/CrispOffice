import 'dart:convert';
import 'arabic_writing_rules.dart';
import 'office_proofing.dart';
Future<void> main() async {
  final inputs = <String>[
    'ا\u0654ختار بين كتابين.',
    'ا\u0653ختار بين كتابين.',
    'ا\u0655ختار بين كتابين.',
    'أختار بين كتابين.',
    '😀 ا\u0654ختار بين كتابين؛ درس كل حالة على حدى.',
  ];
  final results = <Object>[];
  for (final text in inputs) {
    final provider = ArabicWritingRulesProvider(enabledOptionalRuleIds: {'ar.usage.expression'});
    final result = await provider.check(OfficeProofingRequest(documentId: 'd', blockId: 'b', revision: 1, text: text, language: 'ar', startOffset: 100));
    results.add({'text': text, 'findings': [for(final f in result.findings) {'rule':f.ruleId,'original':f.originalText,'start':f.start,'end':f.end,'replacements':f.replacements}]});
    await provider.dispose();
  }
  print(jsonEncode(results));
}
