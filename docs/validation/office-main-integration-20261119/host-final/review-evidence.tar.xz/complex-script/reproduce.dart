import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'before/word_proofing_language.dart' as before;
import 'after/word_proofing_language.dart' as after;
void main() {
  final paragraph = WmlParagraph();
  final inputs = <String>[
    'Plain English', 'English،', 'Invoice ١', 'Invoice ۱',
    '\uFEFFEnglish', 'English\u0651', 'English\u05BE',
    'مرحبا', 'שלום', '\uFEE1',
  ];
  print(jsonEncode([for(final text in inputs) {
    'text': text,
    'before_is_letter':before.wordTextHasComplexScriptLetter(text),
    'after_is_letter':after.wordTextHasComplexScriptLetter(text),
    'before_language': before.wordRunProofingLanguage(WmlRun(text:text), paragraph,documentLanguage:'en-US',documentComplexScriptLanguage:'ar-SA'),
    'after_language': after.wordRunProofingLanguage(WmlRun(text:text), paragraph,documentLanguage:'en-US',documentComplexScriptLanguage:'ar-SA'),
  }]));
}
