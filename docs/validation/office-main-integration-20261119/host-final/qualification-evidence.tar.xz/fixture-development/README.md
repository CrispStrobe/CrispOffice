# Development attempts; excluded from final case totals

The first fixture preflight found obsolete English/default-pane assumptions.
The next attempts preserve a nullable-config compile error and then a pending
native proofing timer in the visibility-only fixture. The third focused setup
attempt passed four cases. After frozen source468 exposed timer ordering in
three more suites, the command in host-controlled-setup-green.log selected no
cases (multiple --plain-name filters); it is **not** a passing regression run.
The corrected full three-suite preflight in host-controlled-suites-green.log
completed 62 successful cases with terminal success. All of these development
runs are separate from the final frozen main/Node qualification and are never
added to it. host-static-preflight.log records the 51-path clean analysis before
that freeze.
