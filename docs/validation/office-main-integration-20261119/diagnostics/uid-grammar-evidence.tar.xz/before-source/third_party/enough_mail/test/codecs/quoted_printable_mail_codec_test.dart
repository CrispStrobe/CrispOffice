import 'dart:convert' as convert;

import 'package:enough_mail/src/codecs/mail_codec.dart';
import 'package:test/test.dart';

// cSpell:disable

void main() {
  group('Quoted Printable decoding', () {
    test('encodings.quoted-printable header', () {
      const input =
          '=?utf-8?Q?Chat=3A?==?utf-8?Q?_?=oh=?utf-8?Q?_?==?utf-8?Q?hi=2C?='
          '=?utf-8?Q?__?=how=?utf-8?Q?_?=do=?utf-8?Q?_?=you=?utf-8?Q?_?==?utf-'
          '8?Q?do=3F?==?utf-8?Q?_?==?utf-8?Q?=3A-)?=';
      expect(MailCodec.decodeHeader(input), 'Chat: oh hi,  how do you do? :-)');
    });

    test('encodings.quoted-printable header no direct start', () {
      const input =
          ' =?utf-8?Q?Chat=3A?==?utf-8?Q?_?=oh=?utf-8?Q?_?==?utf-8?Q?hi=2C?='
          '=?utf-8?Q?__?=how=?utf-8?Q?_?=do=?utf-8?Q?_?=you=?utf-8?Q?_?==?ut'
          'f-8?Q?do=3F?==?utf-8?Q?_?==?utf-8?Q?=3A-)?=';
      expect(
        MailCodec.decodeHeader(input),
        ' Chat: oh hi,  how do you do? :-)',
      );
    });

    test('encoding.iso-8859-1 quoted printable', () {
      const input = '=?iso-8859-1?Q?Bj=F6rn?= Tester <btester@domain.com>';
      expect(
        MailCodec.decodeHeader(input),
        'Björn Tester <btester@domain.com>',
      );
    });

    test('encoding.iso-8859-1 quoted printable not at start', () {
      const input = 'Tester =?iso-8859-1?Q?Bj=F6rn?= <btester@domain.com>';
      expect(
        MailCodec.decodeHeader(input),
        'Tester Björn <btester@domain.com>',
      );
    });

    test('encoding.UTF-8.QuotedPrintable with several codes', () {
      const input = '=?utf-8?Q?=E2=80=93?=';
      expect(
        MailCodec.decodeHeader(input),
        isNotNull,
      ); // this results in a character - which for some
      // reasons cannot be pasted as Dart code
    });
    test('encoding.US-ASCII.QuotedPrintable', () {
      const input = '=?US-ASCII?Q?Keith_Moore?= <moore@cs.utk.edu>';
      expect(MailCodec.decodeHeader(input), 'Keith Moore <moore@cs.utk.edu>');
    });

    test('encoding.UTF-8.QuotedPrintable with line break', () {
      const input =
          'Viele Gr</span>=C3=BC=C3=9Fe</p=\r\n'
          '>';
      expect(
        MailCodec.quotedPrintable.decodeText(input, convert.utf8),
        'Viele Gr</span>üße</p>',
      );
    });

    test('encoding latin1.QuotedPrintable', () {
      const input = 'jeden Tag =E4ndern k=F6nnen';
      expect(
        MailCodec.quotedPrintable.decodeText(
          input,
          const convert.Latin1Codec(),
        ),
        'jeden Tag ändern können',
      );
    });
  });

  group('Quoted Printable encoding', () {
    test('encodeHeader.quoted-printable with ASCII input', () {
      const input = 'Hello World';
      expect(MailCodec.quotedPrintable.encodeHeader(input), 'Hello World');
    });
    test('encodeHeader.quoted-printable with UTF8 input', () {
      const input = 'Hello Wörld';
      expect(
        MailCodec.quotedPrintable.encodeHeader(input),
        'Hello W=?UTF-8?Q?=C3=B6?=rld',
      );
      // counter test:
      expect(
        MailCodec.decodeHeader('Hello W=?UTF8?Q?=C3=B6?=rld'),
        'Hello Wörld',
      );
    });
    test('encodeHeader for a phrase always encodes and escapes specials', () {
      expect(
        MailCodec.quotedPrintable.encodeHeader('a.b c', isPhrase: true),
        '=?UTF-8?Q?a=2Eb_c?=',
      );
    });

    test('encodeText.quoted-printable with UTF8 and = input', () {
      const input =
          'Hello Wörld. This is a long text without linebreak and this '
          'contains the formula c^2=a^2+b^2.';
      expect(
        MailCodec.quotedPrintable.encodeText(input),
        'Hello W=C3=B6rld. This is a long text without linebreak and this '
        'contains t=\r\nhe formula c^2=3Da^2+b^2.',
      );
      // counter test:
      expect(
        MailCodec.quotedPrintable.decodeText(
          'Hello W=C3=B6rld. This is a long text without linebreak and '
          'this contains t=\r\nhe formula c^2=3Da^2+b^2.',
          convert.utf8,
        ),
        'Hello Wörld. This is a long text without linebreak and this '
        'contains the formula c^2=a^2+b^2.',
      );
    });

    test(r'encodeText.quoted-printable \r\n line breaks', () {
      const input =
          'Hello Wörld.\r\nThis is a long text with\r\na linebreak and this '
          'contains the formula c^2=a^2+b^2.';
      expect(
        MailCodec.quotedPrintable.encodeText(input),
        'Hello W=C3=B6rld.\r\nThis is a long text with\r\na linebreak and '
        'this contains the formula c^2=3Da^2+b^2.',
      );
      // counter test:
      expect(
        MailCodec.quotedPrintable.decodeText(
          MailCodec.quotedPrintable.encodeText(input),
          convert.utf8,
        ),
        input,
      );
    });

    test(r'encodeText.quoted-printable \n line breaks', () {
      const input =
          'Hello Wörld.\nThis is a long text with\na linebreak and this '
          'contains the formula c^2=a^2+b^2.';
      expect(
        MailCodec.quotedPrintable.encodeText(input),
        'Hello W=C3=B6rld.\r\nThis is a long text with\r\na linebreak and '
        'this contains the formula c^2=3Da^2+b^2.',
      );
    });
  });

  group('Q Encoding', () {
    group(
      'Decode examples from https://tools.ietf.org/html/rfc2047#section-8',
      () {
        test('Decode space', () {
          const input = 'Keith_Moore';
          expect(
            MailCodec.quotedPrintable.decodeText(
              input,
              convert.utf8,
              isHeader: true,
            ),
            'Keith Moore',
          );
        });

        test('Remove space between 2 encoded words', () {
          const input =
              '=?UTF-8?Q?=E5=9B=9E=E5=A4=8D=EF=BC=9ARe:_Nutzer-Anfrage_zu_dei'
              'ner_A?= =?UTF-8?Q?nzeige_\"Brotbackmaschine_WK84300\"?=';
          expect(
            MailCodec.decodeHeader(input),
            '回复：Re: Nutzer-Anfrage zu deiner Anzeige "Brotbackmaschine'
            ' WK84300"',
          );
        });
      },
    );
    group(
      'Encode examples from https://tools.ietf.org/html/rfc2047#section-8',
      () {
        test('Encode space only when required', () {
          const input = 'Keith Moore';
          expect(MailCodec.quotedPrintable.encodeHeader(input), 'Keith Moore');
        });
      },
    );
  });

  // decodeData is the attachment path: no charset, just the bytes. It used to
  // return `part.codeUnits` undecoded, and MailCodec.decodeBinary had no
  // quoted-printable entry to route here at all, so a quoted-printable
  // attachment was saved as its own source text: `=25PDF=2D1=2E7` where the
  // caller asked for `%PDF-1.7`.
  group('Quoted Printable binary decoding', () {
    test('decodes hex escapes to bytes', () {
      expect(MailCodec.quotedPrintable.decodeData('=25PDF=2D1=2E7'), <int>[
        0x25,
        0x50,
        0x44,
        0x46,
        0x2D,
        0x31,
        0x2E,
        0x37,
      ]);
    });

    test('keeps bytes above 0x7F that a charset decode would mangle', () {
      expect(MailCodec.quotedPrintable.decodeData('=FF=FE=00'), <int>[
        0xFF,
        0xFE,
        0x00,
      ]);
    });

    test('drops soft line breaks', () {
      expect(MailCodec.quotedPrintable.decodeData('ab=\r\ncd'), <int>[
        0x61,
        0x62,
        0x63,
        0x64,
      ]);
    });

    test('passes literal characters through', () {
      expect(MailCodec.quotedPrintable.decodeData('a b'), <int>[
        0x61,
        0x20,
        0x62,
      ]);
    });

    test('leaves an invalid escape alone rather than dropping data', () {
      expect(MailCodec.quotedPrintable.decodeData('=ZZ'), <int>[
        0x3D,
        0x5A,
        0x5A,
      ]);
    });

    test('a trailing = has no hex digits to consume', () {
      expect(MailCodec.quotedPrintable.decodeData('ab='), <int>[
        0x61,
        0x62,
        0x3D,
      ]);
    });

    test('decodeBinary routes quoted-printable here', () {
      expect(MailCodec.decodeBinary('=25PDF', 'quoted-printable'), <int>[
        0x25,
        0x50,
        0x44,
        0x46,
      ]);
      expect(MailCodec.decodeBinary('=25PDF', 'Q'), <int>[
        0x25,
        0x50,
        0x44,
        0x46,
      ]);
    });

    test('decodeBinary knows 7bit, which it used to fall through on', () {
      expect(MailCodec.decodeBinary('plain', '7bit'), <int>[
        0x70,
        0x6C,
        0x61,
        0x69,
        0x6E,
      ]);
    });
  });

  group('malformed truncated =XY escapes are preserved verbatim', () {
    // Regression: a '=' within two characters of the end used to throw
    // RangeError from substring(i+1, i+3). Per RFC 2045 §6.7 consumers may
    // preserve the malformed tail; matches the existing behaviour for
    // non-hex '=XY' where the raw text is written to the buffer.
    test('trailing bare "="', () {
      expect(
        MailCodec.quotedPrintable.decodeText('hello=', convert.utf8),
        'hello=',
      );
    });
    test('trailing "=A"', () {
      expect(
        MailCodec.quotedPrintable.decodeText('hello=A', convert.utf8),
        'hello=A',
      );
    });
    test('lone "=A" at end of a short input', () {
      expect(MailCodec.quotedPrintable.decodeText('h=A', convert.utf8), 'h=A');
    });
    test('valid multi-byte escape followed by truncated "=A"', () {
      expect(
        MailCodec.quotedPrintable.decodeText('hi=C3=B6=A', convert.utf8),
        'hiö=A',
      );
    });
  });
}
