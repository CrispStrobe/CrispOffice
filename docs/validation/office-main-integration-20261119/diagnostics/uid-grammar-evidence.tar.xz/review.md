# Raw FETCH UID grammar review

The focused pre-fix run reproduced six malformed UID acceptances. Its eight existing raw-FETCH controls passed. The identical fourteen tests all passed after the proposed seven-line parsing guard. Neither run changed its recorded source, package configuration, test, launcher, or Dart executable inputs.

## Authoritative grammar

RFC 3501 section 9 defines the UID attribute through uniqueid and nz-number: the first character is a digit from 1 through 9, followed by zero or more decimal digits, within the unsigned 32-bit nonzero range. Hexadecimal notation, a leading plus sign, and leading zeros therefore do not satisfy the wire grammar. The patch enforces the decimal spelling before integer conversion and retains the existing range and AST checks.

Primary source: https://www.rfc-editor.org/rfc/rfc3501.html#section-9

## Scope and source provenance

The explicit source overlay came from Git merge tree b6ba367a9bdcf1ffc2bde1ba9f738f760c9dfcdf, incorporating strict FETCH-root checks, strict repeated-list rejection, and the incoming unsolicited-flags/status handling. The entire tracked vendored source tree used by the pre-fix run is included under before-source. The only product source delta in the green run is the supplied raw_fetch_parser.dart guard. The test file adds six cases to the existing eight; each malformed spelling is exercised both as a complete literal UID and as a later flags-only notification.

The two package configurations explicitly redirect only enough_mail to the corresponding isolated source copy. All other package root URIs are the resolved original paths. This overlay is named in the receipts and is not presented as a final integrated-workspace qualification. The verified Dart runtime and dependency archive provenance are retained separately in the continuation's runtime evidence; executables and hosted dependency bytes are not duplicated here.

Each receipt includes the complete command array, cwd, every vendored source-file hash, effective package configuration, test entry, package:test launcher, Dart executable, before/after comparison, termination status, and timestamps. stdout.jsonl and stderr.log preserve the raw process evidence. summary.json reconstructs user-case outcomes without hidden loading events.

## Application

Apply uid-decimal.patch to the combined checkout after preserving the prior qualification. Then commit/freeze that source and rerun the integrated affected-source gate. The isolated green run establishes the focused repair and does not replace the final combined qualification.

## Deferred review observation

The incoming status filter treats BYE and PREAUTH as generic statuses and says closure is handled by the client. A static review found no BYE-specific handler in ImapClient.onUntaggedResponse; that path logs unhandled responses. No closure regression was authored or run in this task. This observation is outside the UID patch and is not claimed as a reproduced false commit.
