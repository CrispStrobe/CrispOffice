import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'after/third_party/enough_mail/lib/src/private/util/client_connection.dart';

void check(bool condition, String message) {
  if (!condition) throw StateError(message);
}

bool rejectsState(void Function() action) {
  try { action(); } on StateError { return true; }
  return false;
}

Future<void> main() async {
  {
    final raw = _PartialRawSocket();
    final connection = RawClientConnection(raw);
    final listening = Completer<void>();
    final producer = StreamController<List<int>>(onListen: listening.complete);
    connection.write('before:');
    final added = connection.addStream(producer.stream);
    check(rejectsState(() => connection.write('interleaved')), 'write interleaved active producer');
    check(rejectsState(() => connection.addStream(const Stream.empty())), 'overlapping stream admitted');
    await listening.future;
    producer.add(utf8.encode('one'));
    producer.add(utf8.encode(':two'));
    final closing = connection.close();
    await producer.close();
    await added;
    await closing;
    check(utf8.decode(raw.bytes) == 'before:one:two', 'ordered stream bytes changed');
    check(raw.writeClosed && !raw.closedBeforeReady, 'write closed before final readiness');
    connection.destroy();
    print('PASS ordered producer, conflicting writers rejected, close waits for final readiness');
  }
  {
    final raw = _PartialRawSocket();
    final connection = RawClientConnection(raw);
    final listening = Completer<void>();
    final cancelled = Completer<void>();
    final cleanup = Completer<void>();
    final producer = StreamController<List<int>>(
      onListen: listening.complete,
      onCancel: () { cancelled.complete(); return cleanup.future; },
    );
    final outcome = connection.addStream(producer.stream).then<Object?>((_) => null, onError: (Object error) => error);
    await listening.future;
    connection.destroy();
    await cancelled.future;
    final error = await outcome.timeout(const Duration(seconds: 1));
    check(error is SocketException, 'idle producer abort did not reject with SocketException');
    check(!cleanup.isCompleted, 'probe accidentally released cancellation cleanup');
    cleanup.complete();
    await producer.close();
    print('PASS idle producer abort settles before delayed cancellation cleanup');
  }
  {
    final raw = _PartialRawSocket()..releaseReadiness = false;
    final connection = RawClientConnection(raw);
    final outcome = connection.addStream(Stream.fromIterable([List<int>.filled(100, 42)])).then<Object?>((_) => null, onError: (Object error) => error);
    await raw.firstWrite.future;
    connection.destroy();
    final error = await outcome.timeout(const Duration(seconds: 1));
    check(error is SocketException && raw.destroyed, 'blocked producer write did not reject on abort');
    print('PASS abort rejects an active producer blocked on socket readiness');
  }
}

final class _PartialRawSocket extends Stream<RawSocketEvent>
    implements RawSocket {
  final _events = StreamController<RawSocketEvent>();
  final List<int> bytes = [];
  final Completer<void> firstWrite = Completer<void>();
  int writes = 0;
  int readinessEvents = 0;
  bool releaseReadiness = true;
  bool writeClosed = false;
  bool closedBeforeReady = false;
  bool destroyed = false;
  bool _pendingWrite = false;

  @override
  bool readEventsEnabled = false;
  @override
  bool get writeEventsEnabled => false;
  @override
  set writeEventsEnabled(bool value) {
    if (value && releaseReadiness) {
      scheduleMicrotask(() {
        if (!destroyed) {
          _pendingWrite = false;
          readinessEvents++;
          _events.add(RawSocketEvent.write);
        }
      });
    }
  }

  @override
  int write(List<int> buffer, [int offset = 0, int? count]) {
    writes++;
    _pendingWrite = true;
    final available = count ?? buffer.length - offset;
    final length = available < 3 ? available : 3;
    bytes.addAll(buffer.sublist(offset, offset + length));
    if (!firstWrite.isCompleted) firstWrite.complete();
    return length;
  }

  @override
  Uint8List? read([int? length]) => null;
  @override
  void shutdown(SocketDirection direction) {
    if (direction == SocketDirection.send ||
        direction == SocketDirection.both) {
      writeClosed = true;
      closedBeforeReady = _pendingWrite;
    }
  }

  @override
  Future<RawSocket> close() async {
    destroyed = true;
    await _events.close();
    return this;
  }

  @override
  StreamSubscription<RawSocketEvent> listen(
    void Function(RawSocketEvent)? onData, {
    Function? onError,
    void Function()? onDone,
    bool? cancelOnError,
  }) => _events.stream.listen(
    onData,
    onError: onError,
    onDone: onDone,
    cancelOnError: cancelOnError,
  );

  @override
  dynamic noSuchMethod(Invocation invocation) =>
      throw UnsupportedError('Not used by the partial-write fixture');
}
