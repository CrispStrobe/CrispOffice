# Updated Socket facade review

Reviewed incoming source: `022a974a96db23e22bc161f7d465e4b972e8c2a9`.

Adopt its Socket-compatible facade. It now retains the original TCP owner through established TLS, closes TCP before waiting on secure output, races direct connection/upgrade calls against a per-generation abort signal, rejects late results, preserves secure metadata, and supports cancellable stream producers. The deterministic raw-write controls target the selected production adapter.

The physical cancellation guarantee applies to the default owned raw transport. A manually supplied ordinary SDK Socket can be detached by SecureSocket.secure while its handshake is pending; the generation/abort race settles the caller and destroys a future late result, but cannot immediately close an inaccessible detached TCP owner. Incoming merge-review.md explicitly scopes this limitation. No alternate architecture is introduced here.

One narrow regression was reproduced: removing the earlier generation-guarded catch/abort from upgradeToSslSocket left a direct client marked connected after a handshake rejection. The native provider already aborts in finally; direct library clients did not receive that cleanup. The patch restores it and adds disconnected/unauthenticated assertions to the existing implicit-TLS and STARTTLS default-trust tests before their finally cleanup. Case counts do not change.

The standalone probe invokes the real incoming ClientBase with a controlled TLS-factory HandshakeException. Before the patch it reports connected=true and destroyed=false (exit 1). After the patch it preserves HandshakeException and reports connected=false and destroyed=true (exit 0). This proves cleanup and exception propagation at the rejected-future boundary; it is not a live TLS qualification. Existing real TLS tests must run on the final integrated source.
