import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'green-source/client_base.dart';

final class ProbeClient extends ClientBase {
  @override
  Future<Socket> createSecureConnectionSocket(Socket socket, {required String host}) => Future.error(const HandshakeException('controlled TLS rejection'));
  @override
  void onDataReceived(Uint8List data) {}
  @override
  void onConnectionEstablished(ConnectionInfo info, String greeting) {}
  @override
  void onConnectionError(dynamic error) {}
  @override
  Exception createClientError(String message) => StateErrorException(message);
}
final class StateErrorException implements Exception {
  StateErrorException(this.message);
  final String message;
}
final class ProbeSocket extends Stream<Uint8List> implements Socket {
  final events = StreamController<Uint8List>();
  bool destroyed = false;
  @override
  void destroy() { destroyed = true; }
  @override
  StreamSubscription<Uint8List> listen(void Function(Uint8List)? onData, {Function? onError, void Function()? onDone, bool? cancelOnError}) => events.stream.listen(onData, onError:onError,onDone:onDone,cancelOnError:cancelOnError);
  @override
  dynamic noSuchMethod(Invocation invocation) => throw UnsupportedError('Unused probe member');
}
Future<void> main() async {
  final socket = ProbeSocket();
  final client = ProbeClient()..connect(socket, connectionInformation: const ConnectionInfo('loopback-test', 143, isSecure:false));
  Object? error;
  try { await client.upgradeToSslSocket(); } catch (caught) { error=caught; }
  print('exception=${error.runtimeType} isConnected=${client.isConnected} destroyed=${socket.destroyed}');
  final cleaned = error is HandshakeException && !client.isConnected && socket.destroyed;
  await client.abort();
  await socket.events.close();
  if (!cleaned) exitCode=1;
}
