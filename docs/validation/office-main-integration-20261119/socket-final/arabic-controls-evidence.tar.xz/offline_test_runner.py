import importlib.util
import json
from pathlib import Path
import socket
import sys
import tempfile
import unittest
import urllib.request
from unittest.mock import patch

root = Path(__file__).parent
(root / "tmp").mkdir(exist_ok=True)
# All test-created files are temporary scratch fixtures, outside the repository.
tempfile.tempdir = str(root / "tmp")

def forbidden(*args, **kwargs):
    raise AssertionError("Offline qualification attempted network access")

with (
    patch.object(urllib.request, "urlopen", side_effect=forbidden),
    patch.object(socket, "create_connection", side_effect=forbidden),
    patch.object(socket.socket, "connect", side_effect=forbidden),
):
    spec = importlib.util.spec_from_file_location(
        "combined_ayaspell_controls", root / "selected/test_build_bundle.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    suite = unittest.defaultTestLoader.loadTestsFromModule(module)
    def case_ids(group):
        for entry in group:
            if isinstance(entry, unittest.TestSuite):
                yield from case_ids(entry)
            else:
                yield entry.id()
    cases = list(case_ids(suite))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    summary = {
        "tests_run": result.testsRun,
        "case_ids": cases,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "successful": result.wasSuccessful(),
        "network_policy": "urlopen, socket.create_connection and socket.connect fail on invocation",
        "publication": "mock HfApi only; no remote calls or credentials",
    }
    (root / "offline-controls-result.json").write_text(json.dumps(summary, indent=2) + "\n")
    sys.exit(0 if result.wasSuccessful() else 1)
