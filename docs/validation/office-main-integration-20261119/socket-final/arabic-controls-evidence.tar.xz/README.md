# Combined Arabic bundle controls

Select PR #178 builder `0b8f8f7f78fbf4e2e26671ecf9a0d858c38ca75c` unchanged. It keeps the published Hugging Face card metadata and constrains uploads to exact verified payload names plus the manifest. `combined-offline-controls.patch` applies only to its test file, merging complementary PR #177 assertions.

Seven independent unittest cases pass with zero failures, errors or skips. They cover a deterministic local build across all six upstream-name fixtures; explicit no-publish behavior; exact upload allowlist and exclusion/preservation of unrelated and nested files; source size, source hash and licence hash failures before remote mutation; payload and manifest readback mismatch; and card metadata/planned integration.

Run `python3 -B offline_test_runner.py` from this extracted directory. Downloads and Hub methods are replaced with synthetic fixtures/mocks; urllib and socket connection entry points fail if invoked. Temporary outputs stay in `tmp/`. This does not perform a real publication or validate external upstream/licence/linguistic claims. The tested source, runner, raw log and before/after hashes are retained.
