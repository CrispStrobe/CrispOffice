#!/usr/bin/env python3
"""Expose the verified Notes restore evidence in run_targeted's receipt schema."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/scratch/a7846890f2e1')
RUNTIME = BASE / 'runtime-recovery/toolchains'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

original = RUNTIME / 'isolated-restore-runtime.json'
restore = json.loads(original.read_text())
current_path = RUNTIME / 'runtime.json'
current = json.loads(current_path.read_text())
assert restore['status'] == current['status'] == 'ready'
assert restore['archive']['verified'] is True
assert current['archive'] == restore['archive']
assert current['executables_sha256'] == restore['executables_sha256']
before = RUNTIME / 'runtime-before-targeted-adapter.json'
assert not before.exists()
before.write_bytes(current_path.read_bytes())
sdk = {
    'schema': 'derived-notes-runtime-sdk-receipt-v1',
    'scope': 'Schema adapter for run_targeted; all archive/executable values copied from the successfully executed original restoration receipt',
    'derived_from': {'path': str(original), 'sha256': digest(original)},
    'archive': restore['archive'],
    'executables_sha256': restore['executables_sha256'],
    'archive_members': {'path': str(RUNTIME / 'archive-members.json'),
                        'sha256': digest(RUNTIME / 'archive-members.json')},
    'selection': restore['selection'],
    'source_restore_finished_utc': restore['finished_at_utc'],
}
sdk_path = RUNTIME / 'sdk-receipt.json'
assert not sdk_path.exists()
sdk_path.write_text(json.dumps(sdk, indent=2) + '\n')
lock_sha = digest(BASE / 'quds_office_suite/pubspec.lock')
assert lock_sha == restore['workspace_lock_sha256'] == current['integrated_setup']['workspace_lock_sha256']
current['sdk_receipt_sha256'] = digest(sdk_path)
current['pub_cache_receipt_sha256'] = digest(RUNTIME / 'pub-cache-receipt.json')
current['lock_sha256_after'] = lock_sha
current['runner_receipt_adapter'] = {
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'implementation_sha256': digest(Path(__file__)),
    'before_receipt': str(before), 'before_receipt_sha256': digest(before),
    'scope': 'Added hash links and lock identity required by run_targeted; original download and rebinding observations remain intact',
}
current_path.write_text(json.dumps(current, indent=2) + '\n')
print(json.dumps({'status': 'ready', 'sdk_receipt_sha256': current['sdk_receipt_sha256'],
                  'pub_cache_receipt_sha256': current['pub_cache_receipt_sha256'],
                  'lock_sha256_after': lock_sha}, indent=2))
