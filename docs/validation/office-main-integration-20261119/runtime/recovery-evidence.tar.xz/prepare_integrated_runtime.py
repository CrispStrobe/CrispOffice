#!/usr/bin/env python3
"""Bind an already verified isolated runtime to the final integrated checkout.

Only ignored dependency/native hook output is written in the repository.
Original restoration provenance is retained byte-for-byte as a separate receipt.
"""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

BASE = Path('/workspace/scratch/a7846890f2e1')
REPO = BASE / 'quds_office_suite'
RECOVERY = BASE / 'runtime-recovery'
RUNTIME = RECOVERY / 'toolchains'
HELPER = RECOVERY / 'runtime-source/docs/validation/document-review-notes-20261118/runtime/restore_runtime.py'

spec = importlib.util.spec_from_file_location('verified_runtime_restore', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=REPO)

def main():
    original_path = RUNTIME / 'isolated-restore-runtime.json'
    if original_path.exists():
        raise RuntimeError('Preserve the existing original receipt; this setup is one-shot')
    original = (RUNTIME / 'runtime.json').read_bytes()
    receipt = json.loads(original)
    if receipt['status'] != 'ready':
        raise RuntimeError('The original isolated runtime is not ready')
    original_path.write_bytes(original)
    before_diff = git('diff', 'HEAD', '--binary')
    before_lock = digest(REPO / 'pubspec.lock')
    if before_lock != helper.LOCK_SHA256:
        raise RuntimeError('Integrated checkout lock differs from verified runtime')
    evidence = {
        'started_at_utc': datetime.now(timezone.utc).isoformat(),
        'target_source_commit': git('rev-parse', 'HEAD').decode().strip(),
        'target_source': str(REPO),
        'original_source': receipt['source'],
        'original_receipt': str(original_path),
        'original_receipt_sha256': digest(original_path),
        'helper_sha256': digest(HELPER),
        'implementation_sha256': digest(Path(__file__)),
        'workspace_lock_sha256': before_lock,
        'status': 'preparing',
        'runs': [],
        'scope': 'Fresh offline lock enforcement and genuine native hook output for integrated source; original SDK and package restoration unchanged',
    }
    output = RECOVERY / 'integrated-setup.json'
    def save():
        output.write_text(json.dumps(evidence, indent=2) + '\n')
    save()
    env = dict(os.environ, PUB_CACHE=str(RUNTIME / 'pub-cache'),
               FLUTTER_ROOT=str(RUNTIME / 'flutter'), CI='true',
               DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true',
               DASH__SUPPRESS_ANALYTICS='true', XDG_CONFIG_HOME=str(RUNTIME / 'config'),
               XDG_CACHE_HOME=str(RUNTIME / 'cache'), XDG_DATA_HOME=str(RUNTIME / 'data'),
               TMPDIR=str(RUNTIME / 'tmp'))
    env['PATH'] = str(RUNTIME / 'bin') + os.pathsep + env.get('PATH', '')
    dart = RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'
    logs = RECOVERY / 'integrated-setup-logs'
    logs.mkdir()
    def run(name, command, cwd):
        path = logs / (name + '.log')
        print('START ' + name, flush=True)
        with path.open('wb') as stream:
            result = subprocess.run([str(x) for x in command], cwd=cwd, env=env,
                                    stdout=stream, stderr=subprocess.STDOUT, timeout=300)
        evidence['runs'].append({'name': name, 'command': [str(x) for x in command],
                                 'cwd': str(cwd), 'exit_code': result.returncode,
                                 'log': str(path), 'log_sha256': digest(path)})
        save()
        if result.returncode:
            raise RuntimeError(name + ' failed: ' + path.read_text(errors='replace')[-8000:])
    try:
        run('integrated-workspace-pub-get', [dart, 'pub', 'get', '--offline', '--enforce-lockfile'], REPO)
        with helper.native_smoke_entrypoint(REPO) as entrypoint:
            source = REPO / 'docs/validation/document-review-notes-20261118/runtime/native_asset_smoke.dart'
            evidence['native_smoke'] = {
                'source': str(source), 'source_sha256': digest(source),
                'entrypoint': str(entrypoint), 'entrypoint_sha256': digest(entrypoint),
                'owning_package': 'quds_mail_store',
                'cleanup': 'Only the generated temporary entrypoint directory is removed',
            }
            run('integrated-native-assets-smoke', [dart, 'run', entrypoint], REPO / 'packages/quds_mail_store')
        helper.bind_test_inputs(REPO, RUNTIME, receipt, node_tests=True)
        evidence['tracked_source_unchanged'] = git('diff', 'HEAD', '--binary') == before_diff
        evidence['lock_unchanged'] = digest(REPO / 'pubspec.lock') == before_lock
        if not evidence['tracked_source_unchanged'] or not evidence['lock_unchanged']:
            raise RuntimeError('Tracked repository inputs changed during generated-only setup')
        evidence['workspace_package_count'] = len(json.loads((REPO / '.dart_tool/package_config.json').read_text())['packages'])
        if evidence['workspace_package_count'] != 130:
            raise RuntimeError('Unexpected package graph count')
        evidence['status'] = 'ready'
        receipt['source'] = str(REPO)
        receipt['integrated_setup'] = evidence.copy()
        receipt['native_smoke'] = evidence['native_smoke']
        receipt['status'] = 'ready'
        (RUNTIME / 'runtime.json').write_text(json.dumps(receipt, indent=2) + '\n')
    except BaseException as error:
        evidence['status'] = 'failed'
        evidence['error'] = repr(error)
        raise
    finally:
        evidence['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
        save()

if __name__ == '__main__':
    main()
