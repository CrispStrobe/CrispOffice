import datetime,hashlib,json,os,shutil,signal,subprocess,tempfile,time
from pathlib import Path
ROOT=Path('/workspace/scratch/d3ee9898a61b/quds_office_suite')
RUNTIME=ROOT.parent/'runtime'
EDITOR=ROOT/'packages/quds_office_editor'
HARNESS=EDITOR/'tool/zotero/research_target_acceptance.dart'
STEM=RUNTIME/'editor-acceptance-integrated'
SUITES=[
 'test/word_zotero_add_note_controller_test.dart',
 'test/word_zotero_note_target_test.dart',
 'test/word_zotero_note_image_controller_test.dart',
 'test/word_zotero_citing_controller_test.dart',
 'test/word_zotero_citing_dialog_test.dart',
 'test/word_zotero_direct_command_test.dart',
 'test/word_zotero_bibliography_controller_test.dart',
 'test/word_zotero_rich_controller_test.dart',
 'test/word_proofing_session_test.dart',
 'test/word_proofing_capture_cache_test.dart',
 'example/test/studio_comment_draft_proofing_test.dart',
]
SOURCES=set([HARNESS,ROOT/'pubspec.yaml',ROOT/'pubspec.lock'])
for package in (ROOT/'packages').iterdir():
 if not package.is_dir():continue
 SOURCES.update((package/'lib').rglob('*.dart'))
 if (package/'pubspec.yaml').exists():SOURCES.add(package/'pubspec.yaml')
SOURCES.update((EDITOR/'example/lib').rglob('*.dart'))
SOURCES.add(EDITOR/'example/pubspec.yaml')
SOURCES.update((ROOT/'third_party/enough_mail/lib').rglob('*.dart'))
SOURCES.add(ROOT/'third_party/enough_mail/pubspec.yaml')
SOURCES.update(EDITOR/path for path in SUITES)
for asset in ['fonts','assets','templates','example/fonts','example/assets']:
 SOURCES.update(p for p in (EDITOR/asset).rglob('*') if p.is_file())
SOURCES=sorted(SOURCES)
CONFIGS=[RUNTIME/'package_config.json',RUNTIME/'package_graph.json',RUNTIME/'flutter/packages/flutter_tools/.dart_tool/package_config.json']
CACHE_DIRS=[ROOT/'.dart_tool',EDITOR/'.dart_tool',EDITOR/'build',EDITOR/'example/.dart_tool',RUNTIME/'.dart_tool']
CACHE_BEFORE={root:set(root.rglob('*')) if root.exists() else set() for root in CACHE_DIRS}
CACHE_EXISTED={root:root.exists() for root in CACHE_DIRS}
temporary=Path(tempfile.mkdtemp(prefix='zotero-editor-',dir=RUNTIME/'tmp'))
env=dict(os.environ,TMPDIR=str(temporary))
command=['flutter','test','--no-pub','--test-assets','--reporter=json','--concurrency=1',str(HARNESS.relative_to(EDITOR))]
def timestamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes(paths,base):return {str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
receipt={
 'started_utc':timestamp(),'cwd':str(EDITOR),'command':command,
 'temporary_directory':str(temporary),'suite_files':SUITES,
 'dart_version':subprocess.check_output(['dart','--version'],text=True,stderr=subprocess.STDOUT).strip(),
 'git_head_at_start':git('rev-parse','HEAD'),'git_tree_at_start':git('rev-parse','HEAD^{tree}'),
 'free_bytes_before':shutil.disk_usage(RUNTIME).free,
 'source_and_asset_sha256_before':hashes(SOURCES,ROOT),
 'configuration_sha256_before':hashes(CONFIGS,RUNTIME),
 'native_hooks_restored':json.loads((RUNTIME/'native-hook-restore-receipt.json').read_text()),
 'runtime_scope':'Official hash-verified sparse Flutter 3.47.8/Dart 3.13.7; real project assets, real locked package code and native hooks; normal test asset bundle and native-asset build enabled; no package implementations or assets stubbed.',
 'state':'running',
}
manifest=Path(str(STEM)+'.receipt.json')
manifest.write_text(json.dumps(receipt,indent=2)+'\n')
process=None;returncode=255

def interrupt(signum,frame):raise KeyboardInterrupt('Signal '+str(signum))
signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt)
try:
 with Path(str(STEM)+'.jsonl').open('w') as stdout,Path(str(STEM)+'.stderr.log').open('w') as stderr:
  process=subprocess.Popen(command,cwd=EDITOR,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  print(json.dumps({'state':'started','pid':process.pid,'sources_and_assets_hashed':len(SOURCES),'temporary_directory':str(temporary)}),flush=True)
  started=time.monotonic()
  while process.poll() is None:
   if shutil.disk_usage(RUNTIME).free<96*1024**2:raise RuntimeError('Stopped before filesystem exhaustion: below 96 MiB reserve')
   if time.monotonic()-started>600:raise RuntimeError('Editor cohort exceeded 10 minute bounded runtime')
   time.sleep(1)
  returncode=process.returncode
except BaseException as error:receipt['exception']=repr(error)
finally:
 if process is not None and process.poll() is None:
  os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
 shutil.rmtree(temporary,ignore_errors=True)
 removed=[]
 for cache in CACHE_DIRS:
  if not cache.exists():continue
  for path in sorted(set(cache.rglob('*'))-CACHE_BEFORE[cache],key=lambda v:len(v.parts),reverse=True):
   if path.is_file() or path.is_symlink():path.unlink();removed.append(str(path))
   elif path.is_dir():path.rmdir()
  if not CACHE_EXISTED[cache]:cache.rmdir()
 receipt.update({
  'finished_utc':timestamp(),'returncode':returncode,
  'source_and_asset_sha256_after':hashes(SOURCES,ROOT),
  'configuration_sha256_after':hashes(CONFIGS,RUNTIME),
  'removed_new_build_and_test_files':removed,
  'temporary_directory_removed':not temporary.exists(),
  'free_bytes_after':shutil.disk_usage(RUNTIME).free,
  'git_tree_at_end':git('rev-parse','HEAD^{tree}'),
  'state':'completed' if returncode==0 else 'failed',
 })
 receipt['source_and_asset_hashes_unchanged']=receipt['source_and_asset_sha256_before']==receipt['source_and_asset_sha256_after']
 receipt['configuration_hashes_unchanged']=receipt['configuration_sha256_before']==receipt['configuration_sha256_after']
 manifest.write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({key:receipt[key] for key in ['state','returncode','source_and_asset_hashes_unchanged','configuration_hashes_unchanged','temporary_directory_removed','free_bytes_after']}),flush=True)
raise SystemExit(returncode)
