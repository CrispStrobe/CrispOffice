// @dart = 3.12
// Bounded runtime selection: the ten unchanged editor suites.
// Run the original suites in one compilation to bound compiler-cache disk use.
// Each suite retains its own group, hooks, fixtures and test implementation.
// This entrypoint does not replace the original individually runnable tests.
import 'package:flutter_test/flutter_test.dart';

import '/workspace/scratch/d3ee9898a61b/quds_office_suite/packages/quds_office_editor/test/word_zotero_add_note_controller_test.dart' as suite0;
import '/workspace/scratch/d3ee9898a61b/quds_office_suite/packages/quds_office_editor/test/word_zotero_note_target_test.dart' as suite1;
import '/workspace/scratch/d3ee9898a61b/quds_office_suite/packages/quds_office_editor/test/word_zotero_note_image_controller_test.dart' as suite2;
import '/workspace/scratch/d3ee9898a61b/quds_office_suite/packages/quds_office_editor/test/word_zotero_citing_controller_test.dart' as suite3;
import '/workspace/scratch/d3ee9898a61b/quds_office_suite/packages/quds_office_editor/test/word_zotero_citing_dialog_test.dart' as suite4;
import '/workspace/scratch/d3ee9898a61b/quds_office_suite/packages/quds_office_editor/test/word_zotero_direct_command_test.dart' as suite5;
import '/workspace/scratch/d3ee9898a61b/quds_office_suite/packages/quds_office_editor/test/word_zotero_bibliography_controller_test.dart' as suite6;
import '/workspace/scratch/d3ee9898a61b/quds_office_suite/packages/quds_office_editor/test/word_zotero_rich_controller_test.dart' as suite7;
import '/workspace/scratch/d3ee9898a61b/quds_office_suite/packages/quds_office_editor/test/word_proofing_session_test.dart' as suite8;
import '/workspace/scratch/d3ee9898a61b/quds_office_suite/packages/quds_office_editor/test/word_proofing_capture_cache_test.dart' as suite9;

void main() {
  group('word_zotero_add_note_controller_test.dart', suite0.main);
  group('word_zotero_note_target_test.dart', suite1.main);
  group('word_zotero_note_image_controller_test.dart', suite2.main);
  group('word_zotero_citing_controller_test.dart', suite3.main);
  group('word_zotero_citing_dialog_test.dart', suite4.main);
  group('word_zotero_direct_command_test.dart', suite5.main);
  group('word_zotero_bibliography_controller_test.dart', suite6.main);
  group('word_zotero_rich_controller_test.dart', suite7.main);
  group('word_proofing_session_test.dart', suite8.main);
  group('word_proofing_capture_cache_test.dart', suite9.main);
}
