import 'dart:io';
import 'package:quds_office_engine/quds_office_engine.dart';

void main() {
  final document = WmlDocument(sections: [WmlSection(
    pageSize: const WmlPageSize(width: 600, height: 400),
    margins: const WmlPageMargins(top: 36, bottom: 36, left: 36, right: 36),
    blocks: [WmlParagraph(
      properties: WmlParagraphProps(
        headingLevel: 2, rightToLeft: true,
        justification: WmlJustification.right,
        lineSpacingRule: WmlLineSpacingRule.exact, lineSpacing: 18,
        spacingBefore: 6, spacingAfter: 5,
        indent: const WmlIndent(left: 30, right: 24),
      ),
      inlines: [WmlRun(text: 'HeadingFirst\nHeadingSecond')],
    )],
  )]);
  File('/workspace/scratch/167d435dbecc/consumer-heading-diagnostic-4fd/heading-control.odt').writeAsBytesSync(OdtDocumentWriter.writeBytes(document));
  File('/workspace/scratch/167d435dbecc/consumer-heading-diagnostic-4fd/heading-control-native.docx').writeAsBytesSync(WordSerializer().writeBytes(document));
}
