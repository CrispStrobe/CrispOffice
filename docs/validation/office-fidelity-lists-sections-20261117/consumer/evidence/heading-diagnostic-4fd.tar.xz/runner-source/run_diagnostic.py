from pathlib import Path
from lxml import etree
import datetime,gzip,hashlib,importlib.util,json,os,subprocess,zipfile
root=Path('/workspace/scratch/167d435dbecc')
repo=root/'quds_office_suite'
owned=repo/'docs/validation/office-fidelity-lists-sections-20261117/consumer'
out=root/'consumer-heading-diagnostic-4fd'
assert not out.exists()
out.mkdir(); (out/'logs').mkdir(); (out/'converted').mkdir(); (out/'runner-source').mkdir(); (out/'tmp').mkdir()
module_spec=importlib.util.spec_from_file_location('consumer',owned/'verify_consumers.py')
c=importlib.util.module_from_spec(module_spec); module_spec.loader.exec_module(c)
dart=Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/flutter-sdk/bin/cache/dart-sdk/bin/dart')
script=out/'runner-source/heading_control.dart'
script.write_text((root/'heading_control.dart').read_text().replace('/workspace/scratch/167d435dbecc/heading-control',str(out/'heading-control')))
(out/'runner-source/run_diagnostic.py').write_bytes(Path(__file__).read_bytes())
source=c.snapshot(c.source_inputs(repo)+[script,Path(__file__)])
runtime=c.snapshot(c.runtime_inputs(dart,root/'consumer-schemas',repo))
with gzip.GzipFile(filename=str(out/'inputs.json.gz'),mode='wb',mtime=0) as f:f.write(json.dumps({'source':source,'runtime':runtime},indent=2).encode())
receipt={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'started_at_utc':c.now(),'scope':'Diagnostic controls for inherited RTL indentation; not a passing qualification for physical WmlIndent fidelity.','commands':[]}
env=dict(os.environ,TMPDIR=str(out/'tmp'),DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true')
def run(argv,label):
 r=subprocess.run([str(a) for a in argv],env=env,cwd=repo,capture_output=True,timeout=60)
 (out/'logs'/f'{label}.stdout.log').write_bytes(r.stdout); (out/'logs'/f'{label}.stderr.log').write_bytes(r.stderr)
 receipt['commands'].append({'argv':[str(a) for a in argv],'label':label,'exit_code':r.returncode})
 assert r.returncode==0,(label,r.stderr)
run([dart,'--packages='+str(repo/'.dart_tool/package_config.json'),script],'generate')
with zipfile.ZipFile(out/'heading-control.odt') as src,zipfile.ZipFile(out/'heading-control-swapped-rtl-margins.odt','w') as dst:
 changes=[]
 for info in src.infolist():
  data=src.read(info.filename)
  if info.filename=='content.xml':
   old=b'fo:margin-left="30.00pt" fo:margin-right="24.00pt"'; new=b'fo:margin-left="24.00pt" fo:margin-right="30.00pt"'
   assert data.count(old)==1
   data=data.replace(old,new); changes.append({'part':info.filename,'from':old.decode(),'to':new.decode()})
  dst.writestr(info,data)
receipt['controlled_odt_mutation']=changes
inputs=[out/'heading-control.odt',out/'heading-control-native.docx',out/'heading-control-swapped-rtl-margins.odt']
run(['soffice','-env:UserInstallation='+(out/'profile-pdf').as_uri(),'--headless','--convert-to','pdf','--outdir',out/'converted',*inputs],'pdf')
receipt['words']={}
for path in inputs:
 pdf=out/'converted'/(path.stem+'.pdf'); bbox=out/'converted'/(path.stem+'.bbox.xhtml')
 run(['pdftotext','-bbox',pdf,bbox],path.stem+'-bbox')
 run(['pdftoppm','-singlefile','-r','96','-png',pdf,out/'converted'/path.stem],path.stem+'-raster')
 receipt['words'][path.name]=c.page_words(bbox)
with zipfile.ZipFile(out/'heading-control-native.docx') as z:(out/'native-document.xml').write_bytes(z.read('word/document.xml'))
receipt['findings']={'ordinary_odt_same_as_section':'Ordinary and section ODT headings have identical word coordinates: ODT inherited directional indentation mapping is independent of section activation.', 'physical_model_expectation_pt':600-36-24,'odf_rtl_start_expectation_pt':600-36-30,'native_docx_scope':'Native DOCX uses w:bidi, w:ind left=600/right=480 and w:jc=right. LibreOffice renders it left aligned; native DOCX does not establish physical right alignment for the ODT consumer.', 'comparison_changes_only':'The swapped control changes exactly fo:margin-left and fo:margin-right values in content.xml; no model/product code changed.'}
receipt['input_counts']={'source':len(source),'runtime':len(runtime)}
receipt['source_unchanged']=source==c.snapshot(c.source_inputs(repo)+[script,Path(__file__)])
receipt['runtime_unchanged']=runtime==c.snapshot(c.runtime_inputs(dart,root/'consumer-schemas',repo))
receipt['finished_at_utc']=c.now()
receipt['file_hashes']={str(p.relative_to(out)):c.digest(p) for p in out.rglob('*') if p.is_file() and not any(part.startswith('profile-') for part in p.relative_to(out).parts) and 'tmp' not in p.relative_to(out).parts}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['source_head','input_counts','source_unchanged','runtime_unchanged','findings']},indent=2))
