#!/usr/bin/env python3
"""Reconstruct every visible outcome from raw events; keep distinct receipts."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PATHS = ['gector-vm', 'engine-vm', 'corrected-source/engine-node', 'corrected-source/editor']

def main():
    cohorts = []
    total = Counter()
    for name in PATHS:
        folder = ROOT / name
        receipt = json.loads((folder / 'receipt.json').read_text())
        counts = Counter()
        suite_rows = []
        for command in receipt['commands']:
            if not command['name'].startswith('test-'):
                continue
            data = gzip.decompress((folder / command['stdout']).read_bytes())
            assert hashlib.sha256(data).hexdigest() == command['stdout_sha256']
            events = []
            for line in data.decode().split('\n'):
                try:
                    event = json.loads(line)
                except ValueError:
                    continue
                if isinstance(event, dict):
                    events.append(event)
            suites = {e['suite']['id']: e['suite'] for e in events if e.get('type') == 'suite'}
            starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
            per_suite = {identifier: Counter() for identifier in suites}
            names = {identifier: [] for identifier in suites}
            batch = Counter()
            for event in events:
                if event.get('type') != 'testDone' or event.get('hidden'):
                    continue
                start = starts[event['testID']]
                outcome = 'skipped' if event.get('skipped') else event['result']
                batch[outcome] += 1
                per_suite[start['suiteID']][outcome] += 1
                names[start['suiteID']].append({'name': start['name'], 'outcome': outcome})
            assert dict(batch) == command['summary']['outcomes']
            counts.update(batch)
            for identifier, suite in suites.items():
                suite_rows.append({'path': suite['path'], 'outcomes': dict(per_suite[identifier]),
                                   'tests': names[identifier]})
        assert len(suite_rows) == receipt['test_file_count']
        total.update(counts)
        cohorts.append({'name': name, 'receipt': str((folder / 'receipt.json').relative_to(ROOT)),
                        'source_commit': receipt['source_commit'], 'outcomes': dict(counts),
                        'test_file_count': len(suite_rows), 'suites': suite_rows,
                        'source_files': len(receipt['source_before']),
                        'runtime_files': receipt['runtime_before']['runtime_input_count'],
                        'source_unchanged': receipt['source_unchanged'],
                        'runtime_unchanged': receipt['runtime_unchanged'],
                        'lock_unchanged': receipt['lock_unchanged'],
                        'passed_with_recorded_scope': receipt['passed_with_recorded_scope']})
    result = {'cohorts': cohorts, 'dart_flutter_execution_outcomes': dict(total),
              'file_executions': sum(c['test_file_count'] for c in cohorts),
              'node_is_repetition': True,
              'engine_static_requalification': 'strict-requalification.json',
              'ancillary_python': {'reported_tests': 65, 'reported_skips': 0, 'receipt': 'python/receipt.json'},
              'claims': 'Bounded incoming-work coverage. Native inference fixture skipped. No GECToR JavaScript suite was run; its original tests import dart:io. Original engine VM receipt failed static gates before the isolated nonsemantic correction; passing test events retained with explicit strict requalification.'}
    (ROOT / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ['cohorts', 'claims']}, indent=2))

if __name__ == '__main__':
    main()
