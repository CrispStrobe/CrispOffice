# Incoming-work local qualification

This bounded run qualifies newly integrated proofing, annotation extraction and
editor manual-check behavior. It uses genuine Flutter **3.47.8**, Dart **3.13.7**,
and Node **24.22.1**. No GitHub Actions, checks or commit-status endpoints were
queried or awaited.

The initial source is published integration commit
`097475fbda96aa4a6497d92f28d10f1aa5f640b4`. The isolated strict-gate correction is
local commit `56dc162bf9a1003189e36e1f2a4678620c824546`; its complete two-file
patch is preserved in [strict-correction.patch](strict-correction.patch), so the
corrected source can be reconstructed from the published integration without
depending on that local commit's availability. These receipts have their own
source boundaries; later ODT implementation changes are qualified separately.

## Results

| Cohort | Passing cases | Explicit skips | Test files | Source |
| --- | ---: | ---: | ---: | --- |
| GECToR VM | 97 | 1 | 8 | Initial integration |
| Engine VM integration | 78 | 0 | 5 | Initial integration |
| Actual Flutter editor | 119 | 0 | 6 | Corrected source |
| JavaScript/Node engine repetitions | 49 | 0 | 3 | Corrected source |
| **Dart/Flutter executions** | **343** | **1** | **22 file executions** | |
| Ancillary Python checker tests | 65 | 0 | 2 modules | Initial integration |

The Node cohort repeats three engine files and does not add 49 unique test
cases. The VM/editor cohorts contain 294 passing cases in 19 files. GECToR's
skipped case requires four explicitly pinned native model/library fixture
variables; portable adapter guards do execute. This run does **not** qualify
native inference. All original GECToR tests import an I/O-based fixture helper
(and the worker suite also imports `dart:isolate`), so no GECToR JavaScript test
claim is made.

The editor cohort exercises manual-provider ownership and lifecycle, background
exclusion, explicit checks, cache separation, deterministic-finding precedence,
ordinary proofing sessions, context, corrections, dialogs and German integration.
Engine coverage includes the new lexicon query, ODF annotation suppression,
covered-cell suppression, note/comment interaction and search fidelity.

## Preserved failure and narrow requalification

The initial engine VM command ran all 78 cases successfully. Its strict static
gates then exposed two missing-brace lint findings in the incoming
`GermanSpellingProvider.isKnownWord` method and a formatter difference in one
incoming note regression. Its [original receipt](engine-vm/receipt.json)
therefore remains **failed**; its successful test events have not been rewritten.

The correction adds braces around the two existing throw statements and applies
the formatter's newline change to the test. Exact reversal controls reconstruct
both original files byte for byte. The subsequent Node cohort reruns strict
analysis and formatting for the affected source and test, then executes all 49
selected engine cases on the corrected source. The other original VM test files
are unchanged. [strict-requalification.json](strict-requalification.json)
records this composition explicitly. There is no claim of an uninterrupted
all-pass original engine run.

All other cohort static gates pass. The four cohorts retain unchanged source
inputs, runtime inputs, source HEAD and dependency lock throughout their own
execution windows. Receipts bind 1,667 source/input files for initial runs and
1,668 for corrected runs, including the correction launcher. Runtime manifests
bind 8,606 files initially and 8,607 when the compiled Flutter tool snapshot is
additionally bound for later cohorts. The GECToR VM test commands use Dart; the
actual Flutter editor run includes that compiled tool snapshot. Package source,
SDK executables/compiler inputs, engine artifacts, Flutter fallback fonts and
resolved dependency sources are included.

The Python receipt records source hashes before/after and the actual executable
identity. Its NumPy runtime manifest was captured **after** the successful run;
this is explicitly distinguished from the full before/after runtime binding of
the Dart/Flutter cohorts.

## Dependency setup

The preserved workspace lock is unchanged, SHA-256
`344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130`.
The first offline `--enforce-lockfile` attempt failed because the exact pinned
`url_launcher_android` 6.3.33 package was absent from the cache. The available
6.3.35 version was not adopted. After restoring the official 6.3.33 archive with
its lock-matching SHA-256, the same offline/enforced command passed.
[setup.json](setup.json) and [package-restoration.json](package-restoration.json)
retain both attempts and the exact package identity. This qualification makes
no manifest or lock changes; incoming package/workspace declarations were
already part of the integrated source.

## Evidence and reproduction

[summary.json](summary.json) contains per-file and per-test reconstructed
outcomes. [summarize.py](summarize.py) reads the preserved raw JSON events,
checks their hashes and reconstructs the visible counts independently of the
runner summaries. Hidden setup/teardown events are not counted as test cases.
Each cohort receipt also verifies suite coverage, unique event identities,
terminal completion, explicit skips and executable identity.

With the recorded runtime and enforced dependency lock activated, use
`run_cohort.py` at the initial integration for `gector-vm` and `engine-vm`, or
`run_corrected.py` at the corrected source for `engine-node` and `editor`.
Output directories must be new. Test commands use at most two workers and
three test files per batch. The original Python invocation was:

```sh
python3 -m unittest -v test_native_qualification test_guarded_provider_comparison
```

It ran from `tools/proofing/german_model`. These Python cases qualify the
checker/tooling controls; they do not execute a neural model.
