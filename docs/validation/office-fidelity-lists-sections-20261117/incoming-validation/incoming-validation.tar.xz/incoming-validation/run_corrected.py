#!/usr/bin/env python3
"""Run subsequent cohorts after the isolated, nonsemantic strict-gate fix."""
from pathlib import Path
import hashlib
import run_cohort as runner

runner.BASELINE = '56dc162bf9a1003189e36e1f2a4678620c824546'
runner.OUTPUT = Path(__file__).resolve().parent / 'corrected-source'
runner.OUTPUT.mkdir(exist_ok=True)
original_manifest = runner.source_manifest

def manifest():
    result = original_manifest()
    path = Path(__file__).resolve()
    result[str(path.relative_to(runner.REPO))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result

runner.source_manifest = manifest

if __name__ == '__main__':
    raise SystemExit(runner.main())
