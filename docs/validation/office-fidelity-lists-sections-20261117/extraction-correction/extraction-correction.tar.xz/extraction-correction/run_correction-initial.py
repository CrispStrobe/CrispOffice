#!/usr/bin/env python3
"""Qualify the paragraph-anchored ODF extraction correction locally."""
import gzip, hashlib, importlib.util, json, os, pathlib, shutil, subprocess, sys, time
ROOT = pathlib.Path('/workspace/scratch/167d435dbecc/extraction-fix')
OUT = pathlib.Path(__file__).resolve().parent
SOURCE = 'fa9821a7c9634a97aec6a8cf4d2617a926838934'
RUNTIME = pathlib.Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime')
spec=importlib.util.spec_from_file_location('qualification', ROOT/'docs/validation/office-fidelity-lists-sections-20261117/run_qualification.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
prior=module.prior
VM=['odf_text_box_extraction_test.dart','odf_export_text_fidelity_test.dart','odf_annotation_extraction_test.dart','odf_covered_cell_extraction_test.dart','office_search_fidelity_test.dart','odt_note_fidelity_test.dart']
NODE=['odf_text_box_extraction_test.dart','odf_annotation_extraction_test.dart','odf_covered_cell_extraction_test.dart']
cohort=sys.argv[1]
assert cohort in ['vm','node']
tests=VM if cohort=='vm' else NODE
output=OUT/cohort
output.mkdir(exist_ok=False)
env=os.environ.copy()
env.update(FLUTTER_ROOT=str(RUNTIME/'flutter-sdk'),PUB_CACHE=str(RUNTIME/'pub-cache'),CI='true',DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true',XDG_CONFIG_HOME=str(OUT/'config'),TMPDIR=str(OUT/'tmp'))
env['PATH']=str(RUNTIME/'flutter-sdk/bin')+os.pathsep+env['PATH']
os.environ.update(env)
package=ROOT/'packages/quds_office_engine'
dart=str(RUNTIME/'flutter-sdk/bin/dart')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert module.digest(ROOT/'pubspec.lock')==module.digest(module.LOCK)
versions=prior.version_identity(output,'flutter',include_node=True)
metadata=versions['flutter']['metadata']
assert metadata['frameworkVersion']=='3.47.8' and metadata['dartSdkVersion']=='3.13.7'
assert metadata['frameworkRevision']=='737ba8f885dc774b53b442759999a312c9461e4e'
receipt={'source_commit':SOURCE,'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),'cohort':cohort,'scope':'Shared ODF extraction/search helpers, public paragraph and table extraction, and adjacent note/annotation/covered-cell regressions. Node repeats three portable VM files.','github_actions':'Not queried or awaited.','driver_sha256':module.digest(pathlib.Path(__file__)),'started_utc':module.now(),'versions':versions,'tests':tests,'test_file_count':len(tests),'source_before':module.source_manifest(),'runtime_before':prior.runtime_identity(output/'runtime-before.json.gz',include_node=True),'lock_sha256':module.digest(module.LOCK),'environment':{k:env[k] for k in ['FLUTTER_ROOT','PUB_CACHE','CI','DART_SUPPRESS_ANALYTICS','FLUTTER_SUPPRESS_ANALYTICS','XDG_CONFIG_HOME','TMPDIR','PATH']},'commands':[]}
module.write_json(output/'receipt.json',receipt)
analysis=['lib/src/odf/odf_text.dart','lib/src/extract/office_text_extractor.dart','lib/src/extract/office_search_text.dart']+['test/'+t for t in tests]
commands=[('analyze',[dart,'analyze','--fatal-infos']+analysis,None),('format',[dart,'format','--output=none','--set-exit-if-changed']+analysis,None)]
for i in range(0,len(tests),3):
    batch=tests[i:i+3]
    commands.append(('test-'+str(i//3+1),[dart,'test']+(['--platform','node'] if cohort=='node' else [])+['--concurrency=2','--reporter=json']+['test/'+t for t in batch],batch))
for name,command,batch in commands:
    print(json.dumps({'cohort':cohort,'command':name,'status':'running'}),flush=True)
    started=time.monotonic()
    item={'name':name,'command':command,'cwd':str(package),'started_utc':module.now(),'executable_before_sha256':module.digest(pathlib.Path(command[0]))}
    stdout=output/(name+'.stdout')
    stderr=output/(name+'.stderr')
    with stdout.open('wb') as out,stderr.open('wb') as err:
        result=subprocess.run(command,cwd=package,env=env,stdout=out,stderr=err,timeout=600)
    raw=stdout.read_bytes()
    item.update(exit_code=result.returncode,finished_utc=module.now(),duration_seconds=time.monotonic()-started,executable_after_sha256=module.digest(pathlib.Path(command[0])))
    for channel,path in [('stdout',stdout),('stderr',stderr)]:
        data=path.read_bytes()
        (output/(path.name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
        item[channel]=path.name+'.gz'
        item[channel+'_sha256']=hashlib.sha256(data).hexdigest()
        path.unlink()
    if batch:
        item.update(tests=batch,summary=prior.summarize_events(raw),event_integrity=prior.event_integrity(raw,package,batch))
        summary=item['summary']
        item['passed_with_recorded_scope']=result.returncode==0 and item['event_integrity']['passed'] and summary['runner_success'] and not summary['failures'] and not summary['errors'] and not summary['skipped']
    else:
        item['passed_with_recorded_scope']=result.returncode==0
    receipt['commands'].append(item)
    module.write_json(output/'receipt.json',receipt)
    print(json.dumps({'cohort':cohort,'command':name,'exit_code':result.returncode,'summary':item.get('summary')}),flush=True)
receipt.update(finished_utc=module.now(),source_after=module.source_manifest(),runtime_after=prior.runtime_identity(output/'runtime-after.json.gz',include_node=True))
receipt['source_unchanged']=receipt['source_before']==receipt['source_after']
receipt['runtime_unchanged']=receipt['runtime_before']['files']==receipt['runtime_after']['files'] if isinstance(receipt['runtime_before'].get('files'),dict) else receipt['runtime_before']['manifest_sha256']==receipt['runtime_after']['manifest_sha256']
receipt['lock_unchanged']=module.digest(ROOT/'pubspec.lock')==receipt['lock_sha256']
receipt['passed_with_recorded_scope']=all(i['passed_with_recorded_scope'] for i in receipt['commands']) and receipt['source_unchanged'] and receipt['runtime_unchanged'] and receipt['lock_unchanged']
module.write_json(output/'receipt.json',receipt)
print(json.dumps({'cohort':cohort,'passed':receipt['passed_with_recorded_scope'],'source_unchanged':receipt['source_unchanged'],'runtime_unchanged':receipt['runtime_unchanged']}),flush=True)
sys.exit(0 if receipt['passed_with_recorded_scope'] else 1)
