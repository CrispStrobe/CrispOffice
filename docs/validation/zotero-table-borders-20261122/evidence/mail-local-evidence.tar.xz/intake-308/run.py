import datetime, hashlib, json, os, subprocess, sys
from pathlib import Path

root = Path('/workspace/scratch/c48dbdc53e0b/quds_office_suite')
out = Path(__file__).parent
example = root / 'packages/quds_office_editor/example'
names = [
  'studio_mail_account_navigation_test.dart',
  'studio_mail_account_navigation_native_test.dart',
  'studio_mail_account_navigation_native_release_test.dart',
  'studio_mail_account_navigation_provider_test.dart',
  'studio_mail_account_navigation_router_test.dart',
  'studio_mail_cached_host_test.dart',
  'studio_mail_lifecycle_test.dart',
  'studio_mail_presets_test.dart',
  'studio_mail_local_accounts_dialog_test.dart',
]
source = sorted([
  *example.glob('lib/studio_mail*.dart'),
  *example.glob('test/studio_mail*.dart'),
  *example.glob('test/support/mail*.dart'),
  *root.glob('packages/quds_mail_*/lib/**/*.dart'),
  *root.glob('packages/quds_mail_*/pubspec.yaml'),
  root/'pubspec.yaml', root/'pubspec.lock', root/'.fvmrc',
])
def stamp():
 return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes():
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source}
def write(name,data):
 (out/name).write_text(json.dumps(data,indent=2)+'\n')

before=hashes()
write('inputs-before.json', before)
command=['flutter','test','--no-pub','--concurrency=2','--reporter=json', *['test/'+n for n in names]]
meta={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(), 'started':stamp(), 'command':command, 'cwd':str(example), 'BOT':os.environ.get('BOT'), 'FLUTTER_ROOT':os.environ.get('FLUTTER_ROOT')}
write('command.json',meta)
print('Starting focused Mail tests on '+meta['head'],flush=True)
with (out/'tests.jsonl').open('w') as stdout, (out/'tests.stderr').open('w') as stderr:
 result=subprocess.run(command,cwd=example,stdout=stdout,stderr=stderr,timeout=1200)
meta.update({'finished':stamp(),'exit_code':result.returncode})
write('command.json',meta)
started={};completed=[];errors=[];terminal=[]
for line in (out/'tests.jsonl').read_text().splitlines():
 try:event=json.loads(line)
 except ValueError:continue
 if event.get('type')=='testStart':started[event['test']['id']]=event['test']
 if event.get('type')=='testDone' and not event.get('hidden'):completed.append(event)
 if event.get('type')=='error':errors.append(event)
 if event.get('type')=='done':terminal.append(event)
after=hashes();write('inputs-after.json',after)
summary={'head':meta['head'],'exit_code':result.returncode,'suites':names,'cases':len(completed),'passed':sum(e['result']=='success' and not e['skipped'] for e in completed),'failed':[dict(name=started.get(e['testID'],{}).get('name'),result=e['result']) for e in completed if e['result']!='success'],'skipped':sum(e['skipped'] for e in completed),'errors':errors,'terminal':terminal,'changed_inputs':[p for p in before if before[p]!=after.get(p)]}
write('summary.json',summary)
print(json.dumps(summary,indent=2),flush=True)
sys.exit(result.returncode)
