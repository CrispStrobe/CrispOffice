import datetime, hashlib, json, subprocess, sys
from pathlib import Path
root=Path('/workspace/scratch/c48dbdc53e0b/quds_office_suite')
out=Path(__file__).parent
old=Path('/workspace/scratch/c48dbdc53e0b/mail-intake-validation/analysis-command.json')
command=json.loads(old.read_text())['command']
paths=command[3:]
def stamp():
 return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes():
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
def write(data):
 (out/'analysis-command.json').write_text(json.dumps(data,indent=2)+'\n')
meta={'command':command,'cwd':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'started':stamp(),'source_hashes':hashes()}
write(meta)
with (out/'analysis.stdout').open('w') as stdout,(out/'analysis.stderr').open('w') as stderr:
 result=subprocess.run(command,cwd=root,stdout=stdout,stderr=stderr,timeout=600)
meta.update({'exit_code':result.returncode,'finished':stamp(),'source_hashes_after':hashes()})
meta['changed_inputs']=[p for p in paths if meta['source_hashes'][p]!=meta['source_hashes_after'][p]]
write(meta)
print(json.dumps({'head':meta['head'],'exit_code':result.returncode,'files':len(paths),'changed_inputs':meta['changed_inputs'],'stdout':(out/'analysis.stdout').read_text(),'stderr':(out/'analysis.stderr').read_text()},indent=2))
sys.exit(result.returncode)
