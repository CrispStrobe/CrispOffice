#!/usr/bin/env python3
"""Run a bounded incoming Word/Zotero cohort and record its source closure."""
import argparse
from collections import Counter
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
from urllib.parse import unquote, urljoin, urlparse


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('cohort', choices=('engine_vm', 'engine_node', 'editor', 'goldens'))
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    sdk = Path(os.environ['FLUTTER_ROOT'])
    dart = sdk / 'bin/cache/dart-sdk/bin/dart'
    config_path = repo / '.dart_tool/package_config.json'
    config = json.loads(config_path.read_text())
    roots = {}
    for package in config['packages']:
        root_uri = urljoin(config_path.as_uri(), package['rootUri'])
        roots[package['name']] = Path(unquote(urlparse(urljoin(root_uri.rstrip('/') + '/', package.get('packageUri', ''))).path))
    package = repo / 'packages' / ('quds_office_editor' if args.cohort in ('editor', 'goldens') else 'quds_office_engine')
    targets = ['tool/zotero/vertical_table_acceptance.dart']
    if args.cohort == 'goldens':
        targets = [
            'test/office_layout_goldens_test.dart',
            'test/office_frame_wrap_golden_test.dart',
            'test/office_fidelity_golden_test.dart',
            'test/office_structure_goldens_test.dart',
            'test/office_nested_table_golden_test.dart',
            'test/office_story_golden_test.dart',
            'test/office_table_grid_golden_test.dart',
        ]
    elif args.cohort == 'editor':
        targets.extend(['test/embed_test.dart', 'test/word_header_footer_navigation_test.dart', 'test/office_system_fonts_test.dart'])
    if args.cohort in ('editor', 'goldens'):
        command = [str(dart), str(sdk / 'bin/cache/flutter_tools.snapshot'), 'test', '--no-pub', '--reporter=json', '--concurrency=1', *targets]
    else:
        command = [str(dart), '--packages=' + str(config_path), str(Path(os.environ['PUB_CACHE']) / 'hosted/pub.dev/test-1.31.1/bin/test.dart'), '--reporter=json', '--concurrency=1']
        if args.cohort == 'engine_node':
            command.append('--platform=node')
        command.extend(targets)

    def sources():
        pending = [package / target for target in targets]
        seen = set()
        while pending:
            path = pending.pop().resolve()
            if path in seen or not path.is_file():
                continue
            seen.add(path)
            if path.suffix != '.dart':
                continue
            text = path.read_text(errors='replace')
            for directive in re.finditer(r'\b(?:import|export|part)\s+(?!of\b)([^;]+);', text, re.S):
                for uri in re.findall(r'''["']([^"']+)["']''', directive.group(1)):
                    if uri.startswith('dart:'):
                        continue
                    if uri.startswith('package:'):
                        name, rest = uri[8:].split('/', 1)
                        if name in roots:
                            pending.append(roots[name] / rest)
                    elif uri.endswith('.dart'):
                        pending.append(path.parent / uri)
        # Include fixtures, fonts, native assets and package metadata. These are
        # data dependencies not represented by Dart import/export directives.
        tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', 'packages', 'third_party'], cwd=repo).decode().split('\0')
        for rel in tracked:
            path = repo / rel
            if rel and path.is_file() and (path.name == 'pubspec.yaml' or '/fixtures/' in rel or '/fonts/' in rel or '/goldens/' in rel or '/assets/' in rel):
                seen.add(path.resolve())
        seen.update([config_path, repo / 'pubspec.lock', repo / 'pubspec.yaml', Path(__file__).resolve()])
        return {str(p.relative_to(repo)) if p.is_relative_to(repo) else str(p): digest(p) for p in sorted(seen)}

    before = sources()
    before_path = out / (args.cohort + '-sources-before.json')
    before_path.write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
    log_path, err_path = out / (args.cohort + '.jsonl'), out / (args.cohort + '.stderr')
    receipt = {
        'command': command, 'cwd': str(package),
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
        'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=repo, text=True).strip(),
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_scope': 'Transitive Dart imports/exports/parts including conditional branches, package metadata, tracked fixture/font/golden/asset data, dependency config and lock, runner. External SDK/pub Dart sources included when reachable.',
        'source_count': len(before), 'source_manifest_sha256': digest(before_path),
        'dart_version': subprocess.check_output([str(dart), '--version'], stderr=subprocess.STDOUT, text=True).strip(),
        'node_version': subprocess.check_output(['node', '--version'], text=True).strip(),
        'flutter_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=sdk, text=True).strip(),
    }
    start = time.monotonic()
    with log_path.open('w') as log, err_path.open('w') as err:
        result = subprocess.run(command, cwd=package, stdout=log, stderr=err)
    after = sources()
    (out / (args.cohort + '-sources-after.json')).write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
    events = []
    for line in log_path.read_text().splitlines():
        try:
            row = json.loads(line)
            if isinstance(row, dict) and 'type' in row:
                events.append(row)
        except json.JSONDecodeError:
            pass
    starts = {row['test']['id']: row['test'] for row in events if row['type'] == 'testStart'}
    counts, names, completions = Counter(), [], []
    for row in events:
        if row['type'] != 'testDone':
            continue
        completions.append(row['testID'])
        name = starts[row['testID']]['name']
        if row.get('hidden') or name.startswith('loading ') or name.endswith('(setUpAll)') or name.endswith('(tearDownAll)'):
            continue
        outcome = 'skipped' if row.get('skipped') else row['result']
        counts[outcome] += 1
        names.append({'name': name, 'outcome': outcome})
    done = [row for row in events if row['type'] == 'done']
    errors = [row for row in events if row['type'] == 'error']
    clean_terminal = len(done) == 1 and done[0]['success'] is True and set(completions) == set(starts) and len(completions) == len(set(completions)) and bool(starts)
    stable = before == after
    receipt.update(exit_code=result.returncode, seconds=round(time.monotonic() - start, 3), source_stable=stable,
                   changed_sources=[p for p in sorted(set(before) | set(after)) if before.get(p) != after.get(p)],
                   log_sha256=digest(log_path), stderr_sha256=digest(err_path), counts=dict(counts), errors=errors,
                   clean_terminal=clean_terminal, accepted=result.returncode == 0 and stable and clean_terminal and not errors)
    (out / (args.cohort + '-cases.json')).write_text(json.dumps(names, indent=2) + '\n')
    (out / (args.cohort + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k: v for k, v in receipt.items() if k not in ('command', 'errors')}, indent=2), flush=True)
    return 0 if receipt['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
