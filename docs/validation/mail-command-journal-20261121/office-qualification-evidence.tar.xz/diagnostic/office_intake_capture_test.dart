import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'office_layout_goldens_test.dart' as suite0;
import 'office_frame_wrap_golden_test.dart' as suite1;
import 'office_fidelity_golden_test.dart' as suite2;
import 'office_structure_goldens_test.dart' as suite3;
import 'office_nested_table_golden_test.dart' as suite4;
import 'office_story_golden_test.dart' as suite5;
import 'office_table_grid_golden_test.dart' as suite6;
// Diagnostic only: capture first references without updating repository goldens.
// Repeated renders of the same scene must still be byte-identical.
class _Capture extends GoldenFileComparator {
  final Map<String, Uint8List> first = {};
  final Map<String, int> counts = {};
  @override
  Future<bool> compare(Uint8List pixels, Uri golden) async {
    final name = golden.path.replaceAll('/', '__');
    final count = counts.update(name, (n) => n + 1, ifAbsent: () => 0);
    final dir = Directory('/workspace/scratch/1680c40b6915/golden-current-captures')..createSync(recursive: true);
    File('${dir.path}/$name.$count.png').writeAsBytesSync(pixels);
    final previous = first.putIfAbsent(name, () => Uint8List.fromList(pixels));
    if (!listEquals(previous, pixels)) {
      throw TestFailure('Native round-trip changed the exact PNG for $name at render $count.');
    }
    return true;
  }
  @override
  Future<void> update(Uri golden, Uint8List imageBytes) => throw StateError('Capture never updates goldens');
}
void main() {
  goldenFileComparator = _Capture();
  group('office_layout_goldens_test', suite0.main);
  group('office_frame_wrap_golden_test', suite1.main);
  group('office_fidelity_golden_test', suite2.main);
  group('office_structure_goldens_test', suite3.main);
  group('office_nested_table_golden_test', suite4.main);
  group('office_story_golden_test', suite5.main);
  group('office_table_grid_golden_test', suite6.main);
}
