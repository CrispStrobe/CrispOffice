async function(head="HEAD", align=true) {
  const repo="/workspace/scratch/1680c40b6915/quds-office-work";
  const helper="/home/agent/.codex/skills/remote-skills/quds-mail-work-20261120/runtime/publish_snapshot.py";
  const full="CrispStrobe/quds_office_suite", branch="work/mail-command-journal-20261121";
  const quote=s=>"'"+String(s).replace(/'/g,"'\\''")+"'";
  async function command(cmd,max_output_tokens=10000) {
    let r=await tools.exec_command({cmd,workdir:repo,yield_time_ms:1000,max_output_tokens});
    while(r.session_id) {
      const n=await tools.write_stdin({session_id:r.session_id,chars:"",yield_time_ms:1000,max_output_tokens});
      n.output=r.output+n.output;r=n;
    }
    if(r.exit_code!==0)throw Error(r.output);
    return r.output;
  }
  const rows=JSON.parse(await command("cat ../publication-journal.json"));
  const aliases=Object.fromEntries(rows.map(r=>[r.local,r.remote]));
  const expected=rows.at(-1).remote;
  const snapshot=JSON.parse(await command("python3 "+quote(helper)+" "+quote(head)+" "+quote(expected)));
  if((aliases[snapshot.parents[0]]??snapshot.parents[0])!==expected)throw Error("Unexpected first parent");
  const parents=snapshot.parents.slice(1).map(p=>aliases[p]??p);
  for(const entry of snapshot.entries) {
    if(entry.sha===null||entry.type!=="blob"||entry.existing)continue;
    const offsets=[];for(let offset=0;offset<entry.size;offset+=12288)offsets.push(offset);
    const chunks=[];
    for(let start=0;start<offsets.length;start+=4) {
      const reads=await Promise.allSettled(offsets.slice(start,start+4).map(async offset=>(await command("python3 "+quote(helper)+" blob "+quote(entry.sha)+" "+offset+" 12288",16000)).trim()));
      for(const read of reads)if(read.status==="rejected")throw read.reason;
      chunks.push(...reads.map(read=>read.value));
    }
    const blob=await tools.mcp__codex_apps__github_create_blob({repository_full_name:full,encoding:"base64",content:chunks.join("")});
    if(blob.isError||blob.structuredContent?.sha!==entry.sha)throw Error("Blob mismatch "+entry.path+" "+JSON.stringify(blob));
  }
  const baseTree=(await command("git rev-parse "+quote(expected+"^{tree}"))).trim();
  if(snapshot.entries.length) {
    const tree=await tools.mcp__codex_apps__github_create_tree({repository_full_name:full,base_tree_sha:baseTree,tree_elements:snapshot.entries.map(({size,existing,...entry})=>entry)});
    if(tree.isError||tree.structuredContent?.sha!==snapshot.tree)throw Error("Tree mismatch "+JSON.stringify(tree));
  } else if(baseTree!==snapshot.tree)throw Error("Empty delta tree mismatch");
  const commit=await tools.mcp__codex_apps__github_create_commit({repository_full_name:full,parent_sha:expected,additional_parent_shas:parents,tree_sha:snapshot.tree,message:snapshot.message});
  if(commit.isError||!commit.structuredContent?.sha)throw Error("Commit failed "+JSON.stringify(commit));
  const remote=commit.structuredContent.sha;
  const ref=await tools.mcp__codex_apps__github_update_ref({repository_full_name:full,branch_name:branch,expected_sha:expected,sha:remote,force:false});
  if(ref.isError)throw Error("Ref update failed "+JSON.stringify(ref));
  const record={local:snapshot.head,remote,tree:snapshot.tree,message:snapshot.message,files:snapshot.entries.length};
  rows.push(record);
  await command("python3 -c "+quote('import json,sys;from pathlib import Path;p=Path(sys.argv[1]);t=p.with_suffix(".tmp");t.write_text(json.dumps(json.loads(sys.argv[2]),indent=2)+"\\n");t.replace(p)')+" ../publication-journal.json "+quote(JSON.stringify(rows)));
  store("journalRemote",remote);store("journalPublications",rows);store("publicationAliases",Object.fromEntries(rows.map(r=>[r.local,r.remote])));
  notify({checkpoint:remote,files:record.files,tree:record.tree});
  await command("git fetch origin "+quote(branch),3000);
  if(align) {
    const current=(await command("git rev-parse HEAD")).trim();
    const remoteTree=(await command("git rev-parse "+quote("origin/"+branch+"^{tree}"))).trim();
    const remoteHead=(await command("git rev-parse "+quote("origin/"+branch))).trim();
    if(current!==snapshot.head||remoteTree!==snapshot.tree||remoteHead!==remote)throw Error("Alignment identity changed; remote saved, local left untouched");
    await command("git reset --soft "+quote(remote)+" && git branch --set-upstream-to="+quote("origin/"+branch)+" "+quote(branch),3000);
  }
  text(record);
  return remote;
}
