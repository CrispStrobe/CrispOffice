# Durable flag journal: core and storage qualification

All final cohorts passed with observed process exit code 0, one clean successful
test-runner terminal event, zero skipped or failed cases, and equal source
manifests before and after execution. `summary.json` checks the counts, raw-log
hashes and equality of the core VM/Node case sets.

| Accepted cohort | Passing executions | Source-manifest SHA-256 |
| --- | ---: | --- |
| Core VM | 235 | `da05e2bfa8233672874513f0527bf994479e747c20826bf68245fff18398d7f7` |
| Core Node | 235 | `e0061b2fdd9c7065cf31553bfa272a0928ae4b30a051173545bd6186e8add823` |
| Complete store VM | 749 | `49ee3d727f315eba068b12dcdaa2da2ffeddcabfd140ccb2bfcb1243508dca6a` |
| Total runtime executions | **1,219** | Core VM and Node exercise the same 235 cases |

The core journal suite contributes 16 cases in each runtime. The complete store
gate includes 26 journal cases, 14 actual SIGKILL transaction cases and 15
migration cases, alongside the complete existing cache/archive/store regressions.
These are included in the table, not additional executions.

Strict `dart analyze --fatal-infos`, non-mutating Dart format validation and
package-scoped `git diff --check` passed. `static-checks-receipt.json` binds their
commands, observed exits, logs and unchanged 2,468-entry source closure.

## Evidence and reproducibility

Each cohort has its exact command, working directory, runtime revisions,
observed process exit, raw JSON event log, case list, source maps and hashes.
The runtimes are Dart 3.13.7, Flutter revision
`737ba8f885dc774b53b442759999a312c9461e4e` and Node 24.22.3. Test commands invoke
the installed package:test runner directly with the normal workspace package
configuration and genuine generated SQLite native-asset mapping. Process-crash
fixtures invoke the adjacent official `dart run` launcher and send SIGKILL to
the PID that owns the actual SQLite connection.

Manifests follow transitive Dart import/export/part directives, including
conditional branches and reachable external dependencies. They also bind
package metadata, fixtures, fonts, assets, the lock/configuration files,
validation runner and mapped native binaries. The final Node/store wrapper
excludes Office widget PNG baselines because these core/store tests have no
Office image-data dependency. No assertion or relevant fixture was excluded.

`core-source-continuity.json` records the few independent metadata/data changes
after the accepted core runs. All core Dart sources, resolved package
configuration and lockfile remained byte-identical. The host example's added
Drift development dependency was already selected at the same workspace version;
Office images are unrelated to core execution. Regenerated native-asset mapping
files point at identical SQLite binary content and are not used by pure core
tests. This audit is not counted as another test execution.

`package-final-source-manifest.json` captures all 115 tracked core/store package
files at handoff. The repository HEAD values in the runtime receipts are context;
the exact per-file manifests bind the qualified working sources, including
changes awaiting a later integration checkpoint.

## Confirmed cache revision fence

A focused regression reproduced an older cached-view writer incorrectly
overwriting a fresh confirmation when the desired flag already matched the
stored bit. The fix advances affected cached-view revisions for every confirmed
exact cached identity, including an already-matching bit and a wholly unknown
flag snapshot. Known flags change only the requested bit; unknown flags remain
null; missing identities do not create cache rows.

Both stale-writer variants passed. SIGKILL coverage requires the view revision
to remain at its prior value before acknowledgement commit and to advance after
receipt/finish commit, while the unknown snapshot remains null. This verifies
that the revision fence and durable receipt share the commit boundary.

## Retained unsuccessful and earlier evidence

The `diagnostics/` directory is separate from accepted results:

- `pre-yaml-parser-fix`: completed test logs whose wrapper failed reading valid
  generated YAML with JSON-only parsing. The missing process exit was not
  inferred from test events. Node and store were rerun with `yaml.safe_load`.
- `unchanged-confirmation-cas`: the expected failing regression against the
  earlier cache fence, with its observed exit 1 and exact source copies.
- `pre-crash-fence-expectation-fix`: the first post-fence full store run, with
  747 passing and two failing legacy revision assertions. The assertions now
  require the newly specified committed revision; the final 749-case rerun
  passed without removing either scenario.
- `preliminary-local-checks`: initial compilation/analysis fixes, missing native
  asset setup diagnosis and a loader-target mistake. These logs are diagnostic
  only and contribute nothing to accepted totals. The temporary diagnostic Dart
  test was removed before final qualification.

`prior-accepted/` retains the valid pre-fence 747-case store receipt and earlier
static checks separately. They are not counted in the final total.

## Scope and remaining boundaries

No GitHub CI result was queried or awaited. Provider evidence is synthetic;
these gates do not establish authorized live-provider interoperability. SQLite
tests use the actual Linux native engine, and SIGKILL tests establish the tested
process-crash boundaries, not power-loss behavior on every filesystem/device.
Core Node execution does not qualify browser SQLite persistence or installed
macOS, Windows or mobile behavior.

Recovery retains confirmations, makes in-flight work uncertain, leaves the
untouched tail unattempted and performs no provider replay. The journal exposes
no reconciliation/resume API for historical uncertainty. An account with 100
unresolved batches therefore rejects new journaled commands until a later
explicit recovery workflow exists. Total history remains bounded at 200 batches;
normal creation/completion prunes clean history to 100, while recovery may
temporarily retain additional clean receipts until the next pruning write or
explicit cleanup. Package and product contracts document this limitation.
