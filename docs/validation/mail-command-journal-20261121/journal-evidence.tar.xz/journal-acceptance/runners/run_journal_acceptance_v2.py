#!/usr/bin/env python3
"""Run a local mail core/store acceptance cohort and record its source closure."""
import argparse
from collections import Counter
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
import yaml
from urllib.parse import unquote, urljoin, urlparse


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('cohort', choices=('core_vm', 'core_node', 'store_vm', 'crash_vm'))
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    sdk = Path(os.environ['FLUTTER_ROOT'])
    dart = sdk / 'bin/cache/dart-sdk/bin/dart'
    config_path = repo / '.dart_tool/package_config.json'
    config = json.loads(config_path.read_text())
    roots = {}
    for package in config['packages']:
        root_uri = urljoin(config_path.as_uri(), package['rootUri'])
        roots[package['name']] = Path(unquote(urlparse(urljoin(root_uri.rstrip('/') + '/', package.get('packageUri', ''))).path))
    package = repo / 'packages' / ('quds_mail_core' if args.cohort.startswith('core_') else 'quds_mail_store')
    targets = ['test/crash_recovery_test.dart'] if args.cohort == 'crash_vm' else [str(p.relative_to(package)) for p in sorted((package / 'test').glob('*_test.dart'))]
    command = [str(dart), '--packages=' + str(config_path), str(Path(os.environ['PUB_CACHE']) / 'hosted/pub.dev/test-1.31.1/bin/test.dart'), '--reporter=json', '--concurrency=1']
    if args.cohort == 'core_node':
        command.append('--platform=node')
    command.extend(targets)

    def sources():
        pending = [package / target for target in targets]
        seen = set()
        while pending:
            path = pending.pop().resolve()
            if path in seen or not path.is_file():
                continue
            seen.add(path)
            if path.suffix != '.dart':
                continue
            text = path.read_text(errors='replace')
            for directive in re.finditer(r'\b(?:import|export|part)\s+(?!of\b)([^;]+);', text, re.S):
                for uri in re.findall(r'''["']([^"']+)["']''', directive.group(1)):
                    if uri.startswith('dart:'):
                        continue
                    if uri.startswith('package:'):
                        name, rest = uri[8:].split('/', 1)
                        if name in roots:
                            pending.append(roots[name] / rest)
                    elif uri.endswith('.dart'):
                        pending.append(path.parent / uri)
        # Include fixtures, fonts, native assets and package metadata. These are
        # data dependencies not represented by Dart import/export directives.
        tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', 'packages', 'third_party'], cwd=repo).decode().split('\0')
        for rel in tracked:
            path = repo / rel
            if rel.startswith('packages/quds_office_editor/test/goldens/'):
                continue  # Office image baselines are not read by core/store tests.
            if rel and path.is_file() and (path.name == 'pubspec.yaml' or '/fixtures/' in rel or '/fonts/' in rel or '/goldens/' in rel or '/assets/' in rel):
                seen.add(path.resolve())
        seen.update([config_path, repo / 'pubspec.lock', repo / 'pubspec.yaml', Path(__file__).resolve()])
        native_map = repo / '.dart_tool/native_assets.yaml'
        if native_map.exists():
            seen.add(native_map)
            mapping = yaml.safe_load(native_map.read_text())
            for target_map in mapping.get('native-assets', {}).values():
                for asset in target_map.values():
                    if asset[0] == 'absolute' and Path(asset[1]).is_file():
                        seen.add(Path(asset[1]))

        return {str(p.relative_to(repo)) if p.is_relative_to(repo) else str(p): digest(p) for p in sorted(seen)}

    before = sources()
    before_path = out / (args.cohort + '-sources-before.json')
    before_path.write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
    log_path, err_path = out / (args.cohort + '.jsonl'), out / (args.cohort + '.stderr')
    receipt = {
        'command': command, 'cwd': str(package),
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
        'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=repo, text=True).strip(),
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_scope': 'Transitive Dart imports/exports/parts including conditional branches, package metadata, tracked fixture/font/golden/asset data except unrelated packages/quds_office_editor/test/goldens/, dependency config and lock, runner, native asset mapping and referenced binaries. External SDK/pub Dart sources included when reachable.',
        'data_scope_exclusion': 'Office widget PNG baselines are not referenced or loaded by any core/store test or its Dart import closure. Their concurrent qualification updates are independent of mail core/store execution. No test, assertion or relevant fixture is excluded.',
        'source_count': len(before), 'source_manifest_sha256': digest(before_path),
        'dart_version': subprocess.check_output([str(dart), '--version'], stderr=subprocess.STDOUT, text=True).strip(),
        'node_version': subprocess.check_output(['node', '--version'], text=True).strip(),
        'flutter_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=sdk, text=True).strip(),
    }
    start = time.monotonic()
    with log_path.open('w') as log, err_path.open('w') as err:
        result = subprocess.run(command, cwd=package, stdout=log, stderr=err)
    after = sources()
    (out / (args.cohort + '-sources-after.json')).write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
    events = []
    for line in log_path.read_text().splitlines():
        try:
            row = json.loads(line)
            if isinstance(row, dict) and 'type' in row:
                events.append(row)
        except json.JSONDecodeError:
            pass
    starts = {row['test']['id']: row['test'] for row in events if row['type'] == 'testStart'}
    counts, names, completions = Counter(), [], []
    for row in events:
        if row['type'] != 'testDone':
            continue
        completions.append(row['testID'])
        name = starts[row['testID']]['name']
        if row.get('hidden') or name.startswith('loading ') or name.endswith('(setUpAll)') or name.endswith('(tearDownAll)'):
            continue
        outcome = 'skipped' if row.get('skipped') else row['result']
        counts[outcome] += 1
        names.append({'name': name, 'outcome': outcome})
    done = [row for row in events if row['type'] == 'done']
    errors = [row for row in events if row['type'] == 'error']
    clean_terminal = len(done) == 1 and done[0]['success'] is True and set(completions) == set(starts) and len(completions) == len(set(completions)) and bool(starts)
    stable = before == after
    receipt.update(exit_code=result.returncode, seconds=round(time.monotonic() - start, 3), source_stable=stable,
                   changed_sources=[p for p in sorted(set(before) | set(after)) if before.get(p) != after.get(p)],
                   log_sha256=digest(log_path), stderr_sha256=digest(err_path), counts=dict(counts), errors=errors,
                   clean_terminal=clean_terminal, accepted=result.returncode == 0 and stable and clean_terminal and not errors)
    (out / (args.cohort + '-cases.json')).write_text(json.dumps(names, indent=2) + '\n')
    (out / (args.cohort + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k: v for k, v in receipt.items() if k not in ('command', 'errors')}, indent=2), flush=True)
    return 0 if receipt['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
