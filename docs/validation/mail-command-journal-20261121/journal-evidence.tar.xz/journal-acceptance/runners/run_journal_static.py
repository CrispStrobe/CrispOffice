#!/usr/bin/env python3
"""Bind final core/store analysis, formatting and whitespace checks to sources."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

REPO = Path('/workspace/scratch/1680c40b6915/quds-office-work')
OUT = Path('/workspace/scratch/1680c40b6915/journal-acceptance')
DART = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/dart-sdk/bin/dart'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sources():
    seed = json.loads((OUT / 'store_vm-sources-before.json').read_text())
    files = {Path(k) if k.startswith('/') else REPO / k for k in seed}
    for package in ('quds_mail_core', 'quds_mail_store'):
        files.update(p for p in (REPO / 'packages' / package).rglob('*.dart')
                     if '.dart_tool' not in p.parts and 'build' not in p.parts)
    files.add(Path(__file__).resolve())
    files.update(p for p in (REPO / 'analysis_options.yaml',
                             REPO / 'packages/quds_mail_core/analysis_options.yaml',
                             REPO / 'packages/quds_mail_store/analysis_options.yaml')
                 if p.is_file())
    return {str(p.relative_to(REPO)) if p.is_relative_to(REPO) else str(p): digest(p)
            for p in sorted(files)}


before = sources()
before_path = OUT / 'static-checks-sources-before.json'
before_path.write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
checks = []
commands = [
    ('analysis', [str(DART), 'analyze', '--fatal-infos',
                  'packages/quds_mail_core', 'packages/quds_mail_store']),
    ('format', [str(DART), 'format', '--output=none', '--set-exit-if-changed',
                'packages/quds_mail_core', 'packages/quds_mail_store']),
    ('whitespace', ['git', 'diff', '--check', '--',
                    'packages/quds_mail_core', 'packages/quds_mail_store']),
]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
for name, command in commands:
    output = OUT / ('static-' + name + '.log')
    with output.open('w') as sink:
        completed = subprocess.run(command, cwd=REPO, stdout=sink,
                                   stderr=subprocess.STDOUT)
    checks.append({'name': name, 'command': command,
                   'cwd': str(REPO), 'exit_code': completed.returncode,
                   'log': output.name, 'log_sha256': digest(output)})
after = sources()
(OUT / 'static-checks-sources-after.json').write_text(
    json.dumps(after, indent=2, sort_keys=True) + '\n')
receipt = {
    'started_utc': started,
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO,
                                    text=True).strip(),
    'source_scope': 'Full store test transitive source and data closure plus all core/store Dart source files, local analysis options and this runner.',
    'source_manifest_sha256': digest(before_path),
    'source_count': len(before), 'source_stable': before == after,
    'changed_sources': [p for p in sorted(set(before) | set(after))
                        if before.get(p) != after.get(p)],
    'checks': checks,
    'accepted': before == after and all(c['exit_code'] == 0 for c in checks),
}
(OUT / 'static-checks-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(0 if receipt['accepted'] else 1)
