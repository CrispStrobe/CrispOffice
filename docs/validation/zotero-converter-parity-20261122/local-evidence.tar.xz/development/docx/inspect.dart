import 'dart:io';
import 'dart:convert';
import 'package:quds_office_engine/quds_office_engine.dart';
void main() {
 final d = WordDeserializer().readBytes(File('/workspace/scratch/e0e93bd324dd/quds_office_suite/packages/quds_office_engine/test/fixtures/zotero/converter/docx-cycle-1/body.docx').readAsBytesSync());
 for(final f in WordZotero.fields(d)) {
  print({'opaque':f.opaqueMetadata,'whole':f.wholeParagraph});
  for(final inline in f.paragraph.inlines){
   if(inline is WmlFieldBoundary){print({'kind':inline.kind,'propsAllowed':_benignBoundaryRunProperties(inline.runPropertiesXml),'source':inline.sourceXml?.substring(0,70)});}
   else if(inline is WmlRun){print({'run':inline.text,'field':inline.fieldInstruction,'comments':inline.commentIds});}
   else{print(inline.runtimeType);}
  }
 }
}
const _boundaryBoolean = {'0', '1', 'false', 'true', 'off', 'on'};

bool _namespaceDeclaration(XmlAttribute attribute) =>
    attribute.prefix == 'xmlns' || attribute.qualifiedName == 'xmlns';

// LibreOffice writes ordinary character formatting on instrText and fldChar
// runs. It is non-visible field metadata, and retaining its exact XML makes
// in-place native citation updates safe. This deliberately excludes style
// references, revision/form state, hidden text and unrecognized extensions.
bool _benignBoundaryRunProperties(String? xml) {
  if (xml == null || xml.trim().isEmpty) return true;
  if (xml.length > 16384) return false;
  try {
    final root = XmlDocument.parse(xml).root;
    if (root == null ||
        root.localName != 'rPr' ||
        root.namespaceUri != OfficeNamespaces.w ||
        root.attributes.any((attribute) => !_namespaceDeclaration(attribute)) ||
        root.children.length > 64) {
      return false;
    }
    final seen = <String, String>{};
    for (final child in root.children) {
      if (child is XmlText && child.text.trim().isEmpty) continue;
      if (child is! XmlElement ||
          child.namespaceUri != OfficeNamespaces.w ||
          child.children.isNotEmpty) {
        return false;
      }
      final attributes = <String, String>{};
      for (final attribute in child.attributes) {
        if (_namespaceDeclaration(attribute)) continue;
        if (attribute.namespaceUri != OfficeNamespaces.w ||
            attributes.containsKey(attribute.localName)) {
          return false;
        }
        attributes[attribute.localName] = attribute.value;
      }
      final name = child.localName;
      final value = attributes['val'];
      switch (name) {
        case 'b':
        case 'bCs':
        case 'i':
        case 'iCs':
        case 'caps':
        case 'smallCaps':
        case 'rtl':
          if (attributes.keys.any((key) => key != 'val') ||
              (value != null && !_boundaryBoolean.contains(value))) {
            return false;
          }
        case 'color':
          if (attributes.length != 1 ||
              value == null ||
              (value != 'auto' &&
                  !RegExp(r'^[0-9a-fA-F]{6}$').hasMatch(value))) {
            return false;
          }
        case 'kern':
        case 'sz':
        case 'szCs':
          if (attributes.length != 1 ||
              value == null ||
              !RegExp(r'^[0-9]{1,5}$').hasMatch(value)) {
            return false;
          }
          final halfPoints = int.parse(value);
          if (halfPoints > 32767 || (name != 'kern' && halfPoints == 0)) {
            return false;
          }
        case 'rFonts':
          if (attributes.isEmpty ||
              attributes.entries.any(
                (entry) =>
                    !{'ascii', 'hAnsi', 'eastAsia', 'cs'}.contains(entry.key) ||
                    entry.value.trim().isEmpty ||
                    entry.value.length > 256 ||
                    RegExp(r'[\x00-\x1f\x7f]').hasMatch(entry.value),
              )) {
            return false;
          }
        case 'lang':
          if (attributes.isEmpty ||
              attributes.entries.any(
                (entry) =>
                    !{'val', 'eastAsia', 'bidi'}.contains(entry.key) ||
                    entry.value.length > 63 ||
                    !RegExp(
                      r'^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$',
                    ).hasMatch(entry.value),
              )) {
            return false;
          }
        default:
          return false;
      }
      // Observed LibreOffice output repeats identical toggle properties.
      // Preserve those raw nodes, but reject contradictory duplicate values.
      final keys = attributes.keys.toList()..sort();
      final signature = jsonEncode({
        for (final key in keys) key: attributes[key],
      });
      if (seen.containsKey(name) && seen[name] != signature) return false;
      seen[name] = signature;
    }
    return true;
  } on XmlParseException {
    return false;
  }
}

