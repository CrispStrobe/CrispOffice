import importlib.util,json,subprocess,time,hashlib,shutil
from pathlib import Path
ROOT=Path('/workspace/scratch/e0e93bd324dd/quds_office_suite')
OUT=ROOT.parent/'final-qualification'/'serial'
OUT.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('checks',ROOT/'docs/validation/zotero-converter-parity-20261122/run_checks.py')
checks=importlib.util.module_from_spec(spec);spec.loader.exec_module(checks)
base='659b81462224a40f50975cfbfca39f636538b836'
files=[p for p in subprocess.check_output(['git','diff','--name-only','--diff-filter=ACMR',base,'HEAD'],cwd=ROOT,text=True).splitlines() if p.endswith('.dart') and (ROOT/p).is_file()]
before=checks.inputs();(OUT/'static.inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
record={'source_commit':checks.git('rev-parse','HEAD'),'source_tree':checks.git('rev-parse','HEAD^{tree}'),'baseline_main':base,'working_tree':checks.git('status','--porcelain'),'dart_files':files,'started_at_unix':time.time(),'checks':[]}
for label,command in [('analyze',[shutil.which('dart'),'analyze','--fatal-infos',*files]),('format',[shutil.which('dart'),'format','--output=none','--set-exit-if-changed',*files]),('diff',['git','diff','--check',base,'HEAD'])]:
 with (OUT/(label+'.stdout')).open('w') as stdout,(OUT/(label+'.stderr')).open('w') as stderr:
  try:result=subprocess.run(command,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=600);code=result.returncode
  except subprocess.TimeoutExpired:code=124
 record['checks'].append({'name':label,'command':command,'exit_code':code,'stdout_sha256':checks.sha256(OUT/(label+'.stdout')),'stderr_sha256':checks.sha256(OUT/(label+'.stderr'))})
after=checks.inputs();(OUT/'static.inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');record['changed_inputs']=[p for p in sorted(before.keys()|after.keys()) if before.get(p)!=after.get(p)];record['input_count']=len(before);record['finished_at_unix']=time.time();record['accepted']=not record['changed_inputs'] and all(r['exit_code']==0 for r in record['checks'])
(OUT/'static.receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k] for k in ['source_commit','input_count','changed_inputs','accepted']}));raise SystemExit(0 if record['accepted'] else 1)
