import hashlib,io,json,subprocess,tarfile,time
from pathlib import Path
ROOT=Path('/workspace/scratch/e0e93bd324dd/quds_office_suite')
SCRATCH=ROOT.parent
OUT=SCRATCH/'final-qualification'
DEST=ROOT/'docs/validation/zotero-converter-parity-20261122'
SOURCE='81e9da16f9672530d4b39e9cf6cfec979af12830'
COHORT_PATHS={name:OUT/('serial' if name in {'editor','studio','incoming-mail'} else '') for name in ['engine','editor','studio','incoming-word','incoming-mail','incoming-store']}
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
receipts={};reference=None;unique_suites=set()
for name,folder in COHORT_PATHS.items():
 receipt=json.loads((folder/(name+'.receipt.json')).read_text())
 assert receipt['source_commit']==SOURCE,(name,receipt['source_commit'])
 assert receipt['accepted'] is True,(name,receipt)
 before=json.loads((folder/(name+'.inputs-before.json')).read_text())
 after=json.loads((folder/(name+'.inputs-after.json')).read_text())
 assert before==after
 if reference is None:reference=before
 assert before==reference,name
 paths=set(receipt['command'][receipt['command'].index('--no-pub')+1:] if '--no-pub' in receipt['command'] else receipt['command'][3:])
 paths={receipt['cwd']+'/'+p for p in paths if p.endswith('_test.dart')}
 assert not(unique_suites & paths),name
 unique_suites|=paths
 receipts[name]=receipt
static=json.loads((OUT/'normalized/static.receipt.json').read_text())
normalization=json.loads((OUT/'format-normalization/receipt.json').read_text())
assert static['accepted'] is True and static['source_commit']==git('rev-parse','HEAD')
static_before=json.loads((OUT/'normalized/static.inputs-before.json').read_text())
static_after=json.loads((OUT/'normalized/static.inputs-after.json').read_text())
assert static_before==static_after
normalized_file=normalization['file']
assert normalization['canonical_ast_equal'] is True and normalization['parser_diagnostics']==[0,0]
assert reference[normalized_file]==normalization['before_sha256']
assert static_before[normalized_file]==normalization['after_sha256']
assert [p for p in sorted(reference.keys()|static_before.keys()) if reference.get(p)!=static_before.get(p)]==[normalized_file]
assert git('diff','--name-only',SOURCE,'HEAD')==normalized_file
assert not git('status','--porcelain','--untracked-files=no')
members={}
def add(path,name):
 path=Path(path)
 assert path.is_file(),path
 assert name not in members,name
 members[name]=path.read_bytes()
for name,folder in COHORT_PATHS.items():
 for path in sorted(folder.glob(name+'.*')):add(path,'final/'+path.name)
for path in sorted((OUT/'serial').glob('*')):
 if path.is_file() and not any(path.name.startswith(name+'.') for name in {'editor','studio','incoming-mail'}):add(path,'attempts/pre-format-static/'+path.name)
for path in sorted((OUT/'normalized').glob('*')):
 if path.is_file():add(path,'final/'+path.name)
for path in sorted((OUT/'format-normalization').glob('*')):
 if path.is_file():add(path,'format-normalization/'+path.name)
for name in ['static_checks.py','static_checks_serial.py','static_checks_normalized.py','parallel-interruption.json']:
 add(OUT/name,'runners/'+name)
for name in ['editor','studio','incoming-mail','static']:
 for path in sorted(OUT.glob(name+'.*')):add(path,'attempts/parallel/'+path.name)
for name in ['analyze.stdout','analyze.stderr','format.stdout','format.stderr','diff.stdout','diff.stderr']:
 p=OUT/name
 if p.is_file():add(p,'attempts/parallel/'+name)
for p in sorted((SCRATCH/'docx-dev').iterdir()):
 if p.is_file():add(p,'development/docx/'+p.name)
for p in sorted(SCRATCH.glob('odt-outline-tests*')):
 if p.is_file():add(p,'development/odt/'+p.name)
for pattern in ['zotero-converter-controller-*.log','zotero-independent-*']:
 for p in sorted(SCRATCH.glob(pattern)):
  if p.is_file():add(p,'independent/'+p.name)
for name in ['evidence.tar.xz','summary.json','README.md','evidence-index.json','artifact-receipt.json','late-evidence.tar.xz','late-summary.json','late-README.md','late-evidence-index.json','late-artifact-receipt.json']:
 p=SCRATCH/'incoming-qualification'/name
 if p.is_file():add(p,'incoming/'+name)
for name in ['runtime.json','readiness.json','official-release.json','pub-cache-receipt.json','manifest-before.json','manifest-after.json','env.sh']:
 p=SCRATCH/'toolchains'/name
 if p.is_file():add(p,'runtime/'+name)
for name in ['flutter-tools-pub-get.log','workspace-pub-get.log','flutter-version.log','engine-direct-smoke.jsonl','engine-direct-smoke.stderr','flutter-smoke.jsonl','flutter-smoke.stderr','engine-smoke.jsonl','engine-smoke.stderr']:
 p=SCRATCH/'toolchains/logs'/name
 if p.is_file():add(p,'runtime/logs/'+name)
add(DEST/'run_checks.py','runners/run_checks.py')
add(Path(__file__),'runners/build_evidence.py')
index=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(members.items())]
archive=DEST/'local-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
(DEST/'evidence-index.json').write_text(json.dumps({'archive':'local-evidence.tar.xz','members':index},indent=2)+'\n')
runtime=json.loads((SCRATCH/'toolchains/runtime.json').read_text())
summary={'qualified_source_commit':git('rev-parse','HEAD'),'qualified_source_tree':git('rev-parse','HEAD^{tree}'),'functional_test_source_commit':SOURCE,'functional_test_source_tree':git('rev-parse',SOURCE+'^{tree}'),'source_normalization':normalization,'source_input_count':len(reference),'all_functional_cohorts_share_unchanged_inputs':True,'created_at_unix':time.time(),'cohorts':{name:{k:receipt[k] for k in ['passed','failed','skipped','exit_code','input_count','changed_inputs','accepted','reporter_sha256','stderr_sha256']}|{'suite_count':len(receipt['suites']),'receipt':'final/'+name+'.receipt.json'} for name,receipt in receipts.items()},'visible_passed_total':sum(r['passed'] for r in receipts.values()),'distinct_suites':len(unique_suites),'failed':0,'skipped':0,'static':{'source_commit':static['source_commit'],'accepted':static['accepted'],'changed_dart_files':len(static['dart_files']),'checks':static['checks'],'receipt':'final/static.receipt.json'},'runtime':runtime['runtime'],'sdk_archive':runtime['archive'],'real_sqlite':receipts['incoming-store'].get('sqlite_library'),'lockfile_sha256':digest(ROOT/'pubspec.lock'),'evidence':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':digest(archive),'members':len(index)},'excluded_from_acceptance':['Runtime smoke and all development/incoming diagnostic reruns.','Interrupted concurrent editor, Studio, Mail and static attempt; compiler exit, timeout and startup-lock diagnostics retained.','The initial completed static check failed only formatting. The one pinned-formatter constructor-wrap/optional-comma normalization has identical canonical syntax; all final static gates were rerun on the normalized source.','Installed Zotero/Word/LibreOffice plugin sessions and new converter executions were not performed.'],'known_boundaries':['Retained DOCX table-cell to editable ODT reopen still refuses visible table borders.','Unknown/revision-bearing/locked/malformed field semantics remain guarded; ambiguous revision persistence guards remain.','Numbered/positioned outlines, shading-only declarations, nonzero shading, richer table/layout/style/list forms remain outside the qualified input contract.']}
(DEST/'qualification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['qualified_source_commit','source_input_count','visible_passed_total','distinct_suites','evidence']},indent=2))
