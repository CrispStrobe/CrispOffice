import 'dart:convert';

import 'package:quds_office_engine/quds_office_engine.dart';

void require(bool condition, String message) {
  if (!condition) throw StateError(message);
}

ZoteroCitation citation() => ZoteroCitation(
  citationId: 'independent-guard-review',
  plainCitation: '(Original)',
  items: [
    ZoteroCitationItem.fromCsl(
      itemData: {'type': 'book', 'title': 'Independent revision review'},
      uris: ['http://zotero.org/users/42/items/ABCD1234'],
    ),
  ],
);

WmlDocument source({String? properties, String? marker}) => WmlDocument(
  sections: [
    WmlSection(
      blocks: [
        WmlParagraph(
          inlines: [
            WmlRun(text: 'Before '),
            WmlFieldBoundary(
              kind: WmlFieldBoundaryKind.begin,
              sourceXml: marker,
            ),
            WmlFieldBoundary(
              kind: WmlFieldBoundaryKind.instruction,
              text: citation().fieldInstruction,
              runPropertiesXml: properties,
            ),
            WmlFieldBoundary(kind: WmlFieldBoundaryKind.separate),
            WmlRun(text: '(Original)'),
            WmlFieldBoundary(kind: WmlFieldBoundaryKind.end),
            WmlRun(text: ' After'),
          ],
        ),
      ],
    ),
  ],
);

WmlDocument withRevision() {
  final package = WordSerializer().write(source());
  final part = package.getPart('/word/document.xml')!;
  part.writeText(
    part.readText().replaceFirst(
      '</w:instrText></w:r>',
      '</w:instrText></w:r><w:r><w:rPr><w:b/>'
          '<w:rPrChange w:id="17" w:author="Reviewer">'
          '<w:rPr><w:i/></w:rPr></w:rPrChange></w:rPr></w:r>',
    ),
  );
  return WordDeserializer().read(package);
}

Map<String, Object> guards(WmlDocument document) => {
  'nativeCanEdit': WordZotero.fields(document).single.canEdit,
  'ordinaryCanEdit': WordFieldSpans.zoteroCitations(
    document.paragraphs.single,
  ).single.canEdit,
  'clonedParagraphCanEdit': WordFieldSpans.zoteroCitations(
    WmlClone.paragraph(document.paragraphs.single),
  ).single.canEdit,
  'revisions': document.revisions.length,
};

void main() {
  final observations = <Map<String, Object?>>[];
  var pending = withRevision();
  for (var cycle = 0; cycle < 3; cycle++) {
    final state = guards(pending);
    require(state['nativeCanEdit'] == false, 'Native guard disappeared');
    require(state['ordinaryCanEdit'] == false, 'Ordinary guard disappeared');
    require(state['clonedParagraphCanEdit'] == false, 'Clone lost provenance');
    require(state['revisions'] == 1, 'Pending history changed');
    final field = WordZotero.fields(pending).single;
    final inlines = field.paragraph.inlines.toList();
    final history = WordRevisions.capture(pending);
    for (final whole in [false, true]) {
      var refused = false;
      try {
        WmlRunEdit.replaceRange(
          field.paragraph,
          field.start + (whole ? 0 : 1),
          field.end - (whole ? 0 : 1),
          whole ? '' : 'changed',
        );
      } on UnsupportedError {
        refused = true;
      }
      require(refused, 'Pending code revision allowed ordinary replacement');
      require(history.matches(pending), 'Refusal altered revision history');
      require(
        inlines.length == field.paragraph.inlines.length &&
            Iterable<int>.generate(inlines.length).every(
              (i) => identical(inlines[i], field.paragraph.inlines[i]),
            ),
        'Refusal altered field envelope',
      );
    }
    final saved = WordSerializer().write(pending);
    require(
      RegExp(r'<w:rPrChange\b')
              .allMatches(saved.getPart('/word/document.xml')!.readText())
              .length ==
          1,
      'Pending history was lost or duplicated',
    );
    observations.add({'case': 'pending', 'cycle': cycle, ...state});
    pending = WordDeserializer().read(saved);
  }
  for (final accept in [true, false]) {
    var resolved = withRevision();
    final revision = resolved.revisions.single;
    if (accept) {
      WordRevisions.accept(resolved, revision);
    } else {
      WordRevisions.reject(resolved, revision);
    }
    for (var cycle = 0; cycle < 3; cycle++) {
      final state = guards(resolved);
      require(state['nativeCanEdit'] == true, 'Resolved native guard remained');
      require(state['ordinaryCanEdit'] == true, 'Resolved ordinary guard remained');
      require(state['clonedParagraphCanEdit'] == true, 'Resolved clone remained guarded');
      require(state['revisions'] == 0, 'Resolved history reappeared');
      final empty = resolved.paragraphs.single.inlines
          .whereType<WmlRun>()
          .singleWhere((run) => run.text.isEmpty);
      require(!empty.properties.hasEmptyFormattingRevision, 'Marker remained');
      require(empty.properties.bold == accept, 'Current bold not resolved');
      require(empty.properties.italic == !accept, 'Prior italic not resolved');
      final saved = WordSerializer().write(resolved);
      require(
        !saved.getPart('/word/document.xml')!.readText().contains('rPrChange'),
        'Resolved native history was resurrected',
      );
      observations.add({
        'case': accept ? 'accepted' : 'rejected',
        'cycle': cycle,
        ...state,
      });
      resolved = WordDeserializer().read(saved);
    }
  }
  for (final entry in <String, WmlDocument>{
    'EOF property attribute': source(properties: '<w:rPr xmlns:w='),
    'EOF marker attribute': source(
      marker: '<w:fldChar xmlns:w="${OfficeNamespaces.w}" w:fldCharType=',
    ),
  }.entries) {
    final state = guards(entry.value);
    require(state['nativeCanEdit'] == false, 'Malformed fragment was editable');
    require(state['ordinaryCanEdit'] == false, 'Malformed fragment bypassed ordinary guard');
    observations.add({'case': entry.key, ...state});
  }
  print(
    const JsonEncoder.withIndent('  ').convert({
      'check': 'independent empty-code revision and malformed EOF guard review',
      'passed': true,
      'observations': observations,
    }),
  );
}
