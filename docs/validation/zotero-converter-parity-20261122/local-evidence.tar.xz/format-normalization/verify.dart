import 'dart:convert';
import 'dart:io';
import 'package:analyzer/dart/analysis/utilities.dart';
import 'package:crypto/crypto.dart';

void main() {
  final directory = Directory('/workspace/scratch/e0e93bd324dd/final-qualification/format-normalization');
  final before = File('${directory.path}/before.dart').readAsStringSync();
  final after = File('${directory.path}/after.dart').readAsStringSync();
  final oldParsed = parseString(content: before, path: 'before.dart', throwIfDiagnostics: true);
  final newParsed = parseString(content: after, path: 'after.dart', throwIfDiagnostics: true);
  final oldCanonical = oldParsed.unit.toSource();
  final newCanonical = newParsed.unit.toSource();
  if (oldCanonical != newCanonical) {
    throw StateError('Formatter changed the canonical syntax tree');
  }
  final result = {
    'file': 'packages/quds_office_editor/example/lib/studio_mail_account_navigation.dart',
    'functional_test_source': '81e9da16f9672530d4b39e9cf6cfec979af12830',
    'before_sha256': sha256.convert(utf8.encode(before)).toString(),
    'after_sha256': sha256.convert(utf8.encode(after)).toString(),
    'canonical_ast_sha256': sha256.convert(utf8.encode(oldCanonical)).toString(),
    'canonical_ast_equal': true,
    'parser_diagnostics': [oldParsed.errors.length, newParsed.errors.length],
    'reviewed_change': 'The pinned Dart formatter wrapped one constructor call and added its optional trailing comma. No other file or statement changed.',
  };
  File('${directory.path}/receipt.json').writeAsStringSync('${const JsonEncoder.withIndent('  ').convert(result)}\n');
  stdout.writeln(jsonEncode(result));
}
