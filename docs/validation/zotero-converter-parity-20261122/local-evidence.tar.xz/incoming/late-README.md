# Bounded late incoming qualification

Captured incoming head: `373b7fe9bcb9c282fb6fe0bfbc7832a87faf2baa`. Parent merged this head and resolved ancestry before these checks. The qualification agent made no commits, pushes, merges, or GitHub Actions requests.

## Accepted results

| Cohort | Suites | Visible passes | Failures / skips |
| --- | ---: | ---: | --- |
| New Split corpus, native integration, CLI | 3 | 373 | 0 / 0 |
| Existing shared strings, text, arrays, dynamic arrays, Join | 11 | 724 | 0 / 0 |
| Final Mail navigation union | 5 | 133 | 0 / 0 |
| New expected-record store transaction suite, real SQLite | 1 | 21 | 0 / 0 |

The accepted late union contains **1,251 distinct cases in 20 files**. This is not additive with earlier incoming checks, red/green repeats, or the parent's later final acceptance. Every accepted runner completed with exit zero, successful JSON `done`, no error or unfinished records, and identical before/after hashes for its selected input scope. The hash scope is stated in each `run.json`; it covers relevant incoming implementation families, manifests, tests, fixtures, and helpers, not the entire compiled-input closure. Concurrent Zotero edits were excluded.

Runtime: official pinned Flutter 3.47.8 / Dart 3.13.7 from the workspace toolchain, locked resolved dependencies. The store test uses command-local `LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libsqlite3.so.0`: real SQLite 3.46.1, SHA256 `317d80bf5d592f98a71e14d2330591d6a339f631f37c5977835af748a1f26715`. It exercises in-memory transactions and actual file close/reopen, including compare-and-refresh rejection, rollback, concurrent completion, and revision persistence. No substitute SQL implementation, dependency edits, or lockfile changes were used.

## Actual integration correction

The incoming implementation added `rememberConnection`, `rememberSelected`, and the transactional store `expectedRecord` parameter but did not call them from the connection hosts. Native IMAP and the EWS/Gmail/Graph shared host still issued an unconditional final `remember`. A shortcut forgotten during the awaited write was therefore recreated; an intervening revision could be overwritten. A prior read-check could not protect that later mutation.

Eight new deterministic widget tests stop precisely at the write, then remove or revise the selected row. All eight initially fail against the uncorrected integrated production source, including an actual non-null recreated row where the expected result is absent. The production correction now compares and refreshes the selected snapshot atomically **before adopting the candidate draft owner**. Rejected completion retires that candidate and preserves the incoming failed-owner recovery path. Ordinary fresh connections still register their account. Legacy custom directories without the optional atomic API retain their existing metadata.

The correction changes two host production files, three existing navigation test files, and a short editor changelog entry. `late-mail-corrections.patch` and `late-mail-correction-inputs.json` record exact changes and frozen hashes. New tests also preserve fresh registration, exact catalog reconnect revision/owner assertions, legacy-directory nonmutation, and stale completion after an awaited directory read.

Two earlier positive fixtures for missing IMAP ports were aligned with the incoming explicit socket-port contract. Raw zero, oversized, noncanonical, and invalid route inputs remain rejected. No production validation was weakened.

## Preserved unsuccessful attempts

- `late-mail`: interrupted after 80 visible passes, no assertion failure, while a later unit-suite load stopped emitting output. This is not accepted as a completed run. The focused unit rerun and final five-suite run completed normally.
- `late-mail-unit-initial`: 35 passes / 2 failures from the previous implicit-port positive fixtures.
- `late-mail-atomic-red`: 0 passes / 8 failures proving the actual late registration race before the production correction.
- `late-mail-atomic-green`: 6 passes / 2 failures after the production correction. These were new test assumptions: EWS has a session lease to invalidate, whereas cloud providers also expose disposable tokens/provider resources. Final tests assert lease invalidation for every provider and cloud resource disposal for Gmail/Graph. No additional production correction was needed for those two failures.

Raw JSON reporters and stderr files are retained for each attempt. Accepted final Mail is `late-mail-final` (133 / 133). No failure log has been rewritten as successful.

## Reproduction and evidence

Source `/workspace/scratch/e0e93bd324dd/toolchains/env.sh`. `late_run.py` records exact runner commands and supports the four bounded cohorts `split`, `shared`, `mail`, and `store`, plus optional `--label`, `--file-filter`, and `--name`. Pure Dart tests use the official VM and the resolved locked `package:test` entrypoint; Flutter uses `flutter test --no-pub`. Each output directory contains selected input hashes, JSON reporters, per-case records, and command/result metadata. Existing output directories are not overwritten.

`late-summary.json` is the machine-readable overall record. `late-evidence-index.json` enumerates archive members and SHA256 values. Parent final acceptance is separate and runs the integrated source after all owners freeze.
