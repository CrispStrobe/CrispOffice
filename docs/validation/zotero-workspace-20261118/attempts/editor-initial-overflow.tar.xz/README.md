# Excluded first complete editor attempt

This run is **not accepted** and its counts are excluded from final acceptance.
The real Flutter process exited **1**. All 18 suites ran and all input guards
passed; 257 substantive cases ended with 252 success and five error results.
There were no skips. The failures exposed narrow-window layout overflows in the catalog/import
tabs after the new selection-review controls were added. Raw events, exact commands,
source/runtime/dependency/workspace snapshots and actual exit are preserved.

## Failures

- expanded catalog options fit a 320.0-pixel window (word_zotero_catalog_query_test.dart).
- empty saved searches remain usable in a narrow viewport (word_zotero_saved_search_test.dart).
- twenty applied tags and paging fit a 320.0-pixel window (word_zotero_tag_filter_test.dart).
- rich review and format limitation fit a narrow viewport (word_zotero_dialog_test.dart).
- dialog, offline import and composer fit a 320 by 640 viewport (word_zotero_dialog_test.dart).

Four failures reported 52 pixels of bottom overflow; offline import/composer reported 16 pixels and identified the Column in word_zotero_dialog.dart.
