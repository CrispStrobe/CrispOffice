# Focused narrow-window regression check — development only

All five previously failing cases across four suites passed with actual process
exit 0 and unchanged-input guards. The exact names and regex are in run.json;
raw machine events, per-case outcomes and input inventories are retained.

This check overlaps the complete editor cohort and is excluded from final totals.
