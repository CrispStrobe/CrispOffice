from pathlib import Path
r=Path('/workspace/scratch/745299cf52c6/integration-repo/packages/quds_office_editor/example/test')

def replace_once(text, old, new):
    if text.count(old) != 1:
        raise RuntimeError(f'Expected one anchor, found {text.count(old)}: {old[:80]}')
    return text.replace(old,new,1)

p=r/'studio_mail_test.dart';s=p.read_text()
anchor="  testWidgets('composing sends the draft and reports success or failure', ("
new='''  testWidgets(
    'SMTP recipient groups stay in the envelope and survive acknowledged retry',
    (tester) async {
      final client = _Client()
        ..onSend = (_) async => throw StateError('controlled send uncertainty');
      await _open(tester, (_) => client);
      await _connect(tester);
      await tester.tap(find.widgetWithText(TextButton, _strings.compose));
      await _pump(tester);
      await tester.enterText(
        _field(_strings.to),
        'primary@Example.invalid; second@example.invalid',
      );
      await tester.tap(find.text(_strings.mailCopyRecipients));
      await _pump(tester);
      await tester.enterText(
        _field(_strings.mailCc),
        'primary@example.invalid, copy@example.invalid',
      );
      await tester.enterText(
        _field(_strings.mailBcc),
        'copy@example.invalid; hidden@example.invalid',
      );
      await tester.enterText(_field(_strings.subject), 'Recipient privacy');
      tester
          .widget<QudsWordEditor>(find.byType(QudsWordEditor))
          .controller
          .insertText('A controlled local host fixture.');
      final send = find.widgetWithText(FilledButton, _strings.send);
      await tester.ensureVisible(send);
      await tester.tap(send);
      await _pump(tester);
      expect(client.sent, hasLength(1));
      expect(find.text(_strings.mailSubmissionUncertain), findsOneWidget);
      await tester.tap(find.widgetWithText(TextButton, _strings.compose));
      await _pump(tester);
      expect(
        tester.widget<TextField>(_field(_strings.mailCc)).controller!.text,
        'primary@example.invalid, copy@example.invalid',
      );
      expect(
        tester.widget<TextField>(_field(_strings.mailBcc)).controller!.text,
        'copy@example.invalid; hidden@example.invalid',
      );
      expect(tester.widget<FilledButton>(send).onPressed, isNull);
      expect(client.sent, hasLength(1));
      client.onSend = null;
      await tester.ensureVisible(find.byType(CheckboxListTile));
      await tester.tap(find.byType(CheckboxListTile));
      await _pump(tester);
      await tester.ensureVisible(send);
      await tester.tap(send);
      await _pump(tester);
      expect(client.sent, hasLength(2));
      expect(client.appendRequests, <bool>[false, false]);
      for (var index = 0; index < client.sent.length; index++) {
        final message = client.sent[index];
        expect(client.recipientLists[index]!.map((entry) => entry.email), [
          'primary@Example.invalid',
          'second@example.invalid',
          'copy@example.invalid',
          'hidden@example.invalid',
        ]);
        expect(message.to!.map((entry) => entry.email), [
          'primary@Example.invalid',
          'second@example.invalid',
        ]);
        expect(message.cc!.map((entry) => entry.email), ['copy@example.invalid']);
        expect(message.bcc, isEmpty);
        expect(message.renderMessage(), isNot(contains('hidden@example.invalid')));
      }
      expect(tester.takeException(), isNull);
      await _close(tester);
    },
  );

'''
s=replace_once(s,anchor,new+anchor);p.write_text(s)

p=r/'studio_mail_ews_test.dart';s=p.read_text()
anchor="  testWidgets(\n    'uncertain submissions retain the draft and require acknowledged retry',"
new='''  testWidgets(
    'EWS host preserves visible groups and hides Bcc from canonical MIME',
    (tester) async {
      late _Provider provider;
      await _show(
        tester,
        (configuration, credentials) =>
            provider = _Provider(configuration, credentials),
      );
      await _connect(tester);
      await tester.tap(find.byTooltip(_strings.compose));
      await _pump(tester);
      await tester.enterText(
        _composerField(_strings.to),
        'primary@Example.test; second@example.test',
      );
      await tester.tap(find.text(_strings.mailCopyRecipients));
      await _pump(tester);
      await tester.enterText(
        _composerField(_strings.mailCc),
        'primary@example.test, copy@example.test',
      );
      await tester.enterText(
        _composerField(_strings.mailBcc),
        'copy@example.test; hidden@example.test',
      );
      await tester.enterText(_composerField(_strings.subject), 'Recipient privacy');
      final send = find.widgetWithText(FilledButton, _strings.send);
      await tester.ensureVisible(send);
      await tester.tap(send);
      await _pump(tester);
      final submitted = provider.submissions.single;
      expect(submitted.envelope.recipients, [
        'primary@Example.test',
        'second@example.test',
        'copy@example.test',
        'hidden@example.test',
      ]);
      final decoded = const QudsMimeCodec().parse(submitted.wire.bytes);
      expect(decoded.status, MailParseStatus.complete);
      expect(decoded.message!.envelope.to.map((entry) => entry.address), [
        'primary@Example.test',
        'second@example.test',
      ]);
      expect(decoded.message!.envelope.cc.map((entry) => entry.address), [
        'copy@example.test',
      ]);
      expect(decoded.message!.envelope.bcc, isEmpty);
      expect(utf8.decode(submitted.wire.bytes), isNot(contains('hidden@example.test')));
      expect(find.text(_strings.ewsSubmissionAccepted), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );

'''
s=replace_once(s,anchor,new+anchor);p.write_text(s)

p=r/'studio_mail_cloud_test.dart';s=p.read_text()
anchor="  testWidgets(\n    'uncertain cloud send retains draft and never automatically resubmits',"
new='''  for (final service in MailCloudService.values) {
    testWidgets(
      '${service.name} host keeps hidden recipients out of canonical MIME',
      (tester) async {
        final harness = _Harness();
        await _show(tester, harness, service: service);
        await _connect(tester);
        await tester.tap(find.byTooltip(_strings.compose));
        await _pump(tester);
        await tester.enterText(
          _composeField(_strings.to),
          'primary@Example.test; second@example.test',
        );
        await tester.tap(find.text(_strings.mailCopyRecipients));
        await _pump(tester);
        await tester.enterText(
          _composeField(_strings.mailCc),
          'primary@example.test, copy@example.test',
        );
        await tester.enterText(
          _composeField(_strings.mailBcc),
          'copy@example.test; hidden@example.test',
        );
        await tester.enterText(_composeField(_strings.subject), 'Recipient privacy');
        final send = find.widgetWithText(FilledButton, _strings.send);
        await tester.ensureVisible(send);
        await tester.tap(send);
        await _pump(tester);
        final submission = harness.provider!.submissions.single;
        expect(submission.envelope.recipients, [
          'primary@Example.test',
          'second@example.test',
          'copy@example.test',
          'hidden@example.test',
        ]);
        final decoded = const QudsMimeCodec().parse(submission.wire.bytes);
        expect(decoded.status, MailParseStatus.complete);
        expect(decoded.message!.envelope.to.map((entry) => entry.address), [
          'primary@Example.test',
          'second@example.test',
        ]);
        expect(decoded.message!.envelope.cc.map((entry) => entry.address), [
          'copy@example.test',
        ]);
        expect(decoded.message!.envelope.bcc, isEmpty);
        expect(utf8.decode(submission.wire.bytes), isNot(contains('hidden@example.test')));
        expect(find.text(_strings.mailCloudSubmissionAccepted), findsOneWidget);
        expect(tester.takeException(), isNull);
      },
    );
  }

'''
s=replace_once(s,anchor,new+anchor);p.write_text(s)
print('Added SMTP, EWS, Gmail and Microsoft365 host recipient privacy regressions.')
