# Captured late integration review

Both exact branch snapshots captured at **2026-11-19 21:12:09 UTC** are integrated with real Git ancestry. Focused slide qualification passed **105 distinct tests: 68 engine and 37 editor**, with no failures or skips. All seven static gates passed. The earlier progress aggregate of 103 was an arithmetic typo; the raw reporter identities confirm 105.

## Ancestry and published tree

| Role | Exact commit |
| --- | --- |
| Baseline | `9dbba0f7b6581aba4d7a26f7f69ff6492c02b760` |
| Captured Zotero | `780422316b4e37989e01ac871dd2956fbd2c8908` |
| Captured mail | `658095574de89cf3d6f3dfc874fab7e5c479b47e` |
| First local merge | `518074cf4ccdec288d18e1dabc29021837922d1d` |
| Second local merge | `c8ea0e97e665b563a4d59c057841082d04045a41` |
| Published union | `c1b98f12f802863fb602e9919ead524891bfbcc6` |

The published union and second local merge have identical tree `7a212957276dcf1ef9836c648b6b2d24c5409f7b`. The published commit has the baseline and both captured heads as parents; local read-only ancestry checks confirm all three are ancestors. Local worktree refs were not moved after qualification began.

## Reconciliation decisions

- Preserve both branches' feature descriptions and the validated VBA/slide fix entries. Paths: `packages/quds_office_editor/CHANGELOG.md`, `packages/quds_office_engine/CHANGELOG.md`.
- Keep one non-mutating resolvedRichText projection applying scalar edits to copied rich runs. Retain imported run snapshots for undo, paragraph defaults and hasCurrentRichText compatibility getter; discard the duplicate getter introduced by the second merge. Paths: `packages/quds_office_engine/lib/src/slide/model/pml_presentation.dart`.
- Keep native 16pt fallback and paragraph font defaults. Retain explicit-ink adaptation only for a proven solid backing and preserve authored ink on ambiguous backing. Share the incoming _shapeTextOrigin between rich-text paint and hit testing. Paths: `packages/quds_office_editor/lib/src/editor_slide/render_slide_stage.dart`.
- Combine incoming white-paper adaptation with the explicit adaptDocumentColors opt-out: white maps to theme paper when enabled and stays authored white when disabled. Modify only our added white-paper case to test the opt-out; keep the incoming dark/high-contrast case and every original exact-color assertion. Paths: `packages/quds_office_editor/lib/src/editor_slide/render_slide_stage.dart`, `packages/quds_office_editor/test/office_dark_slide_test.dart`.
- Keep resolvedRichText/paragraph defaults; preserve incoming tabBase calculation. Use the incoming shared _slideBackground helper in slide and notes-page PDF paths for explicit-slide/master fallback. Paths: `packages/quds_office_engine/lib/src/pdf/office_pdf_export.dart`.
- Preserve incoming explicit b=0/i=0 parsing so explicit normal styles override paragraph defaults. Paths: `packages/quds_office_engine/lib/src/slide/shapes/slide_rich_text.dart`.
- Preserve incoming inheritsMasterBackground constructor/copy/parser/controller behavior. Prevent explicit post-construction background assignment from staying inherited: the public setter detaches nonempty fills and re-enables inheritance for empty fills, while updateMasterBackground changes only inherited resolved color without detaching it. Strengthen the master-paper test for consecutive updates, explicit assignment, and clearing back to inheritance. Paths: `packages/quds_office_engine/lib/src/slide/model/pml_presentation.dart`, `packages/quds_office_engine/lib/src/slide/serial/slide_serial.dart`, `packages/quds_office_editor/lib/src/embed/office_controller.dart`, `packages/quds_office_editor/test/office_dark_slide_test.dart`.

The original six dark-slide assertions were retained unchanged. Removing only the added five-test block reproduces the original main test file byte for byte, SHA256 `00e384eac7c2e1d3ce8d423d7e3ceafbc6beb28fdddfe704ce06ac2e20e81b85`.

## Source binding and checks

The test guard hashed 534 source/test/config inputs before and after execution; no input changed. The guard still matches at review completion. The exact working bytes differ from the published union in two scoped files only: Dart formatter line wrapping in `slide_serial.dart` and `office_dark_slide_test.dart`. Those deltas existed before the tests. The complete patch and file hashes are included in the JSON receipt. Root published those exact bytes plus separately validated mail host regression tests in checkpoint `8356fb0ad4630824a39453ea9a5923d9fb2a2101`, tree `ff86534f86007d4a64962d2b2cb4f0ab339d6996`. A read-only whole-worktree comparison confirms every tracked working byte matches that checkpoint; no source edit occurred between tests and publication.

| Gate | Result |
| --- | --- |
| Eight engine suites | 68 passed, 0 failed, 0 skipped |
| Three editor suites | 37 passed, 0 failed, 0 skipped |
| Whole engine strict analysis | Exit 0 |
| Renderer and controller strict analysis | Exit 0 for both |
| Dark-slide and render-fidelity test strict analysis | Exit 0 for both |
| Dart format check on 12 selected files | Exit 0, no changes required |
| Scoped Git whitespace check | Exit 0 |

Exact test commands follow; source the pinned runtime environment before running either.

```sh
. /workspace/scratch/745299cf52c6/runtime/env.sh
cd /workspace/scratch/745299cf52c6/integration-repo/packages/quds_office_engine
dart --packages=../../.dart_tool/package_config.json /workspace/scratch/745299cf52c6/runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart --concurrency=2 --reporter=json test/slide_import_fidelity_test.dart test/slide_text_fidelity_test.dart test/slide_test.dart test/office_pdf_export_test.dart test/pdf_image_interlace_test.dart test/visual_test.dart test/slide_render_fidelity_test.dart test/slide_rich_text_explicit_style_test.dart
cd /workspace/scratch/745299cf52c6/integration-repo/packages/quds_office_editor
flutter test --no-pub --concurrency=2 --reporter=json test/office_dark_slide_test.dart test/slide_arrange_history_test.dart test/slide_render_fidelity_test.dart
```

There were two test invocations in this late slide qualification, both successful, with no interrupted attempt. Earlier incoming-PPTX evidence remains separately attributed: original main passed all six dark-slide controls; the incoming editor baseline passed 26 and failed two; the repaired checkpoint passed 58 engine and 30 editor tests. The earlier interrupted empty-log startup established no test result or product failure. Other discarded/intermediate attempts and their logs remain in `incoming-review.json`; they are not hidden or counted as this union's acceptance.

## Macro validation boundary

All 34 tracked engine automation and sheet library source files are byte-identical to baseline `9dbba0f7b6581aba4d7a26f7f69ff6492c02b760`. The late merge changes PML model/serialization and native presentation publication. Root's compact post-union selection is appropriate: native operations/runtime/MCP/steps, new dynamic-array unit and integration tests, the exact Word-plus-presentation CLI case, general native web smoke, and dynamic-array VM/web comparison. This review does not claim their results.

**The prior 675-case macro acceptance is bound to the original 9dbba0f7 checkpoint. It is not a 675-case run on the late union.** Mail and Zotero acceptance are owned by their respective reviewers and are not included in the 105 slide cases.

## Evidence

- Machine-readable reconciliation: `/workspace/scratch/745299cf52c6/late-integration-review.json` (SHA256 `5cfd8d6e1906c1bc15437899e87a181fa32963d8b1e7c2863ed3b3f678990e9f`).
- Source guards, test commands and raw-log bindings: `/workspace/scratch/745299cf52c6/late-slide-validation/receipt.json`.
- Static command receipts: `/workspace/scratch/745299cf52c6/late-slide-validation/static-checks.json`.
- Raw reporter logs: `/workspace/scratch/745299cf52c6/late-slide-validation/engine.jsonl` and `/workspace/scratch/745299cf52c6/late-slide-validation/editor.jsonl`.
- Formatting delta: `/workspace/scratch/745299cf52c6/late-slide-validation/formatting-only-delta.patch`.

This is focused local engine/Flutter qualification. No full application build or external Microsoft Office run is claimed. No GitHub Actions workflow, check, or status endpoint was queried, awaited, or rerun. Branch capture was finite at the stated cutoff.
