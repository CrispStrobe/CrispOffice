import 'dart:convert';
import 'dart:io';
import 'package:analyzer/dart/analysis/utilities.dart';
void main(List<String> args) {
  final results = <Map<String, Object>>[];
  for (final path in args.skip(2)) {
    final before = parseString(content: File('${args[0]}/$path').readAsStringSync());
    final after = parseString(content: File('${args[1]}/$path').readAsStringSync());
    final equal = before.unit.toSource() == after.unit.toSource();
    results.add({'path': path, 'astToSourceEqual': equal,
      'beforeParseErrors': before.errors.length, 'afterParseErrors': after.errors.length});
    if (!equal || before.errors.isNotEmpty || after.errors.isNotEmpty) exitCode = 1;
  }
  stdout.writeln(jsonEncode(results));
}
