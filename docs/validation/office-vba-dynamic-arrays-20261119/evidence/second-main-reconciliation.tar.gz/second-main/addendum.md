# Second advanced-main reconciliation

Merged captured main `057fdb9325ec2f93d2ac0592217da8ad350b0664` with the preserved evidence checkpoint `cf6fb0b0f0d5c4ba1aa5ebf1f318e114eff3af15`. Local commit `636dd5ea8826224365316762636e08595f28af42`, tree `38a287a6e9179f2d0ed02f83f036f71fc11ef13c`, retains both as parents. The worktree is clean.

The incoming mail continuation already includes the qualified functionality. Of 24 differing Dart files, 21 have identical canonical parser output. The remaining differences were reviewed explicitly: the alternate rich-text projection changes the empty-list reference/mutability edge and duplicates run copying, so the qualified implementation is retained; the renderer only renames a local variable/rewords a comment; the dark-slide file reorders existing tests and adds two useful assertions. Those assertions are now retained in our existing tests.

All 5,645 non-document entries except the single dark-slide test file have exactly the qualified `435bc212401db13efa56483ac852e4bc25bcc5d2` modes/types/blobs. All implementation, dependencies, configuration, fixtures and other tests remain unchanged. Product-manifest SHA256: `d6f5a2bb46c5dcc13fc1bae70b35e8a77700dafc4ed55f8f17c9c6a021554356`. The original six dark-slide assertions remain unchanged.

The **11-case dark-slide file passed**, with no failures/skips, after adding explicit-white controller preservation and high-contrast adaptation opt-out checks. Scoped strict analysis, formatting and whitespace checks passed; all 629 guarded inputs stayed unchanged. These 11 cases overlap the earlier 107-case result and are not counted as 11 additional distinct cases. No other tests were rerun.

All previous evidence remains byte-identical except the combined mail README, which retains both authors' records and clearly separates their execution scope. All 91 newly imported main documentation/evidence files retain exact main blobs, and all 93 incoming mail evidence entries other than that merged README are preserved. The two original README files are retained beside this receipt for archival.

The exact source exception, raw test/analysis records, parser comparison, ancestry and evidence checks are in `addendum.json` (SHA256 `c9f5cd1890b1052257e15d0d697fa89037d0e8d73c4bdac53fdb6a1375afd35d`). No GitHub Actions endpoint was used.
