#!/usr/bin/env python3
"""Qualify macro/native boundaries affected by the captured source union."""
import importlib.util
import json
from pathlib import Path
import subprocess

BASE = Path('/workspace/scratch/745299cf52c6')
spec = importlib.util.spec_from_file_location('macro_receipts', BASE / 'final-macro/qualify.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
q.ROOT = BASE / 'integration-repo'
q.ENGINE = q.ROOT / 'packages/quds_office_engine'
q.CONFIG = q.ROOT / '.dart_tool/package_config.json'
q.WORKFLOW = q.ROOT / '.github/workflows/office-macros.yml'
q.OUT = BASE / 'post-union-macro'
q.SELECTED = [
    'test/office_operations_test.dart',
    'test/office_macro_runtime_test.dart',
    'test/office_macro_mcp_test.dart',
    'test/office_steps_test.dart',
    'test/office_vba_dynamic_arrays_test.dart',
    'test/office_vba_dynamic_arrays_integration_test.dart',
    'test/office_macro_cli_test.dart',
]
q.SMOKES = ['tool/macros/web_smoke.dart', 'tool/macros/web_vba_dynamic_arrays_smoke.dart']


def report(name):
    starts, suites, done, errors, non_json = {}, {}, {}, [], []
    final = None
    for line in (q.OUT / (name + '.stdout.log')).read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            non_json.append(line)
            continue
        kind = event.get('type')
        if kind == 'suite':
            suites[event['suite']['id']] = event['suite']
        elif kind == 'testStart':
            starts[event['test']['id']] = event['test']
        elif kind == 'testDone':
            done[event['testID']] = event
        elif kind == 'error':
            errors.append(event)
        elif kind == 'done':
            final = event
    cases = []
    for tid, event in done.items():
        if not event.get('hidden'):
            test = starts[tid]
            cases.append({'path': suites[test['suiteID']]['path'], 'name': test['name'],
                          'result': event['result'], 'skipped': event['skipped']})
    result = {'cases': cases, 'counts': {
        'passed': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
        'failed': sum(c['result'] != 'success' and not c['skipped'] for c in cases),
        'skipped': sum(c['skipped'] for c in cases)},
        'errors': errors, 'non_json': non_json, 'done': final}
    result['accepted'] = bool(cases and final and final.get('success') and
        not errors and not non_json and result['counts']['failed'] == 0 and result['counts']['skipped'] == 0)
    q.save(name + '-acceptance.json', result)
    print(json.dumps({'gate': name, 'accepted': result['accepted'], 'counts': result['counts']}), flush=True)
    if not result['accepted']:
        raise SystemExit(name + ' did not pass')
    return result


before = q.inventory()
q.save('source-before.json', before)
q.save('selection.json', {
    'remote_union_commit': 'c1b98f12f802863fb602e9919ead524891bfbcc6',
    'remote_union_tree': '7a212957276dcf1ef9836c648b6b2d24c5409f7b',
    'local_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=q.ROOT, text=True).strip(),
    'working_deltas': subprocess.check_output(['git', 'status', '--short'], cwd=q.ROOT, text=True).splitlines(),
    'selected_tests': q.SELECTED,
    'smokes': q.SMOKES,
    'purpose': 'Qualify changed PML serialization/native publication plus dynamic-array CLI/MCP behavior after the concurrent-source union; no claim that all 675 prior cases ran on this union.',
})
common = [q.DART, '--packages=' + str(q.CONFIG), q.TEST]
options = ['--concurrency', '1', '--timeout', '4x', '--reporter', 'json']
core = q.run([*common, *q.SELECTED[:-1], *options], 'core')
if core['exit_code'] != 0:
    report('core')
    raise SystemExit('core exit status')
core_result = report('core')
cli = q.run([*common, q.SELECTED[-1], '--plain-name',
             'Word and presentation examples use the same runnable macro format', *options], 'cli')
cli_result = report('cli')
if cli['exit_code'] != 0:
    raise SystemExit('CLI exit status')

(q.OUT / 'web').mkdir(exist_ok=True)
programs = []
for source in q.SMOKES:
    name = Path(source).stem
    output = q.OUT / 'web' / (name + '.js')
    compiled = q.run([q.DART, 'compile', 'js', '-O1', '--packages=' + str(q.CONFIG), source, '-o', output], 'web/' + name + '-compile')
    if compiled['exit_code'] != 0:
        raise SystemExit('compile failed: ' + name)
    run = q.run(['node', '-e', 'globalThis.self = globalThis; require(' + json.dumps(str(output)) + ')'], 'web/' + name + '-run')
    if run['exit_code'] != 0:
        raise SystemExit('web failed: ' + name)
    assertions = json.loads((q.OUT / ('web/' + name + '-run.stdout.log')).read_text())
    if not assertions or any(isinstance(x, bool) and not x for x in assertions.values()):
        raise SystemExit('false assertions: ' + name)
    if name == 'web_vba_dynamic_arrays_smoke':
        if assertions.get('passed') != 27 or len(set(assertions.get('checks', []))) != 27:
            raise SystemExit('missing dynamic assertions')
        vm = q.run([q.DART, '--packages=' + str(q.CONFIG), source], 'web/' + name + '-vm')
        vm_assertions = json.loads((q.OUT / ('web/' + name + '-vm.stdout.log')).read_text())
        if vm['exit_code'] != 0 or assertions != vm_assertions:
            raise SystemExit('VM/JavaScript mismatch')
    elif assertions.get('revision', 0) < 1:
        raise SystemExit('missing native publication')
    programs.append({'source': source, 'assertions': assertions,
                     'source_sha256': q.digest(q.ENGINE / source),
                     'javascript_sha256': q.digest(output)})
    print(json.dumps({'web': name, 'accepted': True}), flush=True)
after = q.inventory()
q.save('source-after.json', after)
guard = q.stable(before, after)
q.save('source-guard.json', guard)
receipt = {'accepted': guard['unchanged'], 'source_guard': guard,
           'distinct_test_cases': core_result['counts']['passed'] + cli_result['counts']['passed'],
           'core_counts': core_result['counts'], 'cli_counts': cli_result['counts'],
           'programs': programs, 'dynamic_vm_javascript_equal': True}
q.save('receipt.json', receipt)
print(json.dumps({k:v for k,v in receipt.items() if k != 'programs'}), flush=True)
if not guard['unchanged']:
    raise SystemExit('source changed')
