#!/usr/bin/env python3
"""Retry only observed timed-out cases, preserving the original complete run."""
import json
from pathlib import Path
import qualify as q

summary = json.loads((q.OUT / 'test-summary.json').read_text())
cases = json.loads((q.OUT / 'test-cases.json').read_text())
failed = [case for case in cases if case['result'] != 'success' and not case['skipped']]
timeout_ids = {event['testID'] for event in summary['error_events'] if event['error'].startswith('TimeoutException after ')}
assert failed and {case['id'] for case in failed} == timeout_ids
assert not summary['skipped'] and not summary['non_json_lines']
before = q.inventory()
original = json.loads((q.OUT / 'source-before.json').read_text())
assert q.stable(original, before)['unchanged']
q.save('source-before-retries.json', before)
(q.OUT / 'retries').mkdir(exist_ok=True)
q.save('retries/cleanup-evidence.json', {
    'original_runner_finished': True,
    'original_exit_code': json.loads((q.OUT / 'tests.json').read_text())['exit_code'],
    'test_ids': sorted(timeout_ids),
    'observed_child_completion': (
        'Each timed-out case subsequently emitted a late exit-code assertion '
        'after both BAS and native CLI Process.run Futures had completed. '
        'The source awaits both processes before these assertions. All earlier '
        'compile/validate subprocesses in those cases were also awaited. '
        'The fixture PathNotFound errors are retained in the original raw log.'
    ),
    'inspection_limit': 'Separate executor invocations have distinct process namespaces; no cross-namespace PID visibility is claimed.',
    'processes_killed': [],
})

retried = []
for index, case in enumerate(failed, 1):
    source_path = Path(case['path'])
    path = str(source_path.relative_to(q.ENGINE) if source_path.is_absolute() else source_path)
    command = [q.DART, '--packages=' + str(q.CONFIG), q.TEST, path,
               '--plain-name', case['name'], '--timeout', '4x',
               '--concurrency', '1', '--reporter', 'json']
    name = 'retries/case-' + str(index)
    receipt = q.run(command, name)
    events = [json.loads(line) for line in (q.OUT / (name + '.stdout.log')).read_text().splitlines()]
    tests = {event['test']['id']: event['test'] for event in events if event.get('type') == 'testStart'}
    outcomes = [event for event in events if event.get('type') == 'testDone' and not event.get('hidden')]
    errors = [event for event in events if event.get('type') == 'error']
    finished = [event for event in events if event.get('type') == 'done']
    accepted = (receipt['exit_code'] == 0 and len(outcomes) == 1 and not errors
                and outcomes[0]['result'] == 'success' and not outcomes[0]['skipped']
                and tests[outcomes[0]['testID']]['name'] == case['name']
                and len(finished) == 1 and finished[0]['success'])
    record = {'original_case': case, 'accepted': bool(accepted), 'outcomes': outcomes,
              'errors': errors, 'final': finished, 'receipt': name + '.json'}
    q.save(name + '-result.json', record)
    retried.append(record)
    print(json.dumps({'case': case['name'], 'accepted': bool(accepted)}), flush=True)
    if not accepted:
        raise SystemExit('Isolated timeout retry did not pass')

after = q.inventory()
q.save('source-after-retries.json', after)
guard = q.stable(before, after)
q.save('retry-source-guard.json', guard)
accepted = guard['unchanged'] and all(record['accepted'] for record in retried)
q.save('final-selected-acceptance.json', {
    'accepted': accepted,
    'source_head': json.loads((q.OUT / 'selection.json').read_text())['source_head'],
    'distinct_passed': summary['passed'] + len(retried),
    'distinct_failed': 0 if accepted else len(failed),
    'distinct_skipped': summary['skipped'],
    'original_attempt': {
        'passed': summary['passed'], 'failed': summary['failed'], 'skipped': summary['skipped'],
        'raw_stdout': 'tests.stdout.log', 'raw_stderr': 'tests.stderr.log',
        'summary': 'test-summary.json',
    },
    'isolated_timeout_retries': retried,
    'claim': 'Distinct cases accepted across the original selection and isolated retries; not an uninterrupted clean run.',
    'source_guard': guard,
})
print(json.dumps({'accepted': accepted, 'distinct_passed': summary['passed'] + len(retried), 'source_guard': guard}), flush=True)
if not accepted:
    raise SystemExit(1)
