#!/usr/bin/env python3
"""Run the committed macro selection and portable smoke programs locally."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time
from urllib.parse import unquote, urlparse

ROOT = Path('/workspace/scratch/745299cf52c6/quds_office_suite')
ENGINE = ROOT / 'packages/quds_office_engine'
OUT = Path('/workspace/scratch/745299cf52c6/final-macro')
DART = Path('/workspace/scratch/745299cf52c6/runtime/flutter/bin/cache/dart-sdk/bin/dart')
TEST = Path('/workspace/scratch/745299cf52c6/runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart')
CONFIG = ROOT / '.dart_tool/package_config.json'
WORKFLOW = ROOT / '.github/workflows/office-macros.yml'
WORKFLOW_TEXT = WORKFLOW.read_text()
SELECTED = re.findall(r'^\s+(test/[^\s]+\.dart)\s*$', WORKFLOW_TEXT, flags=re.M)
SMOKES = re.findall(r'dart compile js -O1 (tool/macros/[^\s]+\.dart) -o', WORKFLOW_TEXT)
assert len(SELECTED) == len(set(SELECTED)) == 26
assert len(SMOKES) == len(set(SMOKES)) == 6


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory():
    paths = set()
    for base in [
        ENGINE / 'lib',
        ENGINE / 'tool/macros',
        ENGINE / 'example/macros',
        ENGINE / 'test/fixtures',
        ROOT / 'packages/legacy_doc_parser/lib',
    ]:
        paths.update(p for p in base.rglob('*') if p.is_file())
    paths.update(ENGINE / p for p in SELECTED)
    paths.update([
        ROOT / '.fvmrc', WORKFLOW, ROOT / 'pubspec.yaml', ROOT / 'pubspec.lock',
        ROOT / 'analysis_options.yaml', CONFIG,
    ])
    for optional in [ROOT / '.dart_tool/package_graph.json', ENGINE / 'analysis_options.yaml']:
        if optional.is_file():
            paths.add(optional)
    config = json.loads(CONFIG.read_text())
    for package in config['packages']:
        uri = package['rootUri']
        package_root = Path(unquote(urlparse(uri).path)) if uri.startswith('file:') else (CONFIG.parent / uri).resolve()
        try:
            package_root.relative_to(ROOT)
        except ValueError:
            continue
        manifest = package_root / 'pubspec.yaml'
        if manifest.is_file():
            paths.add(manifest)
    pending = list(paths)
    while pending:
        path = pending.pop()
        if path.suffix != '.dart':
            continue
        for relative in re.findall(r"(?:import|export|part)\s+['\"]([^'\"]+)['\"]", path.read_text()):
            if ':' in relative:
                continue
            dependency = (path.parent / relative).resolve()
            if dependency.is_file() and dependency not in paths:
                dependency.relative_to(ROOT)
                paths.add(dependency)
                pending.append(dependency)
    files = {}
    for path in sorted(paths):
        files[str(path.relative_to(ROOT))] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
    return {'captured_at': stamp(), 'file_count': len(files), 'files': files}


def stable(before, after):
    changes = [
        p for p in sorted(set(before['files']) | set(after['files']))
        if before['files'].get(p) != after['files'].get(p)
    ]
    return {'unchanged': not changes, 'changed_paths': changes, 'file_count': after['file_count']}


def run(command, name, cwd=ENGINE):
    start = time.monotonic()
    receipt = {'argv': [str(x) for x in command], 'cwd': str(cwd), 'started_at': stamp()}
    (OUT / (name + '.command.txt')).write_text(shlex.join(receipt['argv']) + '\n')
    with (OUT / (name + '.stdout.log')).open('wb') as stdout, (OUT / (name + '.stderr.log')).open('wb') as stderr:
        process = subprocess.run(receipt['argv'], cwd=cwd, stdout=stdout, stderr=stderr)
    receipt.update({'exit_code': process.returncode, 'ended_at': stamp(), 'elapsed_seconds': round(time.monotonic() - start, 3)})
    for stream in ['stdout', 'stderr']:
        file = OUT / (name + '.' + stream + '.log')
        receipt[stream] = {'path': str(file.relative_to(OUT)), 'bytes': file.stat().st_size, 'sha256': digest(file)}
    save(name + '.json', receipt)
    return receipt


def summarize_tests():
    starts, done, suites, errors, non_json = {}, {}, {}, [], []
    final = None
    for index, line in enumerate((OUT / 'tests.stdout.log').read_text().splitlines(), 1):
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            non_json.append({'line': index, 'text': line})
            continue
        kind = event.get('type')
        if kind == 'suite':
            suites[event['suite']['id']] = event['suite']
        elif kind == 'testStart':
            starts[event['test']['id']] = event['test']
        elif kind == 'testDone':
            done[event['testID']] = event
        elif kind == 'error':
            errors.append(event)
        elif kind == 'done':
            final = event
    cases = []
    for test_id, event in done.items():
        if event.get('hidden'):
            continue
        test = starts[test_id]
        suite = suites[test['suiteID']]
        cases.append({
            'id': test_id, 'name': test['name'], 'path': suite['path'],
            'result': event['result'], 'skipped': event['skipped'],
        })
    unique = {(c['path'], c['name']) for c in cases}
    summary = {
        'distinct_cases': len(unique), 'completed_events': len(cases),
        'passed': sum(c['result'] == 'success' and not c['skipped'] for c in cases),
        'failed': sum(c['result'] != 'success' and not c['skipped'] for c in cases),
        'skipped': sum(c['skipped'] for c in cases),
        'final': final, 'error_events': errors, 'non_json_lines': non_json,
        'selected_files': SELECTED,
    }
    save('test-cases.json', cases)
    save('test-summary.json', summary)
    return summary


def tests():
    before = inventory()
    save('source-before.json', before)
    source_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    versions = {}
    for label, command in [('dart', [str(DART), '--version']), ('node', ['node', '--version'])]:
        version = subprocess.run(command, capture_output=True, text=True)
        versions[label] = (version.stdout + version.stderr).strip()
    save('selection.json', {
        'source_head': source_head, 'selected_tests': SELECTED, 'smoke_programs': SMOKES,
        'workflow_sha256': digest(WORKFLOW), 'versions': versions,
        'package_config_sha256': digest(CONFIG), 'runner_sha256': digest(TEST),
        'runtime_setup_receipt': '/workspace/scratch/745299cf52c6/runtime/runtime.json',
        'compiler_review_clearance': 'runtime_setup: no blocking compiler issues',
        'incoming_source_clearance': 'incoming_audit: engine integration sources stable',
    })
    command = [DART, '--packages=' + str(CONFIG), TEST, *SELECTED, '--timeout', '2m', '--concurrency', '2', '--reporter', 'json']
    receipt = run(command, 'tests')
    after = inventory()
    save('source-after-tests.json', after)
    guard = stable(before, after)
    save('test-source-guard.json', guard)
    summary = summarize_tests()
    passed = receipt['exit_code'] == 0 and guard['unchanged'] and summary['failed'] == 0 and summary['skipped'] == 0 and summary['distinct_cases'] == summary['completed_events'] and summary['final'] and summary['final'].get('success') and not summary['error_events'] and not summary['non_json_lines']
    save('test-acceptance.json', {'accepted': bool(passed), 'summary': summary, 'source_guard': guard})
    print(json.dumps({'accepted': bool(passed), 'passed': summary['passed'], 'failed': summary['failed'], 'skipped': summary['skipped'], 'source_guard': guard}), flush=True)
    if not passed:
        sys.exit(1)


def web():
    before = inventory()
    test_before = json.loads((OUT / 'source-before.json').read_text())
    if not stable(test_before, before)['unchanged']:
        raise SystemExit('Sources changed since the selected test acceptance')
    save('source-before-web.json', before)
    (OUT / 'web').mkdir(exist_ok=True)
    receipts = []
    for source in SMOKES:
        name = Path(source).stem
        output = OUT / 'web' / (name + '.js')
        compiled = run([DART, 'compile', 'js', '-O1', '--packages=' + str(CONFIG), source, '-o', output], 'web/' + name + '-compile')
        if compiled['exit_code'] != 0:
            raise SystemExit('Compile failed: ' + source)
        node = run(['node', '-e', 'globalThis.self = globalThis; require(' + json.dumps(str(output)) + ')'], 'web/' + name + '-run')
        if node['exit_code'] != 0:
            raise SystemExit('Node execution failed: ' + source)
        lines = (OUT / ('web/' + name + '-run.stdout.log')).read_text().splitlines()
        if len(lines) != 1:
            raise SystemExit('Missing or ambiguous assertion receipt: ' + source)
        assertions = json.loads(lines[0])
        if not isinstance(assertions, dict) or not assertions or any(isinstance(value, bool) and not value for value in assertions.values()):
            raise SystemExit('Invalid assertion receipt: ' + source)
        if name == 'web_vba_dynamic_arrays_smoke':
            if assertions.get('suite') != 'vba-dynamic-arrays' or assertions.get('passed') != 27 or len(set(assertions.get('checks', []))) != 27:
                raise SystemExit('Dynamic assertion receipt incomplete')
        elif assertions.get('revision', 0) < 1:
            raise SystemExit('No actual runtime publication receipt: ' + source)
        save('web/' + name + '-assertions.json', assertions)
        receipts.append({
            'source': source, 'source_sha256': digest(ENGINE / source),
            'compiled_javascript': {'bytes': output.stat().st_size, 'sha256': digest(output)},
            'compile_exit': compiled['exit_code'], 'node_exit': node['exit_code'],
            'assertions': assertions,
        })
        print(json.dumps({'program': name, 'accepted': True}), flush=True)
    after = inventory()
    save('source-after-web.json', after)
    guard = stable(before, after)
    save('web-source-guard.json', guard)
    save('web/receipt.json', {'accepted': guard['unchanged'], 'program_count': len(receipts), 'programs': receipts, 'source_guard': guard})
    if not guard['unchanged']:
        raise SystemExit('Source changed during portable acceptance')


if __name__ == '__main__':
    if sys.argv[1:] == ['tests']:
        tests()
    elif sys.argv[1:] == ['web']:
        web()
    else:
        raise SystemExit('Usage: qualify.py tests|web')
