#!/usr/bin/env python3
"""Qualify final merged macro inputs with explicit, verified process roots."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time
from urllib.parse import unquote, urlparse

BASE = Path('/workspace/scratch/745299cf52c6')
ROOT = BASE / 'integration-repo'
ENGINE = ROOT / 'packages/quds_office_engine'
OUT = BASE / 'final-union-macro'
CONFIG = ROOT / '.dart_tool/package_config.json'
DART = BASE / 'runtime/flutter/bin/cache/dart-sdk/bin/dart'
TEST = BASE / 'runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart'
WORKFLOW = ROOT / '.github/workflows/office-macros.yml'
CORE_TESTS = [
    'test/office_operations_test.dart',
    'test/office_macro_runtime_test.dart',
    'test/office_macro_mcp_test.dart',
    'test/office_steps_test.dart',
    'test/office_vba_dynamic_arrays_test.dart',
    'test/office_vba_dynamic_arrays_integration_test.dart',
]
CLI_TEST = 'test/office_macro_cli_test.dart'
CLI_NAME = 'Word and presentation examples use the same runnable macro format'
SMOKES = ['tool/macros/web_smoke.dart', 'tool/macros/web_vba_dynamic_arrays_smoke.dart']


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def inventory():
    paths = set()
    for base in [ENGINE / 'lib', ENGINE / 'tool/macros', ENGINE / 'example/macros',
                 ENGINE / 'test/fixtures', ROOT / 'packages/legacy_doc_parser/lib']:
        paths.update(path for path in base.rglob('*') if path.is_file())
    paths.update(ENGINE / name for name in [*CORE_TESTS, CLI_TEST])
    paths.update([ROOT / '.fvmrc', WORKFLOW, ROOT / 'pubspec.yaml', ROOT / 'pubspec.lock',
                  ROOT / 'analysis_options.yaml', CONFIG])
    for path in [ROOT / '.dart_tool/package_graph.json', ENGINE / 'analysis_options.yaml']:
        if path.is_file():
            paths.add(path)
    workspace_packages = {}
    for package in json.loads(CONFIG.read_text())['packages']:
        uri = package['rootUri']
        package_root = Path(unquote(urlparse(uri).path)) if uri.startswith('file:') else (CONFIG.parent / uri).resolve()
        try:
            package_root.relative_to(ROOT)
        except ValueError:
            continue
        workspace_packages[package['name']] = str(package_root)
        manifest = package_root / 'pubspec.yaml'
        if manifest.is_file():
            paths.add(manifest)
    if workspace_packages.get('quds_office_engine') != str(ENGINE):
        raise SystemExit('The configured engine package is not the integration engine')
    pending = list(paths)
    while pending:
        path = pending.pop()
        if path.suffix != '.dart':
            continue
        for relative in re.findall(r"(?:import|export|part)\s+['\"]([^'\"]+)['\"]", path.read_text()):
            if ':' in relative:
                continue
            dependency = (path.parent / relative).resolve()
            if dependency.is_file() and dependency not in paths:
                dependency.relative_to(ROOT)
                paths.add(dependency)
                pending.append(dependency)
    return {'captured_at': stamp(), 'file_count': len(paths), 'workspace_packages': workspace_packages,
            'files': {str(path.relative_to(ROOT)): {'bytes': path.stat().st_size, 'sha256': sha(path)}
                      for path in sorted(paths)}}


def stable(before, after):
    changes = [path for path in sorted(set(before['files']) | set(after['files']))
               if before['files'].get(path) != after['files'].get(path)]
    return {'unchanged': not changes, 'changed_paths': changes, 'file_count': after['file_count']}


def run(command, name, *, cwd):
    """cwd is mandatory; no default can capture another checkout at import."""
    cwd = Path(cwd).resolve()
    if cwd != ENGINE:
        raise SystemExit('Refusing a macro process outside the integration engine: ' + str(cwd))
    argv = list(map(str, command))
    receipt = {'argv': argv, 'cwd': str(cwd), 'started_at': stamp()}
    base = OUT / name
    base.parent.mkdir(parents=True, exist_ok=True)
    command_path = Path(str(base) + '.command.txt')
    if command_path.exists():
        raise SystemExit('Refusing to overwrite an existing attempt: ' + name)
    command_path.write_text('cwd: ' + str(cwd) + '\n' + shlex.join(argv) + '\n')
    save(name + '-started.json', receipt)
    start = time.monotonic()
    with Path(str(base) + '.stdout.log').open('wb') as stdout, Path(str(base) + '.stderr.log').open('wb') as stderr:
        process = subprocess.run(argv, cwd=cwd, stdout=stdout, stderr=stderr)
    receipt.update({'exit_code': process.returncode, 'ended_at': stamp(), 'elapsed_seconds': round(time.monotonic() - start, 3)})
    for stream in ['stdout', 'stderr']:
        path = Path(str(base) + '.' + stream + '.log')
        receipt[stream] = {'path': str(path.relative_to(OUT)), 'bytes': path.stat().st_size, 'sha256': sha(path)}
    save(name + '.json', receipt)
    print(json.dumps({'command': name, 'exit_code': process.returncode, 'seconds': receipt['elapsed_seconds']}), flush=True)
    return receipt


def report(name, selected, receipt, expected_count=None):
    starts, suites, done, errors, non_json = {}, {}, {}, [], []
    final = None
    for number, line in enumerate((OUT / (name + '.stdout.log')).read_text().splitlines(), 1):
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            non_json.append({'line': number, 'text': line})
            continue
        kind = event.get('type')
        if kind == 'suite':
            suites[event['suite']['id']] = event['suite']
        elif kind == 'testStart':
            starts[event['test']['id']] = event['test']
        elif kind == 'testDone':
            done[event['testID']] = event
        elif kind == 'error':
            errors.append(event)
        elif kind == 'done':
            final = event
    cases, invalid_sources, source_urls = [], [], set()
    for test_id, result in done.items():
        if result.get('hidden'):
            continue
        test = starts[test_id]
        suite = suites[test['suiteID']]
        source_url = test.get('root_url', test.get('url', ''))
        source_path = Path(unquote(urlparse(source_url).path)).resolve() if source_url.startswith('file:') else None
        expected_paths = {ENGINE / path for path in selected}
        if source_path not in expected_paths:
            invalid_sources.append({'test_id': test_id, 'name': test['name'], 'source_url': source_url})
        source_urls.add(source_url)
        cases.append({'id': test_id, 'path': suite['path'], 'source_url': source_url,
                      'name': test['name'], 'result': result['result'], 'skipped': result['skipped']})
    unique = {(case['source_url'], case['name']) for case in cases}
    counts = {'distinct_cases': len(unique), 'completed_events': len(cases),
              'passed': sum(case['result'] == 'success' and not case['skipped'] for case in cases),
              'failed': sum(case['result'] != 'success' and not case['skipped'] for case in cases),
              'skipped': sum(case['skipped'] for case in cases)}
    expected_urls = {(ENGINE / path).as_uri() for path in selected}
    source_guard = {'accepted': not invalid_sources and source_urls == expected_urls,
                    'actual_test_source_urls': sorted(source_urls), 'expected_test_source_urls': sorted(expected_urls),
                    'invalid_sources': invalid_sources}
    accepted = bool(receipt['exit_code'] == 0 and cases and final and final.get('success')
                    and not errors and not non_json and counts['failed'] == 0 and counts['skipped'] == 0
                    and counts['distinct_cases'] == counts['completed_events'] and source_guard['accepted']
                    and (expected_count is None or counts['distinct_cases'] == expected_count))
    result = {'accepted': accepted, 'counts': counts, 'errors': errors, 'non_json': non_json,
              'done': final, 'source_location_guard': source_guard}
    save(name + '-cases.json', cases)
    save(name + '-acceptance.json', result)
    print(json.dumps({'gate': name, 'accepted': accepted, 'counts': counts, 'integration_paths_proven': source_guard['accepted']}), flush=True)
    if not accepted:
        raise SystemExit('Failed macro acceptance: ' + name)
    return result


def guard_after(before, name):
    after = inventory()
    save('source-after-' + name + '.json', after)
    guard = stable(before, after)
    save(name + '-source-guard.json', guard)
    if not guard['unchanged']:
        raise SystemExit('Inputs changed during ' + name)
    return guard


def parse_assertions(name):
    lines = (OUT / (name + '.stdout.log')).read_text().splitlines()
    if len(lines) != 1:
        raise SystemExit('Missing or ambiguous JSON assertion output: ' + name)
    result = json.loads(lines[0])
    if not isinstance(result, dict) or not result or any(isinstance(value, bool) and not value for value in result.values()):
        raise SystemExit('False or invalid assertions: ' + name)
    return result


def main():
    if (OUT / 'selection.json').exists():
        raise SystemExit('Final union attempt already exists; preserve it and use a separate retry directory')
    before = inventory()
    save('source-before.json', before)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    status = subprocess.check_output(['git', 'status', '--short'], cwd=ROOT, text=True).splitlines()
    versions = {}
    for name, argv in [('dart', [str(DART), '--version']), ('node', ['node', '--version'])]:
        version = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True)
        if version.returncode != 0:
            raise SystemExit('Runtime version check failed: ' + name)
        versions[name] = (version.stdout + version.stderr).strip()
    save('selection.json', {
        'started_at': stamp(), 'actual_worktree_head': head, 'working_deltas': status,
        'root': str(ROOT), 'explicit_process_cwd': str(ENGINE), 'package_config': str(CONFIG),
        'package_config_sha256': sha(CONFIG), 'test_runner_sha256': sha(TEST), 'qualification_runner_sha256': sha(Path(__file__)),
        'workflow': str(WORKFLOW), 'workflow_sha256': sha(WORKFLOW),
        'core_tests': CORE_TESTS, 'cli_test': CLI_TEST, 'cli_name': CLI_NAME, 'smokes': SMOKES,
        'versions': versions, 'timeout': '4x', 'concurrency': 1,
        'scope': 'Changed native Word/PML publication boundaries and current dynamic-array compile/CLI/MCP behavior. This is not a rerun of the full earlier 675-case selection.',
        'helper_review': 'Standalone runner imports no earlier qualification module, has no rebound helper globals, requires explicit cwd for every macro process, uses absolute test/source paths and validates package root plus reporter source URLs.',
        'excluded_attempt': '../post-union-macro/excluded-attempt.json',
    })
    common = [DART, '--packages=' + str(CONFIG), TEST]
    options = ['--concurrency', '1', '--timeout', '4x', '--reporter', 'json']
    core = run([*common, *(ENGINE / path for path in CORE_TESTS), *options], 'core', cwd=ENGINE)
    core_result = report('core', CORE_TESTS, core)
    guard_after(before, 'core')
    cli = run([*common, ENGINE / CLI_TEST, '--plain-name', CLI_NAME, *options], 'cli', cwd=ENGINE)
    cli_result = report('cli', [CLI_TEST], cli, expected_count=1)
    guard_after(before, 'cli')
    programs = []
    for source in SMOKES:
        name = Path(source).stem
        output = OUT / 'web' / (name + '.js')
        compiled = run([DART, 'compile', 'js', '-O1', '--packages=' + str(CONFIG), ENGINE / source, '-o', output], 'web/' + name + '-compile', cwd=ENGINE)
        if compiled['exit_code'] != 0:
            raise SystemExit('Compilation failed: ' + name)
        executed = run(['node', '-e', 'globalThis.self = globalThis; require(' + json.dumps(str(output)) + ')'], 'web/' + name + '-run', cwd=ENGINE)
        if executed['exit_code'] != 0:
            raise SystemExit('Node execution failed: ' + name)
        assertions = parse_assertions('web/' + name + '-run')
        vm_equal = None
        if name == 'web_vba_dynamic_arrays_smoke':
            if assertions.get('suite') != 'vba-dynamic-arrays' or assertions.get('passed') != 27 or len(set(assertions.get('checks', []))) != 27:
                raise SystemExit('Incomplete dynamic-array assertion receipt')
            vm = run([DART, '--packages=' + str(CONFIG), ENGINE / source], 'web/' + name + '-vm', cwd=ENGINE)
            if vm['exit_code'] != 0:
                raise SystemExit('Dart VM execution failed')
            vm_assertions = parse_assertions('web/' + name + '-vm')
            vm_equal = assertions == vm_assertions
            save('web/' + name + '-vm-js-comparison.json', {'accepted': vm_equal, 'vm_assertions': vm_assertions, 'javascript_assertions': assertions})
            if not vm_equal:
                raise SystemExit('VM and JavaScript assertion receipts differ')
        elif assertions.get('revision', 0) < 1:
            raise SystemExit('Missing actual native publication receipt')
        save('web/' + name + '-assertions.json', assertions)
        programs.append({'source': source, 'source_sha256': sha(ENGINE / source), 'assertions': assertions,
                         'javascript_sha256': sha(output), 'compile_exit': compiled['exit_code'], 'node_exit': executed['exit_code'],
                         'vm_javascript_equal': vm_equal})
        guard_after(before, name)
        print(json.dumps({'web': name, 'accepted': True, 'vm_javascript_equal': vm_equal}), flush=True)
    guard = guard_after(before, 'final')
    receipt = {'accepted': True, 'source_guard': guard, 'actual_worktree_head': head,
               'distinct_test_cases': core_result['counts']['distinct_cases'] + cli_result['counts']['distinct_cases'],
               'core_counts': core_result['counts'], 'cli_counts': cli_result['counts'],
               'test_source_locations_verified': True, 'programs': programs, 'dynamic_vm_javascript_equal': True}
    save('receipt.json', receipt)
    print(json.dumps({key: value for key, value in receipt.items() if key != 'programs'}), flush=True)


if __name__ == '__main__':
    main()
