#!/usr/bin/env python3
"""Bind accepted macro inputs to a specified saved product commit and tree."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/workspace/scratch/745299cf52c6/integration-repo')
OUT = Path('/workspace/scratch/745299cf52c6/final-union-macro')
ENVIRONMENT_INPUTS = {'.dart_tool/package_config.json', '.dart_tool/package_graph.json'}
if len(sys.argv) != 3 or any(re.fullmatch(r'[0-9a-f]{40}', value) is None for value in sys.argv[1:]):
    raise SystemExit('Usage: bind_source.py FULL_SAVED_COMMIT FULL_EXPECTED_TREE')
checkpoint, expected_tree = sys.argv[1:]
acceptance = json.loads((OUT / 'receipt.json').read_text())
if not acceptance['accepted']:
    raise SystemExit('Macro qualification did not pass')
manifest = json.loads((OUT / 'source-before.json').read_text())
tree_id = subprocess.check_output(['git', 'rev-parse', checkpoint + '^{tree}'], cwd=ROOT, text=True).strip()
if tree_id != expected_tree:
    raise SystemExit('Saved commit does not have the expected tree')
tree = subprocess.check_output(['git', 'ls-tree', '-rz', checkpoint], cwd=ROOT)
blobs = {}
for entry in tree.split(b'\x00'):
    if entry:
        metadata, raw_path = entry.split(b'\t', 1)
        mode, kind, object_id = metadata.decode().split()
        if kind == 'blob':
            blobs[raw_path.decode()] = object_id
matched, environment, mismatches = [], [], []
for path, expected in manifest['files'].items():
    data = (ROOT / path).read_bytes()
    sha256 = hashlib.sha256(data).hexdigest()
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\x00' + data).hexdigest()
    if sha256 != expected['sha256'] or len(data) != expected['bytes']:
        mismatches.append({'path': path, 'reason': 'Input changed after qualification'})
    elif path in ENVIRONMENT_INPUTS:
        environment.append({'path': path, 'sha256': sha256, 'bytes': len(data)})
    elif blobs.get(path) != blob:
        mismatches.append({'path': path, 'reason': 'Input differs from saved Git blob', 'saved_blob': blobs.get(path), 'working_blob': blob})
    else:
        matched.append({'path': path, 'git_blob': blob, 'sha256': sha256})
result = {
    'accepted': not mismatches,
    'saved_product_commit': checkpoint,
    'saved_product_tree': tree_id,
    'actual_test_worktree_head': acceptance['actual_worktree_head'],
    'repository_inputs_matched': len(matched),
    'repository_inputs': matched,
    'environment_inputs': environment,
    'mismatches': mismatches,
    'note': 'All selected repository inputs match the saved product tree; recorded package config and graph are environment-generated inputs outside Git.',
}
(OUT / 'source-git-binding.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: result[key] for key in ['accepted', 'saved_product_commit', 'saved_product_tree', 'actual_test_worktree_head', 'repository_inputs_matched', 'mismatches']}))
if mismatches:
    raise SystemExit(1)
