from pathlib import Path
import subprocess,json,hashlib,datetime,time,sys
r=Path('/workspace/scratch/745299cf52c6/integration-repo')
o=Path('/workspace/scratch/745299cf52c6/late-mail')/sys.argv[1]
o.mkdir(exist_ok=False)
p=r/'packages/quds_office_editor/example'
suites=['studio_mail_recipients_test.dart','studio_mail_reply_test.dart','studio_mail_compose_test.dart','studio_mail_threading_test.dart','studio_mail_test.dart','studio_mail_ews_test.dart','studio_mail_cloud_test.dart','studio_mail_operation_test.dart','studio_mail_session_test.dart']
changed=['studio_mail_compose.dart','studio_mail_ews.dart','studio_mail_native.dart','studio_mail_recipients.dart','studio_mail_reply.dart','studio_mail_strings.dart','studio_mail_submission.dart','studio_mail_draft.dart']
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def snapshot():
 paths={r/'.fvmrc',r/'pubspec.yaml',r/'pubspec.lock',r/'.dart_tool/package_config.json'}
 for directory in ['packages/quds_office_engine/lib','packages/quds_office_editor/lib','packages/quds_office_editor/example/lib','packages/quds_mail_core/lib','packages/quds_mail_mime/lib','packages/quds_mail_transport/lib','third_party/enough_mail/lib']:
  paths.update((r/directory).rglob('*.dart'))
 for name in suites:paths.add(p/'test'/name)
 for manifest in r.rglob('pubspec.yaml'):
  if 'docs' not in manifest.parts and '.dart_tool' not in manifest.parts:paths.add(manifest)
 return {str(path.relative_to(r)):sha(path) for path in sorted(paths)}
rec={'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'source_before':snapshot(),'commands':[]}
def save():(o/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n')
def run(name,cmd):
 started=time.monotonic()
 with (o/(name+'.stdout.log')).open('w') as stdout,(o/(name+'.stderr.log')).open('w') as stderr:
  ret=subprocess.run(cmd,cwd=p,stdout=stdout,stderr=stderr,timeout=600)
 result={'name':name,'command':cmd,'cwd':str(p),'exit_code':ret.returncode,'elapsed_seconds':round(time.monotonic()-started,3),'stdout':name+'.stdout.log','stderr':name+'.stderr.log'}
 rec['commands'].append(result);save();print(json.dumps(result),flush=True)
 return result
save()
run('studio-mail-tests',['flutter','test','--no-pub','--concurrency','2','--timeout','2m','--reporter','json',*[f'test/{s}' for s in suites]])
run('studio-mail-analyze',['dart','analyze','--fatal-infos',*[f'lib/{s}' for s in changed],*[f'test/{s}' for s in suites]])
rec['source_after']=snapshot()
rec['changed_inputs']=[k for k in sorted(rec['source_before'].keys()|rec['source_after'].keys()) if rec['source_before'].get(k)!=rec['source_after'].get(k)]
rec['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
rows=[];unparsed=[]
for line in (o/'studio-mail-tests.stdout.log').read_text().splitlines():
 try:rows.append(json.loads(line))
 except json.JSONDecodeError:unparsed.append(line)
tests={x['test']['id']:x['test'] for x in rows if x.get('type')=='testStart'}
suite_names={x['suite']['id']:Path(x['suite']['path']).name for x in rows if x.get('type')=='suite'}
done=[x for x in rows if x.get('type')=='testDone' and not x.get('hidden',False)]
rec['test_counts']={'passed':sum(x['result']=='success' and not x['skipped'] for x in done),'failed':sum(x['result']!='success' for x in done),'skipped':sum(x['skipped'] for x in done)}
rec['test_cases']=[{'suite':suite_names.get(tests[x['testID']]['suiteID']),'name':tests[x['testID']]['name'],'result':x['result'],'skipped':x['skipped']} for x in done]
rec['test_errors']=[{'case':tests.get(x['testID']),'error':x} for x in rows if x.get('type')=='error']
rec['reporter_done']=[x for x in rows if x.get('type')=='done']
rec['unparsed_stdout']=unparsed
for path in o.glob('*.log'):rec.setdefault('log_sha256',{})[path.name]=sha(path)
save();print(json.dumps({k:v for k,v in rec.items() if k not in ['source_before','source_after','test_cases']},indent=2),flush=True)
