# Advanced main reconciliation

Remote main advanced to `88513f04cfbdec210340f2d70a674cf3f23e31c0` after final product qualification. The actual new work is the delta from common ancestor `400fffd04fcceee78959e4c38b4d1dbe89767c2b`: **24 documentation/evidence files, two changelog entries, and formatting in three Dart files**. The larger direct tree difference reflects source increments already present on our tested branch but not yet in main.

The pinned analyzer parsed all three incoming Dart changes with zero errors; canonical AST-to-source text was identical before and after. A read-only merge-tree preview found only the two changelog conflicts. Compose/reply test formatting was already absorbed by the tested tree. The sole remaining product difference was whitespace/layout of two typedefs in `studio_mail_ews.dart`.

## Reconciled commit

Published checkpoint: `6a7e0afaec7b597abf3a6ad5d43a8295fcce855a`. Its exact tree and parents match the local reconciliation; all tracked working bytes match the published checkpoint.

- Local commit: `7d58e76101eee897b19f9d8885d408799d36996a`.
- Tree: `f4b499799e50c5d1955f9c3f180a1560fb1531ae`.
- Parents: tested source `435bc212401db13efa56483ac852e4bc25bcc5d2` and advanced main `88513f04cfbdec210340f2d70a674cf3f23e31c0`.
- Integration worktree: clean.

The merge retains the exact tested EWS source and combines the changelogs using wording consistent with the current rich-text projection. **All 24 incoming main documentation/evidence files retain their exact main blobs.**

## Product identity proof

Every one of the **5,647 tracked entries outside `docs/` and the two package changelogs** has exactly the same mode, type and blob as the tested source checkpoint. This includes implementation, tests, fixtures, dependency/configuration files and workflows. The deterministic manifest SHA256 is `28ba94f1f167c10cd1940098dda7b3cd923cb3d75c46c9265c0c9b29f3aa4493`.

All **629** previously guarded slide inputs also remain unchanged. No product tests were rerun because no tested product byte changed. The existing execution receipts remain attributed to their original checkpoint; this equality proof carries them through the ancestry reconciliation. Imported main validation files retain their historical attribution.

Root can now publish the pending documentation/evidence edits while preserving the newly imported main documents, then perform the expected-main, non-forced merge. No GitHub Actions endpoint was queried, awaited or rerun.

## Evidence

- Full audit: `/workspace/scratch/745299cf52c6/final-main-reconciliation-audit.json`, SHA256 `ea7c2bcf643cc645fb290873ef56e1a83e55068bf17018bd5ffe3c82fd43adf8`.
- Local merge/result proof: `/workspace/scratch/745299cf52c6/final-main-reconciliation-result.json`.
- Read-only merge-tree output: `/workspace/scratch/745299cf52c6/final-main-merge-tree.txt`.
- Parser equivalence results: `/workspace/scratch/745299cf52c6/final-main-format-proof/stdout.json`.
- Exact parser command: `/workspace/scratch/745299cf52c6/final-main-format-proof/command.json`.
