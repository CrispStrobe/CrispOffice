#!/usr/bin/env python3
"""Bind locally accepted inputs to the saved remote checkpoint's Git blobs."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/745299cf52c6/integration-repo')
OUT = Path('/workspace/scratch/745299cf52c6/late-zotero')
CHECKPOINT = '8356fb0ad4630824a39453ea9a5923d9fb2a2101'
EXPECTED_TREE = 'ff86534f86007d4a64962d2b2cb4f0ab339d6996'
ENVIRONMENT_INPUTS = {'.dart_tool/package_config.json', '.dart_tool/package_graph.json'}

acceptance = json.loads((OUT / 'acceptance.json').read_text())
assert acceptance['accepted'], 'Qualification is incomplete or failed'
manifest = json.loads((OUT / 'source-before.json').read_text())
actual_tree = subprocess.check_output(['git', 'rev-parse', CHECKPOINT + '^{tree}'], cwd=ROOT, text=True).strip()
assert actual_tree == EXPECTED_TREE
tree = subprocess.check_output(['git', 'ls-tree', '-rz', CHECKPOINT], cwd=ROOT)
blobs = {}
for entry in tree.split(b'\x00'):
    if not entry:
        continue
    metadata, raw_path = entry.split(b'\t', 1)
    mode, kind, oid = metadata.decode().split()
    if kind == 'blob':
        blobs[raw_path.decode()] = oid

matches, environment, mismatches = [], [], []
for name, expected in manifest['files'].items():
    data = (ROOT / name).read_bytes()
    sha256 = hashlib.sha256(data).hexdigest()
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\x00' + data).hexdigest()
    if sha256 != expected['sha256'] or len(data) != expected['bytes']:
        mismatches.append({'path': name, 'reason': 'Input changed after qualification'})
    elif name in ENVIRONMENT_INPUTS:
        environment.append({'path': name, 'sha256': sha256, 'bytes': len(data)})
    elif blobs.get(name) != blob:
        mismatches.append({'path': name, 'reason': 'Not equal to checkpoint Git blob', 'checkpoint_blob': blobs.get(name), 'working_blob': blob})
    else:
        matches.append({'path': name, 'git_blob': blob, 'sha256': sha256})

result = {
    'accepted': not mismatches,
    'saved_checkpoint': CHECKPOINT,
    'saved_tree': actual_tree,
    'test_worktree_head': json.loads((OUT / 'selection.json').read_text())['source_head'],
    'repository_inputs_matched': len(matches),
    'repository_inputs': matches,
    'environment_inputs': environment,
    'mismatches': mismatches,
    'explanation': 'The test worktree remained at its original HEAD. Every guarded repository input is byte-identical to the saved checkpoint; only the recorded environment-generated package config and graph are outside Git.',
}
(OUT / 'source-git-binding.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: result[key] for key in ['accepted', 'saved_checkpoint', 'saved_tree', 'test_worktree_head', 'repository_inputs_matched', 'mismatches']}))
if mismatches:
    raise SystemExit(1)
