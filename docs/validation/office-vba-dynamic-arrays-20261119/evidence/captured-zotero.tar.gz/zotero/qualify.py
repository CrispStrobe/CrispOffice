#!/usr/bin/env python3
"""Local qualification of the captured Zotero changes in the merged tree."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time
from urllib.parse import unquote, urlparse

ROOT = Path('/workspace/scratch/745299cf52c6/integration-repo')
OUT = Path('/workspace/scratch/745299cf52c6/late-zotero')
ENGINE = ROOT / 'packages/quds_office_engine'
EDITOR = ROOT / 'packages/quds_office_editor'
DART = Path('/workspace/scratch/745299cf52c6/runtime/flutter/bin/cache/dart-sdk/bin/dart')
TEST = Path('/workspace/scratch/745299cf52c6/runtime/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart')
CONFIG = ROOT / '.dart_tool/package_config.json'
ENGINE_TESTS = [
    'test/zotero_tag_catalog_test.dart',
    'test/zotero_tag_filter_test.dart',
    'test/zotero_catalog_query_test.dart',
    'test/zotero_client_test.dart',
    'test/zotero_identity_client_test.dart',
    'test/zotero_saved_search_test.dart',
    'test/zotero_backoff_state_test.dart',
]
EDITOR_TESTS = [
    'test/word_zotero_tag_browser_test.dart',
    'test/word_zotero_source_occurrences_test.dart',
    'test/word_zotero_source_occurrences_dialog_test.dart',
    'test/word_zotero_occurrence_navigation_test.dart',
    'test/word_zotero_tag_filter_test.dart',
    'test/word_zotero_document_sources_test.dart',
    'test/word_zotero_document_source_picker_test.dart',
    'test/word_zotero_document_reuse_test.dart',
    'test/word_zotero_navigation_test.dart',
    'test/word_zotero_navigation_dialog_test.dart',
    'test/word_zotero_navigation_pane_test.dart',
    'test/word_zotero_dialog_test.dart',
    'test/word_zotero_catalog_query_test.dart',
    'test/word_zotero_source_identity_test.dart',
    'test/word_zotero_source_resolver_test.dart',
    'test/word_zotero_stored_details_dialog_test.dart',
    'test/word_zotero_saved_search_test.dart',
]
ENGINE_SOURCE = [
    'lib/src/zotero/zotero_client.dart',
    'lib/src/zotero/zotero_models.dart',
]
EDITOR_SOURCE = [
    'lib/src/embed/word_zotero_dialog.dart',
    'lib/src/embed/word_zotero_document_sources.dart',
    'lib/src/embed/word_zotero_sources.dart',
    'lib/src/embed/word_zotero_tags.dart',
]


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory():
    paths = {
        CONFIG, ROOT / '.dart_tool/package_graph.json', ROOT / '.fvmrc',
        ROOT / 'pubspec.yaml', ROOT / 'pubspec.lock', ROOT / 'analysis_options.yaml',
    }
    for base in [ENGINE / 'lib', EDITOR / 'lib', ENGINE / 'test/fixtures',
                 EDITOR / 'test/fixtures', ROOT / 'packages/legacy_doc_parser/lib']:
        if base.is_dir():
            paths.update(p for p in base.rglob('*') if p.is_file())
    paths.update(ENGINE / path for path in ENGINE_TESTS)
    paths.update(EDITOR / path for path in EDITOR_TESTS)
    package_roots = {}
    for package in json.loads(CONFIG.read_text())['packages']:
        uri = package['rootUri']
        directory = Path(unquote(urlparse(uri).path)) if uri.startswith('file:') else (CONFIG.parent / uri).resolve()
        package_roots[package['name']] = directory
        try:
            directory.relative_to(ROOT)
        except ValueError:
            continue
        for name in ['pubspec.yaml', 'analysis_options.yaml']:
            path = directory / name
            if path.is_file():
                paths.add(path)
    assert package_roots['quds_office_engine'] == ENGINE
    assert package_roots['quds_office_editor'] == EDITOR
    pending = list(paths)
    while pending:
        path = pending.pop()
        if path.suffix != '.dart':
            continue
        for relative in re.findall(r"(?:import|export|part)\s+['\"]([^'\"]+)['\"]", path.read_text()):
            if ':' in relative:
                continue
            dependency = (path.parent / relative).resolve()
            if dependency.is_file() and dependency not in paths:
                dependency.relative_to(ROOT)
                paths.add(dependency)
                pending.append(dependency)
    return {'captured_at': stamp(), 'file_count': len(paths), 'files': {
        str(path.relative_to(ROOT)): {'bytes': path.stat().st_size, 'sha256': sha(path)}
        for path in sorted(paths)
    }}


def source_guard(before, after):
    changes = [path for path in sorted(set(before['files']) | set(after['files']))
               if before['files'].get(path) != after['files'].get(path)]
    return {'unchanged': not changes, 'changed_paths': changes, 'file_count': after['file_count']}


def run(command, name, cwd):
    argv = list(map(str, command))
    receipt = {'argv': argv, 'cwd': str(cwd), 'started_at': stamp()}
    (OUT / (name + '.command.txt')).write_text(shlex.join(argv) + '\n')
    start = time.monotonic()
    with (OUT / (name + '.stdout.log')).open('wb') as stdout, (OUT / (name + '.stderr.log')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=cwd, stdout=stdout, stderr=stderr)
    receipt.update({'exit_code': result.returncode, 'finished_at': stamp(), 'elapsed_seconds': round(time.monotonic() - start, 3)})
    for stream in ['stdout', 'stderr']:
        path = OUT / (name + '.' + stream + '.log')
        receipt[stream] = {'path': path.name, 'sha256': sha(path), 'bytes': path.stat().st_size}
    save(name + '.json', receipt)
    print(json.dumps({'command': name, 'exit_code': result.returncode, 'seconds': receipt['elapsed_seconds']}), flush=True)
    return receipt


def summarize(name):
    suites, starts, done, errors, unparsed = {}, {}, {}, [], []
    final = None
    for number, line in enumerate((OUT / (name + '.stdout.log')).read_text().splitlines(), 1):
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            unparsed.append({'line': number, 'text': line})
            continue
        kind = event.get('type')
        if kind == 'suite':
            suites[event['suite']['id']] = event['suite']
        elif kind == 'testStart':
            starts[event['test']['id']] = event['test']
        elif kind == 'testDone':
            done[event['testID']] = event
        elif kind == 'error':
            errors.append(event)
        elif kind == 'done':
            final = event
    cases = []
    for test_id, result in done.items():
        if result.get('hidden'):
            continue
        test = starts[test_id]
        cases.append({'id': test_id, 'path': suites[test['suiteID']]['path'],
                      'name': test['name'], 'result': result['result'], 'skipped': result['skipped']})
    summary = {
        'distinct_cases': len({(case['path'], case['name']) for case in cases}),
        'completed_events': len(cases),
        'passed': sum(case['result'] == 'success' and not case['skipped'] for case in cases),
        'failed': sum(case['result'] != 'success' and not case['skipped'] for case in cases),
        'skipped': sum(case['skipped'] for case in cases),
        'final': final, 'error_events': errors, 'unparsed_stdout': unparsed,
    }
    save(name + '-cases.json', cases)
    save(name + '-summary.json', summary)
    return summary


def main():
    OUT.mkdir(exist_ok=True)
    before = inventory()
    save('source-before.json', before)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    status = subprocess.check_output(['git', 'status', '--short'], cwd=ROOT, text=True)
    save('selection.json', {
        'source_head': head, 'source_status': status, 'engine_tests': ENGINE_TESTS,
        'editor_tests': EDITOR_TESTS, 'engine_analyzed_source': ENGINE_SOURCE,
        'editor_analyzed_source': EDITOR_SOURCE, 'runner_sha256': sha(TEST),
        'package_config_sha256': sha(CONFIG), 'timeout': '4x', 'concurrency': 1,
        'captured_zotero_head': '780422316b4e37989e01ac871dd2956fbd2c8908',
        'captured_mail_head': '658095574de89cf3d6f3dfc874fab7e5c479b47e',
        'source_clearance': 'incoming_audit: captured merge stable; runtime_setup: integration package config ready',
    })
    runs = []
    for name, cwd, command in [
        ('engine-tests', ENGINE, [DART, '--packages=' + str(CONFIG), TEST, *ENGINE_TESTS, '--concurrency', '1', '--timeout', '4x', '--reporter', 'json']),
        ('editor-tests', EDITOR, ['flutter', 'test', '--no-pub', '--concurrency', '1', '--timeout', '4x', '--reporter', 'json', *EDITOR_TESTS]),
        ('engine-analysis', ENGINE, [DART, 'analyze', '--fatal-infos', *ENGINE_SOURCE, *ENGINE_TESTS]),
        ('editor-analysis', EDITOR, [DART, 'analyze', '--fatal-infos', *EDITOR_SOURCE, *EDITOR_TESTS]),
    ]:
        receipt = run(command, name, cwd)
        if name.endswith('-tests'):
            summary = summarize(name)
            receipt['summary'] = summary
            receipt['accepted'] = bool(receipt['exit_code'] == 0 and summary['final'] and summary['final'].get('success') and summary['passed'] > 0 and summary['failed'] == 0 and summary['skipped'] == 0 and summary['distinct_cases'] == summary['completed_events'] and not summary['error_events'])
        else:
            receipt['accepted'] = receipt['exit_code'] == 0
        runs.append(receipt)
        after = inventory()
        save('source-after-' + name + '.json', after)
        guard = source_guard(before, after)
        save('acceptance.json', {'accepted': all(item['accepted'] for item in runs) and len(runs) == 4 and guard['unchanged'], 'completed_runs': runs, 'source_guard': guard})
        if not receipt['accepted'] or not guard['unchanged']:
            raise SystemExit('Stopped on failed check or changed input: ' + name)
    print(json.dumps({'accepted': True, 'engine_passed': runs[0]['summary']['passed'], 'editor_passed': runs[1]['summary']['passed'], 'source_guard': guard}), flush=True)


if __name__ == '__main__':
    main()
