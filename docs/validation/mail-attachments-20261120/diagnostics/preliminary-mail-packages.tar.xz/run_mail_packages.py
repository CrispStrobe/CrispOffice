#!/usr/bin/env python3
"""Exact-lock local mail + MIME qualification; preserves JSON events and input hashes."""
import concurrent.futures, importlib.util, json, os, re, shutil, signal, subprocess, time
from pathlib import Path
ROOT=Path('/workspace/scratch/75dc9d25dfaf')
REPO=ROOT/'quds_office_suite'
OUT=ROOT/'final-validation/mail-packages'
SDK=Path(os.environ['FLUTTER_ROOT'])
CACHE=Path(os.environ['PUB_CACHE'])
HELPER=REPO/'docs/validation/mail-archive-portability-20261119/run-local-validation.py'
spec=importlib.util.spec_from_file_location('mail_helpers',HELPER)
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
DART=SDK/'bin/cache/dart-sdk/bin/dart'
CONFIG=REPO/'.dart_tool/package_config.json'
TEST=h.package_root(CONFIG,next(p for p in json.loads(CONFIG.read_text())['packages'] if p['name']=='test'))/'bin/test.dart'
PKGS=('quds_mail_core','quds_mail_mime','quds_mail_store','quds_mail_transport')
PREFIXES=tuple('packages/'+p+'/' for p in PKGS)+('third_party/enough_mail/',)
ROOT_INPUTS={'pubspec.yaml','pubspec.lock','.fvmrc','analysis_options.yaml','dart_test.yaml'}
if OUT.exists():raise RuntimeError('Refuse to overwrite prior qualification output')
OUT.mkdir(parents=True)
shutil.copyfile(__file__,OUT/'run_mail_packages.py')
shutil.copyfile(HELPER,OUT/'event_parser_helpers.py')
def inputs():
    names=h.git_paths(REPO,['ls-files','--cached','--others','--exclude-standard'])
    chosen=[n for n in names if (n in ROOT_INPUTS or n.startswith(PREFIXES)) and not n.lower().endswith('.md') and (REPO/n).is_file()]
    return {n:{'bytes':(REPO/n).stat().st_size,'sha256':h.sha(REPO/n)} for n in sorted(chosen)}
def runtime_inputs():
    paths=[DART,TEST,CONFIG,REPO/'.dart_tool/native_assets.yaml',REPO/'.dart_tool/lib/libsqlite3.so',Path(shutil.which('node')).resolve(),ROOT/'runtime/runtime.json',ROOT/'runtime/readiness-receipt.json']
    return {str(p):{'bytes':p.stat().st_size,'sha256':h.sha(p)} for p in paths}
head=h.capture(['git','rev-parse','HEAD'],REPO)
tree=h.capture(['git','rev-parse','HEAD^{tree}'],REPO)
before=inputs(); dependencies=h.dependency_manifest(CONFIG,CACHE,SDK,REPO); runtime=runtime_inputs()
h.write_manifest(OUT/'source-before.json.gz',before)
h.write_manifest(OUT/'dependencies-before.json.gz',dependencies)
h.write_manifest(OUT/'runtime-before.json.gz',runtime)
cohorts=[]
for pkg in PKGS:
    directory=REPO/'packages'/pkg
    vm=[];node=[]
    for path in sorted((directory/'test').rglob('*_test.dart')):
        m=re.search(r"@TestOn\(['\"]([^'\"]+)['\"]\)",path.read_text()[:4000])
        if m and m.group(1) not in ('js','node','vm'):raise RuntimeError('Unplanned platform '+str(path))
        (node if m and m.group(1) in ('js','node') else vm).append(str(path.relative_to(directory)))
    if vm:cohorts.append((pkg+'-vm','packages/'+pkg,vm,'vm'))
    if node:cohorts.append((pkg+'-node','packages/'+pkg,node,'node'))
cohorts.append(('vendor-mime','third_party/enough_mail',['test/codecs/quoted_printable_mail_codec_test.dart','test/message_builder_test.dart','test/quds_portable_mime_test.dart'],'vm'))
h.write_json(OUT/'selection.json',{'source_head':head,'source_tree':tree,'cohorts':[{'name':n,'package':p,'files':f,'platform':k} for n,p,f,k in cohorts],'scope':'All declared tests in the four mail packages; VM for native/default tests and Node/dart2js for declared js/node boundaries. Vendor codec, builder and portable MIME public-entry tests. No live account delivery.'})
env={k:v for k,v in os.environ.items() if not k.startswith('QUDS_')}
def execute(cohort):
    name,package,files,kind=cohort
    folder=OUT/name;folder.mkdir()
    argv=[str(DART),'--disable-dart-dev','--packages='+str(CONFIG),str(TEST),'--platform='+kind,'--compiler='+('dart2js' if kind=='node' else 'kernel'),'--concurrency=2','--reporter=json',*files]
    rec={'name':name,'argv':argv,'cwd':str(REPO/package),'started_at_utc':h.now(),'expected_test_files':[package+'/'+f for f in files],'platform':kind,'timeout_seconds':1200}
    h.write_json(folder/'command.json',rec)
    print(json.dumps({'started':name,'files':len(files)}),flush=True)
    start=time.monotonic()
    with (folder/'events.jsonl').open('wb') as stdout,(folder/'stderr.log').open('wb') as stderr:
        proc=subprocess.Popen(argv,cwd=REPO/package,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        try:rec['exit_code']=proc.wait(timeout=1200)
        except (subprocess.TimeoutExpired,KeyboardInterrupt):
            os.killpg(proc.pid,signal.SIGTERM)
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
            rec.update(exit_code=proc.returncode,interrupted=True)
    parsed=h.parse_tests(folder/'events.jsonl',REPO,rec['expected_test_files'],REPO/package)
    h.write_manifest(folder/'test-cases.json.gz',parsed)
    substantive=[c for c in parsed['cases'] if not c['name'].startswith('loading ') and not c['name'].endswith(('(setUpAll)','(tearDownAll)'))]
    counts={s:sum((c['skipped'] if s=='skipped' else not c['skipped'] and ((c['result']=='success') if s=='passed' else c['result']!='success')) for c in substantive) for s in ('passed','failed','skipped')}
    rec.update(finished_at_utc=h.now(),elapsed_seconds=round(time.monotonic()-start,3),counts=counts,parser_counts={k:parsed[k] for k in ['passed','failed','skipped']},synthetic_cases_excluded=len(parsed['cases'])-len(substantive),missing_files=parsed['missing_files'],unexpected_files=parsed['unexpected_files'],stdout_sha256=h.sha(folder/'events.jsonl'),stderr_sha256=h.sha(folder/'stderr.log'),test_cases_sha256=h.sha(folder/'test-cases.json.gz'))
    rec['accepted']=rec['exit_code']==0 and not rec.get('interrupted') and parsed['accepted']
    h.write_json(folder/'result.json',rec)
    print(json.dumps({'finished':name,'accepted':rec['accepted'],'counts':counts,'seconds':rec['elapsed_seconds']}),flush=True)
    return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:steps=list(pool.map(execute,cohorts))
after=inputs();dependencies_after=h.dependency_manifest(CONFIG,CACHE,SDK,REPO);runtime_after=runtime_inputs()
for name,value in [('source-after',after),('dependencies-after',dependencies_after),('runtime-after',runtime_after)]:h.write_manifest(OUT/(name+'.json.gz'),value)
def changes(a,b):return sorted(k for k in set(a)|set(b) if a.get(k)!=b.get(k))
changed=changes(before,after);dep_changed=changes(dependencies,dependencies_after);run_changed=changes(runtime,runtime_after)
summary={'source_head_before':head,'source_tree_before':tree,'source_head_after':h.capture(['git','rev-parse','HEAD'],REPO),'source_tree_after':h.capture(['git','rev-parse','HEAD^{tree}'],REPO),'inputs_stable':not(changed or dep_changed or run_changed),'source_changed':changed,'dependencies_changed':dep_changed,'runtime_changed':run_changed,'source_files':len(before),'dependency_files':len(dependencies),'source_digest':h.digest(before),'dependency_digest':h.digest(dependencies),'runtime_digest':h.digest(runtime),'steps':steps,'counts':{k:sum(s['counts'][k] for s in steps) for k in ['passed','failed','skipped']},'mail_package_counts':{k:sum(s['counts'][k] for s in steps if s['name']!='vendor-mime') for k in ['passed','failed','skipped']},'vendor_counts':next(s['counts'] for s in steps if s['name']=='vendor-mime'),'github_actions_used':False,'tests_resolved_dependencies':False,'dependency_setup':'SDK and 194 hosted archives hash-verified; offline pub get --enforce-lockfile succeeded with unchanged repository lock before suites. Native sqlite3 asset from unmodified package default hook is verified by SHA-256 and FTS5 probe.','finished_at_utc':h.now()}
summary['accepted']=summary['inputs_stable'] and all(s['accepted'] for s in steps)
h.write_json(OUT/'receipt.json',summary)
print(json.dumps({k:summary[k] for k in ['accepted','counts','mail_package_counts','vendor_counts','inputs_stable','source_changed','dependencies_changed','runtime_changed']}),flush=True)
raise SystemExit(0 if summary['accepted'] else 1)
