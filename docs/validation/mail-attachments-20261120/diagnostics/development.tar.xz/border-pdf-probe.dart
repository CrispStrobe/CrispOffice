import 'dart:convert';
import 'dart:typed_data';
import 'package:quds_office_engine/quds_office_engine.dart';
void main() {
 for (final cropped in [false, true]) {
      final OfficeVisual picture = OfficeVisual(
        kind: OfficeVisualKind.picture,
        imageBytes: PngBytes.studioCard(width: 8, height: 8),
      );
      picture.picture
        ..cropLeft = cropped ? 0.25 : 0
        ..cropBottom = cropped ? 0.1 : 0
        ..borderColor = 'CC3300'
        ..borderWidth = 2.5;
      final PmlPresentation deck = PmlPresentation(
        slides: <PmlSlide>[
          PmlSlide(
            id: 256,
            shapes: <PmlShape>[
              PmlShape(
                id: 2,
                name: 'Bordered picture',
                transform: const PmlTransform(
                  x: 10 * 12700,
                  y: 20 * 12700,
                  cx: 100 * 12700,
                  cy: 50 * 12700,
                ),
                visual: picture,
              ),
            ],
          ),
        ],
      );

final streams=_inflated(OfficePdfExport.presentation(deck));
print(jsonEncode({'cropped':cropped,'streams':streams.where((s)=>s.contains('/Im1 Do')).toList()}));
 }
}
List<String> _inflated(Uint8List pdf) {
  final List<String> out = <String>[];
  final List<int> mark = 'stream\n'.codeUnits;
  var i = 0;
  while (i < pdf.length - mark.length) {
    var hit = true;
    for (int k = 0; k < mark.length; k++) {
      if (pdf[i + k] != mark[k]) {
        hit = false;
        break;
      }
    }
    if (!hit) {
      i++;
      continue;
    }
    final int start = i + mark.length;
    final int end = _indexOf(pdf, 'endstream', start);
    if (end < 0) {
      break;
    }
    var payload = Uint8List.sublistView(pdf, start, end);
    if (payload.isNotEmpty && payload.last == 0x0A) {
      payload = Uint8List.sublistView(payload, 0, payload.length - 1);
    }
    if (payload.length >= 2 && payload[0] == 0x78) {
      try {
        out.add(String.fromCharCodes(PdfFlate.decompress(payload)));
      } catch (_) {}
    }
    i = end + 9;
  }
  return out;
}

int _indexOf(Uint8List data, String token, int from) {
  final List<int> needle = token.codeUnits;
  for (int i = from; i <= data.length - needle.length; i++) {
    var ok = true;
    for (int k = 0; k < needle.length; k++) {
      if (data[i + k] != needle[k]) {
        ok = false;
        break;
      }
    }
    if (ok) {
      return i;
    }
  }
  return -1;
}
