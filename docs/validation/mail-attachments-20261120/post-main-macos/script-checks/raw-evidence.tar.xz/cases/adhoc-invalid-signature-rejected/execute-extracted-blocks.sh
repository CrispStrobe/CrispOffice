set -euo pipefail
FRAMEWORKS=/workspace/scratch/75dc9d25dfaf/final-validation/macos-portability-refresh/script-checks/cases/adhoc-invalid-signature-rejected/Frameworks
RESOURCES=/workspace/scratch/75dc9d25dfaf/final-validation/macos-portability-refresh/script-checks/cases/adhoc-invalid-signature-rejected/Resources
SIGN_MODE=adhoc
REBUILD_SPACY=0
SPACY_PIN_SHA256=7c26634334a94f690e1012a24a2ce9a2e4c5610a1ca22fca51ac16408ec390e2
SPACY_PIN_CODE_SHA256=f2022b1cf75d831cddbd047eec5f5ac759728fee169ed2b5b785ecda1a07efeb
SPACY_PIN_UNSIGNED_SHA256=f62d2a0cf457a0ac577f45eceba93d8d5f2f450d4fd5a191f0cec61d88886ed2
TEST_CODE_BEFORE=f2022b1cf75d831cddbd047eec5f5ac759728fee169ed2b5b785ecda1a07efeb
TEST_CODE_AFTER=f2022b1cf75d831cddbd047eec5f5ac759728fee169ed2b5b785ecda1a07efeb
TEST_UNSIGNED_BEFORE=f62d2a0cf457a0ac577f45eceba93d8d5f2f450d4fd5a191f0cec61d88886ed2
TEST_UNSIGNED_AFTER=f62d2a0cf457a0ac577f45eceba93d8d5f2f450d4fd5a191f0cec61d88886ed2
TEST_VERIFY_EXIT=7
TEST_CALL_LOG=/workspace/scratch/75dc9d25dfaf/final-validation/macos-portability-refresh/script-checks/cases/adhoc-invalid-signature-rejected/codesign-calls.log
TEST_NOTE=/workspace/scratch/75dc9d25dfaf/final-validation/macos-portability-refresh/script-checks/cases/adhoc-invalid-signature-rejected/note.txt
LIBRARIES=(libcrispembed-spacy.dylib unrelated.dylib)
SIGN_ARGS=(--force --sign SYNTHETIC-IDENTITY)
code_sha256() { if [[ "$TEST_PHASE" == before ]]; then printf '%s\n' "$TEST_CODE_BEFORE"; else printf '%s\n' "$TEST_CODE_AFTER"; fi; }
unsigned_sha256() { if [[ "$TEST_PHASE" == before ]]; then printf '%s\n' "$TEST_UNSIGNED_BEFORE"; else printf '%s\n' "$TEST_UNSIGNED_AFTER"; fi; }
codesign() {
  printf '%s\n' "$*" >> "$TEST_CALL_LOG"
  if [[ "$1" == --verify ]]; then return "$TEST_VERIFY_EXIT"; fi
  printf 'SYNTHETIC SIGNATURE CHANGE\n' >> "${@: -1}"
}
TEST_PHASE=before
if [[ "${QUDS_SKIP_SPACY:-0}" != 1 && "$REBUILD_SPACY" != 1 ]]; then
  # The pinned input (SHA-256 and length already verified) is the qualified
  # code: check the runtime's code digest and keep Apple's stripped form of
  # it for the comparison after signing.
  [[ "$(code_sha256 "$FRAMEWORKS/libcrispembed-spacy.dylib")" == "$SPACY_PIN_CODE_SHA256" ]] \
    || { echo "pinned spaCy library: unexpected code digest" >&2; exit 1; }
  # Apple's cross-check is meaningful only with a codesign whose
  # --remove-signature output does not depend on the signature (Xcode 26
  # strips the pinned library to the reference; Xcode 16 does not).
  SPACY_INPUT_UNSIGNED="$(unsigned_sha256 "$FRAMEWORKS/libcrispembed-spacy.dylib")"
  if [[ "$SPACY_INPUT_UNSIGNED" != "$SPACY_PIN_UNSIGNED_SHA256" ]]; then
    echo "note: this codesign strips the pinned library to $SPACY_INPUT_UNSIGNED, not the" \
      "Xcode 26 reference; the codesign cross-check is skipped, the code digest still applies"
    SPACY_INPUT_UNSIGNED=""
  fi
fi

for library in "${LIBRARIES[@]}"; do
  # The pinned spaCy library already carries the ad hoc signature it was
  # qualified with; ad hoc re-signing is not reproducible across codesign
  # versions, so ad hoc builds ship those exact bytes.
  if [[ "$SIGN_MODE" == adhoc && "$library" == libcrispembed-spacy.dylib \
    && "$REBUILD_SPACY" != 1 ]]; then
    codesign --verify --strict "$FRAMEWORKS/$library"
    continue
  fi
  codesign "${SIGN_ARGS[@]}" "$FRAMEWORKS/$library"
done
TEST_PHASE=after
if [[ "${QUDS_SKIP_SPACY:-0}" != 1 ]]; then
  # Studio loads the bundled library only with this digest of the signed
  # bytes; the app signature below seals this description. The code digest
  # carries the qualification across signatures (see the header).
  spacy_library="$FRAMEWORKS/libcrispembed-spacy.dylib"
  spacy_sha="$(shasum -a 256 "$spacy_library" | awk '{print $1}')"
  spacy_code="$(code_sha256 "$spacy_library")"
  printf '{"library":"libcrispembed-spacy.dylib","sha256":"%s","code_sha256":"%s"}\n' \
    "$spacy_sha" "$spacy_code" >"$RESOURCES/spacy-native.json"
  if [[ "$spacy_sha" == "$SPACY_PIN_SHA256" ]]; then
    SPACY_NOTE="spaCy library $spacy_sha: qualified (analysis and manual German grammar)"
  elif [[ "$REBUILD_SPACY" != 1 && "$spacy_code" == "$SPACY_PIN_CODE_SHA256" ]] \
    && [[ -z "${SPACY_INPUT_UNSIGNED:-}" \
      || "$(unsigned_sha256 "$spacy_library")" == "$SPACY_INPUT_UNSIGNED" ]]; then
    SPACY_NOTE="spaCy library $spacy_sha: qualified code $spacy_code re-signed ($SIGN_MODE; analysis and manual German grammar)"
  elif [[ "$REBUILD_SPACY" == 1 ]]; then
    SPACY_NOTE="spaCy library $spacy_sha: UNQUALIFIED rebuild (analysis only; no grammar suggestions)"
  else
    echo "pinned spaCy library changed while signing: $spacy_sha (code $spacy_code)" >&2
    exit 1
  fi
fi
printf '%s\n' "$SPACY_NOTE" > "$TEST_NOTE"
