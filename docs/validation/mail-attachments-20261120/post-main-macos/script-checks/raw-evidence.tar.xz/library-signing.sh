for library in "${LIBRARIES[@]}"; do
  # The pinned spaCy library already carries the ad hoc signature it was
  # qualified with; ad hoc re-signing is not reproducible across codesign
  # versions, so ad hoc builds ship those exact bytes.
  if [[ "$SIGN_MODE" == adhoc && "$library" == libcrispembed-spacy.dylib \
    && "$REBUILD_SPACY" != 1 ]]; then
    codesign --verify --strict "$FRAMEWORKS/$library"
    continue
  fi
  codesign "${SIGN_ARGS[@]}" "$FRAMEWORKS/$library"
done
