if [[ "${QUDS_SKIP_SPACY:-0}" != 1 ]]; then
  # Studio loads the bundled library only with this digest of the signed
  # bytes; the app signature below seals this description. The code digest
  # carries the qualification across signatures (see the header).
  spacy_library="$FRAMEWORKS/libcrispembed-spacy.dylib"
  spacy_sha="$(shasum -a 256 "$spacy_library" | awk '{print $1}')"
  spacy_code="$(code_sha256 "$spacy_library")"
  printf '{"library":"libcrispembed-spacy.dylib","sha256":"%s","code_sha256":"%s"}\n' \
    "$spacy_sha" "$spacy_code" >"$RESOURCES/spacy-native.json"
  if [[ "$spacy_sha" == "$SPACY_PIN_SHA256" ]]; then
    SPACY_NOTE="spaCy library $spacy_sha: qualified (analysis and manual German grammar)"
  elif [[ "$REBUILD_SPACY" != 1 && "$spacy_code" == "$SPACY_PIN_CODE_SHA256" ]] \
    && [[ -z "${SPACY_INPUT_UNSIGNED:-}" \
      || "$(unsigned_sha256 "$spacy_library")" == "$SPACY_INPUT_UNSIGNED" ]]; then
    SPACY_NOTE="spaCy library $spacy_sha: qualified code $spacy_code re-signed ($SIGN_MODE; analysis and manual German grammar)"
  elif [[ "$REBUILD_SPACY" == 1 ]]; then
    SPACY_NOTE="spaCy library $spacy_sha: UNQUALIFIED rebuild (analysis only; no grammar suggestions)"
  else
    echo "pinned spaCy library changed while signing: $spacy_sha (code $spacy_code)" >&2
    exit 1
  fi
fi
