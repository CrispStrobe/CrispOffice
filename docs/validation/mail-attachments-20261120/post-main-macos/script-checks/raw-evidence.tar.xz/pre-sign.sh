if [[ "${QUDS_SKIP_SPACY:-0}" != 1 && "$REBUILD_SPACY" != 1 ]]; then
  # The pinned input (SHA-256 and length already verified) is the qualified
  # code: check the runtime's code digest and keep Apple's stripped form of
  # it for the comparison after signing.
  [[ "$(code_sha256 "$FRAMEWORKS/libcrispembed-spacy.dylib")" == "$SPACY_PIN_CODE_SHA256" ]] \
    || { echo "pinned spaCy library: unexpected code digest" >&2; exit 1; }
  # Apple's cross-check is meaningful only with a codesign whose
  # --remove-signature output does not depend on the signature (Xcode 26
  # strips the pinned library to the reference; Xcode 16 does not).
  SPACY_INPUT_UNSIGNED="$(unsigned_sha256 "$FRAMEWORKS/libcrispembed-spacy.dylib")"
  if [[ "$SPACY_INPUT_UNSIGNED" != "$SPACY_PIN_UNSIGNED_SHA256" ]]; then
    echo "note: this codesign strips the pinned library to $SPACY_INPUT_UNSIGNED, not the" \
      "Xcode 26 reference; the codesign cross-check is skipped, the code digest still applies"
    SPACY_INPUT_UNSIGNED=""
  fi
fi

