#!/usr/bin/env python3
"""Verify recorded parser output and explicitly account for optional commas."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import subprocess

base = Path(__file__).resolve().parents[1]
repo = base.parent / 'quds'
folder = base / 'qualification/format-correction-b32dee6f'
original_receipt = json.loads((folder / 'receipt.json').read_text())
names = original_receipt['files']
before = json.loads((folder / 'tokens-before.stdout').read_text())
after = json.loads((folder / 'tokens-after.stdout').read_text())
ast_before = json.loads((folder / 'ast-before.stdout').read_text())
ast_after = json.loads((folder / 'ast-after.stdout').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
rows = {}
for name in names:
    edits = []
    for tag, first, last, start, end in difflib.SequenceMatcher(a=[tuple(v) for v in before[name]], b=[tuple(v) for v in after[name]], autojunk=False).get_opcodes():
        if tag == 'equal':
            continue
        assert tag == 'insert' and after[name][start:end] == [['COMMA', ',']], (name, tag)
        assert after[name][end][0] == 'CLOSE_PAREN', name
        edits.append({'before_token_offset': first, 'after_token_offset': start, 'inserted': after[name][start:end], 'following_token': after[name][end]})
    first_ast = ast_before[str(folder / 'before' / name)]
    second_ast = ast_after[str(repo / name)]
    assert first_ast == second_ast, name
    assert original_receipt['after_sha256'][name] == sha((repo / name).read_bytes()), name
    rows[name] = {
        'before_sha256': original_receipt['before_sha256'][name],
        'after_sha256': original_receipt['after_sha256'][name],
        'before_git_blob': original_receipt['before_git_blob'][name],
        'after_git_blob': original_receipt['after_git_blob'][name],
        'before_token_count': len(before[name]), 'after_token_count': len(after[name]),
        'token_changes': edits, 'all_other_token_types_and_lexemes_identical': True,
        'parsed_ast_source_equal': True, 'parsed_ast_source_sha256': sha(first_ast.encode()),
    }
assert sum(len(row['token_changes']) for row in rows.values()) == 9
graph = base / 'qualification/run-b32dee6f-1/analysis-package-config.json'
original = repo / '.dart_tool/package_config.json'
prior_directory = original.parent.exists()
prior_bytes = original.read_bytes() if original.exists() else None
dart = Path(os.environ['FLUTTER_ROOT']) / 'bin/cache/dart-sdk/bin/dart'
command = [str(dart), 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed', *names]
try:
    original.parent.mkdir(exist_ok=True)
    original.write_bytes(graph.read_bytes())
    result = subprocess.run(command, cwd=repo, capture_output=True)
    (folder / 'format-recheck.stdout').write_bytes(result.stdout)
    (folder / 'format-recheck.stderr').write_bytes(result.stderr)
    assert result.returncode == 0, result.stdout.decode()
finally:
    if prior_bytes is None:
        original.unlink(missing_ok=True)
        if not prior_directory and original.parent.exists() and not any(original.parent.iterdir()):
            original.parent.rmdir()
    else:
        original.write_bytes(prior_bytes)
assert (original.read_bytes() if original.exists() else None) == prior_bytes
receipt = {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit_before': original_receipt['source_commit_before'],
    'source_tree_before': original_receipt['source_tree_before'],
    'passed': True, 'production_files_modified': False,
    'prior_verifier_limit': 'The first verifier required literal token identity and rejected the formatter\'s nine optional trailing commas. Its receipt, logs and exact script remain retained. The final verification requires parsed AST equality and permits only the explicitly listed inserted commas immediately before closing parentheses.',
    'files': rows, 'optional_trailing_commas_inserted': 9,
    'analyzer_config_restored': True,
    'same_resolved_graph_sha256': sha(graph.read_bytes()),
    'dart_sha256': sha(dart.read_bytes()),
    'verification_script_sha256': sha(Path(__file__).read_bytes()),
    'ast_helper_sha256': sha(Path(__file__).with_name('dart_syntax.dart').read_bytes()),
    'ast_commands': [
        [str(dart), '--packages=' + str(base / 'quds/.dart_tool/package_config.json'), str(Path(__file__).with_name('dart_syntax.dart')), *[str(folder / 'before' / name) for name in names]],
        [str(dart), '--packages=' + str(base / 'quds/.dart_tool/package_config.json'), str(Path(__file__).with_name('dart_syntax.dart')), *[str(repo / name) for name in names]],
    ],
    'ast_command_exit_codes': [0, 0],
    'format_recheck': {'command': command, 'cwd': str(repo), 'exit_code': result.returncode, 'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)},
    'raw_output_sha256': {p.name: sha(p.read_bytes()) for p in sorted(folder.glob('*.stdout'))},
    'tests_run': False,
}
(folder / 'verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'passed': True, 'tests_changed': len(rows), 'optional_trailing_commas_inserted': 9, 'parsed_ast_sources_equal': True, 'analyzer_config_restored': True}))
