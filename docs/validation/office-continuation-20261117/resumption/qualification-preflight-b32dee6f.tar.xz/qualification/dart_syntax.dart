import 'dart:convert';
import 'dart:io';

import 'package:analyzer/dart/analysis/utilities.dart';

void main(List<String> paths) {
  final result = <String, String>{};
  for (final path in paths) {
    final unit = parseString(
      content: File(path).readAsStringSync(),
      path: path,
    ).unit;
    result[path] = unit.toSource();
  }
  stdout.writeln(jsonEncode(result));
}
