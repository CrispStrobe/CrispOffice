#!/usr/bin/env python3
"""Apply four preflight-identified test-only format changes and prove token identity."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

BASE = Path(__file__).resolve().parents[1]
REPO = BASE.parent / 'quds'
SDK = Path(os.environ['FLUTTER_ROOT'])
DART = SDK / 'bin/cache/dart-sdk/bin/dart'
SOURCE = 'b32dee6f1fb6993c928a466b553226209cf27fb8'
OUT = BASE / 'qualification/format-correction-b32dee6f'
FILES = ['packages/quds_office_engine/test/' + name for name in [
    'odp_presentation_writer_test.dart', 'odt_document_writer_test.dart',
    'odt_section_continuation_test.dart', 'odt_section_fidelity_test.dart',
]]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def main():
    assert not OUT.exists(), 'Never replace a correction attempt.'
    assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
    assert not git('status', '--porcelain')
    OUT.mkdir()
    before = {name: (REPO / name).read_bytes() for name in FILES}
    for name, data in before.items():
        assert data == git('show', SOURCE + ':' + name)
    original = REPO / '.dart_tool/package_config.json'
    prior_directory = original.parent.exists()
    prior_bytes = original.read_bytes() if original.exists() else None
    graph = BASE / 'qualification/run-b32dee6f-1/analysis-package-config.json'
    receipt = {
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit_before': SOURCE,
        'source_tree_before': git('rev-parse', SOURCE + '^{tree}').decode().strip(),
        'files': FILES, 'language_version': '3.12',
        'resolved_graph_sha256': sha(graph.read_bytes()),
        'dart_sha256': sha(DART.read_bytes()),
        'script_sha256': sha(Path(__file__).read_bytes()),
        'token_helper_sha256': sha(Path(__file__).with_name('dart_tokens.dart').read_bytes()),
        'original_analyzer_config_sha256': sha(prior_bytes) if prior_bytes is not None else None,
        'before_sha256': {name: sha(data) for name, data in before.items()},
        'before_git_blob': {name: git('rev-parse', SOURCE + ':' + name).decode().strip() for name in FILES},
        'commands': [],
    }

    def save():
        (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

    def run(label, command):
        result = subprocess.run(command, cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        (OUT / (label + '.stdout')).write_bytes(result.stdout)
        (OUT / (label + '.stderr')).write_bytes(result.stderr)
        receipt['commands'].append({'name': label, 'command': list(map(str, command)), 'cwd': str(REPO), 'exit_code': result.returncode, 'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)})
        save()
        assert result.returncode == 0, result.stderr.decode(errors='replace')
        return result.stdout

    try:
        original.parent.mkdir(exist_ok=True)
        original.write_bytes(graph.read_bytes())
        token_command = [DART, '--packages=' + str(BASE / 'quds/.dart_tool/package_config.json'), Path(__file__).with_name('dart_tokens.dart'), *FILES]
        first_tokens = json.loads(run('tokens-before', token_command))
        run('format', [DART, 'format', '--language-version=3.12', *FILES])
        second_tokens = json.loads(run('tokens-after', token_command))
        assert first_tokens == second_tokens, 'Dart executable token sequence changed.'
        run('format-recheck', [DART, 'format', '--language-version=3.12', '--output=none', '--set-exit-if-changed', *FILES])
        receipt['executable_token_sequences_unchanged'] = True
        receipt['token_counts'] = {name: len(tokens) for name, tokens in first_tokens.items()}
        receipt['token_sequence_sha256'] = {name: sha(json.dumps(tokens, separators=(',', ':')).encode()) for name, tokens in first_tokens.items()}
    finally:
        if prior_bytes is None:
            original.unlink(missing_ok=True)
            if not prior_directory and original.parent.exists() and not any(original.parent.iterdir()):
                original.parent.rmdir()
        else:
            original.write_bytes(prior_bytes)
        receipt['analyzer_config_restored'] = (original.read_bytes() if original.exists() else None) == prior_bytes
        receipt['after_sha256'] = {name: sha((REPO / name).read_bytes()) for name in FILES}
        receipt['after_git_blob'] = {name: git('hash-object', name).decode().strip() for name in FILES}
        changed = git('diff', '--name-only').decode().splitlines()
        receipt['changed_tracked_paths'] = changed
        receipt['only_four_test_files_changed'] = set(changed) == set(FILES)
        receipt['production_files_modified'] = False
        receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
    assert receipt['analyzer_config_restored'] and receipt['only_four_test_files_changed']
    assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
    print(json.dumps({key: receipt[key] for key in ('executable_token_sequences_unchanged', 'token_counts', 'analyzer_config_restored', 'changed_tracked_paths')}))


if __name__ == '__main__':
    main()
