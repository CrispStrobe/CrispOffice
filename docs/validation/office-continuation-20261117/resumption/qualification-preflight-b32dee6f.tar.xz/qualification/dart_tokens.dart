import 'dart:convert';
import 'dart:io';

import 'package:analyzer/dart/analysis/utilities.dart';

void main(List<String> paths) {
  final result = <String, List<List<String>>>{};
  for (final path in paths) {
    var token = parseString(
      content: File(path).readAsStringSync(),
      path: path,
    ).unit.beginToken;
    final tokens = <List<String>>[];
    while (!token.isEof) {
      tokens.add([token.type.toString(), token.lexeme]);
      token = token.next!;
    }
    result[path] = tokens;
  }
  stdout.writeln(jsonEncode(result));
}
