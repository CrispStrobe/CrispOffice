"""Inventory existing evidence only. This script never invokes tests or edits sources."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex


RUNTIME = Path(__file__).resolve().parent
LOGS = RUNTIME / 'logs'

# Interpretation is deliberately separate from the unchanged original receipts.
DESCRIPTIONS = {
    'final-dart-core-store': ('accepted_final', 'Final Mail core and SQLite store qualification; strict event audit and unchanged source/runtime manifests.'),
    'final-dart-word-layout': ('accepted_final', 'Final incoming Word incremental-layout compatibility qualification; strict event audit and unchanged source/runtime manifests.'),
    'final-dart-smtp': ('accepted_final', 'Final vendored SMTP, send-transaction and submission-acceptance qualification; strict event audit and unchanged source/runtime manifests.'),
    'final-studio-mail': ('pending_final', 'Combined selected Studio Mail qualification; acceptance requires a complete passing command and final source/runtime audit.'),
    'setup-draft-store': ('accepted_narrow_overlap', 'Environment-readiness run of 16 existing draft-store tests; overlaps the later native adapter and final Studio gates.'),
    'outbox-core-codec-direct': ('accepted_narrow_overlap', '55 core/codec cases using the direct locked test runner; overlaps final-dart-core-store.'),
    'outbox-core-store-first': ('rejected_development_probe', 'Initial standard dart test completed with 19 store failures: SQLite native asset mapping was absent; 55 passing partial cases are excluded.'),
    'outbox-transfer-direct': ('rejected_development_probe', 'Dart VM rejected unsupported --native-assets flag before starting a suite; exit 255.'),
    'outbox-transfer-native-map': ('accepted_narrow_overlap', '19 transfer cases established native SQLite mapping with the exact Flutter-generated asset map; overlaps final-dart-core-store.'),
    'outbox-transfer-final': ('accepted_narrow_overlap', '19 transfer cases reran after submitted-record cleanup refinement; overlaps final-dart-core-store, and adds no distinct count to the earlier 19.'),
    'outbox-core-store-regression': ('accepted_narrow_overlap', 'Earlier 172-case core/store regression run; superseded by source-bound final-dart-core-store.'),
    'studio-outbox-store-initial': ('accepted_narrow_overlap', '18 adapter cases before replacing a direct transitive Drift test import with the declared public native repository opener; superseded by studio-outbox-store-native.'),
    'studio-outbox-store-native': ('accepted_narrow_overlap', '18 new adapter plus 16 existing draft-store cases use actual native file-backed SQLite, reopen and lease behavior; included in final Studio scope.'),
    'studio-outbox-submission-direct': ('rejected_development_probe', 'Direct development runner had 17 passes and one expected-LF versus canonical-CRLF fixture mismatch; original flutter_test imports were restored for the final run.'),
    'studio-outbox-submission-final': ('accepted_narrow_overlap', '18 submission/coordinator cases pass with the declared Flutter test dependency and corrected canonical-CRLF expectation; included in final Studio scope.'),
    'studio-outbox-cloud-dev1': ('accepted_narrow_overlap', 'Four Gmail/Graph widget cases pass on their frozen final authored source; included in final Studio scope despite the development filename.'),
    'outbox-dialog-dev': ('rejected_development_probe', '240-second bounded widget probe could not complete its asynchronous SQLite fixture under FakeAsync; shutdown emitted a sink error. No suite completion.'),
    'outbox-dialog-io-probe': ('rejected_development_probe', '90-second bounded native-isolate widget fixture probe; no suite completion. This is a harness timeout, not accepted qualification.'),
    'outbox-widgets-memory-dev': ('rejected_development_probe', '180-second bounded synchronous-memory SQLite widget probe still needed deferred-work clock pumping; no suite completion.'),
    'outbox-widget-clock-probe': ('rejected_development_probe', 'A fixture callback used guarded expect while tester.pump was active. Replaced callback assertions with expectSync; original guard-conflict failure retained.'),
    'outbox-widget-clock-verified': ('rejected_development_probe', '30-second bounded probe remained blocked at unpumped SQLite teardown; no complete passing suite.'),
    'outbox-widget-teardown-probe': ('accepted_development_probe', 'One instrumented widget case verified bounded pumping through database close; diagnostic pass only, superseded by the full frozen widget cohort.'),
    'outbox-widgets-qualified-dev': ('rejected_development_probe', 'Nine passes and six fixture failures: RawTooltip cast, ambiguous Refresh target, and offscreen composer taps. Corrected scoped IconButton finders and ensureVisible plus pump; partial passes excluded.'),
    'outbox-widgets-final-dev': ('accepted_narrow_overlap', 'Frozen 10 dialog plus five native/EWS host widget cases pass; includes English/German/Arabic compact views. Included in final Studio scope.'),
}


def read_json(path: Path):
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def fingerprint(path: Path):
    before = path.stat()
    content = path.read_bytes()
    after = path.stat()
    return {
        'path': str(path.relative_to(RUNTIME)),
        'bytes': len(content),
        'sha256': hashlib.sha256(content).hexdigest(),
        'mtime_utc': datetime.fromtimestamp(after.st_mtime, timezone.utc).isoformat(),
        'stable_during_read': before.st_size == after.st_size == len(content)
        and before.st_mtime_ns == after.st_mtime_ns,
    }


def summary_result(receipt):
    keys = ('exit_code', 'seconds', 'timed_out', 'passed', 'failed', 'skipped',
            'complete', 'complete_success', 'accepted')
    result = {key: receipt.get(key) for key in keys}
    result['reported_error_events'] = len(receipt.get('errors', []))
    return result


def passing(receipt):
    return receipt.get('accepted') is True and receipt.get('exit_code') == 0 \
        and receipt.get('timed_out') is False and receipt.get('complete') is True \
        and receipt.get('complete_success') is True \
        and receipt.get('failed') == 0 and receipt.get('skipped') == 0 \
        and not receipt.get('errors')


def source_audit_accepted(summary):
    return isinstance(summary, dict) and summary.get('accepted') is True \
        and summary.get('source_unchanged') is True \
        and summary.get('runtime_unchanged') is True


def studio_reaudit_accepted(audit, receipt, original, validator):
    if not (source_audit_accepted(audit) and isinstance(receipt, dict)
            and passing(receipt) and isinstance(original, dict)
            and isinstance(validator, dict) and validator.get('accepted') is True
            and validator.get('source_unchanged') is True):
        return False
    strict = audit.get('strict_event_audit', {})
    comparison = audit.get('corrected_repository_auditor_comparison', {})
    provenance = audit.get('provenance', {})
    checker = RUNTIME.parent / 'quds/tools/mail/check_store.py'
    log = LOGS / 'final-studio-mail.events.jsonl'
    summary = RUNTIME / 'final-studio/summary.json'
    return strict.get('valid') is True and strict.get('terminal_success') is True \
        and all(strict.get(key) == 0 for key in (
            'failed', 'skipped', 'errors', 'all_failed', 'all_skipped',
            'excluded_failed', 'excluded_skipped', 'incomplete', 'protocol_errors')) \
        and comparison.get('strict_valid') is True \
        and comparison.get('identical_to_independent_lf_audit') is True \
        and comparison.get('checker_sha256') == hashlib.sha256(checker.read_bytes()).hexdigest() \
        and audit.get('log_receipt_hashes_match') is True \
        and audit.get('original_log_sha256') == hashlib.sha256(log.read_bytes()).hexdigest() \
        and audit.get('original_summary_sha256') == hashlib.sha256(summary.read_bytes()).hexdigest() \
        and audit.get('original_summary_accepted') is original.get('accepted') \
        and provenance.get('raw_log_modified') is False \
        and provenance.get('original_summary_replaced') is False \
        and provenance.get('tests_rerun') is False \
        and audit.get('missing_expected_suites') == [] \
        and audit.get('unexpected_suites') == [] \
        and audit.get('unique_cases') == receipt.get('passed') == strict.get('passed')


def main():
    captured = datetime.now(timezone.utc).isoformat()
    dart_summary = read_json(RUNTIME / 'final-dart/summary.json')
    studio_summary = read_json(RUNTIME / 'final-studio/summary.json')
    studio_reaudit = read_json(RUNTIME / 'final-studio/lf-framing-audit.json')
    static_summary = read_json(RUNTIME / 'final-static.json')
    validator_final = read_json(RUNTIME / 'validator-fix/final-fix.result.json')
    receipts = {path.name.removesuffix('.result.json'): read_json(path)
                for path in sorted(LOGS.glob('*.result.json'))}
    records = [fingerprint(path) for path in sorted(LOGS.iterdir()) if path.is_file()]
    by_path = {record['path']: record for record in records}
    problems = []
    runs = []
    effective_studio_summary = studio_summary
    for name, receipt in receipts.items():
        if not isinstance(receipt, dict):
            problems.append(f'Unreadable or partial receipt: {name}')
            continue
        category, note = DESCRIPTIONS.get(name, (
            'unclassified', 'New evidence requires explicit classification before final counting.'))
        audit_path = None
        if name.startswith('final-dart-'):
            audit_path = RUNTIME / 'final-dart' / (name + '.audit.json')
            audit = read_json(audit_path)
            if not (source_audit_accepted(dart_summary) and isinstance(audit, dict)
                    and audit.get('accepted') is True and passing(receipt)):
                category = 'pending_final' if not receipt.get('complete') else 'rejected_final'
        elif name == 'final-studio-mail':
            audit_path = RUNTIME / 'final-studio/summary.json'
            if studio_reaudit_accepted(studio_reaudit, receipt, studio_summary, validator_final):
                category = 'accepted_final_after_reaudit'
                audit_path = RUNTIME / 'final-studio/lf-framing-audit.json'
                effective_studio_summary = studio_reaudit
                note = ('The original Flutter command passed. Its unchanged original strict summary '
                        'was rejected because splitlines misframed legal Unicode in JSON strings. '
                        'A separate LF-framing audit retains every strict event rule, agrees with '
                        'the corrected and regression-tested repository checker, and qualifies the same log.')
            elif source_audit_accepted(studio_summary) and passing(receipt):
                category = 'accepted_final'
            elif isinstance(studio_summary, dict) and studio_summary.get('accepted') is False:
                category = 'rejected_final_audit'
            elif receipt.get('complete') and not passing(receipt):
                category = 'rejected_final'
            else:
                category = 'pending_final'
        elif category.startswith('accepted_') and not passing(receipt):
            problems.append(f'Classification conflicts with original result: {name}')
            category = 'unclassified'

        integrity = []
        for recorded in receipt.get('logs', []):
            original_path = Path(recorded['path'])
            relative = str(original_path.relative_to(RUNTIME))
            actual = by_path.get(relative)
            matches = actual is not None and actual['stable_during_read'] \
                and actual['sha256'] == recorded.get('sha256') \
                and actual['bytes'] == recorded.get('bytes')
            integrity.append({'path': relative, 'matches_original_receipt': matches})
            if not matches:
                problems.append(f'Original receipt hash/size mismatch: {relative}')
        error_types = []
        for error in receipt.get('errors', []):
            message = str(error.get('error', error)).splitlines()[0]
            if message not in error_types:
                error_types.append(message)
        run = {
            'name': name, 'classification': category, 'interpretation': note,
            'count_in_final_total': category in ('accepted_final', 'accepted_final_after_reaudit'),
            'started_at_utc': receipt.get('started_at_utc'),
            'cwd': receipt.get('cwd'), 'command': receipt.get('command'),
            'command_shell_display': shlex.join(receipt.get('command', [])),
            'result': summary_result(receipt),
            'receipt': 'logs/' + name + '.result.json',
            'logs': ['logs/' + name + suffix for suffix in ('.events.jsonl', '.stderr.log')],
            'original_log_integrity': integrity,
            'reported_error_types': error_types,
        }
        if audit_path is not None and audit_path.exists():
            run['final_audit'] = str(audit_path.relative_to(RUNTIME))
        if name == 'final-studio-mail' and isinstance(studio_reaudit, dict):
            run['original_audit_history'] = {
                'classification': 'rejected_validator_framing',
                'summary': 'final-studio/summary.json',
                'summary_sha256': studio_reaudit.get('original_summary_sha256'),
                'summary_accepted': studio_reaudit.get('original_summary_accepted'),
                'gate_exit_code': studio_reaudit.get('original_gate_exit_code'),
                'command_exit_code': studio_reaudit.get('original_command_exit_code'),
                'strict_event_audit': studio_reaudit.get('original_strict_event_audit'),
                'originals_rewritten': False,
            }
        runs.append(run)

    runs_by_name = {run['name']: run for run in runs}
    for record in records:
        path = Path(record['path'])
        run_name = next((path.name.removesuffix(suffix) for suffix in (
            '.events.jsonl', '.stderr.log', '.result.json') if path.name.endswith(suffix)), None)
        if run_name in runs_by_name:
            record['run'] = run_name
            record['classification'] = runs_by_name[run_name]['classification']
            record['receipt_present'] = True
        elif run_name == 'final-studio-mail':
            record.update(run=run_name, classification='pending_final', receipt_present=False)
        elif path.name.startswith('final-static-'):
            record.update(
                classification='accepted_final_static' if isinstance(static_summary, dict)
                and static_summary.get('accepted') is True
                and static_summary.get('source_unchanged') is True else 'pending_static',
                receipt='final-static.json',
            )
        elif path.name in ('download-locked.jsonl', 'download-locked.stderr.log', 'pub-get.log'):
            record['classification'] = 'setup_record'
        else:
            record['classification'] = 'unclassified'
            problems.append('Unclassified original log: ' + record['path'])
        record['role'] = ('command_result' if path.name.endswith('.result.json')
                          else 'stdout_events' if path.name.endswith('.events.jsonl')
                          else 'stdout' if path.name.endswith('.stdout.log')
                          else 'stderr' if path.name.endswith('.stderr.log') else 'setup_output')

    support_paths = [RUNTIME / filename for filename in (
        'setup-receipt.json', 'archives-quds.json', 'env.sh', 'run_test.py',
        'download_locked.py', 'qualify_dart_final.py', 'qualify_studio_final.py', 'final-static.json',
        'audit_studio_lf_final.py', 'run_validator_checks.py', 'final-studio-driver.log',
        'outbox-ui-source-screenshot-receipt.json')]
    for directory in ('final-dart', 'final-studio', 'outbox-previews', 'validator-fix'):
        support_paths.extend(path for path in (RUNTIME / directory).glob('*') if path.is_file())
    support = [fingerprint(path) for path in sorted(set(support_paths)) if path.exists()]
    final_cases = []
    for run in runs:
        if not run['count_in_final_total']:
            continue
        if run['name'].startswith('final-dart-'):
            final_cases.extend(read_json(RUNTIME / run['final_audit'])['substantive_cases'])
        else:
            final_cases.extend(effective_studio_summary['cases'])
    unique = {(case['suite_path'], case['name']) for case in final_cases}
    if len(unique) != len(final_cases):
        problems.append('Duplicate case identity across accepted final cohorts; totals need review.')
    studio = runs_by_name.get('final-studio-mail')
    studio_status = {
        'classification': studio['classification'] if studio else 'pending_final',
        'command_receipt_present': studio is not None,
        'complete_passing_result': passing(receipts['final-studio-mail']) if studio else False,
        'source_runtime_audit_accepted': source_audit_accepted(effective_studio_summary),
        'original_source_runtime_audit_accepted': source_audit_accepted(studio_summary),
        'expected_command_receipt': 'logs/final-studio-mail.result.json',
        'expected_source_runtime_audit': 'final-studio/summary.json',
        'planned_runner': 'qualify_studio_final.py',
        'accepted_audit': studio.get('final_audit') if studio and studio['count_in_final_total'] else None,
        'note': 'In-progress log hashes are snapshot identities only. No partial case count is accepted.'
                if not studio or studio['classification'] == 'pending_final'
                else 'See unchanged original command receipt and final source/runtime audit.',
    }
    setup = read_json(RUNTIME / 'setup-receipt.json') or {}
    download_records = [json.loads(line) for line in (LOGS / 'download-locked.jsonl').read_text().splitlines()]
    inventory = {
        'schema': 'quds-local-validation-evidence-inventory-v1',
        'captured_at_utc': captured,
        'runtime_root': str(RUNTIME),
        'scope': 'Every regular file present directly in validation_runtime/logs at capture; originals are never rewritten.',
        'counting_policy': 'Only complete source/runtime-bound accepted_final or accepted_final_after_reaudit cohorts count. Narrow overlaps, partial successes, development probes and setup records add zero. Validator regression methods are reported separately.',
        'final_studio': studio_status,
        'accepted_final_totals': {
            'cohorts': [run['name'] for run in runs if run['count_in_final_total']],
            'distinct_cases': len(unique),
            'distinct_suite_files': len({case['suite_path'] for case in final_cases}),
            'source_case_records': len(final_cases),
            'failed': sum(run['result']['failed'] for run in runs if run['count_in_final_total']),
            'skipped': sum(run['result']['skipped'] for run in runs if run['count_in_final_total']),
        },
        'classification_run_counts': dict(sorted(Counter(run['classification'] for run in runs).items())),
        'original_log_file_count': len(records),
        'original_log_total_bytes': sum(record['bytes'] for record in records),
        'integrity_issues': problems,
        'final_static': {
            'classification': 'accepted_final_static' if isinstance(static_summary, dict)
            and static_summary.get('accepted') is True
            and static_summary.get('source_unchanged') is True else 'pending_static',
            'receipt': 'final-static.json',
            'source_unchanged': static_summary.get('source_unchanged') if static_summary else None,
            'source_file_count': len(static_summary.get('files', {})) if static_summary else None,
            'commands': static_summary.get('commands', []) if static_summary else [],
            'count_in_final_test_total': False,
        },
        'validator_qualification': {
            'final_receipt': 'validator-fix/final-fix.result.json',
            'accepted': validator_final.get('accepted') if validator_final else None,
            'test_methods': validator_final.get('test_methods') if validator_final else None,
            'command': validator_final.get('command') if validator_final else None,
            'exit_code': validator_final.get('exit_code') if validator_final else None,
            'source_unchanged_during_tests': validator_final.get('source_unchanged') if validator_final else None,
            'source_manifest': validator_final.get('source_after') if validator_final else None,
            'count_in_final_product_test_total': False,
            'earlier_records': [
                {'receipt': 'validator-fix/before-fix.result.json',
                 'classification': 'rejected_expected_defect_reproduction'},
                {'receipt': 'validator-fix/after-fix.result.json',
                 'classification': 'accepted_overlapping_intermediate_validator_check'},
            ] if validator_final else [],
        },
        'setup': {
            'sdk': {key: setup.get(key) for key in ('flutter', 'dart', 'framework_revision',
                    'sdk_archive_url', 'sdk_archive_sha256_expected', 'sdk_archive_verified')},
            'pub_get': setup.get('pub_get'),
            'hosted_archive_records': len(download_records),
            'hosted_archive_verifications_pass': all(item.get('verified') is True for item in download_records),
            'download_command_reconstructed_from_script_contract': [
                'python', str(RUNTIME / 'download_locked.py'), str(RUNTIME.parent / 'quds/pubspec.lock')],
            'download_command_note': 'Original archive records retain URLs, exact hashes and sizes; no separate subprocess exit receipt was written for this setup command.',
        },
        'runs': runs,
        'original_logs': records,
        'supporting_evidence': support,
    }
    (RUNTIME / 'evidence-inventory.json').write_text(json.dumps(inventory, indent=2, ensure_ascii=False) + '\n')

    notes = [
        '# Local validation evidence inventory', '',
        f'Captured {captured}. The machine-readable `evidence-inventory.json` records exact commands, results, SHA256 and byte sizes for all **{len(records)} original log files** present at capture. Every hash/size recorded in an original test receipt was checked against the existing logfile. This inventory launches no tests and does not modify originals or repository source.', '',
        '## Counting and completion', '',
        f'Accepted final qualification currently contains **{len(unique)} distinct cases across {len({case["suite_path"] for case in final_cases})} suite files**, with zero failures and zero skips. Only runs in the next table contribute. Narrow runs overlap these scopes and are never added again. Passing cases inside a rejected run also contribute zero.', '',
        '| Final cohort | Passed | Source/runtime qualification |',
        '| --- | ---: | --- |',
    ]
    for run in runs:
        if run['count_in_final_total']:
            notes.append(f'| `{run["name"]}` | {run["result"]["passed"]} | `{run["final_audit"]}` |')
    if studio_status['classification'] == 'pending_final':
        notes.extend(['', '**Final Studio: pending at this snapshot.** No completed passing command plus final source/runtime audit was present. In-progress log hashes, if listed, identify only bytes observed at capture. Run this inventory script again after the existing Studio process completes; it only reads records.'])
    elif studio_status['classification'] in ('rejected_final', 'rejected_final_audit'):
        notes.extend(['', '**Final Studio: rejected.** Its original command result is retained; no partial success is included in final totals.'])
    elif studio_status['classification'] == 'accepted_final_after_reaudit':
        notes.extend(['', '**Studio acceptance uses a separate, explicit re-audit of the same original log.** Flutter completed 610 tests with exit zero. The original aggregate driver exited one and its `final-studio/summary.json` remains `accepted: false` (607 counted cases, nine protocol issues) because Python `str.splitlines()` split legal U+0085/U+2028/U+2029 characters inside three JSON strings. No original log or summary was rewritten and Flutter was not rerun. `final-studio/lf-framing-audit.json` independently checks byte-LF framing, every original strict protocol rule, all 25 expected suites, receipt hashes, source/runtime identity and equality with the corrected repository checker; it qualifies 610 distinct cases with zero issues.'])
    if inventory['final_static']['classification'] == 'accepted_final_static':
        notes.extend(['', f'**Final static gates: accepted separately from test counts.** `final-static.json` binds {inventory["final_static"]["source_file_count"]} Dart files (21 authored and three incoming Word files) to unchanged before/after source hashes. Formatting produced zero changes; strict analysis used `--fatal-infos --fatal-warnings` and reported no issues; `git diff --check` exited zero. Exact commands and the six original stdout/stderr files are included in the JSON inventory.'])
    if validator_final:
        notes.extend(['', f'**Validator correction: {validator_final["test_methods"]} Python checker methods pass separately**, exit {validator_final["exit_code"]}, with unchanged source during the test run. Six new methods cover literal/escaped Unicode names, invalid non-LF framing, CRLF, retained error events, malformed JSON and incomplete cases. The pre-fix run reproduces 16 failing subtests; an intermediate framing check and the final byte-LF check remain separate receipts under `validator-fix/`. These methods do not inflate the 874 product-test count. The pure-Dart manifest retains its original checker hash; the later validator-only change is separately qualified and the independent re-audit confirms the same product case sets.'])
    notes.extend(['', '## Passing narrow and diagnostic runs', '',
                  '| Run | Passed | Disposition |', '| --- | ---: | --- |'])
    for run in runs:
        if run['classification'] in ('accepted_narrow_overlap', 'accepted_development_probe'):
            notes.append(f'| `{run["name"]}` | {run["result"]["passed"]} | {run["interpretation"]} |')
    notes.extend(['', '## Rejected development and setup probes', '',
                  '| Run | Original result | Diagnosis |', '| --- | --- | --- |'])
    for run in runs:
        if run['classification'] == 'rejected_development_probe':
            result = run['result']
            status = (f'timeout; no completion; exit {result["exit_code"]}' if result['timed_out']
                      else f'{result["passed"]} passed / {result["failed"]} failed; exit {result["exit_code"]}')
            notes.append(f'| `{run["name"]}` | {status} | {run["interpretation"]} |')
    notes.extend(['', '## Runtime and fixture boundaries', '',
        '- Official Flutter 3.47.8 / Dart 3.13.7 and 135 checksum-verified locked hosted archives are documented by `setup-receipt.json`, `archives-quds.json` and the original download/pub logs. Offline `dart pub get --offline --enforce-lockfile` exited zero. No production dependency changes or SDK substitutions were needed for setup.',
        '- Pure-Dart final tests use the locked package:test entry point with the exact Flutter-generated native asset mapping. The unsupported VM-flag probe remains rejected; no fallback implementation replaced SQLite.',
        '- Widget tests use the real SQLite repository and Studio adapter with synchronous in-memory SQLite. Bounded FakeAsync pumping includes setup, operations and teardown. Native file-backed adapter tests separately cover disk, reopen and leases. HTTP and native transport fixtures are fakes; these runs do not establish live-provider or installed-platform qualification.',
        '- `outbox-ui-source-screenshot-receipt.json` binds frozen test/helper files and the English/German/Arabic PNGs. The inspected previews use actual bundled Tajawal/MaterialIcons fonts at 700 by 660 pixels. Visual inspection supplements assertions; there is no golden baseline.',
        '- This inventory covers files present in the log directory. Final analyzer/format/diff output is bound to `final-static.json`; earlier output recorded only in terminal conversations is not invented as separate logfiles. Source/runtime manifests and strict event audits remain authoritative for accepted final cohorts.', '',
        '## Rebuilding this inventory', '',
        '```bash', f'python {RUNTIME / "build_evidence_inventory.py"}', '```', '',
        'This reads existing evidence, updates only `evidence-inventory.json` and this notes file, and never launches a compiler or test. Original receipts keep their recorded fields even where an exit of zero accompanies a timed-out, incomplete Flutter run; those probes remain rejected.', '',
        f'Integrity issues at capture: **{len(problems)}**.'
    ])
    if problems:
        notes.extend([''] + ['- ' + issue for issue in problems])
    (RUNTIME / 'evidence-development-notes.md').write_text('\n'.join(notes) + '\n')
    print(json.dumps({key: inventory[key] for key in (
        'captured_at_utc', 'original_log_file_count', 'classification_run_counts',
        'accepted_final_totals', 'final_studio', 'integrity_issues')}, indent=2))


if __name__ == '__main__':
    main()
