"""Preserve original Outbox qualification evidence and bind it to frozen Git source."""
from __future__ import annotations

from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

runtime = Path(__file__).resolve().parent
root = runtime.parent / 'quds'
destination = root / 'docs/validation/mail-outbox-20261120'
evidence = destination / 'evidence'
evidence.mkdir(parents=True, exist_ok=True)
frozen = 'ce9ff1c8b155c03a0e2707d6fc8b41b52e611a93'


def read(path):
    return json.loads((runtime / path).read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


pure = read('final-dart/summary.json')
studio = read('final-studio/lf-framing-audit.json')
static = read('final-static.json')
assert pure['accepted'] and studio['accepted'] and static['accepted']
assert pure['source_unchanged'] and studio['source_unchanged']
assert pure['runtime_unchanged'] and studio['runtime_unchanged']

source_maps = {}
for name in ['final-dart/before-manifest.json', 'final-studio/before-manifest.json']:
    manifest = read(name)
    for item in manifest['source']:
        prior = source_maps.get(item['path'])
        assert prior is None or prior == item['sha256'], item['path']
        source_maps[item['path']] = item['sha256']

for path, expected in source_maps.items():
    data = subprocess.check_output(['git', 'show', f'{frozen}:{path}'], cwd=root)
    assert digest(data) == expected, f'Frozen Git file differs: {path}'
    if path != 'tools/mail/check_store.py':
        assert digest((root / path).read_bytes()) == expected, f'Working file changed: {path}'

validator_paths = ['tools/mail/check_store.py', 'tools/mail/test_check_store.py']
validator_receipt = read('validator-fix/final-fix.result.json')
assert validator_receipt['accepted'] and validator_receipt['source_unchanged']
validator_expected = {item['path']: item['sha256'] for item in validator_receipt['source_after']}
validator_source = []
for path in validator_paths:
    data = (root / path).read_bytes()
    assert digest(data) == validator_expected[path], path
    target = runtime / 'validator-fix' / Path(path).name
    target.parent.mkdir(exist_ok=True)
    target.write_bytes(data)
    validator_source.append({'path': path, 'sha256': digest(data), 'bytes': len(data)})

supplement = read('final-studio/runtime-during-supplement.json')
after_files = []
for item in supplement['files']:
    p = Path(item['path'])
    data = p.read_bytes()
    assert digest(data) == item['sha256'], item['path']
    after_files.append({'path': str(p), 'bytes': len(data), 'sha256': digest(data)})
(runtime / 'final-studio/runtime-after-supplement.json').write_text(json.dumps({
    'captured_at_utc': datetime.now(timezone.utc).isoformat(),
    'phase': 'After final Studio execution; comparison with the during-run supplement.',
    'unchanged_from_during': True,
    'files': after_files,
}, indent=2) + '\n')

case_keys = set()
suite_paths = set()
for cohort in pure['cohorts']:
    audit = read(f"final-dart/{cohort['name']}.audit.json")
    for case in audit['substantive_cases']:
        suite = Path(case['suite_path'])
        suite = str(suite.relative_to(root)) if suite.is_absolute() else str(suite)
        key = (suite, case['name'])
        assert key not in case_keys, key
        case_keys.add(key)
        suite_paths.add(suite)
for case in studio['cases']:
    suite = Path(case['suite_path'])
    suite = str(suite.relative_to(root)) if suite.is_absolute() else str(suite)
    key = (suite, case['name'])
    assert key not in case_keys, key
    case_keys.add(key)
    suite_paths.add(suite)

final_prefixes = ['final-dart-core-store', 'final-dart-word-layout', 'final-dart-smtp', 'final-studio-mail', 'final-static-']
accepted_logs = [p for p in (runtime / 'logs').iterdir() if p.is_file() and any(p.name.startswith(prefix) for prefix in final_prefixes)]
other_logs = [p for p in (runtime / 'logs').iterdir() if p.is_file() and p not in accepted_logs]
support = [runtime / name for name in [
    'setup-receipt.json', 'archives-quds.json', 'env.sh', 'run_test.py',
    'qualify_dart_final.py', 'qualify_studio_final.py', 'package_outbox_evidence.py',
    'write_outbox_readme.py', 'build_evidence_inventory.py', 'audit_studio_lf_final.py',
    'final-static.json', 'outbox-ui-source-screenshot-receipt.json',
    'evidence-inventory.json', 'evidence-development-notes.md',
    'final-studio-driver.log',
] if (runtime / name).is_file()]
for folder in ['final-dart', 'final-studio', 'validator-fix']:
    support.extend(p for p in (runtime / folder).iterdir() if p.is_file())


def archive(name, paths):
    out = evidence / name
    items = []
    with out.open('wb') as target:
        with gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as tar:
                for p in sorted(set(paths)):
                    data = p.read_bytes()
                    relative = p.relative_to(runtime).as_posix()
                    info = tarfile.TarInfo(relative)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    tar.addfile(info, io.BytesIO(data))
                    items.append({'path': relative, 'bytes': len(data), 'sha256': digest(data)})
    return {'path': str(out.relative_to(destination)), 'bytes': out.stat().st_size, 'sha256': digest(out.read_bytes()), 'members': items}


archives = [archive('accepted-runs.tar.gz', accepted_logs + support), archive('development-and-supporting-runs.tar.gz', other_logs)]
visuals = destination / 'visuals'
visuals.mkdir(exist_ok=True)
for language in ['en', 'de', 'ar']:
    shutil.copy2(runtime / f'outbox-previews/outbox-{language}.png', visuals / f'outbox-{language}.png')

cohorts = [{
    'name': c['name'], 'cases': c['unique_cases'], 'suite_files': c['unique_suite_files'],
    'strict_event_audit': c['strict_event_audit'],
} for c in pure['cohorts']]
cohorts.append({'name': 'final-studio-mail', 'cases': studio['unique_cases'], 'suite_files': studio['unique_suite_files'], 'strict_event_audit': studio['strict_event_audit']})
summary = {
    'captured_at_utc': datetime.now(timezone.utc).isoformat(),
    'accepted': True,
    'source_checkpoint': frozen,
    'source_tree': subprocess.check_output(['git', 'rev-parse', frozen + '^{tree}'], cwd=root, text=True).strip(),
    'source_identity': 'Every before-manifest source file matches the frozen Git checkpoint. All product/test inputs also match the current checkout. The sole changed manifested tool is check_store.py, corrected after the run for JSONL LF framing and qualified separately; its original hash remains in the preserved manifest.',
    'combined_distinct_cases': len(case_keys),
    'combined_distinct_suite_files': len(suite_paths),
    'cohorts': cohorts,
    'source_file_union': len(source_maps),
    'pure_source_fingerprint': pure['source_manifest_sha256'],
    'studio_source_fingerprint': studio['source_sha256'],
    'static_gate': {'accepted': True, 'changed_dart_files': len(static['files']), 'format_changed': 0, 'strict_analysis': 'No issues found', 'source_unchanged': True},
    'validator_source': validator_source,
    'validator_regression': {'accepted': True, 'test_methods': validator_receipt['test_methods'], 'counted_separately_from_product_cases': True, 'receipt': 'validator-fix/final-fix.result.json'},
    'studio_audit_correction': 'Original JSONL bytes are unchanged. The original audit incorrectly split legal U+0085/U+2028/U+2029 within three test names; its false summary and driver exit1 are retained. A separate strict LF-framing audit admits all610 complete cases without suppressing any event checks.',
    'runtime_boundary': 'Pinned SDK and lockfile-verified hosted archives; selected runtime inventories. Actual Flutter SQLite map/library and engine frontend are additionally bound during/after the Studio run. This is not a complete transitive runtime-file inventory.',
    'supporting_runs': 'Focused passes and rejected development/probe runs remain in the separate archive; none are added to final case totals.',
    'archives': [{k: v for k, v in a.items() if k != 'members'} for a in archives],
}
(destination / 'acceptance.json').write_text(json.dumps(summary, indent=2) + '\n')
(destination / 'evidence-manifest.json').write_text(json.dumps({'archives': archives}, indent=2) + '\n')
print(json.dumps(summary, indent=2))
