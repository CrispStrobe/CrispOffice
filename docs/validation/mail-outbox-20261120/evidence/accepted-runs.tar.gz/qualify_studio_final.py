"""Qualify the selected Studio Mail workflows with before/after source hashes."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

runtime = Path(__file__).resolve().parent
root = runtime.parent / 'quds'
output = runtime / 'final-studio'
output.mkdir(exist_ok=True)
sys.path.insert(0, str(root / 'tools/mail'))
from check_store import test_summary

names = [
    'studio_mail_outbox_store', 'studio_mail_outbox_submission',
    'studio_mail_outbox_dialog', 'studio_mail_outbox_host',
    'studio_mail_outbox_cloud',
    'studio_mail_compose', 'studio_mail_draft_autosave', 'studio_mail_draft_store',
    'studio_mail_test', 'studio_mail_ews', 'studio_mail_cloud',
    'studio_mail_attachment', 'studio_mail_attachment_compose',
    'studio_mail_attachment_loader', 'studio_mail_forward', 'studio_mail_reply',
    'studio_mail_recipients', 'studio_mail_threading', 'studio_mail_operation',
    'studio_mail_lifecycle', 'studio_mail_session', 'studio_mail_workspace',
    'studio_mail_accounts', 'studio_mail_account_catalog',
    'studio_mail_selected_store_integration',
]
tests = ['test/' + (name if name.endswith('_test') else name + '_test') + '.dart' for name in names]
studio = root / 'packages/quds_office_editor/example'
for name in tests:
    assert (studio / name).is_file(), name


def records(paths, relative=None):
    result = []
    for path in sorted(set(paths)):
        data = path.read_bytes()
        result.append({
            'path': str(path.relative_to(relative) if relative else path),
            'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
        })
    return result


def snapshot(label):
    paths = [root / x for x in ['pubspec.yaml', 'pubspec.lock', '.fvmrc', 'analysis_options.yaml']]
    for package in (root / 'packages').iterdir():
        if not package.is_dir():
            continue
        for folder in ['lib', 'test']:
            if (package / folder).is_dir():
                paths.extend(p for p in (package / folder).rglob('*') if p.is_file())
        for name in ['pubspec.yaml', 'analysis_options.yaml']:
            if (package / name).is_file(): paths.append(package / name)
    for folder in ['lib', 'test']:
        paths.extend(p for p in (studio / folder).rglob('*') if p.is_file())
        paths.extend(p for p in (root / 'third_party/enough_mail' / folder).rglob('*') if p.is_file())
    paths.extend([studio / 'pubspec.yaml', root / 'third_party/enough_mail/pubspec.yaml'])
    runtime_paths = [
        root / '.dart_tool/package_config.json', root / '.dart_tool/native_assets.yaml',
        runtime / 'flutter/bin/cache/dart-sdk/bin/dart',
        runtime / 'flutter/bin/cache/dart-sdk/bin/dartvm',
        runtime / 'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',
        runtime / 'flutter/bin/cache/flutter_tools.snapshot',
        runtime / 'flutter/bin/cache/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot',
        runtime / 'run_test.py', runtime / 'env.sh', Path(__file__).resolve(),
        root / '.dart_tool/lib/libsqlite3.so',
    ]
    source = records(paths, root)
    running = records(runtime_paths)
    result = {
        'captured_at_utc': datetime.now(timezone.utc).isoformat(),
        'git_head_context': subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        'identity': 'Exact file SHA-256 inputs; HEAD is context, not a claim of a clean source tree.',
        'source': source, 'runtime': running,
        'source_sha256': hashlib.sha256(json.dumps(source,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
        'runtime_sha256': hashlib.sha256(json.dumps(running,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
    }
    (output / (label + '-manifest.json')).write_text(json.dumps(result,indent=2)+'\n')
    return result


before = snapshot('before')
print(json.dumps({'stage':'before','files':len(before['source']),'source_sha256':before['source_sha256']}),flush=True)
command = [sys.executable,str(runtime/'run_test.py'),'--name','final-studio-mail','--cwd',str(studio),'--timeout','600','--',
           'flutter','test','--no-pub','--reporter=json','--concurrency=1','--no-track-widget-creation',*tests]
process = subprocess.run(command,cwd=root,check=False)
result = json.loads((runtime/'logs/final-studio-mail.result.json').read_text())
log = runtime/'logs/final-studio-mail.events.jsonl'
audit = test_summary(log)
events=[]
for line in log.read_text().splitlines():
    try: events.append(json.loads(line))
    except ValueError: pass
suites={e['suite']['id']:e['suite'] for e in events if e.get('type')=='suite'}
cases=[{**case,'suite_path':suites[case['suite_id']]['path']} for case in audit['cases']]
unique={(case['suite_path'],case['name']) for case in cases}
after = snapshot('after')
summary={
    'accepted': process.returncode==0 and result['accepted'] and audit['valid'] and len(unique)==len(cases)
                and before['source']==after['source'] and before['runtime']==after['runtime'],
    'source_unchanged':before['source']==after['source'],
    'runtime_unchanged':before['runtime']==after['runtime'],
    'source_sha256':before['source_sha256'],'runtime_sha256':before['runtime_sha256'],
    'command':command,'command_result':result,
    'strict_event_audit':{k:v for k,v in audit.items() if k!='cases'},
    'unique_cases':len(unique),'unique_suite_files':len({case['suite_path'] for case in cases}),
    'cases':cases,
}
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['cases','command_result']},indent=2),flush=True)
raise SystemExit(0 if summary['accepted'] else 1)
