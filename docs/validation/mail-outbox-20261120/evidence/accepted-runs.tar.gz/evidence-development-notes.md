# Local validation evidence inventory

Captured 2026-11-20T13:30:19.034823+00:00. The machine-readable `evidence-inventory.json` records exact commands, results, SHA256 and byte sizes for all **81 original log files** present at capture. Every hash/size recorded in an original test receipt was checked against the existing logfile. This inventory launches no tests and does not modify originals or repository source.

## Counting and completion

Accepted final qualification currently contains **874 distinct cases across 52 suite files**, with zero failures and zero skips. Only runs in the next table contribute. Narrow runs overlap these scopes and are never added again. Passing cases inside a rejected run also contribute zero.

| Final cohort | Passed | Source/runtime qualification |
| --- | ---: | --- |
| `final-dart-core-store` | 172 | `final-dart/final-dart-core-store.audit.json` |
| `final-dart-smtp` | 72 | `final-dart/final-dart-smtp.audit.json` |
| `final-dart-word-layout` | 20 | `final-dart/final-dart-word-layout.audit.json` |
| `final-studio-mail` | 610 | `final-studio/lf-framing-audit.json` |

**Studio acceptance uses a separate, explicit re-audit of the same original log.** Flutter completed 610 tests with exit zero. The original aggregate driver exited one and its `final-studio/summary.json` remains `accepted: false` (607 counted cases, nine protocol issues) because Python `str.splitlines()` split legal U+0085/U+2028/U+2029 characters inside three JSON strings. No original log or summary was rewritten and Flutter was not rerun. `final-studio/lf-framing-audit.json` independently checks byte-LF framing, every original strict protocol rule, all 25 expected suites, receipt hashes, source/runtime identity and equality with the corrected repository checker; it qualifies 610 distinct cases with zero issues.

**Final static gates: accepted separately from test counts.** `final-static.json` binds 24 Dart files (21 authored and three incoming Word files) to unchanged before/after source hashes. Formatting produced zero changes; strict analysis used `--fatal-infos --fatal-warnings` and reported no issues; `git diff --check` exited zero. Exact commands and the six original stdout/stderr files are included in the JSON inventory.

**Validator correction: 48 Python checker methods pass separately**, exit 0, with unchanged source during the test run. Six new methods cover literal/escaped Unicode names, invalid non-LF framing, CRLF, retained error events, malformed JSON and incomplete cases. The pre-fix run reproduces 16 failing subtests; an intermediate framing check and the final byte-LF check remain separate receipts under `validator-fix/`. These methods do not inflate the 874 product-test count. The pure-Dart manifest retains its original checker hash; the later validator-only change is separately qualified and the independent re-audit confirms the same product case sets.

## Passing narrow and diagnostic runs

| Run | Passed | Disposition |
| --- | ---: | --- |
| `outbox-core-codec-direct` | 55 | 55 core/codec cases using the direct locked test runner; overlaps final-dart-core-store. |
| `outbox-core-store-regression` | 172 | Earlier 172-case core/store regression run; superseded by source-bound final-dart-core-store. |
| `outbox-transfer-final` | 19 | 19 transfer cases reran after submitted-record cleanup refinement; overlaps final-dart-core-store, and adds no distinct count to the earlier 19. |
| `outbox-transfer-native-map` | 19 | 19 transfer cases established native SQLite mapping with the exact Flutter-generated asset map; overlaps final-dart-core-store. |
| `outbox-widget-teardown-probe` | 1 | One instrumented widget case verified bounded pumping through database close; diagnostic pass only, superseded by the full frozen widget cohort. |
| `outbox-widgets-final-dev` | 15 | Frozen 10 dialog plus five native/EWS host widget cases pass; includes English/German/Arabic compact views. Included in final Studio scope. |
| `setup-draft-store` | 16 | Environment-readiness run of 16 existing draft-store tests; overlaps the later native adapter and final Studio gates. |
| `studio-outbox-cloud-dev1` | 4 | Four Gmail/Graph widget cases pass on their frozen final authored source; included in final Studio scope despite the development filename. |
| `studio-outbox-store-initial` | 18 | 18 adapter cases before replacing a direct transitive Drift test import with the declared public native repository opener; superseded by studio-outbox-store-native. |
| `studio-outbox-store-native` | 34 | 18 new adapter plus 16 existing draft-store cases use actual native file-backed SQLite, reopen and lease behavior; included in final Studio scope. |
| `studio-outbox-submission-final` | 18 | 18 submission/coordinator cases pass with the declared Flutter test dependency and corrected canonical-CRLF expectation; included in final Studio scope. |

## Rejected development and setup probes

| Run | Original result | Diagnosis |
| --- | --- | --- |
| `outbox-core-store-first` | 55 passed / 19 failed; exit 1 | Initial standard dart test completed with 19 store failures: SQLite native asset mapping was absent; 55 passing partial cases are excluded. |
| `outbox-dialog-dev` | timeout; no completion; exit 0 | 240-second bounded widget probe could not complete its asynchronous SQLite fixture under FakeAsync; shutdown emitted a sink error. No suite completion. |
| `outbox-dialog-io-probe` | timeout; no completion; exit 0 | 90-second bounded native-isolate widget fixture probe; no suite completion. This is a harness timeout, not accepted qualification. |
| `outbox-transfer-direct` | 0 passed / 0 failed; exit 255 | Dart VM rejected unsupported --native-assets flag before starting a suite; exit 255. |
| `outbox-widget-clock-probe` | 0 passed / 1 failed; exit 1 | A fixture callback used guarded expect while tester.pump was active. Replaced callback assertions with expectSync; original guard-conflict failure retained. |
| `outbox-widget-clock-verified` | timeout; no completion; exit 0 | 30-second bounded probe remained blocked at unpumped SQLite teardown; no complete passing suite. |
| `outbox-widgets-memory-dev` | timeout; no completion; exit 0 | 180-second bounded synchronous-memory SQLite widget probe still needed deferred-work clock pumping; no suite completion. |
| `outbox-widgets-qualified-dev` | 9 passed / 6 failed; exit 1 | Nine passes and six fixture failures: RawTooltip cast, ambiguous Refresh target, and offscreen composer taps. Corrected scoped IconButton finders and ensureVisible plus pump; partial passes excluded. |
| `studio-outbox-submission-direct` | 17 passed / 1 failed; exit 1 | Direct development runner had 17 passes and one expected-LF versus canonical-CRLF fixture mismatch; original flutter_test imports were restored for the final run. |

## Runtime and fixture boundaries

- Official Flutter 3.47.8 / Dart 3.13.7 and 135 checksum-verified locked hosted archives are documented by `setup-receipt.json`, `archives-quds.json` and the original download/pub logs. Offline `dart pub get --offline --enforce-lockfile` exited zero. No production dependency changes or SDK substitutions were needed for setup.
- Pure-Dart final tests use the locked package:test entry point with the exact Flutter-generated native asset mapping. The unsupported VM-flag probe remains rejected; no fallback implementation replaced SQLite.
- Widget tests use the real SQLite repository and Studio adapter with synchronous in-memory SQLite. Bounded FakeAsync pumping includes setup, operations and teardown. Native file-backed adapter tests separately cover disk, reopen and leases. HTTP and native transport fixtures are fakes; these runs do not establish live-provider or installed-platform qualification.
- `outbox-ui-source-screenshot-receipt.json` binds frozen test/helper files and the English/German/Arabic PNGs. The inspected previews use actual bundled Tajawal/MaterialIcons fonts at 700 by 660 pixels. Visual inspection supplements assertions; there is no golden baseline.
- This inventory covers files present in the log directory. Final analyzer/format/diff output is bound to `final-static.json`; earlier output recorded only in terminal conversations is not invented as separate logfiles. Source/runtime manifests and strict event audits remain authoritative for accepted final cohorts.

## Rebuilding this inventory

```bash
python /workspace/scratch/bed3312eefb5/validation_runtime/build_evidence_inventory.py
```

This reads existing evidence, updates only `evidence-inventory.json` and this notes file, and never launches a compiler or test. Original receipts keep their recorded fields even where an exit of zero accompanies a timed-out, incomplete Flutter run; those probes remain rejected.

Integrity issues at capture: **0**.
