"""Run one local JSON-reporter test command and preserve original output."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--name', required=True)
parser.add_argument('--cwd', required=True)
parser.add_argument('--timeout', type=int, default=240)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
logs = Path(__file__).resolve().parent / 'logs'
out = logs / (args.name + '.events.jsonl')
err = logs / (args.name + '.stderr.log')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
t0 = time.monotonic()
timed_out = False
with out.open('wb') as stdout, err.open('wb') as stderr:
    process = subprocess.Popen(command, cwd=args.cwd, stdout=stdout, stderr=stderr, start_new_session=True)
    try:
        exit_code = process.wait(timeout=args.timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            exit_code = process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            exit_code = process.wait()
events = []
for line in out.read_text(errors='replace').splitlines():
    try:
        event = json.loads(line)
        if isinstance(event, dict):
            events.append(event)
    except json.JSONDecodeError:
        pass
tests = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
done = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden')]
complete = [e for e in events if e.get('type') == 'done']
result = dict(name=args.name, started_at_utc=started, cwd=args.cwd, command=command,
              exit_code=exit_code, seconds=time.monotonic()-t0, timed_out=timed_out,
              passed=sum(e.get('result') == 'success' and not e.get('skipped') for e in done),
              failed=sum(e.get('result') != 'success' and not e.get('skipped') for e in done),
              skipped=sum(bool(e.get('skipped')) for e in done),
              complete=bool(complete), complete_success=complete[-1].get('success') if complete else None,
              errors=[e for e in events if e.get('type') == 'error'],
              logs=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in [out,err]])
result['accepted'] = exit_code == 0 and not timed_out and result['complete_success'] is True and result['failed'] == 0
(logs / (args.name + '.result.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['accepted'] else 1)
