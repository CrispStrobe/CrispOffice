"""Run the final non-UI cohorts with immutable source/runtime receipts."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone
from urllib.parse import unquote, urlsplit

runtime = Path(__file__).resolve().parent
root = runtime.parent / 'quds'
output = runtime / 'final-dart'
output.mkdir(exist_ok=True)
sys.path.insert(0, str(root / 'tools/mail'))
from check_store import test_summary

store_tests = [
    'codec_test.dart', 'repository_test.dart', 'adversarial_store_test.dart',
    'crash_recovery_test.dart', 'migration_test.dart',
    'draft_editor_state_test.dart', 'outbox_draft_transfer_test.dart',
]
word_tests = [
    'word_incremental_layout_test.dart',
    'word_incremental_layout_prefix_test.dart',
    'word_incremental_layout_differential_test.dart',
]
smtp_tests = sorted(root.glob('third_party/enough_mail/test/smtp/*_test.dart'))
smtp_tests += sorted(root.glob('third_party/enough_mail/test/src/smtp/**/*_test.dart'))
smtp_tests += [
    root / 'third_party/enough_mail/test/mail/mail_send_transaction_test.dart',
    root / 'third_party/enough_mail/test/mail/mail_submission_acceptance_test.dart',
]


def source_paths() -> list[Path]:
    paths = {root / p for p in [
        '.fvmrc', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
        'tools/mail/check_store.py', 'tools/mail/check_reader.py',
    ]}
    for name in ['quds_mail_core', 'quds_mail_store', 'quds_office_engine']:
        package = root / 'packages' / name
        for manifest in ['pubspec.yaml', 'analysis_options.yaml']:
            if (package / manifest).is_file():
                paths.add(package / manifest)
        paths.update(p for p in (package / 'lib').rglob('*') if p.is_file())
    paths.update(p for p in (root / 'packages/quds_mail_core/test').rglob('*') if p.is_file())
    paths.update(root / 'packages/quds_mail_store/test' / p for p in store_tests)
    paths.update(p for p in (root / 'packages/quds_mail_store/tool').rglob('*') if p.is_file())
    paths.update(root / 'packages/quds_office_engine/test' / p for p in word_tests)
    fork = root / 'third_party/enough_mail'
    paths.add(fork / 'pubspec.yaml')
    for folder in ['lib', 'test']:
        paths.update(p for p in (fork / folder).rglob('*') if p.is_file())
    return sorted(paths)


config = root / '.dart_tool/package_config.json'
packages = json.loads(config.read_text())['packages']
resolved = {p['name']: Path(unquote(urlsplit(p['rootUri']).path)) for p in packages if p['rootUri'].startswith('file:')}
test_entry = resolved['test'] / 'bin/test.dart'
dart = runtime / 'flutter/bin/cache/dart-sdk/bin/dart'


def runtime_paths() -> list[Path]:
    paths = {
        config, root / '.dart_tool/native_assets.yaml',
        runtime / 'env.sh', runtime / 'run_test.py', Path(__file__).resolve(),
        dart, dart.with_name('dartvm'),
        runtime / 'flutter/bin/cache/dart-sdk/version',
    }
    mapping = json.loads('\n'.join(
        line for line in (root / '.dart_tool/native_assets.yaml').read_text().splitlines()
        if not line.lstrip().startswith('#')
    ))
    for platform in mapping['native-assets'].values():
        for tag, path in platform.values():
            assert tag == 'absolute'
            paths.add(Path(path))
    for package in ['test', 'test_core', 'test_api', 'sqlite3', 'drift', 'crypto']:
        base = resolved[package]
        paths.add(base / 'pubspec.yaml')
        for folder in ['lib', 'bin']:
            paths.update(p for p in (base / folder).rglob('*') if p.is_file())
    return sorted(paths)


def records(paths: list[Path], relative: Path | None) -> list[dict[str, object]]:
    result = []
    for path in paths:
        data = path.read_bytes()
        item = dict(
            path=str(path.relative_to(relative) if relative else path),
            bytes=len(data),
            sha256=hashlib.sha256(data).hexdigest(),
            mode=oct(path.stat().st_mode & 0o777),
        )
        if path.is_symlink():
            item['symlink_target'] = str(path.readlink())
        result.append(item)
    return result


def snapshot(label: str) -> dict[str, object]:
    source = records(source_paths(), root)
    running = records(runtime_paths(), None)
    identity = dict(
        captured_at_utc=datetime.now(timezone.utc).isoformat(),
        git_head_context=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
        working_tree_context=subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=root, text=True).splitlines(),
        qualification_identity='File SHA-256 manifest; HEAD is contextual and does not assert a clean checkout.',
        source=source,
        runtime=running,
        source_manifest_sha256=hashlib.sha256(json.dumps(source, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        runtime_manifest_sha256=hashlib.sha256(json.dumps(running, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
    )
    (output / f'{label}-manifest.json').write_text(json.dumps(identity, indent=2) + '\n')
    return identity


before = snapshot('before')
print(json.dumps({'stage': 'before', 'source_entries': len(before['source']), 'runtime_entries': len(before['runtime']), 'source_manifest_sha256': before['source_manifest_sha256']}), flush=True)
base = [str(dart), '--disable-dart-dev', '--packages=' + str(config), str(test_entry), '--compiler=kernel', '--concurrency=1', '--reporter=json']
cohorts = [
    ('final-dart-core-store', [
        'packages/quds_mail_core/test',
        *['packages/quds_mail_store/test/' + name for name in store_tests],
    ]),
    ('final-dart-word-layout', [
        'packages/quds_office_engine/test/' + name for name in word_tests
    ]),
    ('final-dart-smtp', [str(p.relative_to(root)) for p in smtp_tests]),
]
receipts = []
for name, tests in cohorts:
    command = [sys.executable, str(runtime / 'run_test.py'), '--name', name, '--cwd', str(root), '--timeout', '240', '--', *base, *tests]
    print(json.dumps({'stage': 'running', 'cohort': name, 'test_paths': tests}), flush=True)
    process = subprocess.run(command, cwd=root, check=False)
    result_path = runtime / 'logs' / (name + '.result.json')
    result = json.loads(result_path.read_text())
    log = runtime / 'logs' / (name + '.events.jsonl')
    audit = test_summary(log)
    events = [json.loads(line) for line in log.read_text().splitlines() if line.strip().startswith('{')]
    suites = {event['suite']['id']: event['suite'] for event in events if event.get('type') == 'suite'}
    case_rows = []
    for case in audit['cases']:
        suite = suites[case['suite_id']]
        case_rows.append({**case, 'suite_path': suite['path'], 'platform': suite['platform']})
    unique_cases = {(case['suite_path'], case['name']) for case in case_rows}
    receipt = dict(
        name=name,
        exact_launcher_command=command,
        launcher_exit_code=process.returncode,
        command_receipt=str(result_path),
        command_result=result,
        strict_event_audit={k: v for k, v in audit.items() if k != 'cases'},
        substantive_cases=case_rows,
        unique_cases=len(unique_cases),
        unique_suite_files=len({case['suite_path'] for case in case_rows}),
        duplicate_case_names_within_suite=len(case_rows) - len(unique_cases),
        accepted=process.returncode == 0 and result['accepted'] and audit['valid'] and len(case_rows) == len(unique_cases),
    )
    receipts.append(receipt)
    (output / (name + '.audit.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'stage': 'audited', 'cohort': name, 'accepted': receipt['accepted'], 'passed': audit['passed'], 'unique_cases': receipt['unique_cases'], 'unique_suite_files': receipt['unique_suite_files']}), flush=True)

after = snapshot('after')
source_unchanged = before['source'] == after['source']
runtime_unchanged = before['runtime'] == after['runtime']
all_cases = {(case['suite_path'], case['name']) for receipt in receipts for case in receipt['substantive_cases']}
summary = dict(
    accepted=source_unchanged and runtime_unchanged and all(r['accepted'] for r in receipts),
    source_unchanged=source_unchanged,
    runtime_unchanged=runtime_unchanged,
    before_manifest='before-manifest.json',
    after_manifest='after-manifest.json',
    source_entries=len(before['source']),
    runtime_entries=len(before['runtime']),
    source_manifest_sha256=before['source_manifest_sha256'],
    runtime_manifest_sha256=before['runtime_manifest_sha256'],
    distinct_cases_across_cohorts=len(all_cases),
    cohorts=[{k: r[k] for k in ['name', 'accepted', 'unique_cases', 'unique_suite_files', 'duplicate_case_names_within_suite', 'strict_event_audit']} for r in receipts],
)
(output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
raise SystemExit(0 if summary['accepted'] else 1)
