"""Re-audit the unchanged Studio JSONL with LF framing and frozen source binding.

This does not run tests, alter original logs, or replace the rejected original
gate summary. The exact original strict auditor is loaded from the qualified
checkpoint. Only its text record splitter is adapted to JSONL's LF delimiter.
The corrected current repository auditor is independently compared when present.
"""
from __future__ import annotations

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys


RUNTIME = Path(__file__).resolve().parent
ROOT = RUNTIME.parent / 'quds'
OUTPUT = RUNTIME / 'final-studio'
CHECKPOINT = 'ce9ff1c8b155c03a0e2707d6fc8b41b52e611a93'
ORIGINAL_CHECKER = '0aff1311f094eeef819d27579f9df0991ae625a73067f1c15983a0ac2acba3c4'
CORRECTED_CHECKER = 'd56b7abce9d4693b21ea9d3f3cb81456a6712a4543323e58ac1c21169caed998'
CORRECTED_TESTS = 'f414de6e298fbc1a0c7dfb4e9a322f2a0a74f5489812da19405125f80584f7b6'
SQLITE = '0a65852703763619a7a34633b4959b3b86c4103804a4dfe4e8b27b5de1c0647b'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(records):
    return sha(json.dumps(records, sort_keys=True, separators=(',', ':')).encode())


def read_json(path):
    return json.loads(path.read_bytes())


def strict_function(source):
    # Use the pinned implementation's entire function, without modifying any
    # acceptance, failure, completion, hidden-case or protocol validation rule.
    function = next(node for node in ast.parse(source).body
                    if isinstance(node, ast.FunctionDef) and node.name == 'test_summary')
    namespace = {'Path': Path, 'json': json}
    exec(compile(ast.Module(body=[function], type_ignores=[]),
                 '<pinned test_summary>', 'exec'), namespace)
    return namespace['test_summary']


class LfText(str):
    def splitlines(self, keepends=False):
        if keepends:
            raise ValueError('The audited function does not request keepends.')
        return self.split('\n')


class LfLog:
    def __init__(self, data):
        self.data = data

    def read_text(self, errors=None):
        # Invalid UTF-8 is an audit error, even though the legacy reader allowed
        # replacement. Original event bytes and event objects are not rewritten.
        return LfText(self.data.decode('utf-8', errors='strict'))


def lf_events(data):
    records = []
    for number, raw in enumerate(data.split(b'\n'), 1):
        if not raw.strip():
            continue
        event = json.loads(raw.decode('utf-8', errors='strict'))
        if not isinstance(event, dict):
            raise ValueError(f'Non-object JSONL record {number}')
        records.append((number, event))
    return records


def case_records(data, audit):
    events = [event for _, event in lf_events(data)]
    suite_rows = [event['suite'] for event in events if event.get('type') == 'suite']
    suites = {suite['id']: suite for suite in suite_rows}
    if len(suites) != len(suite_rows):
        raise ValueError('Duplicate suite identity')
    return [{**case, 'suite_path': suites[case['suite_id']]['path']}
            for case in audit['cases']]


def case_keys(cases):
    return {(str(Path(case['suite_path']).resolve().relative_to(ROOT)), case['name'])
            for case in cases}


def source_binding(records, allowed_current_changes=()):
    missing, checkpoint_mismatch, current_mismatch, allowed = [], [], [], []
    process = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT,
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    for record in records:
        path = record['path']
        process.stdin.write((CHECKPOINT + ':' + path + '\n').encode())
        process.stdin.flush()
        header = process.stdout.readline().rstrip(b'\n').split()
        if len(header) != 3 or header[1] != b'blob':
            missing.append(path)
            continue
        size = int(header[2])
        content = process.stdout.read(size)
        if process.stdout.read(1) != b'\n':
            raise ValueError('Invalid Git object framing')
        if size != record['bytes'] or sha(content) != record['sha256']:
            checkpoint_mismatch.append(path)
        current = (ROOT / path).read_bytes()
        if len(current) != record['bytes'] or sha(current) != record['sha256']:
            target = allowed if path in allowed_current_changes else current_mismatch
            target.append({'path': path, 'qualified_sha256': record['sha256'],
                           'current_sha256': sha(current)})
    process.stdin.close()
    if process.wait() != 0:
        raise ValueError('Git object reader failed')
    return {'entries': len(records), 'checkpoint_missing': missing,
            'checkpoint_mismatches': checkpoint_mismatch,
            'current_product_mismatches': current_mismatch,
            'separate_validator_changes': allowed,
            'accepted': not missing and not checkpoint_mismatch and not current_mismatch}


original_source = subprocess.check_output(
    ['git', 'show', CHECKPOINT + ':tools/mail/check_store.py'], cwd=ROOT)
assert sha(original_source) == ORIGINAL_CHECKER
original_auditor = strict_function(original_source)
current_source = (ROOT / 'tools/mail/check_store.py').read_bytes()
assert sha(current_source) == CORRECTED_CHECKER
assert sha((ROOT / 'tools/mail/test_check_store.py').read_bytes()) == CORRECTED_TESTS

validator_receipt_path = RUNTIME / 'validator-fix/final-fix.result.json'
validator = read_json(validator_receipt_path)
validator_log = (RUNTIME / 'validator-fix/final-fix.stderr.log').read_text()
method_lines = [line for line in validator_log.split('\n')
                if re.match(r'^test_\S+ \(.+\) \.\.\. ok$', line)]
validator_accepted = (
    validator['accepted'] and validator['exit_code'] == 0
    and not validator['timed_out'] and validator['complete_success']
    and validator['source_before'] == validator['source_after']
    and validator['test_methods'] == len(method_lines) == len(set(method_lines)) == 48
    and 'Ran 48 tests in ' in validator_log and validator_log.rstrip().endswith('OK')
    and not any(' ... skipped' in line for line in validator_log.split('\n'))
    and all((ROOT / item['path']).stat().st_size == item['bytes']
            and sha((ROOT / item['path']).read_bytes()) == item['sha256']
            for item in validator['source_after'])
    and all(Path(item['path']).stat().st_size == item['bytes']
            and sha(Path(item['path']).read_bytes()) == item['sha256']
            for item in validator['logs']))

original_summary_path = OUTPUT / 'summary.json'
original_summary_bytes = original_summary_path.read_bytes()
original_summary = json.loads(original_summary_bytes)
before = read_json(OUTPUT / 'before-manifest.json')
after = read_json(OUTPUT / 'after-manifest.json')
result = read_json(RUNTIME / 'logs/final-studio-mail.result.json')
log_path = RUNTIME / 'logs/final-studio-mail.events.jsonl'
log_bytes = log_path.read_bytes()
audit = original_auditor(LfLog(log_bytes))
cases = case_records(log_bytes, audit)
unique = case_keys(cases)

runner_path = RUNTIME / 'qualify_studio_final.py'
runner_bytes = runner_path.read_bytes()
runner = ast.parse(runner_bytes)
names = next(ast.literal_eval(node.value) for node in runner.body
             if isinstance(node, ast.Assign)
             and any(isinstance(target, ast.Name) and target.id == 'names'
                     for target in node.targets))
expected_suites = {
    'packages/quds_office_editor/example/test/'
    + (name if name.endswith('_test') else name + '_test') + '.dart'
    for name in names
}
actual_suites = {path for path, _ in unique}
runner_bound = next(record['sha256'] for record in before['runtime']
                    if record['path'] == str(runner_path)) == sha(runner_bytes)

pure_before = read_json(RUNTIME / 'final-dart/before-manifest.json')
pure_after = read_json(RUNTIME / 'final-dart/after-manifest.json')
studio_binding = source_binding(before['source'])
pure_binding = source_binding(pure_before['source'], ['tools/mail/check_store.py'])

pure_keys = set()
pure_audits = []
for name in ['final-dart-core-store', 'final-dart-word-layout', 'final-dart-smtp']:
    data = (RUNTIME / 'logs' / (name + '.events.jsonl')).read_bytes()
    check = original_auditor(LfLog(data))
    rows = case_records(data, check)
    keys = case_keys(rows)
    saved = read_json(RUNTIME / 'final-dart' / (name + '.audit.json'))
    pure_audits.append({
        'name': name, 'strict_valid': check['valid'], 'unique_cases': len(keys),
        'unique_suite_files': len({path for path, _ in keys}),
        'duplicate_cases': len(rows) - len(keys),
        'overlap_with_earlier_pure_cohorts': len(keys & pure_keys),
        'matches_saved_case_set': keys == case_keys(saved['substantive_cases']),
    })
    pure_keys |= keys

native_data = (RUNTIME / 'logs/studio-outbox-store-native.events.jsonl').read_bytes()
native_audit = original_auditor(LfLog(native_data))
native_keys = case_keys(case_records(native_data, native_audit))

supplement_path = OUTPUT / 'runtime-during-supplement.json'
supplement = read_json(supplement_path)
supplement_matches = all(Path(record['path']).stat().st_size == record['bytes']
                         and sha(Path(record['path']).read_bytes()) == record['sha256']
                         for record in supplement['files'])
native_map = ROOT / 'packages/quds_office_editor/example/build/native_assets/linux/native_assets.json'
mapping = read_json(native_map)
tag, library = mapping['native-assets']['linux_x64']['package:sqlite3/src/ffi/libsqlite3.g.dart']
sqlite_matches = tag == 'absolute' and sha(Path(library).read_bytes()) == SQLITE

framing_cases = []
for number, event in lf_events(log_bytes):
    name = event.get('test', {}).get('name', '')
    for character in ['\u0085', '\u2028', '\u2029']:
        if character in name:
            framing_cases.append({'lf_record': number, 'test_id': event['test']['id'],
                                  'character': f'U+{ord(character):04X}'})

corrected_comparison = None
if sha(current_source) != ORIGINAL_CHECKER:
    corrected = strict_function(current_source)(log_path)
    corrected_comparison = {
        'checker_sha256': sha(current_source), 'strict_valid': corrected['valid'],
        'identical_to_independent_lf_audit': corrected == audit,
    }

source_unchanged = before['source'] == after['source']
runtime_unchanged = before['runtime'] == after['runtime']
fingerprints_valid = (
    fingerprint(before['source']) == before['source_sha256'] == after['source_sha256']
    and fingerprint(before['runtime']) == before['runtime_sha256'] == after['runtime_sha256'])
log_receipts_match = all(Path(record['path']).stat().st_size == record['bytes']
                         and sha(Path(record['path']).read_bytes()) == record['sha256']
                         for record in result['logs'])
accepted = (
    result['exit_code'] == 0 and not result['timed_out']
    and result['complete_success'] is True and audit['valid']
    and len(unique) == len(cases) and actual_suites == expected_suites
    and source_unchanged and runtime_unchanged and fingerprints_valid and runner_bound
    and studio_binding['accepted'] and pure_binding['accepted']
    and pure_before['source'] == pure_after['source']
    and pure_before['runtime'] == pure_after['runtime']
    and log_receipts_match and supplement_matches and sqlite_matches
    and all(item['strict_valid'] and item['duplicate_cases'] == 0
            and item['overlap_with_earlier_pure_cohorts'] == 0
            and item['matches_saved_case_set'] for item in pure_audits)
    and not (unique & pure_keys) and native_keys <= unique
    and validator_accepted and corrected_comparison is not None
    and corrected_comparison['identical_to_independent_lf_audit'])

receipt = {
    'accepted': accepted, 'captured_at_utc': datetime.now(timezone.utc).isoformat(),
    'source_unchanged': source_unchanged, 'runtime_unchanged': runtime_unchanged,
    'source_sha256': before['source_sha256'], 'runtime_sha256': before['runtime_sha256'],
    'source_entries': len(before['source']), 'selected_runtime_entries': len(before['runtime']),
    'checkpoint': CHECKPOINT,
    'checkpoint_tree': subprocess.check_output(['git', 'rev-parse', CHECKPOINT + '^{tree}'],
                                               cwd=ROOT, text=True).strip(),
    'strict_event_audit': {key: value for key, value in audit.items() if key != 'cases'},
    'unique_cases': len(unique), 'unique_suite_files': len(actual_suites), 'cases': cases,
    'duplicate_case_names_within_suite': len(cases) - len(unique),
    'expected_suite_paths': sorted(expected_suites),
    'missing_expected_suites': sorted(expected_suites - actual_suites),
    'unexpected_suites': sorted(actual_suites - expected_suites),
    'original_summary_sha256': sha(original_summary_bytes),
    'original_log_sha256': sha(log_bytes),
    'original_command_exit_code': result['exit_code'],
    'original_gate_exit_code': 1 if not original_summary['accepted'] else 0,
    'original_gate_exit_provenance': 'qualify_studio_final.py exits 1 for its retained accepted=false summary; this audit does not relaunch that gate.',
    'original_summary_accepted': original_summary['accepted'],
    'original_strict_event_audit': original_summary['strict_event_audit'],
    'root_cause': 'Python str.splitlines() split legal unescaped U+0085, U+2028 and U+2029 inside three JSON test-name strings. JSONL records are LF-framed; the original log bytes are valid and complete.',
    'affected_records': framing_cases,
    'provenance': {
        'original_checker_sha256': ORIGINAL_CHECKER,
        'method': 'Extract the complete strict test_summary function from the checkpoint with AST; run it unchanged on strict UTF-8 text whose splitlines uses LF only. Independently decode every byte-LF record and require all 25 expected suite paths.',
        'raw_log_modified': False, 'original_summary_replaced': False, 'tests_rerun': False,
        'reproduction_command': [sys.executable, str(Path(__file__).resolve())],
        'reproduction_script_sha256': sha(Path(__file__).read_bytes()),
        'qualified_runner_sha256': sha(runner_bytes),
    },
    'corrected_repository_auditor_comparison': corrected_comparison,
    'separate_validator_qualification': {
        'accepted': validator_accepted, 'test_methods': len(method_lines),
        'receipt': str(validator_receipt_path),
        'receipt_sha256': sha(validator_receipt_path.read_bytes()),
        'checker_sha256': CORRECTED_CHECKER, 'test_source_sha256': CORRECTED_TESTS,
        'source_before_after_equal': validator['source_before'] == validator['source_after'],
        'notes': 'Separate Python validator qualification; not added to the Dart case count.',
    },
    'studio_source_binding': studio_binding, 'pure_source_binding': pure_binding,
    'log_receipt_hashes_match': log_receipts_match,
    'runtime_inventory_boundary': '11 selected before/after runtime inputs plus the separately timed actual Flutter map/library/frontend supplement; not a complete dependency closure.',
    'runtime_during_supplement_sha256': sha(supplement_path.read_bytes()),
    'runtime_during_supplement_current_match': supplement_matches,
    'actual_flutter_sqlite_matches_pinned_sha256': sqlite_matches,
    'pure_cohorts': pure_audits, 'pure_unique_cases': len(pure_keys),
    'cross_cohort_case_overlap': len(unique & pure_keys),
    'combined_unique_cases': len(unique | pure_keys),
    'combined_unique_suite_files': len({path for path, _ in unique | pure_keys}),
    'earlier_native_adapter_cases': len(native_keys),
    'earlier_native_adapter_entirely_contained_in_studio': native_keys <= unique,
}
assert original_summary_path.read_bytes() == original_summary_bytes
assert log_path.read_bytes() == log_bytes
(OUTPUT / 'lf-framing-audit.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items()
                  if key not in ['cases', 'expected_suite_paths', 'original_strict_event_audit']}, indent=2))
raise SystemExit(0 if accepted else 1)
