#!/usr/bin/env bash
set -euo pipefail

# Run from a fresh runtime directory at the recorded path. Restore only the
# scripts, env.sh and bin wrappers from this evidence bundle into that directory.
runtime_dir=/workspace/scratch/ecc61e3c20da/runtime-flutter
validation_repo=/workspace/scratch/ecc61e3c20da/quds_flutter_validation
expected_head=75f694d5e42049f356ba52b26329d199bfb7c2aa
test "$(git -C "$validation_repo" rev-parse HEAD)" = "$expected_head"
test -z "$(git -C "$validation_repo" status --porcelain)"
test ! -e "$runtime_dir/flutter"
chmod +x "$runtime_dir/bin/dart" "$runtime_dir/bin/flutter"

python3 "$runtime_dir/prepare_sdk.py"
python3 "$runtime_dir/restore_pins.py" \
  --lock "$runtime_dir/flutter/packages/flutter_tools/pubspec.lock" \
  --lock "$validation_repo/pubspec.lock"
source "$runtime_dir/env.sh"

(
  cd "$runtime_dir/flutter/packages/flutter_tools"
  dart pub get --offline --enforce-lockfile
)
flutter --version --machine
(
  cd "$validation_repo"
  dart pub get --offline --enforce-lockfile
)
mkdir -p "$runtime_dir/test-runner"
dart compile kernel \
  --packages="$validation_repo/.dart_tool/package_config.json" \
  "$runtime_dir/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart" \
  -o "$runtime_dir/test-runner/test-runner.dill"
mkdir -p "$validation_repo/packages/quds_mail_store/build/runtime-preparation"
cp "$runtime_dir/sqlite_probe.dart" \
  "$validation_repo/packages/quds_mail_store/build/runtime-preparation/sqlite_probe.dart"
(
  cd "$validation_repo/packages/quds_mail_store"
  dart run build/runtime-preparation/sqlite_probe.dart
)
python3 "$runtime_dir/qualify_incoming.py" \
  --out "$runtime_dir/qualification-75f694d5"
python3 "$runtime_dir/qualify_store_node.py"
