#!/usr/bin/env python3
"""Exercise the store's explicit Node-only suite with the actual Dart compiler."""
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

from qualify_incoming import BASE, REPO, RUNTIME, HEAD, TREE, DART, CONFIG, STORE
from qualify_incoming import digest, git, now, report, source_manifest, write

assert git('rev-parse', 'HEAD') == HEAD
assert git('rev-parse', 'HEAD^{tree}') == TREE
assert not git('status', '--porcelain')
assert shutil.disk_usage(BASE).free >= 2 * 1024 ** 3
out = RUNTIME / 'qualification-75f694d5-node'
out.mkdir(exist_ok=False)
before = source_manifest()
write(out / 'source-before.json', before)
node = Path(shutil.which('node')).resolve()
command = [str(DART), '--old_gen_heap_size=1024', f'--packages={CONFIG}',
    str(RUNTIME / 'test-runner/test-runner.dill'), '--platform=node', '--compiler=dart2js',
    '--concurrency=1', '--timeout=4x', '--reporter=json', 'test/browser_problem_test.dart']
receipt = {'head': HEAD, 'tree': TREE, 'command': command, 'cwd': str(STORE),
    'started_utc': now(), 'status': 'running', 'node_executable': str(node),
    'node_version': subprocess.check_output([str(node), '--version'], text=True).strip(),
    'node_sha256': digest(node), 'script_sha256': digest(__file__),
    'helper_sha256': digest(RUNTIME / 'qualify_incoming.py')}
write(out / 'progress.json', receipt)
start = time.monotonic()
heartbeat = start
stdout, stderr = out / 'store-node.jsonl', out / 'store-node.stderr'
with stdout.open('w') as output, stderr.open('w') as error:
    process = subprocess.Popen(command, cwd=STORE, stdout=output, stderr=error, start_new_session=True)
    while process.poll() is None:
        if time.monotonic() - start > 1200 or shutil.disk_usage(BASE).free < 2 * 1024 ** 3:
            os.killpg(process.pid, signal.SIGTERM)
            receipt['stopped'] = True
            process.wait(timeout=5)
            break
        if time.monotonic() - heartbeat > 30:
            print(json.dumps({'phase': 'running', 'gate': 'store-node',
                              'seconds': round(time.monotonic() - start, 1)}), flush=True)
            heartbeat = time.monotonic()
        time.sleep(0.5)
result = report(stdout)
write(out / 'store-node-cases.json', result.pop('cases'))
after = source_manifest()
write(out / 'source-after.json', after)
receipt.update({'exit_code': process.returncode, 'finished_utc': now(),
    'seconds': round(time.monotonic() - start, 3), 'tests': result,
    'source_unchanged': before == after, 'git_status': git('status', '--porcelain'),
    'stdout_sha256': digest(stdout), 'stderr_sha256': digest(stderr),
    'free_bytes': shutil.disk_usage(BASE).free})
passed = process.returncode == 0 and result['success'] and before == after and not receipt['git_status']
receipt['status'] = 'passed' if passed else 'failed'
write(out / 'progress.json', receipt)
print(json.dumps(receipt), flush=True)
raise SystemExit(0 if passed else 1)
