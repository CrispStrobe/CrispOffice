#!/usr/bin/env python3
"""Package frozen qualification receipts with deterministic archive metadata."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

BASE = Path('/workspace/scratch/ecc61e3c20da')
RUNTIME = BASE / 'runtime-flutter'
REPO = BASE / 'quds_flutter_validation'
OUT = BASE / 'quds_office_suite/docs/validation/word-vba-compatibility-20261121/evidence'
ARCHIVE = OUT / 'incoming-flutter.tar.gz'
INDEX = OUT / 'incoming-flutter-index.json'

parser = argparse.ArgumentParser()
parser.add_argument('--replace-existing', action='store_true')
args = parser.parse_args()
assert OUT.is_dir()
if args.replace_existing:
    prior = json.loads(INDEX.read_text())
    assert hashlib.sha256(ARCHIVE.read_bytes()).hexdigest() == prior['archive_sha256']
else:
    assert not ARCHIVE.exists() and not INDEX.exists(), 'Do not replace existing evidence.'
names = [
    'INCOMING_FLUTTER_REPLAY.md', 'incoming-flutter-summary.json',
    'prepare_sdk.py', 'restore_pins.py', 'qualify_incoming.py', 'qualify_store_node.py',
    'replay_setup.sh', 'package_evidence.py', 'env.sh', 'bin/dart', 'bin/flutter',
    'saved_mail_close_probe_test.dart', 'sqlite_probe.dart', 'runtime-final.json',
    'sdk-preparation.json', 'sdk-preparation.log', 'archive-members.json',
    'pub-cache-receipt.json', 'sdk-pub-restore.log', 'workspace-pub-restore.log',
]
for directory in ['logs', 'qualification-75f694d5', 'qualification-75f694d5-node']:
    names.extend(str(path.relative_to(RUNTIME))
                 for path in (RUNTIME / directory).rglob('*') if path.is_file())
payloads = {f'runtime-flutter/{name}': (RUNTIME / name).read_bytes()
            for name in sorted(set(names))}
copies = {
    'runtime-flutter/replay/workspace-pubspec.lock': REPO / 'pubspec.lock',
    'runtime-flutter/replay/workspace-pubspec.yaml': REPO / 'pubspec.yaml',
    'runtime-flutter/replay/workspace-fvmrc.json': REPO / '.fvmrc',
    'runtime-flutter/replay/workspace-package-config.json': REPO / '.dart_tool/package_config.json',
    'runtime-flutter/replay/workspace-native-assets.yaml': REPO / '.dart_tool/native_assets.yaml',
    'runtime-flutter/replay/flutter-tools-pubspec.lock': RUNTIME / 'flutter/packages/flutter_tools/pubspec.lock',
}
payloads.update({name: path.read_bytes() for name, path in copies.items()})

# Logs contain local fixture names and public download URLs only. Reject common
# private-key, provider token, authorization and token-bearing URL patterns.
secret_patterns = [
    rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    rb'github_pat_[A-Za-z0-9_]{20,}', rb'gh[pousr]_[A-Za-z0-9]{30,}',
    rb'(?i)authorization\s*[:=]\s*["\x27]?bearer\s+[A-Za-z0-9._-]{12,}',
    rb'(?i)[?&](?:access_token|refresh_token|client_secret)=[A-Za-z0-9%._-]{8,}',
]
for name, data in payloads.items():
    assert not any(re.search(pattern, data) for pattern in secret_patterns), name
    data.decode('utf-8')  # Every included payload must be text, never a binary.

members = []
tar_buffer = io.BytesIO()
with tarfile.open(fileobj=tar_buffer, mode='w', format=tarfile.USTAR_FORMAT) as archive:
    for name, data in sorted(payloads.items()):
        member = tarfile.TarInfo(name)
        member.size = len(data)
        member.mtime = member.uid = member.gid = 0
        member.uname = member.gname = ''
        member.mode = 0o644
        archive.addfile(member, io.BytesIO(data))
        members.append({'path': name, 'bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()})
compressed = io.BytesIO()
with gzip.GzipFile(fileobj=compressed, mode='wb', filename='', mtime=0, compresslevel=9) as stream:
    stream.write(tar_buffer.getvalue())
archive_bytes = compressed.getvalue()
with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as check:
    assert [m.name for m in check.getmembers()] == [m['path'] for m in members]
    for member in members:
        assert hashlib.sha256(check.extractfile(member['path']).read()).hexdigest() == member['sha256']

summary = json.loads((RUNTIME / 'incoming-flutter-summary.json').read_text())
index = {
    'schema_version': 1,
    'archive': ARCHIVE.name,
    'archive_bytes': len(archive_bytes),
    'archive_sha256': hashlib.sha256(archive_bytes).hexdigest(),
    'member_count': len(members),
    'uncompressed_member_bytes': sum(m['bytes'] for m in members),
    'deterministic_metadata': {'format': 'ustar', 'tar_mtime': 0, 'uid': 0, 'gid': 0,
        'uname': '', 'gname': '', 'mode': '0644', 'gzip_mtime': 0,
        'gzip_original_filename': '', 'compression_level': 9},
    'summary': summary,
    'summary_member': 'runtime-flutter/incoming-flutter-summary.json',
    'replay_note_member': 'runtime-flutter/INCOMING_FLUTTER_REPLAY.md',
    'sensitive_content_check': 'All members UTF-8 text; scanned private-key, GitHub-token, Bearer-authorization and token-URL patterns; no matches. Logs contain local fixtures and public downloads only.',
    'excluded': ['SDK and package-cache contents', 'native binaries', 'compiled kernels',
        'generated JavaScript', 'screenshots', 'live-account data'],
    'members': members,
}
ARCHIVE.write_bytes(archive_bytes)
INDEX.write_text(json.dumps(index, indent=2, sort_keys=True) + '\n')
print(json.dumps({'archive': str(ARCHIVE), 'archive_bytes': len(archive_bytes),
    'archive_sha256': index['archive_sha256'], 'member_count': len(members),
    'index': str(INDEX), 'index_sha256': hashlib.sha256(INDEX.read_bytes()).hexdigest()}))
