import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_mail_ui/quds_mail_ui.dart';
import 'package:quds_office_studio/studio_mail.dart';
import 'package:quds_office_studio/studio_saved_mail.dart';
import 'package:quds_office_studio/studio_strings.dart';

Future<void> settleRoute(WidgetTester tester) async {
  await tester.pump();
  await tester.pump(const Duration(milliseconds: 350));
  await tester.pump();
}

void main() {
  for (final language in StudioLanguage.values) {
    testWidgets('${language.name}: one Close across saved-message navigation', (
      tester,
    ) async {
      final strings = StudioStrings(language);
      await tester.binding.setSurfaceSize(const Size(1440, 900));
      addTearDown(() => tester.binding.setSurfaceSize(null));
      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) => Scaffold(
              body: TextButton(
                onPressed: () => showDialog<void>(
                  context: context,
                  builder: (_) => StudioMailDialog(strings: strings),
                ),
                child: const Text('Open native Mail'),
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.text('Open native Mail'));
      await settleRoute(tester);
      expect(find.byType(StudioMailDialog), findsOneWidget);
      expect(find.byTooltip(strings.close), findsOneWidget);

      await tester.tap(find.byTooltip(strings.savedMessages));
      await settleRoute(tester);
      expect(find.byType(StudioSavedMailView), findsOneWidget);
      expect(
        find.byTooltip(strings.close),
        findsOneWidget,
        reason: 'The whole native dialog must expose exactly one Close.',
      );
      final reader = tester
          .widget<MailMessageView>(find.byType(MailMessageView))
          .controller;

      await tester.tap(find.byTooltip(strings.mailAccounts));
      await settleRoute(tester);
      expect(find.byType(MailMessageView), findsNothing);
      expect(find.byTooltip(strings.close), findsOneWidget);
      expect(reader.isDisposed, isFalse);

      await tester.tap(find.byTooltip(strings.savedMessages));
      await settleRoute(tester);
      expect(find.byTooltip(strings.close), findsOneWidget);
      expect(
        tester.widget<MailMessageView>(find.byType(MailMessageView)).controller,
        same(reader),
      );
      await tester.tap(find.byTooltip(strings.close));
      await settleRoute(tester);
      expect(find.byType(StudioMailDialog), findsNothing);
      expect(reader.isDisposed, isTrue);
      expect(tester.takeException(), isNull);
    });
  }
}
