#!/usr/bin/env python3
"""Restore official hosted archives matching supplied real Pub locks exactly."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile
import threading
import urllib.parse
import urllib.request
import yaml

parser = argparse.ArgumentParser()
parser.add_argument('--lock', type=Path, action='append', required=True)
args = parser.parse_args()
ROOT = Path(__file__).resolve().parent
CACHE = ROOT / 'pub-cache'
for name in ['_temp', 'hosted/pub.dev', 'hosted-hashes/pub.dev']:
    (CACHE / name).mkdir(parents=True, exist_ok=True)
packages, locks = {}, {}
for lock in args.lock:
    locks[str(lock.resolve())] = hashlib.sha256(lock.read_bytes()).hexdigest()
    for name, item in yaml.safe_load(lock.read_text())['packages'].items():
        if item['source'] != 'hosted': continue
        info = item['description']
        if info['url'] != 'https://pub.dev': raise RuntimeError('Unexpected archive host')
        key = name + '-' + item['version']
        record = {'name': name, 'version': item['version'], 'sha256': info['sha256']}
        if key in packages and packages[key] != record: raise RuntimeError('Conflicting hashes')
        packages[key] = record
extract_lock = threading.Lock()

def restore(pair):
    key, record = pair
    target = CACHE / 'hosted/pub.dev' / key
    marker = CACHE / 'hosted-hashes/pub.dev' / (key + '.sha256')
    if target.is_dir() and marker.is_file() and marker.read_text().strip() == record['sha256']:
        return {**record, 'source': 'verified cache', 'verified': True}
    if target.exists(): raise RuntimeError('Unverified existing package: ' + key)
    url = 'https://pub.dev/api/archives/' + urllib.parse.quote(key, safe='-._+') + '.tar.gz'
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=120) as response: data = response.read()
            break
        except Exception:
            if attempt == 2: raise
    actual = hashlib.sha256(data).hexdigest()
    if actual != record['sha256']: raise RuntimeError('Archive SHA256 mismatch: ' + key)
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as bundle:
        size = sum(member.size for member in bundle.getmembers() if member.isfile())
        with extract_lock:
            if size + 2 * 1024**3 > shutil.disk_usage(ROOT).free:
                raise RuntimeError('Pub restore reached 2 GiB disk reserve')
            target.mkdir()
            bundle.extractall(target, filter='data')
            marker.write_text(actual)
    print(json.dumps({'package': key, 'archive_bytes': len(data), 'extracted_bytes': size}), flush=True)
    return {**record, 'url': url, 'archive_bytes': len(data), 'extracted_bytes': size, 'verified': True}

print(json.dumps({'packages': len(packages), 'locks': locks}), flush=True)
with ThreadPoolExecutor(max_workers=8) as pool:
    restored = list(pool.map(restore, sorted(packages.items())))
receipt_path = ROOT / 'pub-cache-receipt.json'
previous = json.loads(receipt_path.read_text()) if receipt_path.exists() else {'locks': {}, 'packages': {}}
previous['locks'].update(locks)
previous['packages'].update({r['name'] + '-' + r['version']: r for r in restored})
previous['free_bytes'] = shutil.disk_usage(ROOT).free
receipt_path.write_text(json.dumps(previous, indent=2) + '\n')
print(json.dumps({'verified_packages': len(restored), 'total_verified_packages': len(previous['packages']), 'free_bytes': previous['free_bytes']}), flush=True)
