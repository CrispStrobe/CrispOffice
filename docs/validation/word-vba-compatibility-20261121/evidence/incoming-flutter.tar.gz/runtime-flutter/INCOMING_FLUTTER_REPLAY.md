# Incoming Flutter validation for the Word VBA integration

The approved application snapshot is commit
`75f694d5e42049f356ba52b26329d199bfb7c2aa`, tree
`b05bbf48aaa6189c8c297866b4b39263004ca85f`. It was checked out into a separate,
detached sparse worktree at
`/workspace/scratch/ecc61e3c20da/quds_flutter_validation`. Sparse cones were
`packages apps third_party tool tools`; root files were included. These runs did
not modify the main engine checkout or its Dart package configuration.

## Results

| Cohort | Passed | Test source files | Runtime |
| --- | ---: | ---: | --- |
| Complete mail-store VM/native cohort | 825 | 34 | Real SQLite, Dart VM |
| Mail-store explicit Node-only cohort | 3 | 1 | Actual dart2js and Node |
| Four incoming Studio sync suites | 36 | 4 | Flutter tester |
| Saved-mail suite | 14 | 1 | Flutter tester |
| Connected saved-message navigation case | 1 | 1 | Flutter tester |
| Independent global Close probe | 3 | 1 scratch source | Flutter tester |
| Zotero multi-paragraph controller suite | 109 | 1 | Flutter tester |
| **Total** | **991** | **43 source files, including the scratch probe** | |

All 991 tests passed, with zero failures and zero reported skips. The store has
35 test source files: its default VM run loads 34; `browser_problem_test.dart`
declares `@TestOn('node')` and was run separately using the actual JavaScript
compiler. Every store test file was covered exactly once. Source-file counts
describe distinct test files in these cohorts; they do not count setup/teardown
events as tests.

Static analysis passed with both `--fatal-infos` and `--fatal-warnings` for:

- The seven changed Studio Mail native/shared files, all four new sync test
  files, and the saved-mail test.
- `word_zotero_multiparagraph_controller_test.dart`.
- The complete `quds_mail_store` package.

The independent Close probe checks the whole native dialog, so it detects a
duplicate outer toolbar Close action that the existing saved-view-scoped finder
would miss. It covers English, German and Arabic, account-to-saved-to-account
navigation, reader retention, and disposal after closing. The probe was kept in
scratch; no production or tracked test source was changed for it.

Both runs recorded all 6,076 present tracked source files before and after.
Those manifests are identical, the worktree remained clean, and the recorded
SDK executables, package configuration, test kernel, SQLite binary, native-asset
manifest, scripts and dependency receipts retained their hashes. The omitted
paths in the sparse checkout are recoverable from the exact Git tree. The
later merge of documentation-only upstream commits is outside these source
receipts; application-source equivalence is established separately by the
parent integration record.

## Genuine runtime and dependencies

These Flutter gates used Flutter **3.47.8** with its embedded Dart **3.13.7**.
The separate main-engine gate used Dart **3.14.1**; these are distinct runtimes.

The entire official Linux Flutter archive was streamed and SHA256-verified:

`https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.47.8-stable.tar.xz`

- Archive bytes: `1581444364`.
- Archive SHA256: `baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2`.
- Framework revision: `737ba8f885dc774b53b442759999a312c9461e4e`.
- Engine revision: `cf636b1dfb818dd6a3ff16e390e93b1a036969c8`.

Extraction retained genuine Linux debug/test engine binaries, the full Dart SDK,
Flutter/tool/package sources and SDK Git metadata. Unused target-platform
artifacts and the SDK's own test/example directories were omitted to retain a
2 GiB disk reserve. Repository assets, package imports, native hooks and test
behavior were left enabled. No generated substitutes or stub dependencies were
used.

All hosted packages were restored from official Pub archives and checked against
the real Flutter-tools and workspace lockfile SHA256 entries: 202 unique
name/version archives across the two locks. Actual `dart pub get --offline
--enforce-lockfile` resolved both workspaces; tracked manifests remained
unchanged. `pub-cache-receipt.json` records each archive and both lock hashes.

The default sqlite3 3.9.1 native hook supplied SQLite 3.54.1. A real in-memory
FTS5 create/insert/query probe succeeded. The generated native library SHA256
was `0a65852703763619a7a34633b4959b3b86c4103804a4dfe4e8b27b5de1c0647b`.
The mail-store suite exercised transactions and actual child-process crash
recovery with this library. Node-only tests used Node `v24.22.3`.

## Evidence and replay

`qualification-75f694d5/progress.json` contains every main command, cwd, duration,
exit code, output hash and test count. The companion Node directory contains
the explicit JavaScript command and its receipts. Raw JSON reporters, stderr,
analysis logs, per-case results, and source/runtime manifests are included.
`incoming-flutter-summary.json` provides a combined machine-readable index.
The external `incoming-flutter-index.json` lists the archive hash and the exact
size/SHA256 of each archive member.

The setup scripts require Linux x64, Python with PyYAML, Git, access to the
official Flutter/Pub/native-hook download endpoints, an available Node binary,
and sufficient disk space to keep the 2 GiB reserve. They deliberately use the
recorded absolute paths and exact source commit. To reproduce, place the source
worktree at that path, and restore only the scripts, `env.sh` and `bin/` wrappers
into a fresh `runtime-flutter` directory. Keep the captured result directories
separate because the replay refuses to overwrite them. Run:

```sh
bash /workspace/scratch/ecc61e3c20da/runtime-flutter/replay_setup.sh
```

The setup verifies the official SDK archive and executable hashes, restores
locked packages, resolves actual dependencies, compiles the actual package:test
runner, invokes the default SQLite build hook, then runs all focused gates.
`qualify_incoming.py` is the unchanged script used for the main qualification;
`qualify_store_node.py` is the unchanged script used for the Node supplement.
`replay_setup.sh` consolidates the recorded setup commands for replay and was
syntax-checked after qualification; it was not an additional qualification run.

The evidence archive excludes SDKs, package caches, native binaries, compiled
kernels, generated JavaScript and image captures. It contains no credentials or
live-service transcripts. These local tests do not establish live-account mail
provider acceptance, macOS runtime acceptance, screenshot acceptance, or
Microsoft Word execution compatibility. No GitHub Actions queue was queried or
waited on.
