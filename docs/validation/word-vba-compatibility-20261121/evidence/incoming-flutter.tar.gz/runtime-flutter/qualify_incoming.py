#!/usr/bin/env python3
"""Focused genuine Flutter/SQLite validation of a frozen incoming snapshot."""
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

BASE = Path('/workspace/scratch/ecc61e3c20da')
REPO = BASE / 'quds_flutter_validation'
RUNTIME = BASE / 'runtime-flutter'
HEAD = '75f694d5e42049f356ba52b26329d199bfb7c2aa'
TREE = 'b05bbf48aaa6189c8c297866b4b39263004ca85f'
DART = RUNTIME / 'flutter/bin/cache/dart-sdk/bin/dart'
FLUTTER = RUNTIME / 'bin/flutter'
CONFIG = REPO / '.dart_tool/package_config.json'
STUDIO = REPO / 'packages/quds_office_editor/example'
EDITOR = REPO / 'packages/quds_office_editor'
STORE = REPO / 'packages/quds_mail_store'
SQLITE_SHA = '0a65852703763619a7a34633b4959b3b86c4103804a4dfe4e8b27b5de1c0647b'

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()

def source_manifest():
    names = subprocess.check_output(['git', '-C', str(REPO), 'ls-files', '-z']).decode().split('\0')
    return {name: {'sha256': digest(REPO / name), 'bytes': (REPO / name).stat().st_size}
            for name in names if name and (REPO / name).is_file()}

def report(path):
    starts, ends, suites, errors, done = {}, {}, {}, [], []
    for line in path.read_text(errors='replace').splitlines():
        try:
            item = json.loads(line)
        except ValueError:
            continue
        if not isinstance(item, dict):
            continue
        kind = item.get('type')
        if kind == 'testStart':
            starts[item['test']['id']] = item['test']
        elif kind == 'testDone':
            ends[item['testID']] = item
        elif kind == 'suite':
            suites[item['suite']['id']] = item['suite']
        elif kind == 'error':
            errors.append(item)
        elif kind == 'done':
            done.append(item)
    cases = []
    for identity, end in ends.items():
        if end.get('hidden'):
            continue
        start = starts.get(identity, {})
        suite = suites.get(start.get('suiteID'), {})
        cases.append({'name': start.get('name'), 'file': suite.get('path'),
                      'result': end.get('result'), 'skipped': end.get('skipped', False)})
    counts = collections.Counter('skipped' if case['skipped'] else case['result'] for case in cases)
    return {'passed': counts['success'], 'failed': counts['error'] + counts['failure'],
            'skipped': counts['skipped'], 'test_files': len(suites), 'completed': bool(done),
            'success': bool(done) and done[-1].get('success') is True,
            'error_events': errors, 'cases': cases}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--only', action='append')
    args = parser.parse_args()
    assert git('rev-parse', 'HEAD') == HEAD
    assert git('rev-parse', 'HEAD^{tree}') == TREE
    assert not git('status', '--porcelain'), 'Tracked source must be clean.'
    assert digest(REPO / '.dart_tool/lib/libsqlite3.so') == SQLITE_SHA
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    flutter = [str(FLUTTER), 'test', '--no-pub', '--concurrency=1', '--timeout=4x', '--reporter=json']
    vm = [str(DART), '--old_gen_heap_size=1024', f'--packages={CONFIG}',
          str(RUNTIME / 'test-runner/test-runner.dill'), '--compiler=kernel',
          '--concurrency=1', '--timeout=4x', '--reporter=json']
    sync_tests = [f'test/studio_mail_sync_{name}_test.dart' for name in ['dialog', 'host', 'native', 'store']]
    studio_sources = [f'lib/studio_mail_{name}.dart' for name in [
        'cached_mail', 'ews', 'mailbox_store', 'message_loader', 'native', 'sync_dialog', 'sync_strings']]
    analyze = [str(DART), 'analyze', '--fatal-infos', '--fatal-warnings']
    plans = {
        'store': (STORE, vm + ['test'], True),
        'sync': (STUDIO, flutter + sync_tests, True),
        'saved-mail': (STUDIO, flutter + ['test/studio_saved_mail_test.dart'], True),
        'native-navigation': (STUDIO, flutter + ['test/studio_mail_test.dart', '--plain-name',
             'saved-message navigation retains the connected account'], True),
        'close-probe': (STUDIO, flutter + [str(RUNTIME / 'saved_mail_close_probe_test.dart')], True),
        'zotero': (EDITOR, flutter + ['test/word_zotero_multiparagraph_controller_test.dart'], True),
        'studio-analysis': (STUDIO, analyze + studio_sources + sync_tests + ['test/studio_saved_mail_test.dart'], False),
        'zotero-analysis': (EDITOR, analyze + ['test/word_zotero_multiparagraph_controller_test.dart'], False),
        'store-analysis': (STORE, analyze, False),
    }
    chosen = args.only or list(plans)
    if any(name not in plans for name in chosen):
        parser.error('Unknown gate selected')
    before = source_manifest()
    write(out / 'source-before.json', before)
    runtime_files = [DART, RUNTIME / 'flutter/bin/cache/artifacts/engine/linux-x64/flutter_tester',
        RUNTIME / 'flutter/bin/cache/flutter_tools.snapshot', RUNTIME / 'test-runner/test-runner.dill',
        RUNTIME / 'pub-cache-receipt.json', RUNTIME / 'sdk-preparation.json', RUNTIME / 'env.sh',
        Path(__file__), RUNTIME / 'saved_mail_close_probe_test.dart', CONFIG,
        REPO / '.dart_tool/lib/libsqlite3.so', REPO / '.dart_tool/native_assets.yaml']
    write(out / 'runtime-before.json', {str(p): digest(p) for p in runtime_files})
    receipt = {'head': HEAD, 'tree': TREE, 'started_utc': now(), 'selected': chosen,
        'source_files': len(before), 'normal_flutter_assets': True, 'native_hooks_enabled': True,
        'sqlite_sha256': SQLITE_SHA, 'sdk': 'Flutter 3.47.8, Dart 3.13.7', 'commands': [],
        'status': 'running', 'initial_free_bytes': shutil.disk_usage(BASE).free}
    write(out / 'progress.json', receipt)
    for name in chosen:
        if shutil.disk_usage(BASE).free < 2 * 1024 ** 3:
            receipt['status'] = 'disk-reserve-blocked'
            break
        cwd, command, is_test = plans[name]
        stdout = out / (name + ('.jsonl' if is_test else '.log'))
        stderr = out / (name + '.stderr')
        row = {'gate': name, 'command': command, 'cwd': str(cwd), 'started_utc': now(),
               'stdout': stdout.name, 'stderr': stderr.name}
        receipt['commands'].append(row)
        write(out / 'progress.json', receipt)
        print(json.dumps({'phase': 'starting', 'gate': name}), flush=True)
        start = time.monotonic()
        heartbeat = start
        with stdout.open('w') as output, stderr.open('w') as error:
            process = subprocess.Popen(command, cwd=cwd, env=os.environ.copy(), stdout=output,
                                       stderr=error, start_new_session=True)
            row['pid'] = process.pid
            try:
                while process.poll() is None:
                    elapsed = time.monotonic() - start
                    if elapsed > 1200 or shutil.disk_usage(BASE).free < 2 * 1024 ** 3:
                        row['stopped'] = 'timeout' if elapsed > 1200 else 'disk-reserve'
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait()
                        break
                    if time.monotonic() - heartbeat >= 30:
                        print(json.dumps({'phase': 'running', 'gate': name, 'seconds': round(elapsed, 1),
                            'stdout_bytes': stdout.stat().st_size, 'stderr_bytes': stderr.stat().st_size,
                            'free_bytes': shutil.disk_usage(BASE).free}), flush=True)
                        heartbeat = time.monotonic()
                    time.sleep(0.5)
            except BaseException:
                os.killpg(process.pid, signal.SIGTERM)
                raise
        row.update({'exit_code': process.returncode, 'finished_utc': now(),
            'seconds': round(time.monotonic() - start, 3), 'stdout_sha256': digest(stdout),
            'stderr_sha256': digest(stderr)})
        if is_test:
            result = report(stdout)
            write(out / (name + '-cases.json'), result.pop('cases'))
            row['tests'] = result
        print(json.dumps({'phase': 'completed', 'gate': name, 'exit_code': row['exit_code'],
            'tests': row.get('tests')}), flush=True)
        write(out / 'progress.json', receipt)
        if process.returncode or (is_test and not row['tests']['success']):
            receipt['status'] = 'failed'
            break
    else:
        receipt['status'] = 'passed'
    after = source_manifest()
    write(out / 'source-after.json', after)
    write(out / 'runtime-after.json', {str(p): digest(p) for p in runtime_files})
    receipt.update({'source_unchanged': before == after, 'final_git_status': git('status', '--porcelain'),
        'finished_utc': now(), 'final_free_bytes': shutil.disk_usage(BASE).free})
    if before != after or receipt['final_git_status']:
        receipt['status'] = 'source-drift'
    write(out / 'progress.json', receipt)
    print(json.dumps({'phase': 'finished', 'status': receipt['status'],
                      'source_unchanged': receipt['source_unchanged']}), flush=True)
    return 0 if receipt['status'] == 'passed' else 1

if __name__ == '__main__':
    raise SystemExit(main())
