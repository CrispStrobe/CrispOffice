#!/usr/bin/env python3
"""Restore verified Linux Flutter test tooling without changing a source checkout."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tarfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
SDK = ROOT / 'flutter'
URL = 'https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.47.8-stable.tar.xz'
EXPECTED = 'baf7dcc5a3dbba60fe863bf493a6cf203195621f7786eaa5a1bba02cd0d87dd2'
RESERVE = 2 * 1024**3
record = {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'running', 'archive_url': URL}

def save():
    (ROOT / 'sdk-preparation.json').write_text(json.dumps(record, indent=2) + '\n')

class DigestReader:
    def __init__(self, stream):
        self.stream, self.hash, self.total = stream, hashlib.sha256(), 0
    def read(self, n=-1):
        data = self.stream.read(n)
        self.hash.update(data)
        self.total += len(data)
        return data

def selected(name):
    parts = PurePosixPath(name).parts
    if not parts or parts[0] != 'flutter': return False
    if len(parts) == 1: return True
    if parts[1] == '.git': return True
    if parts[1] == 'bin':
        relative = '/'.join(parts[1:])
        if relative.startswith('bin/cache/artifacts/engine/'):
            platform = parts[5] if len(parts) > 5 else ''
            if platform.startswith(('android', 'ios', 'darwin', 'windows', 'linux-arm64', 'linux-x64-profile', 'linux-x64-release')):
                return False
        return True
    if parts[1] == 'packages':
        return not (len(parts) > 3 and parts[3] in {'test', 'test_private', 'test_fixes', 'example', 'examples', 'benchmark', 'benchmarks'})
    return len(parts) == 2 and parts[1] in {'LICENSE', 'AUTHORS', 'README.md', 'version', '.metadata', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', 'flutter_console.bat'}

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''): value.update(block)
    return value.hexdigest()

for name in ['logs', 'pub-cache', 'tmp', 'config', 'cache', 'data', 'bin']:
    (ROOT / name).mkdir(parents=True, exist_ok=True)
if SDK.exists(): raise SystemExit('Use a fresh SDK directory')
try:
    save()
    print('Restoring official Flutter 3.47.8 Linux test runtime', flush=True)
    expanded, members, last = 0, [], time.monotonic()
    with urllib.request.urlopen(URL, timeout=120) as response:
        reader = DigestReader(response)
        with tarfile.open(fileobj=reader, mode='r|xz') as bundle:
            for member in bundle:
                if selected(member.name):
                    if member.size + RESERVE > shutil.disk_usage(ROOT).free:
                        raise RuntimeError('SDK extraction stopped at 2 GiB disk reserve')
                    bundle.extract(member, ROOT, filter='data')
                    expanded += member.size
                    if member.isfile(): members.append({'path': member.name, 'bytes': member.size})
                if time.monotonic() - last > 20:
                    print(json.dumps({'downloaded_bytes': reader.total, 'expanded_bytes': expanded, 'free_bytes': shutil.disk_usage(ROOT).free}), flush=True)
                    last = time.monotonic()
        while reader.read(8 * 1024 * 1024): pass
        actual = reader.hash.hexdigest()
    if actual != EXPECTED: raise RuntimeError('Official archive SHA256 mismatch: ' + actual)
    expected_executables = {
        'bin/cache/dart-sdk/bin/dart': '01e869e4af277734b02ab8898b870c6b00c9bec61bbcf9c923cd14de7ed85fbb',
        'bin/cache/artifacts/engine/linux-x64/flutter_tester': '800f4ca182df7dd2fb46a42dea5d76277b9dbc5e8cd2915e02bcbc978681b45f',
    }
    for name, sha in expected_executables.items():
        if digest(SDK / name) != sha: raise RuntimeError('Executable mismatch: ' + name)
    record.update(status='ready', archive_sha256=actual, archive_bytes=reader.total, extracted_bytes=expanded, executables_sha256=expected_executables, full_archive_verified=True)
    (ROOT / 'archive-members.json').write_text(json.dumps(members, indent=2) + '\n')
    (ROOT / 'sdk-ready').touch()
except BaseException as error:
    record.update(status='failed', error=repr(error))
    raise
finally:
    record.update(finished_at_utc=datetime.now(timezone.utc).isoformat(), free_bytes=shutil.disk_usage(ROOT).free)
    save()
    print(json.dumps(record), flush=True)
