import hashlib
import json
import pathlib
import subprocess
import time
from datetime import datetime, timezone
repo=pathlib.Path('/workspace/scratch/ecc61e3c20da/quds_office_suite')
engine=repo/'packages/quds_office_engine'
out=pathlib.Path('/workspace/scratch/ecc61e3c20da/runtime/incoming-zotero')
tests=sorted((engine/'test').glob('word_zotero_*_test.dart'))+[engine/'test/zotero_add_note_protocol_test.dart',engine/'test/zotero_citing_test.dart']
command=['/workspace/scratch/ecc61e3c20da/runtime/run-engine-tests.sh',*(str(p.relative_to(engine)) for p in tests),'--reporter','json']
def inputs():
    paths=set(tests)
    for base in (engine/'lib',repo/'packages/legacy_doc_parser/lib',engine/'test/support',engine/'test/fixtures'):
        paths.update(p for p in base.rglob('*') if p.is_file())
    for p in [repo/'pubspec.yaml',repo/'pubspec.lock',repo/'.dart_tool/package_config.json',engine/'pubspec.yaml',repo/'packages/legacy_doc_parser/pubspec.yaml']:
        if p.is_file():paths.add(p)
    return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
def save(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
before=inputs();save('inputs-before.json',before)
save('command.json',{'command':command,'working_directory':str(repo),'selected_tests':[str(p.relative_to(engine)) for p in tests],'selected_file_count':len(tests),'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'incoming_snapshot':'a6095c304ad2d6935f2ae6f8b74412038d19f142','input_scope':'All engine and legacy_doc_parser library source; selected Word Zotero and add-note/citing protocol tests; all engine test support and fixtures; workspace/engine/legacy pubspecs, lockfile and package config','runner_sha256':hashlib.sha256(pathlib.Path(command[0]).read_bytes()).hexdigest(),'test_runner_dill_sha256':hashlib.sha256(pathlib.Path('/workspace/scratch/ecc61e3c20da/runtime/test-runner/test-runner.dill').read_bytes()).hexdigest()})
start=datetime.now(timezone.utc).isoformat();t0=time.monotonic()
with (out/'events.jsonl').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
    proc=subprocess.run(command,cwd=repo,stdout=stdout,stderr=stderr)
after=inputs();save('inputs-after.json',after)
events=[]
for line in (out/'events.jsonl').read_text().splitlines():
    try:events.append(json.loads(line))
    except json.JSONDecodeError:pass
cases=[x for x in events if x.get('type')=='testDone' and not x.get('hidden')]
changed=[p for p in sorted(set(before)&set(after)) if before[p]!=after[p]]
added=sorted(set(after)-set(before));removed=sorted(set(before)-set(after))
result={'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'duration_seconds':time.monotonic()-t0,'exit_code':proc.returncode,'selected_file_count':len(tests),'visible_tests':len(cases),'passed':sum(x['result']=='success' and not x['skipped'] for x in cases),'failed':sum(x['result']!='success' for x in cases),'skipped':sum(x['skipped'] for x in cases),'done':[x for x in events if x.get('type')=='done'],'input_count':len(before),'after_input_count':len(after),'changed_inputs':changed,'added_inputs':added,'removed_inputs':removed,'source_stable':not(changed or added or removed)}
save('result.json',result)
save('tests.json',[x for x in events if x.get('type') in ['testStart','testDone','error','done']])
print(json.dumps(result,indent=2))
raise SystemExit(proc.returncode)
