# Incoming Zotero table-cell replacement review and local qualification

## Result

No blocking correctness or regression issue was identified in incoming snapshot `a6095c304ad2d6935f2ae6f8b74412038d19f142`. The reviewed engine source and two changed/new engine test files exactly match that snapshot. No product source or refs were edited by this review.

The actual Dart source runner completed **884 visible tests across 27 files**, with **zero failures and zero skips**, in approximately 189 seconds. This includes **62 new table-cell replacement cases**. All **558 captured inputs** remained byte-identical before and after execution; there were no added or removed inputs.

## Behavior and guards

Research content can replace a consecutive range of ordinary paragraphs inside one existing cell, including nested cells and cells in authored footnotes/endnotes. Existing prefix/suffix text, paragraph emphasis, cell/table structure, sibling cells, headings/lists/images and citation handling are preserved by the existing splice paths.

The session now records initial eligibility and the full table/row/cell/list ownership chain. Identity changes are refused both before staging and at apply, even when flattened paragraph identities and text look unchanged. An initially cross-cell range cannot become eligible after the picker opens. The scanner only descends through tables; it does not admit controls, frames or merged continuation cells. Cross-cell/row/section boundaries, structural markers, duplicate paragraph occurrences, selected nested tables and incoming research-table payloads remain refused.

The rich insertion path now inserts each actual block separately, allowing an existing covariant `List<WmlParagraph>` owner to accept paragraph results without an invalid wider-iterable runtime check. The old cross-cell refusal category remains tested; only an ordinary same-cell range is newly accepted.

## Executed coverage

The selection contains every `word_zotero_*_test.dart` suite plus `zotero_add_note_protocol_test.dart` and `zotero_citing_test.dart`. It covers real native save/reopen, follow-up edits, body/note stories, simple and complex citation fields, rich research content, images/lists/headings, caret placement, merged-origin cells, alias detection, stale ownership, document/field guards, transfer sessions, and the existing add-note/citing protocol.

`command.json` retains the exact 27-file list and executed command. `inputs-before.json` and `inputs-after.json` cover all engine and legacy parser library source, selected tests, all engine test support and fixtures, workspace/engine/legacy pubspecs, the lockfile and package config. Raw events, per-test outcomes, stderr, counts and source binding are retained beside this report.

## Limits

`WordZoteroCitingSession.apply` continues to require the caller's rollback/undo boundary; the engine session does not promise standalone rollback after every arbitrary mutation exception. Flutter/controller behavior is qualified separately. These checks do not claim a new Notes-pane table-cell editing surface or observed live Zotero, Word, LibreOffice or OpenOffice acceptance. The new owner snapshot applies to multiparagraph research ranges; single-paragraph selection semantics were not redesigned. Traversal limits conservatively refuse overly complex documents.
