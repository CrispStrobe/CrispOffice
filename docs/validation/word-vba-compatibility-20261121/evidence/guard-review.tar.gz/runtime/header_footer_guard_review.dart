import 'dart:convert';
import 'dart:typed_data';
import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/quds_office_automation.dart';
import 'package:quds_office_engine/src/automation/operations/word_steps.dart' as native;
import '../quds_office_suite/packages/quds_office_engine/tool/macros/web_vba_word_headers_footers_smoke.dart' as fixture;

Iterable<XmlElement> descendants(XmlElement parent, String name) sync* {
  for (final child in parent.childElements) {
    if (child.namespaceUri == OfficeNamespaces.w && child.localName == name) yield child;
    yield* descendants(child, name);
  }
}

XmlElement reference(XmlElement section, String name, String type) => section.childrenNamed(name, namespaceUri: OfficeNamespaces.w).singleWhere((e) => e.getAttribute('type', namespaceUri: OfficeNamespaces.w) == type);

List<String> evenFooterTargets(Uint8List bytes) {
  final package = OpcPackage.openBytes(bytes);
  final sections = descendants(XmlDocument.parse(package.getPart('/word/document.xml')!.readText()).root!, 'sectPr').toList();
  final relations = package.relationshipsFor('/word/document.xml');
  return [for (final section in sections) relations.resolve(relations.byId(reference(section, 'footerReference', 'even').getAttribute('id', namespaceUri: OfficeNamespaces.r)!)!)];
}

Future<void> main() async {
  final results = <String,Object?>{};
  final package = OpcPackage.openBytes(fixture.wordHeadersFootersInput());
  final main = package.getPart('/word/document.xml')!;
  final xml = XmlDocument.parse(main.readText());
  final sections = descendants(xml.root!, 'sectPr').toList();
  final second = reference(sections[1], 'footerReference', 'even');
  final third = reference(sections[2], 'footerReference', 'even');
  final oldId = third.getAttribute('id', namespaceUri: OfficeNamespaces.r)!;
  final relations = package.relationshipsFor('/word/document.xml');
  final oldPart = relations.resolve(relations.byId(oldId)!);
  third.setAttribute('id', second.getAttribute('id', namespaceUri: OfficeNamespaces.r)!, prefix:'r', namespaceUri:OfficeNamespaces.r);
  relations.removeById(oldId);
  package.deletePart(oldPart);
  main.writeText(xml.toXmlString());
  final input = package.save();
  final session = OfficeMacroSession(input, format:OfficeMacroFormat.docx);
  try {
    await session.run(fixture.wordHeadersFootersPlan('ThisDocument.Sections(1).Headers(wdHeaderFooterPrimary).Range.Paragraphs(1).Range.Font.Bold = True'));
    results['unselectedSharedPart'] = {'accepted':true,'before':evenFooterTargets(input),'after':evenFooterTargets(session.bytes)};
  } catch (error) {
    results['unselectedSharedPart'] = {'accepted':false,'error':error.toString(),'atomic':session.revision==0 && base64Encode(session.bytes)==base64Encode(input)};
  }
  for (final shareRun in [false,true]) {
    final shared = WmlRunProps();
    final bodyRun = WmlRun(text:'Body',properties:shared);
    final headerRun = shareRun ? bodyRun : WmlRun(text:'Header',properties:shared);
    final body = WmlParagraph(inlines:[bodyRun]);
    final header = WmlParagraph(inlines:[headerRun]);
    final document = WmlDocument(sections:[WmlSection(blocks:[body],header:[header],linkToPrevious:false)]);
    try {
      native.applyStep(document, {'op':'runFormat','story':'header','section':0,'paragraph':0,'bold':true});
      results[shareRun ? 'sharedRun' : 'sharedRunProperties'] = {'accepted':true,'bodyBold':bodyRun.properties.bold,'headerBold':headerRun.properties.bold};
    } catch (error) {
      results[shareRun ? 'sharedRun' : 'sharedRunProperties'] = {'accepted':false,'error':error.toString(),'bodyBold':bodyRun.properties.bold,'headerBold':headerRun.properties.bold,'atomic':!bodyRun.properties.bold && !headerRun.properties.bold};
    }
  }
  for (final kind in ['selected-foreign-inline','unselected-foreign-inline','selected-foreign-run','selected-paragraph-attribute']) {
    final inputPackage = OpcPackage.openBytes(fixture.wordHeadersFootersInput());
    final uri = kind.startsWith('unselected') ? '/word/footer12.xml' : '/word/header1.xml';
    final part = inputPackage.getPart(uri)!;
    final before = part.readText();
    final changed = kind.endsWith('paragraph-attribute')
        ? before.replaceFirst('<w:p>', '<w:p xmlns:x="urn:guard-projection" x:marker="KEEP-PAYLOAD">')
        : before.replaceFirst('</w:p>', kind.endsWith('foreign-run')
            ? '<x:r xmlns:x="urn:guard-projection"><x:t>FOREIGN-TEXT</x:t></x:r></w:p>'
            : '<x:payload xmlns:x="urn:guard-projection" x:marker="KEEP-PAYLOAD">FOREIGN-TEXT</x:payload></w:p>');
    if (changed == before) throw StateError('Probe did not alter intended XML');
    part.writeText(changed);
    final original = inputPackage.save();
    final edited = OfficeMacroSession(original,format:OfficeMacroFormat.docx);
    try {
      await edited.run(fixture.wordHeadersFootersPlan('ThisDocument.Sections(1).Headers(wdHeaderFooterPrimary).Range.Paragraphs(1).Range.Font.Bold = False'));
      final after = OpcPackage.openBytes(edited.bytes).getPart(uri)!.readText();
      results[kind] = {'accepted':true,'foreignNamespacePreserved':after.contains('urn:guard-projection'),'payloadMarkerPreserved':after.contains('KEEP-PAYLOAD'),'foreignTextPromoted':kind.endsWith('foreign-run') && after.contains('FOREIGN-TEXT'),'sourceChanged':after!=changed};
    } catch(error) {
      results[kind] = {'accepted':false,'error':error.toString(),'atomic':edited.revision==0 && base64Encode(edited.bytes)==base64Encode(original)};
    }
  }
  print(jsonEncode(results));
  for (final result in results.values) {
    final record = result! as Map<String,Object?>;
    if (record['accepted'] != false || record['atomic'] != true) throw StateError('Unsafe candidate was not refused atomically: $record');
  }
}
