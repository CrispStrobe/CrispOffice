# Development findings and final guard qualification

The files `runtime/header_footer_guard_review.json` and
`runtime/header_footer_guard_review_expanded.json` are **development findings
from before the fixes**. They deliberately record unsafe acceptance that was
found during review. They are not passing qualification, are not added to the
final case counts, and do not describe the final guarded behavior.

Final qualification is recorded only by
`runtime/header_footer_guard_review_final.json`, its `.stdout` and `.stderr`
companions, and the preserved final `runtime/header_footer_guard_review.dart`
probe source. The final receipt contains its exact command, source hashes,
source-stability assertion, probe-source hash and seven atomic refusals.

The final probe source is not represented as the source of the earlier
development findings. Their original paths and bytes are retained for
traceability. The final receipt also retains the limitation concerning
relationship XML namespaces normalized during OpcPackage.open.
