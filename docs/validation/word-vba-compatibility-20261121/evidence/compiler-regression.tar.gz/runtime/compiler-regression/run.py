import hashlib
import json
import pathlib
import subprocess
import time
from datetime import datetime, timezone
repo = pathlib.Path('/workspace/scratch/ecc61e3c20da/quds_office_suite')
engine = repo / 'packages/quds_office_engine'
out = pathlib.Path('/workspace/scratch/ecc61e3c20da/runtime/compiler-regression')
tests = sorted(p for p in (engine / 'test').glob('office_vba_*_test.dart') if '_integration_' not in p.name and '_cli_' not in p.name)
command = ['/workspace/scratch/ecc61e3c20da/runtime/run-engine-tests.sh', *(str(p.relative_to(engine)) for p in tests), '--reporter', 'json']
tracked_inputs = set(tests)
for base in (engine/'lib', repo/'packages/legacy_doc_parser/lib', engine/'test/support', engine/'test/fixtures/vba_conformance'):
    tracked_inputs.update(p for p in base.rglob('*') if p.is_file())
for p in [repo/'pubspec.yaml',repo/'pubspec.lock',repo/'.dart_tool/package_config.json',engine/'pubspec.yaml',repo/'packages/legacy_doc_parser/pubspec.yaml']:
    if p.is_file(): tracked_inputs.add(p)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(): return {str(p.relative_to(repo)): sha(p) for p in sorted(tracked_inputs)}
def save(name,data): (out/name).write_text(json.dumps(data,indent=2)+'\n')
before=manifest()
save('inputs-before.json',before)
save('command.json',{'command':command,'working_directory':str(repo),'selected_tests':[str(p.relative_to(engine)) for p in tests], 'selected_file_count':len(tests), 'exclusions':'integration and CLI files; no native document sessions executed', 'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'runner_sha256':sha(pathlib.Path(command[0])),'test_runner_dill_sha256':sha(pathlib.Path('/workspace/scratch/ecc61e3c20da/runtime/test-runner/test-runner.dill'))})
start=datetime.now(timezone.utc).isoformat()
t0=time.monotonic()
with (out/'events.jsonl').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
    proc=subprocess.run(command,cwd=repo,stdout=stdout,stderr=stderr)
after=manifest()
save('inputs-after.json',after)
changed=[p for p in before if before[p] != after[p]]
events=[]
for line in (out/'events.jsonl').read_text().splitlines():
    try: events.append(json.loads(line))
    except json.JSONDecodeError: pass
cases=[x for x in events if x.get('type')=='testDone' and not x.get('hidden')]
result={'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'duration_seconds':time.monotonic()-t0,'exit_code':proc.returncode,'selected_file_count':len(tests),'visible_tests':len(cases),'passed':sum(x['result']=='success' and not x['skipped'] for x in cases),'failed':sum(x['result']!='success' for x in cases),'skipped':sum(x['skipped'] for x in cases),'done':[x for x in events if x.get('type')=='done'],'input_count':len(before),'changed_inputs':changed}
save('result.json',result)
save('tests.json',[x for x in events if x.get('type') in ['testStart','testDone','error','done']])
print(json.dumps(result,indent=2))
raise SystemExit(proc.returncode)
