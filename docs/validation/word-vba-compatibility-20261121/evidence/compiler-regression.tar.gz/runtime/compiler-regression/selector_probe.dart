import 'dart:convert';
import 'package:quds_office_engine/quds_office_automation.dart';

const story = 'ThisDocument.Sections(1).Headers(1).Range';
String wrap(String body) => 'Sub Main()\n$body\nEnd Sub';

void main() {
  final probes = <(String, String, bool)>[
    ('whole_range_helper_write', '''
Sub Main()
Write target:=$story
End Sub
Sub Write(ByVal target As Range)
target.Font.Bold = True
End Sub
''', false),
    ('whole_range_two_helper_levels', '''
Sub Main()
First target:=$story
End Sub
Sub First(ByVal target As Range)
Second target:=target
End Sub
Sub Second(ByVal target As Range)
target.InsertBefore "whole"
End Sub
''', false),
    ('whole_range_highlight_helper', '''
Sub Main()
Apply target:=$story
End Sub
Sub Apply(ByVal target As Range)
target.HighlightColorIndex = wdRed
End Sub
''', false),
    ('whole_range_with_alias_format', wrap('''
Dim target As Range
Set target = $story
With target
.ParagraphFormat.Space1
End With
'''), false),
    ('whole_range_font_alias', wrap('''
Dim target As Range
Dim face As Font
Set target = $story
Set face = target.Font
'''), false),
    ('whole_range_format_alias', wrap('''
Dim target As Range
Dim layout As ParagraphFormat
Set target = $story
Set layout = target.ParagraphFormat
'''), false),
    ('whole_range_list_alias', wrap('''
Dim target As Range
Dim list As ListFormat
Set target = $story
Set list = target.ListFormat
'''), false),
    ('whole_range_scalar_variant_refused', wrap('''
Dim value As Variant
value = $story
'''), false),
    ('range_to_headerfooter_refused', wrap('''
Dim target As Range
Dim selected As HeaderFooter
Set target = $story
Set selected = target
'''), false),
    ('headerfooter_to_collection_refused', wrap('''
Dim target As HeaderFooter
Dim collection As HeadersFooters
Set target = ThisDocument.Sections(1).Headers(1)
Set collection = target
'''), false),
    ('unbound_collection_helper', '''
Sub Main()
Dim collection As HeadersFooters
Read collection:=collection
End Sub
Sub Read(ByVal collection As HeadersFooters)
collection.Item(1).Range.Paragraphs(1).Range.InsertBefore "x"
End Sub
''', false),
    ('unbound_headerfooter_helper', '''
Sub Main()
Dim selected As HeaderFooter
Read selected:=selected
End Sub
Sub Read(ByVal selected As HeaderFooter)
selected.Range.Paragraphs(1).Range.InsertBefore "x"
End Sub
''', false),
    ('inactive_direct_whole_font', wrap('If False Then\n$story.Font.Bold = True\nEnd If'), false),
    ('inactive_named_collection_index', wrap('If False Then\nThisDocument.Sections(1).Headers(Index:=1).Range.Paragraphs(1).Range.Font.Bold = True\nEnd If'), false),
    ('inactive_missing_collection_index', wrap('If False Then\nThisDocument.Sections(1).Headers().Range.Paragraphs(1).Range.Font.Bold = True\nEnd If'), false),
    ('inactive_wrong_receiver', wrap('If False Then\nThisDocument.Headers(1).Range.Paragraphs(1).Range.Font.Bold = True\nEnd If'), false),
    ('inactive_count_read', wrap('Dim size As Long\nIf False Then\nsize = $story.Paragraphs.Count\nEnd If'), false),
    ('inactive_linkage_write', wrap('If False Then\nThisDocument.Sections(1).Headers(1).LinkToPrevious = False\nEnd If'), false),
    ('unused_unknown_member', '''
Sub Main()
End Sub
Sub NeverCalled(ByVal selected As HeaderFooter)
selected.Exists = True
End Sub
''', false),
    ('whole_range_helper_success', '''
Sub Main()
Mark target:=$story
End Sub
Sub Mark(ByVal target As Range)
target.Paragraphs(2).Range.Font.Bold = True
End Sub
''', true),
    ('whole_range_to_paragraph_rebind', wrap('''
Dim target As Range
Set target = $story
Set target = target.Paragraphs(2).Range
target.InsertBefore "yes"
'''), true),
    ('paragraph_to_whole_rebind_refuses_write', wrap('''
Dim target As Range
Set target = ThisDocument.Paragraphs(1).Range
Set target = $story
target.InsertBefore "no"
'''), false),
    ('paragraph_to_whole_rebind_allows_selection', wrap('''
Dim target As Range
Set target = ThisDocument.Paragraphs(1).Range
Set target = $story
target.Paragraphs(1).Range.InsertBefore "yes"
'''), true),
    ('max_exact_section_and_paragraph_indices', wrap('ThisDocument.Sections(9007199254740991).Headers(1).Range.Paragraphs(9007199254740991).Range.Font.Bold = True'), true),
    ('over_exact_section_refused', wrap('ThisDocument.Sections(9007199254740992).Headers(1).Range.Paragraphs(1).Range.Font.Bold = True'), false),
    ('over_exact_paragraph_refused', wrap('$story.Paragraphs(9007199254740992).Range.Font.Bold = True'), false),
  ];
  final receipts = <Map<String, Object?>>[];
  for (final (name, source, expectSuccess) in probes) {
    try {
      final plan = OfficeMacroLanguages().compile(OfficeMacroSource(language: 'vba-word', format: OfficeMacroFormat.docx, moduleName: 'SelectorProbe', source: source));
      if (!expectSuccess) throw StateError('Expected controlled source refusal: $name');
      receipts.add({'name': name, 'success': true, 'steps': plan.steps.length});
    } on OfficeVbaCompileException catch (error) {
      if (expectSuccess) rethrow;
      if (error.line < 1 || error.column < 1) throw StateError('Invalid diagnostic coordinates');
      receipts.add({'name': name, 'success': false, 'diagnostic': error.toJson()});
    }
  }
  print(const JsonEncoder.withIndent('  ').convert({'cases': receipts.length, 'controlledRefusals': receipts.where((x) => x['success'] == false).length, 'successfulSelectors': receipts.where((x) => x['success'] == true).length, 'receipts': receipts}));
}
