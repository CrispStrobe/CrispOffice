# Incoming Mail and Zotero review

## Result

No blocking correctness or regression issue was identified in Mail snapshot `d9d75300f7eec0eeecc8fdee05bc02fb6ad3db0b`. This was a read-only review of the runner, public export, changelog, assertions, and existing coordinator/repository/cancellation contracts. No product files or refs were changed.

## Mail runner

The runner is an opt-in foreground API. It retains a run-wide lease across coordinator page calls, checks scope around asynchronous boundaries, and uses the existing repository transaction and expected-cursor contract. It retains acknowledged pages after a later cancellation/failure, suppresses stale progress, rejects cursor continuation cycles before persistence, and stops before another fetch when another operation changes the stored cursor. Empty continuation pages consume the budget. Observer exceptions are isolated and external exceptions become typed problems.

The checked local receipt reports **271 visible passes, zero failures and zero skips**, including **36 new runner tests**. All 34 recorded input hashes matched before execution, after execution, and this review. The four changed files match the exact incoming commit; hashes are in `review.json`.

The assertions cover multi-page progress/reset counts, pause/resume, partial provider/storage failures, cancellation before work and across provider/commit boundaries, session invalidation/disposal, observer cancellation/failure, ownership and bounds, cursor repetition/rewind and races, foreign/oversized pages, and sanitized exceptions. They do not claim durable-provider qualification from their in-memory repository.

## Zotero snapshot proof

Snapshot `674ce9701e185971388fc2e517d305689ccba471` has parent exactly `e2abbcda6d19f932bfbacc85e0dafd41a3c478f8`, the original main snapshot. `git diff --name-status e2abbcda6d19f932bfbacc85e0dafd41a3c478f8 674ce9701e185971388fc2e517d305689ccba471` reports only five additions under `docs/validation/zotero-table-cell-ranges-20261121/`: one README, one audit replay script, and three JSON evidence files. `packages`, `apps`, `tool`, and `.github` trees are identical to the base. This is documentation/validation-only intake/planning work, with no product or runtime mutation and no newly qualified table-cell behavior. Exact paths, tree IDs, and added-file hashes are in `review.json`.

## Limits

The repository implementation still owns durable atomicity, cursor compare-and-swap, and the final transaction lease check. Page limits are not wall-clock deadlines; callers/providers must cooperate with cancellation. Progress counts are page payload counts, and prior acknowledged pages intentionally survive later failure. No native Mail UI, credential store, live provider/account, or GitHub Actions work was executed by this review.
