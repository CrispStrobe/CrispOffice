#!/usr/bin/env python3
from datetime import datetime, timezone
import gzip, hashlib, json, os, shutil, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'quds_office_suite'
SDK=ROOT/'flutter'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
record_path=ROOT/'runtime.json'
record=json.loads(record_path.read_text())
assert record['status']=='ready'
assert sha(REPO/'pubspec.lock')==record['workspace_lock_sha256']
env=dict(os.environ,PUB_CACHE=str(ROOT/'pub-cache'),FLUTTER_ROOT=str(SDK),CI='true',DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true',DASH__SUPPRESS_ANALYTICS='true',XDG_CONFIG_HOME=str(ROOT/'config'),XDG_CACHE_HOME=str(ROOT/'cache'),XDG_DATA_HOME=str(ROOT/'data'),TMPDIR=str(ROOT/'tmp'))
env['PATH']=str(ROOT/'bin')+':'+env.get('PATH','')
probe=REPO/'packages/quds_mail_store/.dart_tool/runtime_sqlite_probe.dart'
probe.write_bytes((ROOT/'sqlite-smoke/bin/smoke.dart').read_bytes())
log=ROOT/'logs/workspace-sqlite-smoke.log'
command=[str(ROOT/'bin/dart'),'run',str(probe)]
with log.open('wb') as out:
    result=subprocess.run(command,cwd=REPO/'packages/quds_mail_store',env=env,stdout=out,stderr=subprocess.STDOUT)
if result.returncode:raise RuntimeError(log.read_text())
manifest=REPO/'.dart_tool/native_assets.yaml'
content='\n'.join(line for line in manifest.read_text().splitlines() if not line.lstrip().startswith('#'))
assets=json.loads(content)['native-assets']
node=Path(shutil.which('node')).resolve()
additional={str(node):sha(node),str(manifest):sha(manifest)}
for platform in assets.values():
    for asset in platform.values():
        assert isinstance(asset,list) and len(asset)==2 and asset[0]=='absolute'
        binary=Path(asset[1]);assert binary.is_file()
        additional[str(binary)]=sha(binary)
        assert sha(binary)=='0a65852703763619a7a34633b4959b3b86c4103804a4dfe4e8b27b5de1c0647b'
record['additional_inputs']=additional
record['workspace_sqlite_smoke']={'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'command':command,'exit_code':result.returncode,'source':str(probe),'source_sha256':sha(probe),'log':str(log),'log_sha256':sha(log),'cwd':str(REPO/'packages/quds_mail_store'),'default_native_hook':True,'setup_attempts':[{'log':str(ROOT/'logs/workspace-sqlite-smoke-attempt-1.log'),'status':'failed','reason':'Dependency-free workspace root cannot prepare sqlite native hooks; rerun from declaring Mail Store package.'},{'log':str(ROOT/'logs/workspace-sqlite-smoke-attempt-2.log'),'exit_code':0,'reason':'Declaring Mail Store package invokes genuine default hook and creates workspace-root mapping.'}],'excluded_from_product_test_totals':True}
record_path.write_text(json.dumps(record,indent=2)+'\n')
omissions={'reason':'Mutable generated caches and Git metadata are not source inputs; verified original archive and selected runtime inputs are retained separately.','excluded_directories':['.git','.dart_tool','.cache','build','_temp'],'excluded_names':['lockfile','flutter_tools.stamp','flutter_tools.snapshot'],'symlinks':'Symlink targets are represented by their regular-file paths.'}
(ROOT/'cache-omissions.json').write_text(json.dumps(omissions,indent=2)+'\n')
retained={}
for prefix in ['flutter','pub-cache']:
    for directory, dirs, names in os.walk(ROOT/prefix,followlinks=False):
        dirs[:]=sorted(d for d in dirs if d not in omissions['excluded_directories'] and not (Path(directory)/d).is_symlink())
        for name in sorted(names):
            path=Path(directory)/name
            if name in omissions['excluded_names'] or path.is_symlink() or not path.is_file():continue
            retained[path.relative_to(ROOT).as_posix()]={'bytes':path.stat().st_size,'sha256':sha(path)}
retained=dict(sorted(retained.items()))
data=(json.dumps(retained,indent=2)+'\n').encode()
(ROOT/'retained-inputs.json').write_bytes(data)
with (ROOT/'retained-inputs.json.gz').open('wb') as f:
    with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as out:out.write(data)
summary={'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'status':'ready','retained_files':len(retained),'retained_bytes':sum(item['bytes'] for item in retained.values()),'retained_manifest_sha256':sha(ROOT/'retained-inputs.json'),'compressed_manifest_sha256':sha(ROOT/'retained-inputs.json.gz'),'additional_inputs':additional,'node_version':subprocess.check_output([str(node),'--version'],text=True).strip(),'runtime_receipt_sha256':sha(record_path),'workspace_lock_sha256':sha(REPO/'pubspec.lock'),'free_bytes':shutil.disk_usage(ROOT).free,'no_github_actions_used':True}
(ROOT/'binding-receipt.json').write_text(json.dumps(summary,indent=2)+'\n')
(ROOT/'gate-ready').touch()
print(json.dumps(summary,indent=2))
