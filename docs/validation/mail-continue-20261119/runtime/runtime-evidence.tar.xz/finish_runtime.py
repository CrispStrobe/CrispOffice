#!/usr/bin/env python3
import hashlib, json, os, subprocess
from datetime import datetime, timezone
from pathlib import Path
import yaml
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'quds_office_suite'
SDK=ROOT/'flutter'
def sha(path):
    return hashlib.file_digest(Path(path).open('rb'),'sha256').hexdigest()
def run(name, argv, cwd, env=None):
    log=ROOT/'logs'/(name+'.log')
    with log.open('wb') as stream:
        result=subprocess.run([str(x) for x in argv],cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'{name} exit {result.returncode}: '+log.read_text(errors='replace')[-8000:])
    return {'name':name,'command':[str(x) for x in argv],'cwd':str(cwd),'exit_code':result.returncode,'log':str(log),'sha256':sha(log)}
if not (ROOT/'runtime-ready').exists():
    raise RuntimeError('bootstrap not ready')
record={'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'purpose':'Runtime restoration only; excluded from product regression totals','no_github_actions_used':True}
record['sdk_source_restore']=run('sdk-source-restore',['git','restore','--source=HEAD','--worktree','--','.'],SDK)
record['sdk_source_diff']=run('sdk-source-diff',['git','diff','--exit-code','HEAD','--'],SDK)
expected={'bin/cache/dart-sdk/bin/dart':'01e869e4af277734b02ab8898b870c6b00c9bec61bbcf9c923cd14de7ed85fbb','bin/cache/artifacts/engine/linux-x64/flutter_tester':'800f4ca182df7dd2fb46a42dea5d76277b9dbc5e8cd2915e02bcbc978681b45f'}
record['executables']={name:sha(SDK/name) for name in expected}
assert record['executables']==expected
probe=ROOT/'sqlite-smoke'
(probe/'bin').mkdir(parents=True,exist_ok=True)
(probe/'pubspec.yaml').write_text('name: sqlite_runtime_probe\npublish_to: none\nenvironment:\n  sdk: ^3.12.0\ndependencies:\n  sqlite3: 3.9.1\n')
(probe/'bin/smoke.dart').write_text('''import 'dart:convert';
import 'package:sqlite3/sqlite3.dart';
void main() {
  final database = sqlite3.openInMemory();
  database.execute('CREATE VIRTUAL TABLE probe USING fts5(value)');
  database.execute("INSERT INTO probe(value) VALUES ('durable storage')");
  final count = database.select("SELECT count(*) AS n FROM probe WHERE probe MATCH 'durable'").single['n'];
  if (count != 1) throw StateError('FTS5 query failed');
  print(jsonEncode({'sqlite_version': sqlite3.version.toString(), 'fts5_count': count}));
  database.dispose();
}
''')
env=dict(os.environ,PUB_CACHE=str(ROOT/'pub-cache'),FLUTTER_ROOT=str(SDK),CI='true',DART_SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true',DASH__SUPPRESS_ANALYTICS='true',XDG_CONFIG_HOME=str(ROOT/'config'),XDG_CACHE_HOME=str(ROOT/'cache'),XDG_DATA_HOME=str(ROOT/'data'),TMPDIR=str(ROOT/'tmp'))
env['PATH']=str(ROOT/'bin')+':'+env.get('PATH','')
dart=ROOT/'bin/dart'
record['sqlite_pub_get']=run('sqlite-smoke-pub',[dart,'pub','get','--offline'],probe,env)
workspace_packages=yaml.safe_load((REPO/'pubspec.lock').read_text())['packages']
smoke_packages=yaml.safe_load((probe/'pubspec.lock').read_text())['packages']
for name, package in smoke_packages.items():
    assert all(package[field]==workspace_packages[name][field] for field in ('source','version','description')), name
record['sqlite_dependencies']={'count':len(smoke_packages),'match_workspace':True,'workspace_lock_sha256':sha(REPO/'pubspec.lock'),'smoke_lock_sha256':sha(probe/'pubspec.lock')}
record['sqlite_run']=run('sqlite-smoke',[dart,'run','bin/smoke.dart'],probe,env)
binary=probe/'.dart_tool/lib/libsqlite3.so'
record['sqlite_binary']={'path':str(binary),'sha256':sha(binary)}
assert record['sqlite_binary']['sha256']=='0a65852703763619a7a34633b4959b3b86c4103804a4dfe4e8b27b5de1c0647b'
record['sqlite_source']={'path':str(probe/'bin/smoke.dart'),'sha256':sha(probe/'bin/smoke.dart')}
record['status']='PASS'
(ROOT/'runtime-complete.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
