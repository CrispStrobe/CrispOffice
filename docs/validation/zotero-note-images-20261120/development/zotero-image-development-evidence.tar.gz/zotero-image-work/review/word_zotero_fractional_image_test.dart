import 'dart:convert';

import 'package:quds_office_engine/quds_office_engine.dart';
import 'package:quds_office_engine/src/word/model/word_zotero_note.dart';
import 'package:test/test.dart';

// Independent 3 x 2 RGBA PNG; this is the editor integration fixture.
const _png =
    'iVBORw0KGgoAAAANSUhEUgAAAAMAAAACCAYAAACddGYaAAAAF0lEQVR4nGP4z8DwHwwZ/v8HIyABZgEAqm8O8tH19KMAAAAASUVORK5CYII=';

void main() {
  test('ordinary Zotero note keeps fractional aspect-ratio height', () {
    // Zotero note-editor bdf61e0c275e483c3068ce4fcb86b44691b22afc:
    // node-views/image.js passes naturalHeight * authoredWidth / naturalWidth
    // unchanged through editor-core.js -> commands.js -> schema/nodes.js.
    // Filling a missing height for this 3 x 2 image at width 53 therefore saves
    // height="35.333333333333336" before a subsequent editor reload.
    final note = WordZoteroNoteText.fromHtml(
      '<div data-schema-version="9"><p>Before '
      '<img src="data:image/png;base64,$_png" alt="Sample" '
      'width="53" height="35.333333333333336"> '
      '<a href="https://www.zotero.org/?ABC123">(Author)</a>'
      ' after</p></div>',
    );
    final imageRun = note.paragraphs.single.inlines
        .whereType<WmlRun>()
        .singleWhere((run) => run.inlineVisual != null);
    final visual = imageRun.inlineVisual!.visual;
    expect(visual.imageBytes, base64.decode(_png));
    expect(visual.width, 39.75);
    expect(visual.height, closeTo(26.5, 0.000000001));
    expect(note.plainText, 'Before \uFFFC (Author) after');
    expect(note.placeholders['ABC123']!.start, 9);
    expect(note.placeholders['ABC123']!.end, 17);
  });
}
