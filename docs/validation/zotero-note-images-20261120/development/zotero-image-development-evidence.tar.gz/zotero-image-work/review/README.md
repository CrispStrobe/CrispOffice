# Independent Zotero embedded-image review

Reviewed 2026-11-20 by the runtime/editor integration agent, independently of the
parser implementation owner. Initial product checkpoint: `6895b62e`.

## Finding and disposition

One concrete upstream compatibility defect was found: ordinary Zotero notes can
serialize a fractional image dimension, while the initial Quds reader accepted
only integers. The parser owner has fixed that defect, and the targeted controller
regression now passes. No additional blocking finding remains in this review.

This was established from upstream code and reproduced in a controller test
using an HTML fixture derived from that code; no live export was captured.
Zotero's image node view fills a missing
dimension using the intrinsic aspect ratio. Its update callback and transaction
store the result unchanged, and its schema serializer writes that value into the
HTML attribute. A 3 by 2 PNG with an authored width of 53 pixels can therefore be
exported with height `35.333333333333336`. The initial implementation throws its
invalid-width/height `FormatException` before application.

The focused scratch parser regression is
`word_zotero_fractional_image_test.dart`. The controller regression was added to
`packages/quds_office_editor/test/word_zotero_note_image_controller_test.dart`
with root authorization. It verifies original PNG bytes, active citation data,
surrounding prose, caret placement, undo, and three DOCX save/reopen cycles with
expected extents 39.75 by 26.5 points and a tolerance of one EMU (1/12700 point).
The initial failing run is preserved as `fractional-controller-before.jsonl`
and `fractional-controller-before.stderr`. It executed one application case and
failed at the anticipated dimension check; it is not passing acceptance evidence.

## Primary upstream sources

The following are pinned source references retrieved through the GitHub
connector. No CI, workflow, check, status or Actions endpoint was queried.

| Upstream source | Relevant behavior reviewed |
| --- | --- |
| [Zotero notes.js at c5b271dd](https://github.com/zotero/zotero/blob/c5b271dd05050257b6e035db6347beedbabbd73e/chrome/content/zotero/xpcom/data/notes.js) | `getExportableNote` replaces available note attachment keys with embedded data URIs, removes the attachment-key attribute, and returns serialized HTML. A missing attachment does not become recoverable image bytes. |
| [Zotero editorInstance.js at c5b271dd](https://github.com/zotero/zotero/blob/c5b271dd05050257b6e035db6347beedbabbd73e/chrome/content/zotero/xpcom/editorInstance.js) | Annotation serialization emits image/ink classes, image data or attachment keys, width/height, inert annotation metadata, citation and comment text. Annotation dimensions are rounded integer values. |
| [note-editor image node view at bdf61e0c](https://github.com/zotero/note-editor/blob/bdf61e0c275e483c3068ce4fcb86b44691b22afc/src/core/node-views/image.js) | Lines 13–28 derive a missing dimension from the natural aspect ratio without rounding. |
| [note-editor editor core at bdf61e0c](https://github.com/zotero/note-editor/blob/bdf61e0c275e483c3068ce4fcb86b44691b22afc/src/core/editor-core.js) | Lines 248–252 forward the computed values into the image-dimension command. |
| [note-editor commands at bdf61e0c](https://github.com/zotero/note-editor/blob/bdf61e0c275e483c3068ce4fcb86b44691b22afc/src/core/commands.js) | Lines 487–500 retain the dimensions in node attributes without rounding. |
| [note-editor schema at bdf61e0c](https://github.com/zotero/note-editor/blob/bdf61e0c275e483c3068ce4fcb86b44691b22afc/src/core/schema/nodes.js) | Lines 355–365 serialize width, height, title, alt text and annotation metadata from the node attributes. |
| [note-editor clipboard serializer at bdf61e0c](https://github.com/zotero/note-editor/blob/bdf61e0c275e483c3068ce4fcb86b44691b22afc/src/core/schema/utils.js) | The exported image shape also retains the source and authored image attributes. |

## Review of the implementation

The reviewed implementation paths were
`packages/quds_office_engine/lib/src/word/model/word_zotero_note.dart` and
`packages/quds_office_engine/lib/src/word/model/word_zotero_note_image.dart`.
The review also inspected their parser tests, the editor image integration tests,
the existing XML writer/reader, and the locked `image` package version 4.13.1.

The new image path accepts only embedded PNG/JPEG data. It has no remote, local
file, attachment lookup, SVG or script execution path. HTML tag normalization is
quote-aware and handles actual void `img`/`br` tags and comments. Unknown image
attributes, unsupported image CSS/classes, unresolved source forms, APNG,
unsupported JPEG components and non-upright EXIF orientations refuse the note.
An image inside an active citation placeholder also refuses the note. No newly
accepted image structure was found to be silently converted into ordinary text.

Base64 size and canonical encoding checks occur before base64 decoding. Each
decoded file is capped at 4 MiB, and aggregate file bytes are checked before the
image decoder. PNG inspection verifies signature, chunk bounds/CRC, legal
IHDR combinations, palette/transparency structure, contiguous image data, IEND,
scanline expansion and filter bytes. Compressed ancillary PNG metadata has its
own cumulative expansion limit. JPEG inspection validates frame dimensions,
three components and sampling factors, limits markers/scans, locates every
later scan/frame before decoder allocation, and examines EXIF orientation.
The real image decoder then validates the pixel stream; header-only invented
rasters are not accepted.

The whole note owns image, file-byte, pixel and decoded-data counters. The
existing 8 MiB note payload limit further bounds parsing. These checks constrain
declared input and raster expansion before pixel decoding; they are not a bound
on total process memory. In particular, a progressive 4096 by 4096 three-component
4:4:4 JPEG can need approximately 96 MiB of intermediate Int16 coefficient
storage in the locked decoder before its component planes and final bitmap.
PNG's raw inflater also has a Dart `List<int>` intermediate representation.
The 64 MiB value therefore describes decoded-data accounting, **not a 64 MiB
heap/RSS cap**. Dimension, count, compressed-byte and expansion limits still
bound these operations; no unbounded loop or allocation path was identified in
the reviewed input route. The implementation owner and root were informed of
this distinction, and the user documentation should keep it explicit.

Original accepted raster bytes are stored directly on the native picture visual;
validation does not re-encode them. Alt/title metadata and ordinary image links
map to the native visual/run properties. The image run contains one U+FFFC code
unit, and the parser advances its UTF-16 offset by exactly one. Text offsets use
the corresponding string length. Citation markers are not allowed to contain
images, so a surrounding ordinary link and adjacent active citations remain
separate. Existing transaction staging and the new editor tests verify that a
later malformed image, cancellation or stale target does not publish earlier
images, preferences or partial content into the live document.

## Evidence boundaries

This report is a source review with a targeted regression. It does not replace
the root-owned qualification against the final committed source. The earlier
20-case controller development run, including actual Flutter raster rendering,
passed before this finding; the new fractional-dimension case makes that test
file contain 21 cases and requires qualification after the fix.

No fresh live Zotero account, native Microsoft Word/OpenOffice application,
mobile device, or browser application acceptance is claimed. The review supports
the bounded embedded-image increment; it does not establish full Zotero parity,
all image color-management behavior, arbitrary HTML/CSS, or every external Office
import/export behavior.

## Final follow-up

The parser owner's correction accepts a bounded positive finite decimal value
and retains the existing 1–4000 point display bounds. It does not accept CSS
units, exponents, signed or non-finite values. The new parser regression covers
the exact ordinary-note export example and its active citation offsets.

The targeted controller rerun passed its one application case with no skips or
diagnostic errors. The raw events are in `fractional-controller-after.jsonl`;
stderr is empty. Strict Dart analysis of the updated controller test file also
passed, recorded in `fractional-controller-analysis.log`. Formatting passed.
The before-fix failure has been retained separately and is not relabeled.

The controller command, run from `packages/quds_office_editor` after sourcing
the pinned runtime environment, was:

```bash
flock /workspace/scratch/0faa407ae6ae/toolchains/qualified-local-validation.lock \
  flutter test --no-pub --reporter json --concurrency 1 \
  --plain-name 'ordinary note fractional image extents survive repeated DOCX saves' \
  test/word_zotero_note_image_controller_test.dart
```

These are development runs on the shared working tree, not final frozen-source
qualification. The source and evidence hashes at review closure, and the event
summary, are recorded in `review-receipt.json`. The reviewer has no further
product or test edits pending. The root-owned final gate must qualify the
committed combined changes.
