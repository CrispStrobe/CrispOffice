#!/usr/bin/env python3
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parent;repo=root.parent/'quds_office_suite';sdk=root/'flutter-sdk'
env=dict(os.environ,FLUTTER_ROOT=str(sdk),PUB_CACHE=str(root/'pub-cache'),TMPDIR=str(root/'tmp'),XDG_CONFIG_HOME=str(root/'config'),XDG_CACHE_HOME=str(root/'cache'),XDG_DATA_HOME=str(root/'data'),CI='true',DART_SUPPRESS_ANALYTICS='true',DASH__SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true')
env['PATH']=str(sdk/'bin')+':'+env['PATH']
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
def run(label,cmd,cwd):
 start=time.monotonic()
 with (root/'logs'/f'{label}.log').open('wb') as f:result=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 record={'label':label,'command':cmd,'cwd':str(cwd),'exit_code':result.returncode,'seconds':time.monotonic()-start,'log':f'logs/{label}.log'}
 print(json.dumps(record),flush=True);assert result.returncode==0,record
 return record
state=json.loads((root/'setup/configured-state.json').read_text())
started=state['started_at_utc'];initial=state['configuration_head'];checks=state['checks'];manifest_matches=state['manifest_matches'];sdk_lock=state['sdk_lock'];source_changes=state['source_changes'];version=state['version'];config_before=state['config_before']
before=json.loads((root/'setup/manifests-before.json').read_text());assert all(sha(repo/p)==v for p,v in before.items()),'Manifests changed since setup'
dart=str(sdk/'bin/cache/dart-sdk/bin/dart');flutter=str(sdk/'bin/flutter')
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=repo,text=True).strip(),'Resolve source conflicts before smoke'
smoke_file=repo/'packages/quds_office_editor/test/word_zotero_format_test.dart';smoke_before=sha(smoke_file);smoke_head=head()
checks.append(run('setup-format-smoke',[flutter,'test','--no-pub','test/word_zotero_format_test.dart','--reporter','json','--concurrency','1'],repo/'packages/quds_office_editor'));assert sha(smoke_file)==smoke_before
logs=(root/'logs/setup-format-smoke.log').read_text().splitlines();events=[]
for line in logs:
 try:event=json.loads(line)
 except json.JSONDecodeError:continue
 if isinstance(event,dict):events.append(event)
starts={e['test']['id']:e['test'] for e in events if e.get('type')=='testStart'};done=[e for e in events if e.get('type')=='testDone' and not e.get('hidden') and not starts.get(e['testID'],{}).get('name','').startswith('loading ') and not starts.get(e['testID'],{}).get('name','').endswith(('(setUpAll)','(tearDownAll)'))]
smoke={'passed':sum(e['result']=='success' and not e.get('skipped') for e in done),'failed':sum(e['result']!='success' for e in done),'skipped':sum(bool(e.get('skipped')) for e in done),'done_success':[e.get('success') for e in events if e.get('type')=='done']}
assert smoke['passed']>0 and smoke['failed']==0 and smoke['skipped']==0 and smoke['done_success']==[True],smoke
config_after={str(p.relative_to(repo)):sha(p) for p in (repo/'.dart_tool/package_config.json',repo/'.dart_tool/package_graph.json')}
receipt={'status':'ready','started_at_utc':started,'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'source_head_at_start':initial,'source_head_at_finish':head(),'source':str(repo),'sdk':str(sdk),'environment_script':str(root/'env.sh'),'runtime':version,'archive':json.loads((root/'setup/archive.json').read_text()),'executable_sha256':{p:sha(sdk/p) for p in ['bin/cache/dart-sdk/bin/dart','bin/cache/artifacts/engine/linux-x64/flutter_tester']},'manifest_locks_unchanged':manifest_matches,'flutter_tools_lock_sha256':sdk_lock,'framework_tracked_changes':source_changes,'package_config_before':config_before,'package_config_after':config_after,'commands':checks,'prefetch_evidence':'setup/locked-archive-audit.json','setup_smoke':{'source_head_at_start':smoke_head,'test_source_sha256':smoke_before,'counted_as_product_acceptance':False,**smoke},'product_acceptance_tests_run':0,'no_ci_actions_used':True}
(root/'runtime-ready.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Runtime ready',json.dumps(smoke),flush=True)
