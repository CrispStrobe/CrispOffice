#!/usr/bin/env python3
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parent;repo=root.parent/'quds_office_suite';sdk=root/'flutter-sdk'
env=dict(os.environ,FLUTTER_ROOT=str(sdk),PUB_CACHE=str(root/'pub-cache'),TMPDIR=str(root/'tmp'),XDG_CONFIG_HOME=str(root/'config'),XDG_CACHE_HOME=str(root/'cache'),XDG_DATA_HOME=str(root/'data'),CI='true',DART_SUPPRESS_ANALYTICS='true',DASH__SUPPRESS_ANALYTICS='true',FLUTTER_SUPPRESS_ANALYTICS='true')
env['PATH']=str(sdk/'bin')+':'+env['PATH']
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
def run(label,cmd,cwd):
 start=time.monotonic()
 with (root/'logs'/f'{label}.log').open('wb') as f:result=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 record={'label':label,'command':cmd,'cwd':str(cwd),'exit_code':result.returncode,'seconds':time.monotonic()-start,'log':f'logs/{label}.log'}
 print(json.dumps(record),flush=True);assert result.returncode==0,record
 return record
before=json.loads((root/'setup/manifests-before.json').read_text());assert all(sha(repo/p)==v for p,v in before.items()),'Manifests changed during setup; coordinate before proceeding'
config_before={str(p.relative_to(repo)):sha(p) for p in (repo/'.dart_tool/package_config.json',repo/'.dart_tool/package_graph.json') if p.exists()}
(root/'setup/package-config-before.json').write_text(json.dumps(config_before,indent=2)+'\n')
sdk_lock=sha(sdk/'packages/flutter_tools/pubspec.lock');started=datetime.now(timezone.utc).isoformat();initial=head();checks=[]
dart=str(sdk/'bin/cache/dart-sdk/bin/dart');flutter=str(sdk/'bin/flutter')
checks.append(run('workspace-pub-get',[dart,'pub','get','--offline','--enforce-lockfile'],repo))
checks.append(run('flutter-tools-pub-get',[dart,'pub','get','--offline','--enforce-lockfile'],sdk/'packages/flutter_tools'))
checks.append(run('dart-version',[dart,'--version'],repo))
checks.append(run('flutter-version',[flutter,'--version','--machine'],repo))
manifest_matches={p:sha(repo/p)==v for p,v in before.items()};assert all(manifest_matches.values());assert sha(sdk/'packages/flutter_tools/pubspec.lock')==sdk_lock
source_changes=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=sdk,text=True).strip();assert not source_changes,source_changes
version=json.loads((root/'logs/flutter-version.log').read_text());assert version['frameworkVersion']=='3.47.8' and version['dartSdkVersion']=='3.13.7'

state={'started_at_utc':started,'configuration_head':initial,'checks':checks,'manifest_matches':manifest_matches,'sdk_lock':sdk_lock,'source_changes':source_changes,'version':version,'config_before':config_before}
(root/'setup/configured-state.json').write_text(json.dumps(state,indent=2)+'\n')
print('Runtime configured; source smoke deferred',flush=True)
