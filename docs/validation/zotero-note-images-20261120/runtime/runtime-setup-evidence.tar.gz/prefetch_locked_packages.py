#!/usr/bin/env python3
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import hashlib,io,json,pathlib,re,sys,tarfile,time,urllib.request,yaml
runtime=pathlib.Path(__file__).resolve().parent
locks=[pathlib.Path(p).resolve() for p in sys.argv[1:]]
records={}
for lock in locks:
 for name,record in yaml.safe_load(lock.read_text())['packages'].items():
  if record['source']!='hosted':continue
  version=record['version'];desc=record['description'];expected=desc['sha256']
  assert desc['url']=='https://pub.dev',desc
  assert re.fullmatch(r'[a-zA-Z0-9_]+',name)
  assert re.fullmatch(r'[a-zA-Z0-9.+-]+',version)
  assert re.fullmatch(r'[0-9a-f]{64}',expected)
  records[(name,version)]={'name':name,'version':version,'sha256':expected}
hosted=runtime/'pub-cache/hosted/pub.dev';hashes=runtime/'pub-cache/hosted-hashes/pub.dev'
hosted.mkdir(parents=True,exist_ok=True);hashes.mkdir(parents=True,exist_ok=True)
def fetch(r):
 name,version,expected=(r[k] for k in ['name','version','sha256'])
 stem=f'{name}-{version}';dest=hosted/stem;digest=hashes/f'{stem}.sha256'
 if dest.exists():
  assert digest.read_text()==expected
  return dict(r,status='verified-cache')
 url=f'https://pub.dev/api/archives/{stem}.tar.gz'
 start=time.monotonic()
 with urllib.request.urlopen(url,timeout=90) as resp:data=resp.read()
 actual=hashlib.sha256(data).hexdigest()
 assert actual==expected,(stem,actual,expected)
 temp=hosted/f'.{stem}.restore';temp.mkdir()
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as bundle:bundle.extractall(temp,filter='data')
 temp.rename(dest);digest.write_text(actual)
 return dict(r,url=url,bytes=len(data),actual_sha256=actual,seconds=time.monotonic()-start,status='verified-download')
start=time.monotonic();results=[]
with ThreadPoolExecutor(max_workers=8) as pool:
 for future in as_completed([pool.submit(fetch,r) for r in records.values()]):
  result=future.result();results.append(result)
  print(json.dumps(result),flush=True)
receipt={'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'locks':[{ 'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in locks],'packages':sorted(results,key=lambda r:(r['name'],r['version'])),'seconds':time.monotonic()-start}
out=runtime/'setup'/f'prefetch-{len(records)}.json';out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'restored':len(results),'receipt':str(out),'seconds':receipt['seconds']}),flush=True)
