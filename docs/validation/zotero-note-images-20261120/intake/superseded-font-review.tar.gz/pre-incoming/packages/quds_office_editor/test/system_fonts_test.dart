import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_editor/quds_office_editor.dart';
import 'package:quds_office_editor/src/embed/office_system_fonts_io.dart'
    as system_fonts;

Future<Uint8List> _font(String name) async {
  final data = await rootBundle.load('packages/quds_office_editor/fonts/$name');
  return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late Directory temporary;
  late Uint8List regular;
  setUp(() async {
    temporary = await Directory.systemTemp.createTemp('office-system-fonts-');
    regular = await _font('LiberationSans-Regular.ttf');
  });
  tearDown(() async {
    await temporary.delete(recursive: true);
  });

  test('oversized face cannot hide a valid later-directory face', () async {
    final first = await Directory('${temporary.path}/first').create();
    final second = await Directory('${temporary.path}/second').create();
    await File(
      '${first.path}/Arial.ttf',
    ).writeAsBytes(Uint8List(regular.length + 1));
    await File('${second.path}/Arial.ttf').writeAsBytes(regular);
    final loaded = await system_fonts.load(
      directories: [first.path, second.path],
      maxFaceBytes: regular.length,
    );
    expect(loaded, hasLength(1));
    expect(loaded.single.family, 'Arial');
    expect(loaded.single.bytes, regular);
  });

  test('aggregate byte limit retains only faces that fit', () async {
    await File('${temporary.path}/Arial.ttf').writeAsBytes(regular);
    await File('${temporary.path}/Arial Bold.ttf').writeAsBytes(regular);
    final loaded = await system_fonts.load(
      directories: [temporary.path],
      maxTotalBytes: regular.length * 2 - 1,
    );
    expect(loaded, hasLength(1));
    expect(loaded.single.weight, 400);
    expect(loaded.single.bytes, regular);
  });

  test('unreadable paths and malformed faces keep later fallbacks', () async {
    final blocked = File('${temporary.path}/not-a-directory');
    await blocked.writeAsString('not a directory');
    final invalid = await Directory('${temporary.path}/invalid').create();
    final valid = await Directory('${temporary.path}/valid').create();
    await Directory('${invalid.path}/Arial.ttf').create();
    await File('${invalid.path}/Times New Roman.ttf').writeAsBytes([1, 2, 3]);
    await File('${valid.path}/Arial.ttf').writeAsBytes(regular);
    await File('${valid.path}/Times New Roman.ttf').writeAsBytes(regular);
    final loaded = await system_fonts.load(
      directories: [blocked.path, invalid.path, valid.path],
    );
    expect(loaded.map((face) => face.family), ['Arial', 'Times New Roman']);
  });

  test(
    'first readable copy wins and unknown filenames are not scanned',
    () async {
      final first = await Directory('${temporary.path}/first').create();
      final second = await Directory('${temporary.path}/second').create();
      final other = await _font('LiberationSerif-Regular.ttf');
      await File('${first.path}/Arial.ttf').writeAsBytes(regular);
      await File('${first.path}/Unknown.ttf').writeAsBytes(other);
      await File('${second.path}/Arial.ttf').writeAsBytes(other);
      final loaded = await system_fonts.load(
        directories: [first.path, second.path],
      );
      expect(loaded, hasLength(1));
      expect(loaded.single.bytes, regular);
    },
  );

  test('invalid byte budgets fail before local discovery', () async {
    await expectLater(
      system_fonts.load(directories: [temporary.path], maxFaceBytes: 0),
      throwsArgumentError,
    );
    await expectLater(
      system_fonts.load(
        directories: [temporary.path],
        maxTotalBytes: officeSystemFontMaxTotalBytes + 1,
      ),
      throwsArgumentError,
    );
  });

  test(
    'first registration prefers local faces and keeps existing ownership',
    () async {
      // A bundled Serif fixture stands in for installed Arial so its metric
      // identity is distinguishable from the normal Liberation Sans fallback.
      final selected = await _font('LiberationSerif-Regular.ttf');
      final first = OfficeHostFonts.ensureRegistered(
        preferredFaces: [
          OfficeSystemFontFace(family: 'Arial', bytes: selected),
          OfficeSystemFontFace(family: 'Courier New', bytes: Uint8List(12)),
        ],
      );
      await Future.wait([first, OfficeHostFonts.ensureRegistered()]);
      expect(OfficeHostFonts.registeredFamily('Arial'), 'Arial');
      expect(OfficeHostFonts.registeredFamily('Helvetica'), 'Liberation Sans');
      expect(
        OfficeHostFonts.registeredFamily('Courier New'),
        'Liberation Mono',
      );
      expect(
        OfficeHostFonts.wordMetrics(
          65,
          12,
          WmlRunProps(asciiFont: 'Arial'),
        )!.font.bytes,
        selected,
      );
      final revision = OfficeHostFonts.registrationRevision;
      await OfficeHostFonts.ensureRegistered(
        preferredFaces: [OfficeSystemFontFace(family: 'Arial', bytes: regular)],
      );
      expect(OfficeHostFonts.registrationRevision, revision);
      expect(
        OfficeHostFonts.wordMetrics(
          65,
          12,
          WmlRunProps(asciiFont: 'Arial'),
        )!.font.bytes,
        selected,
      );
      await expectLater(
        OfficeHostFonts.registerFamily(
          family: 'Unrelated owner',
          aliases: ['Arial'],
          faces: [ByteData.sublistView(regular)],
        ),
        throwsStateError,
      );
      expect(OfficeHostFonts.registeredFamily('Arial'), 'Arial');
    },
  );
}
