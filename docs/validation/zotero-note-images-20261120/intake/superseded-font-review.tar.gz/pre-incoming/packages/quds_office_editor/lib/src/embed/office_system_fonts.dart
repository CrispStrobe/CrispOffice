import 'office_system_font_face.dart';
import 'office_system_fonts_stub.dart'
    if (dart.library.io) 'office_system_fonts_io.dart'
    as impl;

export 'office_system_font_face.dart';

/// Discovers installed Microsoft Office/OS fonts without bundling them.
abstract final class OfficeSystemFonts {
  /// Reads known local TrueType faces asynchronously, with an 8 MiB per-face
  /// and 64 MiB total limit. Missing, unreadable, malformed, or oversized faces
  /// keep their bundled fallbacks. Web and mobile hosts return an empty list.
  static Future<List<OfficeSystemFontFace>> load() => impl.load();
}
