# Incoming reconciliation and independent review

## Current intake boundary

All captured new histories are included at integration checkpoint `64e3f71b2d3b72064d8eaef03e9a6699b7d8b54a`. The parent owns the later authoritative source commit and complete qualification. This archive records intake, merge review, concrete defect controls, and exact historical provenance; it is not a claim that the full final source already passed the planned gate.

The initial capture had **255 external ref observations** plus the task's own continuation branch. The second capture adds PR 233, yielding **256 external observations**: 15 fork branch heads, 233 fork PR heads, 4 upstream branch heads, and 4 upstream PR heads. The task's own continuation branch is excluded into `continuation_refs_separate`, so the captured total including that branch is 257. `final-intake-audit.json` records 233 observations included by ancestry and 23 observations covered by 14 exact historical equivalence proofs. Those proofs were freshly rechecked against 480 original changed-path mode/type/blob identities. None failed, and no captured head remains unaccounted for.

`final-required-ancestry.json` separately proves ancestry of the user's original `7501b604` checkpoint, initial main `e06eb3a7`, final captured main `c16e1213`, initial/current VBA `4b8ad781`/`e656bc17`, initial/current Mail `81b0d762`/`20b2ecf5`, and font head `9bd16ff4`. Ref observations can share commits and are not counted as distinct feature changes.

No GitHub Actions, workflow, check, or commit-status endpoints were queried or awaited by this review.

## Original parents and resolved source

The initial three integrations were `60428743` (VBA), `fcc6c2c4` (Mail), and `5b81fe13` (installed font discovery). Their original incoming ancestry is retained. [Initial review](README-initial.md) details the genuine-base Mail merge and its semantic resolutions.

The later main `c16e1213` was merged by the parent as `189831b7`. The native merge had two ordinary conflicts. The already combined importer and 40 unique import-fidelity cases were retained; incoming main had 39 unique cases, all covered. This reconciliation introduces documentation and preserved evidence, with zero product-source delta. The reviewed tree was `467f83c6a37e9da9c2dd5ef9e40234b0bd865dc9`. [Main resolution](second-main-reconciliation/resolution.json) contains parent identities and unchanged hashes for others' unfinished image work.

The later VBA `e656bc17` was merged as `64e3f71b`. Six ordinary conflicts were resolved using its canonical gradient model/parser/rendering and installed-font APIs. Forty unique import-fidelity cases remain, with incoming stronger ownership/stop assertions and the existing additional copy/save/master controls. The editor publication fixture now explicitly marks gradient ownership. The reviewed tree was `c31fd764605893e75db9f7bb815534987021783c`. [VBA resolution](second-vba-reconciliation/resolution.json) records all 21 changed paths and byte-preservation of unrelated image/document edits.

Canonical gradients have one selected fill, preserve ordinary decorations, support consistent copy/clear/save behavior, and route authored master solids through the renderer/exporter using `isBackgroundFill`. Incoming radial PDF gradients and geometry clipping remain intact. Canonical font discovery performs bounded asynchronous reads and validates actual TrueType family/style metadata. Installed registration replaces only the three known bundled Office compatibility aliases, with internal Flutter paint names, while retaining explicit host ownership.

## Independent defects and receipts

### Inherited gradients above directly assigned master solids

The initial combined source painted inherited gradients over a newly assigned master solid. One engine PDF case and two editor pixel cases failed before the correction. The complete focused publication suites then passed 3 engine and 4 editor cases. These development receipts are in [gradient-review](gradient-review/after-fix-engine.json). The subsequent canonical ownership implementation supersedes the minimal identity predicate; the regression cases remain selected for the parent's final source gate. These overlapping development executions are not extra acceptance cases.

### Reserved installed font paint names

An independently added concurrent-registration regression failed on canonical `64e3f71b`: a new authored family could claim an internal paint name while another font load had reserved it but had not yet published its registry entry. The failed receipt is [before-fix](font-reservation-review/before-fix.json).

The correction adds `_installedNames.contains(key)` to the existing ownership gate after same-family pending loads are awaited. Accepted owners and idempotent registration retain their behavior. The full installed-host suite, including the new regression, passes **8 cases**, with no errors or skips and unchanged guarded input hashes. Strict fatal-info analysis passes both changed files. [After-fix receipt](font-reservation-review/after-fix.json), [analysis](font-reservation-review/analysis.json), and [patch](font-reservation-review/fix.diff) retain exact source boundaries. This was a two-file working delta over `64e3f71b`; the parent's later committed gate is authoritative.

### Superseded local font prototype

A local bounded-load/first-registration prototype was interrupted when the newer VBA head delivered a more complete implementation. The prototype's six exact files, 12 passing development cases, and one analyzer information diagnostic are preserved under [font-review](font-review/pre-incoming/manifest.json). Those sources are not the final product API and their results do not qualify the canonical implementation. The parent saved them remotely before their exact tracked paths were restored and the duplicate prototype test removed.

### Arabic detached-buffer control

[Arabic worker review](arabic-worker-review.json) records three Node controls using real structured-clone buffer detachment with controlled Wasm responses. This addresses the previously identified worker-protocol concern without claiming live browser/native-model acceptance.

## Frozen-source gate preparation

[Incoming selection](proposed-incoming-selection-second.json) contains 101 distinct test files in 10 cohorts, including all incoming installed-font/effects/gradient controls. The parent combines it with complete Zotero and shared regressions without duplicate file selection.

[Changed Dart scope](changed-dart-scope-final.json) enumerates **116 active changed Dart source, test, and tool targets** from the original user checkpoint through the current feature working delta. One preserved historical validation probe outside active packages is listed separately. The parent will bind that scope to its next source commit before analysis and formatting checks.

[Portable VBA plan](portable-plan.json) uses the incoming unchanged runner to freshly compile seven smoke programs and replay 271 canonical cases independently on the VM and JavaScript. It compares exact case IDs, VM/JS byte receipts, and the original Excel receipt hashes, with before/after source manifests. That execution was still pending when this review archive was created and belongs to a separate final qualification receipt.

Source/test edits from this reviewer are frozen. Raw failures and earlier evidence retain their original attribution; this archive claims no fresh browser, mobile, live Mail/Zotero-account, or native Word/PowerPoint acceptance.
