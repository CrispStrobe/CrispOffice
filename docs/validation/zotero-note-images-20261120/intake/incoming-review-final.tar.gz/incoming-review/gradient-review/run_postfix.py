import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

repo = Path('/workspace/scratch/0faa407ae6ae/quds_office_suite')
out = Path(__file__).parent
kind = sys.argv[1]
paths = [
    'packages/quds_office_engine/lib/src/pdf/office_pdf_export.dart',
    'packages/quds_office_editor/lib/src/editor_slide/render_slide_stage.dart',
    'packages/quds_office_engine/test/slide_background_publication_test.dart',
    'packages/quds_office_editor/test/slide_background_publication_test.dart',
    'pubspec.lock', '.dart_tool/package_config.json',
]

def hashes():
    return {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in paths}

dart = os.environ['FLUTTER_ROOT'] + '/bin/cache/dart-sdk/bin/dart'
if kind == 'engine':
    package = 'packages/quds_office_engine'
    command = [dart, '--packages=' + str(repo / '.dart_tool/package_config.json'),
               os.environ['PUB_CACHE'] + '/hosted/pub.dev/test-1.31.1/bin/test.dart',
               '--reporter=json', '--concurrency=1',
               'test/slide_background_publication_test.dart']
elif kind == 'editor':
    package = 'packages/quds_office_editor'
    command = ['flock', '/workspace/scratch/0faa407ae6ae/toolchains/qualified-local-validation.lock',
               os.environ['FLUTTER_ROOT'] + '/bin/flutter', 'test', '--no-pub',
               '--concurrency=1', '--reporter=json',
               'test/slide_background_publication_test.dart']
else:
    raise ValueError(kind)
before = hashes()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
r = subprocess.run(command, cwd=repo / package, capture_output=True, text=True)
(out / f'after-fix-{kind}.jsonl').write_text(r.stdout)
(out / f'after-fix-{kind}.stderr.log').write_text(r.stderr)
events = []
for line in r.stdout.splitlines():
    try:
        events.append(json.loads(line))
    except ValueError:
        pass
cases = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden')]
errors = [e for e in events if e.get('type') == 'error']
report = dict(command=command, cwd=package, source_head_before=head,
              source_boundary='Tracked working delta over recorded head; final frozen-source gate is separate.',
              before=before, after=hashes(), exit_code=r.returncode,
              at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              passed=sum(e.get('result') == 'success' and not e.get('skipped') for e in cases),
              failed=sum(e.get('result') != 'success' for e in cases),
              skipped=sum(bool(e.get('skipped')) for e in cases), errors=errors,
              done=[e for e in events if e.get('type') == 'done'])
(out / f'after-fix-{kind}.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['exit_code', 'passed', 'failed', 'skipped', 'errors', 'done']}, indent=2))
print(r.stderr)
