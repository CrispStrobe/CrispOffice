# Incoming history and merge review

This review covers the finite intake captured in `intake-audit.json`, beginning at fork main `e06eb3a7e21b71c1d5d4b1d2cc9abde24774eb26`. It does not substitute historical receipts for qualification of the combined source. No GitHub Actions, workflow, check, or commit-status endpoints were queried or awaited.

## Intake and ancestry

The captured set contains 15 fork branch heads, 232 fork pull-request heads, 4 upstream branch heads, and 4 upstream pull-request heads. The current continuation branch is recorded separately. Of these 255 observations, 228 were already ancestors of main, 23 have exact historical equivalence, and 4 identify three new incoming commits (the VBA branch and PR 227 share one head). Fourteen historical equivalence mappings were rechecked against 480 original changed paths, including Git mode/type/blob identities. All mappings passed. Historical equivalent changes should not be reapplied.

| Incoming snapshot | Commit | Integrated by parent |
| --- | --- | --- |
| VBA, Arabic worker lifecycle, Word and slide work | `4b8ad78188f2d1f4031887cd51262b07e865a552` | `6042874358fd7341df8cb2c9b69a418bcf351086` |
| Mail draft recovery and incoming gradients/transparency | `81b0d7620bd7d57ee2d5fe878abbad85f0488a00` | `fcc6c2c4` |
| Installed Office font discovery | `9bd16ff4d97f2a63f450f161fe10eb3bb2808857` | `5b81fe13c786268b5c549c2cc4a363fecb2156b0` |

These merge commits retain the incoming original parents. Parent controls remote verification and final merge. The initial audit alone does not establish that later remote changes are covered.

## Merge decisions

The VBA conflicts were the slide importer and its import-fidelity suite. Resolution retained both the incoming namespace-aware picture decode/crop/luminance/transparency work and main's gradient ownership/parser behavior. The Word auto-merge was inspected: regular `sz` precedence, preserved `szCs`, main kerning, and cleared/bar tabs coexist.

Ordinary Mail merging could not construct a recursive virtual base because the partial Git repository requested synthetic objects the promisor remote could not serve. No worktree changes occurred in that failed attempt. The two real maximal common ancestors are `2cfeca15d197110a65a1cbe7601e763ee281fc9d` and `9c544ecc0377222c1c491f34328b4a7a340fc02e`. An isolated `merge-tree` used the former genuine ancestor and both current parents. The raw candidate tree was `1a05629ef1e9c3e67029a998dc963212d45cae26`; the reviewed resolution tree was `ad8f185df8599620f66ae8c37e1f0877de072541`. The parent materialized that exact tree and recorded both parents.

Eight normal conflicts and one semantic auto-merge collision required resolution. The latter had duplicate gradient classes. The final model has one gradient API with radial compatibility and separate selected picture/gradient ownership. Rendering applies picture alpha once, retains the incoming projected linear-gradient span, and clips gradient geometry without erasing existing freeform support. The gradient clip switch includes the incoming `homePlate` preset. The import-fidelity test file contains 40 unique named declarations: the duplicate moved geometry test from the intermediate merge was removed while preserving all distinct behavior. All 154 incoming Mail paths checked against the final proposal retain exact incoming identities.

Details and byte identities are in `mail-merge-proposal.json`, with the complete resolution diff and isolated merge receipts beside it.

## Concrete combined-source defect found and fixed

Directly assigning a solid master background left its inherited gradient snapshot painted on top in the editor and PDF exporter. The existing filtering logic recognized selected background pictures but did not recognize the separately selected gradient introduced by incoming work.

The correction recognizes `identical(shape, slide.backgroundGradient)` alongside picture ownership, only when the slide inherits an authored master background. This preserves authored slide/layout gradients and ordinary background decorations. Rendering does not mutate the retained source snapshot.

Four files were changed for this correction: engine PDF export, editor slide renderer, and their two `slide_background_publication_test.dart` suites. The engine regression checks master/layout/slide ownership, dark/white solids, and one/two-slide PDF publication; editor regressions check rendered pixels and unchanged background ownership/decorations.

Development results under `gradient-review/` retain both failures and passes:

| Run | Visible cases | Result |
| --- | ---: | --- |
| Before fix, new engine regression | 1 | Failed with gradient paint operations above the solid master |
| Before fix, new editor regressions | 2 | Failed with red inherited-gradient pixels above dark/white masters |
| After fix, complete engine publication suite | 3 | Passed |
| After fix, complete editor publication suite | 4 | Passed |

The 7 passing cases include the 3 new regressions. Failed attempts and repeated development runs are not added to final acceptance counts. The four changed source/test hashes, lockfile hash, and package configuration hash remained unchanged during each passing run. Fatal-info analysis passed all four files. These are development receipts against a tracked working delta over `5b81fe13`; the parent's frozen-source qualification remains authoritative.

## Additional independent control

`arabic-worker-review.json` records the incoming worker lifecycle harness running with Node v24.22.3, actual structured-clone buffer transfer/detachment, and controlled Wasm responses. It passed three controls: removal retains the database after buffers detach, normal analysis avoids another database transfer, and repeated removal/reload works. This directly addresses the previous detached-buffer concern at the worker protocol seam. It does not establish browser or native binary/model acceptance.

## Remaining qualification boundary

`proposed-incoming-selection.json` selects 97 incoming regression files in 10 cohorts: macros, engine rendering, editor rendering/fonts, Arabic core lifecycle, Arabic Studio, other Studio regressions, Word merge seams, Mail models, Mail store, and Mail hosts. Portable VM/JavaScript replay and strict changed-source analysis are separate controls. The complete Zotero suites and new feature regressions are selected by the parent separately without double counting. Neither this selection nor imported native Word/PowerPoint receipts establishes fresh application, browser, mobile, native model, or live-account acceptance.
