import os,sys,pathlib,json,subprocess,datetime,hashlib
root=pathlib.Path('/workspace/scratch/0faa407ae6ae/quds_office_suite');out=pathlib.Path(__file__).parent
phase=sys.argv[1]
paths=['packages/quds_office_editor/lib/src/embed/office_host_fonts.dart','packages/quds_office_editor/lib/src/embed/office_system_font_validation.dart','packages/quds_office_editor/test/installed_host_fonts_test.dart','packages/quds_office_editor/test/support/installed_font_fixture.dart','pubspec.lock','.dart_tool/package_config.json']
def manifest():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
cmd=['flock',str(root.parent/'toolchains/qualified-local-validation.lock'),os.environ['FLUTTER_ROOT']+'/bin/flutter','test','--no-pub','--concurrency=1','--reporter=json','test/installed_host_fonts_test.dart']
if len(sys.argv)<3:cmd+=['--plain-name','pending internal paint names reject authored ownership']
before=manifest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
with (out/(phase+'.jsonl')).open('w') as stdout,(out/(phase+'.stderr.log')).open('w') as stderr:
 run=subprocess.run(cmd,cwd=root/'packages/quds_office_editor',stdout=stdout,stderr=stderr)
events=[]
for line in (out/(phase+'.jsonl')).read_text().split(chr(10)):
 try:events.append(json.loads(line))
 except json.JSONDecodeError:pass
results=[e for e in events if e.get('type')=='testDone' and not e.get('hidden',False)]
report={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'source_head':head,'source_boundary':'Development working delta; final frozen-source gate separate.','before':before,'after':manifest(),'exit_code':run.returncode,'passed':sum(e.get('result')=='success' and not e.get('skipped',False) for e in results),'failed':sum(e.get('result')!='success' for e in results),'skipped':sum(e.get('skipped',False) for e in results),'errors':[e for e in events if e.get('type')=='error'],'done':[e for e in events if e.get('type')=='done']}
(out/(phase+'.json')).write_text(json.dumps(report,indent=2)+chr(10));print(json.dumps(report,indent=2))
