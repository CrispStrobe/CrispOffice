#!/usr/bin/env python3
"""Source-bound local checks for the German proofing continuation."""
from __future__ import annotations

import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/1f813c551f96')
REPO = ROOT / 'quds_office_suite'
OUT = ROOT / 'validation/final/combined'
DART = ROOT / 'runtime/flutter/bin/cache/dart-sdk/bin/dart'
FLUTTER = ROOT / 'runtime/flutter/bin/flutter'
PYTHON = ROOT / 'native-runtime/venv/bin/python'
NATIVE = ROOT / 'native-runtime'
LIBRARY_SHA = '71b32e67763164be7f79067dc712d1b21d405fd94b925074f880b221b738c856'
MODEL_SHA = '549ee3a5272726d48608cebdb435aaea6a984f3f53508b20b3194a7175a5ef5b'


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    if OUT.exists():
        raise SystemExit('Refusing to replace previous combined evidence.')
    OUT.mkdir(parents=True)
    (NATIVE / 'bin').mkdir(exist_ok=True)
    spec = importlib.util.spec_from_file_location(
        'proofing_verifier', REPO / 'tools/proofing/verify_integration.py')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    env = {**os.environ, 'CI': 'true', 'DART_SUPPRESS_ANALYTICS': 'true',
           'FLUTTER_SUPPRESS_ANALYTICS': 'true',
           'PUB_CACHE': str(ROOT / 'runtime/pub-cache'),
           'TMPDIR': str(ROOT / 'runtime/tmp'), 'CRISPEMBED_GECTOR': '1',
           'GECTOR_TEST_MODEL': str(NATIVE / 'gector-de-mixed-q4_k.gguf'),
           'GECTOR_TEST_MODEL_SHA256': MODEL_SHA,
           'GECTOR_TEST_LIBRARY': str(NATIVE / 'libraries' / LIBRARY_SHA / 'libcrispembed-gector.so'),
           'GECTOR_TEST_LIBRARY_SHA256': LIBRARY_SHA}
    before = verifier.source_hashes()
    manifest = json.dumps(before, sort_keys=True, indent=2).encode() + b'\n'
    (OUT / 'inputs-before.json.gz').write_bytes(gzip.compress(manifest, mtime=0))
    (OUT / 'workspace-pubspec.lock').write_bytes((REPO / 'pubspec.lock').read_bytes())
    record = {'schema_version': 1, 'started_utc': now(),
              'source_head_at_start': verifier.git('rev-parse', 'HEAD'),
              'source_diff_at_start': verifier.git('status', '--short'),
              'input_count': len(before), 'commands': [],
              'runner_sha256': digest(__file__),
              'inputs_before_sha256': digest(OUT / 'inputs-before.json.gz'),
              'workspace_lock_sha256': digest(REPO / 'pubspec.lock'),
              'runtime_sha256': {str(p): digest(p) for p in [DART, FLUTTER, PYTHON]},
              'native_library_sha256': LIBRARY_SHA, 'model_sha256': MODEL_SHA,
              'github_actions_used': False, 'status': 'running'}

    def save():
        (OUT / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')

    def run(name, args, directory):
        args = [str(v) for v in args]
        log = OUT / (name + '.log')
        began = time.monotonic()
        print('START ' + name, flush=True)
        with log.open('wb') as f:
            completed = subprocess.run(args, cwd=directory, env=env,
                                       stdout=f, stderr=subprocess.STDOUT,
                                       timeout=600)
        entry = {'name': name, 'argv': args, 'cwd': str(directory),
                 'exit_code': completed.returncode,
                 'seconds': time.monotonic() - began,
                 'log': log.name, 'log_sha256': digest(log)}
        summary = verifier.test_summary(log)
        if summary:
            entry['tests'] = summary
        record['commands'].append(entry)
        save()
        print('END ' + name + ' ' + json.dumps(entry.get('tests', {})) +
              ' exit=' + str(completed.returncode), flush=True)
        if completed.returncode:
            print(log.read_text(errors='replace')[-10000:], flush=True)
            raise RuntimeError(name + ' failed')

    engine = REPO / 'packages/quds_office_engine'
    editor = REPO / 'packages/quds_office_editor'
    gector = REPO / 'packages/quds_proofing_gector'
    odf = ['odt_document_writer', 'odt_note_fidelity', 'odt_header_footer_fidelity',
           'odt_table_merge', 'odp_presentation_writer', 'odp_table_fidelity',
           'odf_covered_cell_extraction', 'odf_annotation_extraction',
           'office_search_fidelity', 'odf_export_text_fidelity',
           'ods_sheet_reader', 'ods_sheet_writer']
    editor_tests = sorted({str(p.relative_to(editor))
                           for pattern in ['word_proofing_*_test.dart',
                                           'word_hyphenation_*_test.dart',
                                           'word_manual_proofing_test.dart',
                                           'word_german_grammar_integration_test.dart',
                                           'platform_spelling_provider_test.dart']
                           for p in (editor / 'test').glob(pattern)})
    save()
    try:
        run('engine-proofing-vm', [DART, 'test', '--reporter=expanded',
                                 '--concurrency=2', 'test/proofing'], engine)
        run('gector-with-real-native', [DART, 'test', '--reporter=expanded',
                                      '--concurrency=2'], gector)
        run('gector-strict-analysis', [DART, 'analyze', '--fatal-infos',
                                      'lib', 'test', 'tool'], gector)
        run('editor-proofing', [FLUTTER, 'test', '--no-pub', '--reporter=expanded',
                               '--concurrency=2', *editor_tests], editor)
        run('editor-proofing-analysis', [DART, 'analyze', '--fatal-infos',
                                        'lib/src/proofing',
                                        'test/word_manual_proofing_test.dart'], editor)
        run('odf-search-ods', [DART, 'test', '--reporter=expanded', '--concurrency=4',
                             *['test/' + p + '_test.dart' for p in odf]], engine)
        run('qualification-python', [PYTHON, '-m', 'pytest', '-q',
                                     'tools/proofing/german_model/test_export_reference.py',
                                     'tools/proofing/german_model/test_qualification.py',
                                     'tools/proofing/german_model/test_native_qualification.py'], REPO)
        run('compile-provider-aot', [DART, 'compile', 'exe',
                                    'tools/proofing/german_model/run_gector_dart.dart',
                                    '-o', NATIVE / 'bin/gector-check'], REPO)
        record['aot_executable_sha256'] = digest(NATIVE / 'bin/gector-check')
        record['status'] = 'passed'
    except Exception as error:
        record['status'] = 'failed'
        record['error'] = str(error)
    finally:
        after = verifier.source_hashes()
        data = json.dumps(after, sort_keys=True, indent=2).encode() + b'\n'
        (OUT / 'inputs-after.json.gz').write_bytes(gzip.compress(data, mtime=0))
        record['inputs_after_sha256'] = digest(OUT / 'inputs-after.json.gz')
        record['inputs_unchanged'] = before == after
        record['input_differences'] = [p for p in sorted(set(before) | set(after))
                                       if before.get(p) != after.get(p)]
        record['source_head_at_end'] = verifier.git('rev-parse', 'HEAD')
        record['completed_utc'] = now()
        if not record['inputs_unchanged']:
            record['status'] = 'failed'
        save()
        print(json.dumps({k: v for k, v in record.items()
                          if k in ['status', 'input_count', 'inputs_unchanged', 'error']}), flush=True)
    return 0 if record['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
