#!/usr/bin/env python3
"""Compare every new VM/Node outcome with the retained qualified evidence."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path('/workspace/scratch/1f813c551f96')
REPO = ROOT / 'quds_office_suite'
OUTPUT = ROOT / 'validation/final'
ARCHIVE = REPO / 'docs/validation/german-morphology-20261117/morphology-corpora.tar.gz'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    report = {
        'compared_at_utc': datetime.now(timezone.utc).isoformat(),
        'historical_archive': str(ARCHIVE.relative_to(REPO)),
        'historical_archive_sha256': sha(ARCHIVE.read_bytes()),
        'runs': {},
    }
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        for kind, old_directory in (
            ('corpus', 'morphology-final-frozen'),
            ('review-corpus', 'morphology-review-final-frozen'),
        ):
            old_name = old_directory + '/vm-results.json'
            old_bytes = archive.extractfile(old_name).read()
            old = json.loads(old_bytes)
            old_node = json.load(archive.extractfile(old_directory + '/node-results.json'))
            new_file = OUTPUT / kind / 'vm-results.json'
            new = json.loads(new_file.read_text())
            new_node = json.loads((OUTPUT / kind / 'node-results.json').read_text())
            assert old == old_node
            assert new == new_node
            old_results = {(item['id'], item['variant']): item for item in old['results']}
            new_results = {(item['id'], item['variant']): item for item in new['results']}
            assert old_results.keys() == new_results.keys()
            changes = [
                {'id': key[0], 'variant': key[1], 'before': old_results[key], 'after': new_results[key]}
                for key in sorted(old_results)
                if old_results[key] != new_results[key]
            ]
            variants = {}
            for variant in sorted({item['variant'] for item in new['results']}):
                items = [item for item in new['results'] if item['variant'] == variant]
                counts = Counter(item['kind'] for item in items)
                variants[variant] = {
                    'requests': len(items),
                    'errors': counts['error'],
                    'exact_errors': sum(item.get('exact') is True for item in items if item['kind'] == 'error'),
                    'controls': counts['control'],
                    'flagged_controls': sum(item['clean'] is not True for item in items if item['kind'] == 'control'),
                    'protected_requests': counts['protection'],
                    'flagged_protected_requests': sum(item['clean'] is not True for item in items if item['kind'] == 'protection'),
                }
            report['runs'][kind] = {
                'historical_member': old_name,
                'historical_member_sha256': sha(old_bytes),
                'current_vm_sha256': sha(new_file.read_bytes()),
                'current_node_sha256': sha((OUTPUT / kind / 'node-results.json').read_bytes()),
                'historical_vm_node_equal': True,
                'current_vm_node_equal': True,
                'records_compared_per_runtime': len(new_results),
                'before_summary': old['summary'],
                'after_summary': new['summary'],
                'changed_records_per_runtime': len(changes),
                'changes': changes,
                'variants': variants,
            }
    core_changes = report['runs']['corpus']['changes']
    assert {(item['id'], item['variant']) for item in core_changes} == {
        ('error-081', 'base'), ('error-081', 'source-offset'),
        ('error-081', 'soft-hyphen'), ('error-081', 'locale-alias'),
    }
    assert all(item['after']['exact'] is True and item['before']['exact'] is False for item in core_changes)
    assert not report['runs']['review-corpus']['changes']
    report['passed'] = True
    (OUTPUT / 'corpus-outcome-comparison.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({kind: {
        'summary': result['after_summary'],
        'changed_records_per_runtime': result['changed_records_per_runtime'],
        'changed_ids': sorted({item['id'] for item in result['changes']}),
        'current_vm_node_equal': result['current_vm_node_equal'],
    } for kind, result in report['runs'].items()}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
