#!/usr/bin/env python3
"""Record fresh deterministic checks without changing project source."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/1f813c551f96')
REPO = ROOT / 'quds_office_suite'
ENGINE = REPO / 'packages/quds_office_engine'
DART = ROOT / 'runtime/flutter/bin/cache/dart-sdk/bin/dart'
OUTPUT = ROOT / 'validation/final'


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot() -> dict[str, str]:
    paths = set()
    for directory in (
        ENGINE / 'lib', ENGINE / 'test', ENGINE / 'tool',
        REPO / 'packages/legacy_doc_parser/lib',
    ):
        paths.update(path for path in directory.rglob('*') if path.is_file())
    for relative in (
        'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
        '.dart_tool/package_config.json',
        'packages/quds_office_engine/pubspec.yaml',
        'packages/quds_office_engine/analysis_options.yaml',
        'packages/legacy_doc_parser/pubspec.yaml',
        'tools/proofing/run_morphology_qualification.py',
        'tools/proofing/qualify_german_morphology.dart',
        'tools/proofing/german_morphology_cases.json',
        'tools/proofing/german_morphology_review_cases.json',
    ):
        paths.add(REPO / relative)
    return {
        str(path.relative_to(REPO)): digest(path)
        for path in sorted(paths) if path.is_file()
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('kind', choices=['engine-node', 'analysis', 'corpus', 'review-corpus'])
    args = parser.parse_args()
    destination = OUTPUT / args.kind
    destination.mkdir(parents=True, exist_ok=True)
    temporary = destination / 'tmp'
    temporary.mkdir(exist_ok=True)
    controls = {
        'CI': 'true',
        'DART_SUPPRESS_ANALYTICS': 'true',
        'FLUTTER_SUPPRESS_ANALYTICS': 'true',
        'TMPDIR': str(temporary),
        'PUB_CACHE': str(ROOT / 'runtime/pub-cache'),
    }
    environment = dict(os.environ, **controls)
    if args.kind == 'engine-node':
        command = [str(DART), 'test', '--reporter=expanded', '--platform=node',
                   '--concurrency=2', 'test/proofing']
        cwd = ENGINE
    elif args.kind == 'analysis':
        command = [str(DART), 'analyze', '--fatal-infos', 'lib', 'test', 'tool']
        cwd = ENGINE
    else:
        corpus = ('german_morphology_review_cases.json'
                  if args.kind == 'review-corpus' else 'german_morphology_cases.json')
        command = ['python3', str(REPO / 'tools/proofing/run_morphology_qualification.py'),
                   '--target', str(REPO), '--output', str(destination),
                   '--dart', str(DART), '--corpus', str(REPO / 'tools/proofing' / corpus)]
        cwd = REPO
    before = snapshot()
    started = datetime.now(timezone.utc).isoformat()
    begin = time.monotonic()
    log = destination / 'command.log'
    failure = None
    code = None
    try:
        with log.open('wb') as stream:
            result = subprocess.run(command, cwd=cwd, env=environment,
                                    stdout=stream, stderr=subprocess.STDOUT,
                                    timeout=1800)
        code = result.returncode
    except BaseException as error:
        failure = repr(error)
    after = snapshot()
    receipt = {
        'kind': args.kind,
        'started_at_utc': started,
        'completed_at_utc': datetime.now(timezone.utc).isoformat(),
        'elapsed_seconds': time.monotonic() - begin,
        'command': command,
        'cwd': str(cwd),
        'environment_controls': controls,
        'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
        'source_inputs_sha256': before,
        'source_input_count': len(before),
        'source_unchanged': before == after,
        'changed_inputs': sorted(key for key in before.keys() | after.keys() if before.get(key) != after.get(key)),
        'dart_version': subprocess.check_output([str(DART), '--version'], env=environment, text=True, stderr=subprocess.STDOUT).strip(),
        'dart_sha256': digest(DART),
        'node_version': subprocess.check_output(['node', '--version'], text=True).strip(),
        'node_sha256': digest(Path(shutil.which('node')).resolve()),
        'exit_code': code,
        'exception': failure,
        'log_sha256': digest(log),
        'github_actions_used': False,
        'passed': code == 0 and failure is None and before == after,
    }
    (destination / 'command-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: value for key, value in receipt.items() if key != 'source_inputs_sha256'}, indent=2))
    print(log.read_text()[-5000:])
    if not receipt['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
