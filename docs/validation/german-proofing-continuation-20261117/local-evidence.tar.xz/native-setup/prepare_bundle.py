"""Download only the exact Quds-pinned Proofbird development bundle."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import urllib.request

root = Path('/workspace/scratch/1f813c551f96')
manifest = root / 'quds_office_suite/tools/proofing/german_model/artifacts.json'
target = root / 'native-runtime/proofbird'
records_dir = root / 'validation/native-setup'
target.mkdir(parents=True, exist_ok=True)
records_dir.mkdir(parents=True, exist_ok=True)
started = datetime.now(timezone.utc).isoformat()
host = {
    'started_utc': started,
    'platform': platform.platform(),
    'cpu_count': os.cpu_count(),
    'load_average': os.getloadavg(),
    'disk_free_bytes': shutil.disk_usage(root).free,
    'memory': Path('/proc/meminfo').read_text(),
    'cpu_model': next((line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')), None),
}
(records_dir / 'host-before.json').write_text(json.dumps(host, indent=2) + '\n')

def fetch(item):
    name = item['file']
    if Path(name).name != name:
        raise ValueError('Artifact path is not a basename')
    output = target / name
    partial = target / (name + '.part')
    if output.exists() or partial.exists():
        raise ValueError('Use an empty bundle output directory: ' + name)
    digest = hashlib.sha256()
    total = 0
    with urllib.request.urlopen(item['url'], timeout=90) as response, partial.open('xb') as stream:
        for block in iter(lambda: response.read(1024 * 1024), b''):
            total += len(block)
            if total > item['size']:
                raise ValueError('Artifact exceeds pinned size: ' + name)
            digest.update(block)
            stream.write(block)
    actual = digest.hexdigest()
    if total != item['size'] or actual != item['sha256']:
        raise ValueError('Artifact does not match pinned size/hash: ' + name)
    partial.rename(output)
    return {'file': name, 'url': item['url'], 'bytes': total, 'sha256': actual, 'verified': True}

records, errors = [], []
items = json.loads(manifest.read_text())
with ThreadPoolExecutor(max_workers=4) as executor:
    jobs = {executor.submit(fetch, item): item['file'] for item in items}
    for future in as_completed(jobs):
        name = jobs[future]
        try:
            result = future.result()
            records.append(result)
            print('VERIFIED', name, result['bytes'], flush=True)
        except Exception as exc:
            errors.append({'file': name, 'error': str(exc)})
            print('FAILED', name, str(exc), flush=True)
        receipt = {
            'started_utc': started,
            'updated_utc': datetime.now(timezone.utc).isoformat(),
            'source_manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
            'files': sorted(records, key=lambda item: item['file']),
            'errors': errors,
            'complete': len(records) == len(items),
        }
        (records_dir / 'bundle-download.json').write_text(json.dumps(receipt, indent=2) + '\n')
if errors:
    raise SystemExit(1)
