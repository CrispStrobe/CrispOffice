"""Recheck the unchanged transport/UI source behind their retained receipts."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/37104639dddb/quds_office_suite')
OUT = Path('/workspace/scratch/37104639dddb/intake-audit')
BASE = '38dcd802ae79e22d9f84ad79db1a197c43f3ad70'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).splitlines()


def main():
    frozen = git('rev-parse', sys.argv[1])[0]
    entries = {}
    for line in git('ls-tree', '-r', BASE):
        head, path = line.split('\t', 1)
        entries[path] = head.split()[2]
    prior = json.loads((OUT / 'mail-isolated-environment.json').read_text())
    configs = [
        'pubspec.yaml', 'pubspec.lock',
        'packages/quds_mail_core/pubspec.yaml',
        'packages/quds_mail_mime/pubspec.yaml',
        'third_party/enough_mail/pubspec.yaml',
    ]
    cohorts = {
        'transport': {
            'passed': 415,
            'receipt': 'mail-transport-accepted-receipt.json',
            'prefixes': [
                'packages/quds_mail_transport/',
                'packages/quds_mail_core/lib/',
                'packages/quds_mail_mime/lib/',
                'packages/quds_mail_store/lib/',
                'third_party/enough_mail/lib/',
            ],
            'configs': configs + ['packages/quds_mail_store/pubspec.yaml'],
        },
        'shared_ui': {
            'passed': 164,
            'receipt': 'mail-ui-final-receipt.json',
            'prefixes': [
                'packages/quds_mail_ui/',
                'packages/quds_mail_core/lib/',
                'packages/quds_mail_mime/lib/',
                'third_party/enough_mail/lib/',
            ],
            'configs': configs,
        },
    }
    current = set(git('ls-files')) | set(git('ls-files', '--others', '--exclude-standard'))
    for cohort in cohorts.values():
        def selected(path):
            return any(path.startswith(p) for p in cohort['prefixes']) or path in cohort['configs']
        paths = sorted(p for p in entries if selected(p))
        mismatches = []
        hashes = {}
        for path in paths:
            f = ROOT / path
            if not f.is_file():
                mismatches.append({'path': path, 'reason': 'missing'})
                continue
            data = f.read_bytes()
            blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
            hashes[path] = hashlib.sha256(data).hexdigest()
            if blob != entries[path]:
                mismatches.append({'path': path, 'reason': 'blob differs'})
        additions = sorted(p for p in current if selected(p) and p not in entries)
        cohort.update({
            'path_count': len(paths), 'mismatches': mismatches,
            'added_paths': additions, 'source_sha256': hashes,
            'matches_qualified_baseline': not mismatches and not additions,
        })
    config_hash = hashlib.sha256((ROOT / '.dart_tool/package_config.json').read_bytes()).hexdigest()
    result = {
        'qualified_baseline': BASE,
        'frozen_final_source': frozen,
        'cohorts': cohorts,
        'package_config_sha256': config_hash,
        'package_config_matches_baseline': config_hash == prior['package_config_sha256'],
        'note': (
            'Core production libraries are included as transitive inputs; its independently '
            'expanded compatibility test file is not a transport/UI input. The full core '
            'suite and Studio hosts receive separate final-source runs. Retained older '
            'core/host receipts are not added to the final total.'
        ),
    }
    result['all_applicable'] = bool(
        result['package_config_matches_baseline']
        and all(c['matches_qualified_baseline'] for c in cohorts.values())
    )
    (OUT / 'mail-final-source-applicability.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({
        'frozen_final_source': frozen, 'all_applicable': result['all_applicable'],
        'cohorts': {key: {k: c[k] for k in ['passed', 'path_count', 'mismatches', 'added_paths']} for key, c in cohorts.items()},
        'package_config_matches_baseline': result['package_config_matches_baseline'],
    }, indent=2))
    raise SystemExit(0 if result['all_applicable'] else 1)


if __name__ == '__main__':
    main()
