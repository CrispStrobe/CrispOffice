"""Bundle final and retained source-specific Mail qualification without recounts."""

from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path('/workspace/scratch/37104639dddb/intake-audit')


def read(name):
    return json.loads((ROOT / name).read_text())


def suite_counts(log):
    events = []
    for line in (ROOT / log).read_text().splitlines():
        try:
            events.append(json.loads(line))
        except ValueError:
            pass
    suites = {e['suite']['id']: e['suite']['path'] for e in events if isinstance(e, dict) and e.get('type') == 'suite'}
    tests = {e['test']['id']: e['test'] for e in events if isinstance(e, dict) and e.get('type') == 'testStart'}
    counts = Counter()
    for event in events:
        if not isinstance(event, dict) or event.get('type') != 'testDone' or event.get('hidden') or event.get('skipped') or event.get('result') != 'success':
            continue
        test = tests[event['testID']]
        counts[suites[test['suiteID']]] += 1
    return dict(sorted(counts.items()))


def main():
    core = read('mail-final-core-receipt.json')
    hosts = read('mail-final-hosts-receipt.json')
    applicability = read('mail-final-source-applicability.json')
    assert core['accepted'] and hosts['accepted'] and applicability['all_applicable']
    assert core['frozen_head'] == hosts['frozen_head'] == applicability['frozen_final_source']
    assert core['passed'] == 219 and hosts['passed'] == 375
    counts = suite_counts('mail-final-hosts.jsonl')
    visual = sum(value for name, value in counts.items() if name.endswith('/studio_mail_bulk_visual_test.dart'))
    assert visual == 13 and sum(counts.values()) == 375
    baseline = ROOT / 'mail-evidence.tar.gz'
    summary = {
        'frozen_final_source': core['frozen_head'],
        'tree': read('mail-final-core-preflight.json')['tree'],
        'total_passed': 219 + 415 + 164 + 375,
        'skipped': 0, 'failed': 0, 'errors': 0,
        'cohorts': {
            'core': {'passed': 219, 'receipt': 'mail-final-core-receipt.json', 'source': core['frozen_head'], 'suites': suite_counts('mail-final-core.jsonl')},
            'transport': {'passed': 415, 'receipt': 'mail-transport-accepted-receipt.json', 'source': applicability['qualified_baseline'], 'current_source_applicability': 'mail-final-source-applicability.json'},
            'shared_ui': {'passed': 164, 'receipt': 'mail-ui-final-receipt.json', 'source': applicability['qualified_baseline'], 'current_source_applicability': 'mail-final-source-applicability.json'},
            'hosts_and_visual': {'passed': 375, 'six_host_suites': 362, 'visual_variants': 13, 'receipt': 'mail-final-hosts-receipt.json', 'source': hosts['frozen_head'], 'suites': counts},
        },
        'source_stability': {'core_inputs': core['source_count'], 'host_inputs': hosts['source_count'], 'both_unchanged': not core['changed_sources'] and not hosts['changed_sources'], 'runtime_unchanged': core['runtime_unchanged'] and hosts['runtime_unchanged']},
        'baseline_archive': {'path': baseline.name, 'bytes': baseline.stat().st_size, 'sha256': hashlib.sha256(baseline.read_bytes()).hexdigest()},
        'count_policy': 'Count the final core and host runs once. Earlier 213-case core and 361-case host runs remain historical evidence and are excluded from this total. Retain 415 transport and 164 shared-UI cases only with exact current-source applicability proofs.',
        'scope': 'Local runtime tests with controlled providers; no live mail accounts, actual sends, installed application interoperability or GitHub Actions acceptance claimed.',
    }
    (ROOT / 'mail-final-qualification.json').write_text(json.dumps(summary, indent=2) + '\n')
    report = f'''# Final Mail qualification

Qualified combined source: `{summary['frozen_final_source']}`.
Git tree: `{summary['tree']}`.

| Cohort | Passed | Source attribution |
| --- | ---: | --- |
| Complete Mail core | 219 | Final frozen source |
| Mail transport | 415 | Earlier accepted baseline; all relevant current inputs verified identical |
| Shared Mail UI | 164 | Earlier accepted baseline; all relevant current inputs verified identical |
| Six Studio Mail host suites | 362 | Final frozen source |
| Studio visual variants | 13 | Final frozen source |
| **Total** | **1,173** | Each cohort counted once |

No accepted cohort has skips, failures, errors or unfinished cases. Each new process exited 0 with a successful terminal `done` event. The {core['source_count']:,} selected source/configuration/font/asset/fixture inputs and the runtime fingerprints remained unchanged during both new runs, and the working source matched the frozen Git tree before and after execution.

The visual population contains five original toolbar-stop cases, five status-slot cases, and three localized receipt/detail cases. The six host suites include the newly retained native quota case. The core population includes all six new quota-evidence precedence cases without dropping the earlier assertions.

The old baseline archive is preserved byte for byte. Its earlier 213-case core and 361-case host runs are historical and are not added again. Transport and shared-UI reuse is backed by `mail-final-source-applicability.json`, including their local transitive Mail and vendored dependencies, locked configuration and unchanged package resolution. Core compatibility tests changed, but core production libraries used by transport/UI remain identical.

Raw JSON, stderr, exact commands, all test identities, source manifests, runtime fingerprints, process receipts and the evidence-building scripts are retained in the archive. No GitHub Actions or status endpoints were queried or awaited.
'''
    (ROOT / 'mail-final-qualification.md').write_text(report)
    files = {
        p for p in ROOT.glob('mail-final-*')
        if p.is_file() and p.suffix != '.gz'
        and p.name != 'mail-final-evidence-index.json'
    }
    for run in ['mail-transport-accepted', 'mail-ui-final']:
        for suffix in ['-receipt.json', '-sources.json', '.jsonl', '.stderr']:
            files.add(ROOT / (run + suffix))
    for name in [
        'mail-evidence.tar.gz', 'mail-qualification.json', 'mail-qualification.md',
        'mail-isolated-environment.json', 'accepted-source-applicability.json',
        'late-mail-intake-delta.json', 'late-mail-union-resolution.json',
        'run_frozen_mail_validation.py', 'check_final_mail_applicability.py',
        'package_final_mail_evidence.py',
    ]:
        files.add(ROOT / name)
    archive = ROOT / 'mail-final-evidence.tar.gz'
    with archive.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
        for path in sorted(files):
            info = tar.gettarinfo(str(path), arcname=path.name)
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            info.mode = 0o644
            with path.open('rb') as f:
                tar.addfile(info, f)
    index = {'archive': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': len(files), 'files': {p.name: {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)}}
    (ROOT / 'mail-final-evidence-index.json').write_text(json.dumps(index, indent=2) + '\n')
    print(json.dumps({k: v for k, v in index.items() if k != 'files'}, indent=2))


if __name__ == '__main__':
    main()
