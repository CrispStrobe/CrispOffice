# Final Mail qualification

Qualified combined source: `e8edb90a2948af60f41e50795c049a0a4d1ed3e6`.
Git tree: `371ed6defb1986e32fc2e0d516356ac934304e47`.

| Cohort | Passed | Source attribution |
| --- | ---: | --- |
| Complete Mail core | 219 | Final frozen source |
| Mail transport | 415 | Earlier accepted baseline; all relevant current inputs verified identical |
| Shared Mail UI | 164 | Earlier accepted baseline; all relevant current inputs verified identical |
| Six Studio Mail host suites | 362 | Final frozen source |
| Studio visual variants | 13 | Final frozen source |
| **Total** | **1,173** | Each cohort counted once |

No accepted cohort has skips, failures, errors or unfinished cases. Each new process exited 0 with a successful terminal `done` event. The 2,656 selected source/configuration/font/asset/fixture inputs and the runtime fingerprints remained unchanged during both new runs, and the working source matched the frozen Git tree before and after execution.

The visual population contains five original toolbar-stop cases, five status-slot cases, and three localized receipt/detail cases. The six host suites include the newly retained native quota case. The core population includes all six new quota-evidence precedence cases without dropping the earlier assertions.

The old baseline archive is preserved byte for byte. Its earlier 213-case core and 361-case host runs are historical and are not added again. Transport and shared-UI reuse is backed by `mail-final-source-applicability.json`, including their local transitive Mail and vendored dependencies, locked configuration and unchanged package resolution. Core compatibility tests changed, but core production libraries used by transport/UI remain identical.

Raw JSON, stderr, exact commands, all test identities, source manifests, runtime fingerprints, process receipts and the evidence-building scripts are retained in the archive. No GitHub Actions or status endpoints were queried or awaited.
