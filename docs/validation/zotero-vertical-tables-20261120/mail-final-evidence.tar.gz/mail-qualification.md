# Reconciled Mail acceptance for the Zotero intake

The implementation reconciles Mail PRs #273 and #275 and the overlapping Word
continuation while preserving both public core entry points. The source is
`38dcd802ae79e22d9f84ad79db1a197c43f3ad70`, tree
`40ec8e0bffe9d68de077ba47d64c9ec1aa860fea`.

| Cohort | Passed | Skipped | Failed |
| --- | ---: | ---: | ---: |
| Complete portable core | 213 | 0 | 0 |
| Complete transport | 415 | 0 | 0 |
| Complete shared UI | 164 | 0 | 0 |
| Six complete Studio host suites | 361 | 0 | 0 |
| Total | 1153 | 0 | 0 |

Every accepted process exited zero and reports a successful terminal event.
Earlier developmental and failed/mixed runs are retained but excluded from
these counts. Tests cover overlapping behaviors; the table counts test cases,
not independent user capabilities. The six host suites ran together from a
clean detached worktree while Zotero development continued elsewhere. All 901
scoped inputs remained unchanged; a separate 2,137-file manifest and exact Git
tree bind the full tracked Dart/config source. Earlier accepted core, transport
and UI cohorts are replay-bound to this source by exact input hashes. The
transport's broad manifest observed a concurrent Studio test-only change,
which is outside its core/transport inputs.

Complete core, transport and shared-UI analysis and 12 scoped Studio targets
pass `--fatal-infos`. All 35 changed Mail Dart files pass formatting.

## Reconciliation choices

- Preserve `MailBulkFlagRunner` and the single-use coordinator on one execution
  engine, optional validated provider identity, immutable `items`/`results`
  aliases and `stopProblem`. Retain quota-stop and refresh-after-invalid-scope
  semantics. Both runner and coordinator exercise certified quota rejection.
- Preserve the stronger host scope/session/UIDVALIDITY guards. Keep settled
  receipts for a retired selection in the same host, while refusing projection
  into the changed mailbox scope and requiring refresh.
- Preserve both list API spellings through checked aliases. Conflicting scope
  or enabled aliases reject construction. Canonical widget keys remain those
  of #273; imported tests change selectors only where necessary.
- Preserve narrow certified cloud flag rejections including 410/429 while
  leaving the separate established submission rejection/Retry-After contract
  intact. Unfamiliar client responses and timeouts remain uncertain.
- Preserve both distinct host rate-limit and stale-scope tests, original
  summary assertions plus typed receipt assertions, and the complete original
  coordinator and provider-result populations. Exact test byte retention is
  independently recorded.
- The later Word branch contains an exact duplicate runner test blob under
  another filename. Its population is retained once under `bulk_flags_test.dart`;
  the duplicate identity proof is included.

No live provider accounts, real sends, installed release, browser, or other-OS
acceptance is claimed. GitHub Actions and status endpoints were not queried or
awaited. These receipts bind this intake baseline; later changes have their own
qualification.
