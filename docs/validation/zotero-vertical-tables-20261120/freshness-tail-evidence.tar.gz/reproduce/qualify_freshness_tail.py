"""Append exact-source, replacement-only qualification for the last Mail UI intake."""

import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tarfile

from check_post_main_source_applicability import ROOT, compare, tree


OUT = ROOT.parent / 'intake-audit/freshness-tail'
AUDIT = OUT.parent
RUNTIME = ROOT.parent / 'zotero-runtime'
BASE = 'fe2c57604c33c1ee5ef1e9f25121e99d66c74d9a'
INCOMING = '329d03914808589d3e7650fa870df15a2408afe2'
FINAL = '6045998d885cbb045454a993aedfdfc0977714d6'
NATIVE = 'packages/quds_office_editor/example/lib/studio_mail_native.dart'
ACCOUNTS = 'packages/quds_office_editor/example/test/studio_mail_accounts_test.dart'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True)


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    data = Path(path).read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def source(path):
    return (path.startswith(('packages/', 'third_party/')) and not path.endswith('.md')
            or path in {'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', 'dart_test.yaml'}
            or path in {'docs/validation/zotero-vertical-tables-20261120/run_acceptance.py',
                        'docs/validation/zotero-vertical-tables-20261120/audit_results.py'})


def section(text, start, end):
    assert text.count(start) == text.count(end) == 1
    return text[text.index(start):text.index(end)]


def main(source_only=False):
    before, after = tree(BASE), tree(FINAL)
    observed = git('rev-parse', 'HEAD').strip()
    assert observed == FINAL
    assert subprocess.run(['git', 'merge-base', '--is-ancestor', INCOMING, FINAL], cwd=ROOT).returncode == 0
    paths = set(git('ls-files').splitlines()) | set(git('ls-files', '--others', '--exclude-standard').splitlines())
    changed = sorted(p for p in before.keys() | after.keys() if source(p) and before.get(p) != after.get(p))
    assert changed == sorted([NATIVE, ACCOUNTS]), changed
    protected = compare(before, after, paths, lambda p: source(p) and p not in {NATIVE, ACCOUNTS})
    assert protected['source_identical'], protected['mismatches']
    original = git('show', BASE + ':' + NATIVE)
    incoming = git('show', INCOMING + ':' + NATIVE)
    merged = git('show', FINAL + ':' + NATIVE)
    expected = original
    methods = {}
    for name, start, end in [
        ('_mailChrome', '  Widget _mailChrome(BuildContext context) {', '  Widget _accountView(BuildContext context,'),
        ('_rememberedAccounts', '  Widget _rememberedAccounts(BuildContext context) {', '  Widget _credentialFeedback(BuildContext context)'),
    ]:
        old, new = section(original, start, end), section(incoming, start, end)
        assert section(merged, start, end) == new
        expected = expected.replace(old, new, 1)
        methods[name] = {'matches_incoming_exactly': True,
                         'before_sha256': hashlib.sha256(old.encode()).hexdigest(),
                         'after_sha256': hashlib.sha256(new.encode()).hexdigest()}
    assert merged == expected, 'Native source outside the two rendering methods changed'
    assert (ROOT / NATIVE).read_text() == merged
    assert git('show', FINAL + ':' + ACCOUNTS) == git('show', INCOMING + ':' + ACCOUNTS)
    assert (ROOT / ACCOUNTS).read_text() == git('show', FINAL + ':' + ACCOUNTS)
    proof = {'base': BASE, 'incoming_main': INCOMING, 'frozen_head': FINAL,
             'tree': git('rev-parse', FINAL + '^{tree}').strip(), 'incoming_ancestry_included': True,
             'changed_source_paths': changed, 'native_methods': methods,
             'all_other_native_bytes_unchanged': True, 'account_fixture_matches_incoming_exactly': True,
             'protected_inputs': protected, 'source_binding_passed': True}
    (OUT / 'source-binding.json').write_text(json.dumps(proof, indent=2) + '\n')
    if source_only:
        print(json.dumps({'frozen_head': FINAL, 'changed_source_paths': changed,
                          'protected_input_count': protected['path_count'],
                          'source_binding_passed': True}, indent=2))
        return
    receipt = read(OUT / 'mail-final-hosts-receipt.json')
    assert receipt['accepted'] and receipt['frozen_head'] == receipt['head_after'] == FINAL
    spec = importlib.util.spec_from_file_location('audit_results', ROOT / 'docs/validation/zotero-vertical-tables-20261120/audit_results.py')
    auditor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(auditor)
    result = auditor.count(OUT / 'mail-final-hosts.jsonl')
    assert result['passed'] == 95 and result['skipped'] == 0
    assert result['suites'] == {
        'studio_mail_accounts_test.dart': {'success': 22},
        'studio_mail_workspace_test.dart': {'success': 60},
        'studio_mail_bulk_visual_test.dart': {'success': 13},
    }
    static_dir = RUNTIME / 'frozen-dart-6045998d'
    static = read(static_dir / 'receipt.json')
    assert static['frozenHead'] == static['headAfter'] == FINAL and static['fileCount'] == 75
    assert static['sourceStable'] and not static['changedDuringVerification']
    assert read(static_dir / 'source-before.json')['files'] == read(static_dir / 'source-after.json')['files']
    for name, value in static['results'].items():
        assert value['exitCode'] == 0
        assert value['logSha256'] == digest(static_dir / (name + '.log'))['sha256']
    prior = AUDIT / 'latest-main/post-main-evidence.tar.gz'
    prior_index = read(AUDIT / 'latest-main/post-main-evidence-index.json')
    assert digest(prior)['sha256'] == prior_index['sha256']
    prior_qualification = read(AUDIT / 'latest-main/post-main-qualification.json')
    publication_manifest = RUNTIME / 'final-publication-sources.json'
    assert digest(publication_manifest)['sha256'] == 'ea2a110bb9220705d1d7c399448d66ca1ca0d1ba9e53de2c98f1b47a33e54ff8'
    publication_sources = read(publication_manifest)
    assert len(publication_sources) == 5257
    assert all(digest(ROOT / path)['sha256'] == expected for path, expected in publication_sources.items())
    summary = {'frozen_head': FINAL, 'tree': proof['tree'], 'incoming_main': INCOMING,
               'new_acceptance': result,
               'replacement_policy': 'Replace accounts22, native workspace60 and visual13 inside the existing436 host population; add no cases.',
               'host_population': {'retained_from_fe2': 341, 'replaced_at_final': 95, 'total': 436},
               'mail': {'core': 219, 'transport': 415, 'shared_ui': 179, 'hosts': 436, 'total_passed': 1249},
               'word': {'engine': 823, 'editor': 598, 'incoming_word': 974, 'total_passed': 2395, 'skipped': 8},
               'combined': {'passed': 3644, 'skipped': 8, 'failed': 0, 'errors': 0},
               'static_files': 75,
               'source_stability': {'source_count': receipt['source_count'], 'source_unchanged': not receipt['changed_sources'],
                                    'runtime_unchanged': receipt['runtime_unchanged'], 'frozen_tree_matches_before_after': not receipt['source_mismatches_after']},
               'prior_archive': {'name': prior.name, **digest(prior)},
               'prior_qualification_sha256': digest(AUDIT / 'latest-main/post-main-qualification.json')['sha256'],
               'final_publication_source_manifest': {'path': 'final-publication-sources.json',
                                                     'input_count': 5257, **digest(publication_manifest)},
               'scope': 'The only product changes are two native Mail widget-building methods. All other executable inputs, including stronger session/image/bulk guards and Word source/tests, are unchanged. The95 outcomes replace prior results; incomplete and isolated diagnostics are excluded.'}
    assert summary['combined'] == prior_qualification['combined']
    (OUT / 'qualification.json').write_text(json.dumps(summary, indent=2) + '\n')
    (OUT / 'independent-recount.json').write_text(json.dumps(result, indent=2) + '\n')
    files = {}
    for path in sorted(OUT.glob('*.json*')):
        if path.name not in {'evidence-index.json', 'evidence-integrity.json'}: files[path.name] = path
    files['mail-final-hosts.stderr'] = OUT / 'mail-final-hosts.stderr'
    files['final-publication-sources.json'] = publication_manifest
    for path in sorted((OUT / 'initial-incomplete').iterdir()):
        if path.is_file(): files['diagnostic/initial-incomplete/' + path.name] = path
    for suffix in ['.jsonl', '.stderr', '-receipt.json', '-sources.json']:
        path = AUDIT / ('freshness-tail-isolated' + suffix)
        if path.is_file(): files['diagnostic/isolated/' + path.name] = path
    for path in sorted(static_dir.iterdir()):
        if path.is_file(): files['static/' + path.name] = path
    for name in ['qualify_freshness_tail.py', 'run_freshness_tail_validation.py',
                 'run_frozen_mail_validation.py', 'check_post_main_source_applicability.py']:
        files['reproduce/' + name] = AUDIT / name
    files['reproduce/audit_results.py'] = ROOT / 'docs/validation/zotero-vertical-tables-20261120/audit_results.py'
    archive = OUT / 'freshness-tail-evidence.tar.gz'
    with archive.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
        for name, path in sorted(files.items()):
            info = tar.gettarinfo(str(path), arcname=name)
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            info.mode = 0o644
            with path.open('rb') as f: tar.addfile(info, f)
    with tarfile.open(archive, 'r:gz') as tar:
        assert set(tar.getnames()) == set(files)
        for name, path in files.items(): assert tar.extractfile(name).read() == path.read_bytes(), name
    index = {'archive': archive.name, **digest(archive), 'member_count': len(files),
             'all_member_bytes_verified_after_tar': True,
             'files': {name: digest(path) for name, path in sorted(files.items())}}
    (OUT / 'evidence-index.json').write_text(json.dumps(index, indent=2) + '\n')
    integrity = {'archive': digest(archive), 'index': digest(OUT / 'evidence-index.json'),
                 'members_verified': len(files), 'replacement_passes': 95, 'combined_passed': 3644, 'combined_skipped': 8}
    (OUT / 'evidence-integrity.json').write_text(json.dumps(integrity, indent=2) + '\n')
    print(json.dumps(integrity, indent=2))


if __name__ == '__main__':
    main('--source-only' in sys.argv)
