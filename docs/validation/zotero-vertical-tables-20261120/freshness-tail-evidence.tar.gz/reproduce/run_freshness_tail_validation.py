"""Replace the three directly affected Mail suite outcomes after final intake."""

from pathlib import Path

import run_frozen_mail_validation as runner


runner.OUT = Path('/workspace/scratch/37104639dddb/intake-audit/freshness-tail')
runner.OUT.mkdir(parents=True, exist_ok=True)
runner.COHORTS['hosts']['command'] = [
    'timeout', '90s',
    str(runner.DART), str(runner.FLUTTER / 'bin/cache/flutter_tools.snapshot'),
    'test', '--no-pub', '--concurrency=1', '--reporter=json',
    'test/studio_mail_accounts_test.dart',
    'test/studio_mail_workspace_test.dart',
    'test/studio_mail_bulk_visual_test.dart',
]


if __name__ == '__main__':
    runner.main()
