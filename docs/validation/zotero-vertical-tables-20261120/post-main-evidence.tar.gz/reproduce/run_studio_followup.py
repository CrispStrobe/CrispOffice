import hashlib, importlib.util, json, os, subprocess, time
from pathlib import Path
root=Path('/workspace/scratch/37104639dddb/quds_office_suite')
module_path=root/'docs/validation/zotero-vertical-tables-20261120/run_acceptance.py'
import sys
sys.path.insert(0,str(module_path.parent))
spec=importlib.util.spec_from_file_location('acceptance',module_path)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
output=root.parent/'zotero-runtime/latest-main-studio';output.mkdir(exist_ok=True)
expected='fe2c57604c33c1ee5ef1e9f25121e99d66c74d9a'
assert m.git('rev-parse','HEAD')==expected
sdk=Path(os.environ['FLUTTER_ROOT']);dart=sdk/'bin/cache/dart-sdk/bin/dart'
command=[str(dart),str(sdk/'bin/cache/flutter_tools.snapshot'),'test','--no-pub','--reporter=json','--concurrency=1','example/test/studio_comment_draft_proofing_test.dart','example/test/studio_word_chrome_settle_test.dart']
cwd=root/'packages/quds_office_editor';before=m.sources();m.write(output/'studio-sources-before.json',before)
start=time.monotonic()
with (output/'studio.jsonl').open('w') as stdout,(output/'studio.stderr').open('w') as stderr:
 result=subprocess.run(command,cwd=cwd,stdout=stdout,stderr=stderr)
after=m.sources();m.write(output/'studio-sources-after.json',after)
receipt={'head':expected,'tree':m.git('rev-parse','HEAD^{tree}'),'command':command,'cwd':str(cwd),'exit_code':result.returncode,'seconds':round(time.monotonic()-start,3),'source_count':len(before),'source_stable':before==after,'source_manifest_sha256':m.sha256(output/'studio-sources-before.json'),'log_sha256':m.sha256(output/'studio.jsonl'),'stderr_sha256':m.sha256(output/'studio.stderr'),'runner_sha256':m.sha256(Path(__file__)),'already_counted_in_editor_population':True}
try:receipt['acceptance']=m.count(output/'studio.jsonl')
except Exception as error:receipt['audit_error']=str(error)
m.write(output/'studio-receipt.json',receipt)
print(json.dumps(receipt,indent=2))
assert result.returncode==0 and before==after and receipt['acceptance']['passed']==16 and receipt['acceptance']['skipped']==0
