"""Run the final expanded host cohort without overwriting earlier evidence.

Usage: python run_latest_mail_validation.py <frozen-sha> hosts
"""

from pathlib import Path

import run_frozen_mail_validation as runner


runner.OUT = Path('/workspace/scratch/37104639dddb/intake-audit/latest-main')
runner.OUT.mkdir(parents=True, exist_ok=True)
runner.HOST_FILES.extend([
    'test/studio_mail_autoconnect_test.dart',
    'test/studio_mail_remote_images_test.dart',
    'test/studio_mail_accounts_test.dart',
    'test/studio_mail_credential_backend_switch_test.dart',
])
runner.COHORTS['hosts']['command'] = [
    str(runner.DART), str(runner.FLUTTER / 'bin/cache/flutter_tools.snapshot'),
    'test', '--no-pub', '--concurrency=1', '--reporter=json',
    *runner.HOST_FILES,
]


if __name__ == '__main__':
    runner.main()
