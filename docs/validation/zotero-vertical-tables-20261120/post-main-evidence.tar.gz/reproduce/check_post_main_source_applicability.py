"""Bind retained Word and Mail qualification to one later source commit.

The two StudioShell suites require a fresh run because their compiled closure
contains Mail. They replace their original 16 outcomes; they are not extra tests.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


ROOT = Path('/workspace/scratch/37104639dddb/quds_office_suite')
OUT = Path('/workspace/scratch/37104639dddb/intake-audit')
WORD_BASE = '520d0ca8870c6a169e23603660f2cde96366f9b2'
CORE_BASE = 'e8edb90a2948af60f41e50795c049a0a4d1ed3e6'
TRANSPORT_BASE = '38dcd802ae79e22d9f84ad79db1a197c43f3ad70'
WORD_LOGS = OUT.parent / 'zotero-runtime/final-source-acceptance'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).splitlines()


def tree(sha):
    result = {}
    for line in git('ls-tree', '-r', sha):
        header, path = line.split('\t', 1)
        mode, kind, oid = header.split()
        result[path] = {'mode': mode, 'kind': kind, 'blob': oid}
    return result


def file_bytes(path):
    file = ROOT / path
    return os.readlink(file).encode() if file.is_symlink() else file.read_bytes()


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def mail_path(path):
    return (
        path.startswith('packages/quds_mail_')
        or path.startswith('packages/quds_office_editor/example/')
        and Path(path).name.startswith('studio_mail_')
        or path.startswith('packages/quds_office_editor/example/test/support/mail_')
    )


def word_input(path):
    return (
        path.startswith(('packages/', 'third_party/')) and not path.endswith('.md')
        or path in {'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', 'dart_test.yaml'}
        or path in {
            'docs/validation/zotero-vertical-tables-20261120/run_acceptance.py',
            'docs/validation/zotero-vertical-tables-20261120/audit_results.py',
        }
    ) and not mail_path(path)


def compare(base, target, current_paths, selected):
    paths = sorted(p for p in base.keys() | target.keys() | current_paths if selected(p))
    mismatches = []
    manifest = {}
    for path in paths:
        if base.get(path) != target.get(path):
            mismatches.append({'path': path, 'reason': 'committed entry differs',
                               'before': base.get(path), 'after': target.get(path)})
            continue
        if path not in base:
            mismatches.append({'path': path, 'reason': 'untracked executable input'})
            continue
        file = ROOT / path
        if not file.is_file() and not file.is_symlink():
            mismatches.append({'path': path, 'reason': 'missing working input'})
            continue
        data = file_bytes(path)
        blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        mode = '120000' if file.is_symlink() else '100755' if file.stat().st_mode & 0o111 else '100644'
        manifest[path] = dict(base[path], sha256=hashlib.sha256(data).hexdigest())
        if blob != base[path]['blob'] or mode != base[path]['mode']:
            mismatches.append({'path': path, 'reason': 'working bytes/mode differ'})
    return {'path_count': len(paths), 'mismatches': mismatches,
            'source_identical': not mismatches, 'source_manifest': manifest}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('target')
    parser.add_argument('--output', type=Path, default=OUT / 'post-main-source-applicability.json')
    args = parser.parse_args()
    target_sha = git('rev-parse', args.target)[0]
    target = tree(target_sha)
    word = tree(WORD_BASE)
    paths = set(git('ls-files')) | set(git('ls-files', '--others', '--exclude-standard'))
    word_proof = compare(word, target, paths, word_input)
    original_sources = json.loads((WORD_LOGS / 'editor-sources-before.json').read_text())
    original_mismatches = []
    for path, expected in original_sources.items():
        if path != '.dart_tool/package_config.json' and not word_input(path):
            continue
        file = ROOT / path
        if not file.is_file() or sha256(file) != expected:
            original_mismatches.append(path)
    word_proof['recorded_runtime_source_mismatches'] = original_mismatches
    word_proof['source_identical'] &= not original_mismatches
    word_proof['qualified_head'] = WORD_BASE
    word_proof['retained_counts'] = {'engine_passed': 823, 'incoming_word_passed': 974,
                                    'editor_passed': 582, 'editor_skipped': 8}
    word_proof['fresh_studio_cases_replace_original_results'] = [
        {'path': 'packages/quds_office_editor/example/test/studio_comment_draft_proofing_test.dart', 'passed': 15},
        {'path': 'packages/quds_office_editor/example/test/studio_word_chrome_settle_test.dart', 'passed': 1},
    ]
    word_proof['baseline_receipts'] = {
        name: {'path': str(WORD_LOGS / (name + '-receipt.json')),
               'sha256': sha256(WORD_LOGS / (name + '-receipt.json'))}
        for name in ['engine', 'editor', 'incoming']
    }
    configs = {'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
               'packages/quds_mail_core/pubspec.yaml', 'packages/quds_mail_mime/pubspec.yaml',
               'packages/quds_mail_store/pubspec.yaml', 'third_party/enough_mail/pubspec.yaml'}
    mail = {}
    definitions = {
        'core': (CORE_BASE, 219, 'mail-final-core-receipt.json',
                 ('packages/quds_mail_core/', 'packages/quds_mail_mime/lib/')),
        'transport': (TRANSPORT_BASE, 415, 'mail-transport-accepted-receipt.json',
                      ('packages/quds_mail_transport/', 'packages/quds_mail_core/lib/',
                       'packages/quds_mail_mime/lib/', 'packages/quds_mail_store/lib/',
                       'third_party/enough_mail/lib/')),
    }
    for name, (base, count, receipt, prefixes) in definitions.items():
        proof = compare(tree(base), target, paths,
                        lambda p: p.startswith(prefixes) or p in configs)
        proof.update(qualified_head=base, passed=count,
                     receipt_path=str(OUT / receipt), receipt_sha256=sha256(OUT / receipt))
        mail[name] = proof
    ui_receipt_path = OUT.parent / 'zotero-runtime/mail-reader-full-ui-final-receipt.json'
    ui_receipt = json.loads(ui_receipt_path.read_text())
    ui_sources = ui_receipt['sources_before']
    ui_mismatches = []
    for path, expected in ui_sources.items():
        file = ROOT / path
        if not file.is_file() or sha256(file) != expected:
            ui_mismatches.append({'path': path, 'reason': 'captured input differs'})
            continue
        data = file_bytes(path)
        blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        if target.get(path, {}).get('blob') != blob:
            ui_mismatches.append({'path': path, 'reason': 'captured input is not target blob'})
    ui_additions = sorted(p for p in paths | target.keys()
                          if p.startswith(('packages/quds_mail_ui/', 'packages/quds_mail_core/'))
                          and not p.endswith('.md') and p not in ui_sources)
    ui_transitive = compare(tree(ui_receipt['head']), target, paths,
                            lambda p: p.startswith(('packages/quds_mail_mime/lib/',
                                                     'third_party/enough_mail/lib/'))
                            or p in configs)
    ui_ok = bool(ui_receipt['exit_code'] == 0 and ui_receipt['source_stable']
                 and ui_receipt['sources_before'] == ui_receipt['sources_after']
                 and ui_receipt['acceptance']['passed'] == 179
                 and ui_receipt['acceptance']['done_success']
                 and not any(ui_receipt['acceptance'][p] for p in ['skipped', 'failed', 'errors'])
                 and not ui_mismatches and not ui_additions and ui_transitive['source_identical'])
    mail['shared_ui'] = {
        'qualified_head': ui_receipt['head'], 'passed': 179,
        'receipt_path': str(ui_receipt_path), 'receipt_sha256': sha256(ui_receipt_path),
        'path_count': len(ui_sources), 'source_manifest': ui_sources,
        'mismatches': ui_mismatches, 'added_inputs': ui_additions,
        'source_identical': ui_ok, 'transitive_source_binding': ui_transitive,
        'note': ('Reader/core/UI/example inputs were captured before and after the179-case run. '
                 'MIME and vendored enough_mail inputs are separately bound by unchanged Git '
                 'blobs plus current working bytes; dependency resolution is bound below.'),
    }
    prior = json.loads((OUT / 'mail-isolated-environment.json').read_text())
    package_config = sha256(ROOT / '.dart_tool/package_config.json')
    changed = []
    for path in sorted(word.keys() | target.keys() | paths):
        if not mail_path(path):
            continue
        file = ROOT / path
        working_blob = None
        if file.is_file() or file.is_symlink():
            data = file_bytes(path)
            working_blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        if word.get(path) != target.get(path) or working_blob != word.get(path, {}).get('blob'):
            changed.append({'path': path, 'baseline': word.get(path), 'target': target.get(path),
                            'working_blob': working_blob})
    result = {
        'target_head': target_sha, 'observed_head': git('rev-parse', 'HEAD')[0],
        'target_tree': git('rev-parse', target_sha + '^{tree}')[0],
        'word': word_proof, 'mail': mail,
        'package_config_sha256': package_config,
        'mail_package_config_matches_qualified_baseline': package_config == prior['package_config_sha256'],
        'mail_changes_requiring_separate_qualification': changed,
        'note': ('This proves retained source applicability. The two StudioShell suites compile Mail; '
                 'their fresh 16 outcomes replace the original 16 within editor598. Latest shared UI '
                 'and host/image/auto-connect tests require separately source-bound acceptance. '
                 'Earlier focused and diagnostic runs are excluded from acceptance totals.'),
    }
    result['retained_source_binding_passed'] = bool(
        word_proof['source_identical'] and all(v['source_identical'] for v in mail.values())
        and result['mail_package_config_matches_qualified_baseline']
    )
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({
        'target_head': target_sha, 'retained_source_binding_passed': result['retained_source_binding_passed'],
        'word_path_count': word_proof['path_count'], 'word_mismatches': word_proof['mismatches'],
        'recorded_word_runtime_mismatches': original_mismatches,
        'mail': {k: {f: v[f] for f in ['passed', 'path_count', 'mismatches']} for k, v in mail.items()},
        'changed_mail_paths': [v['path'] for v in changed],
    }, indent=2))
    raise SystemExit(0 if result['retained_source_binding_passed'] else 1)


if __name__ == '__main__':
    main()
