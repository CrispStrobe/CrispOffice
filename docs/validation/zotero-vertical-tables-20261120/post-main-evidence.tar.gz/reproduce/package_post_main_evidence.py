"""Recount and package latest-main Mail qualification and the Word source bridge.

Earlier acceptance archives remain separate, identified by their exact hashes.
Focused development runs and replaced older outcomes never increase totals.
"""

import argparse
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import tarfile


ROOT = Path('/workspace/scratch/37104639dddb/quds_office_suite')
AUDIT = ROOT.parent / 'intake-audit'
RUNTIME = ROOT.parent / 'zotero-runtime'
OUT = AUDIT / 'latest-main'


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    data = Path(path).read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def suites(log, package=None):
    rows = [json.loads(line) for line in Path(log).read_text().splitlines() if line.strip().startswith('{')]
    paths = {e['suite']['id']: e['suite']['path'] for e in rows if e.get('type') == 'suite'}
    tests = {e['test']['id']: e['test'] for e in rows if e.get('type') == 'testStart'}
    counts = Counter()
    names = []
    for row in rows:
        if row.get('type') != 'testDone' or row.get('hidden') or row.get('skipped') or row['result'] != 'success':
            continue
        test = tests[row['testID']]
        if test['name'].endswith(('(setUpAll)', '(tearDownAll)')):
            continue
        recorded_path = paths[test['suiteID']]
        if '/packages/' in recorded_path:
            path = 'packages/' + recorded_path.split('/packages/', 1)[1]
        else:
            assert package is not None, recorded_path
            path = str(Path(package) / recorded_path)
        counts[path] += 1
        names.append((path, test['name']))
    assert len(names) == len(set(names)), 'Duplicated test identity in one cohort'
    return dict(sorted(counts.items())), names


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--studio-prefix', type=Path, required=True,
                        help='Prefix for the root-owned16-case Studio .jsonl/.stderr/-receipt files')
    parser.add_argument('--static-dir', type=Path, required=True)
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    spec = importlib.util.spec_from_file_location('audit_results', ROOT / 'docs/validation/zotero-vertical-tables-20261120/audit_results.py')
    auditor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(auditor)
    applicability = read(AUDIT / 'post-main-source-applicability.json')
    hosts = read(OUT / 'mail-final-hosts-receipt.json')
    ui = read(RUNTIME / 'mail-reader-full-ui-final-receipt.json')
    core = read(AUDIT / 'mail-final-core-receipt.json')
    transport = read(AUDIT / 'mail-transport-accepted-receipt.json')
    static = read(args.static_dir / 'receipt.json')
    studio = read(Path(str(args.studio_prefix) + '-receipt.json'))
    host_log = OUT / 'mail-final-hosts.jsonl'
    ui_log = RUNTIME / 'mail-reader-full-ui-final.jsonl'
    studio_log = Path(str(args.studio_prefix) + '.jsonl')
    recount = {
        'core': auditor.count(AUDIT / 'mail-final-core.jsonl'),
        'transport': auditor.count(AUDIT / 'mail-transport-accepted.jsonl'),
        'shared_ui': auditor.count(ui_log),
        'hosts': auditor.count(host_log),
        'studio': auditor.count(studio_log),
    }
    expected = {'core': 219, 'transport': 415, 'shared_ui': 179, 'hosts': 436, 'studio': 16}
    for name, value in expected.items():
        assert recount[name]['passed'] == value, (name, recount[name])
        assert not any(recount[name][p] for p in ['skipped', 'failed', 'errors'])
    assert hosts['accepted'] and hosts['frozen_head'] == applicability['target_head']
    assert applicability['retained_source_binding_passed']
    assert core['accepted'] and transport['exit_code'] == 0 and ui['exit_code'] == 0
    assert ui['source_stable'] and ui['acceptance'] == recount['shared_ui']
    assert ui['log_sha256'] == digest(ui_log)['sha256']
    assert ui['stderr_sha256'] == digest(ui_log.with_suffix('.stderr'))['sha256']
    assert hosts['runtime_after'] == core['runtime_after']
    assert studio['head'] == hosts['frozen_head'] and studio['exit_code'] == 0
    assert studio['source_stable'] and studio['already_counted_in_editor_population']
    assert studio['acceptance'] == recount['studio']
    assert studio['log_sha256'] == digest(studio_log)['sha256']
    assert studio['stderr_sha256'] == digest(studio_log.with_suffix('.stderr'))['sha256']
    studio_before = Path(str(args.studio_prefix) + '-sources-before.json')
    studio_after = Path(str(args.studio_prefix) + '-sources-after.json')
    assert studio_before.read_bytes() == studio_after.read_bytes()
    assert studio['source_manifest_sha256'] == digest(studio_before)['sha256']
    assert static['frozenHead'] == static['headAfter'] == hosts['frozen_head']
    assert static['sourceStable'] and not static['changedDuringVerification']
    assert static['fileCount'] == 74
    static_before = read(args.static_dir / 'source-before.json')
    static_after = read(args.static_dir / 'source-after.json')
    assert static_before['files'] == static_after['files']
    for name, result in static['results'].items():
        assert result['exitCode'] == 0, (name, result)
        assert result['logSha256'] == digest(args.static_dir / (name + '.log'))['sha256']
    host_suites, host_names = suites(host_log)
    ui_suites, ui_names = suites(ui_log)
    core_suites, core_names = suites(AUDIT / 'mail-final-core.jsonl', 'packages/quds_mail_core')
    transport_suites, transport_names = suites(AUDIT / 'mail-transport-accepted.jsonl', 'packages/quds_mail_transport')
    studio_suites, studio_names = suites(studio_log)
    all_mail_names = core_names + transport_names + ui_names + host_names
    assert len(all_mail_names) == 1249 and len(set(all_mail_names)) == 1249
    assert set(host_suites).isdisjoint(ui_suites)
    assert set(host_suites).isdisjoint(studio_suites)
    imports = {}
    for path in host_suites:
        targets = re.findall(r"import\s+['\"]([^'\"]+_test\.dart)['\"]", (ROOT / path).read_text())
        other_tests = [p for p in targets if not p.startswith('package:flutter_test/')]
        imports[path] = other_tests
        assert not other_tests, (path, other_tests)
    physical_base = 'packages/quds_office_editor/example/test/'
    host_expected = {
        'studio_mail_workspace_test.dart': 60, 'studio_mail_ews_test.dart': 77,
        'studio_mail_bulk_provider_test.dart': 39, 'studio_mail_cached_mail_test.dart': 32,
        'studio_mail_message_loader_test.dart': 95, 'studio_mail_cloud_test.dart': 59,
        'studio_mail_bulk_visual_test.dart': 13, 'studio_mail_autoconnect_test.dart': 14,
        'studio_mail_remote_images_test.dart': 18, 'studio_mail_accounts_test.dart': 22,
        'studio_mail_credential_backend_switch_test.dart': 7,
    }
    assert host_suites == {physical_base + k: v for k, v in host_expected.items()}
    assert sum(studio_suites.values()) == 16
    retained_archives = {
        'local-validation.tar.gz': ROOT.parent / 'zotero-final-evidence/local-validation.tar.gz',
        'mail-final-evidence.tar.gz': AUDIT / 'mail-final-evidence.tar.gz',
    }
    summary = {
        'frozen_head': hosts['frozen_head'],
        'tree': read(OUT / 'mail-final-hosts-preflight.json')['tree'],
        'mail': {'passed': 1249, 'skipped': 0, 'failed': 0, 'errors': 0,
                 'cohorts': {
                     'core': {'passed': 219, 'qualified_head': core['frozen_head'], 'retained': True, 'suites': core_suites},
                     'transport': {'passed': 415, 'qualified_head': applicability['mail']['transport']['qualified_head'], 'retained': True, 'suites': transport_suites},
                     'shared_ui': {'passed': 179, 'captured_at_head': ui['head'], 'bound_to_final_source': True, 'suites': ui_suites},
                     'hosts': {'passed': 436, 'qualified_head': hosts['frozen_head'], 'suites': host_suites},
                 }},
        'word': {'passed': 2395, 'skipped': 8, 'failed': 0,
                 'retained_at_520': {'engine': 823, 'incoming_word': 974, 'editor': 582, 'skipped_editor': 8},
                 'fresh_studio_replacement': {'passed': 16, 'suites': studio_suites},
                 'final_editor_total': 598},
        'combined': {'passed': 3644, 'skipped': 8, 'failed': 0, 'errors': 0},
        'source_stability': {'host_input_count': hosts['source_count'],
                             'host_sources_unchanged': not hosts['changed_sources'],
                             'host_runtime_unchanged': hosts['runtime_unchanged'],
                             'runtime_matches_retained_core': hosts['runtime_after'] == core['runtime_after'],
                             'word_protected_inputs': applicability['word']['path_count'],
                             'retained_source_binding_passed': True},
        'test_file_import_audit': imports,
        'retained_evidence_archives': {name: digest(path) for name, path in retained_archives.items()},
        'count_policy': ('Each test identity is counted once. The fresh16 Studio cases replace16 cases inside the '
                         'original598 editor population. Earlier UI164, host375, auto14/focused43, and remote18 '
                         'development runs are not added again. Core219 and transport415 retain exact-input '
                         'qualification; their full original logs remain in the separate Mail evidence archive.'),
        'scope': ('Real local Dart/Flutter runtime with locked dependencies and controlled providers. '
                  'No installed Zotero/Word/LibreOffice, live mail account, actual send, or GitHub Actions result is claimed.'),
    }
    (OUT / 'post-main-qualification.json').write_text(json.dumps(summary, indent=2) + '\n')
    (OUT / 'independent-recount.json').write_text(json.dumps(recount, indent=2) + '\n')
    files = {}
    def add(path, name):
        path = Path(path)
        assert path.is_file(), path
        assert name not in files, name
        files[name] = path
    for path in sorted(OUT.glob('mail-final-hosts*')):
        add(path, 'acceptance/hosts/' + path.name)
    for suffix in ['.jsonl', '.stderr', '-receipt.json']:
        add(RUNTIME / ('mail-reader-full-ui-final' + suffix), 'acceptance/shared-ui/mail-reader-full-ui-final' + suffix)
    for path in sorted(args.studio_prefix.parent.glob(args.studio_prefix.name + '*')):
        if path.is_file(): add(path, 'acceptance/studio/' + path.name)
    for path in sorted(args.static_dir.iterdir()):
        if path.is_file(): add(path, 'static/' + path.name)
    for name in ['post-main-qualification.json', 'independent-recount.json']:
        add(OUT / name, name)
    add(AUDIT / 'post-main-source-applicability.json', 'applicability/post-main-source-applicability.json')
    add(RUNTIME / 'mail-reader-full-ui-fe2-binding.json', 'applicability/mail-reader-full-ui-fe2-binding.json')
    for name in ['mail-final-core-receipt.json', 'mail-transport-accepted-receipt.json',
                 'mail-isolated-environment.json']:
        add(AUDIT / name, 'retained/' + name)
    for name in ['engine', 'editor', 'incoming']:
        add(RUNTIME / ('final-source-acceptance/' + name + '-receipt.json'), 'retained/word-' + name + '-receipt.json')
    for name in ['run_latest_mail_validation.py', 'run_frozen_mail_validation.py',
                 'check_post_main_source_applicability.py', 'package_post_main_evidence.py']:
        add(AUDIT / name, 'reproduce/' + name)
    add(ROOT / 'docs/validation/zotero-vertical-tables-20261120/audit_results.py', 'reproduce/audit_results.py')
    add(RUNTIME / 'verify_frozen_dart.py', 'reproduce/verify_frozen_dart.py')
    add(RUNTIME / 'run_studio_followup.py', 'reproduce/run_studio_followup.py')
    for name in ['native-autoconnect-account-regressions', 'native-autoconnect-final-development']:
        for suffix in ['.jsonl', '.stderr', '-receipt.json', '-sources.json']:
            add(AUDIT / (name + suffix), 'development/' + name + suffix)
    for path in sorted(RUNTIME.glob('remote-image-acquisition-final*')):
        if path.is_file(): add(path, 'development/remote-images/' + path.name)
    add(RUNTIME / 'mail-reader-analysis-final.log', 'development/shared-ui-analysis.log')
    archive = OUT / 'post-main-evidence.tar.gz'
    with archive.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
        for name, path in sorted(files.items()):
            info = tar.gettarinfo(str(path), arcname=name)
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            info.mode = 0o644
            with path.open('rb') as stream: tar.addfile(info, stream)
    index = {'archive': archive.name, **digest(archive), 'member_count': len(files),
             'files': {name: digest(path) for name, path in sorted(files.items())}}
    with tarfile.open(archive, 'r:gz') as tar:
        assert set(tar.getnames()) == set(files)
        for name, path in files.items():
            assert tar.extractfile(name).read() == path.read_bytes(), name
    index['all_member_bytes_verified_after_tar'] = True
    index_path = OUT / 'post-main-evidence-index.json'
    index_path.write_text(json.dumps(index, indent=2) + '\n')
    integrity = {'archive': digest(archive), 'index': digest(index_path),
                 'members_verified': len(files), 'mail_passed': 1249,
                 'word_passed': 2395, 'combined_passed': 3644, 'skipped': 8}
    (OUT / 'post-main-evidence-integrity.json').write_text(json.dumps(integrity, indent=2) + '\n')
    print(json.dumps(integrity, indent=2))


if __name__ == '__main__':
    main()
