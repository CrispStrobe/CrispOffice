"""Run one final Mail cohort against a supplied frozen source commit."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


ROOT = Path('/workspace/scratch/37104639dddb/quds_office_suite')
OUT = Path('/workspace/scratch/37104639dddb/intake-audit')
FLUTTER = Path('/home/agent/.codex/skills/remote-skills/quds-mail-work-20261120/runtime/flutter')
PUB_CACHE = FLUTTER.parent / 'pub-cache'
DART = FLUTTER / 'bin/cache/dart-sdk/bin/dart'
HOST_FILES = [
    'test/studio_mail_workspace_test.dart',
    'test/studio_mail_ews_test.dart',
    'test/studio_mail_bulk_provider_test.dart',
    'test/studio_mail_cached_mail_test.dart',
    'test/studio_mail_message_loader_test.dart',
    'test/studio_mail_cloud_test.dart',
    'test/studio_mail_bulk_visual_test.dart',
]
COHORTS = {
    'core': {
        'cwd': ROOT / 'packages/quds_mail_core',
        'command': [
            str(DART),
            '--packages=' + str(ROOT / '.dart_tool/package_config.json'),
            str(PUB_CACHE / 'hosted/pub.dev/test-1.31.1/bin/test.dart'),
            '--concurrency=1', '--reporter=json',
        ],
    },
    'hosts': {
        'cwd': ROOT / 'packages/quds_office_editor/example',
        'command': [
            str(DART), str(FLUTTER / 'bin/cache/flutter_tools.snapshot'),
            'test', '--no-pub', '--concurrency=1', '--reporter=json',
            *HOST_FILES,
        ],
    },
}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).splitlines()


def selected(path):
    p = Path(path)
    return (
        p.suffix in {'.dart', '.yaml', '.yml', '.lock'}
        or path.startswith((
            'packages/quds_office_editor/fonts/',
            'packages/quds_office_editor/example/fonts/',
            'packages/quds_office_editor/example/assets/',
        ))
        or (path.startswith('packages/quds_mail_') and '/test/fixtures/' in path)
    )


def source_manifest():
    paths = set(git('ls-files')) | set(git('ls-files', '--others', '--exclude-standard'))
    paths = {p for p in paths if selected(p) and (ROOT / p).is_file()}
    paths.update({'.dart_tool/package_config.json', '.dart_tool/native_assets.yaml'})
    return {
        p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest()
        for p in sorted(paths) if (ROOT / p).is_file()
    }


def runtime_manifest():
    paths = [
        DART,
        FLUTTER / 'bin/cache/flutter_tools.snapshot',
        FLUTTER / 'bin/cache/artifacts/engine/linux-x64/flutter_tester',
        ROOT / '.dart_tool/lib/libsqlite3.so',
    ]
    return {
        str(p): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in paths if p.is_file()
    }


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def frozen_source_mismatches(sha, manifest):
    expected = {}
    for line in git('ls-tree', '-r', sha):
        header, path = line.split('\t', 1)
        mode, kind, oid = header.split()
        if selected(path):
            expected[path] = oid
    mismatches = []
    for path, oid in expected.items():
        p = ROOT / path
        if not p.is_file():
            mismatches.append({'path': path, 'reason': 'missing'})
            continue
        data = p.read_bytes()
        actual = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        if actual != oid:
            mismatches.append({'path': path, 'reason': 'different blob'})
    for path in manifest:
        if path not in expected and not path.startswith('.dart_tool/'):
            mismatches.append({'path': path, 'reason': 'not in frozen tree'})
    return mismatches


def main():
    sha, cohort = sys.argv[1:]
    plan = COHORTS[cohort]
    name = 'mail-final-' + cohort
    head = git('rev-parse', 'HEAD')[0]
    expected = git('rev-parse', sha)[0]
    if head != expected:
        raise SystemExit(f'Expected frozen HEAD {expected}, observed {head}.')
    if git('diff', '--name-only', '--diff-filter=U'):
        raise SystemExit('Unresolved merge files remain.')
    before = source_manifest()
    runtime_before = runtime_manifest()
    preflight = {
        'frozen_head': expected,
        'tree': git('rev-parse', expected + '^{tree}')[0],
        'head_before': head,
        'source_count': len(before),
        'source_mismatches': frozen_source_mismatches(expected, before),
        'runtime': runtime_before,
        'environment': {key: os.environ.get(key) for key in [
            'FLUTTER_ROOT', 'PUB_CACHE', 'TMPDIR', 'CI',
            'DART_SUPPRESS_ANALYTICS', 'FLUTTER_SUPPRESS_ANALYTICS',
        ]},
        'dart_version': subprocess.check_output([str(DART), '--version'], text=True).strip(),
        'command': plan['command'],
        'cwd': str(plan['cwd']),
        'github_actions': 'not queried or awaited',
    }
    write(name + '-preflight.json', preflight)
    write(name + '-sources-before.json', before)
    if preflight['source_mismatches']:
        raise SystemExit('The working source does not match the frozen commit.')
    started = time.time()
    with (OUT / (name + '.jsonl')).open('w') as stdout, (OUT / (name + '.stderr')).open('w') as stderr:
        result = subprocess.run(plan['command'], cwd=plan['cwd'], stdout=stdout, stderr=stderr)
    elapsed = time.time() - started
    after = source_manifest()
    runtime_after = runtime_manifest()
    write(name + '-sources-after.json', after)
    events = []
    non_json = []
    for line in (OUT / (name + '.jsonl')).read_text().splitlines():
        try:
            event = json.loads(line)
            if isinstance(event, dict):
                events.append(event)
            else:
                non_json.append(line)
        except ValueError:
            if line.strip():
                non_json.append(line)
    starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    all_finished = {e['testID']: e for e in events if e.get('type') == 'testDone'}
    finished = [e for e in all_finished.values() if not e.get('hidden')]
    errors = [e for e in events if e.get('type') == 'error']
    done = [e for e in events if e.get('type') == 'done']
    changed = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
    receipt = {
        'frozen_head': expected,
        'head_after': git('rev-parse', 'HEAD')[0],
        'command': plan['command'], 'cwd': str(plan['cwd']),
        'exit_code': result.returncode, 'seconds': round(elapsed, 3),
        'passed': sum(e.get('result') == 'success' and not e.get('skipped') for e in finished),
        'skipped': sum(bool(e.get('skipped')) for e in finished),
        'failed': sum(e.get('result') != 'success' and not e.get('skipped') for e in finished),
        'errors': len(errors), 'done': done,
        'unfinished': [starts[i] for i in starts.keys() - all_finished.keys()],
        'source_count': len(before), 'changed_sources': changed,
        'runtime_unchanged': runtime_before == runtime_after,
        'runtime_after': runtime_after,
        'non_json_lines': non_json,
        'source_mismatches_after': frozen_source_mismatches(expected, after),
        'tests': [dict(starts[e['testID']], result=e['result'], skipped=e.get('skipped', False)) for e in finished],
    }
    receipt['accepted'] = bool(
        result.returncode == 0 and done and done[-1].get('success')
        and not receipt['failed'] and not errors and not receipt['unfinished']
        and not changed and receipt['runtime_unchanged']
        and not receipt['source_mismatches_after']
    )
    write(name + '-receipt.json', receipt)
    print(json.dumps({k: v for k, v in receipt.items() if k not in {'tests', 'runtime_after', 'non_json_lines'}}, indent=2))
    raise SystemExit(0 if receipt['accepted'] else result.returncode or 1)


if __name__ == '__main__':
    main()
