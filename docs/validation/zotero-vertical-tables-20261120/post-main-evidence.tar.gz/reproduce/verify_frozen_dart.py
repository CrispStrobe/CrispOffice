#!/usr/bin/env python3
"""Record strict verification of the exact Dart diff at a frozen Git commit."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


parser = argparse.ArgumentParser()
parser.add_argument("--repo", type=Path, required=True)
parser.add_argument("--base", required=True)
parser.add_argument("--head", required=True)
parser.add_argument("--out", type=Path, required=True)
args = parser.parse_args()
repo = args.repo.resolve()
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)


def git(*arguments):
    return subprocess.check_output(["git", *arguments], cwd=repo)


base = git("rev-parse", args.base).decode().strip()
head = git("rev-parse", args.head).decode().strip()
actual_head = git("rev-parse", "HEAD").decode().strip()
if actual_head != head:
    raise SystemExit(f"Expected frozen HEAD {head}; found {actual_head}")
paths = sorted(
    path.decode()
    for path in git(
        "diff", "--name-only", "--diff-filter=ACMR", "-z", base, head,
        "--", "*.dart",
    ).split(b"\0")
    if path
)
if not paths:
    raise SystemExit("Frozen comparison contains no Dart files")
subprocess.run(
    ["git", "diff", "--quiet", head, "--", "*.dart"],
    cwd=repo,
    check=True,
)


def hashes():
    return {
        path: hashlib.sha256((repo / path).read_bytes()).hexdigest()
        for path in paths
    }


before = hashes()
manifest = {
    "base": base,
    "head": head,
    "tree": git("rev-parse", f"{head}^{{tree}}").decode().strip(),
    "files": before,
    "pubspecLockSha256": hashlib.sha256(
        (repo / "pubspec.lock").read_bytes()
    ).hexdigest(),
}
(out / "source-before.json").write_text(json.dumps(manifest, indent=2) + "\n")
(out / "dart-paths.txt").write_text("\n".join(paths) + "\n")
dart = Path(os.environ["FLUTTER_ROOT"]) / "bin/cache/dart-sdk/bin/dart"
commands = {
    "format": [str(dart), "format", "--output=none", "--set-exit-if-changed", *paths],
    "analysis": [str(dart), "analyze", "--fatal-warnings", "--fatal-infos", *paths],
}
results = {}
for name, command in commands.items():
    start = time.time()
    with (out / f"{name}.log").open("wb") as log:
        completed = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    results[name] = {
        "command": command,
        "exitCode": completed.returncode,
        "durationSeconds": round(time.time() - start, 3),
        "logSha256": hashlib.sha256((out / f"{name}.log").read_bytes()).hexdigest(),
    }
after = hashes()
changed = [path for path in paths if before[path] != after[path]]
(out / "source-after.json").write_text(
    json.dumps({"files": after}, indent=2) + "\n"
)
receipt = {
    "base": base,
    "frozenHead": head,
    "headAfter": git("rev-parse", "HEAD").decode().strip(),
    "dartVersion": subprocess.check_output([str(dart), "--version"], text=True).strip(),
    "fileCount": len(paths),
    "sourceStable": not changed,
    "changedDuringVerification": changed,
    "results": results,
}
(out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({
    "frozenHead": head,
    "fileCount": len(paths),
    "sourceStable": not changed,
    "formatExit": results["format"]["exitCode"],
    "analysisExit": results["analysis"]["exitCode"],
    "receipt": str(out / "receipt.json"),
}, indent=2))
raise SystemExit(int(bool(changed) or any(result["exitCode"] for result in results.values())))
