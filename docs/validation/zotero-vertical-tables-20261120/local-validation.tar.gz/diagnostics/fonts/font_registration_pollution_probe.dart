import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_editor/quds_office_editor.dart';

import '../quds_office_suite/packages/quds_office_editor/test/embed_test.dart'
    as original;

void main() {
  setUpAll(OfficeHostFonts.ensureRegistered);
  original.main();
}
