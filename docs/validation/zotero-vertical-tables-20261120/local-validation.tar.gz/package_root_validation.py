"""Archive source-specific root qualification and clearly excluded diagnostics."""

import collections
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

WORK = Path('/workspace/scratch/37104639dddb')
REPO = WORK / 'quds_office_suite'
RUNTIME = WORK / 'zotero-runtime'
AUDIT = WORK / 'intake-audit'
OUT = WORK / 'zotero-final-evidence'
CONTENT = OUT / 'content'
SOURCE = '520d0ca8870c6a169e23603660f2cde96366f9b2'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def diagnostic_count(path):
    events = []
    for line in path.read_text().splitlines():
        try:
            value = json.loads(line)
            if isinstance(value, dict):
                events.append(value)
        except ValueError:
            pass
    starts = {e['test']['id']: e['test'] for e in events if e.get('type') == 'testStart'}
    counts = collections.Counter()
    failures = []
    for e in events:
        if e.get('type') != 'testDone':
            continue
        name = starts[e['testID']]['name']
        if e.get('hidden') or name.startswith('loading ') or name.endswith(('(setUpAll)', '(tearDownAll)')):
            continue
        outcome = 'skipped' if e.get('skipped') else e['result']
        counts[outcome] += 1
        if outcome not in {'success', 'skipped'}:
            failures.append(name)
    return {
        'passed': counts['success'], 'skipped': counts['skipped'],
        'failed': counts['failure'] + counts['error'],
        'error_events': sum(e.get('type') == 'error' for e in events),
        'done': [e for e in events if e.get('type') == 'done'],
        'failure_names': failures,
        'counted_in_acceptance': False,
    }


def main():
    acceptance = RUNTIME / 'final-source-acceptance'
    for name in ['engine', 'editor', 'incoming']:
        receipt = json.loads((acceptance / (name + '-receipt.json')).read_text())
        assert receipt['head'] == SOURCE and receipt['exit_code'] == 0 and receipt['source_stable']
    OUT.mkdir(exist_ok=True)
    CONTENT.mkdir(exist_ok=True)
    files = {}

    def add(path, name):
        assert path.is_file(), path
        files[name] = path

    for name in ['engine', 'editor', 'incoming']:
        for suffix in ['.jsonl', '.stderr', '-receipt.json', '-sources-before.json', '-sources-after.json']:
            add(acceptance / (name + suffix), 'acceptance/' + name + suffix)
    for suffix in ['.jsonl', '.stderr', '-receipt.json', '-sources-before.json', '-sources-after.json']:
        add(RUNTIME / 'final-acceptance' / ('editor' + suffix), 'diagnostics/e8-editor/editor' + suffix)
    for stem in ['editor-vertical-navigation-initial', 'editor-vertical-navigation-fix']:
        for suffix in ['.jsonl', '.stderr']:
            add(RUNTIME / (stem + suffix), 'diagnostics/navigation/' + stem + suffix)
    for stem in ['engine-border-review', 'engine-border-final']:
        for suffix in ['.jsonl', '.stderr', '.exit', '-receipt.json', '-before.json', '-after.json']:
            add(RUNTIME / (stem + suffix), 'diagnostics/borders/' + stem + suffix)
    for suffix in ['.log', '.exit']:
        add(RUNTIME / ('engine-border-final-analyze' + suffix), 'diagnostics/borders/engine-border-final-analyze' + suffix)
    for stem in ['editor-font-isolated', 'editor-font-pollution']:
        for suffix in ['.jsonl', '.stderr', '.exit']:
            add(RUNTIME / (stem + suffix), 'diagnostics/fonts/' + stem + suffix)
    for name in ['editor-font-isolation-receipt.json', 'font_registration_pollution_probe.dart']:
        add(RUNTIME / name, 'diagnostics/fonts/' + name)
    for path in AUDIT.glob('parser-review*'):
        if path.is_file():
            add(path, 'development/parser-review/' + path.name)
    add(AUDIT / 'run_parser_review_validation.py', 'development/parser-review/run_parser_review_validation.py')
    for name in ['receipt.json', 'format.log', 'analysis.log', 'source-before.json', 'source-after.json', 'dart-paths.txt']:
        add(RUNTIME / 'frozen-dart-520d0ca8' / name, 'static/' + name)
    for name in ['verify_frozen_dart.py', 'harness-binding-520d0ca8.json', 'verify_harness_publication.py', 'acceptance-suite-review-520d0ca8.json']:
        add(RUNTIME / name, 'provenance/' + name)
    for name in ['runtime-ready.json', 'env.sh']:
        add(RUNTIME / name, 'runtime/' + name)
    add(Path(__file__), 'package_root_validation.py')

    for name, path in files.items():
        target = CONTENT / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    for name in ['audit_results.py', 'run_acceptance.py']:
        data = subprocess.check_output(['git', 'show', SOURCE + ':docs/validation/zotero-vertical-tables-20261120/' + name], cwd=REPO)
        (CONTENT / name).write_bytes(data)
    result = subprocess.run(['python3', str(CONTENT / 'audit_results.py'), str(CONTENT / 'acceptance')], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    recount = json.loads(result.stdout)
    assert recount['passed'] == 2395 and recount['skipped'] == 8 and recount['failed'] == 0
    assert {name: value['passed'] for name, value in recount['runs'].items()} == {'engine': 823, 'editor': 598, 'incoming': 974}
    (CONTENT / 'acceptance/independent-recount.json').write_text(result.stdout)

    diagnostics = {}
    for path in sorted((CONTENT / 'diagnostics').rglob('*.jsonl')):
        diagnostics[str(path.relative_to(CONTENT))] = diagnostic_count(path)
    assert diagnostics['diagnostics/e8-editor/editor.jsonl']['passed'] == 597
    assert diagnostics['diagnostics/e8-editor/editor.jsonl']['skipped'] == 8
    assert diagnostics['diagnostics/e8-editor/editor.jsonl']['failed'] == 1
    assert diagnostics['diagnostics/navigation/editor-vertical-navigation-initial.jsonl']['failed'] == 4
    assert diagnostics['diagnostics/borders/engine-border-review.jsonl']['failed'] == 8
    assert diagnostics['diagnostics/borders/engine-border-final.jsonl']['passed'] == 41
    assert diagnostics['diagnostics/fonts/editor-font-isolated.jsonl']['passed'] == 1
    assert diagnostics['diagnostics/fonts/editor-font-pollution.jsonl']['failed'] == 1
    (CONTENT / 'diagnostics/index.json').write_text(json.dumps(diagnostics, indent=2) + '\n')
    static = json.loads((CONTENT / 'static/receipt.json').read_text())
    assert static['frozenHead'] == SOURCE and static['fileCount'] == 66 and static['sourceStable']
    assert all(value['exitCode'] == 0 for value in static['results'].values())
    static_before = json.loads((CONTENT / 'static/source-before.json').read_text())
    static_after = json.loads((CONTENT / 'static/source-after.json').read_text())
    assert static_before['files'] == static_after['files']
    for kind, info in static['results'].items():
        assert digest((CONTENT / 'static' / (kind + '.log')).read_bytes()) == info['logSha256']
    policy = {
        'qualified_source': SOURCE,
        'qualified_tree': json.loads((CONTENT / 'acceptance/engine-receipt.json').read_text())['tree'],
        'acceptance': {'passed': 2395, 'skipped': 8, 'failed': 0, 'engine': 823, 'editor': 598, 'incoming': 974},
        'strict_static_files': 66,
        'diagnostics_and_development_excluded': True,
        'mail_evidence': 'Separate mail-final-evidence.tar.gz; not included in this archive or these totals.',
        'source_boundary': 'Qualification is bound to commit520d0ca8. Subsequent main integration requires separate applicability or acceptance evidence.',
        'github_actions': 'Not queried or awaited',
    }
    (CONTENT / 'evidence-policy.json').write_text(json.dumps(policy, indent=2) + '\n')
    members = sorted(p for p in CONTENT.rglob('*') if p.is_file())
    index = {'qualified_source': SOURCE, 'acceptance': policy['acceptance'], 'members': {str(p.relative_to(CONTENT)): {'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())} for p in members}}
    archive = OUT / 'local-validation.tar.gz'
    with archive.open('wb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w') as tar:
        for path in members:
            info = tar.gettarinfo(str(path), arcname=str(path.relative_to(CONTENT)))
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            info.mode = 0o644
            with path.open('rb') as f:
                tar.addfile(info, f)
    index['archive'] = {'name': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes())}
    with tarfile.open(archive, 'r:gz') as tar:
        assert len(tar.getmembers()) == len(index['members'])
        for member in tar.getmembers():
            data = tar.extractfile(member).read()
            assert len(data) == index['members'][member.name]['bytes']
            assert digest(data) == index['members'][member.name]['sha256']
    index['verified_member_count'] = len(members)
    index_path = OUT / 'local-validation-index.json'
    index_path.write_text(json.dumps(index, indent=2) + '\n')
    integrity = {'archive': index['archive'], 'index': {'name': index_path.name, 'bytes': index_path.stat().st_size, 'sha256': digest(index_path.read_bytes())}, 'member_bytes_verified': len(members), 'independent_recount': policy['acceptance']}
    (OUT / 'local-validation-integrity.json').write_text(json.dumps(integrity, indent=2) + '\n')
    print(json.dumps(integrity, indent=2))


if __name__ == '__main__':
    main()
