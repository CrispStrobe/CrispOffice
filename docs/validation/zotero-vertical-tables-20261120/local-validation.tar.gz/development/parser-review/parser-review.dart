import 'dart:convert';
import 'package:quds_office_engine/src/word/model/wml_document.dart';
import 'package:quds_office_engine/src/word/properties/wml_properties.dart';
import 'parser-review-copy.dart';
void main() {
  final cases = <String,String>{
    'adjacent_direct_rows': '<table><tr><td rowspan="2">Origin</td></tr><tr/></table>',
    'empty_tbody_between_direct_rows': '<table><tr><td rowspan="2">Origin</td></tr><tbody/><tr/></table>',
    'separate_nonempty_bodies': '<table><tbody><tr><td rowspan="2">Origin</td></tr></tbody><tbody><tr/></tbody></table>',
    'header_styles': '<table><tbody><tr><th rowspan="2"><p>Heading <span style="font-weight:normal">Normal</span></p></th><td>Top</td></tr><tr><td>Bottom</td></tr></tbody></table>',
  };
  for(final entry in cases.entries) {
    try {
      final note=WordZoteroNoteText.fromHtml(entry.value,baseProperties:WmlRunProps(asciiFont:'Georgia',color:'336699',italic:true));
      print(jsonEncode({'case':entry.key,'accepted':true,'text':note.plainText,'paragraphs':note.paragraphs.map((p)=>{'text':p.text,'runs':p.inlines.whereType<WmlRun>().map((r)=>{'text':r.text,'bold':r.properties.bold,'font':r.properties.asciiFont,'color':r.properties.color}).toList()}).toList()}));
    } catch(e) {
      print(jsonEncode({'case':entry.key,'accepted':false,'error':e.toString()}));
    }
  }
}
