# Independent parser review

## Finding and correction

A direct-row rowspan incorrectly crossed an empty explicit row group:

```html
<table><tr><td rowspan="2">Origin</td></tr><tbody/><tr/></table>
```

The parser previously keyed all direct rows by the same table element. Because an empty `tbody` contributes no rows to the occupancy grid, the cross-group check never observed it. The before reproducer accepted this input. The correction gives each contiguous run of direct rows a distinct identity and resets that identity whenever a `tbody` begins, including empty groups. Populated body groups retain their own element identities.

Two negative regression cases now refuse crossing one or multiple empty body groups. A positive case exercises repeated `tbody` / direct-row / `tbody` chains and separate direct-row chains on either side of an empty group. Empty groups themselves remain supported; only spans across their boundaries are refused.

## Validation

The exact current parser and table integration suites passed **151 tests**, with zero skips, failures, or errors, successful terminal completion, and exit code 0. The 355-path engine source/config/test manifest remained unchanged during the run. See `parser-review-final-receipt.json`, `parser-review-final-sources.json`, and `parser-review-final.jsonl`.

Scoped analysis of the parser and both table suites passed with `--fatal-infos`; the two modified files were formatted.

The initial before reproducer used the unchanged parser logic with imports redirected to already-qualified baseline dependencies while another agent edited layout. `parser-review-before.jsonl` records that diagnostic and is not part of accepted-suite totals. An initial suite invocation omitted the prescribed runtime environment and failed before tests when Dart tried a missing `/tmp`; that environment-only diagnostic is retained separately as `parser-review-env-failure-*`. The accepted run used the prescribed environment and actual runtime.

## Mail applicability

All **356** tracked Mail, Studio Mail, and Mail roadmap paths match qualification baseline `38dcd802ae79e22d9f84ad79db1a197c43f3ad70` byte for byte, with no missing, added, or untracked owned paths. `final-mail-source-comparison.json` records the comparison. The **1,153** accepted Mail tests were qualified at that pre-feature baseline. Later changes to transitive Word engine/layout/editor sources mean those totals must not be described as a new run against the final Zotero feature source; final combined acceptance is a separate cohort.
