import sys,os,subprocess,pathlib,hashlib,json,time
root=pathlib.Path('/workspace/scratch/37104639dddb/quds_office_suite')
out=pathlib.Path('/workspace/scratch/37104639dddb/intake-audit')
name=sys.argv[1]; cwd=root/sys.argv[2];command=sys.argv[3:]
def manifest():
 paths=set()
 for base in ['packages/quds_office_engine/lib']:
  paths.update(p for p in (root/base).rglob('*') if p.is_file() and (p.suffix in ['.dart','.yaml','.lock'] or p.name=='package_config.json') and not any(x in p.parts for x in ['build','.dart_tool','.git']))
 for base in ['pubspec.yaml','pubspec.lock','.dart_tool/package_config.json','packages/quds_office_engine/test/word_zotero_note_table_test.dart','packages/quds_office_engine/test/word_zotero_note_tables_integration_test.dart']:
  if (root/base).exists():paths.add(root/base)
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=manifest();(out/(name+'-sources.json')).write_text(json.dumps(before,indent=2)+'\n')
start=time.time()
with (out/(name+'.jsonl')).open('w') as so,(out/(name+'.stderr')).open('w') as se:
 result=subprocess.run(command,cwd=cwd,stdout=so,stderr=se)
after=manifest()
events=[]
for line in (out/(name+'.jsonl')).read_text().splitlines():
 try:events.append(json.loads(line))
 except:pass
finished=[x for x in events if x.get('type')=='testDone' and not x.get('hidden')]
errors=[x for x in events if x.get('type')=='error']
receipt={'command':command,'cwd':str(cwd),'exit_code':result.returncode,'seconds':round(time.time()-start,3),'passed':sum(x.get('result')=='success' and not x.get('skipped') for x in finished),'skipped':sum(bool(x.get('skipped')) for x in finished),'failed':sum(x.get('result')!='success' and not x.get('skipped') for x in finished),'errors':len(errors),'done':[x for x in events if x.get('type')=='done'],'source_count':len(before),'changed_sources':[p for p in before.keys()|after.keys() if before.get(p)!=after.get(p)]}
(out/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
sys.exit(result.returncode)
