"""Independent PR277 Mail raw-event recount and accepted-union review."""
from collections import Counter
import hashlib
import json
from pathlib import Path
from urllib.parse import unquote, urlparse

ROOT = Path('/workspace/scratch/03cd41fa0e7e')
RUNTIME = ROOT / 'runtime'
REPO = ROOT / 'quds_merge_final'
RUN = RUNTIME / 'mail-pr277-qualification'
ACCEPTED = RUNTIME / 'mail-pr277-accepted'
BASELINE = RUNTIME / 'mail-latest-accepted'
INDEPENDENT = RUNTIME / 'mail-pr277-independent-recount'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def key(c):
    return c['file'], c['name'], c['occurrence']


receipt = read(RUN / 'qualification.json')
assert receipt['status'] == 'passed' and receipt['source_head'] == '5c7b76a6137bc9373276ce2e7fccc6ed48903998'
fresh, portable, command_rows = [], [], []
for command in receipt['commands']:
    assert command['exit_code'] == 0
    for stream in ('stdout', 'stderr'):
        data = (RUN / command[stream]).read_bytes()
        assert sha(data) == command[stream + '_sha256']
        if stream == 'stderr':
            assert not data
    command_rows.append({'name': command['name'], 'exit_code': command['exit_code']})
    if command['expected_test_files'] is None:
        if command['name'].endswith('-analysis'):
            assert '--fatal-infos' in command['command']
        elif command['name'] == 'format':
            assert '--output=none' in command['command'] and '--set-exit-if-changed' in command['command']
        continue
    events = [json.loads(line) for line in (RUN / command['stdout']).read_text().splitlines()]
    suite_rows = [e['suite'] for e in events if e['type'] == 'suite']
    suites = {s['id']: s['path'] for s in suite_rows}
    assert len(suites) == len(suite_rows)
    start_rows = [e['test'] for e in events if e['type'] == 'testStart']
    starts = {s['id']: s for s in start_rows}
    assert len(starts) == len(start_rows)
    ends = [e for e in events if e['type'] == 'testDone']
    assert Counter(e['testID'] for e in ends) == Counter({i: 1 for i in starts})
    terminals = [e for e in events if e['type'] == 'done']
    assert len(terminals) == 1 and terminals[0]['success'] and events[-1] == terminals[0]
    assert not any(e['type'] == 'error' for e in events)
    counts, cases = Counter(), []
    for end in ends:
        if end.get('hidden'):
            continue
        start = starts[end['testID']]
        path = suites[start['suiteID']]
        path = Path(unquote(urlparse(path).path)) if path.startswith('file:') else Path(path)
        if not path.is_absolute():
            path = Path(command['cwd']) / path
        file = str(path.resolve().relative_to(REPO))
        counts[(file, start['name'])] += 1
        assert end['result'] == 'success' and not end.get('skipped')
        cases.append({'file': file, 'name': start['name'],
                      'occurrence': counts[(file, start['name'])], 'result': end['result'],
                      'skipped': False, 'gate': command['name']})
    expected_paths = {str((Path(command['cwd']) / p).resolve().relative_to(REPO))
                      for p in command['expected_test_files']}
    assert {c['file'] for c in cases} == expected_paths
    exported = read(RUN / (command['name'] + '-cases.json'))
    assert [(key(c), c['result'], c['skipped']) for c in cases] == [
        (key(c), c['result'], c['skipped']) for c in exported]
    (portable if command['name'] == 'core-node' else fresh).extend(cases)
assert len(fresh) == len(set(map(key, fresh))) == 411
assert len({c['file'] for c in fresh}) == 23 and len(portable) == 28
for seal in ('source', 'dependencies', 'runtime'):
    assert read(RUN / (seal + '-before.json')) == read(RUN / (seal + '-after.json'))
    # The qualifier records the canonical compact JSON digest, not the
    # human-readable indented manifest file's byte digest.
    canonical_manifest = json.dumps(read(RUN / (seal + '-before.json')),
        sort_keys=True, separators=(',', ':')).encode()
    assert sha(canonical_manifest) == receipt[seal + '_before_sha256']
assert receipt['source_head'] == receipt['source_head_after']
assert receipt['source_tree'] == receipt['source_tree_after'] and receipt['git_status_after'] == ''

previous = read(BASELINE / 'accepted-test-cases.json')
previous_node = read(BASELINE / 'accepted-platform-recheck-cases.json')
files = {c['file'] for c in fresh}
retained = [c for c in previous if c['file'] not in files]
replaced = [c for c in previous if c['file'] in files]
old_keys, new_keys = set(map(key, replaced)), set(map(key, fresh))
assert len(retained) == 1125 and len({c['file'] for c in retained}) == 50
assert len(replaced) == 346 and old_keys <= new_keys and len(new_keys - old_keys) == 65
union = retained + fresh
assert len(union) == len(set(map(key, union))) == 1536
assert len({c['file'] for c in union}) == 73
node = [c for c in previous_node if c['file'] not in files] + portable
assert len(node) == len(set(map(key, node))) == 230
assert Counter(map(key, union)) == Counter(map(key, read(ACCEPTED / 'accepted-test-cases.json')))
assert Counter(map(key, node)) == Counter(map(key, read(ACCEPTED / 'accepted-platform-recheck-cases.json')))
node_files = {c['file'] for c in node}
assert Counter(map(key, node)) == Counter(key(c) for c in union if c['file'] in node_files)
assert all(c['result'] == 'success' and not c['skipped'] for c in union + node)
outputs = ('accepted-union.json', 'accepted-test-cases.json', 'accepted-platform-recheck-cases.json',
           'retained-test-cases.json', 'replaced-prior-test-cases.json', 'fresh-test-cases.json', 'new-test-cases.json')
for name in outputs:
    assert (ACCEPTED / name).read_bytes() == (INDEPENDENT / name).read_bytes(), name
proof = read(ACCEPTED / 'accepted-union.json')
assert proof['status'] == 'passed'
assert proof['source_seals_unchanged'] and proof['dependency_seals_unchanged'] and proof['runtime_seals_unchanged']
assert proof['native_outside_autoconnect_and_explicit_remote_load_exact']
assert proof['message_list_outside_constructor_alias_validation_exact']
assert proof['cross_run_external_dependencies_equal'] and proof['cross_run_shared_runtime_and_configuration_equal']
visual = read(RUNTIME / 'pr277-mail-visual-independent-review.json')
assert visual['status'] == 'no_concrete_visual_blocker'
record = {
    'schema': 1, 'success': True, 'actionable_findings': [],
    'accepted_source_head': receipt['source_head'], 'accepted_source_tree': receipt['source_tree'],
    'accepted_cases': 1536, 'accepted_files': 73, 'failed': 0, 'skipped': 0,
    'fresh_cases': 411, 'fresh_files': 23, 'retained_cases': 1125, 'retained_files': 50,
    'replaced_prior_cases_preserved': 346, 'additional_case_identities': 65,
    'platform_rechecks': {'fresh': 28, 'retained': 202, 'total': 230, 'all_match_canonical_ids': True},
    'execution_source_counts': proof['accepted_execution_source_counts'],
    'raw_commands_verified': len(command_rows), 'all_raw_started_tests_complete_once': True,
    'source_sealed_inputs': 5854, 'dependency_sealed_inputs': 6188,
    'reexecuted_portable_verifier_immutable_git_blob_comparisons': 5838 + 5838 + 5854,
    'seven_portable_verifier_outputs_byte_identical': True,
    'native_and_message_list_impact_boundaries_independently_reviewed': True,
    'visual_review': {'new_pngs_inspected': 5, 'prior_reviewed_identical_pngs': 31,
                      'sha256': sha((RUNTIME / 'pr277-mail-visual-independent-review.json').read_bytes())},
    'qualification_sha256': sha((RUN / 'qualification.json').read_bytes()),
    'accepted_union_sha256': sha((ACCEPTED / 'accepted-union.json').read_bytes()),
    'verifier_sha256': sha((RUNTIME / 'verify_mail_pr277_retention.py').read_bytes()),
    'limits': ['Read-only recount/source/evidence inspection; no tests, captures, provider calls, CI, or repo/config/ref changes.',
               'Retained cases keep their actual c623/416/58cc execution heads; only411 cases execute at5c7.',
               '230 Node executions recheck existing identities and are not added to1536.',
               'The prior18-failure aggregate and its later correction remain unchanged in the baseline package.',
               'Shared Studio cases overlap Word evidence; do not sum project-wide coverage totals.'],
    'auditor_sha256': sha(Path(__file__).read_bytes()),
}
out = RUNTIME / 'pr277-mail-final-independent-review.json'
out.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({'path': str(out), 'sha256': sha(out.read_bytes()), 'success': True,
                  'accepted': 1536, 'files': 73, 'node_rechecks': 230}))
