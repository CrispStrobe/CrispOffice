#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 2 ]]; then
  echo "Usage: $0 ABS_FLUTTER_RUNTIME ABS_REPOSITORY" >&2
  exit 2
fi
runtime_dir="$1"
repo_dir="$2"
source "$runtime_dir/env.sh"
mkdir -p "$runtime_dir/test-runner"
dart compile kernel \
  --packages="$repo_dir/.dart_tool/package_config.json" \
  "$runtime_dir/pub-cache/hosted/pub.dev/test-1.31.1/bin/test.dart" \
  -o "$runtime_dir/test-runner/test-runner.dill"
dart --packages="$repo_dir/.dart_tool/package_config.json" \
  "$runtime_dir/test-runner/test-runner.dill" --version
