#!/usr/bin/env python3
"""Run the committed Word BAS on the pinned VM and generated JavaScript."""

import base64
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

task_root = Path('/workspace/scratch/8cc07534c58a')
repo = task_root / 'quds_office_suite'
package = repo / 'packages/quds_office_engine'
runtime = task_root / 'runtime'
logs = runtime / 'logs'
dart = runtime / 'flutter/bin/cache/dart-sdk/bin/dart'
node = shutil.which('node')
assert node is not None
bas = package / 'example/macros/word_table_formatting.bas'
smoke = package / 'tool/macros/web_vba_word_cell_formatting_smoke.dart'
js = runtime / 'mail-union-word-cell-formatting.js'
define = '-DWORD_CELL_FORMAT_BAS_BASE64=' + base64.b64encode(bas.read_bytes()).decode()
source_paths = [
    'packages/quds_office_engine/lib/src/automation/office_operations.dart',
    'packages/quds_office_engine/lib/src/automation/office_vba_language.dart',
    'packages/quds_office_engine/lib/src/automation/operations/word_steps.dart',
    'packages/quds_office_engine/lib/src/automation/operations/word_table_cell_text_steps.dart',
    str(bas.relative_to(repo)),
    str(smoke.relative_to(repo)),
    'packages/quds_office_engine/tool/macros/web_vba_word_table_cells_smoke.dart',
    'pubspec.lock',
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sources():
    return {path: digest(repo / path) for path in source_paths}


summary = {
    'cwd': str(package),
    'runtime': str(dart),
    'dart_version': subprocess.check_output([str(dart), '--version'], text=True).strip(),
    'node': node,
    'node_version': subprocess.check_output([node, '--version'], text=True).strip(),
    'input_sources_sha256': sources(),
    'stages': [],
}
receipt = logs / 'mail-union-word-portable-receipt.json'


def save():
    receipt.write_text(json.dumps(summary, indent=2) + '\n')


def run(stage, command):
    stdout = logs / f'mail-union-word-{stage}.stdout.log'
    stderr = logs / f'mail-union-word-{stage}.stderr.log'
    started = time.monotonic()
    with stdout.open('w') as out, stderr.open('w') as err:
        process = subprocess.Popen(
            command, cwd=package, stdout=out, stderr=err,
            env=os.environ.copy(), start_new_session=True,
        )
        try:
            code = process.wait(timeout=240)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            code = 124
    record = {
        'stage': stage,
        'command': command,
        'exit_code': code,
        'elapsed_seconds': round(time.monotonic() - started, 3),
        'stdout': str(stdout),
        'stderr': str(stderr),
        'stdout_sha256': digest(stdout),
        'stderr_sha256': digest(stderr),
    }
    summary['stages'].append(record)
    save()
    print(json.dumps({key: record[key] for key in ['stage', 'exit_code', 'elapsed_seconds']}), flush=True)
    if code:
        print(stderr.read_text()[-7000:], flush=True)
        raise SystemExit(code)
    return stdout


def equivalent(left, right):
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return math.isfinite(left) and math.isfinite(right) and left == right
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(equivalent(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(equivalent(a, b) for a, b in zip(left, right))
    return left == right


save()
vm_output = run('vm', [str(dart), define, str(smoke)])
run('compile-js', [str(dart), 'compile', 'js', '-O1', define, str(smoke), '-o', str(js)])
node_output = run('node', [node, '-e', 'globalThis.self = globalThis; require(process.argv[1]);', str(js)])
summary['vm_result'] = json.loads(vm_output.read_text())
summary['node_result'] = json.loads(node_output.read_text())
summary['semantic_results_match'] = equivalent(summary['vm_result'], summary['node_result'])
summary['stdout_byte_identical'] = vm_output.read_bytes() == node_output.read_bytes()
summary['output_javascript_sha256'] = digest(js)
summary['source_unchanged'] = summary['input_sources_sha256'] == sources()
summary['passed'] = summary['semantic_results_match'] and summary['source_unchanged']
save()
print(json.dumps({
    'passed': summary['passed'],
    'source_unchanged': summary['source_unchanged'],
    'semantic_results_match': summary['semantic_results_match'],
    'vm_result': summary['vm_result'],
}), flush=True)
if not summary['passed']:
    raise SystemExit(1)
