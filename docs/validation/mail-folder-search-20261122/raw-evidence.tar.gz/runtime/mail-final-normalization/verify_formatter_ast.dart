import 'dart:convert';
import 'dart:io';

import 'package:analyzer/dart/analysis/utilities.dart';

void main() {
  const root = '/workspace/scratch/8cc07534c58a/runtime/mail-final-normalization';
  final receipt = jsonDecode(File('$root/receipt.json').readAsStringSync())
      as Map<String, Object?>;
  final paths = (receipt['format_paths'] as List<Object?>).cast<String>();
  final results = <Map<String, Object?>>[];
  for (final path in paths) {
    final before = parseString(
      content: File('$root/before/$path').readAsStringSync(),
      throwIfDiagnostics: false,
    );
    final after = parseString(
      content: File('$root/after_formatter/$path').readAsStringSync(),
      throwIfDiagnostics: false,
    );
    final equal = before.unit.toSource() == after.unit.toSource();
    results.add({
      'path': path,
      'ast_to_source_equal': equal,
      'before_parser_errors': before.errors.map((error) => '$error').toList(),
      'after_parser_errors': after.errors.map((error) => '$error').toList(),
    });
    if (!equal || before.errors.isNotEmpty || after.errors.isNotEmpty) {
      exitCode = 1;
    }
  }
  final output = {'passed': exitCode == 0, 'files': results};
  File('$root/formatter-ast-equivalence.json').writeAsStringSync(
    '${const JsonEncoder.withIndent('  ').convert(output)}\n',
  );
  print(jsonEncode(output));
}
