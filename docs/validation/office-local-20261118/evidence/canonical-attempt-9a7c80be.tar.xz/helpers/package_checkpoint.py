#!/usr/bin/env python3
"""Package completed canonical commands without reading an active command log."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--complete', action='store_true')
args = parser.parse_args()
run, output = args.run.resolve(), args.output.resolve()
receipt_bytes = (run / 'receipt.json').read_bytes()
receipt = json.loads(receipt_bytes)
finished = [row for row in receipt['commands'] if row['status'] != 'running']
if args.complete:
    assert receipt['status'] != 'running'
summary = {'source_commit': receipt['source_commit'],
           'checkpoint_complete': args.complete,
           'run_status': receipt['status'],
           'qualification_accepted': bool(args.complete and receipt.get('all_passed')),
           'completed_commands': [row['name'] for row in finished],
           'active_commands_excluded': [row['name'] for row in receipt['commands'] if row['status'] == 'running']}
payloads = {'receipt.json': receipt_bytes,
            'checkpoint.json': (json.dumps(summary, indent=2, sort_keys=True) + '\n').encode()}
for path in sorted(run.iterdir()):
    if path.is_file() and path.name not in {'receipt.json', 'run.lock'}:
        payloads[path.name] = path.read_bytes()
for row in finished:
    for path in sorted((run / row['name']).rglob('*')):
        if path.is_file():
            payloads[path.relative_to(run).as_posix()] = path.read_bytes()
for name in ('run_canonical.sh', 'run_calendar_timezones.py', 'package_checkpoint.py',
             'sdk-byte-identical-deduplication.json', 'published-attempt-raw-release.json'):
    path = run.parent / name
    if path.is_file():
        payloads['helpers/' + name] = path.read_bytes()
members = []
with tarfile.open(output, 'w:xz', preset=6) as archive:
    for name, payload in sorted(payloads.items()):
        info = tarfile.TarInfo(name)
        info.size = len(payload)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(payload))
        members.append({'path': name, 'bytes': len(payload),
                        'sha256': hashlib.sha256(payload).hexdigest()})
index = {'archive': output.name, 'archive_bytes': output.stat().st_size,
         'archive_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
         'members': members, **summary}
index_path = output.with_suffix('.index.json')
index_path.write_text(json.dumps(index, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: v for k, v in index.items() if k != 'members'}))
