#!/usr/bin/env python3
"""Run the unchanged retained/boundary harness through its frozen-source guard."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE / 'quds_office_suite'
WORKSPACE = BASE / 'full-validation-workspace'
DART = BASE / 'toolchains/flutter-sdk/bin/cache/dart-sdk/bin/dart'
CONSUMER = BASE / 'consumer-qualification/retained-reference'
GUARD = REPO / 'docs/validation/office-union-20261117/setup/guard_frozen_run.py'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--cohort', choices=('retained33', 'current7', 'boundary5'), required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.absolute()
    output.mkdir(exist_ok=False, parents=True)
    child_output = output / 'result'
    if args.cohort == 'boundary5':
        child = [sys.executable, str(REPO / 'docs/validation/office-reconciled-20261117/resume/consumer-new/verify_boundary_consumers.py'), '--repo', str(REPO), '--workspace', str(WORKSPACE), '--dart', str(DART), '--schemas', str(CONSUMER / 'schemas'), '--output', str(child_output), '--commit', args.commit]
    else:
        harness = CONSUMER / ('wave3-runner/verify_consumers.py' if args.cohort == 'retained33' else 'verify_current_consumers.py')
        child = [sys.executable, str(harness), '--repo', str(WORKSPACE), '--source-repo', str(REPO), '--dart', str(DART), '--schemas', str(CONSUMER / 'schemas'), '--expected-head', args.commit, '--output', str(child_output)]
    command = [sys.executable, str(GUARD), '--repo', str(REPO), '--workspace', str(WORKSPACE), '--dart', str(DART), '--consumer-root', str(CONSUMER), '--output', str(output / 'guard'), '--commit', args.commit, '--', *child]
    env = dict(os.environ, TMPDIR=str(BASE / 'consumer-qualification/tmp'), XDG_CONFIG_HOME=str(BASE / 'consumer-qualification/config'), PYTHONDONTWRITEBYTECODE='1', CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true', PUB_CACHE=str(BASE / 'toolchains/pub-cache'), FLUTTER_ROOT=str(BASE / 'toolchains/flutter-sdk'))
    receipt = {'source_commit': args.commit, 'cohort': args.cohort, 'started_utc': datetime.now(timezone.utc).isoformat(), 'command': command, 'harness_or_oracle_modified': False, 'wrapper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (output / 'invocation.json').write_text(json.dumps(receipt, indent=2) + '\n')
    with (output / 'driver.log').open('wb') as stream:
        result = subprocess.run(command, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=900)
    receipt.update(exit_code=result.returncode, finished_utc=datetime.now(timezone.utc).isoformat())
    (output / 'invocation.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'cohort': args.cohort, 'source_commit': args.commit, 'exit_code': result.returncode, 'output': str(output)}))
    return result.returncode

if __name__ == '__main__':
    raise SystemExit(main())
