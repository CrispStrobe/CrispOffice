from pathlib import Path
import json
r=Path('zotero-toolchain')
for name in ['workspace-pub-get.log','finish-current.log']:
 (r/'logs'/name).rename(r/'logs'/('attempt-hash-newline-'+name))
for record in json.loads((r/'setup/prefetch-162.json').read_text())['packages']:
 p=r/'pub-cache/hosted-hashes/pub.dev'/f"{record['name']}-{record['version']}.sha256"
 assert p.read_text().strip()==record['sha256']
 p.write_text(record['sha256'])
print('Corrected only serialization of 162 verified digest files: removed trailing newline for pub cache format.')
