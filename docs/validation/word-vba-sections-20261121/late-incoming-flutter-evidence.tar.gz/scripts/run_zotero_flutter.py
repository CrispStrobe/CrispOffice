from pathlib import Path
import hashlib
import json
import subprocess
import time

base = Path(__file__).resolve().parent.parent
workspace = base / 'flutter-validation'
editor = workspace / 'packages/quds_office_editor'
output = base / 'flutter-runtime/zotero-transfer'
flutter = str(base / 'flutter-runtime/bin/flutter')
overlay = json.loads((output / 'overlay.json').read_text())
files = ['test/word_zotero_transfer_controller_test.dart', 'test/word_zotero_transfer_dialog_test.dart', 'test/word_zotero_citing_controller_test.dart', 'test/word_zotero_citing_dialog_test.dart', 'test/word_zotero_direct_command_test.dart']
records = []
for label, command in [
    ('analysis', [flutter, 'analyze', '--no-pub', '--fatal-infos', 'lib/src/embed/office_controller.dart', 'lib/src/embed/word_zotero_dialog.dart', *files[:2]]),
    ('regression', [flutter, 'test', '--no-pub', '--reporter=json', '--concurrency=2', *files]),
]:
    start = time.monotonic()
    print('START ' + label, flush=True)
    with (output / (label + '.stdout')).open('wb') as stdout, (output / (label + '.stderr')).open('wb') as stderr:
        result = subprocess.run(command, cwd=editor, stdout=stdout, stderr=stderr, timeout=300)
    record = {'label': label, 'command': command, 'cwd': str(editor), 'exit_code': result.returncode, 'seconds': round(time.monotonic() - start, 3)}
    records.append(record)
    (output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
events = []
for line in (output / 'regression.stdout').read_text(errors='replace').splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        pass
cases = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden')]
receipt = {'overlay': overlay, 'commands': records, 'test_files': files, 'passed': sum(e.get('result') == 'success' and not e.get('skipped') for e in cases), 'failed': sum(e.get('result') != 'success' and not e.get('skipped') for e in cases), 'skipped': sum(bool(e.get('skipped')) for e in cases), 'terminal': [e for e in events if e.get('type') == 'done'], 'changed_inputs': [entry['path'] for entry in overlay['files'] if entry['sha256'] is not None and hashlib.sha256((workspace / entry['path']).read_bytes()).hexdigest() != entry['sha256']]}
(output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ('passed', 'failed', 'skipped', 'terminal', 'changed_inputs')}), flush=True)
