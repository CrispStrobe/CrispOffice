from pathlib import Path
import hashlib
import json
import subprocess
import time

base = Path(__file__).resolve().parent.parent
repo = base / 'quds_office_suite'
workspace = base / 'flutter-validation'
studio = workspace / 'packages/quds_office_editor/example'
output = base / 'flutter-runtime/mail-sessions'
output.mkdir(parents=True, exist_ok=True)
incoming = '6ec90c8a3acdc8fb5878f1decef0131e478e6b1d'
paths = [
    'packages/quds_mail_store/lib/src/mailbox_views.dart',
    'packages/quds_office_editor/example/lib/studio_mail_mailbox_session.dart',
    'packages/quds_office_editor/example/lib/studio_mail_mailbox_store.dart',
    'packages/quds_office_editor/example/lib/studio_mail_native.dart',
    'packages/quds_office_editor/example/lib/studio_mail_ews.dart',
    'packages/quds_office_editor/example/test/studio_mail_mailbox_session_test.dart',
    'packages/quds_office_editor/example/test/studio_mail_capture_projection_test.dart',
    'packages/quds_office_editor/example/test/studio_mail_mailbox_store_test.dart',
]
inputs = {}
for path in paths:
    data = subprocess.check_output(['git', 'show', incoming + ':' + path], cwd=repo)
    target = workspace / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    inputs[path] = hashlib.sha256(data).hexdigest()
overlay = {'incoming': incoming, 'mailbox_views_prerequisite': 'c375becb51939dcca5c145bf1bcdb14a4febe041 (inherited unchanged by incoming)', 'source_sha256': inputs}
(output / 'overlay.json').write_text(json.dumps(overlay, indent=2) + '\n')
files = ['test/studio_mail_mailbox_session_test.dart', 'test/studio_mail_capture_projection_test.dart', 'test/studio_mail_mailbox_store_test.dart']
analysis = ['lib/studio_mail_mailbox_session.dart', 'lib/studio_mail_mailbox_store.dart', 'lib/studio_mail_native.dart', 'lib/studio_mail_ews.dart', *files]
records = []
for label, command in [
    ('analysis', [str(base / 'flutter-runtime/bin/dart'), 'analyze', '--fatal-infos', *analysis]),
    ('regression', [str(base / 'flutter-runtime/bin/flutter'), 'test', '--no-pub', '--reporter=json', '--concurrency=2', *files]),
]:
    start = time.monotonic()
    print('START ' + label, flush=True)
    with (output / (label + '.stdout')).open('wb') as stdout, (output / (label + '.stderr')).open('wb') as stderr:
        result = subprocess.run(command, cwd=studio, stdout=stdout, stderr=stderr, timeout=300)
    record = {'label': label, 'command': command, 'cwd': str(studio), 'exit_code': result.returncode, 'seconds': round(time.monotonic() - start, 3)}
    records.append(record)
    (output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
events = []
for line in (output / 'regression.stdout').read_text(errors='replace').splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        pass
cases = [e for e in events if e.get('type') == 'testDone' and not e.get('hidden')]
receipt = {'overlay': overlay, 'commands': records, 'test_files': files, 'passed': sum(e.get('result') == 'success' and not e.get('skipped') for e in cases), 'failed': sum(e.get('result') != 'success' and not e.get('skipped') for e in cases), 'skipped': sum(bool(e.get('skipped')) for e in cases), 'terminal': [e for e in events if e.get('type') == 'done'], 'changed_inputs': [path for path, digest in inputs.items() if hashlib.sha256((workspace / path).read_bytes()).hexdigest() != digest]}
(output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ('passed', 'failed', 'skipped', 'terminal', 'changed_inputs')}), flush=True)
