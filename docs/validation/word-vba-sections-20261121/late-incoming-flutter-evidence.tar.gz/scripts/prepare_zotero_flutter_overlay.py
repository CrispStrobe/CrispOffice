from pathlib import Path
import hashlib
import json
import subprocess

base = Path(__file__).resolve().parent.parent
repo = base / 'quds_office_suite'
workspace = base / 'flutter-validation'
output = base / 'flutter-runtime/zotero-transfer'
output.mkdir(parents=True, exist_ok=True)
ours = subprocess.check_output(['git', 'rev-parse', '81b762008'], cwd=repo, text=True).strip()
incoming = '3da241d5f1f3e43d7be47f00bcf7fbe62bd8272b'
ancestor = subprocess.check_output(['git', 'merge-base', ours, incoming], cwd=repo, text=True).strip()
paths = subprocess.check_output(['git', 'diff', '--name-only', ancestor, incoming, '--', 'packages/quds_office_editor', 'packages/quds_office_engine'], cwd=repo, text=True).splitlines()

def blob(revision, path):
    result = subprocess.run(['git', 'show', revision + ':' + path], cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    return result.stdout if result.returncode == 0 else None

files = {}
records = []
for index, path in enumerate(paths):
    original, left, right = blob(ancestor, path), blob(ours, path), blob(incoming, path)
    if left == original or left == right:
        merged = right
        resolution = 'incoming'
    elif right == original:
        merged = left
        resolution = 'current'
    elif None not in (original, left, right):
        temporary = output / ('merge-' + str(index))
        temporary.mkdir(exist_ok=True)
        for label, data in (('current', left), ('ancestor', original), ('incoming', right)):
            (temporary / label).write_bytes(data)
        result = subprocess.run(['git', 'merge-file', '-p', str(temporary / 'current'), str(temporary / 'ancestor'), str(temporary / 'incoming')], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if result.returncode != 0:
            (temporary / 'conflict').write_bytes(result.stdout)
            raise SystemExit('Unresolved overlay conflict: ' + path)
        merged = result.stdout
        resolution = 'three-way'
    else:
        raise SystemExit('Unresolved add/delete overlay: ' + path)
    files[path] = merged
    records.append({'path': path, 'resolution': resolution, 'sha256': hashlib.sha256(merged).hexdigest() if merged is not None else None})
controller = files['packages/quds_office_editor/lib/src/embed/office_controller.dart'].decode()
if '_timedListeners.clear();' not in controller or 'if (replaced) _documentReplaced = true;' not in controller or 'WordZoteroTransfer.isTransferDocument(document)' not in controller:
    raise SystemExit('Merged controller lost a required incoming or main behavior')
for path, data in files.items():
    target = workspace / path
    if data is None:
        if target.exists():
            target.unlink()
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
receipt = {'current': ours, 'incoming': incoming, 'merge_base': ancestor, 'controller_preserves_lazy_retry_and_listener_cleanup': True, 'files': records}
(output / 'overlay.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
