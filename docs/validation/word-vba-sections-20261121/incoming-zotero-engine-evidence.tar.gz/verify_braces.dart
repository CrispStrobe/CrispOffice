import 'dart:convert';
import 'dart:io';

import 'package:analyzer/dart/analysis/utilities.dart';

List<String> tokens(String path) {
  final parsed = parseString(content: File(path).readAsStringSync());
  if (parsed.errors.isNotEmpty) {
    throw StateError('Unexpected parse diagnostics: ${parsed.errors}');
  }
  final result = <String>[];
  var token = parsed.unit.beginToken;
  while (!token.isEof) {
    if (token.lexeme != '{' && token.lexeme != '}') {
      result.add(token.lexeme);
    }
    token = token.next!;
  }
  return result;
}

void main(List<String> args) {
  final before = tokens(args[0]);
  final after = tokens(args[1]);
  final equal = before.length == after.length &&
      Iterable<int>.generate(before.length)
          .every((index) => before[index] == after[index]);
  stdout.writeln(jsonEncode({
    'nonBraceTokensBefore': before.length,
    'nonBraceTokensAfter': after.length,
    'nonBraceTokensIdentical': equal,
  }));
  if (!equal) exitCode = 1;
}
