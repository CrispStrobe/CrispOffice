from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import os
import shutil
import subprocess
import tarfile
import time
import urllib.parse
import urllib.request
import yaml

base = Path(__file__).resolve().parent.parent
root = base / 'flutter-runtime'
repository = base / 'quds_office_suite'
workspace = base / 'flutter-validation'
sdk = root / 'flutter'
cache = root / 'pub-cache'
logs = root / 'logs'
for path in (root, workspace, cache, logs, root / 'bin', root / 'tmp', root / 'config', root / 'cache', root / 'data'):
    path.mkdir(exist_ok=True, parents=True)
metadata = json.loads((base / 'runtime/flutter-releases-linux.json').read_text())
release = next(item for item in metadata['releases'] if item.get('version') == '3.47.8' and item.get('channel') == 'stable')
url = metadata['base_url'] + '/' + release['archive']
(root / 'official-release.json').write_text(json.dumps(release, indent=2) + '\n')
record = {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'running', 'release': release, 'source': str(repository), 'workspace': str(workspace), 'runs': []}

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(8 * 1024 * 1024):
            digest.update(block)
    return digest.hexdigest()

def save():
    (root / 'runtime.json').write_text(json.dumps(record, indent=2) + '\n')

class DigestReader:
    def __init__(self, stream):
        self.stream = stream
        self.hash = hashlib.sha256()
        self.total = 0
    def read(self, n=-1):
        data = self.stream.read(n)
        self.hash.update(data)
        self.total += len(data)
        return data

def selected(name):
    parts = PurePosixPath(name).parts
    if not parts or parts[0] != 'flutter':
        return False
    if len(parts) == 1:
        return True
    if parts[1] == '.git':
        return True
    if parts[1] == 'bin':
        relative = '/'.join(parts[1:])
        if relative.startswith('bin/cache/artifacts/engine/'):
            platform = parts[5] if len(parts) > 5 else ''
            if platform.startswith(('android', 'ios', 'darwin', 'windows', 'linux-arm64', 'linux-x64-profile', 'linux-x64-release')):
                return False
        return True
    if parts[1] == 'packages':
        return not (len(parts) > 3 and parts[3] in {'test', 'test_private', 'test_fixes', 'example', 'examples', 'benchmark', 'benchmarks'})
    return len(parts) == 2 and parts[1] in {'LICENSE', 'AUTHORS', 'README.md', 'version', '.metadata', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'}

def run(label, command, cwd):
    start = time.monotonic()
    print('START ' + label, flush=True)
    with (logs / (label + '.stdout')).open('wb') as stdout, (logs / (label + '.stderr')).open('wb') as stderr:
        result = subprocess.run([str(item) for item in command], cwd=cwd, env=env, stdout=stdout, stderr=stderr, timeout=300)
    record['runs'].append({'label': label, 'command': [str(item) for item in command], 'cwd': str(cwd), 'exit_code': result.returncode, 'seconds': round(time.monotonic() - start, 3)})
    save()
    print('END ' + label + ' exit=' + str(result.returncode), flush=True)
    if result.returncode:
        raise RuntimeError(label + ': ' + (logs / (label + '.stderr')).read_text(errors='replace')[-5000:] + (logs / (label + '.stdout')).read_text(errors='replace')[-5000:])

try:
    save()
    print('Downloading official Flutter 3.47.8 (1,581,444,364 bytes)', flush=True)
    expanded = 0
    last = time.monotonic()
    with urllib.request.urlopen(url, timeout=120) as response:
        reader = DigestReader(response)
        with tarfile.open(fileobj=reader, mode='r|xz') as bundle:
            for member in bundle:
                if selected(member.name):
                    expanded += member.size
                    if expanded > 10 * 1024**3 or shutil.disk_usage(root).free < 2 * 1024**3:
                        raise RuntimeError('SDK extraction exceeded storage budget')
                    bundle.extract(member, root, filter='data')
                if time.monotonic() - last > 15:
                    print(json.dumps({'downloaded_bytes': reader.total, 'selected_expanded_bytes': expanded}), flush=True)
                    last = time.monotonic()
        while reader.read(8 * 1024 * 1024):
            pass
    actual = reader.hash.hexdigest()
    if actual != release['sha256']:
        raise RuntimeError('Official archive checksum mismatch')
    record['archive'] = {'url': url, 'bytes': reader.total, 'sha256': actual, 'verified': True, 'selected_expanded_bytes': expanded}
    save()
    print('Copying isolated repository workspace', flush=True)
    for directory in ('packages', 'apps', 'third_party'):
        shutil.copytree(repository / directory, workspace / directory, dirs_exist_ok=True, ignore=shutil.ignore_patterns('.git', '.dart_tool', 'build'))
    for name in ('pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', '.fvmrc'):
        shutil.copy2(repository / name, workspace / name)
    selected_inputs = [
        'packages/quds_office_editor/lib/src/embed/office_controller.dart',
        'packages/quds_office_editor/test/word_incremental_layout_equivalence_test.dart',
        'packages/quds_office_editor/example/test/studio_typing_proofing_benchmark_test.dart',
        'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
    ]
    record['selected_source_sha256'] = {name: sha(workspace / name) for name in selected_inputs}
    record['workspace_lock_sha256'] = sha(workspace / 'pubspec.lock')
    save()
    packages = {}
    for lock in (sdk / 'packages/flutter_tools/pubspec.lock', workspace / 'pubspec.lock'):
        for name, item in yaml.safe_load(lock.read_text())['packages'].items():
            if item['source'] != 'hosted':
                continue
            info = item['description']
            if info['url'] != 'https://pub.dev':
                raise RuntimeError('Unexpected package host')
            key = name + '-' + item['version']
            entry = {'name': name, 'version': item['version'], 'sha256': info['sha256']}
            if key in packages and packages[key] != entry:
                raise RuntimeError('Conflicting package hashes')
            packages[key] = entry
    for path in (cache / '_temp', cache / 'hosted/pub.dev', cache / 'hosted-hashes/pub.dev'):
        path.mkdir(exist_ok=True, parents=True)
    def fetch(pair):
        key, item = pair
        target = cache / 'hosted/pub.dev' / key
        mark = cache / 'hosted-hashes/pub.dev' / (key + '.sha256')
        existing = base / 'runtime/pub-cache/hosted/pub.dev' / key
        existing_mark = base / 'runtime/pub-cache/hosted-hashes/pub.dev' / (key + '.sha256')
        if existing.is_dir() and existing_mark.is_file() and existing_mark.read_text().strip() == item['sha256']:
            shutil.copytree(existing, target, dirs_exist_ok=True)
            mark.write_text(item['sha256'])
            return dict(item, restored_from_verified_cache=True)
        package_url = 'https://pub.dev/api/archives/' + urllib.parse.quote(key, safe='-._+') + '.tar.gz'
        with urllib.request.urlopen(package_url, timeout=120) as response:
            data = response.read()
        actual = hashlib.sha256(data).hexdigest()
        if actual != item['sha256']:
            raise RuntimeError('Package hash mismatch: ' + key)
        target.mkdir(exist_ok=True)
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as bundle:
            bundle.extractall(target, filter='data')
        mark.write_text(actual)
        return dict(item, url=package_url, bytes=len(data), verified=True)
    print('Restoring ' + str(len(packages)) + ' pinned hosted packages', flush=True)
    with ThreadPoolExecutor(max_workers=16) as pool:
        receipts = list(pool.map(fetch, sorted(packages.items())))
    (root / 'pub-cache-receipt.json').write_text(json.dumps(receipts, indent=2) + '\n')
    record['hosted_packages_verified'] = len(receipts)
    env = dict(os.environ, PUB_CACHE=str(cache), FLUTTER_ROOT=str(sdk), CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true', DASH__SUPPRESS_ANALYTICS='true', XDG_CONFIG_HOME=str(root / 'config'), XDG_CACHE_HOME=str(root / 'cache'), XDG_DATA_HOME=str(root / 'data'), TMPDIR=str(root / 'tmp'))
    dart = sdk / 'bin/cache/dart-sdk/bin/dart'
    run('flutter-tools-pub-get', [dart, 'pub', 'get', '--offline', '--enforce-lockfile'], sdk / 'packages/flutter_tools')
    wrapper = root / 'bin/flutter'
    import shlex
    wrapper.write_text('#!/bin/sh\n' + ''.join('export ' + key + '=' + shlex.quote(env[key]) + '\n' for key in ('PUB_CACHE', 'FLUTTER_ROOT', 'CI', 'DART_SUPPRESS_ANALYTICS', 'FLUTTER_SUPPRESS_ANALYTICS', 'DASH__SUPPRESS_ANALYTICS', 'XDG_CONFIG_HOME', 'XDG_CACHE_HOME', 'XDG_DATA_HOME', 'TMPDIR')) + 'exec ' + shlex.quote(str(dart)) + ' ' + shlex.quote(str(sdk / 'bin/cache/flutter_tools.snapshot')) + ' --no-version-check "$@"\n')
    wrapper.chmod(0o755)
    run('workspace-pub-get', [dart, 'pub', 'get', '--offline', '--enforce-lockfile'], workspace)
    if sha(workspace / 'pubspec.lock') != record['workspace_lock_sha256']:
        raise RuntimeError('Workspace lock changed')
    run('flutter-version', [wrapper, '--version', '--machine'], workspace)
    version = json.loads((logs / 'flutter-version.stdout').read_text())
    if version['frameworkRevision'] != release['hash'] or version['dartSdkVersion'] != release['dart_sdk_version']:
        raise RuntimeError('Runtime version mismatch')
    record['version'] = version
    record['status'] = 'ready'
except BaseException as error:
    record['status'] = 'failed'
    record['error'] = repr(error)
    raise
finally:
    record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps({'status': record['status'], 'error': record.get('error')}), flush=True)
