from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time

base = Path(__file__).resolve().parent.parent
repository = base / 'quds_office_suite'
workspace = base / 'flutter-validation'
output = base / 'flutter-runtime/logs'
flutter = str(base / 'flutter-runtime/bin/flutter')
revision = 'c375becb51939dcca5c145bf1bcdb14a4febe041'
paths = [
    'packages/quds_office_editor/lib/src/embed/office_controller.dart',
    'packages/quds_office_editor/test/word_incremental_layout_equivalence_test.dart',
    'packages/quds_office_editor/example/test/studio_typing_proofing_benchmark_test.dart',
    'packages/quds_office_engine/lib/src/word/layout/word_layout.dart',
]
inputs = {}
for path in paths:
    data = subprocess.check_output(['git', 'show', revision + ':' + path], cwd=repository)
    (workspace / path).write_bytes(data)
    inputs[path] = hashlib.sha256(data).hexdigest()
receipt = {'captured_revision': revision, 'selected_source_sha256': inputs, 'started_at_utc': datetime.now(timezone.utc).isoformat(), 'runs': []}
receipt_path = output / 'focused-flutter-receipt.json'
def save():
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
save()
for label, relative, test, benchmark in [
    ('word-layout-equivalence', 'packages/quds_office_editor', 'test/word_incremental_layout_equivalence_test.dart', False),
    ('studio-typing-benchmark', 'packages/quds_office_editor/example', 'test/studio_typing_proofing_benchmark_test.dart', True),
]:
    command = [flutter, 'test', '--no-pub', '--reporter=json', '--concurrency=1', test]
    env = dict(os.environ)
    if benchmark:
        env['QUDS_TYPING_BENCHMARK'] = '1'
    start = time.monotonic()
    print('START ' + label, flush=True)
    timed_out = False
    with (output / (label + '.jsonl')).open('wb') as stdout, (output / (label + '.stderr')).open('wb') as stderr:
        try:
            result = subprocess.run(command, cwd=workspace / relative, env=env, stdout=stdout, stderr=stderr, timeout=360)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = None
            timed_out = True
    events = []
    for line in (output / (label + '.jsonl')).read_text(errors='replace').splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    cases = [event for event in events if event.get('type') == 'testDone' and not event.get('hidden')]
    record = {'label': label, 'command': command, 'cwd': str(workspace / relative), 'benchmark_enabled': benchmark, 'exit_code': code, 'timed_out': timed_out, 'seconds': round(time.monotonic() - start, 3), 'passed': sum(e.get('result') == 'success' and not e.get('skipped') for e in cases), 'failed': sum(e.get('result') != 'success' and not e.get('skipped') for e in cases), 'skipped': sum(bool(e.get('skipped')) for e in cases), 'done_events': [event for event in events if event.get('type') == 'done']}
    receipt['runs'].append(record)
    save()
    print(json.dumps(record), flush=True)
receipt['source_changes_during_run'] = [path for path, digest in inputs.items() if hashlib.sha256((workspace / path).read_bytes()).hexdigest() != digest]
receipt['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
save()
